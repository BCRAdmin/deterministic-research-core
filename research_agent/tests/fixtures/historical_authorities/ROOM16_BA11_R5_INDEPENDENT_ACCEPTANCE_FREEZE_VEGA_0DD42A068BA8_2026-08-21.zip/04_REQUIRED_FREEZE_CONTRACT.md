# BA11 Freeze Contract Requirements

Create a machine-readable freeze record, recommended path:

`docs/compiler_foundation/freezes/BA11_CANARY_GOVERNANCE_FREEZE_v1.json`

It must bind at minimum:

```text
contract_id = room16.ba11.canary_governance_freeze
schema_version = 1
status = accepted_frozen
independent_acceptance_receipt_sha256
source_r5_package_sha256
source_r5_manifest_sha256
source_r5_verifier_receipt_sha256
research_implementation_commit
research_implementation_tree
research_evidence_commit
research_evidence_tree
product_commit
product_tree
contract_catalog_sha256
ba10_freeze_lock_sha256
runtime_change_policy = new_rfc_and_independent_review_required
ba12_authorized = false
release_authorized = false
publication_authorized = false
freeze_sha256
```

`freeze_sha256` must use an explicit domain-separated canonical hash.

Also add:

`scripts/ops/verify_ba11_canary_governance_freeze.py`

The verifier must fail closed if any bound identity, source file, commit ancestry,
catalog hash, R5 package identity, BA10 freeze result, or final status differs.

The verifier must also assert that the acceptance/freeze task changed no BA11
runtime implementation files.
