# Vega Execution Runbook — BA11 Acceptance/Freeze

## A. Preflight

1. Verify exact R5 package:
   `f81e08620fac195642291d279492c3751e86dbf5130697e3f8205e512023938c`.
2. Verify Research origin is `BCRAdmin/deterministic-research-core`.
3. Verify current `main` contains `a7f83418c1473ef575467472b66934e4ff026dc8` and accepted
   implementation `d31b2c064043fdc1246737d6fc8c62b392d6417f` in ancestry.
4. Verify Product branch still contains `fafcdbd3586075b5f4d0b50b3b18c22fb7a2e9e2`.
5. Verify no pre-existing Room16 runtime diff.
6. Treat materialbedarf-rechner.de as read-only foreign scope.

## B. Materialize Independent Acceptance

Store `01_EXTERNAL_INDEPENDENT_ACCEPTANCE.json` unchanged or byte-identically
inside the canonical BA11 acceptance evidence location.

Update `RFC-0006_BA11_CANARY_GOVERNANCE_CORRECTION.md`:

- status from correction candidate to `ACCEPTED / FROZEN`;
- record R4 and R5 closure;
- record independent R5 acceptance;
- remove stale wording that says independent rereview is still pending;
- retain the Research/Product authority boundaries.

Do not change runtime semantics.

## C. Freeze

Create the machine freeze contract from
`04_REQUIRED_FREEZE_CONTRACT.md` and a fail-closed verifier.

Required verification:

- exact R5 package/manifest/verifier identities;
- exact Research implementation and Product identities;
- contract catalog hash;
- BA10 raw freeze still PASS;
- R5 targeted tests 18/18;
- R4 targeted tests 54/54;
- full Research regression PASS;
- Product verification PASS;
- no BA11 runtime file changed by this freeze task;
- foreign materialbedarf worktree untouched.

## D. Evidence

Build a deterministic package:

`ROOM16_BA11_INDEPENDENT_ACCEPTANCE_FREEZE_<SHORTSHA>_2026-08-21.zip`

Required members:

```text
00_BA11_ACCEPTANCE_VERDICT.md
01_EXTERNAL_INDEPENDENT_ACCEPTANCE.json
02_BA11_FREEZE_RECORD.json
03_STATUS_TRANSITION.json
04_FREEZE_VERIFIER_RECEIPT.json
05_R5_PACKAGE_BINDING.json
06_BA10_FREEZE_RECEIPT.json
07_FINAL_REGRESSION_RECEIPTS.json
08_SOURCE_TREE_BINDINGS.json
09_CHANGED_FILES.json
10_FOREIGN_WORKTREE_BOUNDARY_REPORT.json
11_NEXT_PHASE_GATE.md
MANIFEST.json
```

Also deliver detached `.zip.sha256` and `.zip.identity.json`.

## E. Git

Only governance/docs/verifier/evidence changes are allowed.
Create additive commit(s) on Research `main`, push after all checks pass.
No Product commit is expected unless verification reveals an identity mismatch,
in which case STOP instead of modifying Product.

## F. Final Status

```text
ba11_independent_rereview = ACCEPTED
ba11_implementation_ready = true
ba11_frozen = true
ba12_authorized = false
release_authorized = false
publication_authorized = false
```

Stop after this. BA12 requires a separate architecture/scope decision because no
authoritative BA12 scope currently exists in the repository.
