# Stop Conditions

Fail closed if:

- the R5 ZIP/hash/manifest/verifier identity differs;
- Research implementation/evidence or Product commit/tree differs;
- R5 18/18, R4 54/54, full Research regression, Product verification or BA10 freeze fails;
- the freeze task requires a runtime code change;
- the contract catalog hash differs unexpectedly;
- any BA0–BA10 authority changes;
- materialbedarf-rechner.de would be modified;
- a push requires force/history rewrite.

On stop:
- do not mark BA11 accepted/frozen;
- do not authorize BA12;
- write deterministic stop evidence only.
