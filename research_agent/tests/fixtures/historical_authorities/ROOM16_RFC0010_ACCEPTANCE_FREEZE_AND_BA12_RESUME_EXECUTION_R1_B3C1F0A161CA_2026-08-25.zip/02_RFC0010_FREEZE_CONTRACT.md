# RFC-0010 Live Capture Transport Freeze

Create a machine freeze record, recommended:

`docs/compiler_foundation/freezes/RFC0010_BA12_LIVE_CAPTURE_TRANSPORT_FREEZE_v1.json`

Bind exactly:

```text
status=accepted_frozen

external_acceptance_receipt_sha256=8b14d0f349c640ac8bb8bb42fbcb20012e88f547296cbdf2e389000c5d75e7a3

r2_package_sha256=4aee8c0d0fe2329f21cc3878ac5144352128abfc184e0ae2048e676b53c02b47
r2_manifest_sha256=a852c0ad10a0b731a6e75b3d0240026d68626c5412c3392ac91c713964848066
r2_package_bytes=89459
r2_package_entries=30

research_implementation_commit=6b2efc3cb2fc82acb0a4eaa3b4e692ad48f52fa5
research_implementation_tree=32970a8daf6057dbc8cb0a9f660401849baaaf11
research_evidence_commit_1=9a97941b6b01118a5c6d53aee38efdab953e82db
research_evidence_commit_2=70f3e0e60bda0331422ee1a3424952678436dfb6

product_commit=6dc397556a1e66a1b6eb29a1b3070914b0d562ba
product_tree=f0a9b323edceb3b41f3141ca077d28b595f7f60f

foreign_boundary_snapshot_sha256=56941934c6e8cc7923e0079f35e8bf09a32819d30dbc371ef3299959dd7b355c
previous_boundary_stop_sha256=c3e32493ca669fa61efcef9cf3e73f461c55bdf387b6b192429f9441ff269581

ba3_contract_sha256=c37dd7847905f9113e5b50af9ba669cebf06f1520c2099de65cb5e4ce16fda2b
semantic_wave_v1_lock=62867ad72cd1a99eee482e75087cbe01449faa650d7cf2c535fd494c5fef30f9
ba10_freeze_sha256=29bc0bf2d00aa22d49fd7bb569cf080cc335778c1773b9e63710ecd61dfebc8e
ba11_freeze_sha256=2c0e0e292f2b167e68814e2e2180f9f0823ea8be452be52b95f56db95a4ca1cf
rfc0008_freeze_sha256=27636f891457a98a790702f8fbba19763e0a8b363978c205c9eca54361a84fb0
rfc0009_freeze_sha256=e9c9e6e5e5573961207babd66d7c981504d118ed4d14e87f7d6a8ca4180904b9
```

## Frozen RFC-0010 semantics

Freeze the two-stage authority boundary:

```text
live provider
-> LiveAttempt/LiveRetrievalReceipt
-> immutable content-addressed capture
-> persisted run closure/binding
-> frozen BA3 RetrievalReceiptIR@1 transport=offline_replay
-> frozen SourceSnapshotIR@1
```

Freeze these invariants:

- no parser receives raw network response before immutable capture;
- provider status must normalize to success before authoritative live receipt;
- error/auth/rate-limit/redirect responses never become source evidence;
- required failure blocks run eligibility;
- process restart recovery uses persisted authority only;
- capture/binding/set/snapshot graph is hash-verified on reload;
- actual adapter public methods are normalizable through the capture boundary;
- paid provider requires explicit approval and upstream cost receipt;
- BA3 replay remains zero provider variable cost;
- frozen BA3 and Semantic Wave remain byte/identity unchanged.

## Final Phase-A state

```text
rfc0010_independent_rereview=ACCEPTED
rfc0010_implementation_ready=true
rfc0010_frozen=true
ba12_resume_authorized=true
release_authorized=false
publication_authorized=false
deploy_authorized=false
```
