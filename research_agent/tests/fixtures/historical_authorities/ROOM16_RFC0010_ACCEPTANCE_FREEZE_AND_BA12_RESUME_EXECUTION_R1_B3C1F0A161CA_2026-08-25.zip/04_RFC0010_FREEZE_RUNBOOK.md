# Phase A — RFC-0010 Freeze Runbook

1. Verify the exact R2 Evidence ZIP and execute its bundled verifier.
2. Verify Research ancestry:
   implementation -> boundary evidence -> finalization evidence.
3. Verify Product exact unchanged head/tree.
4. Capture foreign boundary BEFORE.
5. Materialize the independent acceptance.
6. Mark RFC-0010 `ACCEPTED / FROZEN`.
7. Create machine freeze record + fail-closed freeze verifier.
8. Run all 24 freeze rows and all existing Research/Product/freeze regressions.
9. Confirm zero runtime semantic changes in RFC-0010 freeze phase.
10. Capture foreign boundary PRE-PUSH; require unchanged.
11. Build deterministic freeze evidence.
12. Commit/push freeze + evidence additively to Research `main`.
13. Confirm Research/Product clean and remote drift 0/0.
14. Capture foreign boundary AFTER; require unchanged.
15. Set `ba12_resume_authorized=true`.
16. Continue immediately to Phase B.

Any failure stops before BA12.
