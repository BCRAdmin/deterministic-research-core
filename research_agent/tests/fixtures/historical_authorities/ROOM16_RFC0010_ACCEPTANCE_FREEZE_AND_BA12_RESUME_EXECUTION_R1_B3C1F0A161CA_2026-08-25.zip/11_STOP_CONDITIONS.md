# Stop Conditions

STOP if:

1. RFC-0010 freeze fails before BA12 edits.
2. BA12 requires changing frozen BA3/Semantic Wave, BA10, BA11, RFC-0008,
   RFC-0009 or RFC-0010 semantics.
3. actual live network bytes bypass immutable RFC-0010 capture.
4. an error/auth/rate-limit provider response becomes source evidence.
5. live capture cannot replay deterministically into frozen BA3.
6. actual native Bundle@2 receipt/emitter binding fails.
7. Product needs a static implementation allowlist or weaker trust path.
8. Authority-v3/legacy report remains canonical semantic input.
9. canonical Product routes retain legacy semantic fallback.
10. WM/COST/ABT native end-to-end canary fails.
11. any prior freeze verifier regresses.
12. active canonical legacy semantic readers remain > 0 at candidate gate.
13. full Research/Product/security/dependency gates fail.
14. foreign Materialbedarf state changes during a Room16 evidence window.
15. evidence is nondeterministic.
16. push requires history rewrite.

Do not clean or delete foreign Materialbedarf state to make a Room16 gate pass.
