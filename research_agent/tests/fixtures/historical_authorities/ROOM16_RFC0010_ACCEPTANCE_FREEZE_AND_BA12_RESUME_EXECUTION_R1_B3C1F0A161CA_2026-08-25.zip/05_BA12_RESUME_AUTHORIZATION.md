# Phase B — BA12 Final Resume

RFC-0010 completes the missing live-source transport boundary.

The final canonical Research path must now become:

```text
resolver
-> live provider adapter
-> RFC-0010 LiveAttempt/LiveRetrievalReceipt
-> immutable capture
-> frozen BA3 RetrievalReceiptIR@1 / SourceSnapshotIR@1
-> frozen BA4–BA9 semantic compiler
-> RFC-0009 native CompilerArtifactBundle@2
-> Research-signed BundleReceiptV2
```

Product canonical path:

```text
RFC-0009 native verifier/router
-> Bundle@2 read-only model
-> canonical renderer/report routes/UI
```

## Hard rules

- no direct raw-network parser/semantic ingress;
- no Authority-v3/legacy semantic input in canonical run;
- Authority-v3 may remain output compatibility/archive only;
- no Product semantic truth generation;
- no legacy report fallback in canonical Product routes;
- RFC-0010/RFC-0009/BA10/BA11/Semantic Wave freezes remain PASS;
- foreign Materialbedarf state remains read-only and unchanged during evidence windows.

## Actual live canaries

WM, COST and ABT must be native end-to-end canaries.

For every provider used by each canary, BA12 must bind:

```text
live attempt
live receipt
capture artifact
frozen BA3 receipt/snapshot
semantic result
actual native emitter identity
signed Bundle@2 receipt
Product verification
renderer result
```

A deterministic fixture-only adapter harness is not sufficient for the BA12
native canary gate. At least the configured public/free provider path actually
used for each canary must execute through the live transport.

Paid providers are used only when explicitly configured/approved. Missing paid
credentials must not silently trigger fallback.

## Legacy retirement

At final BA12 candidate:
`active canonical legacy semantic readers = 0`.

Historical replay/fixtures/archive compatibility may remain explicitly
non-authoritative.
