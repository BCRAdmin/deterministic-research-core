# Final Freeze Stop Conditions

STOP only if one of these is reproducible:

1. accepted Product R5 runtime/head/tree no longer matches the frozen candidate;
2. accepted Research R5 implementation/evidence ancestry is broken;
3. R5/R4/RFC0010 acceptance regression fails;
4. a prior freeze verifier fails;
5. canonical runtime again reaches legacy semantic truth/fallback;
6. a blocking dependency/security vulnerability is present;
7. the freeze task itself changes accepted runtime semantics;
8. Boundary Gate v2 detects a Room16-caused foreign scope violation;
9. final freeze evidence is nondeterministic or fails its verifier;
10. push requires force/history rewrite.

Everything else is either:
- corrected as freeze documentation/evidence; or
- recorded as a Known Limit and the freeze proceeds.

No new implementation round is authorized by this package.
