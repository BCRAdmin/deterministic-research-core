# Known Limits — Frozen, Non-Blocking

These are explicitly **not** BA12 blockers:

1. **Archive server remains in the repository.**
   It is noncanonical, explicit acknowledgement-gated and loopback-only.
   Keeping historical/archive compatibility code is intentional.

2. **Foreign Materialbedarf worktrees may change externally.**
   Boundary Gate v2 requires causal non-interference:
   Room16 must not mutate or consume them as authority input.
   External drift is recorded, not treated as a Room16 defect.

3. **R5 reuses the already validated R4 native WM/COST/ABT live lineage.**
   Product R5 changed runtime activation only; it reverified the exact signed
   bundles/receipts and did not alter semantic outputs.
   A redundant new network fetch is not required for the freeze.

4. **Release/publication/deploy/commerce remain disabled.**
   This freeze establishes technical readiness only.

5. **Historical v1/Authority-v3 compatibility artifacts remain available for
   archive/replay evidence.**
   They are not canonical semantic inputs.

A future material change to the frozen architecture is a new change/RFC
decision. It is not "BA13" by default and does not reopen BA12 retroactively.
