# BA12 / Whole-System Freeze Runbook

## 1. Preflight

Verify:
- exact R5 package and bundled verifier;
- Research current head is the R5 evidence successor and accepted R5
  implementation is its parent/ancestor;
- Product branch is exactly the accepted R5 implementation;
- Research/Product clean and synchronized.

If later commits exist, continue only if they are clearly evidence-only and do
not change accepted runtime semantics.

## 2. Re-run the closure proof

Run all 30 freeze rows.

Also run the exact existing:
- R5 matrix;
- R4 BA12 matrix;
- RFC-0010 delta matrix;
- full Research/Product verification;
- all freeze verifiers;
- dependency audits;
- Boundary Gate v2.

## 3. Freeze-only mutation check

Before committing freeze material, prove that the freeze task itself changed
zero accepted Product runtime files and zero accepted BA12 Research runtime
files.

Only status/freeze/verifier/closure/evidence docs may change.

## 4. Materialize final status

- RFC-0007 / BA12 -> `ACCEPTED / FROZEN`;
- create whole-system machine freeze record;
- create fail-closed whole-system freeze verifier;
- create final closure/known-limits/roadmap document.

## 5. Deterministic evidence

Build:

`ROOM16_BA12_WHOLE_SYSTEM_FREEZE_<SHORTSHA>_2026-08-25.zip`

Required:

```text
00_FINAL_FREEZE_VERDICT.md
01_EXTERNAL_INDEPENDENT_BA12_ACCEPTANCE.json
02_WHOLE_SYSTEM_FREEZE_RECORD.json
03_KNOWN_LIMITS_AND_NONBLOCKERS.md
04_FREEZE_TEST_MATRIX_EXECUTED.json
05_R5_PACKAGE_BINDING.json
06_CANONICAL_RUNTIME_BINDING.json
07_WM_COST_ABT_BINDING.json
08_FULL_REGRESSION_RECEIPTS.json
09_ALL_PRIOR_FREEZE_RECEIPTS.json
10_SECURITY_DEPENDENCY_REPORT.json
11_BOUNDARY_GATE_V2_REPORT.json
12_SOURCE_TREE_BINDINGS.json
13_FREEZE_CHANGED_FILES.json
14_RELEASE_GATE_STATE.json
15_ROADMAP_CLOSURE.md
16_DETERMINISTIC_BUILD_REPORT.json
MANIFEST.json
independent_verifier/VERIFIER_RECEIPT.json
```

## 6. Git

Commit/push freeze and evidence additively to Research `main`.

Product receives no runtime/source/config mutation in this closure task.

No force push.

Confirm Research remote drift 0/0 and Product unchanged.

## 7. Stop semantics

STOP only for:
- reproducible accepted-runtime correctness regression;
- reproducible security regression;
- broken accepted Git/source identity;
- freeze evidence verifier/determinism failure;
- Room16-caused foreign boundary violation.

Do not reopen BA12 for documentation/evidence wording or known non-blocking
limitations. Record them and complete the freeze.
