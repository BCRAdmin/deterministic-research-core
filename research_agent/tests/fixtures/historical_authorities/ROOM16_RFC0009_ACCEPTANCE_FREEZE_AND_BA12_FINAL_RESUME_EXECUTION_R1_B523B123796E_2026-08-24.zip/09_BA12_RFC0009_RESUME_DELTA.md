# BA12 Resume Delta — RFC-0009 Final Trust Boundary

The original BA12 50-row scope remains authoritative.

Additional mandatory BA12 checks:

```text
BA12-RFC9-001 actual native emitter implementation_sha256 != synthetic verifier/profile hashes
BA12-RFC9-002 signed BundleReceiptV2 binds full actual emitter identity
BA12-RFC9-003 Product accepts actual signed implementation without static hash allowlist
BA12-RFC9-004 same emitter contract with changed implementation requires matching signed receipt
BA12-RFC9-005 receipt/implementation mismatch blocks
BA12-RFC9-006 ba12_cutover_candidate transition passes state machine
BA12-RFC9-007 renderer_cutover=true passes only at valid BA12 state
BA12-RFC9-008 release/publication/deploy remain false throughout candidate
BA12-RFC9-009 RFC-0009 freeze verifier remains PASS after BA12 implementation
```

These are additions to, not replacements for, the existing 50 BA12 rows.
