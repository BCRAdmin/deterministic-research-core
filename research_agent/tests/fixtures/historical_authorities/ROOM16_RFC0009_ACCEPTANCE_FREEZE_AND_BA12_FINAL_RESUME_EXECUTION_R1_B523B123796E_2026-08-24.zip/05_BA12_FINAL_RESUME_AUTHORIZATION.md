# Phase B — Final BA12 Resume Authorization

RFC-0009 closes the final known trust-boundary blocker.

BA12 may now implement the real native emitter and cutover using the frozen
RFC-0009 contract:

```text
dynamic implementation_sha256
Research-signed receipt binding
source_native CompilerIdentity
bundle_native compatibility state
ba12_cutover_candidate boolean
renderer_cutover boolean
```

## No more trust reinterpretation

Do not modify:
- RFC-0008 root;
- Gen1 migration trust;
- RFC-0009 Gen2 policy semantics;
- Bundle@2 schema semantics;
- native emitter contract identity;
- BA10/BA11 freezes.

A concrete BA12 emitter implementation hash is **not** a frozen trust semantic;
it is a per-implementation signed identity.

## Inventory

Update the BA12 legacy-path inventory:
- trust/ABI entries blocked only by RFC-0008/RFC-0009 become resolved;
- remaining active legacy semantic readers remain BA12 work;
- final candidate must report active canonical legacy semantic readers = 0.

## Native canaries

WM/COST/ABT must be newly compiled through the actual native source path.
Migration/synthetic trust probes do not count.

Required native truth:

```text
semantic_artifact_origin=source_native
mode=bundle_native
compiler_mode=source_native
source_native_fact_generation=true
native_source_production=true
```

Each native canary must bind:
- live/frozen source bytes;
- BA3 request/acquisition/receipt/snapshot hashes;
- BA4–BA9 semantic chain;
- Bundle@2;
- actual BA12 emitter implementation hash;
- Research-signed BundleReceiptV2;
- Product verification/render result.
