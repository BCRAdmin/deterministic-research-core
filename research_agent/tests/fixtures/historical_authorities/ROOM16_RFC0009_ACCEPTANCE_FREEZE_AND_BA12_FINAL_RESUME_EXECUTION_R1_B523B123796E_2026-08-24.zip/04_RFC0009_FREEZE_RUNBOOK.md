# Phase A — RFC-0009 Freeze

1. Verify the exact R2 source ZIP and bundled standalone verifier.
2. Verify Research/Product current heads contain the accepted implementation
   and only additive evidence successors.
3. Materialize the independent acceptance unchanged.
4. Mark RFC-0009 `ACCEPTED / FROZEN`.
5. Create the machine freeze record and fail-closed verifier.
6. Execute all 20 freeze tests, full Research/Product regression, BA10, BA11,
   RFC-0008.
7. Confirm zero semantic/runtime changes during the freeze step.
8. Build deterministic freeze evidence.
9. Commit/push additively to Research `main`.
10. Require clean Research/Product worktrees and remote drift `0/0`.
11. Set `ba12_resume_authorized=true`.
12. Continue immediately to Phase B.

If Phase A fails, STOP before BA12.
