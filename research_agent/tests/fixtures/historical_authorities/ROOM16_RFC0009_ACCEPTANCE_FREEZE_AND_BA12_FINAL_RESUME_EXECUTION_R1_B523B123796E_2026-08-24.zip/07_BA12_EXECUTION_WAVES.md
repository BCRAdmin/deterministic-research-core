# BA12 Execution Waves

## Wave 0 — Discovery / Truth-Path Inventory

Before changing code:

1. inventory Research live/current runner;
2. inventory network/provider acquisition paths;
3. inventory all Authority-v3 compatibility reads/writes;
4. inventory Product truth inputs and report routes;
5. inventory legacy fallback behavior;
6. inventory release/publication/private-beta gates;
7. classify every runtime-reachable legacy path.

Output:
`ba12_legacy_path_inventory.json`.

No code change until the inventory is complete.

## Wave 1 — Live BA3 Cutover

Adapt live acquisition so that every successful live run emits native BA3
receipts/snapshots and downstream passes consume only SourceSnapshotIR.

The old runner is allowed as execution machinery, not semantic authority.

## Wave 2 — Native Compiler Authority

Make native BA3→BA10 the canonical Research semantic run path.

Remove/disable canonical legacy semantic inputs.

Keep read-only replay fixtures and migration evidence.

## Wave 3 — Product Renderer Cutover

Convert all canonical Product report/read surfaces to the hash-verified
CompilerArtifactBundle.

Zero legacy semantic fallback.

## Wave 4 — Legacy Quarantine

Move all remaining legacy runtime roles to explicit:

- output compatibility;
- archive;
- fixture;
- migration evidence.

Runtime scanner must report zero active legacy truth inputs.

## Wave 5 — Cutover / Recovery State Machine

Implement deterministic cutover, rollback-before-freeze and recovery semantics.
Fault-inject every state transition.

## Wave 6 — Whole-System Verification

Run:

- frozen WM/COST/ABT native replay;
- live-source smoke under allowed providers;
- replay captured live bytes offline;
- native vs legacy differential comparison;
- full Research regression;
- full Product verification;
- BA10 freeze;
- BA11 freeze;
- BA11 canary governance;
- Product publish/readiness gates in non-action mode;
- dependency/security audit;
- deterministic artifact rebuild.

## Wave 7 — Evidence Candidate

Build BA12 evidence and stop at:

`ready_for_independent_rereview=true`.

No release, publication or deploy.
