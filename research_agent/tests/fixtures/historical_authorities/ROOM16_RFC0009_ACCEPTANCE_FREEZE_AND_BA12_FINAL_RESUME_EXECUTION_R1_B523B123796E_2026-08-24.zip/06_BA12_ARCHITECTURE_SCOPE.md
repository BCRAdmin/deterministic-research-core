# BA12 Architecture Scope — Final Strangler Cutover

## BA12-A — Live Source-Native Acquisition

Convert the existing live/current Research acquisition runner into a producer of
the already frozen BA3 contracts:

```text
CompileRequestIR
SourceAcquisitionIR
RetrievalReceiptIR
SourceSnapshotIR
```

Rules:

- network/provider bytes never bypass immutable SourceSnapshot authority;
- no parser receives unsnapshotted bytes;
- no live runner may directly create Facts, Metrics, Claims, Decisions or Ratings;
- provider/cost/fallback policy remains frozen and explicit;
- paid provider use requires the existing explicit approval contract;
- same captured bytes replay to the same SourceSnapshot and downstream semantic hashes.

The current runner may remain as an adapter/executor implementation, but not as
a parallel semantic truth path.

## BA12-B — Native Source → CompilerArtifactBundle Authority

The canonical production path becomes:

```text
resolver
-> BA3 CompileRequest
-> BA3 Acquisition
-> Retrieval Receipts
-> immutable SourceSnapshot
-> BA4–BA9 Semantic Compiler
-> BA10 CompilerArtifactBundle
-> Product read-only consumer
-> renderer
```

No Authority-v3 or legacy report object may be consumed as semantic input after
the BA3 boundary.

Authority Bundle v3 may survive only as a deterministic **output-side**
compatibility view generated from CompilerArtifactBundle.

Inverse compatibility is forbidden.

## BA12-C — Full Product Renderer Cutover

Inventory every production report/read surface.

For every canonical report surface:

- input truth = `room16.compiler_artifact_bundle@1`;
- renderer may only create presentation/layout;
- no legacy Fact/Metric/Claim/Decision/Rating source;
- no fallback to a legacy report when the native bundle is missing;
- missing/invalid bundle fails closed with an operator-visible diagnostic.

After cutover, the BA10 state `full_renderer_cutover=false` becomes true through
BA12 evidence; BA10 itself is not edited.

## BA12-D — Legacy Bridge Retirement

Produce a complete machine inventory of legacy paths and classify each as:

```text
retired
archive_read_only
output_compatibility_view
test_fixture
migration_evidence
```

Forbidden final states:

```text
active_semantic_input
active_product_truth
implicit_fallback
silent_dual_write_truth
```

Canonical runtime must have zero active legacy semantic readers.

Do not delete historical evidence merely to satisfy the gate.

## BA12-E — Dual-Run / Cutover State Machine

Implement a Research-owned cutover state machine:

```text
shadow_native
dual_run_compare
cutover_candidate
native_authoritative
legacy_quarantined
frozen
```

Promotion requires:

- same frozen inputs;
- native/legacy differential evidence where legacy comparison is meaningful;
- zero unexplained Fact/Claim/Decision/Lineage divergence;
- WM/COST/ABT frozen-canary replay;
- full Product consumer/render verification;
- BA11 canary-governance PASS;
- explicit operator approval receipt for the cutover state transition.

The legacy path cannot regain authority after BA12 freeze without a new RFC.

## BA12-F — Operational Recovery / Replay

The authoritative native pipeline must have machine contracts for:

- interrupted acquisition;
- partial provider set;
- stale cache;
- corrupted snapshot;
- interrupted compiler pass;
- stale Product mirror;
- renderer failure;
- retry/rerun identity;
- archive restoration;
- rollback before BA12 freeze.

Recovery must preserve Research authority and deterministic replay.

## BA12-G — Whole-System Release Readiness

Create a single Research-owned ReleaseReadinessEnvelope binding:

```text
Foundation freeze
Registry freeze
Semantic compiler freeze
BA10 ABI/renderer freeze
BA11 governance freeze
BA12 cutover identity
Research commit/tree
Product commit/tree
native pipeline receipt
legacy inventory receipt
canary replay receipt
full regression receipt
security/dependency receipt
operator-gate policy
```

This envelope may state `release_ready=true`.

It may **not** state `release_authorized`, `publication_authorized` or
`deploy_authorized=true`.

Those remain external operator decisions.
