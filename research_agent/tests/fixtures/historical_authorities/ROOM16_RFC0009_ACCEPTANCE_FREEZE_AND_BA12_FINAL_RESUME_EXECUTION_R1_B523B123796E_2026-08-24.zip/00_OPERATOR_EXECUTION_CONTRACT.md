# Room16 — RFC-0009 Acceptance/Freeze + Final BA12 Resume

```text
HANDOFF_TYPE                         EXECUTE_RFC0009_FREEZE_THEN_BA12_FINAL_RESUME
RFC0009_R2_INDEPENDENT_VERDICT       ACCEPTED
RFC0009_R2_SHA256                    a0639186b4d54547a4a2249e8eafab7d66ff692b1a54fbb95eb0e4da6c7a829e
RESEARCH_IMPLEMENTATION              a77cad16f16f65eda6524f494b1a15b2442ebe07
RESEARCH_EVIDENCE                    18aa651c5ecac18eebd67578bccf74ba51353598
PRODUCT_IMPLEMENTATION               6dc397556a1e66a1b6eb29a1b3070914b0d562ba
RFC0008_FREEZE                       27636f891457a98a790702f8fbba19763e0a8b363978c205c9eca54361a84fb0
RFC0009_FREEZE_AUTHORIZED            TRUE
BA12_RESUME_AFTER_FREEZE_PASS        TRUE
RELEASE/PUBLICATION/DEPLOY           NOT AUTHORIZED
```

This is the final trust-gate handoff before the actual BA12 rebuild.

## Hard order

Phase A:
- formalize the independent RFC-0009 R2 acceptance;
- freeze RFC-0009;
- verify/push the freeze and its evidence.

Phase B:
- only after Phase A PASS and clean `0/0` remote drift, resume RFC-0007 BA12;
- complete the native source/compiler/Product cutover;
- return a BA12 independent-review candidate.

No operator midpoint confirmation is required between Phase A and Phase B.

## Critical freeze rule

RFC-0009 freezes the **native emitter contract**, not a concrete future BA12
implementation hash.

A BA12 native bundle must carry a dynamic 64-hex `implementation_sha256`.
The Research-signed BundleReceiptV2 binds the full emitter identity, and BA12
final evidence binds that hash to the exact Research commit/tree/file set.

Do not create a static implementation allowlist in Product.

## BA12 state rule

The frozen native verifier must permit strict boolean state transitions for:
- `ba12_cutover_candidate`;
- `renderer_cutover`;
- `compile_allowed`;
- `renderer_eligible`.

It must always block:
- `release_ready=true`;
- `publication_allowed=true`;
- `deploy_allowed=true`

until separate operator gates after BA12.

## Scope

Only:
- `BCRAdmin/deterministic-research-core`
- `BCRAdmin/company-dossier-lab`

Materialbedarf remains read-only foreign scope.

No force-push, merge, deploy, public/member exposure, payment activation,
publication or external communication.
