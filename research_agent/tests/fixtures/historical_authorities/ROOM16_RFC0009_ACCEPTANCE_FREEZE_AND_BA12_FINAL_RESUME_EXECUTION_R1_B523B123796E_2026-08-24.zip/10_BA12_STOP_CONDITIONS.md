# BA12 Stop Conditions — Final Resume

STOP only for a genuinely new frozen-boundary conflict or failed correctness
gate.

Specifically STOP if:

1. RFC-0009 freeze did not complete before BA12 code changes.
2. BA12 requires changing RFC-0008 root, RFC-0009 Gen2 policy semantics,
   Bundle@2 schema semantics, native emitter contract, BA10 or BA11.
3. Product requires a static implementation hash allowlist.
4. Live bytes reach parsing without immutable BA3 SourceSnapshotIR.
5. Authority-v3 or legacy reports remain canonical semantic input.
6. Product canonical report/read routes retain legacy semantic fallback.
7. actual native emitter receipt binding fails.
8. WM/COST/ABT native recompile fails.
9. captured live bytes do not replay deterministically.
10. BA10/BA11/RFC0008/RFC0009 freeze verifier regresses.
11. active canonical legacy semantic readers are nonzero at candidate gate.
12. full Research/Product regression fails.
13. blocking security/dependency issue remains.
14. evidence is nondeterministic.
15. materialbedarf-rechner.de would be modified.
16. push requires history rewrite.

Do not create another RFC merely because a concrete BA12 implementation hash
differs from the RFC-0009 synthetic probe. That difference is expected and is
authorized through the Research-signed receipt model.
