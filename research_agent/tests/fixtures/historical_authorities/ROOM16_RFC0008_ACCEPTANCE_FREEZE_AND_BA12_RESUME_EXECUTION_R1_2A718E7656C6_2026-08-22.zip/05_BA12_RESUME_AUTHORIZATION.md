# Phase B — BA12 Resume Authorization

RFC-0007 and `ba12_legacy_path_inventory.json` are already present in Research.

BA12 resumes only after Phase A has produced a valid RFC-0008 freeze.

## New trust boundary

BA12 now has an accepted successor for the previously blocked BA10 boundary:

```text
CompilerArtifactBundle@1 = frozen compatibility/archive ABI
CompilerArtifactBundle@2 = frozen native-capable successor ABI
Product v2 trust root = frozen Research-owned root
Product v2 verifier/router = frozen trust consumer boundary
```

BA12 may implement native source production using Bundle@2 without modifying the
frozen v2 trust-root/consumer-policy semantics.

## Inventory update

Before BA12 implementation, update the legacy inventory dispositions that were
`blocked_pending_rfc` solely because RFC-0008 was missing.

In particular the BA10/Product trust entries must reference the accepted
RFC-0008 v2 successor.

Other blocked legacy semantic paths remain BA12 implementation work.

## Native emitter rule

BA12 may add a native Bundle@2 emitter/build path and new implementation hashes.
Research receipts authenticate the exact emitted bundle/emitter identity.

Do not change:
- Bundle@2 contract major/schema semantics;
- pinned Product trust root;
- frozen Consumer Policy semantic locks;
- BA10/BA11 anchors;
- v1 verifier/freeze.

If native BA12 genuinely needs one of those frozen semantics changed: STOP and
emit a new RFC trigger.
