# Phase A — RFC-0008 Freeze Runbook

1. Verify the exact R2 evidence ZIP and run its bundled standalone verifier.
2. Verify Research/Product heads and frozen BA10/BA11 identities.
3. Materialize the external independent acceptance unchanged.
4. Update RFC-0008 status to `ACCEPTED / FROZEN`.
5. Create the machine freeze record from `02_RFC0008_FREEZE_CONTRACT.md`.
6. Add a fail-closed freeze verifier.
7. Execute all 20 freeze tests plus full Research/Product regressions.
8. Confirm **zero RFC-0008 runtime implementation changes** in this Phase A.
9. Build deterministic freeze evidence.
10. Commit/push freeze and freeze evidence additively to Research `main`.
11. Verify both repositories clean and remote drift `0/0`.
12. Only then set `ba12_resume_authorized=true`.

If any step fails, STOP before BA12.
