# BA12 Resume Delta after RFC-0008

The previously authorized BA12 scope remains unchanged except for its trust
prerequisite, which is now resolved by RFC-0008.

## Required concrete end-state

Research canonical flow:

```text
resolver
-> live BA3 CompileRequestIR
-> SourceAcquisitionIR
-> RetrievalReceiptIR set
-> immutable SourceSnapshotIR
-> native BA4–BA9 compiler
-> CompilerArtifactBundle@2 bundle_native
-> Research-signed v2 bundle receipt
```

Product canonical flow:

```text
v2 trust-root verifier
-> Bundle@2
-> read-only report model
-> renderer
```

Final runtime rules:

- zero canonical Authority-v3/legacy semantic input;
- Authority-v3 only output compatibility/archive view;
- zero legacy report semantic fallback;
- full canonical Product renderer cutover to v2;
- Product cannot create/edit Research semantic truth;
- operator publication/private-beta/payment gates remain non-actioning unless
  separately authorized.

## Cutover evidence

The final BA12 candidate must include **new native-source WM/COST/ABT v2
canaries**. The RFC-0008 migration canaries are not sufficient because they
truthfully state `native_source_production=false`.

Native canaries must state:

```text
mode=bundle_native
compiler_mode=source_native
source_native_fact_generation=true
native_source_production=true
```

and must retain exact source/receipt/snapshot lineage.
