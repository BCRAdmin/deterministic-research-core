# BA12 Stop Conditions after RFC-0008 Freeze

STOP if:

1. RFC-0008 freeze is not complete/PASS before BA12 edits.
2. BA12 requires changing the frozen v2 trust root, Consumer Policy semantic
   locks, Bundle@2 contract/schema semantics, BA10 or BA11.
3. Any live source reaches parsing without immutable SourceSnapshotIR.
4. Authority-v3 or a legacy report object remains canonical semantic input.
5. Product canonical report/read surfaces retain a legacy semantic fallback.
6. Bundle@2 native state cannot be truthfully emitted.
7. Product v2 verifier/router must be weakened to accept native bundles.
8. WM/COST/ABT native v2 recompile cannot pass.
9. captured live bytes do not replay deterministically.
10. full Research/Product/BA10/BA11/RFC0008 regressions fail.
11. legacy path inventory is incomplete or active legacy semantic readers > 0
    at the candidate gate.
12. security/dependency audit has a blocking issue.
13. evidence is not deterministic.
14. materialbedarf-rechner.de would be changed.
15. push requires force/history rewrite.

On STOP:
- do not self-freeze BA12;
- do not release/publish/deploy;
- return deterministic stop/RFC-trigger evidence.
