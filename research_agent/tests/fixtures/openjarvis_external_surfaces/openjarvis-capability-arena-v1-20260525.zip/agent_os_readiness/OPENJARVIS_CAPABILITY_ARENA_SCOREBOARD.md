# OpenJarvis Capability Arena

- Status: `PASS`
- Modus: `shadow_read_only`
- Source of Truth: `False`
- Aufgaben: `30/30`
- Sichere Quellen: `77`
- Baseline-Dokumente: `8`
- Shadow-Dokumente: `77`
- Runtime-Aktion: `False`
- Empfehlung: `promote_shadow_retrieval_benchmark_to_next_read_only_trial`

## Scoreboard

- `pig_obsidian_baseline`: Ø `85.73`, PASS `20`, WARN `9`, FAIL `1`, Wins `0`
- `openjarvis_shadow`: Ø `98.25`, PASS `30`, WARN `0`, FAIL `0`, Wins `12`

## Kategorien

- `autonomy`: Shadow Ø `100.0`, Baseline Ø `99.8`, Shadow Wins `0`, Baseline Wins `0`, Ties `4`
- `code_qa_shadow`: Shadow Ø `82.5`, Baseline Ø `64.2`, Shadow Wins `1`, Baseline Wins `0`, Ties `0`
- `future_github`: Shadow Ø `82.5`, Baseline Ø `64.2`, Shadow Wins `1`, Baseline Wins `0`, Ties `0`
- `kanzlei`: Shadow Ø `100.0`, Baseline Ø `99.5`, Shadow Wins `0`, Baseline Wins `0`, Ties `2`
- `lioncom`: Shadow Ø `91.25`, Baseline Ø `52.3`, Shadow Wins `2`, Baseline Wins `0`, Ties `0`
- `memory`: Shadow Ø `100.0`, Baseline Ø `99.5`, Shadow Wins `0`, Baseline Wins `0`, Ties `2`
- `openjarvis_policy`: Shadow Ø `100.0`, Baseline Ø `64.0`, Shadow Wins `6`, Baseline Wins `0`, Ties `0`
- `openjarvis_surface`: Shadow Ø `100.0`, Baseline Ø `81.7`, Shadow Wins `2`, Baseline Wins `0`, Ties `0`
- `pig_truth`: Shadow Ø `100.0`, Baseline Ø `99.2`, Shadow Wins `0`, Baseline Wins `0`, Ties `3`
- `quality`: Shadow Ø `100.0`, Baseline Ø `99.8`, Shadow Wins `0`, Baseline Wins `0`, Ties `1`
- `room16`: Shadow Ø `100.0`, Baseline Ø `99.35`, Shadow Wins `0`, Baseline Wins `0`, Ties `4`
- `vivi_worker`: Shadow Ø `100.0`, Baseline Ø `99.8`, Shadow Wins `0`, Baseline Wins `0`, Ties `2`

## Schwächste Shadow-Aufgaben

- `oj_code_qa_shadow_projects` `PASS` score `82.5`: missing sources `package.json`, missing terms `none`
- `lioncom_planning_quality_surface` `PASS` score `82.5`: missing sources `lib/types`, missing terms `none`
- `github_digest_gate` `PASS` score `82.5`: missing sources `OPENJARVIS_THREAT_MODEL`, missing terms `none`
- `oj_policy_shadow_mode` `PASS` score `100.0`: missing sources `none`, missing terms `none`
- `oj_policy_no_runtime` `PASS` score `100.0`: missing sources `none`, missing terms `none`
- `oj_policy_secret_scan` `PASS` score `100.0`: missing sources `none`, missing terms `none`
- `oj_allowed_use_cases` `PASS` score `100.0`: missing sources `none`, missing terms `none`
- `oj_adoption_criteria` `PASS` score `100.0`: missing sources `none`, missing terms `none`

## Nicht-Aktionen

- `no_openjarvis_runtime_execution`
- `no_shell_exec`
- `no_file_write_by_openjarvis`
- `no_network`
- `no_github_api`
- `no_commit_push_release`
