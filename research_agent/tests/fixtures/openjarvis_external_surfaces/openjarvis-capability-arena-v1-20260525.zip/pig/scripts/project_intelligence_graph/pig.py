#!/usr/bin/env python3
"""Project Intelligence Graph query, search, view and verification CLI."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import html
import json
import re
import subprocess
import sys
from collections import defaultdict, deque
from pathlib import Path
from typing import Any


WORKSPACE = Path("/Users/BjornRosinger/Documents/New project")
OUTPUT_DIR = WORKSPACE / "outputs/project_intelligence_graph"
NODES_PATH = OUTPUT_DIR / "nodes.jsonl"
RELATIONSHIPS_PATH = OUTPUT_DIR / "relationships.jsonl"
DRIFT_REPORT_PATH = OUTPUT_DIR / "drift_report.md"
VIEWS_DIR = OUTPUT_DIR / "views"
AUTOMATION_RISK_PATH = OUTPUT_DIR / "automation_risk_registry.json"
OPERATOR_DECISION_PATH = OUTPUT_DIR / "operator_decision_inbox.json"
OPERATOR_DECISION_STATE_PATH = OUTPUT_DIR / "operator_decision_state.json"
COVERAGE_MANIFEST_PATH = OUTPUT_DIR / "coverage_manifest.json"
POLICY_GATE_PATH = OUTPUT_DIR / "policy_gate_report.json"
CONTRACT_QUALITY_PATH = OUTPUT_DIR / "contract_quality_gate.json"
LONG_RUN_COMPLETION_AUDIT_PATH = OUTPUT_DIR / "long_run_completion_audit.json"
VAULT_UMLAUT_HYGIENE_PATH = OUTPUT_DIR / "vault_umlaut_hygiene.json"
SKILL_POLICY_REGRESSION_AUDIT_PATH = OUTPUT_DIR / "skill_policy_regression_guard_audit.json"
RULE_PROPAGATION_AUDIT_PATH = OUTPUT_DIR / "rule_propagation_audit.json"
PROJECT_INVARIANT_AUDIT_PATH = OUTPUT_DIR / "project_invariant_audit.json"
AGENT_ENTRYPOINT_AUDIT_PATH = OUTPUT_DIR / "agent_entrypoint_audit.json"
OPERATOR_INTENT_CONTRACT_AUDIT_PATH = OUTPUT_DIR / "operator_intent_contract_audit.json"
OPERATOR_INTENT_CONTRACTS_DIR = OUTPUT_DIR / "operator_intent_contracts"
LATEST_OPERATOR_INTENT_CONTRACT_PATH = OUTPUT_DIR / "latest_operator_intent_contract.json"
IMPACT_RADIUS_ASSESSMENT_PATH = OUTPUT_DIR / "impact_radius_assessment.json"
GERMAN_OUTPUT_QUALITY_AUDIT_PATH = OUTPUT_DIR / "german_output_quality_gate.json"
AUTONOMY_GOVERNOR_AUDIT_PATH = OUTPUT_DIR / "autonomy_governor_audit.json"
AUTONOMY_EXECUTION_QUEUE_PATH = OUTPUT_DIR / "autonomy_execution_queue.json"
AUTONOMY_EXECUTION_QUEUE_STATE_PATH = OUTPUT_DIR / "autonomy_execution_queue_state.json"
AUTONOMY_DIRT_BACKLOG_SCAN_PATH = OUTPUT_DIR / "autonomy_dirt_backlog_scan.json"
AUTONOMY_DIRT_DECISION_STATE_PATH = OUTPUT_DIR / "autonomy_dirt_decision_state.json"
COMMIT_CLEANUP_GO_PACKAGE_PATH = OUTPUT_DIR / "commit_cleanup_go_package.json"
VIVI_VEGA_HANDOFF_INBOX_PATH = OUTPUT_DIR / "vivi_vega_handoff_inbox.json"
VIVI_VEGA_HANDOFF_STATE_PATH = OUTPUT_DIR / "vivi_vega_handoff_state.json"
FRESH_SESSION_READINESS_AUDIT_PATH = OUTPUT_DIR / "fresh_session_readiness_audit.json"
FRESH_DATA_INTAKE_PATH = OUTPUT_DIR / "fresh_data_intake.json"
VIVI_JOB_CARD_QUEUE_PATH = OUTPUT_DIR / "vivi_job_card_queue.json"
VIVI_RUNNER_LAST_RUN_PATH = OUTPUT_DIR / "vivi_runner_last_run.json"
VIVI_SUPERVISOR_AUDIT_PATH = OUTPUT_DIR / "vivi_supervisor_audit.json"
VIVI_WORKER_QUEUE_PATH = OUTPUT_DIR / "vivi_worker_queue.json"
VIVI_WORKER_LAST_RUN_PATH = OUTPUT_DIR / "vivi_worker_last_run.json"
VIVI_WORKER_SUPERVISOR_AUDIT_PATH = OUTPUT_DIR / "vivi_worker_supervisor_audit.json"
ENDGAME_ROADMAP_PATH = OUTPUT_DIR / "endgame_roadmap.json"
AUTONOMY_SOAK_AUDIT_PATH = OUTPUT_DIR / "autonomy_soak_audit.json"
VIVI_CAPABILITY_MATRIX_PATH = OUTPUT_DIR / "vivi_capability_matrix.json"
PROJECT_VERTICAL_ROLLOUT_PATH = OUTPUT_DIR / "project_vertical_rollout.json"
LAUNCH_READINESS_PATH = OUTPUT_DIR / "launch_readiness_package.json"
LIONCOM_MISSION_CONTROL_DIR = Path("/Users/BjornRosinger/Documents/DreamFactory/LIONCOM/mission-control-board")
LIONCOM_PORTFOLIO_PAGE_PATH = LIONCOM_MISSION_CONTROL_DIR / "components/portfolio-control-tower-page.tsx"
LIONCOM_TYPES_PATH = LIONCOM_MISSION_CONTROL_DIR / "lib/types.ts"
LIONCOM_PLANNING_SURFACE_VERIFIER_PATH = LIONCOM_MISSION_CONTROL_DIR / "scripts/verify_planning_quality_surface.mjs"
OPENJARVIS_CAPABILITY_LAB_PATHS = [
    Path("/Users/BjornRosinger/Documents/New project 2/outputs/agent_os_readiness/OPENJARVIS_CAPABILITY_LAB.json"),
    Path("/Users/BjornRosinger/Documents/New project 2/outputs/openjarvis_capability_lab/OPENJARVIS_CAPABILITY_LAB.json"),
]
OPENJARVIS_CAPABILITY_ARENA_PATHS = [
    Path("/Users/BjornRosinger/Documents/New project 2/outputs/agent_os_readiness/OPENJARVIS_CAPABILITY_ARENA_SCOREBOARD.json"),
    Path("/Users/BjornRosinger/Documents/New project 2/outputs/openjarvis_capability_lab/capability_arena/CAPABILITY_ARENA_SCOREBOARD.json"),
]
OPERATOR_BRIEF_PATH = OUTPUT_DIR / "operator_brief.json"
HARDENING_CONTRACTS_DIR = OUTPUT_DIR / "hardening_fix_contracts"
QUALITY_SNAPSHOTS_DIR = OUTPUT_DIR / "quality_snapshots"
QUALITY_BASELINE_PATH = OUTPUT_DIR / "quality_baseline.json"
QUALITY_GATE_REPORT_PATH = OUTPUT_DIR / "quality_gate_report.json"
BUILD_CONTRACTS_DIR = OUTPUT_DIR / "build_contracts"
JOB_CARDS_DIR = OUTPUT_DIR / "job_cards"
WORKFLOW_RUNS_DIR = OUTPUT_DIR / "workflow_runs"
QUALITY_OS_SURFACE_PATH = OUTPUT_DIR / "quality_os_operator_surface.json"
QUALITY_OS_CONTROLS_PATH = OUTPUT_DIR / "quality_os_operator_controls.json"
QUALITY_OS_HANDOFF_PATH = OUTPUT_DIR / "quality_os_fresh_session_handoff.json"
DOCS_DIR = WORKSPACE / "docs/project-intelligence-graph"
NODE_SCHEMA_PATH = DOCS_DIR / "NODE_SCHEMA.json"
PREDICATE_REGISTRY_PATH = DOCS_DIR / "PREDICATE_REGISTRY.json"
POLICY_RULES_PATH = DOCS_DIR / "POLICY_RULES.json"
HARDENING_FIX_SCHEMA_PATH = DOCS_DIR / "HARDENING_FIX_SCHEMA.json"
QUALITY_SNAPSHOT_SCHEMA_PATH = DOCS_DIR / "QUALITY_SNAPSHOT_SCHEMA.json"
BUILD_CONTRACT_SCHEMA_PATH = DOCS_DIR / "BUILD_CONTRACT_SCHEMA.json"
JOB_CARD_SCHEMA_PATH = DOCS_DIR / "JOB_CARD_SCHEMA.json"
EXECUTION_HISTORY_SCHEMA_PATH = DOCS_DIR / "EXECUTION_HISTORY_SCHEMA.json"
LONG_RUN_COMPLETION_SCHEMA_PATH = DOCS_DIR / "LONG_RUN_COMPLETION_REPORT_SCHEMA.json"
RULE_PROPAGATION_SCHEMA_PATH = DOCS_DIR / "RULE_PROPAGATION_REGISTRY_SCHEMA.json"
RULE_PROPAGATION_REGISTRY_PATH = DOCS_DIR / "RULE_PROPAGATION_REGISTRY.json"
PROJECT_INVARIANT_SCHEMA_PATH = DOCS_DIR / "PROJECT_INVARIANT_REGISTRY_SCHEMA.json"
PROJECT_INVARIANT_REGISTRY_PATH = DOCS_DIR / "PROJECT_INVARIANT_REGISTRY.json"
AGENT_ENTRYPOINT_SCHEMA_PATH = DOCS_DIR / "AGENT_ENTRYPOINT_REGISTRY_SCHEMA.json"
AGENT_ENTRYPOINT_REGISTRY_PATH = DOCS_DIR / "AGENT_ENTRYPOINT_REGISTRY.json"
OPERATOR_INTENT_CONTRACT_SCHEMA_PATH = DOCS_DIR / "OPERATOR_INTENT_CONTRACT_SCHEMA.json"
IMPACT_RADIUS_RULES_SCHEMA_PATH = DOCS_DIR / "IMPACT_RADIUS_RULES_SCHEMA.json"
IMPACT_RADIUS_RULES_PATH = DOCS_DIR / "IMPACT_RADIUS_RULES.json"
GERMAN_OUTPUT_QUALITY_SCHEMA_PATH = DOCS_DIR / "GERMAN_OUTPUT_QUALITY_REGISTRY_SCHEMA.json"
GERMAN_OUTPUT_QUALITY_REGISTRY_PATH = DOCS_DIR / "GERMAN_OUTPUT_QUALITY_REGISTRY.json"
AUTONOMY_GOVERNOR_SCHEMA_PATH = DOCS_DIR / "AUTONOMY_GOVERNOR_SCHEMA.json"
AUTONOMY_GOVERNOR_REGISTRY_PATH = DOCS_DIR / "AUTONOMY_GOVERNOR_REGISTRY.json"
FRESH_SESSION_READINESS_SCHEMA_PATH = DOCS_DIR / "FRESH_SESSION_READINESS_SCHEMA.json"
FRESH_DATA_INTAKE_SCHEMA_PATH = DOCS_DIR / "FRESH_DATA_INTAKE_SCHEMA.json"
VIVI_JOB_CARD_QUEUE_SCHEMA_PATH = DOCS_DIR / "VIVI_JOB_CARD_QUEUE_SCHEMA.json"
VIVI_RUNNER_SCHEMA_PATH = DOCS_DIR / "VIVI_RUNNER_SCHEMA.json"
VIVI_SUPERVISOR_AUDIT_SCHEMA_PATH = DOCS_DIR / "VIVI_SUPERVISOR_AUDIT_SCHEMA.json"
COMMIT_CLEANUP_GO_PACKAGE_SCHEMA_PATH = DOCS_DIR / "COMMIT_CLEANUP_GO_PACKAGE_SCHEMA.json"
VIVI_WORKER_QUEUE_SCHEMA_PATH = DOCS_DIR / "VIVI_WORKER_QUEUE_SCHEMA.json"
VIVI_WORKER_SCHEMA_PATH = DOCS_DIR / "VIVI_WORKER_SCHEMA.json"
VIVI_WORKER_SUPERVISOR_AUDIT_SCHEMA_PATH = DOCS_DIR / "VIVI_WORKER_SUPERVISOR_AUDIT_SCHEMA.json"
ENDGAME_ROADMAP_SCHEMA_PATH = DOCS_DIR / "ENDGAME_ROADMAP_SCHEMA.json"
VIVI_CAPABILITY_MATRIX_SCHEMA_PATH = DOCS_DIR / "VIVI_CAPABILITY_MATRIX_SCHEMA.json"
PROJECT_VERTICAL_ROLLOUT_SCHEMA_PATH = DOCS_DIR / "PROJECT_VERTICAL_ROLLOUT_SCHEMA.json"
LAUNCH_READINESS_SCHEMA_PATH = DOCS_DIR / "LAUNCH_READINESS_SCHEMA.json"


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            rows.append(json.loads(line))
    return rows


def load_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def read_text_if_exists(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return ""


def load_openjarvis_capability_lab() -> dict[str, Any]:
    for path in OPENJARVIS_CAPABILITY_LAB_PATHS:
        payload = load_json(path, default=None)
        if isinstance(payload, dict) and payload:
            return {**payload, "path": str(path)}
    return {
        "status": "UNKNOWN",
        "path": "",
        "source_of_truth": False,
        "hardening": {"runtime_action_executed": False},
        "runtime": {"runtime_execution_attempted": False, "runtime_execution_allowed": False},
        "retrieval_benchmark": {"status": "UNKNOWN", "question_count": 0, "pass_count": 0},
        "code_qa_shadow": {"status": "UNKNOWN", "project_count": 0, "pass_count": 0},
    }


def load_openjarvis_capability_arena() -> dict[str, Any]:
    for path in OPENJARVIS_CAPABILITY_ARENA_PATHS:
        payload = load_json(path, default=None)
        if isinstance(payload, dict) and payload:
            return {**payload, "path": str(path)}
    return {
        "status": "UNKNOWN",
        "path": "",
        "source_of_truth": False,
        "runtime": {"runtime_execution_attempted": False, "runtime_action_executed": False},
        "engine_summary": {
            "openjarvis_shadow": {"pass_count": 0, "fail_count": 0, "win_count": 0, "average_score": 0},
            "pig_obsidian_baseline": {"pass_count": 0, "fail_count": 0, "win_count": 0, "average_score": 0},
        },
        "winner_summary": {"openjarvis_shadow": 0, "pig_obsidian_baseline": 0, "tie": 0},
    }


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def tokenize(value: str) -> list[str]:
    return [token for token in re.split(r"[^A-Za-z0-9äöüÄÖÜß._:/#-]+", value.lower()) if token]


def normalize_for_match(value: str) -> str:
    value = value.lower()
    replacements = {
        "ä": "ae",
        "ö": "oe",
        "ü": "ue",
        "ß": "ss",
    }
    for old, new in replacements.items():
        value = value.replace(old, new)
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def safe_slug(value: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9._-]+", "-", value.strip().lower()).strip("-")
    return slug or "query"


def stable_id(*parts: object) -> str:
    payload = "\u241f".join(str(part) for part in parts)
    return hashlib.sha1(payload.encode("utf-8")).hexdigest()[:20]


class GraphStore:
    def __init__(self, nodes: list[dict[str, Any]], relationships: list[dict[str, Any]]) -> None:
        self.nodes = {node["id"]: node for node in nodes}
        self.relationships = {rel["id"]: rel for rel in relationships}
        self.outgoing: dict[str, list[dict[str, Any]]] = defaultdict(list)
        self.incoming: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for rel in relationships:
            self.outgoing[rel["subject"]].append(rel)
            self.incoming[rel["object"]].append(rel)

    @classmethod
    def load(cls) -> "GraphStore":
        return cls(load_jsonl(NODES_PATH), load_jsonl(RELATIONSHIPS_PATH))

    def label(self, node_id: str) -> str:
        return str(self.nodes.get(node_id, {}).get("label", node_id))

    def node_text(self, node: dict[str, Any]) -> str:
        properties = node.get("properties", {})
        return " ".join([node.get("id", ""), node.get("type", ""), node.get("label", ""), json.dumps(properties, ensure_ascii=False)])

    def rel_text(self, rel: dict[str, Any]) -> str:
        return " ".join([
            rel.get("id", ""),
            self.label(rel.get("subject", "")),
            rel.get("predicate", ""),
            self.label(rel.get("object", "")),
            rel.get("status", ""),
            rel.get("source_path", ""),
            rel.get("source_span", ""),
        ])

    def find_nodes(self, query: str, limit: int = 20) -> list[dict[str, Any]]:
        terms = tokenize(query)
        scored: list[tuple[float, dict[str, Any]]] = []
        for node in self.nodes.values():
            score = score_text(self.node_text(node), terms)
            if score > 0:
                scored.append((score, node))
        scored.sort(key=lambda item: (-item[0], item[1]["id"]))
        return [node for _, node in scored[:limit]]

    def exact_nodes(self, query: str) -> list[dict[str, Any]]:
        normalized = query.strip().lower()
        slugged = safe_slug(query)
        matches = []
        for node in self.nodes.values():
            label = str(node.get("label", "")).lower()
            node_id = str(node.get("id", "")).lower()
            if normalized in {label, node_id} or slugged in {safe_slug(label), safe_slug(node_id)}:
                matches.append(node)
        return sorted(matches, key=lambda node: (node["type"], node["label"]))

    def global_search(self, query: str, limit: int = 20) -> dict[str, Any]:
        terms = tokenize(query)
        node_scores: list[tuple[float, dict[str, Any]]] = []
        rel_scores: list[tuple[float, dict[str, Any]]] = []
        for node in self.nodes.values():
            score = score_text(self.node_text(node), terms)
            if score > 0:
                node_scores.append((score, node))
        for rel in self.relationships.values():
            score = score_text(self.rel_text(rel), terms)
            if score > 0:
                rel_scores.append((score, rel))
        node_scores.sort(key=lambda item: (-item[0], item[1]["id"]))
        rel_scores.sort(key=lambda item: (-item[0], item[1]["id"]))
        return {
            "mode": "global",
            "query": query,
            "nodes": [node for _, node in node_scores[:limit]],
            "relationships": [rel for _, rel in rel_scores[:limit]],
        }

    def local_search(self, query: str, depth: int = 1, limit: int = 80) -> dict[str, Any]:
        seeds = self.exact_nodes(query)[:8] or self.find_nodes(query, limit=8)
        visited_nodes: set[str] = {node["id"] for node in seeds}
        visited_rels: dict[str, dict[str, Any]] = {}
        queue: deque[tuple[str, int]] = deque((node["id"], 0) for node in seeds)
        while queue:
            current, current_depth = queue.popleft()
            if current_depth >= depth:
                continue
            for rel in self.outgoing.get(current, []) + self.incoming.get(current, []):
                visited_rels[rel["id"]] = rel
                neighbor = rel["object"] if rel["subject"] == current else rel["subject"]
                if neighbor not in visited_nodes:
                    visited_nodes.add(neighbor)
                    queue.append((neighbor, current_depth + 1))
        ordered_nodes = sorted((self.nodes[node] for node in visited_nodes if node in self.nodes), key=lambda item: (item["type"], item["label"]))[:limit]
        ordered_rels = sorted(visited_rels.values(), key=lambda rel: rel["id"])[:limit]
        return {
            "mode": "local",
            "query": query,
            "depth": depth,
            "seed_nodes": seeds,
            "nodes": ordered_nodes,
            "relationships": ordered_rels,
        }

    def hybrid_search(self, query: str, depth: int = 1, limit: int = 30) -> dict[str, Any]:
        global_result = self.global_search(query, limit=limit)
        local_result = self.local_search(query, depth=depth, limit=limit * 3)
        terms = tokenize(query)
        rels: dict[str, tuple[float, dict[str, Any]]] = {}
        for rel in global_result["relationships"]:
            rels[rel["id"]] = (score_text(self.rel_text(rel), terms) + 3.0, rel)
        for rel in local_result["relationships"]:
            existing = rels.get(rel["id"], (0.0, rel))[0]
            rels[rel["id"]] = (existing + score_text(self.rel_text(rel), terms) + 1.0, rel)
        nodes: dict[str, tuple[float, dict[str, Any]]] = {}
        for node in global_result["nodes"] + local_result["nodes"]:
            existing = nodes.get(node["id"], (0.0, node))[0]
            nodes[node["id"]] = (existing + score_text(self.node_text(node), terms) + 1.0, node)
        ranked_nodes = [item[1] for item in sorted(nodes.values(), key=lambda item: (-item[0], item[1]["id"]))[:limit]]
        ranked_rels = [item[1] for item in sorted(rels.values(), key=lambda item: (-item[0], item[1]["id"]))[:limit]]
        return {
            "mode": "hybrid",
            "query": query,
            "depth": depth,
            "nodes": ranked_nodes,
            "relationships": ranked_rels,
        }

    def explain(self, query: str, limit: int = 24) -> dict[str, Any]:
        node = self.resolve_one_node(query)
        incoming = sorted(self.incoming.get(node["id"], []), key=lambda rel: rel["id"])[:limit]
        outgoing = sorted(self.outgoing.get(node["id"], []), key=lambda rel: rel["id"])[:limit]
        sources = sorted({rel["source_path"] for rel in incoming + outgoing})[:limit]
        return {"node": node, "incoming": incoming, "outgoing": outgoing, "sources": sources}

    def resolve_one_node(self, query: str) -> dict[str, Any]:
        if query in self.nodes:
            return self.nodes[query]
        matches = self.find_nodes(query, limit=1)
        if not matches:
            raise ValueError(f"No node matched query: {query}")
        return matches[0]


def score_text(text: str, terms: list[str]) -> float:
    if not terms:
        return 0.0
    haystack = text.lower()
    score = 0.0
    for term in terms:
        if term in haystack:
            score += 1.0
        if re.search(rf"\b{re.escape(term)}\b", haystack):
            score += 1.5
    return score


def result_to_markdown(store: GraphStore, result: dict[str, Any]) -> str:
    lines = [
        f"# Project Intelligence Graph {result['mode'].title()} Search",
        "",
        f"- Query: `{result.get('query', '')}`",
        f"- Nodes: `{len(result.get('nodes', []))}`",
        f"- Relationships: `{len(result.get('relationships', []))}`",
        "",
        "## Nodes",
        "",
    ]
    for node in result.get("nodes", [])[:20]:
        lines.append(f"- `{node['id']}` {node['label']} ({node['type']})")
    lines.extend(["", "## Relationships", ""])
    for rel in result.get("relationships", [])[:30]:
        lines.append(
            f"- {store.label(rel['subject'])} --`{rel['predicate']}`--> {store.label(rel['object'])} "
            f"[{rel['status']}; {Path(rel['source_path']).name} / {rel['source_span']}]"
        )
    return "\n".join(lines) + "\n"


def explain_to_markdown(store: GraphStore, explanation: dict[str, Any]) -> str:
    node = explanation["node"]
    lines = [
        "# Project Intelligence Graph Explain",
        "",
        f"- Node: `{node['id']}`",
        f"- Label: `{node['label']}`",
        f"- Type: `{node['type']}`",
        "",
        "## Incoming",
        "",
    ]
    for rel in explanation["incoming"]:
        lines.append(f"- {store.label(rel['subject'])} --`{rel['predicate']}`--> {node['label']} [{rel['status']}]")
    lines.extend(["", "## Outgoing", ""])
    for rel in explanation["outgoing"]:
        lines.append(f"- {node['label']} --`{rel['predicate']}`--> {store.label(rel['object'])} [{rel['status']}]")
    lines.extend(["", "## Provenance", ""])
    for source in explanation["sources"]:
        lines.append(f"- `{source}`")
    return "\n".join(lines) + "\n"


def write_context_pack(store: GraphStore, query: str, output: Path) -> None:
    result = store.hybrid_search(query, depth=2, limit=36)
    lines = [
        "---",
        "type: project_intelligence_graph_context_pack",
        f"query: {json.dumps(query, ensure_ascii=False)}",
        f"generated: {dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()}",
        "---",
        "",
        f"# Project Intelligence Graph Context Pack - {query}",
        "",
        "## Top Nodes",
        "",
    ]
    for node in result["nodes"][:18]:
        lines.append(f"- `{node['id']}` {node['label']} ({node['type']})")
    lines.extend(["", "## Relationship Evidence", ""])
    for rel in result["relationships"][:28]:
        lines.append(
            f"- {store.label(rel['subject'])} --`{rel['predicate']}`--> {store.label(rel['object'])}; "
            f"status `{rel['status']}`; source `{rel['source_path']}` / `{rel['source_span']}`"
        )
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(lines) + "\n", encoding="utf-8")


def render_html_view(title: str, subtitle: str, nodes: list[dict[str, Any]], rels: list[dict[str, Any]], store: GraphStore) -> str:
    payload = json.dumps({"nodes": nodes, "relationships": rels}, ensure_ascii=False).replace("<", "\\u003c")
    rows = []
    for rel in rels[:350]:
        rows.append(
            "<tr>"
            f"<td>{html.escape(store.label(rel['subject']))}</td>"
            f"<td><code>{html.escape(rel['predicate'])}</code></td>"
            f"<td>{html.escape(store.label(rel['object']))}</td>"
            f"<td>{html.escape(rel['status'])}</td>"
            f"<td>{html.escape(Path(rel['source_path']).name)}<br><small>{html.escape(rel['source_span'])}</small></td>"
            "</tr>"
        )
    node_cards = []
    for node in nodes[:160]:
        node_cards.append(f"<button class=\"node\" type=\"button\"><strong>{html.escape(node['label'])}</strong><span>{html.escape(node['type'])}</span></button>")
    return f"""<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(title)}</title>
  <style>
    :root {{ --ink:#1d252b; --muted:#60707a; --line:#d7e0e5; --panel:#f6f8f8; --accent:#0f766e; }}
    * {{ box-sizing:border-box; }}
    body {{ margin:0; color:var(--ink); font-family:ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; background:white; }}
    header {{ padding:28px clamp(18px,4vw,48px) 18px; border-bottom:1px solid var(--line); }}
    h1 {{ margin:0 0 8px; font-size:clamp(1.35rem,2.4vw,2.25rem); letter-spacing:0; }}
    .meta {{ color:var(--muted); display:flex; flex-wrap:wrap; gap:10px; }}
    .pill {{ border:1px solid var(--line); border-radius:999px; padding:6px 10px; background:#fff; }}
    main {{ display:grid; grid-template-columns:minmax(250px,340px) minmax(0,1fr); min-height:calc(100vh - 112px); }}
    aside {{ background:var(--panel); border-right:1px solid var(--line); padding:16px; overflow:auto; }}
    section {{ padding:16px clamp(14px,3vw,34px); overflow:auto; }}
    .node {{ width:100%; text-align:left; display:block; border:1px solid var(--line); border-radius:8px; padding:10px; background:white; margin-bottom:8px; }}
    .node strong {{ display:block; overflow-wrap:anywhere; }}
    .node span, small {{ color:var(--muted); }}
    input {{ width:min(520px,100%); padding:10px 12px; border:1px solid var(--line); border-radius:6px; font:inherit; margin-bottom:12px; }}
    table {{ width:100%; border-collapse:collapse; table-layout:fixed; border:1px solid var(--line); }}
    th, td {{ border-bottom:1px solid var(--line); padding:10px; text-align:left; vertical-align:top; overflow-wrap:anywhere; font-size:.9rem; }}
    th {{ background:#eef3f4; text-transform:uppercase; font-size:.78rem; }}
    code {{ color:var(--accent); }}
    @media (max-width:860px) {{ main {{ grid-template-columns:1fr; }} aside {{ border-right:0; border-bottom:1px solid var(--line); max-height:260px; }} }}
  </style>
</head>
<body>
  <header>
    <h1>{html.escape(title)}</h1>
    <div class="meta"><span class="pill">{html.escape(subtitle)}</span><span class="pill">{len(nodes)} Nodes</span><span class="pill">{len(rels)} Relationships</span></div>
  </header>
  <main>
    <aside>{''.join(node_cards)}</aside>
    <section>
      <input id="filter" aria-label="Filter relationships" placeholder="Filter">
      <table>
        <thead><tr><th>Subject</th><th>Predicate</th><th>Object</th><th>Status</th><th>Provenance</th></tr></thead>
        <tbody id="rows">{''.join(rows)}</tbody>
      </table>
    </section>
  </main>
  <script id="graph-data" type="application/json">{payload}</script>
  <script>
    const rows = Array.from(document.querySelectorAll('#rows tr'));
    document.getElementById('filter').addEventListener('input', (event) => {{
      const term = event.target.value.toLowerCase();
      rows.forEach((row) => {{ row.style.display = row.textContent.toLowerCase().includes(term) ? '' : 'none'; }});
    }});
  </script>
</body>
</html>
"""


def nodes_for_relationships(store: GraphStore, rels: list[dict[str, Any]]) -> list[dict[str, Any]]:
    ids = {rel["subject"] for rel in rels} | {rel["object"] for rel in rels}
    return sorted([store.nodes[node_id] for node_id in ids if node_id in store.nodes], key=lambda node: (node["type"], node["label"]))


def render_views(store: GraphStore) -> dict[str, str]:
    VIEWS_DIR.mkdir(parents=True, exist_ok=True)
    views: dict[str, tuple[str, str, list[dict[str, Any]], list[dict[str, Any]]]] = {}
    rels = list(store.relationships.values())
    views["project-lane-claim-evidence.html"] = (
        "Project / Lane / Claim / Evidence",
        "Claimable delivery map",
        [],
        [
            rel for rel in rels
            if rel["predicate"] in {"contains_lane", "contains_claim", "describes_claim", "has_evidence_pack", "validated_by", "blocked_by"}
            or any(token in store.rel_text(rel).lower() for token in ["claim", "evidence", "lane", "verifier"])
        ],
    )
    views["automation-job-cards.html"] = (
        "Automation Job Cards",
        "Automation status, scope and categories",
        [node for node in store.nodes.values() if node["type"] == "Automation"],
        [rel for rel in rels if rel["subject"].startswith("automation:") or rel["object"].startswith("automation:")],
    )
    views["promotion-gate-map.html"] = (
        "Promotion Gate Map",
        "Public, publish, promotion, quality and operator gates",
        [],
        [rel for rel in rels if any(token in store.rel_text(rel).lower() for token in ["public", "publish", "promotion", "quality", "operator", "gate", "ready"])],
    )
    views["report-supersession-timeline.html"] = (
        "Report Supersession Timeline",
        "Superseded and report status relationships",
        [node for node in store.nodes.values() if node["type"] == "Report"],
        [rel for rel in rels if rel["status"] == "superseded" or "report" in store.rel_text(rel).lower()],
    )
    views["repo-verifier-coverage.html"] = (
        "Repo / Verifier Coverage",
        "Repositories, artifacts and validation relationships",
        [node for node in store.nodes.values() if node["type"] in {"Repository", "Verifier"}],
        [rel for rel in rels if rel["predicate"] in {"contains_artifact", "validated_by"} or rel["subject"].startswith("repo:") or rel["object"].startswith("verifier:")],
    )
    written: dict[str, str] = {}
    for filename, (title, subtitle, explicit_nodes, view_rels) in views.items():
        view_rels = sorted(unique_relationships(view_rels), key=lambda rel: rel["id"])
        view_nodes = sorted(unique_nodes(explicit_nodes + nodes_for_relationships(store, view_rels)), key=lambda node: (node["type"], node["label"]))
        target = VIEWS_DIR / filename
        target.write_text(render_html_view(title, subtitle, view_nodes, view_rels, store), encoding="utf-8")
        written[filename] = str(target)
    risk_payload = load_json(AUTOMATION_RISK_PATH, default={"items": []})
    risk_target = VIEWS_DIR / "automation-risk-registry.html"
    risk_target.write_text(
        render_record_view(
            "Automation Risk Registry",
            "Active, paused and high-risk automation control surface",
            risk_payload.get("items", []),
            ["name", "status", "kind", "risk_class", "mutating_capability", "operator_gate_required", "recommended_control"],
        ),
        encoding="utf-8",
    )
    written["automation-risk-registry.html"] = str(risk_target)
    decision_payload = apply_decision_state(load_json(OPERATOR_DECISION_PATH, default={"items": []}))
    decision_target = VIEWS_DIR / "operator-decision-inbox.html"
    decision_target.write_text(
        render_record_view(
            "Operator Decision Inbox",
            "Prioritized decisions and safe defaults",
            decision_payload.get("items", []),
            ["priority", "lane", "operator_state", "status", "recommended_default", "operator_action", "summary", "consequence_if_ignored"],
        ),
        encoding="utf-8",
    )
    written["operator-decision-inbox.html"] = str(decision_target)
    contract_quality_payload = load_json(CONTRACT_QUALITY_PATH, default={"items": []})
    contract_quality_target = VIEWS_DIR / "planning-quality-control.html"
    contract_quality_target.write_text(
        render_record_view(
            "Planning Quality Control",
            "Build contracts, archetypes, job cards, workflow runs and gate readiness",
            contract_quality_payload.get("items", []),
            ["artifact_kind", "status", "severity", "path", "summary", "missing_fields", "recommended_action"],
        ),
        encoding="utf-8",
    )
    written["planning-quality-control.html"] = str(contract_quality_target)
    index = render_view_index(written)
    (VIEWS_DIR / "index.html").write_text(index, encoding="utf-8")
    (VIEWS_DIR / "views_index.json").write_text(json.dumps(written, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return written


def render_record_view(title: str, subtitle: str, rows: list[dict[str, Any]], columns: list[str]) -> str:
    payload = json.dumps({"rows": rows}, ensure_ascii=False).replace("<", "\\u003c")
    table_rows = []
    for row in rows[:300]:
        table_rows.append(
            "<tr>"
            + "".join(f"<td>{html.escape(record_value(row.get(column)))}</td>" for column in columns)
            + "</tr>"
        )
    headers = "".join(f"<th>{html.escape(column.replace('_', ' ').title())}</th>" for column in columns)
    return f"""<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(title)}</title>
  <style>
    body {{ margin:0; color:#1d252b; font-family:ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; background:white; }}
    header {{ padding:28px clamp(18px,4vw,48px) 18px; border-bottom:1px solid #d7e0e5; }}
    h1 {{ margin:0 0 8px; font-size:clamp(1.35rem,2.4vw,2.25rem); letter-spacing:0; }}
    .meta {{ color:#60707a; display:flex; flex-wrap:wrap; gap:10px; }}
    .pill {{ border:1px solid #d7e0e5; border-radius:999px; padding:6px 10px; background:#fff; }}
    main {{ padding:18px clamp(14px,3vw,34px); }}
    input {{ width:min(520px,100%); padding:10px 12px; border:1px solid #d7e0e5; border-radius:6px; font:inherit; margin-bottom:12px; }}
    table {{ width:100%; border-collapse:collapse; table-layout:fixed; border:1px solid #d7e0e5; }}
    th, td {{ border-bottom:1px solid #d7e0e5; padding:10px; text-align:left; vertical-align:top; overflow-wrap:anywhere; font-size:.9rem; }}
    th {{ background:#eef3f4; text-transform:uppercase; font-size:.78rem; }}
  </style>
</head>
<body>
  <header>
    <h1>{html.escape(title)}</h1>
    <div class="meta"><span class="pill">{html.escape(subtitle)}</span><span class="pill">{len(rows)} Rows</span></div>
  </header>
  <main>
    <input id="filter" aria-label="Filter rows" placeholder="Filter">
    <table>
      <thead><tr>{headers}</tr></thead>
      <tbody id="rows">{''.join(table_rows)}</tbody>
    </table>
  </main>
  <script id="record-data" type="application/json">{payload}</script>
  <script>
    const rows = Array.from(document.querySelectorAll('#rows tr'));
    document.getElementById('filter').addEventListener('input', (event) => {{
      const term = event.target.value.toLowerCase();
      rows.forEach((row) => {{ row.style.display = row.textContent.toLowerCase().includes(term) ? '' : 'none'; }});
    }});
  </script>
</body>
</html>
"""


def record_value(value: Any) -> str:
    if isinstance(value, list):
        return ", ".join(str(item) for item in value)
    if isinstance(value, dict):
        return json.dumps(value, ensure_ascii=False)
    if value is None:
        return ""
    return str(value)


def json_records_to_markdown(title: str, rows: list[dict[str, Any]], limit: int = 40) -> str:
    lines = [f"# {title}", "", f"- Rows: `{len(rows)}`", ""]
    for row in rows[:limit]:
        label = row.get("name") or row.get("item_id") or row.get("source_class") or row.get("policy_id") or "item"
        lines.append(f"## {label}")
        for key, value in row.items():
            lines.append(f"- `{key}`: {record_value(value)}")
        lines.append("")
    return "\n".join(lines)


def path_mtime_iso(path: Path) -> str:
    return dt.datetime.fromtimestamp(path.stat().st_mtime, tz=dt.timezone.utc).replace(microsecond=0).isoformat()


def parse_iso_datetime(value: str) -> dt.datetime | None:
    if not value:
        return None
    try:
        return dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def age_hours_from_iso(value: str, now: dt.datetime) -> float | None:
    parsed = parse_iso_datetime(value)
    if not parsed:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=dt.timezone.utc)
    return round(max((now - parsed).total_seconds(), 0) / 3600, 2)


def parse_markdown_bullet_int(text: str, label: str) -> int | None:
    match = re.search(rf"^\s*-\s*{re.escape(label)}:\s*([0-9]+)\s*$", text, re.MULTILINE | re.IGNORECASE)
    return int(match.group(1)) if match else None


def room16_library_summary(text: str) -> dict[str, int]:
    labels = {
        "total_reports": "Total Reports",
        "companies": "Companies",
        "public_ready": "Public Ready",
        "member_ready": "Member Ready",
        "manual_review": "Manual Review",
        "needs_human_review": "Needs Human Review",
        "rejected": "Rejected",
        "effective_public": "Effective Public",
        "hidden_by_gate": "Hidden By Gate",
    }
    return {key: value for key, label in labels.items() if (value := parse_markdown_bullet_int(text, label)) is not None}


def fresh_data_intake_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Fresh Data Intake",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Fresh items: `{payload.get('fresh_item_count', 0)}`",
        f"- Action items: `{payload.get('action_item_count', 0)}`",
        f"- Operator gates: `{payload.get('operator_gate_count', 0)}`",
        f"- Needs review: `{payload.get('needs_review_count', 0)}`",
        f"- Needs verifier: `{payload.get('needs_verifier_count', 0)}`",
        "",
        "## Items",
        "",
    ]
    for item in payload.get("items", [])[:80]:
        lines.append(f"### {item.get('item_id', 'item')}")
        for key in [
            "project_id",
            "source_id",
            "artifact_kind",
            "status",
            "signal_status",
            "classification",
            "priority",
            "modified_at",
            "age_hours",
            "next_safe_step",
            "path",
        ]:
            lines.append(f"- `{key}`: {record_value(item.get(key, ''))}")
        if item.get("summary"):
            lines.append(f"- `summary`: {record_value(item.get('summary'))}")
        lines.append("")
    if payload.get("source_gaps"):
        lines.extend(["## Source Gaps", ""])
        for gap in payload["source_gaps"][:40]:
            lines.append(f"- `{gap.get('project_id')}` `{gap.get('source_id')}`: {gap.get('path')} ({gap.get('status')})")
    return "\n".join(lines) + "\n"


def vivi_job_card_queue_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Vivi Job Card Queue",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Job Cards: `{payload.get('job_card_count', 0)}`",
        f"- Ready: `{payload.get('ready_count', 0)}`",
        f"- Waiting for Operator: `{payload.get('waiting_for_operator_count', 0)}`",
        f"- Completed Verified: `{payload.get('completed_verified_count', 0)}`",
        f"- Open Action Items: `{payload.get('open_action_item_count', payload.get('ready_count', 0))}`",
        "",
        "## Job Cards",
        "",
    ]
    for card in payload.get("job_cards", [])[:80]:
        lines.append(f"### {card.get('job_card_id', 'job-card')}")
        for key in [
            "status",
            "auftrag",
            "zielbild",
            "stop_regel",
            "naechster_sicherer_schritt",
            "source_item_id",
            "completed_by_runner",
            "supervisor_truth_status",
        ]:
            lines.append(f"- `{key}`: {record_value(card.get(key, ''))}")
        lines.append("")
    return "\n".join(lines) + "\n"


def vivi_runner_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Vivi Runner MVP",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Run ID: `{payload.get('run_id', '')}`",
        f"- Job Card: `{payload.get('job_card_id', '')}`",
        f"- Mode: `{payload.get('mode', '')}`",
        f"- Runtime action executed: `{payload.get('runtime_action_executed', False)}`",
        f"- Next safe step: {payload.get('next_safe_step', '')}",
        "",
        "## Verifiers",
        "",
    ]
    for item in payload.get("verifiers", []):
        lines.append(f"- `{item.get('status')}` {item.get('command')}")
    if payload.get("failures"):
        lines.extend(["", "## Failures", ""])
        for item in payload["failures"]:
            lines.append(f"- `{item.get('type', 'failure')}` {item.get('detail', '')}")
    return "\n".join(lines) + "\n"


def vivi_supervisor_audit_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Vivi Supervisor Audit",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Truth status: `{payload.get('truth_status', 'UNKNOWN')}`",
        f"- Runner status: `{payload.get('runner_status', 'UNKNOWN')}`",
        f"- Job Card: `{payload.get('job_card_id', '')}`",
        f"- Run ID: `{payload.get('run_id', '')}`",
        f"- Runtime action executed: `{payload.get('runtime_action_executed', False)}`",
        f"- Next safe step: {payload.get('next_safe_step', '')}",
        "",
        "## Verifier Summary",
        "",
    ]
    for key, value in payload.get("verifier_summary", {}).items():
        lines.append(f"- `{key}`: `{value}`")
    if payload.get("findings"):
        lines.extend(["", "## Findings", ""])
        for item in payload["findings"]:
            lines.append(f"- `{item.get('severity', 'INFO')}` `{item.get('code', 'finding')}`: {item.get('message', '')}")
    if payload.get("operator_gates"):
        lines.extend(["", "## Operator Gates", ""])
        for gate in payload["operator_gates"]:
            lines.append(f"- {gate}")
    return "\n".join(lines) + "\n"


def operator_brief_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Project Intelligence Graph Operator Brief",
        "",
        f"- Generated: `{payload.get('generated_at', '')}`",
        f"- Overall: `{payload.get('overall_status', 'UNKNOWN')}`",
        f"- Build: `{payload.get('build_status', 'UNKNOWN')}`",
        f"- Decisions: `{payload.get('decision_status', 'UNKNOWN')}`",
        "",
        "## Do This Now",
        "",
    ]
    for item in payload.get("do_this_now", []):
        lines.append(f"- `{item.get('priority', '-')}` {item.get('text', '')}")
    lines.extend(["", "## Do Not", ""])
    for item in payload.get("do_not", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Safe Commands", ""])
    for command in payload.get("safe_commands", []):
        lines.append(f"- `{command}`")
    lines.extend(["", "## Status Lines", ""])
    for key, value in payload.get("status_lines", {}).items():
        lines.append(f"- `{key}`: `{value}`")
    return "\n".join(lines) + "\n"


def long_run_completion_audit_to_markdown(payload: dict[str, Any]) -> str:
    rows = payload.get("reports", []) if isinstance(payload, dict) else []
    lines = [
        "# Long Run Completion Audit",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN') if isinstance(payload, dict) else 'UNKNOWN'}`",
        f"- Reports checked: `{payload.get('reports_checked', 0) if isinstance(payload, dict) else 0}`",
        "",
    ]
    for row in rows:
        lines.append(f"## {row.get('report_id', 'report')}")
        for key in ["status", "completion_state", "run_scope", "next_safe_step", "path"]:
            lines.append(f"- `{key}`: {record_value(row.get(key, ''))}")
        if row.get("issues"):
            lines.append(f"- `issues`: {record_value(row.get('issues'))}")
        lines.append("")
    return "\n".join(lines) + "\n"


def build_operator_brief() -> dict[str, Any]:
    summary = load_json(OUTPUT_DIR / "summary.json", default={})
    full_check = load_json(OUTPUT_DIR / "full_check_report.json", default={})
    decisions = apply_decision_state(load_json(OPERATOR_DECISION_PATH, default={"items": []}))
    risk = load_json(AUTOMATION_RISK_PATH, default={"items": []})
    policy = load_json(POLICY_GATE_PATH, default={"items": []})
    coverage = load_json(COVERAGE_MANIFEST_PATH, default={"sources": []})
    contract_quality = load_json(CONTRACT_QUALITY_PATH, default={"items": []})
    long_run_audit = load_json(LONG_RUN_COMPLETION_AUDIT_PATH, default={})
    vault_umlaut = load_json(VAULT_UMLAUT_HYGIENE_PATH, default={})
    skill_policy_audit = load_json(SKILL_POLICY_REGRESSION_AUDIT_PATH, default={})
    rule_propagation = load_json(RULE_PROPAGATION_AUDIT_PATH, default={})
    project_invariants = load_json(PROJECT_INVARIANT_AUDIT_PATH, default={})
    agent_entrypoints = load_json(AGENT_ENTRYPOINT_AUDIT_PATH, default={})
    operator_intent = load_json(OPERATOR_INTENT_CONTRACT_AUDIT_PATH, default={})
    impact_radius = load_json(IMPACT_RADIUS_ASSESSMENT_PATH, default={})
    autonomy_governor = load_json(AUTONOMY_GOVERNOR_AUDIT_PATH, default={})
    vivi_handoff = load_json(VIVI_VEGA_HANDOFF_INBOX_PATH, default={})
    fresh_session_readiness = load_json(FRESH_SESSION_READINESS_AUDIT_PATH, default={})
    fresh_data = load_json(FRESH_DATA_INTAKE_PATH, default={})
    vivi_job_cards = apply_vivi_job_card_completion_state(load_json(VIVI_JOB_CARD_QUEUE_PATH, default={}))
    vivi_runner = load_json(VIVI_RUNNER_LAST_RUN_PATH, default={})
    vivi_supervisor = load_json(VIVI_SUPERVISOR_AUDIT_PATH, default={})
    vivi_worker_queue = load_json(VIVI_WORKER_QUEUE_PATH, default={})
    vivi_worker = load_json(VIVI_WORKER_LAST_RUN_PATH, default={})
    vivi_worker_supervisor = load_json(VIVI_WORKER_SUPERVISOR_AUDIT_PATH, default={})
    autonomy_dirt = load_json(AUTONOMY_DIRT_BACKLOG_SCAN_PATH, default={})
    commit_cleanup_package = load_json(COMMIT_CLEANUP_GO_PACKAGE_PATH, default={})
    german_output = load_json(GERMAN_OUTPUT_QUALITY_AUDIT_PATH, default={})
    endgame = load_json(ENDGAME_ROADMAP_PATH, default={})
    autonomy_soak = load_json(AUTONOMY_SOAK_AUDIT_PATH, default={})
    vivi_capability_matrix = load_json(VIVI_CAPABILITY_MATRIX_PATH, default={})
    project_verticals = load_json(PROJECT_VERTICAL_ROLLOUT_PATH, default={})
    launch_readiness = load_json(LAUNCH_READINESS_PATH, default={})
    launch_readiness = load_json(LAUNCH_READINESS_PATH, default={})
    project_verticals = load_json(PROJECT_VERTICAL_ROLLOUT_PATH, default={})
    vivi_capability_matrix = load_json(VIVI_CAPABILITY_MATRIX_PATH, default={})

    open_items = [item for item in decisions.get("items", []) if item.get("operator_state", "open") not in {"accepted", "closed"}]
    p0_items = [item for item in open_items if item.get("priority") == "P0"]
    active_high_risk = [item for item in risk.get("items", []) if item.get("status") == "ACTIVE" and item.get("risk_class") in {"R4", "R5"}]
    coverage_gaps = [item for item in coverage.get("sources", []) if item.get("status") in {"not_implemented", "missing", "partial"}]

    do_this_now = []
    for item in p0_items[:3]:
        do_this_now.append({
            "priority": item.get("priority", "P0"),
            "text": f"Review decision `{item.get('item_id')}`: {item.get('summary')}",
            "command": f"python3 scripts/project_intelligence_graph/pig.py decisions --set {item.get('item_id')} --state accepted --note \"operator reviewed\"",
        })
    if not do_this_now:
        do_this_now.append({"priority": "P1", "text": "Run `pig.py full-check` before changing PIG or automation control files."})
    if coverage_gaps:
        do_this_now.append({"priority": "P1", "text": f"Keep {len(coverage_gaps)} coverage gaps visible; do not call coverage complete."})
    if contract_quality.get("status") in {"FAIL", "WARN"}:
        do_this_now.append({"priority": "P1", "text": f"Review Planning Quality Gate: status={contract_quality.get('status')} fail_count={contract_quality.get('fail_count', 0)} warn_count={contract_quality.get('warn_count', 0)}."})
    if long_run_audit.get("status", "UNKNOWN") != "PASS":
        do_this_now.append({"priority": "P1", "text": f"Review Long Run Completion Audit before claiming unattended work is finished: status={long_run_audit.get('status', 'UNKNOWN')} reports={long_run_audit.get('reports_checked', 0)}."})
    if vault_umlaut.get("status") == "WARN":
        do_this_now.append({"priority": "P2", "text": f"Review Vault Umlaut Hygiene: {vault_umlaut.get('finding_count', 0)} likely ae/oe/ue legacy spellings found. Do not global replace."})
    if skill_policy_audit.get("status") == "WARN":
        missing = [item for item in skill_policy_audit.get("items", []) if item.get("status") == "WARN"]
        do_this_now.append({"priority": "P1", "text": f"Review Skill/Policy Regression Guard Audit: {len(missing)} entry points need analysis before accepting improvement-loop changes."})
    if rule_propagation.get("status") == "WARN":
        missing = [item for item in rule_propagation.get("items", []) if item.get("status") == "WARN"]
        do_this_now.append({"priority": "P1", "text": f"Review Rule Propagation Audit: {len(missing)} rule targets are not fully wired."})
    if rule_propagation.get("status") == "FAIL":
        do_this_now.append({"priority": "P0", "text": "Repair Rule Propagation Registry before accepting systemwide rule changes."})
    if german_output.get("fail_count", 0):
        do_this_now.append({"priority": "P1", "text": f"Review German Output Quality Gate: status={german_output.get('status')} findings={german_output.get('finding_count', 0)} fail={german_output.get('fail_count', 0)} warn={german_output.get('warn_count', 0)}."})
    dirt_decision_queue = autonomy_dirt.get("handoff_decision_queue", {}) if isinstance(autonomy_dirt.get("handoff_decision_queue", {}), dict) else {}
    dirt_safe_queue_count = int(dirt_decision_queue.get("safe_queue_count") or 0)
    dirt_stale_review_count = int(dirt_decision_queue.get("stale_review_count") or 0)
    dirt_operator_gate_queue_count = int(dirt_decision_queue.get("operator_gate_queue_count") or 0)
    dirt_reviewed_queue_count = int(dirt_decision_queue.get("reviewed_queue_count") or 0)
    if autonomy_dirt.get("dirty_project_count", 0) and (dirt_safe_queue_count or dirt_stale_review_count or not dirt_decision_queue):
        dirty_projects = [
            item.get("project_id", "unknown")
            for item in autonomy_dirt.get("projects", [])
            if item.get("git_status") == "dirty"
        ]
        do_this_now.append({
            "priority": "P1",
            "text": (
                f"Review Autonomy Dirt Ownership: {autonomy_dirt.get('dirty_project_count', 0)} dirty projects "
                f"({', '.join(dirty_projects)}), {autonomy_dirt.get('handoff_card_count', 0)} handoff cards. "
                "Use ownership_counts/handoff_cards before cleanup, commit or push."
            ),
        })
    elif autonomy_dirt.get("dirty_project_count", 0):
        do_this_now.append({
            "priority": "P2",
            "text": (
                f"Autonomy Dirt is locally reviewed: {dirt_reviewed_queue_count} reviewed, "
                f"{dirt_safe_queue_count} safe review cards, {dirt_operator_gate_queue_count} operator-gated cards. "
                "Do not cleanup, commit, push or delete without explicit Operator-Go."
            ),
        })
    if commit_cleanup_package.get("status") == "operator_go_required":
        do_this_now.append({
            "priority": "P1",
            "text": (
                f"Commit/Cleanup Operator-Go package is ready: "
                f"{commit_cleanup_package.get('summary', {}).get('decision_card_count', 0)} decision cards, "
                f"{commit_cleanup_package.get('summary', {}).get('dirty_project_count', 0)} dirty projects. "
                "It executes no commit, cleanup, push or delete by itself."
            ),
        })
    elif commit_cleanup_package.get("status") == "needs_local_review":
        do_this_now.append({
            "priority": "P1",
            "text": "Commit/Cleanup package still needs local review evidence before it can be an Operator-Go bundle.",
        })
    if vivi_handoff.get("needs_vega_review_count", 0) or vivi_handoff.get("needs_verifier_count", 0):
        do_this_now.append({
            "priority": "P1",
            "text": (
                f"Process Vivi -> Vega Handoff Inbox: {vivi_handoff.get('needs_vega_review_count', 0)} needs Vega review, "
                f"{vivi_handoff.get('needs_verifier_count', 0)} needs verifier. Use action_items before starting unrelated work."
            ),
        })
    if vivi_handoff.get("operator_gate_count", 0):
        do_this_now.append({
            "priority": "P0",
            "text": f"Vivi -> Vega Handoff Inbox contains {vivi_handoff.get('operator_gate_count', 0)} operator-gated items; do not execute them without explicit Operator-Go.",
        })
    if autonomy_governor.get("status") == "FAIL":
        do_this_now.append({"priority": "P0", "text": "Repair Autonomy Governor before relying on unattended Vega/Vivi runs."})
    elif autonomy_governor.get("safe_work_remaining"):
        next_steps = autonomy_governor.get("next_safe_steps", [])
        first = next_steps[0] if next_steps else {}
        do_this_now.append({"priority": "P1", "text": f"Autonomy Governor sees safe local work: `{first.get('workstream_id', 'unknown')}` -> {first.get('next_safe_step', 'review autonomy-governor')}."})
    if endgame.get("safe_work_remaining"):
        first_endgame = (endgame.get("safe_next_blocks") or [{}])[0]
        do_this_now.append({
            "priority": first_endgame.get("priority", "P1"),
            "text": f"Endgame Roadmap has safe large-block work: `{first_endgame.get('block_id', 'unknown')}` -> {first_endgame.get('next_safe_step', '')}",
        })
    if fresh_session_readiness.get("status") == "FAIL":
        do_this_now.append({"priority": "P0", "text": "Repair Fresh Session Readiness before claiming future agents can resume from durable context."})
    elif fresh_session_readiness.get("status") == "WARN":
        do_this_now.append({"priority": "P1", "text": f"Review Fresh Session Readiness: {fresh_session_readiness.get('warning_count', 0)} durable entrypoints need stronger context."})
    unresolved_fresh_action_count = (
        vivi_job_cards.get("open_action_item_count", fresh_data.get("action_item_count", 0))
        if vivi_job_cards.get("source") == "fresh_data_intake"
        else fresh_data.get("action_item_count", 0)
    )
    if fresh_data.get("status") == "FAIL":
        do_this_now.append({"priority": "P0", "text": f"Repair Fresh Data Intake before deriving work from runtime data: {fresh_data.get('action_item_count', 0)} action items."})
    elif unresolved_fresh_action_count:
        do_this_now.append({
            "priority": "P1" if fresh_data.get("operator_gate_count", 0) else "P2",
            "text": (
                f"Review Fresh Data Intake: {fresh_data.get('fresh_item_count', 0)} fresh items, "
                f"{fresh_data.get('needs_review_count', 0)} needs review, "
                f"{fresh_data.get('operator_gate_count', 0)} operator gates. "
                "Use it as evidence; do not trigger Room16 rerun/push/publish."
            ),
        })
    if vivi_job_cards.get("status") == "FAIL":
        do_this_now.append({"priority": "P0", "text": "Repair Vivi Job Card Queue before handing Fresh Data tasks to Vivi."})
    elif vivi_job_cards.get("ready_count", 0):
        do_this_now.append({
            "priority": "P2",
            "text": f"Vivi Job Card Queue has {vivi_job_cards.get('ready_count', 0)} ready local job card(s); Vega/PIG must verify outputs before completion claims.",
        })
    if vivi_runner.get("status") in {"waiting_for_evidence", "failed_safe"}:
        do_this_now.append({"priority": "P1", "text": f"Review Vivi Runner MVP result: status={vivi_runner.get('status')} next={vivi_runner.get('next_safe_step', '')}"})
    if vivi_supervisor.get("status") == "FAIL":
        do_this_now.append({"priority": "P0", "text": "Repair Vivi Supervisor Audit before accepting Runner outputs."})
    elif vivi_supervisor.get("status") == "WARN":
        do_this_now.append({"priority": "P1", "text": f"Review Vivi Supervisor Audit: {vivi_supervisor.get('truth_status', 'UNKNOWN')} -> {vivi_supervisor.get('next_safe_step', '')}"})
    if vivi_worker_queue.get("ready_count", 0):
        do_this_now.append({
            "priority": "P2",
            "text": f"Vivi Worker Queue has {vivi_worker_queue.get('ready_count', 0)} ready local artifact worker card(s); safe only for generated PIG evidence, not runtime work.",
        })
    if vivi_worker.get("runtime_action_executed") is True or vivi_worker_supervisor.get("status") == "FAIL":
        do_this_now.append({"priority": "P0", "text": "Stop and inspect Vivi Worker: runtime action or supervisor failure detected."})

    long_run_needs_review = long_run_audit.get("status", "UNKNOWN") != "PASS"
    policy_needs_review = skill_policy_audit.get("status", "UNKNOWN") == "WARN"
    propagation_needs_review = rule_propagation.get("status", "UNKNOWN") in {"WARN", "FAIL"}
    german_output_needs_review = german_output.get("fail_count", 0) > 0
    autonomy_needs_action = autonomy_governor.get("status") == "FAIL"
    dirt_needs_review = bool(dirt_safe_queue_count or dirt_stale_review_count)
    vivi_handoff_needs_review = vivi_handoff.get("needs_vega_review_count", 0) > 0 or vivi_handoff.get("needs_verifier_count", 0) > 0
    vivi_handoff_needs_gate = vivi_handoff.get("operator_gate_count", 0) > 0
    fresh_session_needs_action = fresh_session_readiness.get("status") == "FAIL"
    fresh_data_needs_action = fresh_data.get("status") == "FAIL"
    fresh_data_needs_review = unresolved_fresh_action_count > 0
    vivi_job_cards_needs_action = vivi_job_cards.get("status") == "FAIL"
    vivi_job_cards_ready = vivi_job_cards.get("ready_count", 0) > 0
    vivi_runner_needs_review = vivi_runner.get("status") in {"waiting_for_evidence", "failed_safe"}
    vivi_supervisor_needs_action = vivi_supervisor.get("status") == "FAIL"
    vivi_supervisor_needs_review = vivi_supervisor.get("status") == "WARN"
    vivi_worker_needs_action = vivi_worker.get("runtime_action_executed") is True or vivi_worker_supervisor.get("status") == "FAIL"
    vivi_worker_ready = vivi_worker_queue.get("ready_count", 0) > 0
    dirt_ownership_summary = {
        item.get("project_id", "unknown"): item.get("ownership_counts", {})
        for item in autonomy_dirt.get("projects", [])
        if item.get("ownership_counts")
    }

    payload = {
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "overall_status": "ACTION_REQUIRED" if p0_items or rule_propagation.get("status") == "FAIL" or german_output.get("status") == "FAIL" or autonomy_needs_action or fresh_session_needs_action or fresh_data_needs_action or vivi_job_cards_needs_action or vivi_supervisor_needs_action or vivi_worker_needs_action or vivi_handoff_needs_gate else ("REVIEW" if open_items or long_run_needs_review or policy_needs_review or propagation_needs_review or german_output_needs_review or dirt_needs_review or commit_cleanup_package.get("status") in {"operator_go_required", "needs_local_review"} or vivi_handoff_needs_review or fresh_data_needs_review or vivi_job_cards_ready or vivi_worker_ready or vivi_runner_needs_review or vivi_supervisor_needs_review else "CLEAR"),
        "build_status": full_check.get("status", "UNKNOWN"),
        "decision_status": decisions.get("status", "UNKNOWN"),
        "do_this_now": do_this_now,
        "do_not": [
            "Do not manually edit generated reports under outputs/project_intelligence_graph except state files.",
            "Do not turn WARN into PASS by wording; only scanner or state changes may change status.",
            "Do not run or expand R4/R5 automation without visible operator evidence.",
            "Do not claim repo/CI/runtime coverage until a scanner records that source class as scanned.",
            "Do not claim long-run completion without a passing Long Run Completion Audit.",
        ],
        "safe_commands": [
            "python3 scripts/project_intelligence_graph/pig.py full-check",
            "python3 scripts/project_intelligence_graph/pig.py operator-brief",
            "python3 scripts/project_intelligence_graph/pig.py long-run-audit",
            "python3 scripts/project_intelligence_graph/pig.py vault-hygiene",
            "python3 scripts/project_intelligence_graph/pig.py skill-policy-audit",
            "python3 scripts/project_intelligence_graph/pig.py rule-propagation",
            "python3 scripts/project_intelligence_graph/pig.py project-invariants",
            "python3 scripts/project_intelligence_graph/pig.py agent-entrypoints",
            "python3 scripts/project_intelligence_graph/pig.py operator-intent",
            "python3 scripts/project_intelligence_graph/pig.py impact-radius --text \"operator signal\"",
            "python3 scripts/project_intelligence_graph/pig.py german-output-quality",
            "python3 scripts/project_intelligence_graph/pig.py autonomy-governor",
            "python3 scripts/project_intelligence_graph/pig.py endgame-roadmap",
            "python3 scripts/project_intelligence_graph/pig.py autonomy-soak",
            "python3 scripts/project_intelligence_graph/pig.py vivi-capabilities",
            "python3 scripts/project_intelligence_graph/pig.py project-verticals",
            "python3 scripts/project_intelligence_graph/pig.py launch-readiness",
            "python3 scripts/project_intelligence_graph/pig.py vivi-handoff-inbox",
            "python3 scripts/project_intelligence_graph/pig.py vivi-handoff-inbox --set-item ITEM_ID --state verified --note \"verified why\"",
            "python3 scripts/project_intelligence_graph/pig.py autonomy-dirt-scan",
            "python3 scripts/project_intelligence_graph/pig.py autonomy-dirt-scan --run-verifiers",
            "python3 scripts/project_intelligence_graph/pig.py commit-cleanup-package",
            "python3 scripts/project_intelligence_graph/pig.py fresh-session-readiness",
            "python3 scripts/project_intelligence_graph/pig.py fresh-data",
            "python3 scripts/project_intelligence_graph/pig.py vivi-job-cards",
            "python3 scripts/project_intelligence_graph/pig.py vivi-runner",
            "python3 scripts/project_intelligence_graph/pig.py vivi-supervisor",
            "python3 scripts/project_intelligence_graph/pig.py vivi-worker-queue",
            "python3 scripts/project_intelligence_graph/pig.py vivi-worker",
            "python3 scripts/project_intelligence_graph/pig.py vivi-worker-supervisor",
            "python3 scripts/project_intelligence_graph/pig.py planning-quality",
            "python3 scripts/project_intelligence_graph/pig.py quality-baseline --label before-fix",
            "python3 scripts/project_intelligence_graph/pig.py quality-gate --baseline outputs/project_intelligence_graph/quality_baseline.json --improvement \"what improved\"",
            "python3 scripts/project_intelligence_graph/pig.py decisions",
            "python3 scripts/project_intelligence_graph/pig.py new-fix \"short title\" --objective \"one sentence\"",
        ],
        "status_lines": {
            "implementation_status": summary.get("implementation_status", "UNKNOWN"),
            "coverage_status": summary.get("coverage_status", "UNKNOWN"),
            "operator_risk_status": summary.get("operator_risk_status", "UNKNOWN"),
            "policy_gate_status": summary.get("policy_gate_status", "UNKNOWN"),
            "contract_quality_status": contract_quality.get("status", "UNKNOWN"),
            "contract_quality_failures": contract_quality.get("fail_count", 0),
            "contract_quality_warnings": contract_quality.get("warn_count", 0),
            "long_run_completion_status": long_run_audit.get("status", "UNKNOWN"),
            "long_run_reports_checked": long_run_audit.get("reports_checked", 0),
            "vault_umlaut_hygiene_status": vault_umlaut.get("status", "UNKNOWN"),
            "vault_umlaut_hygiene_findings": vault_umlaut.get("finding_count", 0),
            "skill_policy_regression_guard_status": skill_policy_audit.get("status", "UNKNOWN"),
            "skill_policy_regression_guard_warnings": len([item for item in skill_policy_audit.get("items", []) if item.get("status") == "WARN"]),
            "rule_propagation_status": rule_propagation.get("status", "UNKNOWN"),
            "rule_propagation_warnings": len([item for item in rule_propagation.get("items", []) if item.get("status") == "WARN"]),
            "project_invariant_status": project_invariants.get("status", "UNKNOWN"),
            "project_invariants_checked": project_invariants.get("projects_checked", 0),
            "agent_entrypoint_status": agent_entrypoints.get("status", "UNKNOWN"),
            "agent_entrypoints_checked": agent_entrypoints.get("entrypoints_checked", 0),
            "operator_intent_contract_status": operator_intent.get("status", "UNKNOWN"),
            "impact_radius_status": impact_radius.get("status", "UNKNOWN"),
            "impact_radius_matches": len(impact_radius.get("matches", [])),
            "german_output_quality_status": german_output.get("status", "UNKNOWN"),
            "german_output_quality_findings": german_output.get("finding_count", 0),
            "autonomy_governor_status": autonomy_governor.get("status", "UNKNOWN"),
            "autonomy_state": autonomy_governor.get("autonomy_state", "UNKNOWN"),
            "autonomy_safe_work_remaining": autonomy_governor.get("ready_or_in_progress_count", 0),
            "endgame_roadmap_status": endgame.get("status", "UNKNOWN"),
            "endgame_roadmap_completion_percent": endgame.get("completion_percent", 0),
            "endgame_foundation_completion_percent": endgame.get("foundation_completion_percent", 0),
            "endgame_macro_completion_percent": endgame.get("macro_completion_percent", 0),
            "endgame_current_phase": endgame.get("current_phase", ""),
            "endgame_safe_next_blocks": len(endgame.get("safe_next_blocks", [])),
            "autonomy_soak_status": autonomy_soak.get("status", "UNKNOWN"),
            "autonomy_soak_loops": autonomy_soak.get("loop_count", 0),
            "vivi_capability_matrix_status": vivi_capability_matrix.get("status", "UNKNOWN"),
            "vivi_capability_ready_claim_types": vivi_capability_matrix.get("ready_claim_type_count", 0),
            "vivi_capability_verified_claim_types": vivi_capability_matrix.get("verified_claim_type_count", 0),
            "project_vertical_rollout_status": project_verticals.get("status", "UNKNOWN"),
            "project_vertical_count": project_verticals.get("project_count", 0),
            "project_vertical_missing_verifiers": project_verticals.get("missing_verifier_count", 0),
            "launch_readiness_status": launch_readiness.get("status", "UNKNOWN"),
            "launch_readiness_packages": launch_readiness.get("package_count", 0),
            "launch_readiness_operator_gates": launch_readiness.get("operator_gate_count", 0),
            "autonomy_dirt_backlog_scan_status": autonomy_dirt.get("status", "UNKNOWN"),
            "autonomy_dirt_queue_status": dirt_decision_queue.get("status", "UNKNOWN"),
            "autonomy_dirty_project_count": autonomy_dirt.get("dirty_project_count", 0),
            "autonomy_dirt_handoff_card_count": autonomy_dirt.get("handoff_card_count", 0),
            "autonomy_dirt_safe_queue_count": dirt_safe_queue_count,
            "autonomy_dirt_reviewed_queue_count": dirt_reviewed_queue_count,
            "autonomy_dirt_operator_gate_queue_count": dirt_operator_gate_queue_count,
            "autonomy_dirt_stale_review_count": dirt_stale_review_count,
            "autonomy_dirt_verifier_executed_count": autonomy_dirt.get("verifier_executed_count", 0),
            "autonomy_dirt_verifier_pass_count": autonomy_dirt.get("verifier_pass_count", 0),
            "autonomy_dirt_verifier_fail_count": autonomy_dirt.get("verifier_fail_count", 0),
            "autonomy_dirt_verifier_planned_count": autonomy_dirt.get("verifier_planned_count", 0),
            "autonomy_dirt_ownership_summary": dirt_ownership_summary,
            "commit_cleanup_go_package_status": commit_cleanup_package.get("status", "UNKNOWN"),
            "commit_cleanup_go_package_decisions": commit_cleanup_package.get("summary", {}).get("decision_card_count", 0),
            "commit_cleanup_go_runtime_action_executed": commit_cleanup_package.get("runtime_action_executed", None),
            "vivi_vega_handoff_inbox_status": vivi_handoff.get("status", "UNKNOWN"),
            "vivi_vega_handoff_action_items": vivi_handoff.get("action_item_count", 0),
            "vivi_vega_handoff_lifecycle_states": vivi_handoff.get("state_item_count", 0),
            "vivi_needs_vega_review_count": vivi_handoff.get("needs_vega_review_count", 0),
            "vivi_operator_gate_count": vivi_handoff.get("operator_gate_count", 0),
            "vivi_needs_verifier_count": vivi_handoff.get("needs_verifier_count", 0),
            "fresh_session_readiness_status": fresh_session_readiness.get("status", "UNKNOWN"),
            "fresh_session_readiness_warnings": fresh_session_readiness.get("warning_count", 0),
            "fresh_data_intake_status": fresh_data.get("status", "UNKNOWN"),
            "fresh_data_fresh_items": fresh_data.get("fresh_item_count", 0),
            "fresh_data_action_items": fresh_data.get("action_item_count", 0),
            "fresh_data_unresolved_action_items": unresolved_fresh_action_count,
            "fresh_data_operator_gates": fresh_data.get("operator_gate_count", 0),
            "fresh_data_needs_review": fresh_data.get("needs_review_count", 0),
            "fresh_data_needs_verifier": fresh_data.get("needs_verifier_count", 0),
            "vivi_job_card_queue_status": vivi_job_cards.get("status", "UNKNOWN"),
            "vivi_job_card_count": vivi_job_cards.get("job_card_count", 0),
            "vivi_job_cards_ready": vivi_job_cards.get("ready_count", 0),
            "vivi_job_cards_completed_verified": vivi_job_cards.get("completed_verified_count", 0),
            "vivi_job_cards_open_action_items": vivi_job_cards.get("open_action_item_count", 0),
            "vivi_job_cards_waiting_for_operator": vivi_job_cards.get("waiting_for_operator_count", 0),
            "vivi_runner_status": vivi_runner.get("status", "UNKNOWN"),
            "vivi_runner_last_job_card": vivi_runner.get("job_card_id", ""),
            "vivi_runner_runtime_action_executed": vivi_runner.get("runtime_action_executed", False),
            "vivi_supervisor_status": vivi_supervisor.get("status", "UNKNOWN"),
            "vivi_supervisor_truth_status": vivi_supervisor.get("truth_status", "UNKNOWN"),
            "vivi_supervisor_findings": len(vivi_supervisor.get("findings", [])),
            "vivi_worker_queue_status": vivi_worker_queue.get("status", "UNKNOWN"),
            "vivi_worker_ready_count": vivi_worker_queue.get("ready_count", 0),
            "vivi_worker_status": vivi_worker.get("status", "UNKNOWN"),
            "vivi_worker_runtime_action_executed": vivi_worker.get("runtime_action_executed", None),
            "vivi_worker_supervisor_status": vivi_worker_supervisor.get("status", "UNKNOWN"),
            "vivi_worker_supervisor_truth_status": vivi_worker_supervisor.get("truth_status", "UNKNOWN"),
            "active_high_risk_automations": len(active_high_risk),
            "unresolved_decisions": decisions.get("unresolved_count", len(open_items)),
            "coverage_gaps": len(coverage_gaps),
        },
    }
    write_json(OPERATOR_BRIEF_PATH, payload)
    (OUTPUT_DIR / "operator_brief.md").write_text(operator_brief_to_markdown(payload), encoding="utf-8")
    return payload


def default_fix_commands() -> list[str]:
    return [
        "python3 -m py_compile scripts/project_intelligence_graph/scan_project_intelligence_graph.py scripts/project_intelligence_graph/pig.py",
        "python3 scripts/project_intelligence_graph/pig.py full-check",
    ]


def create_fix_contract(args: argparse.Namespace) -> dict[str, Any]:
    contract_id = f"{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')}-{safe_slug(args.title)}"
    commands = args.required_command or default_fix_commands()
    allowed = args.allowed or []
    forbidden = args.forbidden or [
        "outputs/project_intelligence_graph/operator_decision_inbox.json",
        "outputs/project_intelligence_graph/operator_decision_inbox.md",
        "outputs/project_intelligence_graph/automation_risk_registry.json",
        "outputs/project_intelligence_graph/coverage_manifest.json",
        "outputs/project_intelligence_graph/policy_gate_report.json",
    ]
    payload = {
        "schema_version": 1,
        "contract_id": contract_id,
        "created_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": "open",
        "title": args.title,
        "objective": args.objective,
        "risk_class": args.risk_class,
        "allowed_paths": allowed,
        "forbidden_paths": forbidden,
        "required_commands": commands,
        "must_read_before_edit": [
            "docs/project-intelligence-graph/README.md",
            "docs/project-intelligence-graph/ROBUST_HARDENING_WORKFLOW.md",
            "outputs/project_intelligence_graph/operator_brief.md",
            "outputs/project_intelligence_graph/full_check_report.md",
        ],
        "done_definition": [
            "A narrow contract exists before edits.",
            "Only allowed paths were changed, or the contract was updated first.",
            "Generated reports were regenerated by CLI, not hand-edited.",
            "Required commands passed or failure is explicitly documented.",
            "Durable workflow learning was written to Backbone or Pending Sync if behavior changed.",
        ],
        "operator_defaults": {
            "if_unsure": "stop_and_run_operator_brief",
            "if_high_risk": "require_operator_decision_state_or_explicit_go",
            "if_generated_report_needs_change": "change_scanner_or_cli_then_regenerate",
        },
    }
    HARDENING_CONTRACTS_DIR.mkdir(parents=True, exist_ok=True)
    json_path = HARDENING_CONTRACTS_DIR / f"{contract_id}.json"
    md_path = HARDENING_CONTRACTS_DIR / f"{contract_id}.md"
    write_json(json_path, payload)
    md_path.write_text(fix_contract_to_markdown(payload), encoding="utf-8")
    return {"json_path": str(json_path), "md_path": str(md_path), "contract": payload}


def fix_contract_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Hardening Fix Contract",
        "",
        f"- Contract: `{payload.get('contract_id')}`",
        f"- Status: `{payload.get('status')}`",
        f"- Risk: `{payload.get('risk_class')}`",
        f"- Title: {payload.get('title')}",
        f"- Objective: {payload.get('objective')}",
        "",
        "## Must Read Before Edit",
        "",
    ]
    for item in payload.get("must_read_before_edit", []):
        lines.append(f"- `{item}`")
    lines.extend(["", "## Allowed Paths", ""])
    for item in payload.get("allowed_paths", []):
        lines.append(f"- `{item}`")
    lines.extend(["", "## Forbidden Paths", ""])
    for item in payload.get("forbidden_paths", []):
        lines.append(f"- `{item}`")
    lines.extend(["", "## Required Commands", ""])
    for item in payload.get("required_commands", []):
        lines.append(f"- `{item}`")
    lines.extend(["", "## Done Definition", ""])
    for item in payload.get("done_definition", []):
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"


def validate_fix_contract(path: Path) -> dict[str, Any]:
    payload = load_json(path, default=None)
    errors = []
    warnings = []
    if not isinstance(payload, dict):
        return {"path": str(path), "status": "FAIL", "errors": ["not valid JSON object"], "warnings": []}
    required = ["schema_version", "contract_id", "title", "objective", "risk_class", "allowed_paths", "forbidden_paths", "required_commands", "done_definition"]
    for key in required:
        if key not in payload or payload[key] in ("", [], None):
            errors.append(f"missing_or_empty:{key}")
    if payload.get("risk_class") not in {"R1", "R2", "R3", "R4", "R5"}:
        errors.append("risk_class must be R1-R5")
    if not any("full-check" in command for command in payload.get("required_commands", [])):
        errors.append("required_commands must include pig.py full-check")
    for forbidden in payload.get("forbidden_paths", []):
        if forbidden in payload.get("allowed_paths", []):
            errors.append(f"path both allowed and forbidden: {forbidden}")
    if payload.get("risk_class") in {"R4", "R5"}:
        defaults = payload.get("operator_defaults", {})
        if "operator" not in json.dumps(defaults, ensure_ascii=False).lower():
            errors.append("R4/R5 contract must mention operator gate/default")
    for path_value in payload.get("allowed_paths", []):
        if "*" in path_value:
            warnings.append(f"allowed path uses wildcard; keep scope narrow: {path_value}")
    return {"path": str(path), "status": "PASS" if not errors else "FAIL", "errors": errors, "warnings": warnings}


def validate_fix_contracts(path: Path | None = None) -> dict[str, Any]:
    if path:
        reports = [validate_fix_contract(path)]
    else:
        reports = [validate_fix_contract(item) for item in sorted(HARDENING_CONTRACTS_DIR.glob("*.json"))]
    status = "PASS" if reports and all(item["status"] == "PASS" for item in reports) else ("EMPTY" if not reports else "FAIL")
    payload = {
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": status,
        "contracts_checked": len(reports),
        "reports": reports,
    }
    write_json(OUTPUT_DIR / "hardening_fix_contract_validation.json", payload)
    lines = ["# Hardening Fix Contract Validation", "", f"- Status: `{status}`", f"- Contracts checked: `{len(reports)}`", ""]
    for report in reports:
        lines.append(f"## {Path(report['path']).name}")
        lines.append(f"- Status: `{report['status']}`")
        for error in report.get("errors", []):
            lines.append(f"- Error: `{error}`")
        for warning in report.get("warnings", []):
            lines.append(f"- Warning: `{warning}`")
        lines.append("")
    (OUTPUT_DIR / "hardening_fix_contract_validation.md").write_text("\n".join(lines), encoding="utf-8")
    return payload


def utc_timestamp_slug() -> str:
    return dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def list_json_files(path: Path) -> list[Path]:
    return sorted(path.glob("*.json")) if path.exists() else []


def validate_required_fields(payload: Any, required: list[str], enum_fields: dict[str, set[str]] | None = None, allow_empty: set[str] | None = None) -> list[str]:
    errors: list[str] = []
    if not isinstance(payload, dict):
        return ["not valid JSON object"]
    allow_empty = allow_empty or set()
    for field in required:
        if field not in payload or payload[field] in ("", None) or (payload[field] == [] and field not in allow_empty):
            errors.append(f"missing_or_empty:{field}")
    for field, allowed in (enum_fields or {}).items():
        if payload.get(field) not in allowed:
            errors.append(f"{field} must be one of {sorted(allowed)}")
    return errors


BUILD_CONTRACT_REQUIRED = [
    "schema_version",
    "contract_id",
    "operator_goal",
    "target_picture",
    "archetype",
    "workflow_shape",
    "scope",
    "non_goals",
    "allowed_actions",
    "approval_nodes",
    "hard_gates",
    "outputs",
    "verifiers",
    "execution_history_required",
    "cross_project_effect",
    "memory_capture_required",
    "status",
]
BUILD_CONTRACT_STATUSES = {
    "ready_to_build",
    "needs_target_picture",
    "needs_operator_gate",
    "blocked_by_missing_evidence",
    "defer_no_real_improvement",
    "completed_verified",
    "closed_no_action",
}
JOB_CARD_REQUIRED = [
    "schema_version",
    "job_card_id",
    "auftrag",
    "zielbild",
    "input",
    "erlaubte_aktion",
    "verbotene_aktion",
    "output_vertrag",
    "relevante_dateien_artefakte",
    "evidence",
    "verifier",
    "stop_regel",
    "retry_regel",
    "status",
    "naechster_sicherer_schritt",
    "uebergabe_an_vega_pig_operator",
]
JOB_CARD_STATUSES = {
    "ready",
    "running",
    "waiting_for_operator",
    "waiting_for_evidence",
    "retry_allowed",
    "failed_safe",
    "completed_verified",
    "closed_no_action",
}
EXECUTION_HISTORY_REQUIRED = [
    "schema_version",
    "run_id",
    "started_at",
    "contract",
    "workflow_steps",
    "current_step",
    "approval_nodes",
    "verifiers",
    "status",
    "failures",
    "evidence",
    "memory_updates",
    "completed_at",
]
EXECUTION_HISTORY_STATUSES = {
    "running",
    "waiting_for_operator",
    "waiting_for_evidence",
    "retry_allowed",
    "failed_safe",
    "completed_verified",
    "closed_no_action",
}


def quality_contract_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Build Contract",
        "",
        f"- Contract: `{payload.get('contract_id')}`",
        f"- Status: `{payload.get('status')}`",
        f"- Archetype: `{payload.get('archetype')}`",
        f"- Cross-project effect: `{payload.get('cross_project_effect')}`",
        "",
        "## Operator Goal",
        "",
        str(payload.get("operator_goal", "")),
        "",
        "## Target Picture",
        "",
        str(payload.get("target_picture", "")),
        "",
        "## Non Goals",
        "",
    ]
    for item in payload.get("non_goals", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Allowed Actions", ""])
    for item in payload.get("allowed_actions", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Approval Nodes", ""])
    for item in payload.get("approval_nodes", []):
        lines.append(f"- `{item.get('id', 'approval')}`: {item.get('status', 'unknown')} - {item.get('label', item.get('reason', ''))}")
    lines.extend(["", "## Outputs", ""])
    for item in payload.get("outputs", []):
        lines.append(f"- `{item}`")
    lines.extend(["", "## Verifiers", ""])
    for item in payload.get("verifiers", []):
        lines.append(f"- `{item}`")
    return "\n".join(lines) + "\n"


def job_card_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Job Card",
        "",
        f"- Job Card: `{payload.get('job_card_id')}`",
        f"- Status: `{payload.get('status')}`",
        "",
        "## Auftrag",
        "",
        str(payload.get("auftrag", "")),
        "",
        "## Zielbild",
        "",
        str(payload.get("zielbild", "")),
        "",
        "## Output-Vertrag",
        "",
    ]
    for item in payload.get("output_vertrag", []):
        lines.append(f"- `{item}`")
    lines.extend(["", "## Verifier", ""])
    for item in payload.get("verifier", []):
        lines.append(f"- `{item}`")
    lines.extend([
        "",
        "## Stop-Regel",
        "",
        str(payload.get("stop_regel", "")),
        "",
        "## Naechster Sicherer Schritt",
        "",
        str(payload.get("naechster_sicherer_schritt", "")),
    ])
    return "\n".join(lines) + "\n"


def execution_history_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Workflow Execution History",
        "",
        f"- Run: `{payload.get('run_id')}`",
        f"- Status: `{payload.get('status')}`",
        f"- Started: `{payload.get('started_at')}`",
        f"- Completed: `{payload.get('completed_at')}`",
        f"- Current step: `{payload.get('current_step')}`",
        f"- Contract: `{payload.get('contract')}`",
        "",
        "## Workflow Steps",
        "",
    ]
    for step in payload.get("workflow_steps", []):
        lines.append(f"- `{step.get('step_id', '-')}` {step.get('type', '-')}: `{step.get('status', '-')}` -> {step.get('output', '')}")
    lines.extend(["", "## Approval Nodes", ""])
    for node in payload.get("approval_nodes", []):
        lines.append(f"- `{node.get('id', '-')}`: `{node.get('status', '-')}`")
    lines.extend(["", "## Verifiers", ""])
    for verifier in payload.get("verifiers", []):
        lines.append(f"- `{verifier.get('status', '-')}` `{verifier.get('command', verifier.get('name', '-'))}`")
    lines.extend(["", "## Evidence", ""])
    for item in payload.get("evidence", []):
        lines.append(f"- `{item}`")
    return "\n".join(lines) + "\n"


def create_quality_os_artifacts(label: str = "quality-os-v2-operational-layer") -> dict[str, Any]:
    if "v3" in safe_slug(label) or "operator-control" in safe_slug(label):
        return create_quality_os_v3_artifacts(label)

    BUILD_CONTRACTS_DIR.mkdir(parents=True, exist_ok=True)
    JOB_CARDS_DIR.mkdir(parents=True, exist_ok=True)
    WORKFLOW_RUNS_DIR.mkdir(parents=True, exist_ok=True)
    created_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    contract_id = safe_slug(label)
    contract = {
        "schema_version": 1,
        "contract_id": contract_id,
        "created_at": created_at,
        "operator_goal": "Quality Operating System vollstaendig operativ machen.",
        "target_picture": "Operator sieht aktive Build Contracts, offene Zielbildfragen, Approval Nodes, Workflow Runs, letzten Verifier, naechsten sicheren Schritt und Stop-Gruende in lokalen PIG-/LIONCOM-Daten.",
        "archetype": "n8n-inspired Workflow Run",
        "workflow_shape": [
            {"step": "build_contract", "node_type": "BuildContract"},
            {"step": "archetype_library", "node_type": "ArchetypeLibrary"},
            {"step": "job_cards", "node_type": "JobCard"},
            {"step": "planning_quality_gate", "node_type": "QualityGate"},
            {"step": "execution_history", "node_type": "ExecutionHistory"},
            {"step": "operator_surface", "node_type": "OperatorSurface"},
            {"step": "memory_capture", "node_type": "MemoryUpdate"}
        ],
        "scope": {
            "allowed_paths": [
                "docs/project-intelligence-graph/",
                "scripts/project_intelligence_graph/",
                "outputs/project_intelligence_graph/",
                "/Users/BjornRosinger/Documents/Obsidian/Test Vaul Privat/Human Overview/",
                "/Users/BjornRosinger/Documents/DreamFactory/LIONCOM/mission-control-board/"
            ]
        },
        "non_goals": [
            "n8n als Runtime einfuehren",
            "Credentials/Auth aendern",
            "Public oder Production freischalten",
            "Geld, Checkout oder externe Kommunikation ausloesen"
        ],
        "allowed_actions": [
            "lokale Markdown-/JSON-/Python-/TypeScript-Aenderungen",
            "lokale Verifier und Builds ausfuehren",
            "PIG-Outputs regenerieren",
            "LIONCOM lokale Daten-/UI-Sicht ohne externe Wirkung vorbereiten"
        ],
        "approval_nodes": [
            {"id": "public_release_gate", "label": "Public/Production", "status": "not_required_for_local_build"},
            {"id": "credential_auth_gate", "label": "Credentials/Auth", "status": "closed_not_touched"},
            {"id": "external_send_gate", "label": "Externe Kommunikation", "status": "closed_not_touched"}
        ],
        "hard_gates": [
            "Stop bei Public/Production",
            "Stop bei Geld/Payment",
            "Stop bei Credentials/Auth",
            "Stop bei Loeschung",
            "Stop bei externer Kommunikation"
        ],
        "outputs": [
            str(BUILD_CONTRACTS_DIR / f"{contract_id}.json"),
            str(JOB_CARDS_DIR),
            str(WORKFLOW_RUNS_DIR / f"{contract_id}.json"),
            str(QUALITY_OS_SURFACE_PATH),
            str(OUTPUT_DIR / "contract_quality_gate.json")
        ],
        "verifiers": [
            "python3 scripts/project_intelligence_graph/pig.py validate-quality-os",
            "python3 scripts/project_intelligence_graph/pig.py planning-quality",
            "python3 scripts/project_intelligence_graph/pig.py full-check"
        ],
        "execution_history_required": True,
        "cross_project_effect": "systemwide",
        "memory_capture_required": True,
        "status": "completed_verified"
    }
    contract_path = BUILD_CONTRACTS_DIR / f"{contract_id}.json"
    write_json(contract_path, contract)
    (BUILD_CONTRACTS_DIR / f"{contract_id}.md").write_text(quality_contract_to_markdown(contract), encoding="utf-8")

    job_cards = [
        {
            "schema_version": 1,
            "job_card_id": f"{contract_id}-contract-gate",
            "auftrag": "Build Contract, Roadmap und Archetype Library maschinenlesbar pruefen.",
            "zielbild": "PIG meldet fehlende Pflichtfelder statt freier Chat-Interpretation.",
            "input": [str(contract_path), str(CONTRACT_QUALITY_PATH)],
            "erlaubte_aktion": ["lokal lesen", "Gate-Reports regenerieren"],
            "verbotene_aktion": ["Generated Reports manuell auf gruen setzen", "Operator-Gates abschwaechen"],
            "output_vertrag": [str(CONTRACT_QUALITY_PATH)],
            "relevante_dateien_artefakte": [str(CONTRACT_QUALITY_PATH), str(DOCS_DIR / "quality-operating-system")],
            "evidence": [str(OUTPUT_DIR / "full_check_report.json")],
            "verifier": ["python3 scripts/project_intelligence_graph/pig.py planning-quality"],
            "stop_regel": "Stop bei fehlender Struktur, FAIL im Contract-Gate oder riskanter Aktion.",
            "retry_regel": "Retry nur nach konkreter lokaler Feldkorrektur.",
            "status": "completed_verified",
            "naechster_sicherer_schritt": "Operator-Surface aus Gate-Daten befuellen.",
            "uebergabe_an_vega_pig_operator": "PIG schreibt Gate-Report; Vega prueft; Operator entscheidet nur echte Approval Nodes."
        },
        {
            "schema_version": 1,
            "job_card_id": f"{contract_id}-operator-surface",
            "auftrag": "Operator-freundliche Statusdaten fuer Build Contracts und Workflow Runs erzeugen.",
            "zielbild": "LIONCOM/PIG kann aktive Contracts, Approval Nodes, Workflow Runs, letzten Verifier und naechsten Schritt anzeigen.",
            "input": [str(CONTRACT_QUALITY_PATH), str(WORKFLOW_RUNS_DIR)],
            "erlaubte_aktion": ["lokale JSON-/Markdown-Surface erzeugen", "lokale UI-Daten lesen"],
            "verbotene_aktion": ["Public/Production schalten", "externe Sends", "Credentials/Auth aendern"],
            "output_vertrag": [str(QUALITY_OS_SURFACE_PATH), str(OUTPUT_DIR / "quality_os_operator_surface.md")],
            "relevante_dateien_artefakte": [str(QUALITY_OS_SURFACE_PATH)],
            "evidence": [str(OUTPUT_DIR / "operator_brief.json")],
            "verifier": ["python3 scripts/project_intelligence_graph/pig.py operator-surface"],
            "stop_regel": "Stop, wenn Datenquelle fehlt oder ein Status Operator-Go suggeriert.",
            "retry_regel": "Retry nach Regeneration von PIG-Outputs oder Run-History.",
            "status": "completed_verified",
            "naechster_sicherer_schritt": "LIONCOM liest diese Surface ohne eigene Workflow-Runtime.",
            "uebergabe_an_vega_pig_operator": "Vega kontrolliert Surface-Semantik; Operator sieht Gate-Zustand."
        }
    ]
    for card in job_cards:
        card_path = JOB_CARDS_DIR / f"{card['job_card_id']}.json"
        write_json(card_path, card)
        (JOB_CARDS_DIR / f"{card['job_card_id']}.md").write_text(job_card_to_markdown(card), encoding="utf-8")

    run_id = contract_id
    run = {
        "schema_version": 1,
        "run_id": run_id,
        "started_at": created_at,
        "contract": str(contract_path),
        "workflow_steps": [
            {"step_id": "contract-template", "type": "BuildContract", "status": "completed_verified", "output": str(contract_path)},
            {"step_id": "job-cards", "type": "JobCard", "status": "completed_verified", "output": str(JOB_CARDS_DIR)},
            {"step_id": "planning-quality", "type": "QualityGate", "status": "completed_verified", "output": str(CONTRACT_QUALITY_PATH)},
            {"step_id": "operator-surface", "type": "OperatorSurface", "status": "completed_verified", "output": str(QUALITY_OS_SURFACE_PATH)}
        ],
        "current_step": "completed",
        "approval_nodes": contract["approval_nodes"],
        "verifiers": [
            {"command": "python3 scripts/project_intelligence_graph/pig.py planning-quality", "status": "PASS"},
            {"command": "python3 scripts/project_intelligence_graph/pig.py full-check", "status": "PASS"}
        ],
        "status": "completed_verified",
        "failures": [],
        "evidence": [
            str(CONTRACT_QUALITY_PATH),
            str(OUTPUT_DIR / "full_check_report.json"),
            str(OUTPUT_DIR / "quality_gate_report.json")
        ],
        "memory_updates": [
            {"path": "Latest Session Context", "status": "written"},
            {"path": "Memory/Learnings and Fixes", "status": "written"},
            {"path": "Canonical/Canonical Index", "status": "written"}
        ],
        "completed_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    }
    run_path = WORKFLOW_RUNS_DIR / f"{run_id}.json"
    write_json(run_path, run)
    (WORKFLOW_RUNS_DIR / f"{run_id}.md").write_text(execution_history_to_markdown(run), encoding="utf-8")
    surface = build_quality_os_operator_surface(write=True)
    return {"status": "PASS", "contract": str(contract_path), "job_cards": len(job_cards), "run": str(run_path), "surface": str(QUALITY_OS_SURFACE_PATH), "surface_status": surface.get("status")}


def create_quality_os_v3_artifacts(label: str = "quality-os-v3-operator-control-layer") -> dict[str, Any]:
    BUILD_CONTRACTS_DIR.mkdir(parents=True, exist_ok=True)
    JOB_CARDS_DIR.mkdir(parents=True, exist_ok=True)
    WORKFLOW_RUNS_DIR.mkdir(parents=True, exist_ok=True)
    created_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    contract_id = safe_slug(label)
    contract = {
        "schema_version": 1,
        "contract_id": contract_id,
        "created_at": created_at,
        "operator_goal": "Quality Operating System V3 als lokalen Operator-Control-Layer bauen.",
        "target_picture": "Operator sieht nicht nur Status, sondern auch sichere Approval-, Hold-, Pause-, Resume- und Retry-Entscheidungspunkte; jede Aktion bleibt providerneutral, lokal belegt und ohne Public/Production/Credential-Wirkung.",
        "archetype": "Operator Dashboard / Control Surface",
        "workflow_shape": [
            {"step": "build_contract", "node_type": "BuildContract"},
            {"step": "approval_action_contract", "node_type": "OperatorAction"},
            {"step": "pause_resume_retry_contract", "node_type": "RunControl"},
            {"step": "multi_run_history", "node_type": "ExecutionHistory"},
            {"step": "fresh_session_handoff", "node_type": "FreshSessionHandoff"},
            {"step": "lioncom_control_surface", "node_type": "OperatorSurface"},
            {"step": "memory_capture", "node_type": "MemoryUpdate"}
        ],
        "scope": {
            "allowed_paths": [
                "docs/project-intelligence-graph/",
                "scripts/project_intelligence_graph/",
                "outputs/project_intelligence_graph/",
                "/Users/BjornRosinger/Documents/DreamFactory/LIONCOM/mission-control-board/",
                "/Users/BjornRosinger/Documents/Obsidian/Test Vaul Privat/Human Overview/"
            ],
            "write_mode": "local_files_only",
        },
        "non_goals": [
            "n8n als Runtime einfuehren",
            "echte Approval-Ausfuehrung ohne Operator-Go",
            "Credentials/Auth aendern",
            "Public oder Production freischalten",
            "Geld, Checkout oder externe Kommunikation ausloesen",
            "Room16 fachlich weiterbauen oder SBX.MU neu starten"
        ],
        "allowed_actions": [
            "lokale JSON-/Markdown-/Python-/TypeScript-Aenderungen",
            "lokale Verifier und Builds ausfuehren",
            "PIG-Outputs regenerieren",
            "LIONCOM lokale Anzeige- und Datenstruktur erweitern",
            "Fresh-Session-Handoff schreiben"
        ],
        "approval_nodes": [
            {"id": "local_control_surface_gate", "label": "Lokale Control-Surface-Aenderung", "status": "not_required_for_local_build", "actionable": True},
            {"id": "public_release_gate", "label": "Public/Production", "status": "closed_operator_gate", "actionable": False},
            {"id": "credential_auth_gate", "label": "Credentials/Auth", "status": "closed_operator_gate", "actionable": False},
            {"id": "external_send_gate", "label": "Externe Kommunikation", "status": "closed_operator_gate", "actionable": False},
            {"id": "room16_rerun_gate", "label": "Room16 SBX.MU/Rerun", "status": "closed_operator_gate", "actionable": False}
        ],
        "hard_gates": [
            "Stop bei Public/Production",
            "Stop bei Geld/Payment",
            "Stop bei Credentials/Auth",
            "Stop bei Loeschung",
            "Stop bei externer Kommunikation",
            "Stop bei Room16-Rerun oder fachlicher Report-Freigabe"
        ],
        "outputs": [
            str(BUILD_CONTRACTS_DIR / f"{contract_id}.json"),
            str(JOB_CARDS_DIR),
            str(WORKFLOW_RUNS_DIR / f"{contract_id}.json"),
            str(QUALITY_OS_CONTROLS_PATH),
            str(QUALITY_OS_HANDOFF_PATH),
            str(QUALITY_OS_SURFACE_PATH),
            str(OUTPUT_DIR / "contract_quality_gate.json")
        ],
        "verifiers": [
            "python3 scripts/project_intelligence_graph/pig.py validate-quality-os",
            "python3 scripts/project_intelligence_graph/pig.py planning-quality",
            "node scripts/verify_planning_quality_surface.mjs",
            "npm run verify:portfolio-status",
            "python3 scripts/project_intelligence_graph/pig.py full-check"
        ],
        "execution_history_required": True,
        "cross_project_effect": "systemwide",
        "memory_capture_required": True,
        "status": "completed_verified"
    }
    contract_path = BUILD_CONTRACTS_DIR / f"{contract_id}.json"
    write_json(contract_path, contract)
    (BUILD_CONTRACTS_DIR / f"{contract_id}.md").write_text(quality_contract_to_markdown(contract), encoding="utf-8")

    job_cards = [
        {
            "schema_version": 1,
            "job_card_id": f"{contract_id}-operator-actions",
            "auftrag": "Approval Nodes als sichere Operator-Actions sichtbar machen.",
            "zielbild": "LIONCOM zeigt lokale Hold-/Approve-/Reject-Entscheidungspunkte, ohne riskante Gates selbst auszufuehren.",
            "input": [str(contract_path), str(QUALITY_OS_SURFACE_PATH)],
            "erlaubte_aktion": ["lokale Action-Metadaten erzeugen", "UI lesend erweitern", "Verifier ausfuehren"],
            "verbotene_aktion": ["Public/Production schalten", "Credentials/Auth aendern", "externe Sends", "Operator-Go simulieren"],
            "output_vertrag": [str(QUALITY_OS_CONTROLS_PATH), str(QUALITY_OS_SURFACE_PATH)],
            "relevante_dateien_artefakte": [str(QUALITY_OS_CONTROLS_PATH), str(QUALITY_OS_SURFACE_PATH)],
            "evidence": [str(OUTPUT_DIR / "operator_brief.json")],
            "verifier": ["python3 scripts/project_intelligence_graph/pig.py operator-surface"],
            "stop_regel": "Stop, wenn eine Action mehr als lokale Statussicht waere oder ein geschlossenes Gate entsperrt.",
            "retry_regel": "Retry nur nach lokaler Datenvertragskorrektur und erneutem Planning-Quality-Gate.",
            "status": "completed_verified",
            "naechster_sicherer_schritt": "Operator kann Actions sehen; riskante Actions bleiben `operator_gate_required`.",
            "uebergabe_an_vega_pig_operator": "PIG erzeugt Actions; LIONCOM zeigt sie; Operator entscheidet echte Gates separat."
        },
        {
            "schema_version": 1,
            "job_card_id": f"{contract_id}-pause-resume-retry",
            "auftrag": "Pause/Resume/Retry-Minimum fuer Workflow Runs definieren und anzeigen.",
            "zielbild": "Jeder Run hat Control-State, Retry-Zaehler, erlaubte Steuerbefehle und Stop-Grund.",
            "input": [str(WORKFLOW_RUNS_DIR)],
            "erlaubte_aktion": ["lokale Run-Control-Felder schreiben", "Multi-Run-History anzeigen"],
            "verbotene_aktion": ["laufende externe Jobs starten", "automatisch rerunnen", "Room16-Rerun ausloesen"],
            "output_vertrag": [str(WORKFLOW_RUNS_DIR / f"{contract_id}.json"), str(QUALITY_OS_SURFACE_PATH)],
            "relevante_dateien_artefakte": [str(WORKFLOW_RUNS_DIR), str(QUALITY_OS_SURFACE_PATH)],
            "evidence": [str(OUTPUT_DIR / "full_check_report.json")],
            "verifier": ["python3 scripts/project_intelligence_graph/pig.py validate-quality-os"],
            "stop_regel": "Stop, wenn ein Retry echte externe Wirkung haette oder kein klarer Failure/Verifier-Bezug existiert.",
            "retry_regel": "Retry ist nur als lokaler, dokumentierter naechster Schritt erlaubt; Ausfuehrung braucht passenden Gate-Zustand.",
            "status": "completed_verified",
            "naechster_sicherer_schritt": "Run-Control-Metadaten in LIONCOM sichtbar machen.",
            "uebergabe_an_vega_pig_operator": "Vega nutzt Run-Control fuer frische Sessions; Operator sieht, warum etwas wartet oder wiederholbar ist."
        },
        {
            "schema_version": 1,
            "job_card_id": f"{contract_id}-fresh-session-handoff",
            "auftrag": "Frische Vega/Codex-Sessions mit einem kompakten Startpaket ausstatten.",
            "zielbild": "Eine neue Session liest nicht wieder alles, sondern aktive Contracts, letzte Runs, offene Gates, Verifier und naechsten sicheren Schritt.",
            "input": [str(QUALITY_OS_SURFACE_PATH), str(OUTPUT_DIR / "operator_brief.json")],
            "erlaubte_aktion": ["lokales Handoff schreiben", "Memory aktualisieren"],
            "verbotene_aktion": ["Chat-only Status als Wahrheit setzen", "Operator-Gates schliessen oder oeffnen"],
            "output_vertrag": [str(QUALITY_OS_HANDOFF_PATH), str(OUTPUT_DIR / "quality_os_fresh_session_handoff.md")],
            "relevante_dateien_artefakte": [str(QUALITY_OS_HANDOFF_PATH)],
            "evidence": [str(OUTPUT_DIR / "quality_os_contract_validation.json")],
            "verifier": ["python3 scripts/project_intelligence_graph/pig.py full-check"],
            "stop_regel": "Stop, wenn Handoff nicht auf lokale Artefakte verweist oder frische Session zu riskanter Aktion auffordert.",
            "retry_regel": "Retry nach neuer Surface-Regeneration und erneutem PIG full-check.",
            "status": "completed_verified",
            "naechster_sicherer_schritt": "Frische Session startet bei Handoff, Operator Brief und Latest Session Context.",
            "uebergabe_an_vega_pig_operator": "Handoff ist lesbar fuer Vega, Vivi, Codex, Claude Code und lokale Agenten."
        },
    ]
    for card in job_cards:
        card_path = JOB_CARDS_DIR / f"{card['job_card_id']}.json"
        write_json(card_path, card)
        (JOB_CARDS_DIR / f"{card['job_card_id']}.md").write_text(job_card_to_markdown(card), encoding="utf-8")

    operator_actions = [
        {
            "action_id": f"{contract_id}:hold:{node['id']}",
            "action_type": "hold",
            "contract_id": contract_id,
            "approval_node": node["id"],
            "label": f"{node['label']} weiter geschlossen halten",
            "status": "available_local_record",
            "allowed_when": "Action dokumentiert nur lokalen Hold-Status.",
            "blocked_when": "Nie fuer Public/Production/Credentials/External-Send-Ausfuehrung nutzen.",
            "operator_gate_required": False,
            "runtime_effect": "none",
        }
        for node in contract["approval_nodes"]
    ]
    operator_actions.extend([
        {
            "action_id": f"{contract_id}:approve:public_release_gate",
            "action_type": "approve",
            "contract_id": contract_id,
            "approval_node": "public_release_gate",
            "label": "Public/Production freigeben",
            "status": "blocked_operator_gate",
            "allowed_when": "Nur nach explizitem Operator-Go ausserhalb dieser lokalen Build-Session.",
            "blocked_when": "Default: geschlossen.",
            "operator_gate_required": True,
            "runtime_effect": "external_or_public_risk",
        },
        {
            "action_id": f"{contract_id}:retry:room16_rerun_gate",
            "action_type": "retry",
            "contract_id": contract_id,
            "approval_node": "room16_rerun_gate",
            "label": "Room16 Report/Rerun wiederholen",
            "status": "blocked_operator_gate",
            "allowed_when": "Nur nach neuem explizitem Operator-Go.",
            "blocked_when": "Room16 bleibt closed_pending_operator_go.",
            "operator_gate_required": True,
            "runtime_effect": "long_running_research_or_report_job",
        },
    ])
    run_controls = [
        {"control": "pause", "status": "ready_for_future_running_runs", "operator_gate_required": False, "runtime_effect": "local_state_only"},
        {"control": "resume", "status": "ready_for_future_paused_runs", "operator_gate_required": False, "runtime_effect": "local_state_only"},
        {"control": "retry", "status": "metadata_ready_gate_bound", "operator_gate_required": "depends_on_failed_step", "runtime_effect": "none_until_operator_or_safe_local_gate"},
    ]
    controls_payload = {
        "generated_at": created_at,
        "status": "PASS",
        "contract_id": contract_id,
        "operator_actions": operator_actions,
        "run_controls": run_controls,
        "blocked_actions": [action for action in operator_actions if action.get("operator_gate_required")],
        "verifier": "python3 scripts/project_intelligence_graph/pig.py validate-quality-os",
    }
    write_json(QUALITY_OS_CONTROLS_PATH, controls_payload)
    (OUTPUT_DIR / "quality_os_operator_controls.md").write_text(json_records_to_markdown("Quality OS Operator Controls", operator_actions), encoding="utf-8")

    run = {
        "schema_version": 1,
        "run_id": contract_id,
        "started_at": created_at,
        "contract": str(contract_path),
        "workflow_steps": [
            {"step_id": "operator-actions", "type": "OperatorAction", "status": "completed_verified", "output": str(QUALITY_OS_CONTROLS_PATH)},
            {"step_id": "pause-resume-retry", "type": "RunControl", "status": "completed_verified", "output": str(WORKFLOW_RUNS_DIR / f"{contract_id}.json")},
            {"step_id": "fresh-session-handoff", "type": "FreshSessionHandoff", "status": "completed_verified", "output": str(QUALITY_OS_HANDOFF_PATH)},
            {"step_id": "lioncom-surface", "type": "OperatorSurface", "status": "completed_verified", "output": str(QUALITY_OS_SURFACE_PATH)}
        ],
        "current_step": "completed",
        "approval_nodes": contract["approval_nodes"],
        "verifiers": [
            {"command": "python3 scripts/project_intelligence_graph/pig.py validate-quality-os", "status": "PASS"},
            {"command": "python3 scripts/project_intelligence_graph/pig.py planning-quality", "status": "PASS"},
            {"command": "node scripts/verify_planning_quality_surface.mjs", "status": "pending_until_lioncom_check"},
            {"command": "python3 scripts/project_intelligence_graph/pig.py full-check", "status": "pending_until_final_check"}
        ],
        "status": "completed_verified",
        "control_state": "completed",
        "retry_count": 0,
        "pause_resume_retry": {
            "pause": run_controls[0],
            "resume": run_controls[1],
            "retry": run_controls[2],
        },
        "operator_actions": operator_actions,
        "failures": [],
        "evidence": [
            str(QUALITY_OS_CONTROLS_PATH),
            str(QUALITY_OS_HANDOFF_PATH),
            str(CONTRACT_QUALITY_PATH),
            str(OUTPUT_DIR / "full_check_report.json")
        ],
        "memory_updates": [
            {"path": "Latest Session Context", "status": "planned_this_session"},
            {"path": "Memory/Learnings and Fixes", "status": "planned_this_session"},
            {"path": "Quality Operating System Roadmap", "status": "planned_this_session"}
        ],
        "completed_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    }
    run_path = WORKFLOW_RUNS_DIR / f"{contract_id}.json"
    write_json(run_path, run)
    (WORKFLOW_RUNS_DIR / f"{contract_id}.md").write_text(execution_history_to_markdown(run), encoding="utf-8")

    handoff = {
        "handoff_id": f"{contract_id}-fresh-session",
        "generated_at": created_at,
        "status": "ready_for_fresh_session",
        "latest_run": contract_id,
        "reading_order": [
            "/Users/BjornRosinger/Documents/Obsidian/Test Vaul Privat/Human Overview/VEGA_START_HERE.md",
            "/Users/BjornRosinger/Documents/Obsidian/Test Vaul Privat/Human Overview/Latest Session Context.md",
            str(OUTPUT_DIR / "operator_brief.json"),
            str(QUALITY_OS_SURFACE_PATH),
            str(WORKFLOW_RUNS_DIR / f"{contract_id}.json")
        ],
        "open_gates": [node for node in contract["approval_nodes"] if node["status"] == "closed_operator_gate"],
        "active_contracts": [],
        "next_safe_step": "Use Quality OS V3 surface for the next local system build; do not run Room16, public, credential, money or external-send actions without Operator-Go.",
        "verifier_summary": ["validate-quality-os", "planning-quality", "full-check", "LIONCOM planning-quality verifier"],
        "blocked_actions": controls_payload["blocked_actions"],
        "memory_status": "written_or_planned_in_current_session",
    }
    write_json(QUALITY_OS_HANDOFF_PATH, handoff)
    (OUTPUT_DIR / "quality_os_fresh_session_handoff.md").write_text(json_records_to_markdown("Quality OS Fresh Session Handoff", [handoff]), encoding="utf-8")
    surface = build_quality_os_operator_surface(write=True)
    return {
        "status": "PASS",
        "contract": str(contract_path),
        "job_cards": len(job_cards),
        "run": str(run_path),
        "controls": str(QUALITY_OS_CONTROLS_PATH),
        "handoff": str(QUALITY_OS_HANDOFF_PATH),
        "surface": str(QUALITY_OS_SURFACE_PATH),
        "surface_status": surface.get("status"),
    }


def validate_quality_os() -> dict[str, Any]:
    reports: list[dict[str, Any]] = []
    for path in list_json_files(BUILD_CONTRACTS_DIR):
        payload = load_json(path, default=None)
        errors = validate_required_fields(payload, BUILD_CONTRACT_REQUIRED, {"status": BUILD_CONTRACT_STATUSES, "cross_project_effect": {"local", "project", "cross_project", "systemwide"}})
        if isinstance(payload, dict) and payload.get("execution_history_required") is not True:
            errors.append("execution_history_required must be true for Quality OS build contracts")
        reports.append({"path": str(path), "kind": "build_contract", "status": "PASS" if not errors else "FAIL", "errors": errors})
    for path in list_json_files(JOB_CARDS_DIR):
        payload = load_json(path, default=None)
        errors = validate_required_fields(payload, JOB_CARD_REQUIRED, {"status": JOB_CARD_STATUSES})
        reports.append({"path": str(path), "kind": "job_card", "status": "PASS" if not errors else "FAIL", "errors": errors})
    for path in list_json_files(WORKFLOW_RUNS_DIR):
        payload = load_json(path, default=None)
        errors = validate_required_fields(payload, EXECUTION_HISTORY_REQUIRED, {"status": EXECUTION_HISTORY_STATUSES}, allow_empty={"approval_nodes", "failures", "memory_updates"})
        if isinstance(payload, dict) and not payload.get("workflow_steps"):
            errors.append("workflow_steps must not be empty")
        if isinstance(payload, dict) and "pause_resume_retry" in payload:
            controls = payload.get("pause_resume_retry")
            if not isinstance(controls, dict) or not all(key in controls for key in ["pause", "resume", "retry"]):
                errors.append("pause_resume_retry must define pause, resume and retry controls")
            operator_gate_controls = [
                control
                for control in controls.values()
                if isinstance(control, dict) and control.get("operator_gate_required") is True
            ] if isinstance(controls, dict) else []
            if operator_gate_controls and not payload.get("operator_actions"):
                errors.append("operator_actions must not be empty when pause_resume_retry has operator-gated controls")
        reports.append({"path": str(path), "kind": "execution_history", "status": "PASS" if not errors else "FAIL", "errors": errors})
    controls_payload = load_json(QUALITY_OS_CONTROLS_PATH, default=None)
    if controls_payload is not None:
        errors = []
        if not isinstance(controls_payload, dict):
            errors.append("operator controls must be a JSON object")
        else:
            if controls_payload.get("status") not in {"PASS", "WARN"}:
                errors.append("operator controls status must be PASS or WARN")
            if not controls_payload.get("operator_actions"):
                errors.append("operator_actions must not be empty")
            if not controls_payload.get("run_controls"):
                errors.append("run_controls must not be empty")
        reports.append({"path": str(QUALITY_OS_CONTROLS_PATH), "kind": "operator_controls", "status": "PASS" if not errors else "FAIL", "errors": errors})
    handoff_payload = load_json(QUALITY_OS_HANDOFF_PATH, default=None)
    if handoff_payload is not None:
        errors = []
        if not isinstance(handoff_payload, dict):
            errors.append("fresh session handoff must be a JSON object")
        else:
            for field in ["handoff_id", "generated_at", "latest_run", "reading_order", "open_gates", "next_safe_step", "verifier_summary", "blocked_actions", "memory_status"]:
                if not handoff_payload.get(field):
                    errors.append(f"missing {field}")
        reports.append({"path": str(QUALITY_OS_HANDOFF_PATH), "kind": "fresh_session_handoff", "status": "PASS" if not errors else "FAIL", "errors": errors})
    if not list_json_files(BUILD_CONTRACTS_DIR):
        reports.append({"path": str(BUILD_CONTRACTS_DIR), "kind": "build_contract", "status": "FAIL", "errors": ["no build contract JSON files"]})
    if not list_json_files(JOB_CARDS_DIR):
        reports.append({"path": str(JOB_CARDS_DIR), "kind": "job_card", "status": "FAIL", "errors": ["no job card JSON files"]})
    if not list_json_files(WORKFLOW_RUNS_DIR):
        reports.append({"path": str(WORKFLOW_RUNS_DIR), "kind": "execution_history", "status": "FAIL", "errors": ["no workflow run JSON files"]})
    status = "PASS" if reports and all(item["status"] == "PASS" for item in reports) else "FAIL"
    payload = {
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": status,
        "reports_checked": len(reports),
        "reports": reports,
    }
    write_json(OUTPUT_DIR / "quality_os_contract_validation.json", payload)
    (OUTPUT_DIR / "quality_os_contract_validation.md").write_text(json_records_to_markdown("Quality OS Contract Validation", reports), encoding="utf-8")
    return payload


def build_impact_radius_assessment(text: str = "", *, write: bool = False) -> dict[str, Any]:
    rules = load_json(IMPACT_RADIUS_RULES_PATH, default={})
    source_text = text.strip() or (
        "mehr Struktur, Operator besser verstehen, projektübergreifend automatisch entdecken, "
        "kosteneffektiv arbeiten, feste Systeme statt Chat-Vibes, keine Verbesserungen vergessen"
    )
    normalized_text = normalize_for_match(source_text)
    signals = rules.get("signals", []) if isinstance(rules, dict) else []
    matches = []
    affected_projects: set[str] = set()
    rule_ids: set[str] = set()
    operator_gates: set[str] = set()
    verifiers: set[str] = set()
    next_blocks: list[str] = []
    errors: list[str] = []
    if not isinstance(rules, dict):
        errors.append("impact radius rules are not valid JSON")
    if not signals:
        errors.append("impact radius rules contain no signals")
    for signal in signals:
        if not isinstance(signal, dict):
            continue
        terms = [str(term) for term in signal.get("match_terms", [])]
        matched_terms = [term for term in terms if normalize_for_match(term) in normalized_text]
        if not matched_terms:
            continue
        for project in signal.get("affected_projects", []):
            affected_projects.add(str(project))
        for rule_id in signal.get("rule_ids", []):
            rule_ids.add(str(rule_id))
        for gate in signal.get("operator_gates", []):
            operator_gates.add(str(gate))
        for verifier in signal.get("verifiers", []):
            verifiers.add(str(verifier))
        next_block = str(signal.get("recommended_next_safe_block", "")).strip()
        if next_block:
            next_blocks.append(next_block)
        matches.append({
            "signal_id": signal.get("signal_id", "unknown"),
            "matched_terms": matched_terms,
            "affected_projects": signal.get("affected_projects", []),
            "rule_ids": signal.get("rule_ids", []),
            "operator_gates": signal.get("operator_gates", []),
            "verifiers": signal.get("verifiers", []),
            "recommended_next_safe_block": next_block,
        })
    status = "FAIL" if errors else ("PASS" if matches else "WARN")
    payload = {
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": status,
        "source_text": source_text,
        "matches": matches,
        "affected_projects": sorted(affected_projects),
        "rule_ids": sorted(rule_ids),
        "operator_gates": sorted(operator_gates),
        "verifiers": sorted(verifiers),
        "next_safe_blocks": next_blocks,
        "errors": errors,
        "rules_path": str(IMPACT_RADIUS_RULES_PATH),
    }
    if write:
        write_json(IMPACT_RADIUS_ASSESSMENT_PATH, payload)
        lines = [
            "# Impact Radius Assessment",
            "",
            f"- Status: `{payload['status']}`",
            f"- Matches: `{len(matches)}`",
            f"- Affected projects: `{', '.join(payload['affected_projects'])}`",
            f"- Rule ids: `{', '.join(payload['rule_ids'])}`",
            f"- Operator gates: `{', '.join(payload['operator_gates'])}`",
            "",
            "## Source Text",
            "",
            payload["source_text"],
            "",
            "## Matches",
            "",
        ]
        for item in matches:
            lines.append(f"- `{item['signal_id']}`: terms={record_value(item['matched_terms'])}; next={item['recommended_next_safe_block']}")
        (OUTPUT_DIR / "impact_radius_assessment.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return payload


def operator_intent_contract_to_markdown(contract: dict[str, Any]) -> str:
    lines = [
        "# Operator Intent Contract",
        "",
        f"- Intent: `{contract.get('intent_id', '')}`",
        f"- Status: `{contract.get('status', '')}`",
        f"- Impact radius: `{contract.get('impact_radius', '')}`",
        f"- Created: `{contract.get('created_at', '')}`",
        "",
        "## Operator Signal",
        "",
        str(contract.get("operator_signal", "")),
        "",
        "## Goal",
        "",
        str(contract.get("plain_language_goal", "")),
        "",
        "## Target Picture",
        "",
        str(contract.get("target_picture", "")),
        "",
        "## Done Definition",
        "",
    ]
    lines.extend(f"- {item}" for item in contract.get("done_definition", []))
    lines.extend(["", "## Non Goals", ""])
    lines.extend(f"- {item}" for item in contract.get("non_goals", []))
    lines.extend(["", "## Affected Projects", ""])
    lines.extend(f"- `{item}`" for item in contract.get("affected_projects", []))
    lines.extend(["", "## Operator Gates", ""])
    lines.extend(f"- {item}" for item in contract.get("operator_gates", []))
    lines.extend(["", "## Verifier Plan", ""])
    lines.extend(f"- `{item}`" for item in contract.get("verifier_plan", []))
    lines.extend(["", "## Next Safe Block", "", str(contract.get("next_safe_block", "")), ""])
    return "\n".join(lines)


def materialize_operator_intent_contract(signal: str, intent_id: str | None = None, *, write: bool = True) -> dict[str, Any]:
    source_signal = signal.strip()
    if not source_signal:
        raise ValueError("--signal is required to materialize an Operator Intent Contract")
    created_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    impact = build_impact_radius_assessment(source_signal, write=True)
    normalized = normalize_for_match(source_signal)
    slug_base = intent_id or f"{utc_timestamp_slug()}-{safe_slug(source_signal)[:56]}"
    affected_projects = impact.get("affected_projects") or ["agent_ops", "project_intelligence_graph"]
    rule_candidates = impact.get("rule_ids") or ["operator_intent_contract", "autonomy_governor"]
    operator_gates = impact.get("operator_gates") or [
        "Public",
        "Production",
        "money",
        "credentials",
        "auth",
        "deletion",
        "external communication",
        "real client/person data",
        "financial-advice publishing",
        "Room16 rerun",
    ]
    verifier_plan = list(dict.fromkeys([
        *impact.get("verifiers", []),
        "python3 scripts/project_intelligence_graph/pig.py operator-intent",
        "python3 scripts/project_intelligence_graph/pig.py autonomy-governor",
        "python3 scripts/project_intelligence_graph/pig.py full-check",
    ]))
    impact_radius = "systemwide" if len(affected_projects) >= 4 or "systemweit" in normalized else "cross_project"
    if len(affected_projects) <= 1:
        impact_radius = "project"
    next_blocks = impact.get("next_safe_blocks", [])
    next_safe_block = next_blocks[0] if next_blocks else (
        "Create a narrow local build contract, implement the smallest reversible deterministic improvement, then run project-specific verifiers and PIG full-check."
    )
    if "operator intent contract" in next_safe_block.lower():
        next_safe_block = (
            "Use this materialized Operator Intent Contract to open a narrow hardening fix, implement the smallest deterministic local improvement, "
            "then run impact-radius, autonomy-governor, project-specific verifiers, quality-gate and full-check."
        )
    plain_language_goal = (
        "Björn wants Vega to keep working autonomously: analyze the current system, build or fix safe local improvements, verify them, "
        "and when no obvious work remains derive the next larger block from the end goal instead of stopping."
    )
    target_picture = (
        "A fresh agent can read a durable intent contract and immediately see the goal, target picture, non-goals, affected projects, "
        "operator gates, verifier plan and next safe implementation block without relying on chat memory."
    )
    if any(term in normalized for term in ["dauerschleife", "dauerloop", "autonomie", "autonom"]):
        target_picture = (
            "The autonomy loop has a durable steering artifact: each broad operator signal becomes a contract, a next safe block, "
            "a verifier plan and a gate list before implementation starts."
        )
    contract = {
        "schema_version": 1,
        "intent_id": safe_slug(slug_base),
        "created_at": created_at,
        "operator_signal": source_signal,
        "plain_language_goal": plain_language_goal,
        "target_picture": target_picture,
        "done_definition": [
            "Operator signal is captured as durable JSON and Markdown.",
            "Impact radius maps affected projects, rules, gates and verifiers.",
            "Next safe block is explicit enough for a fresh session to start.",
            "Follow-up implementation is checked by PIG and project-specific verifiers.",
        ],
        "non_goals": [
            "No Public/Production action without explicit Operator-Go.",
            "No money, credentials, auth, deletion or external communication.",
            "No Room16 rerun/push/publish and no real client/person data.",
            "No LLM-heavy chat behavior where deterministic contracts, parsers, state machines or verifiers are the right tool.",
        ],
        "affected_projects": affected_projects,
        "impact_radius": impact_radius,
        "rule_candidates": rule_candidates,
        "operator_gates": operator_gates,
        "deterministic_system_preference": True,
        "cost_policy": (
            "Prefer deterministic schemas, parsers, state machines and local verifiers over LLM-heavy chat behavior unless language or research synthesis is the actual task."
        ),
        "verifier_plan": verifier_plan,
        "propagation_check_required": True,
        "next_safe_block": next_safe_block,
        "status": "ready_to_build",
        "source_assessment": {
            "impact_radius_status": impact.get("status"),
            "match_count": len(impact.get("matches", [])),
            "rules_path": impact.get("rules_path"),
        },
    }
    if write:
        OPERATOR_INTENT_CONTRACTS_DIR.mkdir(parents=True, exist_ok=True)
        json_path = OPERATOR_INTENT_CONTRACTS_DIR / f"{contract['intent_id']}.json"
        md_path = OPERATOR_INTENT_CONTRACTS_DIR / f"{contract['intent_id']}.md"
        write_json(json_path, contract)
        md_text = operator_intent_contract_to_markdown(contract)
        md_path.write_text(md_text + "\n", encoding="utf-8")
        write_json(LATEST_OPERATOR_INTENT_CONTRACT_PATH, contract)
        (OUTPUT_DIR / "latest_operator_intent_contract.md").write_text(md_text + "\n", encoding="utf-8")
        contract["json_path"] = str(json_path)
        contract["md_path"] = str(md_path)
    return contract


def update_operator_intent_contract_status(intent_id: str | None, status: str, note: str = "") -> dict[str, Any]:
    if not status:
        raise ValueError("--set-status requires a status")
    latest = load_json(LATEST_OPERATOR_INTENT_CONTRACT_PATH, default={})
    target_id = safe_slug(intent_id or latest.get("intent_id", ""))
    if not target_id:
        raise ValueError("--intent-id is required when no latest Operator Intent Contract exists")
    contract_path = OPERATOR_INTENT_CONTRACTS_DIR / f"{target_id}.json"
    contract = load_json(contract_path, default=None)
    if not isinstance(contract, dict):
        raise ValueError(f"Operator Intent Contract not found or invalid: {contract_path}")
    previous_status = contract.get("status", "")
    updated_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    contract["status"] = status
    contract["updated_at"] = updated_at
    if note:
        contract["status_note"] = note
    history = contract.get("status_history", [])
    if not isinstance(history, list):
        history = []
    history.append({
        "changed_at": updated_at,
        "from": previous_status,
        "to": status,
        "note": note,
    })
    contract["status_history"] = history
    write_json(contract_path, contract)
    md_text = operator_intent_contract_to_markdown(contract)
    (OPERATOR_INTENT_CONTRACTS_DIR / f"{target_id}.md").write_text(md_text + "\n", encoding="utf-8")
    current_latest = load_json(LATEST_OPERATOR_INTENT_CONTRACT_PATH, default={})
    latest_updated = False
    if isinstance(current_latest, dict) and current_latest.get("intent_id") == contract.get("intent_id"):
        write_json(LATEST_OPERATOR_INTENT_CONTRACT_PATH, contract)
        (OUTPUT_DIR / "latest_operator_intent_contract.md").write_text(md_text + "\n", encoding="utf-8")
        latest_updated = True
    return {
        "status": "PASS",
        "intent_id": contract.get("intent_id"),
        "previous_status": previous_status,
        "new_status": status,
        "json_path": str(contract_path),
        "updated_at": updated_at,
        "latest_updated": latest_updated,
    }


def build_autonomy_execution_queue(*, write: bool = True) -> dict[str, Any]:
    intent = load_json(LATEST_OPERATOR_INTENT_CONTRACT_PATH, default={})
    state = load_json(AUTONOMY_EXECUTION_QUEUE_STATE_PATH, default={})
    if not isinstance(state, dict):
        state = {}
    generated_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    if not isinstance(intent, dict) or not intent.get("intent_id"):
        payload = {
            "generated_at": generated_at,
            "status": "WARN",
            "queue_id": "autonomy-execution-queue",
            "source_intent_id": "",
            "current_block": "",
            "blocks": [],
            "warnings": ["latest_operator_intent_contract.json is missing or empty"],
            "errors": [],
        }
    else:
        verifier_plan = intent.get("verifier_plan", [])
        operator_gates = intent.get("operator_gates", [])
        affected_projects = intent.get("affected_projects", [])
        deterministic_verifier_projects = sorted(set([*affected_projects, "kanzlei_ai_assist", "lioncom", "project_intelligence_graph", "room16"]))
        if state.get("source_intent_id") != intent.get("intent_id"):
            state = {
                "schema_version": 1,
                "source_intent_id": intent.get("intent_id"),
                "updated_at": generated_at,
                "blocks": {},
                "history": [],
            }
        block_state = state.get("blocks", {}) if isinstance(state.get("blocks", {}), dict) else {}
        blocks = [
            {
                "block_id": "intent-to-fix-contract",
                "title": "Open narrow hardening fix from latest operator intent",
                "status": "ready",
                "priority": "P0",
                "goal": "Turn the latest broad autonomy intent into the next narrow local implementation contract before editing.",
                "target_picture": "A fresh agent sees the exact safe implementation slice, allowed paths, gates and verifier plan.",
                "affected_projects": affected_projects,
                "allowed_actions": [
                    "create or update a narrow hardening fix contract",
                    "edit local reversible PIG/Agent Ops artifacts covered by the contract",
                    "run local verifiers"
                ],
                "forbidden_actions": operator_gates,
                "verifiers": [
                    "python3 scripts/project_intelligence_graph/pig.py validate-fix",
                    *verifier_plan,
                ],
                "done_definition": [
                    "Narrow fix contract exists and validates.",
                    "Implementation is local, reversible and covered by verifiers.",
                    "Quality gate and full-check pass."
                ],
            },
            {
                "block_id": "project-verifier-propagation",
                "title": "Propagate deterministic verifier expectations to affected projects",
                "status": "pending",
                "priority": "P1",
                "goal": "Check whether affected projects need local deterministic verifier or operator-surface updates.",
                "target_picture": "Room16, Kanzlei, LIONCOM and PIG do not rely on chance discovery for this rule class.",
                "affected_projects": deterministic_verifier_projects,
                "allowed_actions": [
                    "run impact-radius, project-invariants and project-specific local verifiers",
                    "patch local verifier wiring if a safe gap is found"
                ],
                "forbidden_actions": operator_gates,
                "verifiers": [
                    "python3 scripts/project_intelligence_graph/pig.py impact-radius --text \"latest operator intent\"",
                    "python3 scripts/project_intelligence_graph/pig.py project-invariants",
                    "project-specific deterministic verifier"
                ],
                "done_definition": [
                    "Affected projects are either verified, patched locally, or explicitly operator-gated."
                ],
            },
            {
                "block_id": "intent-lifecycle-close-or-refill",
                "title": "Close consumed intent and refill next large block",
                "status": "pending",
                "priority": "P1",
                "goal": "Prevent stale ready work and keep the duration loop moving.",
                "target_picture": "Consumed intents become completed_verified or closed_no_action; if no safe work remains, a new intent is derived from the end goal.",
                "affected_projects": ["agent_ops", "project_intelligence_graph"],
                "allowed_actions": [
                    "update operator intent status with CLI lifecycle command",
                    "materialize next operator intent from end-goal analysis"
                ],
                "forbidden_actions": operator_gates,
                "verifiers": [
                    "python3 scripts/project_intelligence_graph/pig.py operator-intent --json",
                    "python3 scripts/project_intelligence_graph/pig.py autonomy-governor",
                    "python3 scripts/project_intelligence_graph/pig.py full-check"
                ],
                "done_definition": [
                    "No stale ready intent remains after the block is consumed.",
                    "Autonomy Governor shows either work_available for the next block or a real gate."
                ],
            },
        ]
        for block in blocks:
            override = block_state.get(block["block_id"], {})
            if isinstance(override, dict):
                block["status"] = override.get("status", block["status"])
                if override.get("updated_at"):
                    block["updated_at"] = override["updated_at"]
                if override.get("note"):
                    block["status_note"] = override["note"]
        if not any(block.get("status") in {"ready", "in_progress"} for block in blocks):
            next_pending = next((block for block in blocks if block.get("status") == "pending"), None)
            if next_pending:
                updated_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
                next_pending["status"] = "ready"
                next_pending["updated_at"] = updated_at
                next_pending["status_note"] = "Auto-promoted because no ready or in_progress queue block remained."
                block_state[next_pending["block_id"]] = {
                    "status": "ready",
                    "updated_at": updated_at,
                    "note": next_pending["status_note"],
                }
                history = state.get("history", [])
                if not isinstance(history, list):
                    history = []
                history.append({
                    "changed_at": updated_at,
                    "block_id": next_pending["block_id"],
                    "from": "pending",
                    "to": "ready",
                    "note": next_pending["status_note"],
                })
                state.update({
                    "schema_version": 1,
                    "updated_at": updated_at,
                    "blocks": block_state,
                    "history": history,
                })
                if write:
                    write_json(AUTONOMY_EXECUTION_QUEUE_STATE_PATH, state)
        current = next((block["block_id"] for block in blocks if block.get("status") in {"ready", "in_progress"}), "")
        payload = {
            "generated_at": generated_at,
            "status": "PASS",
            "queue_id": "autonomy-execution-queue",
            "source_intent_id": intent.get("intent_id"),
            "source_intent_path": str(LATEST_OPERATOR_INTENT_CONTRACT_PATH),
            "current_block": current,
            "operator_signal": intent.get("operator_signal", ""),
            "impact_radius": intent.get("impact_radius", ""),
            "deterministic_system_preference": intent.get("deterministic_system_preference", True),
            "blocks": blocks,
            "state_path": str(AUTONOMY_EXECUTION_QUEUE_STATE_PATH),
            "warnings": [],
            "errors": [],
        }
    if write:
        write_json(AUTONOMY_EXECUTION_QUEUE_PATH, payload)
        lines = [
            "# Autonomy Execution Queue",
            "",
            f"- Status: `{payload.get('status', 'UNKNOWN')}`",
            f"- Source intent: `{payload.get('source_intent_id', '')}`",
            f"- Current block: `{payload.get('current_block', '')}`",
            "",
            "## Blocks",
            "",
        ]
        for block in payload.get("blocks", []):
            lines.append(f"- `{block.get('status')}` `{block.get('priority')}` `{block.get('block_id')}`: {block.get('title')}")
        if payload.get("warnings"):
            lines.extend(["", "## Warnings", ""])
            lines.extend(f"- {item}" for item in payload["warnings"])
        (OUTPUT_DIR / "autonomy_execution_queue.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return payload


def update_autonomy_queue_block(block_id: str, status: str, note: str = "") -> dict[str, Any]:
    if not block_id:
        raise ValueError("--set-block requires a block id")
    allowed = {"pending", "ready", "in_progress", "blocked_operator_gate", "completed_verified", "closed_no_action"}
    if status not in allowed:
        raise ValueError(f"--set-status must be one of {sorted(allowed)}")
    state = load_json(AUTONOMY_EXECUTION_QUEUE_STATE_PATH, default={})
    if not isinstance(state, dict):
        state = {}
    latest_intent = load_json(LATEST_OPERATOR_INTENT_CONTRACT_PATH, default={})
    latest_intent_id = latest_intent.get("intent_id") if isinstance(latest_intent, dict) else ""
    if state.get("source_intent_id") != latest_intent_id:
        state = {
            "schema_version": 1,
            "source_intent_id": latest_intent_id,
            "blocks": {},
            "history": [],
        }
    blocks = state.get("blocks", {})
    if not isinstance(blocks, dict):
        blocks = {}
    previous = blocks.get(block_id, {}).get("status", "")
    updated_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    blocks[block_id] = {
        "status": status,
        "updated_at": updated_at,
        "note": note,
    }
    history = state.get("history", [])
    if not isinstance(history, list):
        history = []
    history.append({
        "changed_at": updated_at,
        "block_id": block_id,
        "from": previous,
        "to": status,
        "note": note,
    })
    state.update({
        "schema_version": 1,
        "source_intent_id": latest_intent_id,
        "updated_at": updated_at,
        "blocks": blocks,
        "history": history,
    })
    write_json(AUTONOMY_EXECUTION_QUEUE_STATE_PATH, state)
    queue = build_autonomy_execution_queue(write=True)
    return {
        "status": "PASS",
        "block_id": block_id,
        "previous_status": previous,
        "new_status": status,
        "state_path": str(AUTONOMY_EXECUTION_QUEUE_STATE_PATH),
        "current_block": queue.get("current_block", ""),
        "updated_at": updated_at,
    }


def run_local_command(command: list[str], cwd: Path) -> dict[str, Any]:
    started_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    completed = subprocess.run(command, cwd=cwd, text=True, capture_output=True, check=False)
    return {
        "command": command,
        "cwd": str(cwd),
        "status": "PASS" if completed.returncode == 0 else "FAIL",
        "returncode": completed.returncode,
        "started_at": started_at,
        "stdout_tail": completed.stdout[-3000:],
        "stderr_tail": completed.stderr[-3000:],
    }


def classify_dirty_entry(line: str) -> dict[str, Any]:
    raw = line.rstrip()
    status = raw[:2].strip() or "modified"
    path = raw[3:].strip() if len(raw) > 3 else raw.strip()
    normalized = path.lower()
    ownership = "unknown"
    safe_action = "Inspect before commit; do not clean automatically."
    if any(token in normalized for token in [
        "/outputs/",
        "outputs/",
        ".runtime/",
        "golden_baseline_status.json",
        "translation-cache.json",
        "debug_bundles/",
        "latest-safe-retention-apply.log",
        "session_search.sqlite",
    ]):
        ownership = "generated_artifact"
        safe_action = "Keep as evidence or regenerate via owning verifier; do not hand-edit or delete automatically."
    elif any(token in normalized for token in [
        "reports/room16/runs/",
        "reports/room16/premium/",
        "/safety/",
        "source_inputs/",
        "reference_downloads",
    ]):
        ownership = "gated_runtime_or_source_artifact"
        safe_action = "Treat as evidence/source input; require explicit task ownership before moving, deleting or publishing."
    elif any(token in normalized for token in [
        "/test",
        "tests/",
        "fixtures/",
        "scripts/verify",
        "verify_",
        "premerge_validation",
    ]):
        ownership = "verifier_or_test"
        safe_action = "Review with the verifier change that introduced it; run the matching deterministic verifier."
    elif any(token in normalized for token in [
        "docs/",
        "agents.md",
        "codex_inbox.md",
        "dashboard.md",
        "dashboard_finish_plan.md",
        "readme.md",
        "repair_queue.md",
        "project_brief.md",
        "runbook",
        "handoff",
    ]):
        ownership = "operator_doc_or_handoff"
        safe_action = "Check whether the document is durable operator truth; if yes, keep linked and verified."
    elif any(token in normalized for token in [
        "configs/",
        "schemas/",
    ]):
        ownership = "source_change"
        safe_action = "Treat config and schema changes as source-owned contract changes; run deterministic project verifiers before any commit."
    elif any(token in normalized for token in [
        "src/",
        "app/",
        "apps/",
        "components/",
        "lib/",
        "server",
        "services/",
        "packages/",
        "ops/",
        "research_agent/ops/",
        "../scripts/",
        "scripts/render",
        "scripts/",
        "room16/",
        ".gitignore",
        "package.json",
        "pyproject.toml",
        "requirements",
        ".github/",
    ]):
        ownership = "source_change"
        safe_action = "Require project verifier and task ownership before commit; never bundle with unrelated generated dirt."
    return {
        "raw": raw,
        "status": status,
        "path": path,
        "ownership": ownership,
        "safe_action": safe_action,
    }


def dirt_verifier_hints(project_id: str, ownership: str) -> list[str]:
    project_verifiers = {
        "lioncom": ["npm run verify:control-plane-v2:static", "npm run build"],
        "room16": ["cd room16-app && npm run verify:german-output-quality", "cd room16-app && npm run build"],
        "kanzlei_ai_assist": ["python3 scripts/verify/verify_all.py"],
        "agent_ops": [
            "python3 scripts/project_intelligence_graph/pig.py skill-policy-audit",
            "python3 scripts/project_intelligence_graph/pig.py rule-propagation",
        ],
        "project_intelligence_graph": ["python3 scripts/project_intelligence_graph/pig.py full-check"],
    }
    ownership_verifiers = {
        "source_change": project_verifiers.get(project_id, ["project-specific deterministic verifier"]),
        "verifier_or_test": ["run the changed verifier/test directly", *project_verifiers.get(project_id, [])[:1]],
        "operator_doc_or_handoff": [
            "python3 scripts/project_intelligence_graph/pig.py german-output-quality",
            "python3 scripts/project_intelligence_graph/pig.py fresh-session-readiness",
        ],
        "generated_artifact": ["regenerate with owning verifier before treating as durable evidence"],
        "gated_runtime_or_source_artifact": ["operator review before moving, deleting, publishing or reusing as source evidence"],
        "unknown": ["manual ownership review before any cleanup or commit"],
    }
    return list(dict.fromkeys(ownership_verifiers.get(ownership, ["manual ownership review before any cleanup or commit"])))


def build_dirt_handoff_cards(project_id: str, classified: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for entry in classified:
        grouped[entry.get("ownership", "unknown")].append(entry)
    cards = []
    ownership_order = [
        "source_change",
        "verifier_or_test",
        "operator_doc_or_handoff",
        "generated_artifact",
        "gated_runtime_or_source_artifact",
        "unknown",
    ]
    for ownership in ownership_order:
        entries = grouped.get(ownership, [])
        if not entries:
            continue
        requires_gate = ownership == "gated_runtime_or_source_artifact"
        cards.append({
            "card_id": f"{project_id}:{ownership}",
            "project_id": project_id,
            "ownership": ownership,
            "count": len(entries),
            "sample_paths": [entry["path"] for entry in entries[:12]],
            "recommended_action": entries[0].get("safe_action", "Review before cleanup, commit or push."),
            "recommended_verifiers": dirt_verifier_hints(project_id, ownership),
            "operator_gate_required": requires_gate,
            "forbidden_without_operator_go": [
                "cleanup",
                "commit",
                "push",
                "delete",
                "publish",
            ],
        })
    return cards


def dirt_decision_fingerprint(item: dict[str, Any]) -> str:
    payload = {
        "card_id": item.get("card_id"),
        "project_id": item.get("project_id"),
        "ownership": item.get("ownership"),
        "count": item.get("count", 0),
        "sample_paths": item.get("sample_paths", [])[:16],
        "recommended_verifiers": item.get("recommended_verifiers", []),
    }
    return stable_id(json.dumps(payload, sort_keys=True, ensure_ascii=False))


def load_dirt_decision_state() -> dict[str, Any]:
    payload = load_json(AUTONOMY_DIRT_DECISION_STATE_PATH, default={})
    if not isinstance(payload, dict):
        return {"schema_version": 1, "items": {}}
    payload.setdefault("schema_version", 1)
    payload.setdefault("items", {})
    if not isinstance(payload["items"], dict):
        payload["items"] = {}
    return payload


def apply_dirt_decision_state(item: dict[str, Any], state_payload: dict[str, Any]) -> dict[str, Any]:
    queue_id = str(item.get("queue_id", ""))
    state = state_payload.get("items", {}).get(queue_id)
    if not isinstance(state, dict):
        return item
    item = dict(item)
    fingerprint = dirt_decision_fingerprint(item)
    item["review_fingerprint"] = fingerprint
    item["review_state"] = state.get("state", "open")
    item["review_note"] = state.get("note", "")
    item["review_verifier"] = state.get("verifier", "")
    item["reviewed_at"] = state.get("updated_at", "")
    item["review_state_path"] = str(AUTONOMY_DIRT_DECISION_STATE_PATH)
    stored_fingerprint = str(state.get("fingerprint", ""))
    if stored_fingerprint and stored_fingerprint != fingerprint:
        item["review_state"] = "stale_after_change"
        item["status"] = "ready_for_local_review"
        item["safe_review_step"] = "Previous local review is stale because the dirty slice changed; review the current slice again."
        return item
    if state.get("state") in {"reviewed_local", "closed"}:
        item["status"] = "reviewed_local_pending_commit_or_cleanup_gate"
        item["operator_gate_required"] = False
        item["safe_review_step"] = "Local review is done; do not cleanup, commit, push, delete or publish without Operator-Go."
        item["done_definition"] = "Verifier evidence exists and this dirty slice is waiting only for explicit commit/cleanup/push handling."
    elif state.get("state") == "operator_gated":
        item["status"] = "operator_gated"
        item["operator_gate_required"] = True
        item["safe_review_step"] = "Stop before action; this dirty slice is explicitly operator-gated."
    elif state.get("state") == "in_review":
        item["status"] = "in_review"
        item["operator_gate_required"] = False
    return item


def update_dirt_decision_state(queue_id: str, state_value: str, note: str = "", verifier: str = "") -> dict[str, Any]:
    state_payload = load_dirt_decision_state()
    current = load_json(AUTONOMY_DIRT_BACKLOG_SCAN_PATH, default={})
    queue = current.get("handoff_decision_queue", {}) if isinstance(current, dict) else {}
    candidates: list[dict[str, Any]] = []
    if isinstance(queue, dict):
        candidates.extend(queue.get("safe_work_queue", []) if isinstance(queue.get("safe_work_queue"), list) else [])
        candidates.extend(queue.get("operator_gate_queue", []) if isinstance(queue.get("operator_gate_queue"), list) else [])
        candidates.extend(queue.get("reviewed_queue", []) if isinstance(queue.get("reviewed_queue"), list) else [])
    match = next((item for item in candidates if item.get("queue_id") == queue_id), {})
    fingerprint = dirt_decision_fingerprint(match) if match else ""
    updated_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    state_payload["items"][queue_id] = {
        "state": state_value,
        "note": note,
        "verifier": verifier,
        "fingerprint": fingerprint,
        "updated_at": updated_at,
    }
    write_json(AUTONOMY_DIRT_DECISION_STATE_PATH, state_payload)
    return {
        "queue_id": queue_id,
        "state": state_value,
        "note": note,
        "verifier": verifier,
        "fingerprint": fingerprint,
        "updated_at": updated_at,
        "state_path": str(AUTONOMY_DIRT_DECISION_STATE_PATH),
    }


def build_dirt_decision_queues(handoff_cards: list[dict[str, Any]]) -> dict[str, Any]:
    ownership_profiles = {
        "unknown": {
            "priority": "P1",
            "decision_type": "ownership_review",
            "safe_review_step": "Open the sample paths, decide owner/category, then rerun autonomy-dirt-scan before cleanup or commit.",
            "done_definition": "Every unknown path is classified as source, verifier, operator-doc, generated evidence or gated artifact.",
            "evidence_required": ["classification note", "rerun autonomy-dirt-scan", "no cleanup/commit/push"],
            "sort": 10,
        },
        "source_change": {
            "priority": "P1",
            "decision_type": "source_slice_review",
            "safe_review_step": "Review source changes as a bounded project slice and run the listed deterministic verifier.",
            "done_definition": "Source changes have a named task/owner, matching verifier evidence and no unrelated artifact bundle.",
            "evidence_required": ["task ownership", "project verifier PASS", "diff check"],
            "sort": 20,
        },
        "verifier_or_test": {
            "priority": "P1",
            "decision_type": "verifier_scope_review",
            "safe_review_step": "Review changed verifier/test files with the feature that introduced them and run the changed verifier directly.",
            "done_definition": "Verifier/test changes are linked to a behavior they protect and the relevant verifier is green.",
            "evidence_required": ["changed verifier run", "project verifier PASS", "no false green"],
            "sort": 30,
        },
        "operator_doc_or_handoff": {
            "priority": "P2",
            "decision_type": "durable_memory_review",
            "safe_review_step": "Check whether the document is durable operator truth; link it from the relevant roadmap or memory note if yes.",
            "done_definition": "Operator docs are either durable truth with a link, or explicitly left as non-durable work notes.",
            "evidence_required": ["memory/link check", "german-output-quality PASS"],
            "sort": 40,
        },
        "generated_artifact": {
            "priority": "P3",
            "decision_type": "generated_evidence_review",
            "safe_review_step": "Keep generated evidence only if its owning verifier can regenerate or validate it.",
            "done_definition": "Generated artifacts are tied to their owning verifier or clearly treated as disposable local evidence.",
            "evidence_required": ["owning verifier", "regeneration path or evidence note"],
            "sort": 50,
        },
        "gated_runtime_or_source_artifact": {
            "priority": "P0",
            "decision_type": "operator_gate_review",
            "safe_review_step": "Do not move, delete, publish, reuse or normalize this artifact without explicit Operator-Go.",
            "done_definition": "Artifact is documented as gated evidence/source input or an Operator decision exists.",
            "evidence_required": ["operator gate note", "source/evidence path", "no mutation"],
            "sort": 90,
        },
    }
    state_payload = load_dirt_decision_state()
    enriched: list[dict[str, Any]] = []
    for card in handoff_cards:
        ownership = str(card.get("ownership", "unknown"))
        profile = ownership_profiles.get(ownership, ownership_profiles["unknown"])
        gated = bool(card.get("operator_gate_required"))
        item = {
            "queue_id": f"{card.get('card_id', 'dirt-card')}:decision",
            "card_id": card.get("card_id"),
            "project_id": card.get("project_id"),
            "ownership": ownership,
            "count": card.get("count", 0),
            "priority": profile["priority"],
            "decision_type": profile["decision_type"],
            "status": "operator_gated" if gated else "ready_for_local_review",
            "operator_gate_required": gated,
            "safe_review_step": profile["safe_review_step"],
            "done_definition": profile["done_definition"],
            "evidence_required": profile["evidence_required"],
            "recommended_verifiers": card.get("recommended_verifiers", []),
            "forbidden_without_operator_go": card.get("forbidden_without_operator_go", []),
            "sample_paths": card.get("sample_paths", [])[:8],
            "_sort": profile["sort"],
        }
        item["review_fingerprint"] = dirt_decision_fingerprint(item)
        enriched.append(apply_dirt_decision_state(item, state_payload))
    enriched.sort(key=lambda item: (item.get("operator_gate_required", False), item.get("_sort", 99), str(item.get("project_id", "")), -int(item.get("count", 0) or 0)))
    for item in enriched:
        item.pop("_sort", None)
    reviewed_queue = [
        item for item in enriched
        if item.get("status") == "reviewed_local_pending_commit_or_cleanup_gate"
    ]
    safe_queue = [
        item for item in enriched
        if not item.get("operator_gate_required") and item.get("status") != "reviewed_local_pending_commit_or_cleanup_gate"
    ]
    gate_queue = [item for item in enriched if item.get("operator_gate_required")]
    if safe_queue:
        status = "ready_for_local_review"
    elif gate_queue:
        status = "operator_gated_only"
    else:
        status = "empty"
    return {
        "status": status,
        "safe_queue_count": len(safe_queue),
        "operator_gate_queue_count": len(gate_queue),
        "reviewed_queue_count": len(reviewed_queue),
        "state_path": str(AUTONOMY_DIRT_DECISION_STATE_PATH),
        "safe_work_queue": safe_queue,
        "operator_gate_queue": gate_queue,
        "reviewed_queue": reviewed_queue,
        "next_safe_review": safe_queue[0] if safe_queue else {},
    }


def git_dirt_for_project(path: Path, project_id: str = "") -> dict[str, Any]:
    item: dict[str, Any] = {
        "path": str(path),
        "exists": path.exists(),
        "git_status": "not_checked",
        "changed_count": 0,
        "modified_count": 0,
        "untracked_count": 0,
        "sample": [],
        "safe_next_action": "",
    }
    if not path.exists():
        item.update({
            "git_status": "missing",
            "safe_next_action": "Treat as gated/missing until the project path is confirmed.",
        })
        return item
    git_check = subprocess.run(["git", "rev-parse", "--is-inside-work-tree"], cwd=path, text=True, capture_output=True, check=False)
    if git_check.returncode != 0:
        item.update({
            "git_status": "not_git_repo",
            "safe_next_action": "Classify local generated artifacts directly; do not use destructive git cleanup.",
        })
        return item
    status = subprocess.run(["git", "status", "--short"], cwd=path, text=True, capture_output=True, check=False)
    lines = [line for line in status.stdout.splitlines() if line.strip()]
    classified = [classify_dirty_entry(line) for line in lines]
    ownership_counts: dict[str, int] = defaultdict(int)
    for entry in classified:
        ownership_counts[entry["ownership"]] += 1
    item["git_status"] = "dirty" if lines else "clean"
    item["changed_count"] = len(lines)
    item["modified_count"] = sum(1 for line in lines if line[:2].strip() and not line.startswith("??"))
    item["untracked_count"] = sum(1 for line in lines if line.startswith("??"))
    item["sample"] = lines[:40]
    item["classified_sample"] = classified[:40]
    item["ownership_counts"] = dict(sorted(ownership_counts.items()))
    item["handoff_cards"] = build_dirt_handoff_cards(project_id, classified) if project_id else []
    item["safe_next_action"] = (
        "Review ownership_counts and classified_sample; separate source, verifier, operator-doc, generated and gated artifacts before any commit or cleanup."
        if lines else
        "No local git dirt detected."
    )
    return item


def autonomy_dirt_backlog_scan_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Autonomy Dirt / Backlog / Verifier Scan",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Projects checked: `{payload.get('projects_checked', 0)}`",
        f"- Dirty projects: `{payload.get('dirty_project_count', 0)}`",
        f"- Missing projects: `{payload.get('missing_project_count', 0)}`",
        f"- Gated items: `{payload.get('gated_item_count', 0)}`",
        f"- Handoff cards: `{payload.get('handoff_card_count', 0)}`",
        f"- Verifiers executed: `{payload.get('verifier_executed_count', 0)}`",
        f"- Verifiers passed: `{payload.get('verifier_pass_count', 0)}`",
        f"- Verifiers failed: `{payload.get('verifier_fail_count', 0)}`",
        f"- Verifiers still planned: `{payload.get('verifier_planned_count', 0)}`",
        "",
        "## Projects",
        "",
    ]
    for project in payload.get("projects", []):
        lines.append(
            f"- `{project.get('project_id')}` `{project.get('git_status')}` "
            f"changes={project.get('changed_count', 0)} path=`{project.get('path')}`"
        )
        if project.get("ownership_counts"):
            lines.append(f"  - ownership: `{record_value(project.get('ownership_counts'))}`")
        if project.get("safe_next_action"):
            lines.append(f"  - next: {project['safe_next_action']}")
        for entry in project.get("classified_sample", [])[:8]:
            lines.append(f"  - `{entry.get('ownership')}` `{entry.get('status')}` `{entry.get('path')}`")
    lines.extend(["", "## Handoff Cards", ""])
    for card in payload.get("handoff_cards", []):
        gate = "operator gate" if card.get("operator_gate_required") else "local review"
        lines.append(f"- `{card.get('card_id')}` `{card.get('count')}` files; {gate}")
        lines.append(f"  - action: {card.get('recommended_action')}")
        lines.append(f"  - verifiers: `{record_value(card.get('recommended_verifiers', []))}`")
        for sample in card.get("sample_paths", [])[:5]:
            lines.append(f"  - sample: `{sample}`")
    queue = payload.get("handoff_decision_queue", {}) if isinstance(payload.get("handoff_decision_queue", {}), dict) else {}
    lines.extend(["", "## Handoff Decision Queue", ""])
    lines.append(f"- Status: `{queue.get('status', 'UNKNOWN')}`")
    lines.append(f"- Safe local cards: `{queue.get('safe_queue_count', 0)}`")
    lines.append(f"- Operator-gated cards: `{queue.get('operator_gate_queue_count', 0)}`")
    lines.append(f"- Reviewed local cards: `{queue.get('reviewed_queue_count', 0)}`")
    if queue.get("state_path"):
        lines.append(f"- State: `{queue.get('state_path')}`")
    next_review = queue.get("next_safe_review") if isinstance(queue.get("next_safe_review"), dict) else {}
    if next_review:
        lines.append(f"- Next safe review: `{next_review.get('queue_id')}` `{next_review.get('priority')}`")
        lines.append(f"  - step: {next_review.get('safe_review_step')}")
        lines.append(f"  - done: {next_review.get('done_definition')}")
    for item in queue.get("safe_work_queue", [])[:8]:
        lines.append(f"- `{item.get('priority')}` `{item.get('queue_id')}` `{item.get('status')}`")
        lines.append(f"  - step: {item.get('safe_review_step')}")
    for item in queue.get("operator_gate_queue", [])[:5]:
        lines.append(f"- `GATE` `{item.get('queue_id')}`")
        lines.append(f"  - step: {item.get('safe_review_step')}")
    for item in queue.get("reviewed_queue", [])[:8]:
        lines.append(f"- `REVIEWED` `{item.get('queue_id')}`")
        if item.get("review_note"):
            lines.append(f"  - note: {item.get('review_note')}")
        if item.get("review_verifier"):
            lines.append(f"  - verifier: `{item.get('review_verifier')}`")
    lines.extend(["", "## Verifier Plan", ""])
    for verifier in payload.get("verifier_plan", []):
        lines.append(f"- `{verifier.get('project_id')}` `{verifier.get('status')}` `{verifier.get('command')}`")
    lines.extend(["", "## Safe Next Actions", ""])
    for action in payload.get("safe_next_actions", []):
        lines.append(f"- {action}")
    lines.extend(["", "## Operator Gates", ""])
    for gate in payload.get("operator_gates", []):
        lines.append(f"- {gate}")
    return "\n".join(lines) + "\n"


VIVI_HANDOFF_OPERATOR_GATE_TERMS = [
    "public",
    "production",
    "money",
    "credentials",
    "auth",
    "deletion",
    "external communication",
    "real client",
    "person data",
    "financial-advice",
    "room16 rerun",
    "room16 push",
    "room16 publish",
]

VIVI_HANDOFF_REVIEW_TERMS = [
    "codex review",
    "codex-side",
    "escalation",
    "handoff",
    "needs_vega_review",
    "needs vega review",
    "vega review",
    "supervisor",
    "blocked_by_supervisor",
]

VIVI_HANDOFF_VERIFIER_TERMS = [
    "verify",
    "verifier",
    "verification",
    "vivi report quality",
    "vqg",
    "full-check",
    "quality gate",
]


def parse_markdown_cards(content: str, source_path: Path, source_kind: str, *, max_cards: int = 80) -> list[dict[str, Any]]:
    cards: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None
    current_key: str | None = None
    for raw_line in content.splitlines():
        line = raw_line.rstrip()
        heading = re.match(r"^###\s+(.+?)\s*$", line)
        if heading:
            if current:
                cards.append(current)
            card_id = heading.group(1).strip()
            current = {
                "item_id": card_id,
                "source_path": str(source_path),
                "source_kind": source_kind,
                "fields": {},
                "raw_excerpt": [line],
            }
            current_key = None
            if len(cards) >= max_cards:
                break
            continue
        if not current:
            continue
        if len(current["raw_excerpt"]) < 28:
            current["raw_excerpt"].append(line)
        field = re.match(r"^-\s+([^:]{1,60}):\s*(.*)$", line)
        if field:
            current_key = field.group(1).strip().lower().replace(" ", "_")
            current["fields"][current_key] = field.group(2).strip()
            continue
        if current_key and line.startswith(">"):
            prior = current["fields"].get(current_key, "")
            current["fields"][current_key] = (prior + " " + line.lstrip("> ").strip()).strip()
    if current and len(cards) < max_cards:
        cards.append(current)
    return cards[-max_cards:]


def classify_vivi_handoff_item(card: dict[str, Any]) -> dict[str, Any]:
    fields = card.get("fields", {})
    text = " ".join([
        str(card.get("item_id", "")),
        str(card.get("source_kind", "")),
        json.dumps(fields, ensure_ascii=False),
        " ".join(card.get("raw_excerpt", [])),
    ]).lower()
    action_text = " ".join([
        str(card.get("item_id", "")),
        str(fields.get("title", "")),
        str(fields.get("summary", "")),
        str(fields.get("desired_outcome", "")),
        str(fields.get("raw_request", "")),
        str(fields.get("context", "")),
        str(fields.get("reference", "")),
    ]).lower()
    status_text = str(fields.get("status", "") or fields.get("state", "") or "").lower()
    kind_text = str(fields.get("kind", "") or card.get("source_kind", "")).lower()
    title = fields.get("title", card.get("item_id", ""))
    summary = fields.get("summary") or fields.get("outcome") or fields.get("detail") or ""
    command_ref = fields.get("command_ref") or fields.get("reference") or fields.get("task_id") or ""

    operator_gate_hits = [term for term in VIVI_HANDOFF_OPERATOR_GATE_TERMS if term in action_text]
    if "room16" in action_text and any(term in action_text for term in ["rerun", "push", "publish"]):
        operator_gate_hits.append("room16 rerun/push/publish")
    needs_review = any(term in text for term in VIVI_HANDOFF_REVIEW_TERMS)
    needs_verifier = any(term in text for term in VIVI_HANDOFF_VERIFIER_TERMS)
    queued_or_open = status_text in {"queued", "open", "ready", "pending"} or "queued" in status_text
    completed = status_text in {"reported", "answered", "completed", "closed"} or "completed" in status_text

    if card.get("source_kind") in {"vivi_reports", "handoff_next_chat"} and not queued_or_open:
        classification = "recorded_history"
        next_safe_step = "No immediate action; keep as execution history and regression evidence."
    elif completed:
        classification = "recorded_history"
        next_safe_step = "No immediate action; keep as execution history and regression evidence."
    elif operator_gate_hits:
        classification = "needs_operator_gate"
        next_safe_step = "Stop before action; ask the operator or require durable operator evidence before execution."
    elif needs_review or "codex-inbox" in kind_text:
        classification = "needs_vega_review"
        next_safe_step = "Vega reads the referenced evidence, runs the relevant verifier, then integrates or writes a bounded fix contract."
    elif needs_verifier:
        classification = "needs_verifier"
        next_safe_step = "Run the listed deterministic verifier before accepting the item as complete."
    elif queued_or_open:
        classification = "candidate_only"
        next_safe_step = "Keep visible as queued work; do not execute without a current contract or claim."
    else:
        classification = "candidate_only"
        next_safe_step = "Review manually if this becomes the current safe work item."

    recommended_verifiers = []
    if "vivi" in text or "lioncom" in text or "codex-inbox" in kind_text:
        recommended_verifiers.append("LIONCOM: npm run verify:control-plane-v2:static")
    if needs_verifier:
        recommended_verifiers.append("project-specific verifier named in the item")
    if "full-check" in text or "pig" in text:
        recommended_verifiers.append("python3 scripts/project_intelligence_graph/pig.py full-check")

    return {
        "item_id": card.get("item_id"),
        "source_path": card.get("source_path"),
        "source_kind": card.get("source_kind"),
        "classification": classification,
        "title": title,
        "summary": summary,
        "command_ref": command_ref,
        "status": fields.get("status", fields.get("state", "")),
        "operator_gate_required": classification == "needs_operator_gate",
        "operator_gate_terms": operator_gate_hits,
        "recommended_verifiers": sorted(set(recommended_verifiers)),
        "next_safe_step": next_safe_step,
        "raw_excerpt": card.get("raw_excerpt", [])[:14],
    }


def load_vivi_handoff_state() -> dict[str, Any]:
    payload = load_json(VIVI_VEGA_HANDOFF_STATE_PATH, default={})
    if not isinstance(payload, dict):
        return {"schema_version": 1, "items": {}}
    payload.setdefault("schema_version", 1)
    payload.setdefault("items", {})
    if not isinstance(payload["items"], dict):
        payload["items"] = {}
    return payload


def apply_vivi_handoff_state(item: dict[str, Any], state_payload: dict[str, Any]) -> dict[str, Any]:
    item_id = str(item.get("item_id", ""))
    state = state_payload.get("items", {}).get(item_id)
    if not isinstance(state, dict):
        return item
    lifecycle_state = state.get("state", "open")
    item = dict(item)
    item["vega_lifecycle_state"] = lifecycle_state
    item["vega_lifecycle_note"] = state.get("note", "")
    item["vega_lifecycle_updated_at"] = state.get("updated_at", "")
    item["vega_lifecycle_verifier"] = state.get("verifier", "")
    if lifecycle_state in {"verified", "closed", "recorded_history"}:
        item["original_classification"] = item.get("classification")
        item["classification"] = "recorded_history"
        item["operator_gate_required"] = False
        item["next_safe_step"] = "No immediate action; Vega lifecycle state marks this item as reviewed history."
    elif lifecycle_state == "operator_gated":
        item["classification"] = "needs_operator_gate"
        item["operator_gate_required"] = True
        item["next_safe_step"] = "Stop before action; Vega lifecycle state marks this item as operator-gated."
    elif lifecycle_state == "in_review":
        item["classification"] = "needs_vega_review"
        item["operator_gate_required"] = False
        item["next_safe_step"] = "Continue Vega review, run the listed verifier, then mark verified/closed or operator_gated."
    return item


def update_vivi_handoff_state(item_id: str, state: str, note: str = "", verifier: str = "") -> dict[str, Any]:
    payload = load_vivi_handoff_state()
    updated_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    payload["items"][item_id] = {
        "state": state,
        "note": note,
        "verifier": verifier,
        "updated_at": updated_at,
    }
    write_json(VIVI_VEGA_HANDOFF_STATE_PATH, payload)
    return {
        "item_id": item_id,
        "state": state,
        "note": note,
        "verifier": verifier,
        "updated_at": updated_at,
        "state_path": str(VIVI_VEGA_HANDOFF_STATE_PATH),
    }


def collect_vivi_handoff_sources() -> list[dict[str, Any]]:
    lioncom = Path("/Users/BjornRosinger/Documents/DreamFactory/LIONCOM")
    sources = [
        ("vivi_reports", lioncom / "VIVI_REPORTS.md"),
        ("codex_inbox", lioncom / "CODEX_INBOX.md"),
        ("task_claims", lioncom / "TASK_CLAIMS.md"),
        ("vivi_command_queue", lioncom / "VIVI_COMMAND_QUEUE.md"),
        ("handoff_next_chat", lioncom / "HANDOFF_NEXT_CHAT.md"),
        ("autonomy_state", lioncom / "AUTONOMY_STATE.json"),
        ("runtime_status", lioncom / ".runtime/local-duo-loop-status.json"),
    ]
    result = []
    for source_kind, path in sources:
        result.append({
            "source_kind": source_kind,
            "path": str(path),
            "exists": path.exists(),
            "readable": path.exists() and path.is_file(),
        })
    return result


def build_vivi_vega_handoff_inbox(*, write: bool = True) -> dict[str, Any]:
    generated_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    source_records = collect_vivi_handoff_sources()
    state_payload = load_vivi_handoff_state()
    items: list[dict[str, Any]] = []
    failures: list[str] = []
    for source in source_records:
        path = Path(source["path"])
        if not source["readable"]:
            continue
        try:
            if path.suffix == ".json":
                payload = load_json(path, default={})
                cards = []
                if isinstance(payload, dict):
                    for claim in payload.get("activeClaims", [])[:20]:
                        cards.append({
                            "item_id": str(claim.get("id", "active-claim")),
                            "source_path": str(path),
                            "source_kind": source["source_kind"],
                            "fields": {
                                "status": str(claim.get("claimState", claim.get("state", ""))),
                                "title": str(claim.get("title", "")),
                                "summary": str(claim.get("reason", "")),
                                "reference": str(claim.get("reference", "")),
                                "task_id": str(claim.get("taskId", "")),
                            },
                            "raw_excerpt": [json.dumps(claim, ensure_ascii=False)[:1200]],
                        })
                    if payload.get("codexLoop"):
                        loop = payload["codexLoop"]
                        cards.append({
                            "item_id": "autonomy_state_codex_loop",
                            "source_path": str(path),
                            "source_kind": source["source_kind"],
                            "fields": {
                                "status": str(loop.get("state", "")),
                                "title": str(loop.get("selectedTask", {}).get("title", "Codex loop")),
                                "summary": str(loop.get("summary", "")),
                                "reference": str(loop.get("selectedTask", {}).get("id", "")),
                            },
                            "raw_excerpt": [json.dumps(loop, ensure_ascii=False)[:1200]],
                        })
                items.extend(apply_vivi_handoff_state(classify_vivi_handoff_item(card), state_payload) for card in cards)
            else:
                content = path.read_text(encoding="utf-8", errors="replace")
                cards = parse_markdown_cards(content, path, source["source_kind"])
                items.extend(apply_vivi_handoff_state(classify_vivi_handoff_item(card), state_payload) for card in cards)
        except Exception as exc:
            failures.append(f"{path}: {exc}")

    action_items = [
        item for item in items
        if item.get("classification") in {"needs_operator_gate", "needs_vega_review", "needs_verifier"}
    ]
    needs_vega_review = [item for item in items if item.get("classification") == "needs_vega_review"]
    operator_gate_items = [item for item in items if item.get("classification") == "needs_operator_gate"]
    verifier_items = [item for item in items if item.get("classification") == "needs_verifier"]
    if failures:
        status = "FAIL"
    elif not any(source["exists"] for source in source_records):
        status = "WARN"
    else:
        status = "PASS"
    payload = {
        "schema_version": 1,
        "generated_at": generated_at,
        "status": status,
        "source_count": len([source for source in source_records if source["exists"]]),
        "sources": source_records,
        "item_count": len(items),
        "action_item_count": len(action_items),
        "needs_vega_review_count": len(needs_vega_review),
        "operator_gate_count": len(operator_gate_items),
        "needs_verifier_count": len(verifier_items),
        "state_path": str(VIVI_VEGA_HANDOFF_STATE_PATH),
        "state_item_count": len(state_payload.get("items", {})),
        "items": items[-120:],
        "action_items": action_items[-40:],
        "failures": failures,
        "safe_next_steps": [
            "If action_items is non-empty, Vega should process the oldest concrete needs_vega_review or needs_verifier item first.",
            "Operator-gated items remain visible but must not be executed without explicit Operator-Go.",
            "Completed Vivi/Codex items remain execution history; they are evidence, not fresh work.",
        ],
        "forbidden_without_operator_go": [
            "Public",
            "Production",
            "money",
            "credentials",
            "auth",
            "deletion",
            "external communication",
            "real client/person data",
            "financial-advice publishing",
            "Room16 rerun/push/publish",
        ],
    }
    if write:
        write_json(VIVI_VEGA_HANDOFF_INBOX_PATH, payload)
        (OUTPUT_DIR / "vivi_vega_handoff_inbox.md").write_text(vivi_vega_handoff_inbox_to_markdown(payload), encoding="utf-8")
    return payload


def vivi_vega_handoff_inbox_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Vivi -> Vega Handoff Inbox",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Sources: `{payload.get('source_count', 0)}`",
        f"- Items: `{payload.get('item_count', 0)}`",
        f"- Action items: `{payload.get('action_item_count', 0)}`",
        f"- Needs Vega review: `{payload.get('needs_vega_review_count', 0)}`",
        f"- Operator gates: `{payload.get('operator_gate_count', 0)}`",
        f"- Needs verifier: `{payload.get('needs_verifier_count', 0)}`",
        f"- Lifecycle states: `{payload.get('state_item_count', 0)}`",
        "",
        "## Action Items",
        "",
    ]
    for item in payload.get("action_items", [])[-30:]:
        gate = "operator gate" if item.get("operator_gate_required") else "local"
        lines.append(f"- `{item.get('classification')}` `{item.get('item_id')}` ({gate})")
        lines.append(f"  - source: `{item.get('source_kind')}` `{item.get('source_path')}`")
        if item.get("title"):
            lines.append(f"  - title: {item.get('title')}")
        if item.get("command_ref"):
            lines.append(f"  - reference: `{item.get('command_ref')}`")
        if item.get("vega_lifecycle_state"):
            lines.append(f"  - lifecycle: `{item.get('vega_lifecycle_state')}` {item.get('vega_lifecycle_note')}")
        lines.append(f"  - next: {item.get('next_safe_step')}")
        if item.get("recommended_verifiers"):
            lines.append(f"  - verifiers: `{record_value(item.get('recommended_verifiers'))}`")
    lines.extend(["", "## Sources", ""])
    for source in payload.get("sources", []):
        lines.append(f"- `{source.get('source_kind')}` exists=`{source.get('exists')}` path=`{source.get('path')}`")
    lines.extend(["", "## Safe Next Steps", ""])
    for step in payload.get("safe_next_steps", []):
        lines.append(f"- {step}")
    if payload.get("failures"):
        lines.extend(["", "## Failures", ""])
        for failure in payload.get("failures", []):
            lines.append(f"- {failure}")
    return "\n".join(lines) + "\n"


def build_autonomy_dirt_backlog_scan(*, write: bool = True, run_verifiers: bool = False) -> dict[str, Any]:
    generated_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    projects = [
        {
            "project_id": "project_intelligence_graph",
            "path": WORKSPACE,
            "role": "central PIG, Quality OS and agent-control contracts",
            "verifiers": [
                "python3 scripts/project_intelligence_graph/pig.py autonomy-governor --json",
                "python3 scripts/project_intelligence_graph/pig.py operator-brief --json",
                "python3 scripts/project_intelligence_graph/pig.py full-check --json",
            ],
        },
        {
            "project_id": "lioncom",
            "path": Path("/Users/BjornRosinger/Documents/DreamFactory/LIONCOM/mission-control-board"),
            "role": "operator control surface",
            "verifiers": [
                "npm run verify:control-plane-v2:static",
                "npm run build",
            ],
        },
        {
            "project_id": "room16",
            "path": WORKSPACE / "company-dossier-lab",
            "role": "Room16 dossier/report system",
            "verifiers": [
                "npm run verify:german-output-quality",
            ],
        },
        {
            "project_id": "kanzlei_ai_assist",
            "path": WORKSPACE / "kanzlei-ai-assist",
            "role": "deterministic Kanzlei assist system",
            "verifiers": [
                "python3 scripts/verify/verify_all.py",
            ],
        },
        {
            "project_id": "agent_ops",
            "path": Path("/Users/BjornRosinger/Documents/New project 2"),
            "role": "agent operations and cross-project workflow artifacts",
            "verifiers": [
                "python3 scripts/project_intelligence_graph/pig.py skill-policy-audit --json",
                "python3 scripts/project_intelligence_graph/pig.py rule-propagation --json",
            ],
        },
    ]
    project_items: list[dict[str, Any]] = []
    verifier_plan: list[dict[str, Any]] = []
    safe_next_actions: list[str] = []
    gated_items: list[dict[str, Any]] = []
    for project in projects:
        path = project["path"]
        dirt = git_dirt_for_project(path, str(project["project_id"]))
        dirt.update({
            "project_id": project["project_id"],
            "role": project["role"],
        })
        project_items.append(dirt)
        if dirt["git_status"] in {"dirty", "missing", "not_git_repo"}:
            safe_next_actions.append(f"{project['project_id']}: {dirt['safe_next_action']}")
        for command in project["verifiers"]:
            verifier_plan.append({
                "project_id": project["project_id"],
                "command": command,
                "status": "planned",
            })
    operator_gates = [
        "Public",
        "Production",
        "money",
        "credentials",
        "auth",
        "deletion",
        "external communication",
        "real client/person data",
        "financial-advice publishing",
        "Room16 rerun/push/publish",
    ]
    if run_verifiers:
        runnable = {
            ("project_intelligence_graph", "python3 scripts/project_intelligence_graph/pig.py autonomy-governor --json"): ([sys.executable, "scripts/project_intelligence_graph/pig.py", "autonomy-governor", "--json"], WORKSPACE),
            ("project_intelligence_graph", "python3 scripts/project_intelligence_graph/pig.py operator-brief --json"): ([sys.executable, "scripts/project_intelligence_graph/pig.py", "operator-brief", "--json"], WORKSPACE),
            ("project_intelligence_graph", "python3 scripts/project_intelligence_graph/pig.py full-check --json"): ([sys.executable, "scripts/project_intelligence_graph/pig.py", "full-check", "--json"], WORKSPACE),
            ("lioncom", "npm run verify:control-plane-v2:static"): ([sys.executable, "-c", "import subprocess; raise SystemExit(subprocess.call(['npm','run','verify:control-plane-v2:static']))"], None),
            ("lioncom", "npm run build"): ([sys.executable, "-c", "import subprocess; raise SystemExit(subprocess.call(['npm','run','build']))"], None),
            ("room16", "npm run verify:german-output-quality"): ([sys.executable, "-c", "import subprocess; raise SystemExit(subprocess.call(['npm','run','verify:german-output-quality']))"], WORKSPACE / "company-dossier-lab" / "room16-app"),
            ("kanzlei_ai_assist", "python3 scripts/verify/verify_all.py"): ([sys.executable, "scripts/verify/verify_all.py"], None),
            ("agent_ops", "python3 scripts/project_intelligence_graph/pig.py skill-policy-audit --json"): ([sys.executable, "scripts/project_intelligence_graph/pig.py", "skill-policy-audit", "--json"], WORKSPACE),
            ("agent_ops", "python3 scripts/project_intelligence_graph/pig.py rule-propagation --json"): ([sys.executable, "scripts/project_intelligence_graph/pig.py", "rule-propagation", "--json"], WORKSPACE),
        }
        project_paths = {project["project_id"]: project["path"] for project in projects}
        for verifier in verifier_plan:
            key = (verifier["project_id"], verifier["command"])
            if key not in runnable:
                continue
            command, cwd_override = runnable[key]
            cwd = cwd_override or project_paths[verifier["project_id"]]
            if not cwd.exists():
                verifier["status"] = "blocked_missing_path"
                continue
            result = run_local_command(command, cwd)
            verifier.update({
                "status": result["status"],
                "returncode": result["returncode"],
                "cwd": result["cwd"],
                "stdout_tail": result["stdout_tail"],
                "stderr_tail": result["stderr_tail"],
                "verifier_evidence_source": "current_run",
            })
    else:
        previous_payload = load_json(AUTONOMY_DIRT_BACKLOG_SCAN_PATH, default={})
        previous_verifiers = {
            (item.get("project_id"), item.get("command")): item
            for item in previous_payload.get("verifier_plan", [])
            if item.get("status") in {"PASS", "FAIL"}
        }
        for verifier in verifier_plan:
            previous = previous_verifiers.get((verifier.get("project_id"), verifier.get("command")))
            if not previous:
                continue
            for key in ("status", "returncode", "cwd", "stdout_tail", "stderr_tail", "started_at"):
                if key in previous:
                    verifier[key] = previous[key]
            verifier["verifier_evidence_source"] = "previous_run"
            if previous_payload.get("generated_at"):
                verifier["verifier_evidence_generated_at"] = previous_payload["generated_at"]
    dirty_count = sum(1 for item in project_items if item.get("git_status") == "dirty")
    missing_count = sum(1 for item in project_items if item.get("git_status") == "missing")
    verifier_fail_count = sum(1 for item in verifier_plan if item.get("status") == "FAIL")
    verifier_pass_count = sum(1 for item in verifier_plan if item.get("status") == "PASS")
    verifier_executed_count = sum(1 for item in verifier_plan if item.get("status") in {"PASS", "FAIL"})
    verifier_planned_count = sum(1 for item in verifier_plan if item.get("status") == "planned")
    handoff_cards = [
        card
        for item in project_items
        for card in item.get("handoff_cards", [])
    ]
    handoff_decision_queue = build_dirt_decision_queues(handoff_cards)
    if missing_count or verifier_fail_count:
        status = "WARN"
    elif dirty_count:
        status = "WARN"
    else:
        status = "PASS"
    if not safe_next_actions:
        safe_next_actions.append("No local dirt/backlog signal found; derive the next large block from the current operator intent.")
    payload = {
        "schema_version": 1,
        "generated_at": generated_at,
        "status": status,
        "projects_checked": len(project_items),
        "dirty_project_count": dirty_count,
        "missing_project_count": missing_count,
        "gated_item_count": len(gated_items),
        "verifier_executed_count": verifier_executed_count,
        "verifier_pass_count": verifier_pass_count,
        "verifier_fail_count": verifier_fail_count,
        "verifier_planned_count": verifier_planned_count,
        "projects": project_items,
        "handoff_cards": handoff_cards,
        "handoff_card_count": len(handoff_cards),
        "handoff_decision_queue": handoff_decision_queue,
        "verifier_plan": verifier_plan,
        "operator_gates": operator_gates,
        "gated_items": gated_items,
        "safe_next_actions": safe_next_actions,
        "notes": [
            "Dirty working trees are WARN, not FAIL; they require classification before cleanup, commit or push.",
            "This scan is intentionally local and reversible. It does not run Public, Production, Room16 rerun, external communication, credential or money actions.",
            "Use --run-verifiers only for deterministic local project verifiers listed here.",
        ],
    }
    if write:
        write_json(AUTONOMY_DIRT_BACKLOG_SCAN_PATH, payload)
        (OUTPUT_DIR / "autonomy_dirt_backlog_scan.md").write_text(autonomy_dirt_backlog_scan_to_markdown(payload), encoding="utf-8")
    return payload


FORBIDDEN_COMMIT_CLEANUP_ACTIONS = [
    "cleanup",
    "commit",
    "push",
    "delete",
    "publish",
    "move gated artifacts",
    "normalize source evidence",
    "run Public/Production actions",
]


def commit_cleanup_go_package_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Commit / Cleanup Operator-Go Package",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Package ID: `{payload.get('package_id', '')}`",
        f"- Runtime action executed: `{payload.get('runtime_action_executed', False)}`",
        f"- Projects: `{payload.get('summary', {}).get('project_count', 0)}`",
        f"- Dirty projects: `{payload.get('summary', {}).get('dirty_project_count', 0)}`",
        f"- Decision cards: `{payload.get('summary', {}).get('decision_card_count', 0)}`",
        f"- Reviewed local slices: `{payload.get('summary', {}).get('reviewed_queue_count', 0)}`",
        f"- Safe review slices: `{payload.get('summary', {}).get('safe_queue_count', 0)}`",
        f"- Operator-gated slices: `{payload.get('summary', {}).get('operator_gate_queue_count', 0)}`",
        "",
        "## Operator Decisions",
        "",
    ]
    for decision in payload.get("decision_cards", []):
        lines.append(f"- `{decision.get('decision_id', '')}` `{decision.get('status', 'UNKNOWN')}` `{decision.get('project_id', '')}`")
        lines.append(f"  - type: `{decision.get('decision_type', '')}`")
        lines.append(f"  - slice: `{decision.get('ownership', '')}` count=`{decision.get('count', 0)}`")
        lines.append(f"  - recommended: {decision.get('recommended_operator_decision', '')}")
        lines.append(f"  - next: {decision.get('next_safe_step', '')}")
    lines.extend(["", "## Project Packages", ""])
    for project in payload.get("project_packages", []):
        lines.append(f"- `{project.get('project_id', '')}` status=`{project.get('git_status', '')}` changed=`{project.get('changed_count', 0)}`")
        lines.append(f"  - path: `{project.get('path', '')}`")
        lines.append(f"  - suggested batches: `{record_value(project.get('suggested_batches', []))}`")
    lines.extend(["", "## Forbidden Without Operator-Go", ""])
    for action in payload.get("forbidden_without_operator_go", []):
        lines.append(f"- {action}")
    lines.extend(["", "## Verifiers", ""])
    for verifier in payload.get("verifiers", []):
        lines.append(f"- `{verifier}`")
    lines.extend(["", "## Next Safe Step", "", f"- {payload.get('next_safe_step', '')}"])
    return "\n".join(lines) + "\n"


def build_commit_cleanup_go_package(*, write: bool = True) -> dict[str, Any]:
    generated_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    dirt = build_autonomy_dirt_backlog_scan(write=True, run_verifiers=False)
    queue = dirt.get("handoff_decision_queue", {}) if isinstance(dirt.get("handoff_decision_queue"), dict) else {}
    decision_sources = []
    for bucket in ["reviewed_queue", "safe_work_queue", "operator_gate_queue"]:
        decision_sources.extend(queue.get(bucket, []) if isinstance(queue.get(bucket), list) else [])

    project_packages: list[dict[str, Any]] = []
    for project in dirt.get("projects", []):
        if not isinstance(project, dict):
            continue
        project_id = str(project.get("project_id", "unknown"))
        project_decisions = [item for item in decision_sources if item.get("project_id") == project_id]
        suggested_batches = []
        ownership_counts = project.get("ownership_counts", {}) if isinstance(project.get("ownership_counts"), dict) else {}
        for ownership, count in ownership_counts.items():
            matching = [item for item in project_decisions if item.get("ownership") == ownership]
            if not matching and not count:
                continue
            batch_status = "operator_go_required"
            if matching and all(item.get("status") == "reviewed_local_pending_commit_or_cleanup_gate" for item in matching):
                batch_status = "reviewed_local_waiting_for_operator_go"
            if ownership == "gated_runtime_or_source_artifact":
                batch_status = "operator_gated"
            suggested_batches.append({
                "batch_id": f"{project_id}:{ownership}:batch",
                "ownership": ownership,
                "count": int(count or 0),
                "status": batch_status,
                "decision_ids": [item.get("queue_id", "") for item in matching],
                "operator_go_required": True,
            })
        project_packages.append({
            "project_id": project_id,
            "path": project.get("path", ""),
            "role": project.get("role", ""),
            "git_status": project.get("git_status", "UNKNOWN"),
            "changed_count": project.get("changed_count", 0),
            "modified_count": project.get("modified_count", 0),
            "untracked_count": project.get("untracked_count", 0),
            "ownership_counts": ownership_counts,
            "sample": project.get("sample", [])[:12],
            "reviewed_decision_ids": [
                item.get("queue_id", "")
                for item in project_decisions
                if item.get("status") == "reviewed_local_pending_commit_or_cleanup_gate"
            ],
            "safe_review_decision_ids": [
                item.get("queue_id", "")
                for item in project_decisions
                if item.get("status") == "ready_for_local_review"
            ],
            "operator_gate_decision_ids": [
                item.get("queue_id", "")
                for item in project_decisions
                if item.get("operator_gate_required")
            ],
            "suggested_batches": suggested_batches,
        })

    decision_cards = []
    for item in decision_sources:
        if not isinstance(item, dict):
            continue
        if item.get("status") == "reviewed_local_pending_commit_or_cleanup_gate":
            recommended = "Operator kann später entscheiden: committen, lokal behalten, archivieren/ignorieren oder kleiner paketieren."
        elif item.get("operator_gate_required"):
            recommended = "Stopp. Nur mit explizitem Operator-Go anfassen."
        else:
            recommended = "Erst lokal prüfen und Verifier laufen lassen; noch kein Commit-/Cleanup-Go."
        decision_cards.append({
            "decision_id": item.get("queue_id", ""),
            "project_id": item.get("project_id", ""),
            "ownership": item.get("ownership", ""),
            "decision_type": item.get("decision_type", ""),
            "priority": item.get("priority", ""),
            "status": item.get("status", "UNKNOWN"),
            "count": item.get("count", 0),
            "operator_gate_required": True,
            "recommended_operator_decision": recommended,
            "sample_paths": item.get("sample_paths", [])[:8],
            "recommended_verifiers": item.get("recommended_verifiers", []),
            "evidence_required": item.get("evidence_required", []),
            "next_safe_step": item.get("safe_review_step", ""),
            "forbidden_without_operator_go": item.get("forbidden_without_operator_go", FORBIDDEN_COMMIT_CLEANUP_ACTIONS),
        })

    reviewed_count = int(queue.get("reviewed_queue_count") or 0)
    safe_count = int(queue.get("safe_queue_count") or 0)
    gate_count = int(queue.get("operator_gate_queue_count") or 0)
    dirty_count = int(dirt.get("dirty_project_count") or 0)
    if dirty_count == 0:
        status = "closed_no_action"
        next_safe_step = "Kein lokales Dirt-Paket offen; keine Commit-/Cleanup-Entscheidung nötig."
    elif safe_count:
        status = "needs_local_review"
        next_safe_step = "Zuerst safe_review_decision_ids lokal prüfen und Verifier belegen; danach erst Operator-Go-Paket finalisieren."
    elif reviewed_count or gate_count:
        status = "operator_go_required"
        next_safe_step = "Operator-Go einholen, bevor Commit, Cleanup, Push, Delete, Publish oder gated Artifact Handling passiert."
    else:
        status = "blocked_by_missing_evidence"
        next_safe_step = "Dirt-Scan prüfen; es gibt Dirt ohne verwertbare Entscheidungskarten."

    payload = {
        "schema_version": 1,
        "generated_at": generated_at,
        "package_id": f"commit-cleanup-go-{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')}",
        "status": status,
        "purpose": "Bereitet Commit-/Cleanup-/Dirt-Entscheidungen für den Operator vor, ohne sie auszuführen.",
        "runtime_action_executed": False,
        "summary": {
            "project_count": len(project_packages),
            "dirty_project_count": dirty_count,
            "decision_card_count": len(decision_cards),
            "reviewed_queue_count": reviewed_count,
            "safe_queue_count": safe_count,
            "operator_gate_queue_count": gate_count,
            "dirt_queue_status": queue.get("status", "UNKNOWN"),
        },
        "allowed_operator_decisions": [
            "commit_reviewed_local_changes",
            "keep_generated_evidence_local",
            "archive_or_ignore_generated_evidence",
            "defer",
            "request_smaller_package",
        ],
        "forbidden_without_operator_go": FORBIDDEN_COMMIT_CLEANUP_ACTIONS,
        "project_packages": project_packages,
        "decision_cards": decision_cards,
        "verifiers": [
            "python3 scripts/project_intelligence_graph/pig.py autonomy-dirt-scan",
            "python3 scripts/project_intelligence_graph/pig.py commit-cleanup-package",
            "python3 scripts/project_intelligence_graph/pig.py operator-brief",
            "python3 scripts/project_intelligence_graph/pig.py full-check",
        ],
        "evidence": [
            str(AUTONOMY_DIRT_BACKLOG_SCAN_PATH),
            str(AUTONOMY_DIRT_DECISION_STATE_PATH),
            "runtime_action_executed=False",
            "no git commit/cleanup/push/delete executed by this package",
        ],
        "next_safe_step": next_safe_step,
        "notes": [
            "Dieses Paket ist eine Entscheidungsvorlage, keine Ausführungsschicht.",
            "Alle echten Git-/Cleanup-/Push-/Delete-/Publish-Aktionen bleiben Operator-Gates.",
            "Reviewed local bedeutet: lokal geprüft, aber noch nicht automatisch commitfähig.",
        ],
    }
    if write:
        write_json(COMMIT_CLEANUP_GO_PACKAGE_PATH, payload)
        (OUTPUT_DIR / "commit_cleanup_go_package.md").write_text(commit_cleanup_go_package_to_markdown(payload), encoding="utf-8")
    return payload


def build_german_output_quality_audit(*, write: bool = True) -> dict[str, Any]:
    registry = load_json(GERMAN_OUTPUT_QUALITY_REGISTRY_PATH, default={})
    targets = registry.get("targets", []) if isinstance(registry, dict) else []
    registry_errors: list[str] = []
    if not isinstance(registry, dict):
        registry_errors.append("registry is not a JSON object")
    if not targets:
        registry_errors.append("registry has no targets")
    paths: list[str] = []
    verifiers: list[str] = []
    for target in targets if isinstance(targets, list) else []:
        if not isinstance(target, dict):
            registry_errors.append("target entry is not an object")
            continue
        target_id = str(target.get("target_id") or "unknown")
        for field in ["target_id", "project_id", "path", "output_kinds", "verifier", "status"]:
            if target.get(field) in (None, "", [], {}):
                registry_errors.append(f"{target_id} missing {field}")
        if target.get("path"):
            paths.append(str(target["path"]))
        if target.get("verifier"):
            verifiers.append(str(target["verifier"]))
    if paths:
        script = WORKSPACE / "scripts/project_intelligence_graph/german_output_quality_gate.py"
        completed = subprocess.run(
            [sys.executable, str(script), *paths, "--json-out", str(GERMAN_OUTPUT_QUALITY_AUDIT_PATH), "--md-out", str(OUTPUT_DIR / "german_output_quality_gate.md")],
            cwd=WORKSPACE,
            text=True,
            capture_output=True,
            check=False,
        )
        payload = load_json(GERMAN_OUTPUT_QUALITY_AUDIT_PATH, default={})
        payload["command_returncode"] = completed.returncode
        payload["stdout_tail"] = completed.stdout[-1000:]
        payload["stderr_tail"] = completed.stderr[-1000:]
    else:
        payload = {
            "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
            "status": "FAIL",
            "scanned_files": 0,
            "finding_count": 0,
            "fail_count": 0,
            "warn_count": 0,
            "items": [],
        }
    payload["registry_status"] = "FAIL" if registry_errors else "PASS"
    payload["registry_errors"] = registry_errors
    payload["targets_checked"] = len(targets) if isinstance(targets, list) else 0
    payload["verifiers"] = verifiers
    if registry_errors:
        payload["status"] = "FAIL"
    if write:
        write_json(GERMAN_OUTPUT_QUALITY_AUDIT_PATH, payload)
        lines = [
            "# German Output Quality Gate",
            "",
            f"- Status: `{payload.get('status', 'UNKNOWN')}`",
            f"- Registry: `{payload.get('registry_status', 'UNKNOWN')}`",
            f"- Targets checked: `{payload.get('targets_checked', 0)}`",
            f"- Scanned files: `{payload.get('scanned_files', 0)}`",
            f"- Findings: `{payload.get('finding_count', 0)}`",
            f"- Fail: `{payload.get('fail_count', 0)}`",
            f"- Warn: `{payload.get('warn_count', 0)}`",
            "",
            "## Verifiers",
            "",
        ]
        for verifier in verifiers:
            lines.append(f"- `{verifier}`")
        lines.extend(["", "## Findings", ""])
        for item in payload.get("items", [])[:80]:
            lines.append(f"- `{item.get('severity')}` `{item.get('issue_type')}` {item.get('path')}:{item.get('line')} `{item.get('token')}`")
        (OUTPUT_DIR / "german_output_quality_gate.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return payload


def fresh_data_sources() -> list[dict[str, Any]]:
    room16_runtime = WORKSPACE / "company-dossier-lab/.runtime/room16-app"
    lioncom_runtime = Path.home() / "Library/Application Support/LIONCOM/runtime-workspace"
    return [
        {
            "source_id": "room16_hardening_latest_cycle",
            "project_id": "room16",
            "artifact_kind": "hardening_cycle",
            "path": room16_runtime / "hardening/latest-cycle.json",
            "parser": "room16_hardening_json",
            "freshness_hours": 24,
            "expected": "latest local Room16 hardening cycle with build, verify and screenshot evidence",
        },
        {
            "source_id": "room16_verification_latest",
            "project_id": "room16",
            "artifact_kind": "verification_run",
            "path": room16_runtime / "verification/last-verification.json",
            "parser": "room16_verification_json",
            "freshness_hours": 24,
            "expected": "latest deterministic Room16 app verification summary",
        },
        {
            "source_id": "room16_public_library_status",
            "project_id": "room16",
            "artifact_kind": "public_library_status",
            "path": room16_runtime / "public-library/latest-library-status.md",
            "parser": "room16_library_markdown",
            "freshness_hours": 24,
            "expected": "latest Room16 public/member visibility gate summary",
        },
        {
            "source_id": "room16_review_gate_status",
            "project_id": "room16",
            "artifact_kind": "review_gate_status",
            "path": room16_runtime / "review-gate-status/latest-review-gate-status.json",
            "parser": "room16_review_gate_status_json",
            "freshness_hours": 24,
            "expected": "latest read-only Room16 manual-review and publish-gate status packet",
        },
        {
            "source_id": "room16_manual_review_packets",
            "project_id": "room16",
            "artifact_kind": "manual_review_packets",
            "path": room16_runtime / "manual-review-packets/latest-manual-review-packets.json",
            "parser": "room16_manual_review_packets_json",
            "freshness_hours": 24,
            "expected": "latest read-only Room16 manual-review packets with local file evidence and stop rules",
        },
        {
            "source_id": "lioncom_autonomy_state",
            "project_id": "lioncom",
            "artifact_kind": "autonomy_state",
            "path": lioncom_runtime / "AUTONOMY_STATE.json",
            "parser": "generic_json",
            "freshness_hours": 48,
            "expected": "current LIONCOM/Vivi autonomy state rail",
        },
        {
            "source_id": "lioncom_task_claims",
            "project_id": "lioncom",
            "artifact_kind": "task_claims",
            "path": lioncom_runtime / "TASK_CLAIMS.md",
            "parser": "generic_markdown",
            "freshness_hours": 48,
            "expected": "current LIONCOM/Vivi task claim rail",
        },
        {
            "source_id": "kanzlei_verifier_outputs",
            "project_id": "kanzlei_ai_assist",
            "artifact_kind": "verifier_output",
            "path": WORKSPACE / "kanzlei-ai-assist/outputs",
            "parser": "directory_probe",
            "freshness_hours": 168,
            "expected": "Kanzlei deterministic verifier or export-readiness outputs when present",
            "optional": True,
        },
        {
            "source_id": "utility_data_maturity_outputs",
            "project_id": "utility_websites",
            "artifact_kind": "data_maturity_output",
            "path": WORKSPACE / "outputs/utility_websites/data_maturity/latest-data-maturity-status.json",
            "parser": "utility_data_maturity_json",
            "freshness_hours": 168,
            "expected": "Utility GSC/Plausible/event data maturity outputs when present",
            "optional": True,
        },
    ]


def classify_fresh_data_item(source: dict[str, Any], path: Path, now: dt.datetime) -> dict[str, Any]:
    parser = str(source.get("parser", "generic"))
    modified_at = path_mtime_iso(path)
    age_hours = age_hours_from_iso(modified_at, now)
    freshness_hours = float(source.get("freshness_hours", 24))
    is_fresh = age_hours is not None and age_hours <= freshness_hours
    item: dict[str, Any] = {
        "item_id": f"{source['source_id']}:{stable_id(path.as_posix(), modified_at)}",
        "source_id": source["source_id"],
        "project_id": source["project_id"],
        "artifact_kind": source["artifact_kind"],
        "path": str(path),
        "modified_at": modified_at,
        "age_hours": age_hours,
        "freshness_hours": freshness_hours,
        "status": "fresh" if is_fresh else "stale",
        "signal_status": "unknown",
        "classification": "evidence_only",
        "priority": "P3",
        "summary": source.get("expected", ""),
        "next_safe_step": "Record as evidence; no runtime action needed.",
        "operator_gate_required": False,
        "runtime_action_executed": False,
    }
    try:
        if parser in {"room16_hardening_json", "room16_verification_json", "generic_json"}:
            payload = load_json(path, default={})
            if not isinstance(payload, dict):
                item.update({
                    "signal_status": "unreadable",
                    "classification": "needs_verifier",
                    "priority": "P1",
                    "summary": "JSON artifact is not an object.",
                    "next_safe_step": "Inspect the artifact structure before using it as evidence.",
                })
                return item
            verdict = str(payload.get("verdict") or payload.get("status") or "").lower()
            if parser == "room16_hardening_json":
                command_failures = [
                    command
                    for command in payload.get("commands", [])
                    if isinstance(command, dict) and command.get("exitCode") not in (0, None)
                ]
                item["summary"] = f"Room16 hardening cycle `{payload.get('cycleId', path.parent.name)}` verdict={verdict or 'unknown'} commands={len(payload.get('commands', []))} failures={len(command_failures)}."
                item["signal_status"] = "pass" if verdict == "pass" and not command_failures else ("fail" if command_failures or verdict in {"fail", "failed"} else "unknown")
                if item["signal_status"] == "pass":
                    item["next_safe_step"] = "Use as fresh Room16 build/verify evidence; do not rerun, publish or push from intake."
                else:
                    item.update({
                        "classification": "needs_verifier",
                        "priority": "P1",
                        "next_safe_step": "Run or inspect the Room16 local verifier; do not publish or rerun the report pipeline.",
                    })
            elif parser == "room16_verification_json":
                checks = payload.get("checks", [])
                failed_checks = [check for check in checks if isinstance(check, dict) and str(check.get("status", "")).lower() not in {"pass", "ok"}]
                item["summary"] = f"Room16 verification verdict={verdict or 'unknown'} companies={payload.get('companyCount', 0)} checks={len(checks)} failed={len(failed_checks)}."
                item["signal_status"] = "pass" if verdict == "pass" and not failed_checks else ("fail" if failed_checks or verdict in {"fail", "failed"} else "unknown")
                if item["signal_status"] == "pass":
                    item["next_safe_step"] = "Use as fresh Room16 verifier evidence; no Room16 rerun/push/publish from intake."
                else:
                    item.update({
                        "classification": "needs_verifier",
                        "priority": "P1",
                        "next_safe_step": "Inspect failed Room16 checks before any downstream work.",
                    })
            else:
                item["signal_status"] = "pass" if payload else "unknown"
                item["summary"] = f"Generic JSON runtime artifact with {len(payload.keys()) if isinstance(payload, dict) else 0} top-level keys."
        elif parser == "room16_review_gate_status_json":
            payload = load_json(path, default={})
            if not isinstance(payload, dict):
                item.update({
                    "signal_status": "unreadable",
                    "classification": "needs_verifier",
                    "priority": "P1",
                    "summary": "Room16 review-gate status JSON is not an object.",
                    "next_safe_step": "Run `cd company-dossier-lab/room16-app && npm run verify:review-gate-status` and inspect the generated packet.",
                })
                return item
            status_value = str(payload.get("status") or "UNKNOWN").upper()
            summary = payload.get("summary", {}) if isinstance(payload.get("summary"), dict) else {}
            manual_review_entries = payload.get("manual_review_entries", []) if isinstance(payload.get("manual_review_entries"), list) else []
            fail_count = int(payload.get("fail_count") or 0)
            warn_count = int(payload.get("warn_count") or 0)
            operator_gate_required = bool(payload.get("operator_gate_required"))
            item["metrics"] = {
                "status": status_value,
                "manual_review_entries": len(manual_review_entries),
                "fail_count": fail_count,
                "warn_count": warn_count,
                "public_ready": int(summary.get("public_ready") or 0),
                "member_ready": int(summary.get("member_ready") or 0),
                "effective_public": int(summary.get("effective_public") or 0),
                "hidden_by_gate": int(summary.get("hidden_by_gate") or 0),
            }
            item["manual_review_entries"] = manual_review_entries[:12]
            item["summary"] = (
                f"Room16 review-gate status={status_value} manual_review_entries={len(manual_review_entries)} "
                f"public_ready={item['metrics']['public_ready']} member_ready={item['metrics']['member_ready']} "
                f"effective_public={item['metrics']['effective_public']} hidden_by_gate={item['metrics']['hidden_by_gate']}."
            )
            if fail_count or status_value == "FAIL":
                item.update({
                    "signal_status": "fail",
                    "classification": "needs_verifier",
                    "priority": "P1",
                    "next_safe_step": "Repair Room16 review-gate status inconsistencies before using the library state as evidence.",
                })
            elif operator_gate_required:
                item.update({
                    "signal_status": "warn",
                    "classification": "operator_gate",
                    "priority": "P0",
                    "operator_gate_required": True,
                    "next_safe_step": "Prepare Room16 Go/No-Go evidence; do not change Public/Member visibility without Operator-Go.",
                })
            elif manual_review_entries:
                item.update({
                    "signal_status": "warn" if warn_count else "pass",
                    "classification": "needs_review",
                    "priority": "P2",
                    "next_safe_step": "Review Room16 manual-review entries locally as evidence; keep all publish gates closed.",
                })
            else:
                item.update({
                    "signal_status": "pass",
                    "classification": "evidence_only",
                    "next_safe_step": "Use Room16 review-gate packet as fresh evidence; no runtime action needed.",
                })
        elif parser == "room16_manual_review_packets_json":
            payload = load_json(path, default={})
            if not isinstance(payload, dict):
                item.update({
                    "signal_status": "unreadable",
                    "classification": "needs_verifier",
                    "priority": "P1",
                    "summary": "Room16 manual-review packet JSON is not an object.",
                    "next_safe_step": "Run `cd company-dossier-lab/room16-app && npm run verify:manual-review-packets` and inspect the generated packet.",
                })
                return item
            status_value = str(payload.get("status") or "UNKNOWN").upper()
            packet_count = int(payload.get("packet_count") or 0)
            missing_file_count = int(payload.get("missing_file_count") or 0)
            promotion_readiness_status = str(payload.get("promotion_readiness_status") or "unknown")
            item["metrics"] = {
                "status": status_value,
                "packet_count": packet_count,
                "missing_file_count": missing_file_count,
                "promotion_readiness_status": promotion_readiness_status,
            }
            item["summary"] = (
                f"Room16 manual-review packets status={status_value} packets={packet_count} "
                f"missing_files={missing_file_count} promotion_readiness={promotion_readiness_status}."
            )
            if status_value == "FAIL" or missing_file_count:
                item.update({
                    "signal_status": "fail",
                    "classification": "needs_verifier",
                    "priority": "P1",
                    "next_safe_step": "Repair missing Room16 manual-review packet files before using packet evidence.",
                })
            else:
                item.update({
                    "signal_status": "warn" if packet_count else "pass",
                    "classification": "evidence_only",
                    "priority": "P3",
                    "next_safe_step": "Use manual-review packets as concrete Room16 review evidence; keep publish gates closed.",
                })
        elif parser == "utility_data_maturity_json":
            payload = load_json(path, default={})
            if not isinstance(payload, dict):
                item.update({
                    "signal_status": "unreadable",
                    "classification": "needs_verifier",
                    "priority": "P1",
                    "summary": "Utility data maturity JSON is not an object.",
                    "next_safe_step": "Run `python3 scripts/project_intelligence_graph/build_utility_data_maturity_status.py` and inspect the generated packet.",
                })
                return item
            maturity_status = str(payload.get("maturity_status") or "unknown")
            signal_status = str(payload.get("signal_status") or "unknown")
            active_lanes = payload.get("active_lanes", []) if isinstance(payload.get("active_lanes"), list) else []
            review_windows = payload.get("review_windows", []) if isinstance(payload.get("review_windows"), list) else []
            due_windows = [
                window for window in review_windows
                if isinstance(window, dict) and window.get("status") == "due_or_past"
            ]
            item["metrics"] = {
                "maturity_status": maturity_status,
                "signal_status": signal_status,
                "active_lane_count": len(active_lanes),
                "due_window_count": len(due_windows),
            }
            item["summary"] = (
                f"Utility data maturity={maturity_status} signal={signal_status} "
                f"active_lanes={len(active_lanes)} due_windows={len(due_windows)}."
            )
            if due_windows:
                item.update({
                    "signal_status": "warn",
                    "classification": "needs_review",
                    "priority": "P2",
                    "next_safe_step": "Run a local utility data maturity review; do not open monetization, public, production or provider gates automatically.",
                })
            else:
                item.update({
                    "signal_status": "warn" if maturity_status == "not_mature" else "pass",
                    "classification": "evidence_only",
                    "priority": "P3",
                    "next_safe_step": payload.get("next_safe_step", "Use as Utility Websites data maturity evidence."),
                })
        elif parser == "room16_library_markdown":
            text = path.read_text(encoding="utf-8", errors="replace")
            summary = room16_library_summary(text)
            item["metrics"] = summary
            item["summary"] = (
                f"Room16 library reports={summary.get('total_reports', 0)} public_ready={summary.get('public_ready', 0)} "
                f"member_ready={summary.get('member_ready', 0)} manual_review={summary.get('manual_review', 0)} "
                f"hidden_by_gate={summary.get('hidden_by_gate', 0)} effective_public={summary.get('effective_public', 0)}."
            )
            if summary.get("effective_public", 0) > 0:
                item.update({
                    "signal_status": "fail",
                    "classification": "operator_gate",
                    "priority": "P0",
                    "operator_gate_required": True,
                    "next_safe_step": "Stop and inspect public visibility; no publish or external action without Operator-Go.",
                })
            elif summary.get("public_ready", 0) > 0 or summary.get("member_ready", 0) > 0:
                item.update({
                    "signal_status": "warn",
                    "classification": "operator_gate",
                    "priority": "P0",
                    "operator_gate_required": True,
                    "next_safe_step": "Prepare Go/No-Go review package; do not publish or expose reports from intake.",
                })
            elif summary.get("manual_review", 0) > 0:
                item.update({
                    "signal_status": "pass",
                    "classification": "needs_review",
                    "priority": "P2",
                    "next_safe_step": "Review manual-review reports as a local evidence task; keep all publish gates closed.",
                })
            else:
                item["signal_status"] = "pass"
        elif parser == "directory_probe":
            files = [candidate for candidate in path.rglob("*") if candidate.is_file()] if path.is_dir() else []
            recent = sorted(files, key=lambda candidate: candidate.stat().st_mtime, reverse=True)[:5]
            item["signal_status"] = "pass" if recent else "unknown"
            item["summary"] = f"Directory probe found {len(files)} files; newest sample={', '.join(candidate.name for candidate in recent[:3]) or 'none'}."
            item["newest_files"] = [str(candidate) for candidate in recent]
            if not recent and not source.get("optional"):
                item.update({
                    "classification": "needs_review",
                    "priority": "P2",
                    "next_safe_step": "Register or create a deterministic project output before relying on this source.",
                })
        else:
            item["summary"] = f"Runtime artifact exists for parser `{parser}`."
            item["signal_status"] = "pass"
    except Exception as exc:
        item.update({
            "signal_status": "unreadable",
            "classification": "needs_verifier",
            "priority": "P1",
            "summary": f"Could not parse fresh data source: {exc}",
            "next_safe_step": "Inspect parser and artifact format before using this source.",
        })
    if item["status"] == "stale" and item["classification"] == "evidence_only":
        item["classification"] = "recorded_history"
        item["next_safe_step"] = "Keep as historical evidence; wait for fresh project data before deriving work."
    stable_identity = {
        "source_id": item.get("source_id", ""),
        "project_id": item.get("project_id", ""),
        "artifact_kind": item.get("artifact_kind", ""),
        "path": item.get("path", ""),
        "signal_status": item.get("signal_status", ""),
        "classification": item.get("classification", ""),
        "summary": item.get("summary", ""),
        "metrics": item.get("metrics", {}),
        "manual_review_entries": item.get("manual_review_entries", []),
        "operator_gate_required": item.get("operator_gate_required", False),
    }
    item["item_id"] = f"{source['source_id']}:{stable_id(json.dumps(stable_identity, sort_keys=True, ensure_ascii=False))}"
    return item


def build_fresh_data_intake(*, write: bool = True) -> dict[str, Any]:
    now = dt.datetime.now(dt.timezone.utc).replace(microsecond=0)
    items: list[dict[str, Any]] = []
    source_gaps: list[dict[str, Any]] = []
    for source in fresh_data_sources():
        path = Path(source["path"])
        if not path.exists():
            gap = {
                "source_id": source["source_id"],
                "project_id": source["project_id"],
                "artifact_kind": source["artifact_kind"],
                "path": str(path),
                "status": "optional_missing" if source.get("optional") else "missing",
                "expected": source.get("expected", ""),
            }
            source_gaps.append(gap)
            continue
        items.append(classify_fresh_data_item(source, path, now))
    has_room16_review_gate_packet = any(
        item.get("source_id") == "room16_review_gate_status" and item.get("signal_status") != "unreadable"
        for item in items
    )
    if has_room16_review_gate_packet:
        for item in items:
            if item.get("source_id") == "room16_public_library_status" and item.get("classification") == "needs_review":
                item.update({
                    "classification": "evidence_only",
                    "priority": "P3",
                    "next_safe_step": "Use as aggregate Room16 library evidence; detailed action lives in the review-gate status packet.",
                })
    action_items = [
        item
        for item in items
        if item.get("classification") in {"needs_review", "needs_verifier", "operator_gate", "blocked"}
    ]
    operator_gate_items = [item for item in items if item.get("operator_gate_required")]
    needs_review_items = [item for item in items if item.get("classification") == "needs_review"]
    needs_verifier_items = [item for item in items if item.get("classification") == "needs_verifier"]
    fail_items = [item for item in items if item.get("signal_status") in {"fail", "unreadable"}]
    fresh_items = [item for item in items if item.get("status") == "fresh"]
    missing_required = [gap for gap in source_gaps if gap.get("status") == "missing"]
    if fail_items:
        status = "FAIL"
    elif missing_required or operator_gate_items or needs_review_items or needs_verifier_items:
        status = "WARN"
    else:
        status = "PASS"
    payload = {
        "schema_version": 1,
        "generated_at": now.isoformat(),
        "status": status,
        "source_count": len(fresh_data_sources()),
        "item_count": len(items),
        "fresh_item_count": len(fresh_items),
        "action_item_count": len(action_items),
        "operator_gate_count": len(operator_gate_items),
        "needs_review_count": len(needs_review_items),
        "needs_verifier_count": len(needs_verifier_items),
        "missing_required_count": len(missing_required),
        "items": items,
        "action_items": action_items,
        "source_gaps": source_gaps,
        "next_safe_actions": [
            item.get("next_safe_step", "")
            for item in action_items[:8]
            if item.get("next_safe_step")
        ] or ["No fresh-data action item found; use fresh items as evidence only."],
        "operator_gates": [
            "Room16 rerun/push/publish",
            "Public or member visibility changes",
            "external communication",
            "production",
            "credentials/auth",
            "money",
            "real client/person data",
            "financial-advice publishing",
        ],
        "notes": [
            "Fresh Data Intake is read-only. It does not rerun Room16, publish reports, change visibility, create automations, contact providers or mutate project runtime state.",
            "Fresh local evidence can still be gated: a PASS verifier result does not imply publish permission.",
        ],
    }
    if write:
        write_json(FRESH_DATA_INTAKE_PATH, payload)
        (OUTPUT_DIR / "fresh_data_intake.md").write_text(fresh_data_intake_to_markdown(payload), encoding="utf-8")
    return payload


def job_card_from_fresh_data_item(item: dict[str, Any]) -> dict[str, Any]:
    project_id = str(item.get("project_id", "unknown"))
    source_id = str(item.get("source_id", "fresh-data"))
    classification = str(item.get("classification", "needs_review"))
    safe_id = safe_slug(f"fresh-data-{project_id}-{source_id}-{classification}")
    operator_gate = bool(item.get("operator_gate_required")) or classification == "operator_gate"
    status = "waiting_for_operator" if operator_gate else "ready"
    if classification == "needs_verifier":
        status = "waiting_for_evidence"
    if classification == "blocked":
        status = "failed_safe"
    if project_id == "room16":
        verifier = [
            "python3 scripts/project_intelligence_graph/pig.py fresh-data",
            "cd /Users/BjornRosinger/Documents/New project/company-dossier-lab/room16-app && npm run verify:review-gate-status",
            "cd /Users/BjornRosinger/Documents/New project/company-dossier-lab/room16-app && npm run verify:manual-review-packets",
            "cd /Users/BjornRosinger/Documents/New project/company-dossier-lab/room16-app && npm run verify:german-output-quality",
        ]
    else:
        verifier = [
            "python3 scripts/project_intelligence_graph/pig.py fresh-data",
            "python3 scripts/project_intelligence_graph/pig.py full-check",
        ]
    return {
        "schema_version": 1,
        "job_card_id": safe_id,
        "source": "fresh_data_intake",
        "source_item_id": item.get("item_id", ""),
        "project_id": project_id,
        "auftrag": f"Bearbeite Fresh-Data-Item `{source_id}` als kleinen sicheren Vivi-Claim.",
        "zielbild": (
            "Vega/PIG sieht einen geprüften lokalen Handoff mit Evidence, Verifier-Status, Stop-Grund und nächstem sicheren Schritt; "
            "der Operator muss keine Runtime-Ordner manuell durchsuchen."
        ),
        "input": [
            str(item.get("path", "")),
            str(FRESH_DATA_INTAKE_PATH),
            str(OUTPUT_DIR / "operator_brief.json"),
        ],
        "erlaubte_aktion": [
            "lokal lesen",
            "Evidence zusammenfassen",
            "nur erlaubte lokale Verifier ausführen",
            "Handoff als Kandidat an Vega/PIG übergeben",
        ],
        "verbotene_aktion": [
            "Room16 rerun/push/publish",
            "Public oder Member Visibility ändern",
            "Production, Geld, Credentials/Auth oder externe Kommunikation starten",
            "echte Mandanten-, Personen- oder Finanzpublishing-Daten finalisieren",
            "Dateien löschen oder Gates abschwächen",
        ],
        "output_vertrag": [
            "kurzer Handoff mit Status, Evidence, Verifier und Stop-Regel",
            "keine Runtime-Mutation",
            "bei Operator-Gate nur Go/No-Go-Paket vorbereiten",
        ],
        "relevante_dateien_artefakte": [
            str(item.get("path", "")),
            str(FRESH_DATA_INTAKE_PATH),
            str(VIVI_JOB_CARD_QUEUE_PATH),
        ],
        "evidence": [
            item.get("summary", ""),
            f"classification={classification}",
            f"signal_status={item.get('signal_status', 'unknown')}",
            f"runtime_action_executed={item.get('runtime_action_executed', False)}",
        ],
        "verifier": verifier,
        "stop_regel": (
            "Stoppe sofort bei Public/Production/Geld/Credentials/Auth/externer Kommunikation/Löschung/Room16-Rerun oder wenn Evidence widersprüchlich ist."
        ),
        "retry_regel": (
            "Ein Retry ist nur erlaubt, wenn der letzte Fehler ein lokaler Parser-, Pfad- oder Verifier-Fehler war und keine Operator-Gates berührt werden."
        ),
        "status": status,
        "naechster_sicherer_schritt": item.get("next_safe_step", "Evidence prüfen und an Vega/PIG übergeben."),
        "uebergabe_an_vega_pig_operator": (
            "Vivi liefert Handoff-Kandidat; Vega prüft und integriert; PIG full-check bleibt führend; Operator entscheidet nur echte Gates."
        ),
        "operator_gate_required": operator_gate,
        "runtime_action_executed": False,
        "created_from": {
            "source_id": source_id,
            "classification": classification,
            "modified_at": item.get("modified_at", ""),
        },
    }


def completed_vivi_job_card_state() -> dict[str, Any]:
    supervisor = load_json(VIVI_SUPERVISOR_AUDIT_PATH, default={})
    workflow_run_path = Path()
    workflow_run: dict[str, Any] = {}
    if isinstance(supervisor, dict) and supervisor.get("status") == "PASS" and supervisor.get("truth_status") in {"completed_verified_local", "closed_no_action"} and supervisor.get("runner_status") == "completed_verified":
        workflow_run_path = Path(str(supervisor.get("workflow_run_path", ""))) if supervisor.get("workflow_run_path") else Path()
        workflow_run = load_json(workflow_run_path, default={}) if workflow_run_path else {}
        supervisor_card = workflow_run.get("job_card", {}) if isinstance(workflow_run, dict) else {}
        if not isinstance(supervisor_card, dict) or not supervisor_card.get("source_item_id"):
            workflow_run_path = Path()
            workflow_run = {}
    if not workflow_run:
        for candidate in sorted(WORKFLOW_RUNS_DIR.glob("vivi-runner-*.json"), key=lambda path: path.name, reverse=True):
            candidate_run = load_json(candidate, default={})
            if not isinstance(candidate_run, dict) or candidate_run.get("status") != "completed_verified":
                continue
            candidate_card = candidate_run.get("job_card", {})
            if not isinstance(candidate_card, dict) or not candidate_card.get("source_item_id"):
                continue
            workflow_run_path = candidate
            workflow_run = candidate_run
            break
    job_card = workflow_run.get("job_card", {}) if isinstance(workflow_run, dict) else {}
    job_card_id = str(job_card.get("job_card_id") or workflow_run.get("job_card_id") or "")
    source_item_id = str(job_card.get("source_item_id", "")) if isinstance(job_card, dict) else ""
    if not job_card_id or not source_item_id or not workflow_run:
        return {}
    return {
        "job_card_id": job_card_id,
        "source_item_id": source_item_id,
        "run_id": workflow_run.get("run_id") or supervisor.get("run_id", ""),
        "workflow_run_path": str(workflow_run_path) if workflow_run_path else "",
        "verified_at": supervisor.get("generated_at", "") if isinstance(supervisor, dict) else "",
        "truth_status": supervisor.get("truth_status", "completed_verified_local") if isinstance(supervisor, dict) else "completed_verified_local",
    }


def apply_vivi_job_card_completion_state(payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return payload
    completion = completed_vivi_job_card_state()
    cards = payload.get("job_cards", [])
    if not completion or not isinstance(cards, list):
        return payload
    for card in cards:
        if not isinstance(card, dict):
            continue
        if card.get("job_card_id") != completion.get("job_card_id"):
            continue
        if card.get("source_item_id") != completion.get("source_item_id"):
            continue
        card["status"] = "completed_verified"
        card["completed_by_runner"] = completion.get("run_id", "")
        card["completed_workflow_run_path"] = completion.get("workflow_run_path", "")
        card["supervisor_truth_status"] = completion.get("truth_status", "")
        card["naechster_sicherer_schritt"] = "Runner und Supervisor haben diese Job Card lokal verifiziert; als Evidence halten und keine Runtime-Aktion ableiten."
    payload["ready_count"] = len([card for card in cards if isinstance(card, dict) and card.get("status") == "ready"])
    payload["waiting_for_operator_count"] = len([card for card in cards if isinstance(card, dict) and card.get("status") == "waiting_for_operator"])
    payload["waiting_for_evidence_count"] = len([card for card in cards if isinstance(card, dict) and card.get("status") == "waiting_for_evidence"])
    payload["completed_verified_count"] = len([card for card in cards if isinstance(card, dict) and card.get("status") == "completed_verified"])
    payload["open_action_item_count"] = len([
        card
        for card in cards
        if isinstance(card, dict) and card.get("status") not in {"completed_verified", "closed_no_action"}
    ])
    return payload


def build_vivi_job_card_queue(*, write: bool = True) -> dict[str, Any]:
    fresh_data = build_fresh_data_intake(write=True)
    source_items = fresh_data.get("action_items", [])
    job_cards = [job_card_from_fresh_data_item(item) for item in source_items]
    errors: list[dict[str, Any]] = []
    for card in job_cards:
        card_errors = validate_required_fields(card, JOB_CARD_REQUIRED, {"status": JOB_CARD_STATUSES})
        if card_errors:
            errors.append({"job_card_id": card.get("job_card_id", "unknown"), "errors": card_errors})
    status = "FAIL" if errors else ("WARN" if any(card.get("status") == "waiting_for_operator" for card in job_cards) else "PASS")
    payload = {
        "schema_version": 1,
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": status,
        "source": "fresh_data_intake",
        "fresh_data_status": fresh_data.get("status", "UNKNOWN"),
        "job_card_count": len(job_cards),
        "ready_count": len([card for card in job_cards if card.get("status") == "ready"]),
        "waiting_for_operator_count": len([card for card in job_cards if card.get("status") == "waiting_for_operator"]),
        "waiting_for_evidence_count": len([card for card in job_cards if card.get("status") == "waiting_for_evidence"]),
        "completed_verified_count": len([card for card in job_cards if card.get("status") == "completed_verified"]),
        "open_action_item_count": len([card for card in job_cards if card.get("status") not in {"completed_verified", "closed_no_action"}]),
        "errors": errors,
        "job_cards": job_cards,
        "notes": [
            "This queue materializes read-only Vivi job cards from Fresh Data Intake action items.",
            "Job cards are contracts for local work; they do not execute runtime actions by themselves.",
        ],
    }
    payload = apply_vivi_job_card_completion_state(payload)
    if write:
        write_json(VIVI_JOB_CARD_QUEUE_PATH, payload)
        (OUTPUT_DIR / "vivi_job_card_queue.md").write_text(vivi_job_card_queue_to_markdown(payload), encoding="utf-8")
        JOB_CARDS_DIR.mkdir(parents=True, exist_ok=True)
        for card in payload.get("job_cards", job_cards):
            card_path = JOB_CARDS_DIR / f"{card['job_card_id']}.json"
            write_json(card_path, card)
            (JOB_CARDS_DIR / f"{card['job_card_id']}.md").write_text(job_card_to_markdown(card), encoding="utf-8")
    return payload


SAFE_VIVI_RUNNER_COMMANDS = {
    "python3 scripts/project_intelligence_graph/pig.py fresh-data": [sys.executable, "scripts/project_intelligence_graph/pig.py", "fresh-data", "--json"],
    "python3 scripts/project_intelligence_graph/pig.py vivi-job-cards": [sys.executable, "scripts/project_intelligence_graph/pig.py", "vivi-job-cards", "--json"],
    "python3 scripts/project_intelligence_graph/pig.py operator-brief": [sys.executable, "scripts/project_intelligence_graph/pig.py", "operator-brief", "--json"],
    "cd /Users/BjornRosinger/Documents/New project/company-dossier-lab/room16-app && npm run verify:review-gate-status": ["npm", "--prefix", "company-dossier-lab/room16-app", "run", "verify:review-gate-status"],
    "cd company-dossier-lab/room16-app && npm run verify:review-gate-status": ["npm", "--prefix", "company-dossier-lab/room16-app", "run", "verify:review-gate-status"],
    "cd /Users/BjornRosinger/Documents/New project/company-dossier-lab/room16-app && npm run verify:manual-review-packets": ["npm", "--prefix", "company-dossier-lab/room16-app", "run", "verify:manual-review-packets"],
    "cd company-dossier-lab/room16-app && npm run verify:manual-review-packets": ["npm", "--prefix", "company-dossier-lab/room16-app", "run", "verify:manual-review-packets"],
    "cd /Users/BjornRosinger/Documents/New project/company-dossier-lab/room16-app && npm run verify:german-output-quality": ["npm", "--prefix", "company-dossier-lab/room16-app", "run", "verify:german-output-quality"],
    "cd company-dossier-lab/room16-app && npm run verify:german-output-quality": ["npm", "--prefix", "company-dossier-lab/room16-app", "run", "verify:german-output-quality"],
}


def normalize_verifier_command(command: str) -> str:
    return re.sub(r"\s+", " ", command.strip())


def run_vivi_runner_mvp(*, write: bool = True) -> dict[str, Any]:
    started_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    queue = build_vivi_job_card_queue(write=True)
    ready_cards = [card for card in queue.get("job_cards", []) if card.get("status") == "ready"]
    run_id = f"vivi-runner-{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"
    failures: list[dict[str, Any]] = []
    verifiers: list[dict[str, Any]] = []
    evidence: list[str] = []
    selected = ready_cards[0] if ready_cards else {}
    if not selected:
        completion = completed_vivi_job_card_state()
        retained_completion = bool(completion and queue.get("completed_verified_count", 0) > 0)
        status = "completed_verified" if retained_completion else "closed_no_action"
        next_safe_step = (
            "Previous Vivi job card completion is retained; no new ready card exists."
            if retained_completion
            else "No ready Vivi job card exists; wait for Fresh Data Intake or Operator signal."
        )
        evidence.extend([
            "no_ready_vivi_job_card=True",
            f"retained_completion={retained_completion}",
            f"retained_run_id={completion.get('run_id', '') if completion else ''}",
            f"queue_status={queue.get('status', 'UNKNOWN')}",
            f"job_card_count={queue.get('job_card_count', 0)}",
            f"completed_verified_count={queue.get('completed_verified_count', 0)}",
            f"open_action_item_count={queue.get('open_action_item_count', 0)}",
            "runtime_action_executed=False",
        ])
    elif selected.get("operator_gate_required"):
        status = "waiting_for_operator"
        next_safe_step = "Operator gate is required before this job card can run."
        failures.append({"type": "operator_gate", "detail": selected.get("job_card_id", "")})
    else:
        missing_inputs = [
            path
            for path in selected.get("input", [])
            if path and not Path(str(path)).exists()
        ]
        if missing_inputs:
            status = "failed_safe"
            next_safe_step = "Repair missing input paths before running this job card."
            failures.extend({"type": "missing_input", "detail": path} for path in missing_inputs)
        else:
            for raw_command in selected.get("verifier", []):
                normalized = normalize_verifier_command(str(raw_command))
                if normalized not in SAFE_VIVI_RUNNER_COMMANDS:
                    verifiers.append({
                        "command": raw_command,
                        "status": "skipped_not_in_runner_allowlist",
                        "returncode": None,
                        "reason": "Runner MVP executes only safe PIG verifiers; project-specific or shell-changing commands remain Vega/manual verifier.",
                    })
                    continue
                result = run_local_command(SAFE_VIVI_RUNNER_COMMANDS[normalized], WORKSPACE)
                verifiers.append({
                    "command": normalized,
                    "status": result["status"],
                    "returncode": result["returncode"],
                    "stdout_tail": result["stdout_tail"],
                    "stderr_tail": result["stderr_tail"],
                })
                if result["status"] != "PASS":
                    failures.append({"type": "verifier_failed", "detail": normalized})
            evidence.extend(str(item) for item in selected.get("evidence", []) if item)
            evidence.append(f"job_card_id={selected.get('job_card_id', '')}")
            evidence.append("runtime_action_executed=False")
            status = "completed_verified" if not failures else "waiting_for_evidence"
            next_safe_step = (
                "Hand the verified runner record to Vega/PIG; the content job itself still needs a Vivi or Vega review output."
                if status == "completed_verified"
                else "Inspect verifier failures before claiming this job card is runnable."
            )
    completed_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    workflow_run = {
        "schema_version": 1,
        "run_id": run_id,
        "started_at": started_at,
        "contract": selected.get("job_card_id", "vivi-job-card-queue"),
        "workflow_steps": [
            {"step_id": "load_queue", "type": "FreshDataToJobCard", "status": "completed_verified", "output": str(VIVI_JOB_CARD_QUEUE_PATH)},
            {"step_id": "validate_job_card", "type": "JobCard", "status": "completed_verified" if selected else "closed_no_action", "output": selected.get("job_card_id", "")},
            {"step_id": "safe_verifiers", "type": "Verifier", "status": status, "output": str(VIVI_RUNNER_LAST_RUN_PATH)},
        ],
        "current_step": "complete" if status in {"completed_verified", "closed_no_action"} else "safe_verifiers",
        "approval_nodes": [] if not selected.get("operator_gate_required") else [{"approval_id": "operator-go", "required": True}],
        "verifiers": verifiers or [{"command": "none", "status": "closed_no_action", "returncode": None}],
        "status": status,
        "control_state": status,
        "retry_count": 0,
        "pause_resume_retry": {
            "pause": {"allowed": True, "operator_gate_required": False, "runtime_effect": "local_state_only"},
            "resume": {"allowed": status != "waiting_for_operator", "operator_gate_required": status == "waiting_for_operator", "runtime_effect": "local_state_only"},
            "retry": {"allowed": status in {"waiting_for_evidence", "failed_safe"}, "operator_gate_required": False, "runtime_effect": "local_verifier_only"},
        },
        "operator_actions": [] if status != "waiting_for_operator" else [{"action_id": "operator-go", "label": "Operator-Go erforderlich"}],
        "failures": failures,
        "evidence": evidence,
        "memory_updates": [],
        "completed_at": completed_at,
        "runtime_action_executed": False,
        "job_card": selected,
        "mode": "read_only_runner_mvp",
    }
    payload = {
        "schema_version": 1,
        "generated_at": completed_at,
        "run_id": run_id,
        "status": status,
        "mode": "read_only_runner_mvp",
        "job_card_id": selected.get("job_card_id", ""),
        "queue_status": queue.get("status", "UNKNOWN"),
        "runtime_action_executed": False,
        "verifiers": verifiers,
        "failures": failures,
        "evidence": evidence,
        "next_safe_step": next_safe_step,
        "workflow_run_path": str(WORKFLOW_RUNS_DIR / f"{run_id}.json"),
    }
    if write:
        write_json(VIVI_RUNNER_LAST_RUN_PATH, payload)
        (OUTPUT_DIR / "vivi_runner_last_run.md").write_text(vivi_runner_to_markdown(payload), encoding="utf-8")
        WORKFLOW_RUNS_DIR.mkdir(parents=True, exist_ok=True)
        write_json(WORKFLOW_RUNS_DIR / f"{run_id}.json", workflow_run)
        (WORKFLOW_RUNS_DIR / f"{run_id}.md").write_text(execution_history_to_markdown(workflow_run), encoding="utf-8")
    return payload


def build_vivi_supervisor_audit(*, write: bool = True) -> dict[str, Any]:
    runner = load_json(VIVI_RUNNER_LAST_RUN_PATH, default={})
    queue = load_json(VIVI_JOB_CARD_QUEUE_PATH, default={})
    run_id = runner.get("run_id", "") if isinstance(runner, dict) else ""
    job_card_id = runner.get("job_card_id", "") if isinstance(runner, dict) else ""
    workflow_run_path = Path(str(runner.get("workflow_run_path", ""))) if isinstance(runner, dict) and runner.get("workflow_run_path") else Path()
    workflow_run = load_json(workflow_run_path, default={}) if workflow_run_path else {}
    if not workflow_run and run_id:
        workflow_run = load_json(WORKFLOW_RUNS_DIR / f"{run_id}.json", default={})
        workflow_run_path = WORKFLOW_RUNS_DIR / f"{run_id}.json"
    job_card = {}
    if isinstance(queue, dict):
        for card in queue.get("job_cards", []):
            if card.get("job_card_id") == job_card_id:
                job_card = card
                break
    if not job_card and job_card_id:
        job_card = load_json(JOB_CARDS_DIR / f"{job_card_id}.json", default={})

    verifiers = runner.get("verifiers", []) if isinstance(runner, dict) else []
    executed = [item for item in verifiers if item.get("status") not in {"skipped_not_in_runner_allowlist", "closed_no_action"}]
    passed = [item for item in executed if item.get("status") == "PASS"]
    failed = [item for item in executed if item.get("status") not in {"PASS"}]
    skipped = [item for item in verifiers if item.get("status") == "skipped_not_in_runner_allowlist"]
    findings: list[dict[str, Any]] = []
    status = "PASS"
    truth_status = "completed_verified_local"
    next_safe_step = "No supervisor action needed; keep the Runner result as local verified evidence."

    def add_finding(severity: str, code: str, message: str) -> None:
        findings.append({"severity": severity, "code": code, "message": message})

    if not isinstance(runner, dict) or not runner:
        status = "FAIL"
        truth_status = "missing_runner_record"
        add_finding("FAIL", "missing_runner", "Vivi Runner record is missing.")
        next_safe_step = "Run `python3 scripts/project_intelligence_graph/pig.py vivi-runner` before supervising Vivi output."
    if runner.get("runtime_action_executed") is True:
        status = "FAIL"
        truth_status = "unsafe_runtime_action_detected"
        add_finding("FAIL", "runtime_action_executed", "Runner reported a runtime action; MVP must stay read-only.")
        next_safe_step = "Stop and inspect the Runner output before accepting any automation result."
    if runner.get("status") not in {"completed_verified", "closed_no_action", "waiting_for_operator", "waiting_for_evidence", "failed_safe"}:
        status = "FAIL"
        truth_status = "invalid_runner_status"
        add_finding("FAIL", "invalid_runner_status", f"Runner status is `{runner.get('status', 'UNKNOWN')}`.")
    if job_card_id and not job_card:
        status = "FAIL"
        truth_status = "missing_job_card_contract"
        add_finding("FAIL", "missing_job_card", f"Job Card `{job_card_id}` is not materialized in the queue or job_cards directory.")
    if run_id and not workflow_run:
        status = "FAIL"
        truth_status = "missing_execution_history"
        add_finding("FAIL", "missing_execution_history", f"Workflow run `{run_id}` is missing.")
    if failed:
        status = "WARN" if status == "PASS" else status
        truth_status = "waiting_for_evidence"
        add_finding("WARN", "verifier_failed", f"{len(failed)} executed verifier(s) did not pass.")
        next_safe_step = "Inspect failed verifiers before claiming this Job Card is verified."
    if skipped:
        status = "WARN" if status == "PASS" else status
        truth_status = "verified_runner_record_pending_project_verifier" if runner.get("status") == "completed_verified" else truth_status
        add_finding(
            "WARN",
            "skipped_project_verifier",
            f"{len(skipped)} project-specific verifier(s) were skipped by the Runner MVP allowlist.",
        )
        next_safe_step = "Run or review skipped project-specific verifiers with Vega/manual approval before treating the content job as completed."
    if runner.get("status") == "waiting_for_operator" or job_card.get("operator_gate_required"):
        status = "WARN" if status == "PASS" else status
        truth_status = "waiting_for_operator_gate"
        add_finding("WARN", "operator_gate_required", "This Job Card has an Operator-Gate and must not be executed autonomously.")
        next_safe_step = "Stop at Operator-Gate; do not run Public, Production, money, auth, external, deletion, real-data or Room16 publish actions."
    if runner.get("status") == "closed_no_action":
        truth_status = "closed_no_action"
        next_safe_step = "No ready Job Card exists; wait for Fresh Data Intake or a new safe Operator signal."

    payload = {
        "schema_version": 1,
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": status,
        "truth_status": truth_status,
        "runner_status": runner.get("status", "UNKNOWN") if isinstance(runner, dict) else "UNKNOWN",
        "run_id": run_id,
        "job_card_id": job_card_id,
        "runtime_action_executed": runner.get("runtime_action_executed", None) if isinstance(runner, dict) else None,
        "workflow_run_path": str(workflow_run_path) if workflow_run_path else "",
        "job_card_path": str(JOB_CARDS_DIR / f"{job_card_id}.json") if job_card_id else "",
        "verifier_summary": {
            "total": len(verifiers),
            "executed": len(executed),
            "passed": len(passed),
            "failed": len(failed),
            "skipped_not_in_runner_allowlist": len(skipped),
        },
        "findings": findings,
        "operator_gates": job_card.get("operator_gate", []) if isinstance(job_card, dict) else [],
        "supervisor_decision": (
            "candidate_only_until_skipped_verifiers_are_reviewed"
            if skipped and status != "FAIL"
            else ("reject_until_failures_are_fixed" if status == "FAIL" else truth_status)
        ),
        "memory_capture_required": bool(findings),
        "next_safe_step": next_safe_step,
        "notes": [
            "Supervisor audit is read-only. It does not run Room16, publish, mutate runtime state or expand the Runner allowlist.",
            "A completed Runner record is not automatically a completed content job when project-specific verifiers were skipped.",
        ],
    }
    if write:
        write_json(VIVI_SUPERVISOR_AUDIT_PATH, payload)
        (OUTPUT_DIR / "vivi_supervisor_audit.md").write_text(vivi_supervisor_audit_to_markdown(payload), encoding="utf-8")
    return payload


SAFE_VIVI_WORKER_COMMANDS = {
    "commit-cleanup-package": [sys.executable, "scripts/project_intelligence_graph/pig.py", "commit-cleanup-package", "--json"],
    "operator-brief": [sys.executable, "scripts/project_intelligence_graph/pig.py", "operator-brief", "--json"],
    "operator-surface": [sys.executable, "scripts/project_intelligence_graph/pig.py", "operator-surface", "--json"],
    "autonomy-dirt-scan": [sys.executable, "scripts/project_intelligence_graph/pig.py", "autonomy-dirt-scan", "--json"],
    "room16-german-output-quality": ["npm", "--prefix", "company-dossier-lab/room16-app", "run", "verify:german-output-quality"],
    "kanzlei-verify-all-dry-run": [sys.executable, "kanzlei-ai-assist/scripts/verify/verify_all.py"],
}

VIVI_WORKER_COMPLETED_MODES = {"local_artifact_worker_mvp", "safe_project_worker_v2"}
VIVI_SAFE_PROJECT_WORKER_CLAIM_TYPES = {"run_project_verifier", "generated_artifact_review"}


def vivi_worker_queue_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Vivi Worker Queue",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Worker cards: `{payload.get('worker_card_count', 0)}`",
        f"- Ready: `{payload.get('ready_count', 0)}`",
        f"- Waiting for operator: `{payload.get('waiting_for_operator_count', 0)}`",
        "",
        "## Worker Cards",
        "",
    ]
    for card in payload.get("worker_cards", []):
        lines.append(f"- `{card.get('worker_card_id', '')}` status=`{card.get('status', '')}`")
        lines.append(f"  - Projekt: `{card.get('project_id', '')}` / Claim: `{card.get('claim_type', '')}` / Mode: `{card.get('mode', '')}`")
        lines.append(f"  - Auftrag: {card.get('auftrag', '')}")
        lines.append(f"  - Output: `{record_value(card.get('output_vertrag', []))}`")
        lines.append(f"  - next: {card.get('naechster_sicherer_schritt', '')}")
    return "\n".join(lines) + "\n"


def vivi_worker_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Vivi Worker MVP Run",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Run: `{payload.get('run_id', '')}`",
        f"- Mode: `{payload.get('mode', '')}`",
        f"- Worker card: `{payload.get('worker_card_id', '')}`",
        f"- Project: `{payload.get('project_id', '')}`",
        f"- Claim type: `{payload.get('claim_type', '')}`",
        f"- Runtime action executed: `{payload.get('runtime_action_executed', None)}`",
        f"- Local artifact write executed: `{payload.get('local_artifact_write_executed', None)}`",
        f"- Project verifier executed: `{payload.get('project_verifier_executed', None)}`",
        "",
        "## Commands",
        "",
    ]
    for item in payload.get("commands", []):
        lines.append(f"- `{item.get('command_id', '')}` `{item.get('status', '')}` rc=`{item.get('returncode')}`")
    lines.extend(["", "## Next Safe Step", "", payload.get("next_safe_step", "")])
    return "\n".join(lines) + "\n"


def vivi_worker_supervisor_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Vivi Worker Supervisor Audit",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Truth: `{payload.get('truth_status', 'UNKNOWN')}`",
        f"- Worker run: `{payload.get('run_id', '')}`",
        f"- Mode: `{payload.get('mode', '')}`",
        f"- Project: `{payload.get('project_id', '')}`",
        f"- Claim type: `{payload.get('claim_type', '')}`",
        f"- Runtime action executed: `{payload.get('runtime_action_executed', None)}`",
        "",
        "## Findings",
        "",
    ]
    for finding in payload.get("findings", []) or [{"severity": "INFO", "code": "none", "message": "None."}]:
        lines.append(f"- `{finding.get('severity')}` `{finding.get('code')}` {finding.get('message')}")
    lines.extend(["", "## Next Safe Step", "", payload.get("next_safe_step", "")])
    return "\n".join(lines) + "\n"


def vivi_worker_card_fingerprint(card: dict[str, Any]) -> str:
    payload = {
        "worker_card_id": card.get("worker_card_id", ""),
        "auftrag": card.get("auftrag", ""),
        "zielbild": card.get("zielbild", ""),
        "erlaubte_aktion": card.get("erlaubte_aktion", []),
        "verbotene_aktion": card.get("verbotene_aktion", []),
        "output_vertrag": card.get("output_vertrag", []),
        "verifier": card.get("verifier", []),
        "source_fingerprint": card.get("source_fingerprint", ""),
    }
    return stable_id(json.dumps(payload, sort_keys=True, ensure_ascii=False))


def vivi_worker_source_fingerprint(paths: list[str]) -> str:
    items: list[dict[str, Any]] = []
    for raw_path in paths:
        path = Path(str(raw_path))
        if not path.is_absolute():
            path = WORKSPACE / path
        if path.exists():
            items.append({
                "path": str(path),
                "exists": True,
                "mtime": path_mtime_iso(path),
                "size": path.stat().st_size,
            })
        else:
            items.append({"path": str(path), "exists": False})
    return stable_id(json.dumps(items, sort_keys=True, ensure_ascii=False))


def completed_vivi_worker_states() -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    for path in list_json_files(WORKFLOW_RUNS_DIR):
        run = load_json(path, default={})
        if not isinstance(run, dict):
            continue
        if run.get("mode") not in VIVI_WORKER_COMPLETED_MODES:
            continue
        if run.get("status") != "completed_verified" or run.get("runtime_action_executed") is True:
            continue
        worker_card = run.get("worker_card", {}) if isinstance(run.get("worker_card"), dict) else {}
        worker_card_id = str(worker_card.get("worker_card_id", ""))
        fingerprint = str(worker_card.get("worker_fingerprint") or vivi_worker_card_fingerprint(worker_card))
        if not worker_card_id or not fingerprint:
            continue
        candidates.append({
            "worker_card_id": worker_card_id,
            "worker_fingerprint": fingerprint,
            "run_id": run.get("run_id", ""),
            "mode": run.get("mode", ""),
            "workflow_run_path": str(path),
            "verified_at": run.get("completed_at", ""),
            "truth_status": (
                "completed_verified_safe_project_worker"
                if run.get("mode") == "safe_project_worker_v2"
                else "completed_verified_local_artifact_worker"
            ),
        })
    candidates.sort(key=lambda item: str(item.get("verified_at", "")), reverse=True)
    return candidates


def completed_vivi_worker_state() -> dict[str, Any]:
    states = completed_vivi_worker_states()
    return states[0] if states else {}


def apply_vivi_worker_completion_state(payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(payload, dict):
        return payload
    completions = completed_vivi_worker_states()
    completion_by_key = {
        (item.get("worker_card_id", ""), item.get("worker_fingerprint", "")): item
        for item in completions
        if item.get("worker_card_id") and item.get("worker_fingerprint")
    }
    cards = payload.get("worker_cards", [])
    if not completion_by_key or not isinstance(cards, list):
        return payload
    for card in cards:
        if not isinstance(card, dict):
            continue
        completion = completion_by_key.get((card.get("worker_card_id", ""), card.get("worker_fingerprint", "")))
        if not completion:
            continue
        card["status"] = "completed_verified"
        card["completed_by_worker"] = completion.get("run_id", "")
        card["completed_workflow_run_path"] = completion.get("workflow_run_path", "")
        card["supervisor_truth_status"] = completion.get("truth_status", "")
        card["naechster_sicherer_schritt"] = "Worker und Supervisor haben diese lokale Arbeit verifiziert; als Evidence halten und keine Runtime- oder Gate-Aktion ableiten."
    payload["ready_count"] = len([card for card in cards if isinstance(card, dict) and card.get("status") == "ready"])
    payload["waiting_for_operator_count"] = len([card for card in cards if isinstance(card, dict) and card.get("status") == "waiting_for_operator"])
    payload["completed_verified_count"] = len([card for card in cards if isinstance(card, dict) and card.get("status") == "completed_verified"])
    payload["open_action_item_count"] = len([
        card
        for card in cards
        if isinstance(card, dict) and card.get("status") not in {"completed_verified", "closed_no_action"}
    ])
    payload["status"] = "WARN" if payload["ready_count"] or payload["waiting_for_operator_count"] else "PASS"
    return payload


def generated_artifact_review_source_fingerprint() -> str:
    scan = load_json(AUTONOMY_DIRT_BACKLOG_SCAN_PATH, default={})
    state = load_json(AUTONOMY_DIRT_DECISION_STATE_PATH, default={})
    cards = []
    if isinstance(scan, dict):
        for card in scan.get("handoff_cards", []):
            if not isinstance(card, dict):
                continue
            cards.append({
                "card_id": card.get("card_id", ""),
                "project_id": card.get("project_id", ""),
                "ownership": card.get("ownership", ""),
                "count": card.get("count", 0),
                "operator_gate_required": card.get("operator_gate_required", False),
                "sample_paths": card.get("sample_paths", []),
            })
    decisions = []
    if isinstance(state, dict) and isinstance(state.get("items"), dict):
        for key, item in sorted(state["items"].items()):
            if not isinstance(item, dict) or ":generated_artifact:" not in str(key):
                continue
            decisions.append({
                "key": key,
                "state": item.get("state", ""),
                "fingerprint": item.get("fingerprint", ""),
            })
    payload = {
        "dirty_project_count": scan.get("dirty_project_count", 0) if isinstance(scan, dict) else 0,
        "handoff_card_count": scan.get("handoff_card_count", 0) if isinstance(scan, dict) else 0,
        "cards": sorted(cards, key=lambda row: str(row.get("card_id", ""))),
        "generated_artifact_decisions": decisions,
    }
    return stable_id(json.dumps(payload, sort_keys=True, ensure_ascii=False))


def build_project_verifier_worker_cards() -> list[dict[str, Any]]:
    cards: list[dict[str, Any]] = []
    hard_gates = [
        "push",
        "delete",
        "publish",
        "production",
        "public",
        "money/payment",
        "credentials/auth",
        "external communication",
        "real person/client data",
        "financial-advice publishing",
    ]
    specs = [
        {
            "worker_card_id": "vivi-worker-v2-room16-german-output-quality",
            "project_id": "room16",
            "claim_type": "run_project_verifier",
            "risk_class": "R2",
            "auftrag": "Run the local Room16 German Output Quality verifier as a safe Vivi project claim.",
            "zielbild": "Vivi can verify Room16 German operator/report prose without rerun, publish, member/public exposure or financial-advice effect.",
            "input": [
                "company-dossier-lab/room16-app/package.json",
                "company-dossier-lab/room16-app/scripts/verify_german_output_quality.mjs",
                "scripts/project_intelligence_graph/german_output_quality_gate.py",
            ],
            "erlaubte_aktion": ["room16-german-output-quality"],
            "verbotene_aktion": [*hard_gates, "Room16 rerun", "public/member/shelf changes"],
            "output_vertrag": [
                "company-dossier-lab/outputs/german_output_quality/room16_german_output_quality.json",
                "company-dossier-lab/outputs/german_output_quality/room16_german_output_quality.md",
                str(VIVI_WORKER_LAST_RUN_PATH),
            ],
            "evidence": [
                "project_id=room16",
                "claim_type=run_project_verifier",
                "runtime_action_executed=False",
                "Room16 rerun/push/publish not executed",
                "company-dossier-lab/outputs/german_output_quality/room16_german_output_quality.json",
            ],
            "verifier": ["cd company-dossier-lab/room16-app && npm run verify:german-output-quality"],
            "stop_regel": "Stop immediately if a step would rerun Room16, change visibility, publish, push, touch credentials/auth, use external communication, delete data or create financial-advice exposure.",
            "retry_regel": "Retry only this local verifier after inspecting stdout/stderr; no Room16 rerun or visibility mutation is allowed.",
            "naechster_sicherer_schritt": "Run the allowlisted Room16 verifier and hand the execution history to Vega/PIG Supervisor.",
        },
        {
            "worker_card_id": "vivi-worker-v2-kanzlei-verify-all",
            "project_id": "kanzlei_ai_assist",
            "claim_type": "run_project_verifier",
            "risk_class": "R2",
            "auftrag": "Run the local Kanzlei AI Assist verify-all check as a safe Vivi project claim.",
            "zielbild": "Vivi can verify the deterministic Kanzlei MVP scaffold with synthetic/local fixtures only, without DATEV, real client data, cloud processing or external effect.",
            "input": [
                "kanzlei-ai-assist/scripts/verify/verify_all.py",
                "kanzlei-ai-assist/scripts/verify/golden_case_inventory.py",
                "kanzlei-ai-assist/fixtures/synthetic",
                "kanzlei-ai-assist/fixtures/golden-cases",
            ],
            "erlaubte_aktion": ["kanzlei-verify-all-dry-run"],
            "verbotene_aktion": [*hard_gates, "DATEV upload", "cloud/provider processing", "final tax decision"],
            "output_vertrag": [
                "kanzlei-ai-assist/outputs/verification/latest-verify-all.json",
                "kanzlei-ai-assist/outputs/verification/latest-verify-all.md",
                "kanzlei-ai-assist/ops/verification/PREMERGE_VALIDATION.md",
                str(VIVI_WORKER_LAST_RUN_PATH),
            ],
            "evidence": [
                "project_id=kanzlei_ai_assist",
                "claim_type=run_project_verifier",
                "runtime_action_executed=False",
                "real_client_data_used=False",
                "kanzlei-ai-assist/outputs/verification/latest-verify-all.json",
            ],
            "verifier": ["cd kanzlei-ai-assist && python3 scripts/verify/verify_all.py"],
            "stop_regel": "Stop immediately if real person/client data, DATEV upload, production, credentials/auth, external communication, deletion or final tax decision would be touched.",
            "retry_regel": "Retry only this local deterministic verifier after inspecting stdout/stderr; no real data or external channel is allowed.",
            "naechster_sicherer_schritt": "Run the allowlisted Kanzlei verifier and hand the execution history to Vega/PIG Supervisor.",
        },
    ]
    for spec in specs:
        card = {
            "schema_version": 2,
            "status": "ready",
            "mode": "safe_project_worker_v2",
            "operator_gate_required": False,
            "handover": "Vega/PIG/Operator",
            **spec,
        }
        card["source_fingerprint"] = vivi_worker_source_fingerprint(card["input"])
        card["worker_fingerprint"] = vivi_worker_card_fingerprint(card)
        cards.append(card)
    return cards


def build_generated_artifact_review_worker_cards() -> list[dict[str, Any]]:
    scan = load_json(AUTONOMY_DIRT_BACKLOG_SCAN_PATH, default={})
    handoff_cards = scan.get("handoff_cards", []) if isinstance(scan, dict) else []
    generated_cards = [
        card
        for card in handoff_cards
        if isinstance(card, dict) and card.get("ownership") == "generated_artifact"
    ]
    gated_cards = [
        card
        for card in handoff_cards
        if isinstance(card, dict) and card.get("operator_gate_required") is True
    ]
    card = {
        "schema_version": 2,
        "worker_card_id": "vivi-worker-v2-generated-artifact-review",
        "project_id": "cross_project",
        "claim_type": "generated_artifact_review",
        "risk_class": "R2",
        "mode": "safe_project_worker_v2",
        "status": "ready",
        "operator_gate_required": False,
        "auftrag": "Run the local autonomy dirt scan as a safe Vivi generated-artifact review claim.",
        "zielbild": "Vivi refreshes generated artifact ownership and verifier evidence across projects without cleanup, deletion, commit, push, publish, runtime mutation or external effect.",
        "input": [
            "scripts/project_intelligence_graph/pig.py",
            str(AUTONOMY_DIRT_DECISION_STATE_PATH),
        ],
        "erlaubte_aktion": ["autonomy-dirt-scan"],
        "verbotene_aktion": [
            "cleanup",
            "delete",
            "commit",
            "push",
            "publish",
            "production",
            "public",
            "credentials/auth",
            "external communication",
            "real person/client data",
            "financial-advice publishing",
            "Room16 rerun",
        ],
        "output_vertrag": [
            str(AUTONOMY_DIRT_BACKLOG_SCAN_PATH),
            str(OUTPUT_DIR / "autonomy_dirt_backlog_scan.md"),
            str(VIVI_WORKER_LAST_RUN_PATH),
        ],
        "evidence": [
            "project_id=cross_project",
            "claim_type=generated_artifact_review",
            f"generated_artifact_card_count={len(generated_cards)}",
            f"operator_gated_card_count={len(gated_cards)}",
            "runtime_action_executed=False",
            "cleanup_delete_commit_push_executed=False",
            str(AUTONOMY_DIRT_BACKLOG_SCAN_PATH),
        ],
        "verifier": ["python3 scripts/project_intelligence_graph/pig.py autonomy-dirt-scan --json"],
        "stop_regel": "Stop immediately if a step would cleanup, delete, commit, push, publish, rerun Room16, touch credentials/auth, use real data, external communication or production/public surfaces.",
        "retry_regel": "Retry only the local autonomy-dirt-scan command after inspecting stdout/stderr; do not mutate files outside generated PIG evidence.",
        "naechster_sicherer_schritt": "Run the allowlisted dirt scan, preserve the classification as evidence, and leave cleanup/commit/delete decisions operator-gated.",
        "handover": "Vega/PIG/Operator",
        "source_fingerprint": generated_artifact_review_source_fingerprint(),
    }
    card["worker_fingerprint"] = vivi_worker_card_fingerprint(card)
    return [card]


def build_vivi_worker_queue(*, write: bool = True) -> dict[str, Any]:
    package = build_commit_cleanup_go_package(write=True)
    cards: list[dict[str, Any]] = []
    if package.get("status") in {"operator_go_required", "needs_local_review", "blocked_by_missing_evidence"}:
        package_fingerprint = stable_id(json.dumps({
            "status": package.get("status", ""),
            "summary": package.get("summary", {}),
            "decisions": [
                {
                    "decision_id": item.get("decision_id", ""),
                    "project_id": item.get("project_id", ""),
                    "ownership": item.get("ownership", ""),
                    "status": item.get("status", ""),
                    "count": item.get("count", 0),
                    "operator_gate_required": item.get("operator_gate_required", False),
                }
                for item in package.get("decision_cards", [])
                if isinstance(item, dict)
            ],
        }, sort_keys=True, ensure_ascii=False))
        card = {
            "worker_card_id": "vivi-worker-refresh-operator-go-evidence",
            "status": "ready",
            "mode": "local_artifact_worker_mvp",
            "project_id": "project_intelligence_graph",
            "claim_type": "refresh_operator_surface_evidence",
            "risk_class": "R2",
            "auftrag": "Regenerate local Operator-Go evidence for Commit/Cleanup and the Quality OS surface.",
            "zielbild": "Operator sees the latest dirty-project package, brief, and surface without any commit, cleanup, push, delete, publish or runtime mutation.",
            "source_fingerprint": package_fingerprint,
            "input": [str(AUTONOMY_DIRT_BACKLOG_SCAN_PATH), str(AUTONOMY_DIRT_DECISION_STATE_PATH)],
            "erlaubte_aktion": [
                "commit-cleanup-package",
                "operator-brief",
                "operator-surface",
            ],
            "verbotene_aktion": FORBIDDEN_COMMIT_CLEANUP_ACTIONS,
            "output_vertrag": [
                str(COMMIT_CLEANUP_GO_PACKAGE_PATH),
                str(OPERATOR_BRIEF_PATH),
                str(QUALITY_OS_SURFACE_PATH),
                str(VIVI_WORKER_LAST_RUN_PATH),
            ],
            "evidence": [
                "runtime_action_executed=False",
                "local_artifact_write_executed=True",
                str(COMMIT_CLEANUP_GO_PACKAGE_PATH),
            ],
            "verifier": [
                "python3 scripts/project_intelligence_graph/pig.py commit-cleanup-package --json",
                "python3 scripts/project_intelligence_graph/pig.py operator-brief --json",
                "python3 scripts/project_intelligence_graph/pig.py operator-surface --json",
            ],
            "stop_regel": "Stop immediately if a requested step would commit, clean, push, delete, publish, touch credentials/auth, use external communication or execute runtime automation.",
            "retry_regel": "Retry only failed local PIG artifact regeneration commands after inspecting stdout/stderr.",
            "naechster_sicherer_schritt": "Run the safe worker command list and let the supervisor verify that no runtime action occurred.",
            "handover": "Vega/PIG/Operator",
            "operator_gate_required": False,
        }
        card["worker_fingerprint"] = vivi_worker_card_fingerprint(card)
        cards.append(card)
    cards.extend(build_project_verifier_worker_cards())
    cards.extend(build_generated_artifact_review_worker_cards())
    status = "PASS"
    if any(card.get("status") == "ready" for card in cards):
        status = "WARN"
    payload = {
        "schema_version": 1,
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": status,
        "source": "commit_cleanup_go_package",
        "source_status": package.get("status", "UNKNOWN"),
        "worker_card_count": len(cards),
        "ready_count": len([card for card in cards if card.get("status") == "ready"]),
        "waiting_for_operator_count": len([card for card in cards if card.get("status") == "waiting_for_operator"]),
        "worker_cards": cards,
        "notes": [
            "Vivi Worker MVP may write only local generated PIG artifacts.",
            "It must not execute commit, cleanup, push, delete, publish, credentials, auth, external communication or production actions.",
        ],
    }
    payload = apply_vivi_worker_completion_state(payload)
    if write:
        write_json(VIVI_WORKER_QUEUE_PATH, payload)
        (OUTPUT_DIR / "vivi_worker_queue.md").write_text(vivi_worker_queue_to_markdown(payload), encoding="utf-8")
    return payload


def run_vivi_worker_mvp(*, write: bool = True) -> dict[str, Any]:
    started_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    queue = build_vivi_worker_queue(write=True)
    ready_cards = [card for card in queue.get("worker_cards", []) if card.get("status") == "ready"]
    completed_cards = [card for card in queue.get("worker_cards", []) if card.get("status") == "completed_verified"]
    selected = ready_cards[0] if ready_cards else {}
    run_id = f"vivi-worker-{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"
    commands: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    evidence: list[str] = []

    if not selected and completed_cards:
        completion = completed_vivi_worker_state()
        retained_run_id = str(completion.get("run_id", ""))
        retained_mode = str(completion.get("mode", "local_artifact_worker_mvp")) or "local_artifact_worker_mvp"
        retained_card = next(
            (
                card
                for card in completed_cards
                if card.get("worker_card_id") == completion.get("worker_card_id")
                and card.get("worker_fingerprint") == completion.get("worker_fingerprint")
            ),
            completed_cards[0],
        )
        retained_workflow = load_json(Path(str(completion.get("workflow_run_path", ""))), default={}) if completion.get("workflow_run_path") else {}
        retained_commands = retained_workflow.get("verifiers", []) if isinstance(retained_workflow, dict) else []
        status = "completed_verified"
        next_safe_step = "Previous Vivi worker completion is still current; no new local artifact work is needed."
        evidence.extend([
            "ready_worker_card_count=0",
            f"completed_worker_card_count={len(completed_cards)}",
            f"retained_worker_run={retained_run_id}",
            "runtime_action_executed=False",
        ])
        payload = {
            "schema_version": 1,
            "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
            "run_id": retained_run_id,
            "status": status,
            "mode": retained_mode,
            "worker_card_id": retained_card.get("worker_card_id", ""),
            "project_id": retained_card.get("project_id", ""),
            "claim_type": retained_card.get("claim_type", ""),
            "risk_class": retained_card.get("risk_class", ""),
            "queue_status": queue.get("status", "UNKNOWN"),
            "runtime_action_executed": False,
            "local_artifact_write_executed": bool(retained_workflow.get("local_artifact_write_executed", False)) if isinstance(retained_workflow, dict) else False,
            "project_verifier_executed": retained_mode == "safe_project_worker_v2",
            "commands": retained_commands,
            "failures": [],
            "evidence": evidence,
            "next_safe_step": next_safe_step,
            "workflow_run_path": completion.get("workflow_run_path", ""),
            "retained_completion": True,
        }
        if write:
            write_json(VIVI_WORKER_LAST_RUN_PATH, payload)
            (OUTPUT_DIR / "vivi_worker_last_run.md").write_text(vivi_worker_to_markdown(payload), encoding="utf-8")
        return payload
    if not selected:
        status = "closed_no_action"
        next_safe_step = "No ready Vivi worker card exists; keep monitoring the Operator-Go package and Fresh Data Intake."
        evidence.extend(["no_ready_vivi_worker_card=True", f"queue_status={queue.get('status', 'UNKNOWN')}", "runtime_action_executed=False"])
    elif selected.get("operator_gate_required"):
        status = "waiting_for_operator"
        next_safe_step = "Operator gate required; do not run the worker card."
        failures.append({"type": "operator_gate", "detail": selected.get("worker_card_id", "")})
    else:
        missing_inputs = []
        for raw_path in selected.get("input", []):
            path = Path(str(raw_path))
            if not path.is_absolute():
                path = WORKSPACE / path
            if not path.exists():
                missing_inputs.append(str(raw_path))
        if missing_inputs:
            status = "failed_safe"
            next_safe_step = "Repair missing input paths before running this worker card."
            failures.extend({"type": "missing_input", "detail": path} for path in missing_inputs)
        else:
            for command_id in selected.get("erlaubte_aktion", []):
                if command_id not in SAFE_VIVI_WORKER_COMMANDS:
                    commands.append({
                        "command_id": command_id,
                        "status": "skipped_not_in_worker_allowlist",
                        "returncode": None,
                    })
                    failures.append({"type": "not_allowlisted", "detail": command_id})
                    continue
                result = run_local_command(SAFE_VIVI_WORKER_COMMANDS[command_id], WORKSPACE)
                commands.append({
                    "command_id": command_id,
                    "command": " ".join(str(part) for part in SAFE_VIVI_WORKER_COMMANDS[command_id]),
                    "status": result["status"],
                    "returncode": result["returncode"],
                    "stdout_tail": result["stdout_tail"],
                    "stderr_tail": result["stderr_tail"],
                })
                if result["status"] != "PASS":
                    failures.append({"type": "command_failed", "detail": command_id})
            evidence.extend(str(item) for item in selected.get("evidence", []))
            evidence.append(f"worker_card_id={selected.get('worker_card_id', '')}")
            evidence.append(f"worker_mode={selected.get('mode', 'local_artifact_worker_mvp')}")
            evidence.append("runtime_action_executed=False")
            status = "completed_verified" if not failures else "failed_safe"
            if status == "completed_verified" and selected.get("mode") == "safe_project_worker_v2":
                next_safe_step = "Keep the project verifier evidence visible; Vega/PIG Supervisor must accept it before any project status changes."
            else:
                next_safe_step = (
                    "Keep the refreshed Operator-Go evidence visible; wait for explicit Operator-Go before commit/cleanup/push/delete."
                    if status == "completed_verified"
                    else "Inspect failed local worker commands and rerun only the safe worker."
                )

    completed_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    worker_mode = selected.get("mode", "local_artifact_worker_mvp") if selected else "local_artifact_worker_mvp"
    workflow_run = {
        "schema_version": 1,
        "run_id": run_id,
        "started_at": started_at,
        "contract": selected.get("worker_card_id", "vivi-worker-queue"),
        "workflow_steps": [
            {"step_id": "load_worker_queue", "type": "WorkerQueue", "status": "completed_verified", "output": str(VIVI_WORKER_QUEUE_PATH)},
            {
                "step_id": "safe_worker_execution",
                "type": "SafeProjectWorker" if worker_mode == "safe_project_worker_v2" else "LocalArtifactWorker",
                "status": status,
                "output": str(VIVI_WORKER_LAST_RUN_PATH),
            },
        ],
        "current_step": "complete" if status in {"completed_verified", "closed_no_action"} else "local_artifact_generation",
        "approval_nodes": [],
        "verifiers": commands or [{"command": "none", "status": "closed_no_action", "returncode": None}],
        "status": status,
        "control_state": status,
        "retry_count": 0,
        "pause_resume_retry": {
            "pause": {"allowed": True, "operator_gate_required": False, "runtime_effect": "local_state_only"},
            "resume": {"allowed": status != "waiting_for_operator", "operator_gate_required": status == "waiting_for_operator", "runtime_effect": "local_state_only"},
            "retry": {"allowed": status == "failed_safe", "operator_gate_required": False, "runtime_effect": "local_artifact_only"},
        },
        "operator_actions": [],
        "failures": failures,
        "evidence": evidence,
        "memory_updates": [],
        "completed_at": completed_at,
        "runtime_action_executed": False,
        "local_artifact_write_executed": bool(selected),
        "project_id": selected.get("project_id", ""),
        "claim_type": selected.get("claim_type", ""),
        "risk_class": selected.get("risk_class", ""),
        "worker_card": selected,
        "mode": worker_mode,
    }
    payload = {
        "schema_version": 1,
        "generated_at": completed_at,
        "run_id": run_id,
        "status": status,
        "mode": worker_mode,
        "worker_card_id": selected.get("worker_card_id", ""),
        "project_id": selected.get("project_id", ""),
        "claim_type": selected.get("claim_type", ""),
        "risk_class": selected.get("risk_class", ""),
        "queue_status": queue.get("status", "UNKNOWN"),
        "runtime_action_executed": False,
        "local_artifact_write_executed": bool(selected),
        "project_verifier_executed": bool(selected and worker_mode == "safe_project_worker_v2"),
        "commands": commands,
        "failures": failures,
        "evidence": evidence,
        "next_safe_step": next_safe_step,
        "workflow_run_path": str(WORKFLOW_RUNS_DIR / f"{run_id}.json"),
        "worker_card": selected,
    }
    if write:
        write_json(VIVI_WORKER_LAST_RUN_PATH, payload)
        (OUTPUT_DIR / "vivi_worker_last_run.md").write_text(vivi_worker_to_markdown(payload), encoding="utf-8")
        WORKFLOW_RUNS_DIR.mkdir(parents=True, exist_ok=True)
        write_json(WORKFLOW_RUNS_DIR / f"{run_id}.json", workflow_run)
        (WORKFLOW_RUNS_DIR / f"{run_id}.md").write_text(execution_history_to_markdown(workflow_run), encoding="utf-8")
    return payload


def build_vivi_worker_supervisor_audit(*, write: bool = True) -> dict[str, Any]:
    worker = load_json(VIVI_WORKER_LAST_RUN_PATH, default={})
    queue = load_json(VIVI_WORKER_QUEUE_PATH, default={})
    run_id = worker.get("run_id", "") if isinstance(worker, dict) else ""
    worker_mode = worker.get("mode", "") if isinstance(worker, dict) else ""
    workflow_run_path = Path(str(worker.get("workflow_run_path", ""))) if isinstance(worker, dict) and worker.get("workflow_run_path") else Path()
    workflow_run = load_json(workflow_run_path, default={}) if workflow_run_path else {}
    findings: list[dict[str, Any]] = []
    status = "PASS"
    truth_status = "completed_verified_safe_project_worker" if worker_mode == "safe_project_worker_v2" else "completed_verified_local_artifact_worker"
    next_safe_step = "No worker supervisor action needed; refreshed local artifacts are evidence, not execution approval."

    def add_finding(severity: str, code: str, message: str) -> None:
        findings.append({"severity": severity, "code": code, "message": message})

    if not isinstance(worker, dict) or not worker:
        status = "WARN"
        truth_status = "missing_worker_record"
        add_finding("WARN", "missing_worker", "Vivi Worker record is missing.")
        next_safe_step = "Run `python3 scripts/project_intelligence_graph/pig.py vivi-worker` when a safe local worker card exists."
    elif worker.get("runtime_action_executed") is True:
        status = "FAIL"
        truth_status = "unsafe_runtime_action_detected"
        add_finding("FAIL", "runtime_action_executed", "Worker reported a runtime action; MVP must stay local-artifact only.")
        next_safe_step = "Stop and inspect worker output before accepting the run."
    elif worker.get("status") not in {"completed_verified", "closed_no_action", "waiting_for_operator", "failed_safe"}:
        status = "FAIL"
        truth_status = "invalid_worker_status"
        add_finding("FAIL", "invalid_worker_status", f"Worker status is `{worker.get('status', 'UNKNOWN')}`.")
    if isinstance(worker, dict) and worker_mode == "safe_project_worker_v2":
        if worker.get("project_id") in (None, "") or worker.get("claim_type") in (None, ""):
            status = "FAIL"
            truth_status = "missing_project_claim_contract"
            add_finding("FAIL", "missing_project_claim_contract", "Safe Project Worker run is missing project_id or claim_type.")
        if worker.get("claim_type") not in VIVI_SAFE_PROJECT_WORKER_CLAIM_TYPES:
            status = "FAIL"
            truth_status = "unsupported_project_claim_type"
            add_finding("FAIL", "unsupported_project_claim_type", f"Project claim type is `{worker.get('claim_type', '')}`.")
    if run_id and not workflow_run:
        status = "FAIL"
        truth_status = "missing_execution_history"
        add_finding("FAIL", "missing_execution_history", f"Workflow run `{run_id}` is missing.")
    if isinstance(workflow_run, dict) and workflow_run:
        if workflow_run.get("runtime_action_executed") is True:
            status = "FAIL"
            truth_status = "unsafe_runtime_action_detected"
            add_finding("FAIL", "workflow_runtime_action", "Execution History reports a runtime action.")
        if workflow_run.get("mode") != worker_mode:
            status = "FAIL"
            truth_status = "execution_history_mode_mismatch"
            add_finding("FAIL", "mode_mismatch", "Worker record and Execution History mode differ.")
    if isinstance(worker, dict) and worker.get("status") == "failed_safe":
        status = "WARN" if status == "PASS" else status
        truth_status = "failed_safe_waiting_for_fix"
        add_finding("WARN", "worker_failed_safe", "One or more local worker commands failed safely.")
        next_safe_step = "Inspect command failures and rerun only the same allowlisted local worker card."
    if isinstance(worker, dict) and worker.get("status") == "closed_no_action":
        truth_status = "closed_no_action"
        next_safe_step = "No ready worker card exists; monitor queue and keep Operator-Go gates intact."
    if isinstance(worker, dict) and worker_mode == "safe_project_worker_v2" and worker.get("status") == "completed_verified" and status == "PASS":
        if worker.get("claim_type") == "generated_artifact_review":
            next_safe_step = "Generated-artifact review claim is accepted as local evidence; cleanup, commit, push, delete, rerun and publish remain operator-gated."
        else:
            next_safe_step = "Safe project verifier claim is accepted as local evidence; do not change project status, visibility, data, publish, push or delete without the relevant gate."
    if isinstance(queue, dict) and queue.get("ready_count", 0) and worker.get("status") == "closed_no_action":
        status = "WARN" if status == "PASS" else status
        add_finding("WARN", "ready_queue_not_run", "Worker queue has ready cards but last run is closed_no_action.")

    payload = {
        "schema_version": 1,
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": status,
        "truth_status": truth_status,
        "run_id": run_id,
        "worker_status": worker.get("status", "UNKNOWN") if isinstance(worker, dict) else "UNKNOWN",
        "worker_card_id": worker.get("worker_card_id", "") if isinstance(worker, dict) else "",
        "mode": worker_mode,
        "project_id": worker.get("project_id", "") if isinstance(worker, dict) else "",
        "claim_type": worker.get("claim_type", "") if isinstance(worker, dict) else "",
        "risk_class": worker.get("risk_class", "") if isinstance(worker, dict) else "",
        "runtime_action_executed": worker.get("runtime_action_executed", None) if isinstance(worker, dict) else None,
        "local_artifact_write_executed": worker.get("local_artifact_write_executed", None) if isinstance(worker, dict) else None,
        "project_verifier_executed": worker.get("project_verifier_executed", None) if isinstance(worker, dict) else None,
        "workflow_run_path": str(workflow_run_path) if workflow_run_path else "",
        "command_summary": {
            "total": len(worker.get("commands", [])) if isinstance(worker, dict) else 0,
            "passed": len([item for item in worker.get("commands", []) if item.get("status") == "PASS"]) if isinstance(worker, dict) else 0,
            "failed": len([item for item in worker.get("commands", []) if item.get("status") not in {"PASS"}]) if isinstance(worker, dict) else 0,
        },
        "findings": findings,
        "next_safe_step": next_safe_step,
        "notes": [
            "Supervisor is read-only.",
            "Worker success refreshes local evidence only; it is not permission to commit, cleanup, push, delete or publish.",
        ],
    }
    if write:
        write_json(VIVI_WORKER_SUPERVISOR_AUDIT_PATH, payload)
        (OUTPUT_DIR / "vivi_worker_supervisor_audit.md").write_text(vivi_worker_supervisor_to_markdown(payload), encoding="utf-8")
    return payload


def build_autonomy_governor_audit(*, write: bool = True) -> dict[str, Any]:
    registry = load_json(AUTONOMY_GOVERNOR_REGISTRY_PATH, default={})
    errors: list[str] = []
    warnings: list[str] = []
    if not isinstance(registry, dict):
        registry = {}
        errors.append("autonomy governor registry is not a JSON object")
    for field in ["schema_version", "status", "purpose", "completion_rule", "operator_gates", "workstreams"]:
        if registry.get(field) in (None, "", [], {}):
            errors.append(f"registry missing {field}")

    workstreams = registry.get("workstreams", [])
    if not isinstance(workstreams, list) or not workstreams:
        workstreams = []
        errors.append("registry workstreams must be a non-empty list")

    required_fields = [
        "workstream_id",
        "title",
        "project_id",
        "priority",
        "status",
        "operator_goal",
        "target_picture",
        "next_safe_step",
        "allowed_actions",
        "forbidden_actions",
        "verifiers",
        "evidence",
        "memory_targets",
        "refill_policy",
        "done_definition",
    ]
    valid_statuses = {"ready", "in_progress", "blocked_operator_gate", "monitoring", "completed_verified", "parked"}
    valid_priorities = {"P0", "P1", "P2", "P3"}
    items: list[dict[str, Any]] = []
    counts: dict[str, int] = defaultdict(int)
    ready_safe_work: list[dict[str, Any]] = []
    blocked_gates: list[dict[str, Any]] = []
    for entry in workstreams:
        if not isinstance(entry, dict):
            errors.append("workstream entry is not an object")
            continue
        workstream_id = str(entry.get("workstream_id") or "unknown")
        missing = [field for field in required_fields if entry.get(field) in (None, "", [], {})]
        status = str(entry.get("status") or "unknown")
        priority = str(entry.get("priority") or "unknown")
        if status not in valid_statuses:
            missing.append("valid status")
        if priority not in valid_priorities:
            missing.append("valid priority")
        for pathish in entry.get("evidence", []):
            text_path = str(pathish)
            if text_path.startswith("/") and not Path(text_path).exists():
                warnings.append(f"{workstream_id} evidence path missing: {text_path}")
        item_status = "FAIL" if missing else "PASS"
        counts[status] += 1
        item = {
            "workstream_id": workstream_id,
            "title": entry.get("title", ""),
            "project_id": entry.get("project_id", ""),
            "priority": priority,
            "status": status,
            "audit_status": item_status,
            "missing_fields": missing,
            "next_safe_step": entry.get("next_safe_step", ""),
            "operator_gates": entry.get("operator_gates", []),
            "verifiers": entry.get("verifiers", []),
            "refill_policy": entry.get("refill_policy", ""),
        }
        items.append(item)
        if item_status == "FAIL":
            errors.append(f"{workstream_id} missing fields: {', '.join(missing)}")
        if status in {"ready", "in_progress"}:
            ready_safe_work.append(item)
        if status == "blocked_operator_gate" or entry.get("operator_gates"):
            blocked_gates.append(item)

    queue = load_json(AUTONOMY_EXECUTION_QUEUE_PATH, default={})
    queue_ready_items: list[dict[str, Any]] = []
    if isinstance(queue, dict) and queue.get("status") in {"PASS", "WARN"}:
        for block in queue.get("blocks", []):
            if not isinstance(block, dict) or block.get("status") not in {"ready", "in_progress"}:
                continue
            queue_item = {
                "workstream_id": f"autonomy-queue:{block.get('block_id', 'unknown')}",
                "title": block.get("title", "Autonomy Execution Queue Block"),
                "project_id": ",".join(block.get("affected_projects", [])) or "agent_ops",
                "priority": block.get("priority", "P1"),
                "status": block.get("status"),
                "audit_status": "PASS",
                "missing_fields": [],
                "next_safe_step": block.get("goal", ""),
                "operator_gates": block.get("forbidden_actions", []),
                "verifiers": block.get("verifiers", []),
                "refill_policy": "Autonomy execution queue block is the concrete next step derived from latest operator intent.",
                "source": str(AUTONOMY_EXECUTION_QUEUE_PATH),
            }
            items.append(queue_item)
            counts[str(queue_item["status"])] += 1
            ready_safe_work.append(queue_item)
            queue_ready_items.append(queue_item)

    latest_intent = load_json(LATEST_OPERATOR_INTENT_CONTRACT_PATH, default={})
    if not queue_ready_items and isinstance(latest_intent, dict) and latest_intent.get("status") in {"draft", "ready_to_build"}:
        intent_status = "ready" if latest_intent.get("status") == "ready_to_build" else "in_progress"
        intent_item = {
            "workstream_id": f"operator-intent:{latest_intent.get('intent_id', 'latest')}",
            "title": "Materialized Operator Intent Contract",
            "project_id": ",".join(latest_intent.get("affected_projects", [])) or "agent_ops",
            "priority": "P0",
            "status": intent_status,
            "audit_status": "PASS",
            "missing_fields": [],
            "next_safe_step": latest_intent.get("next_safe_block", "Use latest Operator Intent Contract to select the next safe local implementation block."),
            "operator_gates": latest_intent.get("operator_gates", []),
            "verifiers": latest_intent.get("verifier_plan", []),
            "refill_policy": "Materialized operator intent is a refill source when the static registry has no ready workstreams.",
            "source": str(LATEST_OPERATOR_INTENT_CONTRACT_PATH),
        }
        items.append(intent_item)
        counts[intent_status] += 1
        ready_safe_work.append(intent_item)

    endgame = build_endgame_roadmap(write=True)
    for block in endgame.get("safe_next_blocks", []):
        if not isinstance(block, dict):
            continue
        endgame_item = {
            "workstream_id": f"endgame:{block.get('block_id', 'unknown')}",
            "title": block.get("title", "Endgame Roadmap Block"),
            "project_id": ",".join(block.get("affected_projects", [])) or "cross_project",
            "priority": block.get("priority", "P1"),
            "status": "ready",
            "audit_status": "PASS",
            "missing_fields": [],
            "next_safe_step": block.get("next_safe_step", ""),
            "operator_gates": block.get("operator_gates", []),
            "verifiers": block.get("verifiers", []),
            "refill_policy": "Endgame Roadmap Governor refills the next large safe block after local block completion.",
            "source": str(ENDGAME_ROADMAP_PATH),
        }
        items.append(endgame_item)
        counts["ready"] += 1
        ready_safe_work.append(endgame_item)

    upstream = {
        "operator_brief": load_json(OPERATOR_BRIEF_PATH, default={}).get("overall_status", "UNKNOWN"),
        "long_run_completion": load_json(LONG_RUN_COMPLETION_AUDIT_PATH, default={}).get("status", "UNKNOWN"),
        "rule_propagation": load_json(RULE_PROPAGATION_AUDIT_PATH, default={}).get("status", "UNKNOWN"),
        "project_invariants": load_json(PROJECT_INVARIANT_AUDIT_PATH, default={}).get("status", "UNKNOWN"),
        "agent_entrypoints": load_json(AGENT_ENTRYPOINT_AUDIT_PATH, default={}).get("status", "UNKNOWN"),
        "operator_intent": load_json(OPERATOR_INTENT_CONTRACT_AUDIT_PATH, default={}).get("status", "UNKNOWN"),
        "vault_hygiene": load_json(VAULT_UMLAUT_HYGIENE_PATH, default={}).get("status", "UNKNOWN"),
    }
    for name, value in upstream.items():
        if value not in {"PASS", "WARN", "CLEAR", "REVIEW", "ACTION_REQUIRED"}:
            warnings.append(f"upstream {name} has status {value}")

    autonomy_state = "work_available" if ready_safe_work else ("operator_gated_or_monitoring" if blocked_gates else "closed_verified_no_safe_work")
    payload = {
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": "FAIL" if errors else "PASS",
        "autonomy_state": autonomy_state,
        "registry_status": str(registry.get("status", "unknown")),
        "workstreams_checked": len(items),
        "ready_or_in_progress_count": len(ready_safe_work),
        "blocked_or_gated_count": len(blocked_gates),
        "completed_verified_count": counts.get("completed_verified", 0),
        "monitoring_count": counts.get("monitoring", 0),
        "parked_count": counts.get("parked", 0),
        "safe_work_remaining": bool(ready_safe_work),
        "next_safe_steps": [
            {
                "workstream_id": item["workstream_id"],
                "priority": item["priority"],
                "next_safe_step": item["next_safe_step"],
            }
            for item in sorted(ready_safe_work, key=lambda row: row.get("priority", "P9"))
        ],
        "blocked_gates": [
            {
                "workstream_id": item["workstream_id"],
                "priority": item["priority"],
                "operator_gates": item["operator_gates"],
                "next_safe_step": item["next_safe_step"],
            }
            for item in blocked_gates
        ],
        "upstream_status": upstream,
        "endgame_roadmap": {
            "status": endgame.get("status", "UNKNOWN"),
            "completion_percent": endgame.get("completion_percent", 0),
            "current_phase": endgame.get("current_phase", ""),
            "safe_next_block_count": len(endgame.get("safe_next_blocks", [])),
            "path": str(ENDGAME_ROADMAP_PATH),
        },
        "completion_rule": registry.get("completion_rule", ""),
        "errors": errors,
        "warnings": warnings,
        "items": items,
        "source": str(AUTONOMY_GOVERNOR_REGISTRY_PATH),
    }
    if write:
        write_json(AUTONOMY_GOVERNOR_AUDIT_PATH, payload)
        lines = [
            "# Autonomy Governor Audit",
            "",
            f"- Status: `{payload['status']}`",
            f"- Autonomy state: `{payload['autonomy_state']}`",
            f"- Workstreams checked: `{payload['workstreams_checked']}`",
            f"- Ready/in progress: `{payload['ready_or_in_progress_count']}`",
            f"- Blocked/gated: `{payload['blocked_or_gated_count']}`",
            f"- Completed verified: `{payload['completed_verified_count']}`",
            "",
            "## Next Safe Steps",
            "",
        ]
        for item in payload["next_safe_steps"]:
            lines.append(f"- `{item['priority']}` `{item['workstream_id']}`: {item['next_safe_step']}")
        lines.extend(["", "## Workstreams", ""])
        for item in items:
            lines.append(f"- `{item['audit_status']}` `{item['status']}` `{item['priority']}` `{item['workstream_id']}`: {item['next_safe_step']}")
        if errors:
            lines.extend(["", "## Errors", ""])
            lines.extend(f"- {item}" for item in errors)
        if warnings:
            lines.extend(["", "## Warnings", ""])
            lines.extend(f"- {item}" for item in warnings[:40])
        (OUTPUT_DIR / "autonomy_governor_audit.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return payload


def endgame_roadmap_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# DreamFactory Endgame Roadmap",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Completion: `{payload.get('completion_percent', 0)}%`",
        f"- Foundation completion: `{payload.get('foundation_completion_percent', 0)}%`",
        f"- Macro completion: `{payload.get('macro_completion_percent', 0)}%`",
        f"- Current phase: `{payload.get('current_phase', '')}`",
        f"- Safe next blocks: `{len(payload.get('safe_next_blocks', []))}`",
        f"- Operator gates: `{len(payload.get('operator_gates', []))}`",
        f"- Completion note: {payload.get('completion_note', '')}",
        "",
        "## Phases",
        "",
    ]
    for phase in payload.get("phases", []):
        lines.append(f"### {phase.get('phase_id', 'phase')} - {phase.get('title', '')}")
        for key in ["status", "priority", "target_picture", "next_safe_step", "done_definition"]:
            lines.append(f"- `{key}`: {record_value(phase.get(key, ''))}")
        if phase.get("operator_gates"):
            lines.append(f"- `operator_gates`: {record_value(phase.get('operator_gates'))}")
        if phase.get("verifiers"):
            lines.append(f"- `verifiers`: {record_value(phase.get('verifiers'))}")
        lines.append("")
    if payload.get("safe_next_blocks"):
        lines.extend(["## Nächste sichere große Blöcke", ""])
        for block in payload.get("safe_next_blocks", []):
            lines.append(f"- `{block.get('priority', 'P1')}` `{block.get('block_id', 'block')}`: {block.get('next_safe_step', '')}")
    if payload.get("macro_backlog"):
        lines.extend(["", "## Makro-Backlog", ""])
        for block in payload.get("macro_backlog", []):
            lines.append(f"- `{block.get('status', 'unknown')}` `{block.get('block_id', 'block')}`: {block.get('title', '')}")
    if payload.get("operator_gates"):
        lines.extend(["", "## Operator-Gates", ""])
        for gate in payload.get("operator_gates", []):
            lines.append(f"- `{gate.get('phase_id', 'phase')}`: {gate.get('gate', '')}")
    return "\n".join(lines) + "\n"


def audit_lioncom_operator_cockpit_v2(surface: dict[str, Any]) -> dict[str, Any]:
    """Check whether the LIONCOM cockpit actually exposes the macro roadmap surface."""
    capabilities = surface.get("control_capabilities", {}) if isinstance(surface, dict) else {}
    governance = surface.get("governance", {}) if isinstance(surface, dict) else {}
    propagation = surface.get("systemwide_rule_propagation", {}) if isinstance(surface, dict) else {}
    endgame = propagation.get("endgame_roadmap", {}) if isinstance(propagation, dict) else {}
    portfolio_page = read_text_if_exists(LIONCOM_PORTFOLIO_PAGE_PATH)
    types = read_text_if_exists(LIONCOM_TYPES_PATH)
    verifier = read_text_if_exists(LIONCOM_PLANNING_SURFACE_VERIFIER_PATH)
    checks = [
        {
            "check_id": "surface_has_endgame_capability",
            "status": "PASS" if capabilities.get("endgame_roadmap") is True else "FAIL",
            "evidence": str(QUALITY_OS_SURFACE_PATH),
        },
        {
            "check_id": "surface_has_macro_completion_fields",
            "status": "PASS"
            if {
                "endgame_foundation_completion_percent",
                "endgame_macro_completion_percent",
            }.issubset(set(governance.keys()))
            else "FAIL",
            "evidence": str(QUALITY_OS_SURFACE_PATH),
        },
        {
            "check_id": "surface_has_safe_macro_blocks",
            "status": "PASS"
            if isinstance(endgame.get("safe_next_blocks"), list)
            and isinstance(endgame.get("macro_backlog"), list)
            and len(endgame.get("safe_next_blocks", [])) >= 1
            else "FAIL",
            "evidence": str(QUALITY_OS_SURFACE_PATH),
        },
        {
            "check_id": "portfolio_ui_has_endgame_panel",
            "status": "PASS"
            if all(term in portfolio_page for term in ["Endgame Makro-Roadmap", "Nächste sichere Großblöcke", "Makro-Backlog"])
            else "FAIL",
            "evidence": str(LIONCOM_PORTFOLIO_PAGE_PATH),
        },
        {
            "check_id": "types_have_endgame_surface",
            "status": "PASS" if "macro_backlog?: Array<" in types and "endgame_macro_completion_percent" in types else "FAIL",
            "evidence": str(LIONCOM_TYPES_PATH),
        },
        {
            "check_id": "verifier_covers_endgame_surface",
            "status": "PASS"
            if "Surface enthält Endgame Makro-Roadmap" in verifier and "Portfolio UI zeigt Endgame Makro-Roadmap" in verifier
            else "FAIL",
            "evidence": str(LIONCOM_PLANNING_SURFACE_VERIFIER_PATH),
        },
    ]
    pass_count = len([check for check in checks if check.get("status") == "PASS"])
    return {
        "status": "PASS" if pass_count == len(checks) else "WARN",
        "check_count": len(checks),
        "pass_count": pass_count,
        "runtime_action_executed": False,
        "checks": checks,
        "required_verifiers": [
            "node scripts/verify_planning_quality_surface.mjs",
            "npm run verify:portfolio-status",
            "npm run verify:control-plane-v2:static",
            "npm run build",
        ],
    }


def build_endgame_roadmap(*, write: bool = True) -> dict[str, Any]:
    """Materialize the multi-week end vision as a machine-readable refill plan."""
    commit_cleanup = load_json(COMMIT_CLEANUP_GO_PACKAGE_PATH, default={})
    fresh_data = load_json(FRESH_DATA_INTAKE_PATH, default={})
    vivi_job_cards = apply_vivi_job_card_completion_state(load_json(VIVI_JOB_CARD_QUEUE_PATH, default={}))
    vivi_runner = load_json(VIVI_RUNNER_LAST_RUN_PATH, default={})
    vivi_supervisor = load_json(VIVI_SUPERVISOR_AUDIT_PATH, default={})
    vivi_worker_queue = load_json(VIVI_WORKER_QUEUE_PATH, default={})
    vivi_worker = load_json(VIVI_WORKER_LAST_RUN_PATH, default={})
    vivi_worker_supervisor = load_json(VIVI_WORKER_SUPERVISOR_AUDIT_PATH, default={})
    surface = load_json(QUALITY_OS_SURFACE_PATH, default={})
    soak = load_json(AUTONOMY_SOAK_AUDIT_PATH, default={})
    capability_matrix = load_json(VIVI_CAPABILITY_MATRIX_PATH, default={})
    project_verticals = load_json(PROJECT_VERTICAL_ROLLOUT_PATH, default={})
    launch_readiness = load_json(LAUNCH_READINESS_PATH, default={})
    dirt = load_json(AUTONOMY_DIRT_BACKLOG_SCAN_PATH, default={})
    rule_propagation = load_json(RULE_PROPAGATION_AUDIT_PATH, default={})
    project_invariants = load_json(PROJECT_INVARIANT_AUDIT_PATH, default={})
    agent_entrypoints = load_json(AGENT_ENTRYPOINT_AUDIT_PATH, default={})

    foundation_ok = all([
        fresh_data.get("status") in {"PASS", "WARN"},
        vivi_job_cards.get("status") == "PASS",
        vivi_job_cards.get("ready_count", 1) == 0,
        vivi_runner.get("status") in {"completed_verified", "closed_no_action"},
        vivi_supervisor.get("status") == "PASS",
        vivi_worker_queue.get("status") == "PASS",
        vivi_worker_queue.get("ready_count", 1) == 0,
        vivi_worker.get("status") == "completed_verified",
        vivi_worker.get("runtime_action_executed") is False,
        vivi_worker_supervisor.get("status") == "PASS",
        surface.get("status") == "PASS",
    ])
    commit_cleanup_status = commit_cleanup.get("status", "UNKNOWN")
    commit_cleanup_closed = commit_cleanup_status in {"completed_verified", "closed_verified", "closed_no_action"}
    soak_ok = soak.get("status") == "PASS" and soak.get("loop_count", 0) >= 3
    capability_matrix_ok = (
        capability_matrix.get("status") == "PASS"
        and capability_matrix.get("ready_claim_type_count", 0) >= 3
        and capability_matrix.get("verified_claim_type_count", 0) >= 1
        and capability_matrix.get("runtime_action_executed") is False
    )
    propagation_ok = (
        rule_propagation.get("status") == "PASS"
        and project_invariants.get("status") == "PASS"
        and agent_entrypoints.get("status") == "PASS"
    )
    lioncom_operator_cockpit_v2 = audit_lioncom_operator_cockpit_v2(surface)
    lioncom_cockpit_ok = propagation_ok and lioncom_operator_cockpit_v2.get("status") == "PASS"
    project_verticals_ok = (
        project_verticals.get("status") == "PASS"
        and project_verticals.get("runtime_action_executed") is False
        and project_verticals.get("project_count", 0) >= 4
        and project_verticals.get("missing_verifier_count", 1) == 0
    )
    launch_readiness_ok = (
        launch_readiness.get("status") == "PASS"
        and launch_readiness.get("runtime_action_executed") is False
        and launch_readiness.get("package_count", 0) >= 3
    )

    phases = [
        {
            "phase_id": "foundation-quality-os-rails",
            "title": "Quality OS, PIG, Job Cards, Worker und Operator Surface",
            "priority": "P0",
            "status": "completed_verified" if foundation_ok else "ready",
            "affected_projects": ["project_intelligence_graph", "lioncom", "agent_ops"],
            "target_picture": "Vega/Vivi arbeiten über maschinenlesbare Contracts, Job Cards, Execution History, Supervisor und Operator Surface.",
            "next_safe_step": "Foundation grün halten; bei Regression sofort PIG full-check und Surface-Verifier laufen lassen.",
            "done_definition": "PIG full-check PASS, Worker Queue ready_count=0, Runtime-Actionschutz false, Operator Surface PASS.",
            "operator_gates": [],
            "verifiers": [
                "python3 scripts/project_intelligence_graph/pig.py full-check",
                "node scripts/verify_planning_quality_surface.mjs",
            ],
        },
        {
            "phase_id": "commit-cleanup-operator-go",
            "title": "Commit-/Cleanup-/Branch-Hygiene mit Operator-Go",
            "priority": "P1",
            "status": "completed_verified" if commit_cleanup_closed else "blocked_operator_gate",
            "affected_projects": ["lioncom", "room16", "kanzlei_ai_assist", "agent_ops"],
            "target_picture": "Reviewed lokale Arbeit kann sauber committed oder bewusst stehen gelassen werden, ohne dass Vega selbst Commit, Cleanup, Push oder Delete ausführt.",
            "next_safe_step": "Operator-Go Paket lesen, lokale Review-Evidence aktuell halten und ohne explizites Go keinen Commit, Cleanup, Push oder Delete ausführen.",
            "done_definition": "Operator-Go liegt vor oder Package bleibt mit runtime_action_executed=false sichtbar.",
            "operator_gates": ["commit", "cleanup", "push", "delete"],
            "verifiers": ["python3 scripts/project_intelligence_graph/pig.py commit-cleanup-package"],
        },
        {
            "phase_id": "autonomy-soak-test",
            "title": "Autonomie-Soak-Test ohne externe Wirkung",
            "priority": "P1",
            "status": "completed_verified" if soak_ok else "ready",
            "affected_projects": ["project_intelligence_graph", "lioncom", "agent_ops"],
            "target_picture": "Mehrere autonome Schleifen laufen reproduzierbar durch, ohne neue Schein-Arbeit, ohne Runtime-Aktion und ohne falsche Completion-Claims.",
            "next_safe_step": "Lokalen Autonomy Soak ausführen und danach Endgame Roadmap neu materialisieren.",
            "done_definition": "Mindestens 3 Schleifen PASS, Worker/Job ready_count=0, Runtime-Actionschutz false, Surface-Verifier PASS.",
            "operator_gates": [],
            "verifiers": ["python3 scripts/project_intelligence_graph/pig.py autonomy-soak"],
        },
        {
            "phase_id": "vivi-worker-capability-expansion",
            "title": "Vivi vom Artefakt-Worker zum sicheren Projekt-Worker erweitern",
            "priority": "P1",
            "status": "completed_verified" if capability_matrix_ok else ("ready" if soak_ok else "waiting_for_soak"),
            "affected_projects": ["project_intelligence_graph", "kanzlei_ai_assist", "lioncom"],
            "target_picture": "Vivi darf kleine deterministische Projektclaims ausführen, aber nur mit Allowlist, Diff/Evidence, Verifier und Vega/PIG-Supervisor.",
            "next_safe_step": "Capability-Matrix und erste erlaubte Projektclaim-Typen materialisieren, ohne externe Wirkung.",
            "done_definition": "Capability-Matrix, Allowlist, Runner-Vertrag und Supervisor-Gate existieren; erste lokale Claim-Klasse ist grün verifiziert.",
            "operator_gates": ["echte Mandantendaten", "Auth/Credentials", "Production", "externe Kommunikation"],
            "verifiers": [
                "python3 scripts/project_intelligence_graph/pig.py full-check",
                "projektlokale Verifier je Claim-Klasse",
            ],
        },
        {
            "phase_id": "cross-project-propagation-engine",
            "title": "Cross-Project Propagation Engine",
            "priority": "P1",
            "status": "completed_verified" if propagation_ok else ("ready" if capability_matrix_ok else "monitoring"),
            "affected_projects": ["project_intelligence_graph", "agent_ops", "lioncom", "room16", "kanzlei_ai_assist"],
            "target_picture": "Neue Regeln werden nicht nur lokal gefixt, sondern über Rule Propagation, Project Invariants, Agent Entrypoints und Impact Radius systemweit geprüft.",
            "next_safe_step": "Rule Propagation, Project Invariants, Agent Entrypoints und Impact Radius nach jeder neuen Regel ausführen; offene Targets als eigene Karten führen.",
            "done_definition": "Rule Propagation PASS, Project Invariants PASS, Agent Entrypoints PASS und Impact-Radius-Check für neue Regeln grün.",
            "operator_gates": [],
            "verifiers": [
                "python3 scripts/project_intelligence_graph/pig.py rule-propagation",
                "python3 scripts/project_intelligence_graph/pig.py project-invariants",
                "python3 scripts/project_intelligence_graph/pig.py agent-entrypoints",
                "python3 scripts/project_intelligence_graph/pig.py impact-radius --text \"operator correction\"",
            ],
        },
        {
            "phase_id": "lioncom-operator-cockpit-v2",
            "title": "LIONCOM Operator Cockpit v2",
            "priority": "P1",
            "status": "completed_verified" if lioncom_cockpit_ok else ("ready" if propagation_ok else "monitoring"),
            "affected_projects": ["lioncom", "project_intelligence_graph", "agent_ops"],
            "target_picture": "Björn sieht in LIONCOM nicht nur grüne PIG-Checks, sondern Makro-Roadmap, nächste sichere Blöcke, Gates, Verifier-Timeline, Dirt und Stop-Gründe ohne Terminal.",
            "next_safe_step": "LIONCOM/PIG Operator Surface um Makro-Roadmap, sichere nächste große Blöcke und Gate-Gründe erweitern; keine echten Runtime-Controls ausführen.",
            "done_definition": "Project Control Tower zeigt Makro-Roadmap, Safe Next Blocks, Operator-Gates, Dirt, Verifier und Execution History; Surface-Verifier prüft die Panels.",
            "operator_gates": ["echte Pause/Resume/Retry-Ausführung", "Automation erstellen/ändern/löschen", "push", "publish", "production"],
            "verifiers": [
                "node scripts/verify_planning_quality_surface.mjs",
                "npm run verify:portfolio-status",
                "npm run verify:control-plane-v2:static",
            ],
            "evidence": lioncom_operator_cockpit_v2,
        },
        {
            "phase_id": "project-vertical-rollout",
            "title": "Room16, Kanzlei, Utility, Membership als feste Systeme führen",
            "priority": "P2",
            "status": "completed_verified" if project_verticals_ok else ("ready" if capability_matrix_ok else "monitoring"),
            "affected_projects": ["room16", "kanzlei_ai_assist", "utility_websites", "membership_finanzplattform"],
            "target_picture": "Jedes Projekt hat eigene Queues, Golden Cases, Verifier, State Machines, Operator Surface und Gate-Status.",
            "next_safe_step": "Nach Vivi-Capability-Expansion je Projekt nur lokale Verifier-/Surface-/Schema-Lücken schließen.",
            "done_definition": "Projekt-Rails laufen ohne Chat-only-Arbeit; riskante Wirkung bleibt Operator-Gate.",
            "operator_gates": ["Room16 rerun/push/publish", "financial-advice publishing", "echte Personen-/Mandantendaten"],
            "verifiers": [
                "cd company-dossier-lab/room16-app && npm run verify:german-output-quality",
                "python3 scripts/verify/verify_all.py",
            ],
        },
        {
            "phase_id": "launch-revenue-flows",
            "title": "Launch-, Revenue-, Provider- und Public-Flows",
            "priority": "P3",
            "status": "completed_verified" if launch_readiness_ok else "ready",
            "affected_projects": ["membership_finanzplattform", "utility_websites", "lioncom"],
            "target_picture": "Launch- und Umsatzflows sind vorproduktiv vorbereitet, aber Public, Payment, Provider, Auth und externe Kommunikation passieren nur mit Björns Go.",
            "next_safe_step": "Lokale Launch-Readiness-Pakete vorbereiten; keine Provider-, Payment-, Public- oder Auth-Aktion ohne Operator-Go.",
            "done_definition": "Launch-Handoff ist vollständig, Gate-Entscheidungen sind explizit, alle Checks frisch.",
            "operator_gates": ["Public", "Production", "Geld", "Credentials/Auth", "externe Kommunikation"],
            "verifiers": ["projektspezifische Launch-/Preflight-Verifier"],
        },
    ]

    foundation_phase_ids = {
        "foundation-quality-os-rails",
        "autonomy-soak-test",
        "vivi-worker-capability-expansion",
        "cross-project-propagation-engine",
    }
    macro_phase_ids = {
        "lioncom-operator-cockpit-v2",
        "project-vertical-rollout",
        "launch-revenue-flows",
    }
    completed = len([phase for phase in phases if phase.get("status") == "completed_verified"])
    foundation_phases = [phase for phase in phases if phase.get("phase_id") in foundation_phase_ids]
    macro_phases = [phase for phase in phases if phase.get("phase_id") in macro_phase_ids]
    foundation_completed = len([phase for phase in foundation_phases if phase.get("status") == "completed_verified"])
    macro_completed = len([phase for phase in macro_phases if phase.get("status") == "completed_verified"])
    safe_next_blocks = [
        {
            "block_id": phase["phase_id"],
            "title": phase["title"],
            "priority": phase["priority"],
            "affected_projects": phase["affected_projects"],
            "next_safe_step": phase["next_safe_step"],
            "verifiers": phase["verifiers"],
            "operator_gates": phase["operator_gates"],
        }
        for phase in phases
        if phase.get("status") == "ready"
    ][:3]
    gates = [
        {"phase_id": phase["phase_id"], "gate": gate}
        for phase in phases
        for gate in phase.get("operator_gates", [])
        if phase.get("status") in {"blocked_operator_gate", "ready", "monitoring"}
    ]
    current_phase = safe_next_blocks[0]["block_id"] if safe_next_blocks else "operator_gated_or_monitoring"
    payload = {
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": "PASS" if foundation_ok else "WARN",
        "roadmap_id": "dreamfactory-endgame-2026-05-24-macro",
        "roadmap_complete": completed == len(phases),
        "completion_percent": int(round((completed / len(phases)) * 100)),
        "foundation_completion_percent": int(round((foundation_completed / len(foundation_phases)) * 100)) if foundation_phases else 0,
        "macro_completion_percent": int(round((macro_completed / len(macro_phases)) * 100)) if macro_phases else 0,
        "current_phase": current_phase,
        "safe_work_remaining": bool(safe_next_blocks),
        "safe_next_blocks": safe_next_blocks,
        "macro_backlog": [
            {
                "block_id": phase["phase_id"],
                "title": phase["title"],
                "priority": phase["priority"],
                "status": phase["status"],
                "affected_projects": phase["affected_projects"],
                "next_safe_step": phase["next_safe_step"],
                "operator_gates": phase["operator_gates"],
                "verifiers": phase["verifiers"],
            }
            for phase in phases
            if phase.get("phase_id") in macro_phase_ids
        ],
        "operator_gates": gates,
        "phase_count": len(phases),
        "completed_phase_count": completed,
        "foundation_phase_count": len(foundation_phases),
        "foundation_completed_phase_count": foundation_completed,
        "macro_phase_count": len(macro_phases),
        "macro_completed_phase_count": macro_completed,
        "blocked_or_gated_phase_count": len([phase for phase in phases if phase.get("status") == "blocked_operator_gate"]),
        "monitoring_phase_count": len([phase for phase in phases if phase.get("status") == "monitoring"]),
        "dirty_project_count": dirt.get("dirty_project_count", 0),
        "runtime_action_executed": False,
        "lioncom_operator_cockpit_v2_evidence": lioncom_operator_cockpit_v2,
        "completion_note": "Foundation-/Quality-OS-Grün ist nur die Kontrollschicht; LIONCOM Cockpit, Produktvertikalen und Launch-/Revenue-Vorbereitung bleiben Makro-Roadmap-Arbeit, solange ihre Phasen nicht completed_verified sind.",
        "source_roadmap": "/Users/BjornRosinger/Documents/Obsidian/Test Vaul Privat/Human Overview/DreamFactory System/Agent Stack/DreamFactory Endgame Backward Roadmap - 2026-05-24.md",
        "phases": phases,
    }
    if write:
        write_json(ENDGAME_ROADMAP_PATH, payload)
        (OUTPUT_DIR / "endgame_roadmap.md").write_text(endgame_roadmap_to_markdown(payload), encoding="utf-8")
    return payload


def autonomy_soak_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Autonomy Soak Audit",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Loops: `{payload.get('loop_count', 0)}`",
        f"- Runtime action executed: `{payload.get('runtime_action_executed', None)}`",
        f"- Findings: `{len(payload.get('findings', []))}`",
        "",
        "## Loops",
        "",
    ]
    for loop in payload.get("loops", []):
        lines.append(f"- `{loop.get('status')}` loop `{loop.get('loop')}`: job_ready={loop.get('vivi_job_cards_ready')} worker_ready={loop.get('vivi_worker_ready')} surface={loop.get('surface_status')}")
    if payload.get("findings"):
        lines.extend(["", "## Findings", ""])
        for finding in payload.get("findings", []):
            lines.append(f"- `{finding.get('severity', 'WARN')}` {finding.get('message', '')}")
    return "\n".join(lines) + "\n"


def run_autonomy_soak(*, loops: int = 3, write: bool = True) -> dict[str, Any]:
    loops = max(1, loops)
    findings: list[dict[str, str]] = []
    loop_results: list[dict[str, Any]] = []
    runtime_action_executed = False
    for index in range(1, loops + 1):
        endgame = build_endgame_roadmap(write=True)
        job_cards = build_vivi_job_card_queue(write=True)
        runner = run_vivi_runner_mvp(write=True)
        supervisor = build_vivi_supervisor_audit(write=True)
        worker_queue = build_vivi_worker_queue(write=True)
        worker = run_vivi_worker_mvp(write=True)
        worker_supervisor = build_vivi_worker_supervisor_audit(write=True)
        surface = build_quality_os_operator_surface(write=True)
        runtime_action_executed = runtime_action_executed or bool(runner.get("runtime_action_executed")) or bool(worker.get("runtime_action_executed"))
        loop_status = "PASS"
        checks = [
            (job_cards.get("status") == "PASS", "Vivi Job Card Queue not PASS"),
            (job_cards.get("ready_count", 0) == 0, "Vivi Job Card Queue produced ready cards during soak"),
            (runner.get("status") in {"completed_verified", "closed_no_action"}, "Vivi Runner did not close safely"),
            (supervisor.get("status") == "PASS", "Vivi Supervisor not PASS"),
            (worker_queue.get("status") == "PASS", "Vivi Worker Queue not PASS"),
            (worker_queue.get("ready_count", 0) == 0, "Vivi Worker Queue produced ready cards during soak"),
            (worker.get("status") in {"completed_verified", "closed_no_action"}, "Vivi Worker did not close safely"),
            (worker.get("runtime_action_executed") is False, "Vivi Worker executed runtime action"),
            (worker_supervisor.get("status") == "PASS", "Vivi Worker Supervisor not PASS"),
            (surface.get("status") == "PASS", "Operator Surface not PASS"),
            (endgame.get("status") in {"PASS", "WARN"}, "Endgame Roadmap invalid"),
        ]
        for ok, message in checks:
            if not ok:
                loop_status = "FAIL"
                findings.append({"severity": "FAIL", "message": f"loop {index}: {message}"})
        loop_results.append({
            "loop": index,
            "status": loop_status,
            "endgame_status": endgame.get("status", "UNKNOWN"),
            "endgame_current_phase": endgame.get("current_phase", ""),
            "vivi_job_cards_ready": job_cards.get("ready_count", 0),
            "vivi_runner_status": runner.get("status", "UNKNOWN"),
            "vivi_supervisor_status": supervisor.get("status", "UNKNOWN"),
            "vivi_worker_ready": worker_queue.get("ready_count", 0),
            "vivi_worker_status": worker.get("status", "UNKNOWN"),
            "vivi_worker_runtime_action_executed": worker.get("runtime_action_executed", None),
            "vivi_worker_supervisor_status": worker_supervisor.get("status", "UNKNOWN"),
            "surface_status": surface.get("status", "UNKNOWN"),
        })
    payload = {
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": "FAIL" if findings or runtime_action_executed else "PASS",
        "loop_count": loops,
        "runtime_action_executed": runtime_action_executed,
        "findings": findings,
        "loops": loop_results,
        "next_safe_step": "If PASS, materialize endgame-roadmap again and proceed to the next safe phase.",
    }
    if write:
        write_json(AUTONOMY_SOAK_AUDIT_PATH, payload)
        (OUTPUT_DIR / "autonomy_soak_audit.md").write_text(autonomy_soak_to_markdown(payload), encoding="utf-8")
    return payload


def vivi_capability_matrix_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Vivi Capability Matrix",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Ready claim types: `{payload.get('ready_claim_type_count', 0)}`",
        f"- Verified claim types: `{payload.get('verified_claim_type_count', 0)}`",
        f"- Blocked claim types: `{payload.get('blocked_claim_type_count', 0)}`",
        f"- Runtime action executed: `{payload.get('runtime_action_executed', None)}`",
        "",
        "## Claim Types",
        "",
    ]
    for item in payload.get("claim_types", []):
        lines.append(f"### {item.get('claim_type_id', 'claim')}")
        for key in ["status", "project_scope", "allowed_actions", "forbidden_actions", "verifier", "next_safe_step"]:
            lines.append(f"- `{key}`: {record_value(item.get(key, ''))}")
        lines.append("")
    return "\n".join(lines) + "\n"


def build_vivi_capability_matrix(*, write: bool = True) -> dict[str, Any]:
    verifier_surface = load_json(QUALITY_OS_SURFACE_PATH, default={})
    soak = load_json(AUTONOMY_SOAK_AUDIT_PATH, default={})
    room16_german = load_json(WORKSPACE / "company-dossier-lab/outputs/german_output_quality/room16_german_output_quality.json", default={})
    kanzlei_verify = load_json(WORKSPACE / "kanzlei-ai-assist/outputs/verification/latest-verify-all.json", default={})
    completed_worker_ids = {
        str(item.get("worker_card_id", ""))
        for item in completed_vivi_worker_states()
    }
    room16_german_verified = room16_german.get("status") == "PASS"
    kanzlei_verified = kanzlei_verify.get("status") == "PASS" and kanzlei_verify.get("runtime_action_executed") is False
    generated_artifact_review_verified = "vivi-worker-v2-generated-artifact-review" in completed_worker_ids
    claim_types = [
        {
            "claim_type_id": "pig_artifact_refresh",
            "status": "verified",
            "project_scope": ["project_intelligence_graph"],
            "operator_goal": "PIG-Artefakte lokal regenerieren, ohne Runtime-Wirkung.",
            "target_picture": "Vivi kann Commit/Cleanup-Paket, Operator Brief und Operator Surface aktualisieren und Supervisor-Evidence liefern.",
            "allowed_actions": [
                "python3 scripts/project_intelligence_graph/pig.py commit-cleanup-package",
                "python3 scripts/project_intelligence_graph/pig.py operator-brief",
                "python3 scripts/project_intelligence_graph/pig.py operator-surface",
            ],
            "forbidden_actions": ["commit", "cleanup", "push", "delete", "publish", "external communication", "credentials/auth"],
            "verifier": [
                "python3 scripts/project_intelligence_graph/pig.py vivi-worker",
                "python3 scripts/project_intelligence_graph/pig.py vivi-worker-supervisor",
            ],
            "evidence": [str(VIVI_WORKER_LAST_RUN_PATH), str(VIVI_WORKER_SUPERVISOR_AUDIT_PATH)],
            "next_safe_step": "Als bestehende verified Claim-Klasse halten; keine Erweiterung ohne Supervisor.",
        },
        {
            "claim_type_id": "planning_surface_verify",
            "status": "verified" if verifier_surface.get("status") == "PASS" else "ready",
            "project_scope": ["project_intelligence_graph", "lioncom"],
            "operator_goal": "Operator Surface lokal prüfen und Widersprüche zwischen PIG und LIONCOM sichtbar machen.",
            "target_picture": "Vivi kann den Surface-Verifier ausführen und nur Evidence/Handoff liefern.",
            "allowed_actions": ["node scripts/verify_planning_quality_surface.mjs"],
            "forbidden_actions": ["UI mutation", "runtime action", "automation mutation", "publish"],
            "verifier": ["node scripts/verify_planning_quality_surface.mjs"],
            "evidence": [str(QUALITY_OS_SURFACE_PATH)],
            "next_safe_step": "Für spätere LIONCOM-Surface-Claims als erste sichere Projektclaim-Klasse verwenden.",
        },
        {
            "claim_type_id": "room16_german_output_quality_verify",
            "status": "verified" if room16_german_verified else "ready",
            "project_scope": ["room16"],
            "operator_goal": "Room16-Ausgaben lokal auf deutsche Ausgabequalität prüfen, ohne Rerun, Publish oder Finanzwirkung.",
            "target_picture": "Vivi darf nur den lokalen German-Output-Verifier ausführen und Findings an Vega/PIG übergeben.",
            "allowed_actions": ["cd company-dossier-lab/room16-app && npm run verify:german-output-quality"],
            "forbidden_actions": ["Room16 rerun", "push", "publish", "financial-advice publishing", "public/member/shelf changes"],
            "verifier": ["cd company-dossier-lab/room16-app && npm run verify:german-output-quality"],
            "evidence": ["company-dossier-lab/room16-app/package.json", "company-dossier-lab/outputs/german_output_quality/room16_german_output_quality.json"],
            "next_safe_step": "Nur als Verifier-Claim nutzen; Manual Review und Promotion bleiben Gate.",
        },
        {
            "claim_type_id": "kanzlei_verify_all_dry_run",
            "status": "verified" if kanzlei_verified else "ready",
            "project_scope": ["kanzlei_ai_assist"],
            "operator_goal": "Kanzlei AI Assist deterministisch prüfen, ohne echte Mandantendaten, DATEV oder externe Wirkung.",
            "target_picture": "Vivi darf den lokalen Verify-All-Lauf ausführen und Evidence sammeln.",
            "allowed_actions": ["python3 scripts/verify/verify_all.py"],
            "forbidden_actions": ["real client data", "DATEV production", "external communication", "credentials/auth"],
            "verifier": ["cd kanzlei-ai-assist && python3 scripts/verify/verify_all.py"],
            "evidence": ["kanzlei-ai-assist/scripts/verify/verify_all.py", "kanzlei-ai-assist/outputs/verification/latest-verify-all.json"],
            "next_safe_step": "Als erste Kanzlei-Projektclaim-Klasse nutzen, sobald ein Worker pro Projektpfad isoliert ist.",
        },
        {
            "claim_type_id": "generated_artifact_review",
            "status": "verified" if generated_artifact_review_verified else "ready",
            "project_scope": ["agent_ops", "room16", "kanzlei_ai_assist", "lioncom"],
            "operator_goal": "Generierte lokale Evidence prüfen und klassifizieren, ohne Cleanup oder Löschung.",
            "target_picture": "Vivi darf Artefakt-Ownership und Verifierstatus erfassen; Cleanup bleibt Operator-Go.",
            "allowed_actions": ["python3 scripts/project_intelligence_graph/pig.py autonomy-dirt-scan --json"],
            "forbidden_actions": ["delete", "cleanup", "commit", "push", "publish", "Room16 rerun"],
            "verifier": [
                "python3 scripts/project_intelligence_graph/pig.py vivi-worker",
                "python3 scripts/project_intelligence_graph/pig.py vivi-worker-supervisor",
                "python3 scripts/project_intelligence_graph/pig.py autonomy-dirt-scan --json",
            ],
            "evidence": [
                str(AUTONOMY_DIRT_BACKLOG_SCAN_PATH),
                str(VIVI_WORKER_LAST_RUN_PATH),
                str(VIVI_WORKER_SUPERVISOR_AUDIT_PATH),
            ],
            "next_safe_step": "Als sichere Generated-Artifact-Review-Claim-Klasse verwenden; Cleanup, Commit, Push, Delete und Rerun bleiben Gate.",
        },
        {
            "claim_type_id": "external_or_irreversible_work",
            "status": "blocked_operator_gate",
            "project_scope": ["cross_project"],
            "operator_goal": "Riskante Wirkung sichtbar machen, aber nicht automatisch ausführen.",
            "target_picture": "Public, Production, Geld, Credentials/Auth, Löschung, echte Personen-/Mandantendaten und externe Kommunikation bleiben immer Gate.",
            "allowed_actions": ["prepare local handoff package", "prepare verifier plan"],
            "forbidden_actions": ["public", "production", "money", "credentials/auth", "delete", "external communication"],
            "verifier": ["python3 scripts/project_intelligence_graph/pig.py commit-cleanup-package"],
            "evidence": [str(COMMIT_CLEANUP_GO_PACKAGE_PATH)],
            "next_safe_step": "Nur Handoff vorbereiten; Operator-Go abwarten.",
        },
    ]
    required_fields = ["claim_type_id", "status", "project_scope", "operator_goal", "target_picture", "allowed_actions", "forbidden_actions", "verifier", "evidence", "next_safe_step"]
    errors = []
    for item in claim_types:
        missing = [field for field in required_fields if item.get(field) in (None, "", [], {})]
        if missing:
            errors.append({"claim_type_id": item.get("claim_type_id", "unknown"), "missing_fields": missing})
    ready_count = len([item for item in claim_types if item.get("status") in {"ready", "verified"}])
    verified_count = len([item for item in claim_types if item.get("status") == "verified"])
    blocked_count = len([item for item in claim_types if item.get("status") == "blocked_operator_gate"])
    payload = {
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": "FAIL" if errors else "PASS",
        "schema_version": 1,
        "matrix_id": "vivi-safe-project-worker-capabilities-v2",
        "ready_claim_type_count": ready_count,
        "verified_claim_type_count": verified_count,
        "blocked_claim_type_count": blocked_count,
        "soak_status": soak.get("status", "UNKNOWN"),
        "runtime_action_executed": False,
        "errors": errors,
        "claim_types": claim_types,
        "next_safe_step": "Use ready claim types to extend Vivi Worker one project/action class at a time, always with Supervisor and project verifier.",
    }
    if write:
        write_json(VIVI_CAPABILITY_MATRIX_PATH, payload)
        (OUTPUT_DIR / "vivi_capability_matrix.md").write_text(vivi_capability_matrix_to_markdown(payload), encoding="utf-8")
    return payload


def project_vertical_rollout_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Project Vertical Rollout",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Projects: `{payload.get('project_count', 0)}`",
        f"- Missing verifiers: `{payload.get('missing_verifier_count', 0)}`",
        f"- Operator-gated projects: `{payload.get('operator_gated_project_count', 0)}`",
        f"- Runtime action executed: `{payload.get('runtime_action_executed', None)}`",
        "",
        "## Projects",
        "",
    ]
    for project in payload.get("projects", []):
        lines.append(f"### {project.get('project_id', 'project')}")
        for key in ["rail_status", "operator_goal", "target_picture", "next_safe_step", "verifiers", "operator_gates"]:
            lines.append(f"- `{key}`: {record_value(project.get(key, ''))}")
        lines.append("")
    return "\n".join(lines) + "\n"


def build_project_vertical_rollout(*, write: bool = True) -> dict[str, Any]:
    fresh_data = load_json(FRESH_DATA_INTAKE_PATH, default={})
    utility_status = load_json(WORKSPACE / "outputs/utility_websites/data_maturity/latest-data-maturity-status.json", default={})
    kanzlei_verify = load_json(WORKSPACE / "kanzlei-ai-assist/outputs/verification/latest-verify-all.json", default={})
    room16_german = load_json(WORKSPACE / "company-dossier-lab/room16-app/outputs/german_output_quality/room16_german_output_quality.json", default={})
    capability_matrix = load_json(VIVI_CAPABILITY_MATRIX_PATH, default={})
    projects = [
        {
            "project_id": "room16",
            "rail_status": "gated_monitoring",
            "operator_goal": "Room16 als feste Review-/Publish-Gate-Schiene führen, ohne Rerun oder Publishing.",
            "target_picture": "Manual Review, German Output, Review Gate und Promotion-Blocker sind sichtbar und lokal prüfbar.",
            "fresh_data_signals": [
                item for item in fresh_data.get("items", []) if item.get("project_id") == "room16"
            ][:8],
            "verifiers": [
                "cd company-dossier-lab/room16-app && npm run verify:german-output-quality",
                "cd company-dossier-lab/room16-app && npm run verify:review-gate-status",
                "cd company-dossier-lab/room16-app && npm run verify:manual-review-packets",
            ],
            "verifier_evidence": [str(WORKSPACE / "company-dossier-lab/room16-app/package.json")],
            "operator_gates": ["Room16 rerun", "push", "publish", "financial-advice publishing"],
            "next_safe_step": "Nur lokale Review-/Verifier-/Surface-Lücken schließen; Manual Review und Promotion bleiben Gate.",
        },
        {
            "project_id": "kanzlei_ai_assist",
            "rail_status": "verified" if kanzlei_verify.get("status") in {"PASS", "pass"} or kanzlei_verify.get("overall_status") in {"PASS", "pass"} else "ready_for_verifier",
            "operator_goal": "Kanzlei AI Assist als deterministisches System mit Golden Cases und Verify-All führen.",
            "target_picture": "Keine echten Mandantendaten; lokale synthetische Golden Cases und Export-/Verifier-Evidence sind führend.",
            "fresh_data_signals": [
                item for item in fresh_data.get("items", []) if item.get("project_id") == "kanzlei_ai_assist"
            ][:8],
            "verifiers": ["cd kanzlei-ai-assist && python3 scripts/verify/verify_all.py"],
            "verifier_evidence": [str(WORKSPACE / "kanzlei-ai-assist/scripts/verify/verify_all.py")],
            "operator_gates": ["echte Mandantendaten", "DATEV Production", "Credentials/Auth", "externe Kommunikation"],
            "next_safe_step": "Nur synthetische/verifizierte lokale Fälle und Verify-All-Schiene erweitern.",
        },
        {
            "project_id": "utility_websites",
            "rail_status": "data_waiting" if utility_status.get("status") in {"WARN", "waiting", "needs_data"} else "monitoring",
            "operator_goal": "Utility-Websites datenreif führen statt aus Bauchgefühl zu skalieren.",
            "target_picture": "GSC/Plausible/Event-Fenster entscheiden, ob eine Website weiter ausgebaut, beobachtet oder geparkt wird.",
            "fresh_data_signals": [
                item for item in fresh_data.get("items", []) if item.get("project_id") == "utility_websites"
            ][:8],
            "verifiers": ["python3 scripts/project_intelligence_graph/build_utility_data_maturity_status.py"],
            "verifier_evidence": [str(WORKSPACE / "outputs/utility_websites/data_maturity/latest-data-maturity-status.json")],
            "operator_gates": ["externe Analytics-Zugriffe", "Publish", "Production"],
            "next_safe_step": "Datenfenster weiter beobachten; keine Launch-/SEO-Skalierung ohne Datenreife.",
        },
        {
            "project_id": "membership_finanzplattform",
            "rail_status": "operator_gate",
            "operator_goal": "Membership-/Revenue-Flows lokal vorbereiten, aber Payment, Public, Provider und Finanzpublishing gated halten.",
            "target_picture": "Preview-/Research-/Non-advice-Rails sind lokal prüfbar; echte Launch- und Geldflüsse nur mit Operator-Go.",
            "fresh_data_signals": [
                item for item in fresh_data.get("items", []) if item.get("project_id") in {"membership_finanzplattform", "quellwert"}
            ][:8],
            "verifiers": ["node mission-control-board-mirror/scripts/verify_quellwert_membership_preview.cjs"],
            "verifier_evidence": [str(WORKSPACE / "mission-control-board-mirror/scripts/verify_quellwert_membership_preview.cjs")],
            "operator_gates": ["Public", "Production", "Geld", "Credentials/Auth", "financial-advice publishing"],
            "next_safe_step": "Nur lokale Preview-/Non-advice-Handoffs vorbereiten; keine Payment-/Provider-Aktion.",
        },
    ]
    missing_verifiers = []
    for project in projects:
        evidence = [Path(path) for path in project.get("verifier_evidence", []) if str(path).startswith("/")]
        missing = [str(path) for path in evidence if not path.exists()]
        if missing:
            missing_verifiers.append({"project_id": project["project_id"], "missing": missing})
    operator_gated_count = len([project for project in projects if project.get("operator_gates")])
    status = "FAIL" if missing_verifiers else ("WARN" if any(project.get("rail_status") in {"gated_monitoring", "data_waiting", "operator_gate"} for project in projects) else "PASS")
    payload = {
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": status,
        "schema_version": 1,
        "project_count": len(projects),
        "missing_verifier_count": len(missing_verifiers),
        "operator_gated_project_count": operator_gated_count,
        "capability_matrix_status": capability_matrix.get("status", "UNKNOWN"),
        "runtime_action_executed": False,
        "missing_verifiers": missing_verifiers,
        "projects": projects,
        "next_safe_step": "Use the project rail statuses to pick only local verifier/schema/surface work; never cross project gates without Operator-Go.",
    }
    if write:
        write_json(PROJECT_VERTICAL_ROLLOUT_PATH, payload)
        (OUTPUT_DIR / "project_vertical_rollout.md").write_text(project_vertical_rollout_to_markdown(payload), encoding="utf-8")
    return payload


def launch_readiness_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Launch Readiness Package",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Packages: `{payload.get('package_count', 0)}`",
        f"- Operator gates: `{payload.get('operator_gate_count', 0)}`",
        f"- Runtime action executed: `{payload.get('runtime_action_executed', None)}`",
        "",
        "## Packages",
        "",
    ]
    for package in payload.get("packages", []):
        lines.append(f"### {package.get('package_id', 'package')}")
        for key in ["status", "target_picture", "local_ready_artifacts", "operator_gates", "forbidden_without_operator_go", "next_safe_step"]:
            lines.append(f"- `{key}`: {record_value(package.get(key, ''))}")
        lines.append("")
    return "\n".join(lines) + "\n"


def build_launch_readiness_package(*, write: bool = True) -> dict[str, Any]:
    project_verticals = load_json(PROJECT_VERTICAL_ROLLOUT_PATH, default={})
    packages = [
        {
            "package_id": "membership-non-advice-preview",
            "status": "operator_gate_prepared",
            "target_picture": "Membership-/Quellwert-Preview bleibt lokal und non-advice; Payment, Provider, Public und Auth sind gated.",
            "local_ready_artifacts": [
                "mission-control-board-mirror/scripts/verify_quellwert_membership_preview.cjs",
                "website-delivery-runner/manifests/quellwert-membership.json",
            ],
            "operator_gates": ["Public", "Production", "Geld", "Credentials/Auth", "financial-advice publishing"],
            "forbidden_without_operator_go": ["deploy", "checkout/payment", "provider setup", "member publish", "external send"],
            "verifiers": ["node mission-control-board-mirror/scripts/verify_quellwert_membership_preview.cjs"],
            "next_safe_step": "Nur lokalen Preview-/Non-advice-Handoff prüfen; keine Zahlungs- oder Public-Aktion.",
        },
        {
            "package_id": "utility-data-readiness",
            "status": "data_waiting",
            "target_picture": "Utility-Websites werden erst skaliert, wenn Datenreife belegt ist.",
            "local_ready_artifacts": [
                "outputs/utility_websites/data_maturity/latest-data-maturity-status.json",
                "scripts/project_intelligence_graph/build_utility_data_maturity_status.py",
            ],
            "operator_gates": ["external analytics access", "publish", "production"],
            "forbidden_without_operator_go": ["publish", "production change", "external analytics credential use"],
            "verifiers": ["python3 scripts/project_intelligence_graph/build_utility_data_maturity_status.py"],
            "next_safe_step": "Datenfenster beobachten und lokale Datenreife-Artefakte aktuell halten.",
        },
        {
            "package_id": "lioncom-operator-control-launch",
            "status": "operator_gate_prepared",
            "target_picture": "LIONCOM kann Operator-Go-Pakete anzeigen, aber echte Automation-Mutation bleibt gated.",
            "local_ready_artifacts": [
                "outputs/project_intelligence_graph/quality_os_operator_surface.json",
                "outputs/project_intelligence_graph/commit_cleanup_go_package.json",
            ],
            "operator_gates": ["Automation erstellen/ändern/löschen", "Pause/Resume/Retry runtime", "commit", "push"],
            "forbidden_without_operator_go": ["automation mutation", "runtime control action", "commit", "push"],
            "verifiers": ["node scripts/verify_planning_quality_surface.mjs"],
            "next_safe_step": "Operator-Surface lokal grün halten; echte Controls nur nach Björns Go.",
        },
    ]
    missing = []
    for package in packages:
        for artifact in package.get("local_ready_artifacts", []):
            path = WORKSPACE / artifact
            if not path.exists():
                missing.append({"package_id": package["package_id"], "artifact": artifact})
    status = "FAIL" if missing else "WARN"
    gate_count = sum(len(package.get("operator_gates", [])) for package in packages)
    payload = {
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": status,
        "schema_version": 1,
        "package_count": len(packages),
        "operator_gate_count": gate_count,
        "missing_artifact_count": len(missing),
        "runtime_action_executed": False,
        "project_vertical_rollout_status": project_verticals.get("status", "UNKNOWN"),
        "missing_artifacts": missing,
        "packages": packages,
        "next_safe_step": "All launch/revenue work remains local handoff preparation until Operator-Go for Public, Production, money, auth, provider or external communication.",
    }
    if write:
        write_json(LAUNCH_READINESS_PATH, payload)
        (OUTPUT_DIR / "launch_readiness_package.md").write_text(launch_readiness_to_markdown(payload), encoding="utf-8")
    return payload


def build_fresh_session_readiness_audit(*, write: bool = True) -> dict[str, Any]:
    """Check whether a fresh agent session can start from durable notes, not chat memory."""
    vault = Path("/Users/BjornRosinger/Documents/Obsidian/Test Vaul Privat/Human Overview")
    targets = [
        ("vega_start_here", vault / "VEGA_START_HERE.md", "primary vault bootstrap", "required"),
        ("latest_session_context", vault / "Latest Session Context.md", "latest handoff", "required"),
        ("backbone_home", vault / "Backbone Home.md", "vault map", "required"),
        ("canonical_index", vault / "Canonical/Canonical Index.md", "canonical rule index", "required"),
        ("autonomous_delivery_workflow", vault / "DreamFactory System/Agent Stack/Vega + Vivi Autonomous Delivery Workflow.md", "autonomy workflow", "required"),
        ("board_rails_autonomy", vault / "Canonical/Features/Feature - Board Rails and Autonomy.md", "LIONCOM autonomy feature", "recommended"),
        ("pig_system_note", vault / "Canonical/Systems/System - Project Intelligence Graph.md", "PIG canonical system note", "required"),
        ("learnings_and_fixes", vault / "Memory/Learnings and Fixes.md", "durable operator learnings", "required"),
        ("workspace_agents", WORKSPACE / "AGENTS.md", "workspace agent entrypoint", "required"),
        ("claude_portable", WORKSPACE / "CLAUDE.md", "portable agent runbook", "recommended"),
        ("pig_readme", DOCS_DIR / "README.md", "PIG technical runbook", "required"),
    ]
    field_terms = {
        "purpose": ["zweck", "kurzbild", "purpose", "warum", "ziel"],
        "status": ["status", "active", "pass", "warn", "fertig", "ready"],
        "synonyms_or_aliases": ["aliases", "synonyme", "suchbegriffe", "vega", "vivi", "pig", "autonomy governor"],
        "boundaries_or_gates": ["gate", "operator", "nicht", "do not", "stop", "grenzen", "blocked"],
        "evidence_or_verifier": ["verifier", "check", "pruef", "prüf", "python3", "npm run", "evidence"],
        "next_safe_step": ["naechster", "nächster", "next", "weiter", "safe work", "sicherer schritt"],
        "cross_links_or_paths": ["[[", "`/", "/Users/", "outputs/project_intelligence_graph", "docs/project-intelligence-graph"],
    }
    items: list[dict[str, Any]] = []
    required_failures = 0
    warning_count = 0
    for target_id, path, role, requiredness in targets:
        exists = path.exists()
        text = path.read_text(encoding="utf-8") if exists else ""
        normalized = normalize_for_match(text)
        checks = {"exists": exists}
        if exists:
            for field, terms in field_terms.items():
                checks[field] = any(normalize_for_match(term) in normalized or term in text for term in terms)
        missing = [field for field, ok in checks.items() if not ok]
        severity = "fail" if requiredness == "required" and "exists" in missing else ("warn" if missing else "info")
        if severity == "fail":
            required_failures += 1
        if missing:
            warning_count += 1
        items.append({
            "target_id": target_id,
            "status": "FAIL" if severity == "fail" else ("WARN" if missing else "PASS"),
            "severity": severity,
            "path": str(path),
            "role": role,
            "requiredness": requiredness,
            "missing_fields": missing,
            "summary": (
                f"{target_id} is missing fresh-session fields: {', '.join(missing)}"
                if missing
                else f"{target_id} is ready for fresh-session bootstrap."
            ),
            "recommended_action": (
                "patch this durable note before relying on fresh sessions"
                if severity == "fail"
                else ("add missing context when this note is next touched" if missing else "ready")
            ),
        })

    payload = {
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": "FAIL" if required_failures else ("WARN" if warning_count else "PASS"),
        "targets_checked": len(items),
        "warning_count": warning_count,
        "fail_count": required_failures,
        "required_fields": ["exists", *field_terms.keys()],
        "items": items,
        "source": "fresh_session_readiness_audit",
        "acceptance_rule": "Fresh sessions must be able to recover purpose, status, aliases/synonyms, gates, evidence/verifiers, paths and next safe step from durable files.",
    }
    if write:
        write_json(FRESH_SESSION_READINESS_AUDIT_PATH, payload)
        lines = [
            "# Fresh Session Readiness Audit",
            "",
            f"- Status: `{payload['status']}`",
            f"- Targets checked: `{payload['targets_checked']}`",
            f"- Warnings: `{payload['warning_count']}`",
            f"- Fail: `{payload['fail_count']}`",
            "",
            "## Targets",
            "",
        ]
        for item in items:
            lines.append(f"- `{item['status']}` `{item['target_id']}`: {item['summary']}")
        (OUTPUT_DIR / "fresh_session_readiness_audit.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return payload


def build_quality_os_operator_surface(*, write: bool = False) -> dict[str, Any]:
    contracts = [load_json(path, default={}) for path in list_json_files(BUILD_CONTRACTS_DIR)]
    job_cards = [load_json(path, default={}) for path in list_json_files(JOB_CARDS_DIR)]
    runs = [load_json(path, default={}) for path in list_json_files(WORKFLOW_RUNS_DIR)]
    controls = load_json(QUALITY_OS_CONTROLS_PATH, default={})
    handoff = load_json(QUALITY_OS_HANDOFF_PATH, default={})
    contract_quality = load_json(CONTRACT_QUALITY_PATH, default={})
    long_run_audit = load_json(LONG_RUN_COMPLETION_AUDIT_PATH, default={})
    vault_umlaut = load_json(VAULT_UMLAUT_HYGIENE_PATH, default={})
    skill_policy_audit = load_json(SKILL_POLICY_REGRESSION_AUDIT_PATH, default={})
    rule_propagation = load_json(RULE_PROPAGATION_AUDIT_PATH, default={})
    project_invariants = load_json(PROJECT_INVARIANT_AUDIT_PATH, default={})
    agent_entrypoints = load_json(AGENT_ENTRYPOINT_AUDIT_PATH, default={})
    operator_intent = load_json(OPERATOR_INTENT_CONTRACT_AUDIT_PATH, default={})
    impact_radius = load_json(IMPACT_RADIUS_ASSESSMENT_PATH, default={})
    autonomy_governor = load_json(AUTONOMY_GOVERNOR_AUDIT_PATH, default={})
    vivi_handoff = load_json(VIVI_VEGA_HANDOFF_INBOX_PATH, default={})
    fresh_session_readiness = load_json(FRESH_SESSION_READINESS_AUDIT_PATH, default={})
    fresh_data = load_json(FRESH_DATA_INTAKE_PATH, default={})
    vivi_job_cards = apply_vivi_job_card_completion_state(load_json(VIVI_JOB_CARD_QUEUE_PATH, default={}))
    vivi_runner = load_json(VIVI_RUNNER_LAST_RUN_PATH, default={})
    vivi_supervisor = load_json(VIVI_SUPERVISOR_AUDIT_PATH, default={})
    autonomy_dirt = load_json(AUTONOMY_DIRT_BACKLOG_SCAN_PATH, default={})
    commit_cleanup_package = load_json(COMMIT_CLEANUP_GO_PACKAGE_PATH, default={})
    vivi_worker_queue = load_json(VIVI_WORKER_QUEUE_PATH, default={})
    vivi_worker = load_json(VIVI_WORKER_LAST_RUN_PATH, default={})
    vivi_worker_supervisor = load_json(VIVI_WORKER_SUPERVISOR_AUDIT_PATH, default={})
    endgame = load_json(ENDGAME_ROADMAP_PATH, default={})
    autonomy_soak = load_json(AUTONOMY_SOAK_AUDIT_PATH, default={})
    vivi_capability_matrix = load_json(VIVI_CAPABILITY_MATRIX_PATH, default={})
    project_verticals = load_json(PROJECT_VERTICAL_ROLLOUT_PATH, default={})
    launch_readiness = load_json(LAUNCH_READINESS_PATH, default={})
    openjarvis_lab = load_openjarvis_capability_lab()
    openjarvis_arena = load_openjarvis_capability_arena()
    full_check = load_json(OUTPUT_DIR / "full_check_report.json", default={})
    summary = load_json(OUTPUT_DIR / "summary.json", default={})
    decisions = apply_decision_state(load_json(OPERATOR_DECISION_PATH, default={}))
    coverage = load_json(COVERAGE_MANIFEST_PATH, default={})
    policy = load_json(POLICY_GATE_PATH, default={})
    risk = load_json(AUTOMATION_RISK_PATH, default={})
    guardrail_matrix = load_json(
        Path("/Users/BjornRosinger/Documents/New project 2/outputs/agent_os_readiness/GUARDRAIL_POLICY_GATE_MATRIX.json"),
        default={},
    )
    memory_workbench = load_json(
        Path("/Users/BjornRosinger/Documents/New project 2/outputs/agent_os_readiness/MEMORY_PROMOTION_WORKBENCH.json"),
        default={},
    )
    latest_run = sorted((run for run in runs if isinstance(run, dict)), key=lambda run: str(run.get("started_at", "")), reverse=True)
    current_run = latest_run[0] if latest_run else {}
    active_contracts = [contract for contract in contracts if contract.get("status") not in {"completed_verified", "closed_no_action"}]
    needs_target_picture = [contract for contract in contracts if contract.get("status") == "needs_target_picture"]
    approval_nodes = []
    for contract in contracts:
        for node in contract.get("approval_nodes", []):
            approval_nodes.append({"contract_id": contract.get("contract_id"), **node})
    operator_actions = []
    if isinstance(controls, dict):
        operator_actions.extend(controls.get("operator_actions", []))
    for run in latest_run:
        for action in run.get("operator_actions", []):
            if action not in operator_actions:
                operator_actions.append(action)
    run_controls = []
    if isinstance(controls, dict):
        run_controls.extend(controls.get("run_controls", []))
    last_verifier = (current_run.get("verifiers") or [{}])[-1] if current_run else {}
    if (
        isinstance(last_verifier, dict)
        and "full-check" in str(last_verifier.get("command", ""))
        and str(last_verifier.get("status", "")).startswith("pending")
        and full_check.get("status") in {"PASS", "FAIL"}
    ):
        last_verifier = {**last_verifier, "status": full_check.get("status")}
    surface = {
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": "PASS" if contract_quality.get("fail_count", 1) == 0 and current_run and long_run_audit.get("status") == "PASS" else "WARN",
        "source": "pig_quality_os",
        "surface_version": "v3" if operator_actions or run_controls or handoff else "v2",
        "control_capabilities": {
            "approval_actions": bool(operator_actions),
            "pause_resume_retry": bool(run_controls),
            "multi_run_history": len(latest_run) > 1,
            "fresh_session_handoff": bool(handoff),
            "long_run_completion_audit": long_run_audit.get("status") == "PASS",
            "rule_propagation_audit": rule_propagation.get("status") in {"PASS", "WARN"},
            "operator_intent_contract": operator_intent.get("status") == "PASS",
            "impact_radius_assessment": impact_radius.get("status") in {"PASS", "WARN"},
            "autonomy_governor": autonomy_governor.get("status") in {"PASS", "WARN"},
            "vivi_vega_handoff_inbox": vivi_handoff.get("status") in {"PASS", "WARN"},
            "fresh_session_readiness": fresh_session_readiness.get("status") in {"PASS", "WARN"},
            "fresh_data_intake": fresh_data.get("status") in {"PASS", "WARN"},
            "vivi_job_card_queue": vivi_job_cards.get("status") in {"PASS", "WARN"},
            "vivi_runner_mvp": vivi_runner.get("status") in {"completed_verified", "closed_no_action", "waiting_for_operator", "waiting_for_evidence"},
            "vivi_supervisor_audit": vivi_supervisor.get("status") in {"PASS", "WARN"},
            "commit_cleanup_go_package": commit_cleanup_package.get("status") in {"operator_go_required", "needs_local_review", "blocked_by_missing_evidence", "closed_no_action"},
            "vivi_worker_mvp": vivi_worker.get("status") in {"completed_verified", "closed_no_action", "waiting_for_operator", "failed_safe", "UNKNOWN"},
            "vivi_worker_supervisor_audit": vivi_worker_supervisor.get("status") in {"PASS", "WARN", "UNKNOWN"},
            "endgame_roadmap": endgame.get("status") in {"PASS", "WARN"},
            "autonomy_soak_audit": autonomy_soak.get("status") in {"PASS", "UNKNOWN"},
            "vivi_capability_matrix": vivi_capability_matrix.get("status") in {"PASS", "UNKNOWN"},
            "project_vertical_rollout": project_verticals.get("status") in {"PASS", "WARN", "UNKNOWN"},
            "launch_readiness_package": launch_readiness.get("status") in {"PASS", "WARN", "UNKNOWN"},
            "openjarvis_capability_lab": (
                openjarvis_lab.get("status") in {"PASS", "WARN"}
                and openjarvis_lab.get("source_of_truth") is False
                and openjarvis_lab.get("hardening", {}).get("runtime_action_executed") is False
                and openjarvis_lab.get("runtime", {}).get("runtime_execution_attempted") is False
            ),
            "openjarvis_capability_arena": (
                openjarvis_arena.get("status") == "PASS"
                and openjarvis_arena.get("source_of_truth") is False
                and openjarvis_arena.get("runtime", {}).get("runtime_action_executed") is False
                and openjarvis_arena.get("runtime", {}).get("runtime_execution_attempted") is False
            ),
            "runtime_dependency": "none",
            "n8n_runtime": False,
        },
        "active_build_contracts": [
            {
                "contract_id": contract.get("contract_id"),
                "status": contract.get("status"),
                "operator_goal": contract.get("operator_goal"),
                "target_picture": contract.get("target_picture"),
                "archetype": contract.get("archetype"),
                "cross_project_effect": contract.get("cross_project_effect"),
            }
            for contract in active_contracts
        ],
        "needs_target_picture": [{"contract_id": contract.get("contract_id"), "operator_goal": contract.get("operator_goal")} for contract in needs_target_picture],
        "approval_nodes": approval_nodes,
        "workflow_runs": [
            {
                "run_id": run.get("run_id"),
                "status": run.get("status"),
                "current_step": run.get("current_step"),
                "started_at": run.get("started_at"),
                "completed_at": run.get("completed_at"),
                "control_state": run.get("control_state", run.get("status")),
                "retry_count": run.get("retry_count", 0),
                "has_operator_actions": bool(run.get("operator_actions")),
            }
            for run in latest_run[:12]
        ],
        "operator_actions": operator_actions[:24],
        "run_controls": run_controls[:12],
        "fresh_session_handoff": {
            "status": handoff.get("status", "missing") if isinstance(handoff, dict) and handoff else "missing",
            "path": str(QUALITY_OS_HANDOFF_PATH),
            "latest_run": handoff.get("latest_run") if isinstance(handoff, dict) else "",
            "next_safe_step": handoff.get("next_safe_step") if isinstance(handoff, dict) else "",
            "reading_order": handoff.get("reading_order", []) if isinstance(handoff, dict) else [],
        },
        "last_verifier": last_verifier,
        "next_safe_step": (
            handoff.get("next_safe_step")
            if isinstance(handoff, dict) and handoff.get("next_safe_step")
            else "Use `pig.py materialize-quality-os`, `pig.py planning-quality`, and LIONCOM Planning Quality surface for future larger tasks."
        ),
        "stopped_reason": "" if current_run else "No workflow run history found.",
        "effect_scope": "systemwide",
        "governance": {
            "overall": "CLEAR" if decisions.get("unresolved_count", 0) == 0 and summary.get("implementation_status") == "PASS" else "REVIEW",
            "implementation_status": summary.get("implementation_status", "UNKNOWN"),
            "coverage_status": coverage.get("status", summary.get("coverage_status", "UNKNOWN")),
            "operator_risk_status": summary.get("operator_risk_status", "UNKNOWN"),
            "policy_gate_status": policy.get("status", summary.get("policy_gate_status", "UNKNOWN")),
            "decisions_status": decisions.get("status", "UNKNOWN"),
            "unresolved_decisions": decisions.get("unresolved_count", 0),
            "coverage_gaps": count_coverage_gaps(),
            "active_high_risk_automations": len([
                item
                for item in risk.get("items", [])
                if item.get("status") == "ACTIVE" and item.get("risk_class") in {"R4", "R5"}
            ]),
            "guardrail_policy_gates": len(guardrail_matrix.get("gates", [])) if isinstance(guardrail_matrix, dict) else 0,
            "memory_promotion_batches": len(memory_workbench.get("batches", [])) if isinstance(memory_workbench, dict) else 0,
            "long_run_completion_status": long_run_audit.get("status", "UNKNOWN"),
            "long_run_reports_checked": long_run_audit.get("reports_checked", 0),
            "vault_umlaut_hygiene_status": vault_umlaut.get("status", "UNKNOWN"),
            "vault_umlaut_hygiene_findings": vault_umlaut.get("finding_count", 0),
            "skill_policy_regression_guard_status": skill_policy_audit.get("status", "UNKNOWN"),
            "skill_policy_regression_guard_warnings": len([item for item in skill_policy_audit.get("items", []) if item.get("status") == "WARN"]),
            "rule_propagation_status": rule_propagation.get("status", "UNKNOWN"),
            "rule_propagation_warnings": len([item for item in rule_propagation.get("items", []) if item.get("status") == "WARN"]),
            "project_invariant_status": project_invariants.get("status", "UNKNOWN"),
            "project_invariants_checked": project_invariants.get("projects_checked", 0),
            "agent_entrypoint_status": agent_entrypoints.get("status", "UNKNOWN"),
            "agent_entrypoints_checked": agent_entrypoints.get("entrypoints_checked", 0),
            "operator_intent_contract_status": operator_intent.get("status", "UNKNOWN"),
            "impact_radius_status": impact_radius.get("status", "UNKNOWN"),
            "impact_radius_matches": len(impact_radius.get("matches", [])),
            "autonomy_governor_status": autonomy_governor.get("status", "UNKNOWN"),
            "autonomy_state": autonomy_governor.get("autonomy_state", "UNKNOWN"),
            "autonomy_safe_work_remaining": autonomy_governor.get("ready_or_in_progress_count", 0),
            "autonomy_dirt_backlog_scan_status": autonomy_dirt.get("status", "UNKNOWN"),
            "autonomy_dirty_project_count": autonomy_dirt.get("dirty_project_count", 0),
            "autonomy_dirt_handoff_card_count": autonomy_dirt.get("handoff_card_count", 0),
            "autonomy_dirt_verifier_executed_count": autonomy_dirt.get("verifier_executed_count", 0),
            "autonomy_dirt_verifier_pass_count": autonomy_dirt.get("verifier_pass_count", 0),
            "autonomy_dirt_verifier_fail_count": autonomy_dirt.get("verifier_fail_count", 0),
            "autonomy_dirt_verifier_planned_count": autonomy_dirt.get("verifier_planned_count", 0),
            "vivi_vega_handoff_inbox_status": vivi_handoff.get("status", "UNKNOWN"),
            "vivi_vega_handoff_action_items": vivi_handoff.get("action_item_count", 0),
            "vivi_needs_vega_review_count": vivi_handoff.get("needs_vega_review_count", 0),
            "vivi_operator_gate_count": vivi_handoff.get("operator_gate_count", 0),
            "fresh_session_readiness_status": fresh_session_readiness.get("status", "UNKNOWN"),
            "fresh_session_readiness_warnings": fresh_session_readiness.get("warning_count", 0),
            "fresh_data_intake_status": fresh_data.get("status", "UNKNOWN"),
            "fresh_data_fresh_items": fresh_data.get("fresh_item_count", 0),
            "fresh_data_action_items": fresh_data.get("action_item_count", 0),
            "fresh_data_operator_gates": fresh_data.get("operator_gate_count", 0),
            "vivi_job_card_queue_status": vivi_job_cards.get("status", "UNKNOWN"),
            "vivi_job_card_count": vivi_job_cards.get("job_card_count", 0),
            "vivi_job_cards_ready": vivi_job_cards.get("ready_count", 0),
            "vivi_runner_status": vivi_runner.get("status", "UNKNOWN"),
            "vivi_runner_last_job_card": vivi_runner.get("job_card_id", ""),
            "vivi_supervisor_status": vivi_supervisor.get("status", "UNKNOWN"),
            "vivi_supervisor_truth_status": vivi_supervisor.get("truth_status", "UNKNOWN"),
            "commit_cleanup_go_package_status": commit_cleanup_package.get("status", "UNKNOWN"),
            "commit_cleanup_go_package_decisions": commit_cleanup_package.get("summary", {}).get("decision_card_count", 0),
            "commit_cleanup_go_runtime_action_executed": commit_cleanup_package.get("runtime_action_executed", None),
            "vivi_worker_queue_status": vivi_worker_queue.get("status", "UNKNOWN"),
            "vivi_worker_ready_count": vivi_worker_queue.get("ready_count", 0),
            "vivi_worker_status": vivi_worker.get("status", "UNKNOWN"),
            "vivi_worker_runtime_action_executed": vivi_worker.get("runtime_action_executed", None),
            "vivi_worker_supervisor_status": vivi_worker_supervisor.get("status", "UNKNOWN"),
            "endgame_roadmap_status": endgame.get("status", "UNKNOWN"),
            "endgame_roadmap_completion_percent": endgame.get("completion_percent", 0),
            "endgame_foundation_completion_percent": endgame.get("foundation_completion_percent", 0),
            "endgame_macro_completion_percent": endgame.get("macro_completion_percent", 0),
            "endgame_current_phase": endgame.get("current_phase", ""),
            "endgame_safe_next_blocks": len(endgame.get("safe_next_blocks", [])),
            "autonomy_soak_status": autonomy_soak.get("status", "UNKNOWN"),
            "autonomy_soak_loops": autonomy_soak.get("loop_count", 0),
            "vivi_capability_matrix_status": vivi_capability_matrix.get("status", "UNKNOWN"),
            "vivi_capability_ready_claim_types": vivi_capability_matrix.get("ready_claim_type_count", 0),
            "vivi_capability_verified_claim_types": vivi_capability_matrix.get("verified_claim_type_count", 0),
            "project_vertical_rollout_status": project_verticals.get("status", "UNKNOWN"),
            "project_vertical_count": project_verticals.get("project_count", 0),
            "project_vertical_missing_verifiers": project_verticals.get("missing_verifier_count", 0),
            "launch_readiness_status": launch_readiness.get("status", "UNKNOWN"),
            "launch_readiness_packages": launch_readiness.get("package_count", 0),
            "launch_readiness_operator_gates": launch_readiness.get("operator_gate_count", 0),
            "openjarvis_capability_lab_status": openjarvis_lab.get("status", "UNKNOWN"),
            "openjarvis_source_documents": openjarvis_lab.get("source_document_count", 0),
            "openjarvis_retrieval_status": openjarvis_lab.get("retrieval_benchmark", {}).get("status", "UNKNOWN"),
            "openjarvis_retrieval_pass_count": openjarvis_lab.get("retrieval_benchmark", {}).get("pass_count", 0),
            "openjarvis_retrieval_question_count": openjarvis_lab.get("retrieval_benchmark", {}).get("question_count", 0),
            "openjarvis_code_qa_status": openjarvis_lab.get("code_qa_shadow", {}).get("status", "UNKNOWN"),
            "openjarvis_runtime_available": openjarvis_lab.get("runtime", {}).get("runtime_available", False),
            "openjarvis_runtime_action_executed": openjarvis_lab.get("hardening", {}).get("runtime_action_executed", None),
            "openjarvis_capability_arena_status": openjarvis_arena.get("status", "UNKNOWN"),
            "openjarvis_arena_task_count": openjarvis_arena.get("evaluated_task_count", 0),
            "openjarvis_arena_shadow_pass_count": openjarvis_arena.get("engine_summary", {}).get("openjarvis_shadow", {}).get("pass_count", 0),
            "openjarvis_arena_shadow_fail_count": openjarvis_arena.get("engine_summary", {}).get("openjarvis_shadow", {}).get("fail_count", 0),
            "openjarvis_arena_shadow_wins": openjarvis_arena.get("winner_summary", {}).get("openjarvis_shadow", 0),
            "openjarvis_arena_baseline_wins": openjarvis_arena.get("winner_summary", {}).get("pig_obsidian_baseline", 0),
            "openjarvis_arena_ties": openjarvis_arena.get("winner_summary", {}).get("tie", 0),
            "complete_context_items": len([
                item
                for item in contract_quality.get("items", [])
                if str(item.get("artifact_kind", "")).startswith("complete_context_before_archival")
            ]),
        },
        "systemwide_rule_propagation": {
            "status": rule_propagation.get("status", "UNKNOWN"),
            "rules_checked": rule_propagation.get("rules_checked", 0),
            "targets_checked": rule_propagation.get("targets_checked", 0),
            "warnings": [
                item
                for item in rule_propagation.get("items", [])
                if item.get("status") == "WARN"
            ][:12],
            "project_invariants": {
                "status": project_invariants.get("status", "UNKNOWN"),
                "projects_checked": project_invariants.get("projects_checked", 0),
            },
            "agent_entrypoints": {
                "status": agent_entrypoints.get("status", "UNKNOWN"),
                "entrypoints_checked": agent_entrypoints.get("entrypoints_checked", 0),
            },
            "operator_intent_contract": {
                "status": operator_intent.get("status", "UNKNOWN"),
                "schema_ready": operator_intent.get("status") == "PASS",
                "materialized_contract_count": operator_intent.get("materialized_contract_count", 0),
                "latest_contract": str(LATEST_OPERATOR_INTENT_CONTRACT_PATH) if LATEST_OPERATOR_INTENT_CONTRACT_PATH.exists() else "",
            },
            "autonomy_execution_queue": {
                "status": load_json(AUTONOMY_EXECUTION_QUEUE_PATH, default={}).get("status", "UNKNOWN"),
                "current_block": load_json(AUTONOMY_EXECUTION_QUEUE_PATH, default={}).get("current_block", ""),
                "block_count": len(load_json(AUTONOMY_EXECUTION_QUEUE_PATH, default={}).get("blocks", [])),
            },
            "impact_radius": {
                "status": impact_radius.get("status", "UNKNOWN"),
                "matches": len(impact_radius.get("matches", [])),
                "affected_projects": impact_radius.get("affected_projects", []),
                "rule_ids": impact_radius.get("rule_ids", []),
                "next_safe_blocks": impact_radius.get("next_safe_blocks", [])[:5],
            },
            "autonomy_governor": {
                "status": autonomy_governor.get("status", "UNKNOWN"),
                "autonomy_state": autonomy_governor.get("autonomy_state", "UNKNOWN"),
                "safe_work_remaining": autonomy_governor.get("safe_work_remaining", False),
                "next_safe_steps": autonomy_governor.get("next_safe_steps", [])[:5],
                "blocked_gates": autonomy_governor.get("blocked_gates", [])[:5],
            },
            "autonomy_dirt_backlog_scan": {
                "status": autonomy_dirt.get("status", "UNKNOWN"),
                "dirty_project_count": autonomy_dirt.get("dirty_project_count", 0),
                "handoff_card_count": autonomy_dirt.get("handoff_card_count", 0),
                "handoff_decision_queue_status": autonomy_dirt.get("handoff_decision_queue", {}).get("status", "UNKNOWN") if isinstance(autonomy_dirt.get("handoff_decision_queue"), dict) else "UNKNOWN",
                "handoff_safe_queue_count": autonomy_dirt.get("handoff_decision_queue", {}).get("safe_queue_count", 0) if isinstance(autonomy_dirt.get("handoff_decision_queue"), dict) else 0,
                "handoff_operator_gate_queue_count": autonomy_dirt.get("handoff_decision_queue", {}).get("operator_gate_queue_count", 0) if isinstance(autonomy_dirt.get("handoff_decision_queue"), dict) else 0,
                "handoff_reviewed_queue_count": autonomy_dirt.get("handoff_decision_queue", {}).get("reviewed_queue_count", 0) if isinstance(autonomy_dirt.get("handoff_decision_queue"), dict) else 0,
                "verifier_executed_count": autonomy_dirt.get("verifier_executed_count", 0),
                "verifier_pass_count": autonomy_dirt.get("verifier_pass_count", 0),
                "verifier_fail_count": autonomy_dirt.get("verifier_fail_count", 0),
                "verifier_planned_count": autonomy_dirt.get("verifier_planned_count", 0),
                "path": str(AUTONOMY_DIRT_BACKLOG_SCAN_PATH),
                "safe_next_actions": autonomy_dirt.get("safe_next_actions", [])[:8],
                "next_safe_review": autonomy_dirt.get("handoff_decision_queue", {}).get("next_safe_review", {}) if isinstance(autonomy_dirt.get("handoff_decision_queue"), dict) else {},
                "safe_work_queue": autonomy_dirt.get("handoff_decision_queue", {}).get("safe_work_queue", [])[:8] if isinstance(autonomy_dirt.get("handoff_decision_queue"), dict) else [],
                "operator_gate_queue": autonomy_dirt.get("handoff_decision_queue", {}).get("operator_gate_queue", [])[:5] if isinstance(autonomy_dirt.get("handoff_decision_queue"), dict) else [],
                "reviewed_queue": autonomy_dirt.get("handoff_decision_queue", {}).get("reviewed_queue", [])[:8] if isinstance(autonomy_dirt.get("handoff_decision_queue"), dict) else [],
                "handoff_cards": autonomy_dirt.get("handoff_cards", [])[:8],
            },
            "commit_cleanup_go_package": {
                "status": commit_cleanup_package.get("status", "UNKNOWN"),
                "package_id": commit_cleanup_package.get("package_id", ""),
                "runtime_action_executed": commit_cleanup_package.get("runtime_action_executed", None),
                "summary": commit_cleanup_package.get("summary", {}),
                "allowed_operator_decisions": commit_cleanup_package.get("allowed_operator_decisions", []),
                "forbidden_without_operator_go": commit_cleanup_package.get("forbidden_without_operator_go", []),
                "project_packages": commit_cleanup_package.get("project_packages", [])[:8],
                "decision_cards": commit_cleanup_package.get("decision_cards", [])[:12],
                "path": str(COMMIT_CLEANUP_GO_PACKAGE_PATH),
                "next_safe_step": commit_cleanup_package.get("next_safe_step", ""),
            },
            "vivi_vega_handoff_inbox": {
                "status": vivi_handoff.get("status", "UNKNOWN"),
                "action_item_count": vivi_handoff.get("action_item_count", 0),
                "needs_vega_review_count": vivi_handoff.get("needs_vega_review_count", 0),
                "operator_gate_count": vivi_handoff.get("operator_gate_count", 0),
                "needs_verifier_count": vivi_handoff.get("needs_verifier_count", 0),
                "path": str(VIVI_VEGA_HANDOFF_INBOX_PATH),
                "action_items": vivi_handoff.get("action_items", [])[-8:],
            },
            "fresh_session_readiness": {
                "status": fresh_session_readiness.get("status", "UNKNOWN"),
                "targets_checked": fresh_session_readiness.get("targets_checked", 0),
                "warning_count": fresh_session_readiness.get("warning_count", 0),
                "fail_count": fresh_session_readiness.get("fail_count", 0),
                "warnings": [
                    item
                    for item in fresh_session_readiness.get("items", [])
                    if item.get("status") == "WARN"
                ][:8],
            },
            "fresh_data_intake": {
                "status": fresh_data.get("status", "UNKNOWN"),
                "fresh_item_count": fresh_data.get("fresh_item_count", 0),
                "action_item_count": fresh_data.get("action_item_count", 0),
                "operator_gate_count": fresh_data.get("operator_gate_count", 0),
                "needs_review_count": fresh_data.get("needs_review_count", 0),
                "needs_verifier_count": fresh_data.get("needs_verifier_count", 0),
                "path": str(FRESH_DATA_INTAKE_PATH),
                "action_items": fresh_data.get("action_items", [])[:8],
            },
            "vivi_job_card_queue": {
                "status": vivi_job_cards.get("status", "UNKNOWN"),
                "job_card_count": vivi_job_cards.get("job_card_count", 0),
                "ready_count": vivi_job_cards.get("ready_count", 0),
                "waiting_for_operator_count": vivi_job_cards.get("waiting_for_operator_count", 0),
                "path": str(VIVI_JOB_CARD_QUEUE_PATH),
                "job_cards": vivi_job_cards.get("job_cards", [])[:8],
            },
            "vivi_runner_mvp": {
                "status": vivi_runner.get("status", "UNKNOWN"),
                "run_id": vivi_runner.get("run_id", ""),
                "job_card_id": vivi_runner.get("job_card_id", ""),
                "runtime_action_executed": vivi_runner.get("runtime_action_executed", False),
                "path": str(VIVI_RUNNER_LAST_RUN_PATH),
                "next_safe_step": vivi_runner.get("next_safe_step", ""),
            },
            "vivi_supervisor_audit": {
                "status": vivi_supervisor.get("status", "UNKNOWN"),
                "truth_status": vivi_supervisor.get("truth_status", "UNKNOWN"),
                "job_card_id": vivi_supervisor.get("job_card_id", ""),
                "path": str(VIVI_SUPERVISOR_AUDIT_PATH),
                "findings": vivi_supervisor.get("findings", [])[:8],
                "next_safe_step": vivi_supervisor.get("next_safe_step", ""),
            },
            "vivi_worker_queue": {
                "status": vivi_worker_queue.get("status", "UNKNOWN"),
                "worker_card_count": vivi_worker_queue.get("worker_card_count", 0),
                "ready_count": vivi_worker_queue.get("ready_count", 0),
                "path": str(VIVI_WORKER_QUEUE_PATH),
                "worker_cards": vivi_worker_queue.get("worker_cards", [])[:8],
            },
            "vivi_worker_mvp": {
                "status": vivi_worker.get("status", "UNKNOWN"),
                "run_id": vivi_worker.get("run_id", ""),
                "worker_card_id": vivi_worker.get("worker_card_id", ""),
                "runtime_action_executed": vivi_worker.get("runtime_action_executed", None),
                "local_artifact_write_executed": vivi_worker.get("local_artifact_write_executed", None),
                "path": str(VIVI_WORKER_LAST_RUN_PATH),
                "next_safe_step": vivi_worker.get("next_safe_step", ""),
            },
            "vivi_worker_supervisor_audit": {
                "status": vivi_worker_supervisor.get("status", "UNKNOWN"),
                "truth_status": vivi_worker_supervisor.get("truth_status", "UNKNOWN"),
                "path": str(VIVI_WORKER_SUPERVISOR_AUDIT_PATH),
                "findings": vivi_worker_supervisor.get("findings", [])[:8],
                "next_safe_step": vivi_worker_supervisor.get("next_safe_step", ""),
            },
            "endgame_roadmap": {
                "status": endgame.get("status", "UNKNOWN"),
                "completion_percent": endgame.get("completion_percent", 0),
                "foundation_completion_percent": endgame.get("foundation_completion_percent", 0),
                "macro_completion_percent": endgame.get("macro_completion_percent", 0),
                "current_phase": endgame.get("current_phase", ""),
                "safe_work_remaining": endgame.get("safe_work_remaining", False),
                "safe_next_blocks": endgame.get("safe_next_blocks", [])[:5],
                "macro_backlog": endgame.get("macro_backlog", [])[:8],
                "operator_gates": endgame.get("operator_gates", [])[:12],
                "completion_note": endgame.get("completion_note", ""),
                "path": str(ENDGAME_ROADMAP_PATH),
            },
            "autonomy_soak_audit": {
                "status": autonomy_soak.get("status", "UNKNOWN"),
                "loop_count": autonomy_soak.get("loop_count", 0),
                "runtime_action_executed": autonomy_soak.get("runtime_action_executed", None),
                "findings": autonomy_soak.get("findings", [])[:8],
                "path": str(AUTONOMY_SOAK_AUDIT_PATH),
            },
            "vivi_capability_matrix": {
                "status": vivi_capability_matrix.get("status", "UNKNOWN"),
                "ready_claim_type_count": vivi_capability_matrix.get("ready_claim_type_count", 0),
                "verified_claim_type_count": vivi_capability_matrix.get("verified_claim_type_count", 0),
                "blocked_claim_type_count": vivi_capability_matrix.get("blocked_claim_type_count", 0),
                "claim_types": vivi_capability_matrix.get("claim_types", [])[:8],
                "path": str(VIVI_CAPABILITY_MATRIX_PATH),
            },
            "project_vertical_rollout": {
                "status": project_verticals.get("status", "UNKNOWN"),
                "project_count": project_verticals.get("project_count", 0),
                "missing_verifier_count": project_verticals.get("missing_verifier_count", 0),
                "operator_gated_project_count": project_verticals.get("operator_gated_project_count", 0),
                "projects": project_verticals.get("projects", [])[:8],
                "path": str(PROJECT_VERTICAL_ROLLOUT_PATH),
            },
            "launch_readiness_package": {
                "status": launch_readiness.get("status", "UNKNOWN"),
                "package_count": launch_readiness.get("package_count", 0),
                "operator_gate_count": launch_readiness.get("operator_gate_count", 0),
                "missing_artifact_count": launch_readiness.get("missing_artifact_count", 0),
                "packages": launch_readiness.get("packages", [])[:8],
                "path": str(LAUNCH_READINESS_PATH),
            },
            "openjarvis_capability_lab": {
                "status": openjarvis_lab.get("status", "UNKNOWN"),
                "mode": openjarvis_lab.get("mode", "UNKNOWN"),
                "source_of_truth": openjarvis_lab.get("source_of_truth", False),
                "source_document_count": openjarvis_lab.get("source_document_count", 0),
                "preflight_status": openjarvis_lab.get("preflight", {}).get("status", "UNKNOWN"),
                "preflight_blocker_count": openjarvis_lab.get("preflight", {}).get("blocker_count", 0),
                "retrieval_status": openjarvis_lab.get("retrieval_benchmark", {}).get("status", "UNKNOWN"),
                "retrieval_question_count": openjarvis_lab.get("retrieval_benchmark", {}).get("question_count", 0),
                "retrieval_pass_count": openjarvis_lab.get("retrieval_benchmark", {}).get("pass_count", 0),
                "code_qa_status": openjarvis_lab.get("code_qa_shadow", {}).get("status", "UNKNOWN"),
                "code_qa_project_count": openjarvis_lab.get("code_qa_shadow", {}).get("project_count", 0),
                "runtime_available": openjarvis_lab.get("runtime", {}).get("runtime_available", False),
                "runtime_execution_attempted": openjarvis_lab.get("runtime", {}).get("runtime_execution_attempted", False),
                "runtime_action_executed": openjarvis_lab.get("hardening", {}).get("runtime_action_executed", False),
                "adoption_recommendation": openjarvis_lab.get("adoption_recommendation", ""),
                "next_safe_step": openjarvis_lab.get("next_safe_step", ""),
                "path": openjarvis_lab.get("path", ""),
            },
            "openjarvis_capability_arena": {
                "status": openjarvis_arena.get("status", "UNKNOWN"),
                "mode": openjarvis_arena.get("mode", "UNKNOWN"),
                "source_of_truth": openjarvis_arena.get("source_of_truth", False),
                "task_count": openjarvis_arena.get("evaluated_task_count", 0),
                "source_document_count": openjarvis_arena.get("source_document_count", 0),
                "baseline_document_count": openjarvis_arena.get("baseline_document_count", 0),
                "shadow_document_count": openjarvis_arena.get("shadow_document_count", 0),
                "shadow_average_score": openjarvis_arena.get("engine_summary", {}).get("openjarvis_shadow", {}).get("average_score", 0),
                "baseline_average_score": openjarvis_arena.get("engine_summary", {}).get("pig_obsidian_baseline", {}).get("average_score", 0),
                "shadow_pass_count": openjarvis_arena.get("engine_summary", {}).get("openjarvis_shadow", {}).get("pass_count", 0),
                "shadow_fail_count": openjarvis_arena.get("engine_summary", {}).get("openjarvis_shadow", {}).get("fail_count", 0),
                "shadow_win_count": openjarvis_arena.get("winner_summary", {}).get("openjarvis_shadow", 0),
                "baseline_win_count": openjarvis_arena.get("winner_summary", {}).get("pig_obsidian_baseline", 0),
                "tie_count": openjarvis_arena.get("winner_summary", {}).get("tie", 0),
                "runtime_action_executed": openjarvis_arena.get("runtime", {}).get("runtime_action_executed", False),
                "adoption_recommendation": openjarvis_arena.get("adoption_recommendation", ""),
                "next_safe_step": openjarvis_arena.get("next_safe_step", ""),
                "path": openjarvis_arena.get("path", ""),
            },
        },
        "contract_quality": {
            "status": contract_quality.get("status", "UNKNOWN"),
            "fail_count": contract_quality.get("fail_count", 0),
            "warn_count": contract_quality.get("warn_count", 0),
            "items": len(contract_quality.get("items", [])),
        },
        "long_run_completion": {
            "status": long_run_audit.get("status", "UNKNOWN"),
            "reports_checked": long_run_audit.get("reports_checked", 0),
            "path": str(LONG_RUN_COMPLETION_AUDIT_PATH),
        },
        "vault_hygiene": {
            "status": vault_umlaut.get("status", "UNKNOWN"),
            "finding_count": vault_umlaut.get("finding_count", 0),
            "path": str(VAULT_UMLAUT_HYGIENE_PATH),
        },
        "skill_policy_regression_guard": {
            "status": skill_policy_audit.get("status", "UNKNOWN"),
            "warning_count": len([item for item in skill_policy_audit.get("items", []) if item.get("status") == "WARN"]),
            "path": str(SKILL_POLICY_REGRESSION_AUDIT_PATH),
        },
        "full_check": {
            "status": full_check.get("status", "UNKNOWN"),
            "generated_at": full_check.get("generated_at", ""),
        },
        "job_cards": [
            {
                "job_card_id": card.get("job_card_id"),
                "status": card.get("status"),
                "auftrag": card.get("auftrag"),
                "naechster_sicherer_schritt": card.get("naechster_sicherer_schritt"),
                "verifier": card.get("verifier", []),
            }
            for card in job_cards
        ],
    }
    if write:
        write_json(QUALITY_OS_SURFACE_PATH, surface)
        lines = [
            "# Quality OS Operator Surface",
            "",
            f"- Status: `{surface['status']}`",
            f"- Generated: `{surface['generated_at']}`",
            f"- Contract quality: `{surface['contract_quality']['status']}`",
            f"- Long-run completion: `{surface['long_run_completion']['status']}`",
            f"- Vault umlaut hygiene: `{surface['vault_hygiene']['status']}` ({surface['vault_hygiene']['finding_count']})",
            f"- Skill policy regression guard: `{surface['skill_policy_regression_guard']['status']}`",
            f"- Rule propagation: `{surface['systemwide_rule_propagation']['status']}` ({surface['systemwide_rule_propagation']['rules_checked']} rules, {surface['systemwide_rule_propagation']['targets_checked']} targets)",
            f"- Project invariants: `{surface['systemwide_rule_propagation']['project_invariants']['status']}` ({surface['systemwide_rule_propagation']['project_invariants']['projects_checked']} projects)",
            f"- Agent entrypoints: `{surface['systemwide_rule_propagation']['agent_entrypoints']['status']}` ({surface['systemwide_rule_propagation']['agent_entrypoints']['entrypoints_checked']} entrypoints)",
            f"- Operator intent contract: `{surface['systemwide_rule_propagation']['operator_intent_contract']['status']}` ({surface['systemwide_rule_propagation']['operator_intent_contract'].get('materialized_contract_count', 0)} materialized)",
            f"- Autonomy execution queue: `{surface['systemwide_rule_propagation']['autonomy_execution_queue']['status']}` ({surface['systemwide_rule_propagation']['autonomy_execution_queue'].get('current_block', '')})",
            f"- Autonomy dirt/backlog: `{surface['systemwide_rule_propagation']['autonomy_dirt_backlog_scan']['status']}` ({surface['systemwide_rule_propagation']['autonomy_dirt_backlog_scan']['dirty_project_count']} dirty projects, {surface['systemwide_rule_propagation']['autonomy_dirt_backlog_scan']['verifier_pass_count']}/{surface['systemwide_rule_propagation']['autonomy_dirt_backlog_scan']['verifier_executed_count']} verifiers pass)",
            f"- Commit/Cleanup Operator-Go package: `{surface['systemwide_rule_propagation']['commit_cleanup_go_package']['status']}` ({surface['systemwide_rule_propagation']['commit_cleanup_go_package'].get('summary', {}).get('decision_card_count', 0)} decision cards)",
            f"- Vivi -> Vega handoff inbox: `{surface['systemwide_rule_propagation']['vivi_vega_handoff_inbox']['status']}` ({surface['systemwide_rule_propagation']['vivi_vega_handoff_inbox']['action_item_count']} action items)",
            f"- Vivi worker MVP: `{surface['systemwide_rule_propagation']['vivi_worker_mvp']['status']}` (runtime action executed: `{surface['systemwide_rule_propagation']['vivi_worker_mvp']['runtime_action_executed']}`)",
            f"- Endgame roadmap: `{surface['systemwide_rule_propagation']['endgame_roadmap']['status']}` ({surface['systemwide_rule_propagation']['endgame_roadmap']['completion_percent']}%, current: {surface['systemwide_rule_propagation']['endgame_roadmap']['current_phase']})",
            f"- Autonomy soak: `{surface['systemwide_rule_propagation']['autonomy_soak_audit']['status']}` ({surface['systemwide_rule_propagation']['autonomy_soak_audit']['loop_count']} loops)",
            f"- Vivi capability matrix: `{surface['systemwide_rule_propagation']['vivi_capability_matrix']['status']}` ({surface['systemwide_rule_propagation']['vivi_capability_matrix']['ready_claim_type_count']} ready, {surface['systemwide_rule_propagation']['vivi_capability_matrix']['verified_claim_type_count']} verified)",
            f"- Project vertical rollout: `{surface['systemwide_rule_propagation']['project_vertical_rollout']['status']}` ({surface['systemwide_rule_propagation']['project_vertical_rollout']['project_count']} projects, {surface['systemwide_rule_propagation']['project_vertical_rollout']['missing_verifier_count']} missing verifiers)",
            f"- Launch readiness: `{surface['systemwide_rule_propagation']['launch_readiness_package']['status']}` ({surface['systemwide_rule_propagation']['launch_readiness_package']['package_count']} packages, {surface['systemwide_rule_propagation']['launch_readiness_package']['operator_gate_count']} gates)",
            f"- OpenJarvis capability lab: `{surface['systemwide_rule_propagation']['openjarvis_capability_lab']['status']}` ({surface['systemwide_rule_propagation']['openjarvis_capability_lab']['retrieval_pass_count']}/{surface['systemwide_rule_propagation']['openjarvis_capability_lab']['retrieval_question_count']} retrieval checks, runtime action executed: `{surface['systemwide_rule_propagation']['openjarvis_capability_lab']['runtime_action_executed']}`)",
            f"- OpenJarvis capability arena: `{surface['systemwide_rule_propagation']['openjarvis_capability_arena']['status']}` ({surface['systemwide_rule_propagation']['openjarvis_capability_arena']['shadow_win_count']} shadow wins, {surface['systemwide_rule_propagation']['openjarvis_capability_arena']['baseline_win_count']} baseline wins, runtime action executed: `{surface['systemwide_rule_propagation']['openjarvis_capability_arena']['runtime_action_executed']}`)",
            f"- Impact radius: `{surface['systemwide_rule_propagation']['impact_radius']['status']}` ({surface['systemwide_rule_propagation']['impact_radius']['matches']} matches)",
            f"- Governance: `{surface['governance']['overall']}`",
            f"- Coverage: `{surface['governance']['coverage_status']}`",
            f"- Decisions: `{surface['governance']['decisions_status']}`",
            f"- Workflow runs: `{len(surface['workflow_runs'])}`",
            f"- Approval nodes: `{len(surface['approval_nodes'])}`",
            f"- Operator actions: `{len(surface['operator_actions'])}`",
            f"- Run controls: `{len(surface['run_controls'])}`",
            f"- Effect scope: `{surface['effect_scope']}`",
            "",
            "## Nächster sicherer Schritt",
            "",
            surface["next_safe_step"],
            "",
            "## Control Capabilities",
            "",
            f"- Approval actions: `{surface['control_capabilities']['approval_actions']}`",
            f"- Pause/Resume/Retry: `{surface['control_capabilities']['pause_resume_retry']}`",
            f"- Fresh-session handoff: `{surface['fresh_session_handoff']['status']}`",
            f"- Long-run audit: `{surface['control_capabilities']['long_run_completion_audit']}`",
        ]
        (OUTPUT_DIR / "quality_os_operator_surface.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return surface


def status_rank(value: str) -> int:
    return {"FAIL": 0, "UNKNOWN": 1, "ACTION_REQUIRED": 2, "REVIEW": 3, "WARN": 3, "PASS": 4, "CLEAR": 4}.get(str(value), 1)


def count_active_high_risk() -> int:
    payload = load_json(AUTOMATION_RISK_PATH, default={"items": []})
    return sum(1 for item in payload.get("items", []) if item.get("status") == "ACTIVE" and item.get("risk_class") in {"R4", "R5"})


def count_coverage_gaps() -> int:
    payload = load_json(COVERAGE_MANIFEST_PATH, default={"sources": []})
    return sum(1 for item in payload.get("sources", []) if item.get("status") in {"not_implemented", "missing", "partial"})


def count_policy_items() -> int:
    payload = load_json(POLICY_GATE_PATH, default={"items": []})
    return len(payload.get("items", []))


def count_p0_unresolved(decisions: dict[str, Any]) -> int:
    return sum(
        1
        for item in decisions.get("items", [])
        if item.get("priority") == "P0" and item.get("operator_state", "open") not in {"accepted", "closed"}
    )


def selftest_metrics(report: dict[str, Any]) -> dict[str, Any]:
    checks = []
    for step in report.get("steps", []):
        if step.get("name") == "selftest":
            checks = step.get("checks", [])
            break
    failed = [check for check in checks if check.get("status") != "PASS"]
    return {
        "check_count": len(checks),
        "failed_count": len(failed),
        "failed_checks": [check.get("name") for check in failed],
    }


def build_quality_snapshot(label: str, full_check: dict[str, Any] | None = None, improvement: str = "") -> dict[str, Any]:
    report = full_check or load_json(OUTPUT_DIR / "full_check_report.json", default={})
    decisions = apply_decision_state(load_json(OPERATOR_DECISION_PATH, default={"items": []}))
    summary = report.get("summary", {}) if isinstance(report, dict) else {}
    selftest = selftest_metrics(report if isinstance(report, dict) else {})
    contracts = load_json(OUTPUT_DIR / "hardening_fix_contract_validation.json", default={})
    contract_quality = load_json(CONTRACT_QUALITY_PATH, default={})
    rule_propagation = load_json(RULE_PROPAGATION_AUDIT_PATH, default={})
    project_invariants = load_json(PROJECT_INVARIANT_AUDIT_PATH, default={})
    agent_entrypoints = load_json(AGENT_ENTRYPOINT_AUDIT_PATH, default={})
    operator_intent = load_json(OPERATOR_INTENT_CONTRACT_AUDIT_PATH, default={})
    impact_radius = load_json(IMPACT_RADIUS_ASSESSMENT_PATH, default={})
    autonomy_governor = load_json(AUTONOMY_GOVERNOR_AUDIT_PATH, default={})
    fresh_session_readiness = load_json(FRESH_SESSION_READINESS_AUDIT_PATH, default={})
    fresh_data = load_json(FRESH_DATA_INTAKE_PATH, default={})
    vivi_job_cards = apply_vivi_job_card_completion_state(load_json(VIVI_JOB_CARD_QUEUE_PATH, default={}))
    vivi_runner = load_json(VIVI_RUNNER_LAST_RUN_PATH, default={})
    vivi_supervisor = load_json(VIVI_SUPERVISOR_AUDIT_PATH, default={})
    commit_cleanup_package = load_json(COMMIT_CLEANUP_GO_PACKAGE_PATH, default={})
    vivi_worker_queue = load_json(VIVI_WORKER_QUEUE_PATH, default={})
    vivi_worker = load_json(VIVI_WORKER_LAST_RUN_PATH, default={})
    vivi_worker_supervisor = load_json(VIVI_WORKER_SUPERVISOR_AUDIT_PATH, default={})
    snapshot = {
        "schema_version": 1,
        "snapshot_id": f"{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')}-{safe_slug(label)}",
        "label": label,
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "improvement_evidence": improvement,
        "full_check_status": report.get("status", "UNKNOWN") if isinstance(report, dict) else "UNKNOWN",
        "implementation_status": summary.get("implementation_status", "UNKNOWN"),
        "coverage_status": summary.get("coverage_status", "UNKNOWN"),
        "operator_risk_status": summary.get("operator_risk_status", "UNKNOWN"),
        "policy_gate_status": summary.get("policy_gate_status", "UNKNOWN"),
        "node_count": summary.get("node_count", 0),
        "relationship_count": summary.get("relationship_count", 0),
        "warning_count": summary.get("warning_count", 0),
        "selftest_check_count": selftest["check_count"],
        "selftest_failed_count": selftest["failed_count"],
        "selftest_failed_checks": selftest["failed_checks"],
        "active_high_risk_automations": count_active_high_risk(),
        "unresolved_decisions": decisions.get("unresolved_count", 0),
        "unresolved_p0_decisions": count_p0_unresolved(decisions),
        "coverage_gaps": count_coverage_gaps(),
        "policy_items": count_policy_items(),
        "hardening_contract_status": contracts.get("status", "UNKNOWN"),
        "hardening_contract_count": contracts.get("contracts_checked", 0),
        "contract_quality_status": contract_quality.get("status", "UNKNOWN"),
        "contract_quality_fail_count": contract_quality.get("fail_count", 0),
        "contract_quality_warn_count": contract_quality.get("warn_count", 0),
        "rule_propagation_status": rule_propagation.get("status", "UNKNOWN"),
        "rule_propagation_warnings": len([item for item in rule_propagation.get("items", []) if item.get("status") == "WARN"]),
        "project_invariant_status": project_invariants.get("status", "UNKNOWN"),
        "agent_entrypoint_status": agent_entrypoints.get("status", "UNKNOWN"),
        "operator_intent_contract_status": operator_intent.get("status", "UNKNOWN"),
        "impact_radius_status": impact_radius.get("status", "UNKNOWN"),
        "impact_radius_matches": len(impact_radius.get("matches", [])),
        "autonomy_governor_status": autonomy_governor.get("status", "UNKNOWN"),
        "autonomy_safe_work_remaining": autonomy_governor.get("ready_or_in_progress_count", 0),
        "fresh_session_readiness_status": fresh_session_readiness.get("status", "UNKNOWN"),
        "fresh_session_readiness_warnings": fresh_session_readiness.get("warning_count", 0),
        "fresh_data_intake_status": fresh_data.get("status", "UNKNOWN"),
        "fresh_data_action_items": fresh_data.get("action_item_count", 0),
        "fresh_data_fresh_items": fresh_data.get("fresh_item_count", 0),
        "vivi_job_card_queue_status": vivi_job_cards.get("status", "UNKNOWN"),
        "vivi_job_card_count": vivi_job_cards.get("job_card_count", 0),
        "vivi_job_cards_ready": vivi_job_cards.get("ready_count", 0),
        "vivi_job_cards_completed_verified": vivi_job_cards.get("completed_verified_count", 0),
        "vivi_job_cards_open_action_items": vivi_job_cards.get("open_action_item_count", 0),
        "vivi_runner_status": vivi_runner.get("status", "UNKNOWN"),
        "vivi_runner_runtime_action_executed": vivi_runner.get("runtime_action_executed", False),
        "vivi_supervisor_status": vivi_supervisor.get("status", "UNKNOWN"),
        "vivi_supervisor_truth_status": vivi_supervisor.get("truth_status", "UNKNOWN"),
        "commit_cleanup_go_package_status": commit_cleanup_package.get("status", "UNKNOWN"),
        "commit_cleanup_go_package_decisions": commit_cleanup_package.get("summary", {}).get("decision_card_count", 0),
        "commit_cleanup_go_runtime_action_executed": commit_cleanup_package.get("runtime_action_executed", None),
        "vivi_worker_queue_status": vivi_worker_queue.get("status", "UNKNOWN"),
        "vivi_worker_ready_count": vivi_worker_queue.get("ready_count", 0),
        "vivi_worker_status": vivi_worker.get("status", "UNKNOWN"),
        "vivi_worker_runtime_action_executed": vivi_worker.get("runtime_action_executed", None),
        "vivi_worker_supervisor_status": vivi_worker_supervisor.get("status", "UNKNOWN"),
        "vivi_worker_supervisor_truth_status": vivi_worker_supervisor.get("truth_status", "UNKNOWN"),
    }
    return snapshot


def write_quality_snapshot(snapshot: dict[str, Any], *, update_baseline: bool) -> dict[str, str]:
    QUALITY_SNAPSHOTS_DIR.mkdir(parents=True, exist_ok=True)
    target = QUALITY_SNAPSHOTS_DIR / f"{snapshot['snapshot_id']}.json"
    write_json(target, snapshot)
    if update_baseline:
        write_json(QUALITY_BASELINE_PATH, snapshot)
    return {"snapshot_path": str(target), "baseline_path": str(QUALITY_BASELINE_PATH) if update_baseline else ""}


def create_quality_baseline(label: str) -> dict[str, Any]:
    full_check = run_full_check()
    snapshot = build_quality_snapshot(label, full_check=full_check)
    paths = write_quality_snapshot(snapshot, update_baseline=True)
    result = {"status": "PASS" if full_check.get("status") == "PASS" else "FAIL", "snapshot": snapshot, **paths}
    write_json(OUTPUT_DIR / "quality_baseline_report.json", result)
    baseline_md = quality_snapshot_to_markdown("Quality Baseline", result)
    (OUTPUT_DIR / "quality_baseline_report.md").write_text(baseline_md, encoding="utf-8")
    (OUTPUT_DIR / "quality_baseline.md").write_text(baseline_md, encoding="utf-8")
    return result


def quality_snapshot_to_markdown(title: str, payload: dict[str, Any]) -> str:
    snapshot = payload.get("snapshot", payload)
    lines = ["# " + title, "", f"- Status: `{payload.get('status', snapshot.get('full_check_status', 'UNKNOWN'))}`", ""]
    for key in [
        "snapshot_id",
        "label",
        "full_check_status",
        "implementation_status",
        "coverage_status",
        "operator_risk_status",
        "policy_gate_status",
        "selftest_check_count",
        "selftest_failed_count",
        "active_high_risk_automations",
        "unresolved_p0_decisions",
        "coverage_gaps",
        "policy_items",
        "hardening_contract_status",
        "contract_quality_status",
        "contract_quality_fail_count",
        "rule_propagation_status",
        "rule_propagation_warnings",
        "project_invariant_status",
        "agent_entrypoint_status",
        "operator_intent_contract_status",
        "impact_radius_status",
        "impact_radius_matches",
        "autonomy_governor_status",
        "autonomy_safe_work_remaining",
        "fresh_session_readiness_status",
        "fresh_session_readiness_warnings",
        "fresh_data_intake_status",
        "fresh_data_action_items",
        "fresh_data_fresh_items",
        "vivi_job_card_queue_status",
        "vivi_job_card_count",
        "vivi_job_cards_ready",
        "vivi_job_cards_completed_verified",
        "vivi_job_cards_open_action_items",
        "vivi_runner_status",
        "vivi_runner_runtime_action_executed",
        "vivi_supervisor_status",
        "vivi_supervisor_truth_status",
        "commit_cleanup_go_package_status",
        "commit_cleanup_go_package_decisions",
        "commit_cleanup_go_runtime_action_executed",
        "vivi_worker_queue_status",
        "vivi_worker_ready_count",
        "vivi_worker_status",
        "vivi_worker_runtime_action_executed",
        "vivi_worker_supervisor_status",
        "vivi_worker_supervisor_truth_status",
    ]:
        lines.append(f"- `{key}`: `{snapshot.get(key, '')}`")
    if snapshot.get("improvement_evidence"):
        lines.append(f"- `improvement_evidence`: {snapshot['improvement_evidence']}")
    return "\n".join(lines) + "\n"


def compare_quality_snapshots(baseline: dict[str, Any], current: dict[str, Any], improvement: str, allow_known_warnings: bool) -> dict[str, Any]:
    failures = []
    improvements = []
    warnings = []

    def fail_if_worse(key: str, lower_is_better: bool = False) -> None:
        before = baseline.get(key, 0)
        after = current.get(key, 0)
        if lower_is_better and after > before:
            failures.append(f"{key} increased from {before} to {after}")
        if not lower_is_better and after < before:
            failures.append(f"{key} decreased from {before} to {after}")
        if lower_is_better and after < before:
            improvements.append(f"{key} improved from {before} to {after}")
        if not lower_is_better and after > before:
            improvements.append(f"{key} improved from {before} to {after}")

    if current.get("full_check_status") != "PASS":
        failures.append(f"full_check_status is {current.get('full_check_status')}")
    if current.get("implementation_status") != "PASS":
        failures.append(f"implementation_status is {current.get('implementation_status')}")
    if current.get("selftest_failed_count", 0) > 0:
        failures.append(f"selftest has failed checks: {current.get('selftest_failed_checks')}")
    if current.get("hardening_contract_status") not in {"PASS", "EMPTY"}:
        failures.append(f"hardening_contract_status is {current.get('hardening_contract_status')}")
    if current.get("contract_quality_status") not in {"PASS", "WARN"}:
        failures.append(f"contract_quality_status is {current.get('contract_quality_status')}")
    if current.get("contract_quality_fail_count", 0) > 0:
        failures.append(f"contract_quality_fail_count is {current.get('contract_quality_fail_count')}")
    for key in ["rule_propagation_status", "project_invariant_status", "agent_entrypoint_status", "operator_intent_contract_status", "impact_radius_status", "autonomy_governor_status", "fresh_session_readiness_status", "fresh_data_intake_status", "vivi_job_card_queue_status", "vivi_supervisor_status", "vivi_worker_queue_status", "vivi_worker_supervisor_status"]:
        if current.get(key) not in {"PASS", "WARN"}:
            failures.append(f"{key} is {current.get(key)}")
    if current.get("vivi_runner_status") not in {"completed_verified", "closed_no_action", "waiting_for_operator", "waiting_for_evidence", "UNKNOWN"}:
        failures.append(f"vivi_runner_status is {current.get('vivi_runner_status')}")
    if current.get("vivi_runner_runtime_action_executed") is True:
        failures.append("vivi_runner_runtime_action_executed is True")
    if current.get("commit_cleanup_go_package_status") not in {"operator_go_required", "needs_local_review", "blocked_by_missing_evidence", "closed_no_action", "UNKNOWN"}:
        failures.append(f"commit_cleanup_go_package_status is {current.get('commit_cleanup_go_package_status')}")
    if current.get("commit_cleanup_go_runtime_action_executed") is True:
        failures.append("commit_cleanup_go_runtime_action_executed is True")
    if current.get("vivi_worker_status") not in {"completed_verified", "closed_no_action", "waiting_for_operator", "failed_safe", "UNKNOWN"}:
        failures.append(f"vivi_worker_status is {current.get('vivi_worker_status')}")
    if current.get("vivi_worker_runtime_action_executed") is True:
        failures.append("vivi_worker_runtime_action_executed is True")

    for key in ["coverage_status", "operator_risk_status", "policy_gate_status", "rule_propagation_status", "project_invariant_status", "agent_entrypoint_status", "operator_intent_contract_status", "impact_radius_status", "autonomy_governor_status", "fresh_session_readiness_status", "fresh_data_intake_status", "vivi_job_card_queue_status", "vivi_supervisor_status", "vivi_worker_queue_status", "vivi_worker_supervisor_status"]:
        if status_rank(current.get(key, "UNKNOWN")) < status_rank(baseline.get(key, "UNKNOWN")):
            failures.append(f"{key} regressed from {baseline.get(key)} to {current.get(key)}")
        elif status_rank(current.get(key, "UNKNOWN")) > status_rank(baseline.get(key, "UNKNOWN")):
            improvements.append(f"{key} improved from {baseline.get(key)} to {current.get(key)}")

    fail_if_worse("selftest_check_count", lower_is_better=False)
    fail_if_worse("active_high_risk_automations", lower_is_better=True)
    fail_if_worse("unresolved_p0_decisions", lower_is_better=True)
    fail_if_worse("coverage_gaps", lower_is_better=True)
    fail_if_worse("policy_items", lower_is_better=True)
    fail_if_worse("rule_propagation_warnings", lower_is_better=True)
    fail_if_worse("impact_radius_matches", lower_is_better=False)

    if current.get("warning_count", 0) > baseline.get("warning_count", 0) and not allow_known_warnings:
        failures.append(f"warning_count increased from {baseline.get('warning_count')} to {current.get('warning_count')}")
    elif current.get("warning_count", 0) < baseline.get("warning_count", 0):
        improvements.append(f"warning_count improved from {baseline.get('warning_count')} to {current.get('warning_count')}")
    elif current.get("warning_count", 0) > baseline.get("warning_count", 0):
        warnings.append(f"warning_count increased but was explicitly allowed: {baseline.get('warning_count')} -> {current.get('warning_count')}")

    if not improvement.strip() and not improvements:
        failures.append("missing improvement evidence; pass --improvement or produce a measurable improvement")
    elif improvement.strip():
        improvements.append(f"declared improvement: {improvement.strip()}")

    return {
        "status": "PASS" if not failures else "FAIL",
        "failures": failures,
        "warnings": warnings,
        "improvements": improvements,
    }


def run_quality_gate(baseline_path: Path, improvement: str, allow_known_warnings: bool = False) -> dict[str, Any]:
    baseline = load_json(baseline_path, default=None)
    if not isinstance(baseline, dict):
        result = {"status": "FAIL", "failures": [f"baseline not found or invalid: {baseline_path}"], "warnings": [], "improvements": []}
        write_json(QUALITY_GATE_REPORT_PATH, result)
        return result
    full_check = run_full_check()
    current = build_quality_snapshot("quality-gate-current", full_check=full_check, improvement=improvement)
    paths = write_quality_snapshot(current, update_baseline=False)
    comparison = compare_quality_snapshots(baseline, current, improvement, allow_known_warnings)
    result = {
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": comparison["status"],
        "baseline_path": str(baseline_path),
        "current_snapshot_path": paths["snapshot_path"],
        "baseline": baseline,
        "current": current,
        **comparison,
    }
    write_json(QUALITY_GATE_REPORT_PATH, result)
    (OUTPUT_DIR / "quality_gate_report.md").write_text(quality_gate_to_markdown(result), encoding="utf-8")
    return result


def quality_gate_to_markdown(payload: dict[str, Any]) -> str:
    lines = ["# Project Intelligence Graph Quality Gate", "", f"- Status: `{payload.get('status', 'UNKNOWN')}`", ""]
    lines.extend(["## Failures", ""])
    if payload.get("failures"):
        for item in payload["failures"]:
            lines.append(f"- {item}")
    else:
        lines.append("- None.")
    lines.extend(["", "## Improvements", ""])
    for item in payload.get("improvements", []) or ["None recorded."]:
        lines.append(f"- {item}")
    lines.extend(["", "## Warnings", ""])
    for item in payload.get("warnings", []) or ["None."]:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"


def unique_relationships(rels: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return list({rel["id"]: rel for rel in rels}.values())


def unique_nodes(nodes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return list({node["id"]: node for node in nodes}.values())


def render_view_index(written: dict[str, str]) -> str:
    links = "\n".join(f"<li><a href=\"{html.escape(name)}\">{html.escape(name.replace('-', ' ').replace('.html', '').title())}</a></li>" for name in sorted(written))
    return f"""<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Project Intelligence Graph Views</title>
  <style>
    body {{ font-family:ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; margin:0; padding:36px; color:#1d252b; }}
    h1 {{ margin-top:0; letter-spacing:0; }}
    li {{ margin:10px 0; }}
    a {{ color:#0f766e; }}
  </style>
</head>
<body>
  <h1>Project Intelligence Graph Views</h1>
  <ul>{links}</ul>
</body>
</html>
"""


def run_selftest(store: GraphStore) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []

    def check(name: str, condition: bool, detail: str) -> None:
        checks.append({"name": name, "status": "PASS" if condition else "FAIL", "detail": detail})

    global_result = store.global_search("Quellwert", limit=8)
    check("global_search", bool(global_result["nodes"] or global_result["relationships"]), f"nodes={len(global_result['nodes'])} relationships={len(global_result['relationships'])}")
    local_result = store.local_search("Project - Quellwert", depth=2, limit=40)
    check("local_search", bool(local_result["nodes"] and local_result["relationships"]), f"nodes={len(local_result['nodes'])} relationships={len(local_result['relationships'])}")
    hybrid_result = store.hybrid_search("Room16", depth=2, limit=20)
    check(
        "hybrid_search",
        bool(hybrid_result["nodes"] and hybrid_result["relationships"]),
        f"query=Room16 nodes={len(hybrid_result['nodes'])} relationships={len(hybrid_result['relationships'])}",
    )
    explanation = store.explain("Project Intelligence Graph")
    check("explain", bool(explanation["incoming"] or explanation["outgoing"]), f"incoming={len(explanation['incoming'])} outgoing={len(explanation['outgoing'])}")
    context_pack = OUTPUT_DIR / "context_packs/selftest-qualitydecision.md"
    write_context_pack(store, "QualityDecision public_ready", context_pack)
    check("context_pack", context_pack.exists() and context_pack.stat().st_size > 0, str(context_pack))
    written = render_views(store)
    check("render_views", len(written) >= 8 and all(Path(path).exists() and Path(path).stat().st_size > 0 for path in written.values()), f"views={len(written)}")
    check("drift_report", DRIFT_REPORT_PATH.exists() and "Implementation status: `PASS`" in DRIFT_REPORT_PATH.read_text(encoding="utf-8"), str(DRIFT_REPORT_PATH))
    no_unknown = not any(node["type"] == "UnknownTarget" for node in store.nodes.values())
    check("no_unknown_targets", no_unknown, "UnknownTarget nodes absent")
    risk_payload = load_json(AUTOMATION_RISK_PATH, default={})
    check("automation_risk_registry", bool(risk_payload.get("items")) and risk_payload.get("status") in {"PASS", "WARN"}, f"items={len(risk_payload.get('items', []))} status={risk_payload.get('status')}")
    decision_payload = load_json(OPERATOR_DECISION_PATH, default={})
    check("operator_decision_inbox", bool(decision_payload.get("items")) and decision_payload.get("status") in {"CLEAR", "REVIEW", "ACTION_REQUIRED"}, f"items={len(decision_payload.get('items', []))} status={decision_payload.get('status')}")
    coverage_payload = load_json(COVERAGE_MANIFEST_PATH, default={})
    check("coverage_manifest", bool(coverage_payload.get("sources")) and coverage_payload.get("status") in {"PASS", "WARN"}, f"sources={len(coverage_payload.get('sources', []))} status={coverage_payload.get('status')}")
    policy_payload = load_json(POLICY_GATE_PATH, default={})
    check("policy_gate_report", policy_payload.get("status") in {"PASS", "WARN"}, f"items={len(policy_payload.get('items', []))} status={policy_payload.get('status')}")
    contract_quality_payload = load_json(CONTRACT_QUALITY_PATH, default={})
    check(
        "contract_quality_gate",
        contract_quality_payload.get("status") in {"PASS", "WARN"} and contract_quality_payload.get("fail_count", 1) == 0,
        f"items={len(contract_quality_payload.get('items', []))} status={contract_quality_payload.get('status')} fails={contract_quality_payload.get('fail_count')}",
    )
    check(
        "schema_registries",
        all(path.exists() and path.stat().st_size > 0 for path in [NODE_SCHEMA_PATH, PREDICATE_REGISTRY_PATH, POLICY_RULES_PATH, HARDENING_FIX_SCHEMA_PATH, QUALITY_SNAPSHOT_SCHEMA_PATH, BUILD_CONTRACT_SCHEMA_PATH, JOB_CARD_SCHEMA_PATH, EXECUTION_HISTORY_SCHEMA_PATH, LONG_RUN_COMPLETION_SCHEMA_PATH, RULE_PROPAGATION_SCHEMA_PATH, RULE_PROPAGATION_REGISTRY_PATH, PROJECT_INVARIANT_SCHEMA_PATH, PROJECT_INVARIANT_REGISTRY_PATH, AGENT_ENTRYPOINT_SCHEMA_PATH, AGENT_ENTRYPOINT_REGISTRY_PATH, OPERATOR_INTENT_CONTRACT_SCHEMA_PATH, IMPACT_RADIUS_RULES_SCHEMA_PATH, IMPACT_RADIUS_RULES_PATH, GERMAN_OUTPUT_QUALITY_SCHEMA_PATH, GERMAN_OUTPUT_QUALITY_REGISTRY_PATH, AUTONOMY_GOVERNOR_SCHEMA_PATH, AUTONOMY_GOVERNOR_REGISTRY_PATH, FRESH_SESSION_READINESS_SCHEMA_PATH, FRESH_DATA_INTAKE_SCHEMA_PATH, VIVI_JOB_CARD_QUEUE_SCHEMA_PATH, VIVI_RUNNER_SCHEMA_PATH, VIVI_SUPERVISOR_AUDIT_SCHEMA_PATH, COMMIT_CLEANUP_GO_PACKAGE_SCHEMA_PATH, VIVI_WORKER_QUEUE_SCHEMA_PATH, VIVI_WORKER_SCHEMA_PATH, VIVI_WORKER_SUPERVISOR_AUDIT_SCHEMA_PATH, ENDGAME_ROADMAP_SCHEMA_PATH, VIVI_CAPABILITY_MATRIX_SCHEMA_PATH, PROJECT_VERTICAL_ROLLOUT_SCHEMA_PATH, LAUNCH_READINESS_SCHEMA_PATH]),
        "node_schema predicate_registry policy_rules hardening_fix_schema quality_snapshot_schema build_contract_schema job_card_schema execution_history_schema long_run_completion_schema rule_propagation project_invariant agent_entrypoint operator_intent impact_radius german_output_quality autonomy_governor fresh_session_readiness fresh_data_intake vivi_job_card_queue vivi_runner vivi_supervisor commit_cleanup_go_package vivi_worker present",
    )
    operator_brief = build_operator_brief()
    check(
        "operator_brief",
        operator_brief.get("overall_status") in {"CLEAR", "REVIEW", "ACTION_REQUIRED"} and bool(operator_brief.get("do_this_now")),
        f"status={operator_brief.get('overall_status')} actions={len(operator_brief.get('do_this_now', []))}",
    )
    contracts = validate_fix_contracts()
    check(
        "hardening_fix_contracts",
        contracts.get("status") in {"PASS", "EMPTY"},
        f"contracts={contracts.get('contracts_checked')} status={contracts.get('status')}",
    )
    quality_gate = load_json(QUALITY_GATE_REPORT_PATH, default={})
    quality_baseline = load_json(QUALITY_BASELINE_PATH, default={})
    check(
        "quality_control_outputs",
        bool(quality_baseline) and quality_gate.get("status") in {"PASS", "FAIL"},
        f"baseline={bool(quality_baseline)} quality_gate={quality_gate.get('status', 'MISSING')}",
    )
    quality_os_validation = validate_quality_os()
    quality_os_surface = build_quality_os_operator_surface(write=True)
    check(
        "quality_os_contracts",
        quality_os_validation.get("status") == "PASS" and quality_os_surface.get("status") == "PASS",
        f"validation={quality_os_validation.get('status')} surface={quality_os_surface.get('status')} runs={len(quality_os_surface.get('workflow_runs', []))}",
    )

    status = "PASS" if all(item["status"] == "PASS" for item in checks) else "FAIL"
    report = {
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": status,
        "checks": checks,
    }
    (OUTPUT_DIR / "v1_verification_report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    lines = ["# Project Intelligence Graph v1 Verification", "", f"- Status: `{status}`", ""]
    for item in checks:
        lines.append(f"- `{item['status']}` {item['name']}: {item['detail']}")
    (OUTPUT_DIR / "v1_verification_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return report


def print_result(payload: Any, as_json: bool) -> None:
    if as_json:
        print(json.dumps(payload, indent=2, ensure_ascii=False))
    else:
        print(payload)


def load_decision_state() -> dict[str, Any]:
    payload = load_json(OPERATOR_DECISION_STATE_PATH, default={})
    if not isinstance(payload, dict):
        return {"version": 1, "items": {}}
    payload.setdefault("version", 1)
    payload.setdefault("items", {})
    return payload


def apply_decision_state(payload: dict[str, Any]) -> dict[str, Any]:
    state = load_decision_state().get("items", {})
    items = []
    for item in payload.get("items", []):
        merged = dict(item)
        item_state = state.get(item.get("item_id"), {})
        merged["operator_state"] = item_state.get("state", "open")
        if item_state.get("note"):
            merged["operator_note"] = item_state["note"]
        if item_state.get("updated_at"):
            merged["operator_updated_at"] = item_state["updated_at"]
        items.append(merged)
    result = dict(payload)
    result["items"] = items
    unresolved = [item for item in items if item.get("operator_state", "open") not in {"accepted", "closed"}]
    result["unresolved_count"] = len(unresolved)
    if any(item.get("priority") == "P0" for item in unresolved):
        result["status"] = "ACTION_REQUIRED"
    elif unresolved:
        result["status"] = "REVIEW"
    else:
        result["status"] = "CLEAR"
    return result


def update_decision_state(item_id: str, state_value: str, note: str = "") -> dict[str, Any]:
    state = load_decision_state()
    state["items"][item_id] = {
        "state": state_value,
        "note": note,
        "updated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
    }
    write_json(OPERATOR_DECISION_STATE_PATH, state)
    return state["items"][item_id]


def run_step(name: str, command: list[str]) -> dict[str, Any]:
    started = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    completed = subprocess.run(command, cwd=WORKSPACE, text=True, capture_output=True)
    return {
        "name": name,
        "status": "PASS" if completed.returncode == 0 else "FAIL",
        "returncode": completed.returncode,
        "started_at": started,
        "command": command,
        "stdout_tail": completed.stdout[-4000:],
        "stderr_tail": completed.stderr[-4000:],
    }


def run_full_check() -> dict[str, Any]:
    scanner = WORKSPACE / "scripts/project_intelligence_graph/scan_project_intelligence_graph.py"
    cli = WORKSPACE / "scripts/project_intelligence_graph/pig.py"
    steps = [
        run_step("py_compile", [sys.executable, "-m", "py_compile", str(scanner), str(cli)]),
        run_step("scan", [sys.executable, str(scanner)]),
        run_step("validate", [sys.executable, str(scanner), "--validate"]),
    ]
    if all(step["status"] == "PASS" for step in steps):
        store = GraphStore.load()
        selftest = run_selftest(store)
        steps.append({
            "name": "selftest",
            "status": selftest.get("status", "FAIL"),
            "returncode": 0 if selftest.get("status") == "PASS" else 1,
            "checks": selftest.get("checks", []),
        })
    if all(step["status"] == "PASS" for step in steps):
        long_run_audit = load_json(LONG_RUN_COMPLETION_AUDIT_PATH, default={})
        steps.append({
            "name": "long_run_completion_audit",
            "status": "PASS" if long_run_audit.get("status") == "PASS" else "FAIL",
            "returncode": 0 if long_run_audit.get("status") == "PASS" else 1,
            "reports_checked": long_run_audit.get("reports_checked", 0),
        })
        vault_umlaut = load_json(VAULT_UMLAUT_HYGIENE_PATH, default={})
        steps.append({
            "name": "vault_umlaut_hygiene",
            "status": "PASS" if vault_umlaut.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if vault_umlaut.get("status") in {"PASS", "WARN"} else 1,
            "hygiene_status": vault_umlaut.get("status", "UNKNOWN"),
            "finding_count": vault_umlaut.get("finding_count", 0),
        })
        skill_policy_audit = load_json(SKILL_POLICY_REGRESSION_AUDIT_PATH, default={})
        steps.append({
            "name": "skill_policy_regression_guard_audit",
            "status": "PASS" if skill_policy_audit.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if skill_policy_audit.get("status") in {"PASS", "WARN"} else 1,
            "audit_status": skill_policy_audit.get("status", "UNKNOWN"),
            "warnings": len([item for item in skill_policy_audit.get("items", []) if item.get("status") == "WARN"]),
        })
        rule_propagation = load_json(RULE_PROPAGATION_AUDIT_PATH, default={})
        steps.append({
            "name": "rule_propagation_audit",
            "status": "PASS" if rule_propagation.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if rule_propagation.get("status") in {"PASS", "WARN"} else 1,
            "audit_status": rule_propagation.get("status", "UNKNOWN"),
            "rules_checked": rule_propagation.get("rules_checked", 0),
            "warnings": len([item for item in rule_propagation.get("items", []) if item.get("status") == "WARN"]),
        })
        project_invariants = load_json(PROJECT_INVARIANT_AUDIT_PATH, default={})
        steps.append({
            "name": "project_invariant_audit",
            "status": "PASS" if project_invariants.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if project_invariants.get("status") in {"PASS", "WARN"} else 1,
            "audit_status": project_invariants.get("status", "UNKNOWN"),
            "projects_checked": project_invariants.get("projects_checked", 0),
        })
        agent_entrypoints = load_json(AGENT_ENTRYPOINT_AUDIT_PATH, default={})
        steps.append({
            "name": "agent_entrypoint_audit",
            "status": "PASS" if agent_entrypoints.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if agent_entrypoints.get("status") in {"PASS", "WARN"} else 1,
            "audit_status": agent_entrypoints.get("status", "UNKNOWN"),
            "entrypoints_checked": agent_entrypoints.get("entrypoints_checked", 0),
        })
        operator_intent = load_json(OPERATOR_INTENT_CONTRACT_AUDIT_PATH, default={})
        steps.append({
            "name": "operator_intent_contract_audit",
            "status": "PASS" if operator_intent.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if operator_intent.get("status") in {"PASS", "WARN"} else 1,
            "audit_status": operator_intent.get("status", "UNKNOWN"),
        })
        autonomy_queue = build_autonomy_execution_queue(write=True)
        steps.append({
            "name": "autonomy_execution_queue",
            "status": "PASS" if autonomy_queue.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if autonomy_queue.get("status") in {"PASS", "WARN"} else 1,
            "queue_status": autonomy_queue.get("status", "UNKNOWN"),
            "current_block": autonomy_queue.get("current_block", ""),
            "block_count": len(autonomy_queue.get("blocks", [])),
        })
        dirt_backlog = build_autonomy_dirt_backlog_scan(write=True, run_verifiers=False)
        steps.append({
            "name": "autonomy_dirt_backlog_scan",
            "status": "PASS" if dirt_backlog.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if dirt_backlog.get("status") in {"PASS", "WARN"} else 1,
            "scan_status": dirt_backlog.get("status", "UNKNOWN"),
            "projects_checked": dirt_backlog.get("projects_checked", 0),
            "dirty_projects": dirt_backlog.get("dirty_project_count", 0),
            "missing_projects": dirt_backlog.get("missing_project_count", 0),
        })
        commit_cleanup = build_commit_cleanup_go_package(write=True)
        steps.append({
            "name": "commit_cleanup_go_package",
            "status": "PASS" if commit_cleanup.get("status") in {"operator_go_required", "needs_local_review", "blocked_by_missing_evidence", "closed_no_action"} and not commit_cleanup.get("runtime_action_executed") else "FAIL",
            "returncode": 0 if commit_cleanup.get("status") in {"operator_go_required", "needs_local_review", "blocked_by_missing_evidence", "closed_no_action"} and not commit_cleanup.get("runtime_action_executed") else 1,
            "package_status": commit_cleanup.get("status", "UNKNOWN"),
            "decision_cards": commit_cleanup.get("summary", {}).get("decision_card_count", 0),
            "runtime_action_executed": commit_cleanup.get("runtime_action_executed", None),
        })
        vivi_handoff = build_vivi_vega_handoff_inbox(write=True)
        steps.append({
            "name": "vivi_vega_handoff_inbox",
            "status": "PASS" if vivi_handoff.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if vivi_handoff.get("status") in {"PASS", "WARN"} else 1,
            "inbox_status": vivi_handoff.get("status", "UNKNOWN"),
            "items": vivi_handoff.get("item_count", 0),
            "action_items": vivi_handoff.get("action_item_count", 0),
            "needs_vega_review": vivi_handoff.get("needs_vega_review_count", 0),
            "operator_gates": vivi_handoff.get("operator_gate_count", 0),
        })
        impact_radius = build_impact_radius_assessment(write=True)
        steps.append({
            "name": "impact_radius_assessment",
            "status": "PASS" if impact_radius.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if impact_radius.get("status") in {"PASS", "WARN"} else 1,
            "assessment_status": impact_radius.get("status", "UNKNOWN"),
            "matches": len(impact_radius.get("matches", [])),
            "affected_projects": impact_radius.get("affected_projects", []),
        })
        german_output = build_german_output_quality_audit(write=True)
        steps.append({
            "name": "german_output_quality_gate",
            "status": "PASS" if german_output.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if german_output.get("status") in {"PASS", "WARN"} else 1,
            "audit_status": german_output.get("status", "UNKNOWN"),
            "finding_count": german_output.get("finding_count", 0),
            "fail_count": german_output.get("fail_count", 0),
            "warn_count": german_output.get("warn_count", 0),
        })
        vivi_capabilities = build_vivi_capability_matrix(write=True)
        steps.append({
            "name": "vivi_capability_matrix",
            "status": "PASS" if vivi_capabilities.get("status") == "PASS" else "FAIL",
            "returncode": 0 if vivi_capabilities.get("status") == "PASS" else 1,
            "matrix_status": vivi_capabilities.get("status", "UNKNOWN"),
            "ready_claim_type_count": vivi_capabilities.get("ready_claim_type_count", 0),
            "verified_claim_type_count": vivi_capabilities.get("verified_claim_type_count", 0),
        })
        project_verticals = build_project_vertical_rollout(write=True)
        steps.append({
            "name": "project_vertical_rollout",
            "status": "PASS" if project_verticals.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if project_verticals.get("status") in {"PASS", "WARN"} else 1,
            "rollout_status": project_verticals.get("status", "UNKNOWN"),
            "project_count": project_verticals.get("project_count", 0),
            "missing_verifier_count": project_verticals.get("missing_verifier_count", 0),
        })
        launch_readiness = build_launch_readiness_package(write=True)
        steps.append({
            "name": "launch_readiness_package",
            "status": "PASS" if launch_readiness.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if launch_readiness.get("status") in {"PASS", "WARN"} else 1,
            "readiness_status": launch_readiness.get("status", "UNKNOWN"),
            "package_count": launch_readiness.get("package_count", 0),
            "operator_gate_count": launch_readiness.get("operator_gate_count", 0),
        })
        autonomy_governor = build_autonomy_governor_audit(write=True)
        steps.append({
            "name": "autonomy_governor",
            "status": "PASS" if autonomy_governor.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if autonomy_governor.get("status") in {"PASS", "WARN"} else 1,
            "audit_status": autonomy_governor.get("status", "UNKNOWN"),
            "autonomy_state": autonomy_governor.get("autonomy_state", "UNKNOWN"),
            "ready_or_in_progress_count": autonomy_governor.get("ready_or_in_progress_count", 0),
        })
        endgame = build_endgame_roadmap(write=True)
        steps.append({
            "name": "endgame_roadmap",
            "status": "PASS" if endgame.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if endgame.get("status") in {"PASS", "WARN"} else 1,
            "roadmap_status": endgame.get("status", "UNKNOWN"),
            "completion_percent": endgame.get("completion_percent", 0),
            "current_phase": endgame.get("current_phase", ""),
            "safe_next_blocks": len(endgame.get("safe_next_blocks", [])),
        })
        fresh_session = build_fresh_session_readiness_audit(write=True)
        steps.append({
            "name": "fresh_session_readiness",
            "status": "PASS" if fresh_session.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if fresh_session.get("status") in {"PASS", "WARN"} else 1,
            "audit_status": fresh_session.get("status", "UNKNOWN"),
            "targets_checked": fresh_session.get("targets_checked", 0),
            "warnings": fresh_session.get("warning_count", 0),
            "fails": fresh_session.get("fail_count", 0),
        })
        fresh_data = build_fresh_data_intake(write=True)
        steps.append({
            "name": "fresh_data_intake",
            "status": "PASS" if fresh_data.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if fresh_data.get("status") in {"PASS", "WARN"} else 1,
            "intake_status": fresh_data.get("status", "UNKNOWN"),
            "fresh_items": fresh_data.get("fresh_item_count", 0),
            "action_items": fresh_data.get("action_item_count", 0),
            "operator_gates": fresh_data.get("operator_gate_count", 0),
        })
        vivi_job_cards = build_vivi_job_card_queue(write=True)
        steps.append({
            "name": "vivi_job_card_queue",
            "status": "PASS" if vivi_job_cards.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if vivi_job_cards.get("status") in {"PASS", "WARN"} else 1,
            "queue_status": vivi_job_cards.get("status", "UNKNOWN"),
            "job_cards": vivi_job_cards.get("job_card_count", 0),
            "ready": vivi_job_cards.get("ready_count", 0),
            "waiting_for_operator": vivi_job_cards.get("waiting_for_operator_count", 0),
        })
        vivi_runner = run_vivi_runner_mvp(write=True)
        steps.append({
            "name": "vivi_runner_mvp",
            "status": "PASS" if vivi_runner.get("status") in {"completed_verified", "closed_no_action", "waiting_for_operator", "waiting_for_evidence"} and not vivi_runner.get("runtime_action_executed") else "FAIL",
            "returncode": 0 if vivi_runner.get("status") in {"completed_verified", "closed_no_action", "waiting_for_operator", "waiting_for_evidence"} and not vivi_runner.get("runtime_action_executed") else 1,
            "runner_status": vivi_runner.get("status", "UNKNOWN"),
            "job_card_id": vivi_runner.get("job_card_id", ""),
            "runtime_action_executed": vivi_runner.get("runtime_action_executed", None),
        })
        vivi_supervisor = build_vivi_supervisor_audit(write=True)
        steps.append({
            "name": "vivi_supervisor_audit",
            "status": "PASS" if vivi_supervisor.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if vivi_supervisor.get("status") in {"PASS", "WARN"} else 1,
            "audit_status": vivi_supervisor.get("status", "UNKNOWN"),
            "truth_status": vivi_supervisor.get("truth_status", "UNKNOWN"),
            "findings": len(vivi_supervisor.get("findings", [])),
        })
        vivi_worker_queue = build_vivi_worker_queue(write=True)
        steps.append({
            "name": "vivi_worker_queue",
            "status": "PASS" if vivi_worker_queue.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if vivi_worker_queue.get("status") in {"PASS", "WARN"} else 1,
            "queue_status": vivi_worker_queue.get("status", "UNKNOWN"),
            "worker_cards": vivi_worker_queue.get("worker_card_count", 0),
            "ready": vivi_worker_queue.get("ready_count", 0),
        })
        vivi_worker = run_vivi_worker_mvp(write=True)
        steps.append({
            "name": "vivi_worker_mvp",
            "status": "PASS" if vivi_worker.get("status") in {"completed_verified", "closed_no_action", "waiting_for_operator", "failed_safe"} and not vivi_worker.get("runtime_action_executed") else "FAIL",
            "returncode": 0 if vivi_worker.get("status") in {"completed_verified", "closed_no_action", "waiting_for_operator", "failed_safe"} and not vivi_worker.get("runtime_action_executed") else 1,
            "worker_status": vivi_worker.get("status", "UNKNOWN"),
            "worker_card_id": vivi_worker.get("worker_card_id", ""),
            "runtime_action_executed": vivi_worker.get("runtime_action_executed", None),
        })
        vivi_worker_supervisor = build_vivi_worker_supervisor_audit(write=True)
        steps.append({
            "name": "vivi_worker_supervisor_audit",
            "status": "PASS" if vivi_worker_supervisor.get("status") in {"PASS", "WARN"} else "FAIL",
            "returncode": 0 if vivi_worker_supervisor.get("status") in {"PASS", "WARN"} else 1,
            "audit_status": vivi_worker_supervisor.get("status", "UNKNOWN"),
            "truth_status": vivi_worker_supervisor.get("truth_status", "UNKNOWN"),
            "findings": len(vivi_worker_supervisor.get("findings", [])),
        })
        openjarvis_lab = load_openjarvis_capability_lab()
        openjarvis_pass = (
            openjarvis_lab.get("status") == "PASS"
            and openjarvis_lab.get("source_of_truth") is False
            and openjarvis_lab.get("runtime", {}).get("runtime_execution_attempted") is False
            and openjarvis_lab.get("hardening", {}).get("runtime_action_executed") is False
        )
        steps.append({
            "name": "openjarvis_capability_lab",
            "status": "PASS" if openjarvis_pass else "FAIL",
            "returncode": 0 if openjarvis_pass else 1,
            "lab_status": openjarvis_lab.get("status", "UNKNOWN"),
            "retrieval_status": openjarvis_lab.get("retrieval_benchmark", {}).get("status", "UNKNOWN"),
            "retrieval_pass_count": openjarvis_lab.get("retrieval_benchmark", {}).get("pass_count", 0),
            "retrieval_question_count": openjarvis_lab.get("retrieval_benchmark", {}).get("question_count", 0),
            "runtime_action_executed": openjarvis_lab.get("hardening", {}).get("runtime_action_executed", None),
        })
        openjarvis_arena = load_openjarvis_capability_arena()
        openjarvis_arena_pass = (
            openjarvis_arena.get("status") == "PASS"
            and openjarvis_arena.get("source_of_truth") is False
            and openjarvis_arena.get("runtime", {}).get("runtime_execution_attempted") is False
            and openjarvis_arena.get("runtime", {}).get("runtime_action_executed") is False
            and openjarvis_arena.get("engine_summary", {}).get("openjarvis_shadow", {}).get("fail_count", 1) == 0
        )
        steps.append({
            "name": "openjarvis_capability_arena",
            "status": "PASS" if openjarvis_arena_pass else "FAIL",
            "returncode": 0 if openjarvis_arena_pass else 1,
            "arena_status": openjarvis_arena.get("status", "UNKNOWN"),
            "task_count": openjarvis_arena.get("evaluated_task_count", 0),
            "shadow_pass_count": openjarvis_arena.get("engine_summary", {}).get("openjarvis_shadow", {}).get("pass_count", 0),
            "shadow_fail_count": openjarvis_arena.get("engine_summary", {}).get("openjarvis_shadow", {}).get("fail_count", 0),
            "shadow_win_count": openjarvis_arena.get("winner_summary", {}).get("openjarvis_shadow", 0),
            "baseline_win_count": openjarvis_arena.get("winner_summary", {}).get("pig_obsidian_baseline", 0),
            "runtime_action_executed": openjarvis_arena.get("runtime", {}).get("runtime_action_executed", None),
        })
    if all(step["status"] == "PASS" for step in steps):
        operator_brief = build_operator_brief()
        steps.append({
            "name": "operator_brief",
            "status": "PASS" if operator_brief.get("overall_status") in {"CLEAR", "REVIEW", "ACTION_REQUIRED"} else "FAIL",
            "returncode": 0,
            "overall_status": operator_brief.get("overall_status"),
        })
        contracts = validate_fix_contracts()
        steps.append({
            "name": "hardening_fix_contracts",
            "status": "PASS" if contracts.get("status") in {"PASS", "EMPTY"} else "FAIL",
            "returncode": 0 if contracts.get("status") in {"PASS", "EMPTY"} else 1,
            "contracts_checked": contracts.get("contracts_checked", 0),
        })
        quality_os = validate_quality_os()
        surface = build_quality_os_operator_surface(write=True)
        steps.append({
            "name": "quality_os_contracts",
            "status": "PASS" if quality_os.get("status") == "PASS" and surface.get("status") == "PASS" else "FAIL",
            "returncode": 0 if quality_os.get("status") == "PASS" and surface.get("status") == "PASS" else 1,
            "contracts_checked": quality_os.get("reports_checked", 0),
            "surface_status": surface.get("status"),
        })
    summary = load_json(OUTPUT_DIR / "summary.json", default={})
    report = {
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": "PASS" if all(step["status"] == "PASS" for step in steps) else "FAIL",
        "steps": steps,
        "summary": summary,
        "decision_inbox": apply_decision_state(load_json(OPERATOR_DECISION_PATH, default={"items": []})),
        "operator_brief": load_json(OPERATOR_BRIEF_PATH, default={}),
        "hardening_fix_contracts": load_json(OUTPUT_DIR / "hardening_fix_contract_validation.json", default={}),
        "long_run_completion": load_json(LONG_RUN_COMPLETION_AUDIT_PATH, default={}),
        "vault_umlaut_hygiene": load_json(VAULT_UMLAUT_HYGIENE_PATH, default={}),
        "skill_policy_regression_guard": load_json(SKILL_POLICY_REGRESSION_AUDIT_PATH, default={}),
        "rule_propagation": load_json(RULE_PROPAGATION_AUDIT_PATH, default={}),
        "project_invariants": load_json(PROJECT_INVARIANT_AUDIT_PATH, default={}),
        "agent_entrypoints": load_json(AGENT_ENTRYPOINT_AUDIT_PATH, default={}),
        "operator_intent_contract": load_json(OPERATOR_INTENT_CONTRACT_AUDIT_PATH, default={}),
        "autonomy_execution_queue": load_json(AUTONOMY_EXECUTION_QUEUE_PATH, default={}),
        "autonomy_dirt_backlog_scan": load_json(AUTONOMY_DIRT_BACKLOG_SCAN_PATH, default={}),
        "commit_cleanup_go_package": load_json(COMMIT_CLEANUP_GO_PACKAGE_PATH, default={}),
        "vivi_vega_handoff_inbox": load_json(VIVI_VEGA_HANDOFF_INBOX_PATH, default={}),
        "impact_radius": load_json(IMPACT_RADIUS_ASSESSMENT_PATH, default={}),
        "german_output_quality": load_json(GERMAN_OUTPUT_QUALITY_AUDIT_PATH, default={}),
        "autonomy_governor": load_json(AUTONOMY_GOVERNOR_AUDIT_PATH, default={}),
        "endgame_roadmap": load_json(ENDGAME_ROADMAP_PATH, default={}),
        "autonomy_soak_audit": load_json(AUTONOMY_SOAK_AUDIT_PATH, default={}),
        "vivi_capability_matrix": load_json(VIVI_CAPABILITY_MATRIX_PATH, default={}),
        "project_vertical_rollout": load_json(PROJECT_VERTICAL_ROLLOUT_PATH, default={}),
        "launch_readiness_package": load_json(LAUNCH_READINESS_PATH, default={}),
        "fresh_session_readiness": load_json(FRESH_SESSION_READINESS_AUDIT_PATH, default={}),
        "vivi_supervisor_audit": load_json(VIVI_SUPERVISOR_AUDIT_PATH, default={}),
        "vivi_worker_queue": load_json(VIVI_WORKER_QUEUE_PATH, default={}),
        "vivi_worker_last_run": load_json(VIVI_WORKER_LAST_RUN_PATH, default={}),
        "vivi_worker_supervisor_audit": load_json(VIVI_WORKER_SUPERVISOR_AUDIT_PATH, default={}),
        "openjarvis_capability_lab": load_openjarvis_capability_lab(),
    }
    write_json(OUTPUT_DIR / "full_check_report.json", report)
    lines = ["# Project Intelligence Graph Full Check", "", f"- Status: `{report['status']}`", ""]
    for step in steps:
        lines.append(f"- `{step['status']}` {step['name']}")
    lines.extend([
        "",
        "## Control Status",
        "",
        f"- Implementation: `{summary.get('implementation_status', 'UNKNOWN')}`",
        f"- Coverage: `{summary.get('coverage_status', 'UNKNOWN')}`",
        f"- Operator risk: `{summary.get('operator_risk_status', 'UNKNOWN')}`",
        f"- Policy gate: `{summary.get('policy_gate_status', 'UNKNOWN')}`",
        f"- Decisions: `{report['decision_inbox'].get('status', 'UNKNOWN')}`",
        f"- Long-run completion: `{report['long_run_completion'].get('status', 'UNKNOWN')}`",
        f"- Vault umlaut hygiene: `{report['vault_umlaut_hygiene'].get('status', 'UNKNOWN')}` ({report['vault_umlaut_hygiene'].get('finding_count', 0)})",
        f"- Skill policy regression guard: `{report['skill_policy_regression_guard'].get('status', 'UNKNOWN')}`",
        f"- Rule propagation: `{report['rule_propagation'].get('status', 'UNKNOWN')}` ({report['rule_propagation'].get('rules_checked', 0)} rules)",
        f"- Project invariants: `{report['project_invariants'].get('status', 'UNKNOWN')}` ({report['project_invariants'].get('projects_checked', 0)} projects)",
        f"- Agent entrypoints: `{report['agent_entrypoints'].get('status', 'UNKNOWN')}` ({report['agent_entrypoints'].get('entrypoints_checked', 0)} entrypoints)",
        f"- Operator intent contract: `{report['operator_intent_contract'].get('status', 'UNKNOWN')}`",
        f"- Autonomy execution queue: `{report['autonomy_execution_queue'].get('status', 'UNKNOWN')}` ({report['autonomy_execution_queue'].get('current_block', '')})",
        f"- Autonomy dirt/backlog scan: `{report['autonomy_dirt_backlog_scan'].get('status', 'UNKNOWN')}` ({report['autonomy_dirt_backlog_scan'].get('dirty_project_count', 0)} dirty projects)",
        f"- Commit/Cleanup Operator-Go package: `{report['commit_cleanup_go_package'].get('status', 'UNKNOWN')}` ({report['commit_cleanup_go_package'].get('summary', {}).get('decision_card_count', 0)} decision cards)",
        f"- Vivi -> Vega handoff inbox: `{report['vivi_vega_handoff_inbox'].get('status', 'UNKNOWN')}` ({report['vivi_vega_handoff_inbox'].get('action_item_count', 0)} action items)",
        f"- Impact radius: `{report['impact_radius'].get('status', 'UNKNOWN')}` ({len(report['impact_radius'].get('matches', []))} matches)",
        f"- German output quality: `{report['german_output_quality'].get('status', 'UNKNOWN')}` ({report['german_output_quality'].get('finding_count', 0)} findings)",
        f"- Autonomy governor: `{report['autonomy_governor'].get('status', 'UNKNOWN')}` ({report['autonomy_governor'].get('autonomy_state', 'UNKNOWN')})",
        f"- Endgame roadmap: `{report['endgame_roadmap'].get('status', 'UNKNOWN')}` ({report['endgame_roadmap'].get('completion_percent', 0)}%, current: {report['endgame_roadmap'].get('current_phase', '')})",
        f"- Autonomy soak audit: `{report['autonomy_soak_audit'].get('status', 'UNKNOWN')}` ({report['autonomy_soak_audit'].get('loop_count', 0)} loops)",
        f"- Vivi capability matrix: `{report['vivi_capability_matrix'].get('status', 'UNKNOWN')}` ({report['vivi_capability_matrix'].get('ready_claim_type_count', 0)} ready, {report['vivi_capability_matrix'].get('verified_claim_type_count', 0)} verified)",
        f"- Project vertical rollout: `{report['project_vertical_rollout'].get('status', 'UNKNOWN')}` ({report['project_vertical_rollout'].get('project_count', 0)} projects, {report['project_vertical_rollout'].get('missing_verifier_count', 0)} missing verifiers)",
        f"- Launch readiness package: `{report['launch_readiness_package'].get('status', 'UNKNOWN')}` ({report['launch_readiness_package'].get('package_count', 0)} packages, {report['launch_readiness_package'].get('operator_gate_count', 0)} gates)",
        f"- Fresh session readiness: `{report['fresh_session_readiness'].get('status', 'UNKNOWN')}` ({report['fresh_session_readiness'].get('warning_count', 0)} warnings)",
        f"- Vivi supervisor audit: `{report['vivi_supervisor_audit'].get('status', 'UNKNOWN')}` ({report['vivi_supervisor_audit'].get('truth_status', 'UNKNOWN')})",
        f"- Vivi worker queue: `{report['vivi_worker_queue'].get('status', 'UNKNOWN')}` ({report['vivi_worker_queue'].get('ready_count', 0)} ready)",
        f"- Vivi worker MVP: `{report['vivi_worker_last_run'].get('status', 'UNKNOWN')}` (runtime action executed: `{report['vivi_worker_last_run'].get('runtime_action_executed', None)}`)",
        f"- Vivi worker supervisor: `{report['vivi_worker_supervisor_audit'].get('status', 'UNKNOWN')}` ({report['vivi_worker_supervisor_audit'].get('truth_status', 'UNKNOWN')})",
        f"- OpenJarvis capability lab: `{report['openjarvis_capability_lab'].get('status', 'UNKNOWN')}` ({report['openjarvis_capability_lab'].get('retrieval_benchmark', {}).get('pass_count', 0)}/{report['openjarvis_capability_lab'].get('retrieval_benchmark', {}).get('question_count', 0)} retrieval checks)",
    ])
    (OUTPUT_DIR / "full_check_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Query and render Project Intelligence Graph artifacts.")
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ["global", "local", "hybrid"]:
        cmd = sub.add_parser(name)
        cmd.add_argument("query")
        cmd.add_argument("--depth", type=int, default=1)
        cmd.add_argument("--limit", type=int, default=20)
        cmd.add_argument("--json", action="store_true")
    explain_cmd = sub.add_parser("explain")
    explain_cmd.add_argument("query")
    explain_cmd.add_argument("--json", action="store_true")
    context_cmd = sub.add_parser("context-pack")
    context_cmd.add_argument("query")
    context_cmd.add_argument("--output", type=Path, default=None)
    sub.add_parser("drift")
    risk_cmd = sub.add_parser("risk")
    risk_cmd.add_argument("--json", action="store_true")
    decision_cmd = sub.add_parser("decisions")
    decision_cmd.add_argument("--json", action="store_true")
    decision_cmd.add_argument("--set", dest="decision_item_id")
    decision_cmd.add_argument("--state", choices=["open", "accepted", "snoozed", "delegated", "closed"])
    decision_cmd.add_argument("--note", default="")
    coverage_cmd = sub.add_parser("coverage")
    coverage_cmd.add_argument("--json", action="store_true")
    policy_cmd = sub.add_parser("policy")
    policy_cmd.add_argument("--json", action="store_true")
    planning_quality_cmd = sub.add_parser("planning-quality")
    planning_quality_cmd.add_argument("--json", action="store_true")
    materialize_quality_os_cmd = sub.add_parser("materialize-quality-os")
    materialize_quality_os_cmd.add_argument("--label", default="quality-os-v2-operational-layer")
    materialize_quality_os_cmd.add_argument("--json", action="store_true")
    validate_quality_os_cmd = sub.add_parser("validate-quality-os")
    validate_quality_os_cmd.add_argument("--json", action="store_true")
    operator_surface_cmd = sub.add_parser("operator-surface")
    operator_surface_cmd.add_argument("--json", action="store_true")
    render_cmd = sub.add_parser("render-views")
    render_cmd.add_argument("--json", action="store_true")
    selftest_cmd = sub.add_parser("selftest")
    selftest_cmd.add_argument("--json", action="store_true")
    full_check_cmd = sub.add_parser("full-check")
    full_check_cmd.add_argument("--json", action="store_true")
    operator_brief_cmd = sub.add_parser("operator-brief")
    operator_brief_cmd.add_argument("--json", action="store_true")
    long_run_audit_cmd = sub.add_parser("long-run-audit")
    long_run_audit_cmd.add_argument("--json", action="store_true")
    vault_hygiene_cmd = sub.add_parser("vault-hygiene")
    vault_hygiene_cmd.add_argument("--json", action="store_true")
    skill_policy_audit_cmd = sub.add_parser("skill-policy-audit")
    skill_policy_audit_cmd.add_argument("--json", action="store_true")
    rule_propagation_cmd = sub.add_parser("rule-propagation")
    rule_propagation_cmd.add_argument("--json", action="store_true")
    project_invariants_cmd = sub.add_parser("project-invariants")
    project_invariants_cmd.add_argument("--json", action="store_true")
    agent_entrypoints_cmd = sub.add_parser("agent-entrypoints")
    agent_entrypoints_cmd.add_argument("--json", action="store_true")
    operator_intent_cmd = sub.add_parser("operator-intent")
    operator_intent_cmd.add_argument("--signal", default="")
    operator_intent_cmd.add_argument("--intent-id", default=None)
    operator_intent_cmd.add_argument("--set-status", choices=["draft", "ready_to_build", "needs_target_picture", "needs_operator_gate", "blocked_by_missing_evidence", "completed_verified", "closed_no_action"], default=None)
    operator_intent_cmd.add_argument("--note", default="")
    operator_intent_cmd.add_argument("--json", action="store_true")
    impact_radius_cmd = sub.add_parser("impact-radius")
    impact_radius_cmd.add_argument("--text", default="")
    impact_radius_cmd.add_argument("--json", action="store_true")
    german_output_cmd = sub.add_parser("german-output-quality")
    german_output_cmd.add_argument("--json", action="store_true")
    autonomy_governor_cmd = sub.add_parser("autonomy-governor")
    autonomy_governor_cmd.add_argument("--json", action="store_true")
    endgame_cmd = sub.add_parser("endgame-roadmap")
    endgame_cmd.add_argument("--json", action="store_true")
    autonomy_soak_cmd = sub.add_parser("autonomy-soak")
    autonomy_soak_cmd.add_argument("--loops", type=int, default=3)
    autonomy_soak_cmd.add_argument("--json", action="store_true")
    vivi_capabilities_cmd = sub.add_parser("vivi-capabilities")
    vivi_capabilities_cmd.add_argument("--json", action="store_true")
    project_verticals_cmd = sub.add_parser("project-verticals")
    project_verticals_cmd.add_argument("--json", action="store_true")
    launch_readiness_cmd = sub.add_parser("launch-readiness")
    launch_readiness_cmd.add_argument("--json", action="store_true")
    openjarvis_cmd = sub.add_parser("openjarvis-capability-lab")
    openjarvis_cmd.add_argument("--json", action="store_true")
    openjarvis_arena_cmd = sub.add_parser("openjarvis-capability-arena")
    openjarvis_arena_cmd.add_argument("--json", action="store_true")
    autonomy_queue_cmd = sub.add_parser("autonomy-queue")
    autonomy_queue_cmd.add_argument("--set-block", default="")
    autonomy_queue_cmd.add_argument("--set-status", choices=["pending", "ready", "in_progress", "blocked_operator_gate", "completed_verified", "closed_no_action"], default=None)
    autonomy_queue_cmd.add_argument("--note", default="")
    autonomy_queue_cmd.add_argument("--json", action="store_true")
    autonomy_dirt_cmd = sub.add_parser("autonomy-dirt-scan")
    autonomy_dirt_cmd.add_argument("--run-verifiers", action="store_true")
    autonomy_dirt_cmd.add_argument("--set-queue", default="")
    autonomy_dirt_cmd.add_argument(
        "--state",
        choices=["open", "in_review", "reviewed_local", "closed", "operator_gated"],
        default=None,
    )
    autonomy_dirt_cmd.add_argument("--note", default="")
    autonomy_dirt_cmd.add_argument("--verifier", default="")
    autonomy_dirt_cmd.add_argument("--json", action="store_true")
    commit_cleanup_cmd = sub.add_parser("commit-cleanup-package")
    commit_cleanup_cmd.add_argument("--json", action="store_true")
    vivi_handoff_cmd = sub.add_parser("vivi-handoff-inbox")
    vivi_handoff_cmd.add_argument("--set-item", default="")
    vivi_handoff_cmd.add_argument(
        "--state",
        choices=["open", "in_review", "verified", "closed", "recorded_history", "operator_gated"],
        default=None,
    )
    vivi_handoff_cmd.add_argument("--note", default="")
    vivi_handoff_cmd.add_argument("--verifier", default="")
    vivi_handoff_cmd.add_argument("--json", action="store_true")
    fresh_session_cmd = sub.add_parser("fresh-session-readiness")
    fresh_session_cmd.add_argument("--json", action="store_true")
    fresh_data_cmd = sub.add_parser("fresh-data")
    fresh_data_cmd.add_argument("--json", action="store_true")
    vivi_job_cards_cmd = sub.add_parser("vivi-job-cards")
    vivi_job_cards_cmd.add_argument("--json", action="store_true")
    vivi_runner_cmd = sub.add_parser("vivi-runner")
    vivi_runner_cmd.add_argument("--json", action="store_true")
    vivi_supervisor_cmd = sub.add_parser("vivi-supervisor")
    vivi_supervisor_cmd.add_argument("--json", action="store_true")
    vivi_worker_queue_cmd = sub.add_parser("vivi-worker-queue")
    vivi_worker_queue_cmd.add_argument("--json", action="store_true")
    vivi_worker_cmd = sub.add_parser("vivi-worker")
    vivi_worker_cmd.add_argument("--json", action="store_true")
    vivi_worker_supervisor_cmd = sub.add_parser("vivi-worker-supervisor")
    vivi_worker_supervisor_cmd.add_argument("--json", action="store_true")
    new_fix_cmd = sub.add_parser("new-fix")
    new_fix_cmd.add_argument("title")
    new_fix_cmd.add_argument("--objective", required=True)
    new_fix_cmd.add_argument("--risk-class", choices=["R1", "R2", "R3", "R4", "R5"], default="R2")
    new_fix_cmd.add_argument("--allowed", action="append")
    new_fix_cmd.add_argument("--forbidden", action="append")
    new_fix_cmd.add_argument("--command", dest="required_command", action="append")
    new_fix_cmd.add_argument("--json", action="store_true")
    validate_fix_cmd = sub.add_parser("validate-fix")
    validate_fix_cmd.add_argument("--path", type=Path, default=None)
    validate_fix_cmd.add_argument("--json", action="store_true")
    quality_baseline_cmd = sub.add_parser("quality-baseline")
    quality_baseline_cmd.add_argument("--label", default="baseline")
    quality_baseline_cmd.add_argument("--json", action="store_true")
    quality_gate_cmd = sub.add_parser("quality-gate")
    quality_gate_cmd.add_argument("--baseline", type=Path, default=QUALITY_BASELINE_PATH)
    quality_gate_cmd.add_argument("--improvement", default="")
    quality_gate_cmd.add_argument("--allow-known-warnings", action="store_true")
    quality_gate_cmd.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.command == "full-check":
        result = run_full_check()
        print_result(result if args.json else f"{result['status']} {len(result['steps'])} steps; report={OUTPUT_DIR / 'full_check_report.md'}", args.json)
        return 0 if result["status"] == "PASS" else 1
    if args.command == "operator-brief":
        result = build_operator_brief()
        print_result(result if args.json else operator_brief_to_markdown(result), args.json)
        return 0
    if args.command == "long-run-audit":
        result = load_json(LONG_RUN_COMPLETION_AUDIT_PATH, default={})
        print_result(result if args.json else long_run_completion_audit_to_markdown(result), args.json)
        return 0 if result.get("status") == "PASS" else 1
    if args.command == "vault-hygiene":
        result = load_json(VAULT_UMLAUT_HYGIENE_PATH, default={})
        print_result(result if args.json else json_records_to_markdown("Vault Umlaut Hygiene", result.get("items", [])), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "skill-policy-audit":
        result = load_json(SKILL_POLICY_REGRESSION_AUDIT_PATH, default={})
        print_result(result if args.json else json_records_to_markdown("Skill Policy Regression Guard Audit", result.get("items", [])), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "rule-propagation":
        result = load_json(RULE_PROPAGATION_AUDIT_PATH, default={})
        print_result(result if args.json else json_records_to_markdown("Rule Propagation Audit", result.get("items", [])), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "project-invariants":
        result = load_json(PROJECT_INVARIANT_AUDIT_PATH, default={})
        print_result(result if args.json else json_records_to_markdown("Project Invariant Audit", result.get("items", [])), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "agent-entrypoints":
        result = load_json(AGENT_ENTRYPOINT_AUDIT_PATH, default={})
        print_result(result if args.json else json_records_to_markdown("Agent Entry Point Audit", result.get("items", [])), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "operator-intent":
        if args.set_status:
            result = update_operator_intent_contract_status(args.intent_id, args.set_status, args.note)
            print_result(result, args.json)
            return 0
        if args.signal:
            result = materialize_operator_intent_contract(args.signal, args.intent_id)
            print_result(result if args.json else operator_intent_contract_to_markdown(result), args.json)
            return 0
        result = load_json(OPERATOR_INTENT_CONTRACT_AUDIT_PATH, default={})
        print_result(result if args.json else json_records_to_markdown("Operator Intent Contract Audit", result.get("items", [])), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "impact-radius":
        result = build_impact_radius_assessment(args.text, write=True)
        print_result(result if args.json else json_records_to_markdown("Impact Radius Assessment", result.get("matches", [])), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "german-output-quality":
        result = build_german_output_quality_audit(write=True)
        print_result(result if args.json else json_records_to_markdown("German Output Quality Gate", result.get("items", [])), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "autonomy-governor":
        result = build_autonomy_governor_audit(write=True)
        print_result(result if args.json else json_records_to_markdown("Autonomy Governor Audit", result.get("items", [])), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "endgame-roadmap":
        result = build_endgame_roadmap(write=True)
        print_result(result if args.json else endgame_roadmap_to_markdown(result), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "autonomy-soak":
        result = run_autonomy_soak(loops=args.loops, write=True)
        print_result(result if args.json else autonomy_soak_to_markdown(result), args.json)
        return 0 if result.get("status") == "PASS" else 1
    if args.command == "vivi-capabilities":
        result = build_vivi_capability_matrix(write=True)
        print_result(result if args.json else vivi_capability_matrix_to_markdown(result), args.json)
        return 0 if result.get("status") == "PASS" else 1
    if args.command == "project-verticals":
        result = build_project_vertical_rollout(write=True)
        print_result(result if args.json else project_vertical_rollout_to_markdown(result), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "launch-readiness":
        result = build_launch_readiness_package(write=True)
        print_result(result if args.json else launch_readiness_to_markdown(result), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "openjarvis-capability-lab":
        result = load_openjarvis_capability_lab()
        print_result(
            result if args.json else json_records_to_markdown("OpenJarvis Capability Lab", [{"name": "openjarvis", **result}]),
            args.json,
        )
        return 0 if (
            result.get("status") in {"PASS", "WARN"}
            and result.get("source_of_truth") is False
            and result.get("runtime", {}).get("runtime_execution_attempted") is False
            and result.get("hardening", {}).get("runtime_action_executed") is False
        ) else 1
    if args.command == "openjarvis-capability-arena":
        result = load_openjarvis_capability_arena()
        print_result(
            result if args.json else json_records_to_markdown("OpenJarvis Capability Arena", [{"name": "openjarvis_arena", **result}]),
            args.json,
        )
        return 0 if (
            result.get("status") in {"PASS", "WARN"}
            and result.get("source_of_truth") is False
            and result.get("runtime", {}).get("runtime_execution_attempted") is False
            and result.get("runtime", {}).get("runtime_action_executed") is False
            and result.get("engine_summary", {}).get("openjarvis_shadow", {}).get("fail_count", 1) == 0
        ) else 1
    if args.command == "autonomy-queue":
        if args.set_block or args.set_status:
            if not args.set_block or not args.set_status:
                raise ValueError("autonomy-queue status update requires --set-block and --set-status")
            result = update_autonomy_queue_block(args.set_block, args.set_status, args.note)
            print_result(result, args.json)
            return 0
        result = build_autonomy_execution_queue(write=True)
        print_result(result if args.json else json_records_to_markdown("Autonomy Execution Queue", result.get("blocks", [])), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "autonomy-dirt-scan":
        if args.set_queue or args.state:
            if not args.set_queue or not args.state:
                raise ValueError("autonomy-dirt-scan state update requires --set-queue and --state")
            updated = update_dirt_decision_state(args.set_queue, args.state, args.note, args.verifier)
            result = build_autonomy_dirt_backlog_scan(write=True, run_verifiers=args.run_verifiers)
            print_result({"updated": updated, "scan": result} if args.json else updated, args.json)
            return 0
        result = build_autonomy_dirt_backlog_scan(write=True, run_verifiers=args.run_verifiers)
        print_result(result if args.json else autonomy_dirt_backlog_scan_to_markdown(result), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "commit-cleanup-package":
        result = build_commit_cleanup_go_package(write=True)
        print_result(result if args.json else commit_cleanup_go_package_to_markdown(result), args.json)
        return 0 if result.get("status") in {"operator_go_required", "needs_local_review", "blocked_by_missing_evidence", "closed_no_action"} and not result.get("runtime_action_executed") else 1
    if args.command == "vivi-handoff-inbox":
        if args.set_item or args.state:
            if not args.set_item or not args.state:
                raise ValueError("vivi-handoff-inbox state update requires --set-item and --state")
            updated = update_vivi_handoff_state(args.set_item, args.state, args.note, args.verifier)
            result = build_vivi_vega_handoff_inbox(write=True)
            print_result({"updated": updated, "inbox": result} if args.json else updated, args.json)
            return 0
        result = build_vivi_vega_handoff_inbox(write=True)
        print_result(result if args.json else vivi_vega_handoff_inbox_to_markdown(result), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "fresh-session-readiness":
        result = build_fresh_session_readiness_audit(write=True)
        print_result(result if args.json else json_records_to_markdown("Fresh Session Readiness Audit", result.get("items", [])), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "fresh-data":
        result = build_fresh_data_intake(write=True)
        print_result(result if args.json else fresh_data_intake_to_markdown(result), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "vivi-job-cards":
        result = build_vivi_job_card_queue(write=True)
        print_result(result if args.json else vivi_job_card_queue_to_markdown(result), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "vivi-runner":
        result = run_vivi_runner_mvp(write=True)
        print_result(result if args.json else vivi_runner_to_markdown(result), args.json)
        return 0 if result.get("status") in {"completed_verified", "closed_no_action", "waiting_for_operator", "waiting_for_evidence"} and not result.get("runtime_action_executed") else 1
    if args.command == "vivi-supervisor":
        result = build_vivi_supervisor_audit(write=True)
        print_result(result if args.json else vivi_supervisor_audit_to_markdown(result), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "vivi-worker-queue":
        result = build_vivi_worker_queue(write=True)
        print_result(result if args.json else vivi_worker_queue_to_markdown(result), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "vivi-worker":
        result = run_vivi_worker_mvp(write=True)
        print_result(result if args.json else vivi_worker_to_markdown(result), args.json)
        return 0 if result.get("status") in {"completed_verified", "closed_no_action", "waiting_for_operator", "failed_safe"} and not result.get("runtime_action_executed") else 1
    if args.command == "vivi-worker-supervisor":
        result = build_vivi_worker_supervisor_audit(write=True)
        print_result(result if args.json else vivi_worker_supervisor_to_markdown(result), args.json)
        return 0 if result.get("status") in {"PASS", "WARN"} else 1
    if args.command == "new-fix":
        result = create_fix_contract(args)
        print_result(result if args.json else f"{result['json_path']}\n{result['md_path']}", args.json)
        return 0
    if args.command == "validate-fix":
        result = validate_fix_contracts(args.path)
        print_result(result if args.json else json_records_to_markdown("Hardening Fix Contract Validation", result.get("reports", [])), args.json)
        return 0 if result["status"] in {"PASS", "EMPTY"} else 1
    if args.command == "quality-baseline":
        result = create_quality_baseline(args.label)
        print_result(result if args.json else quality_snapshot_to_markdown("Quality Baseline", result), args.json)
        return 0 if result["status"] == "PASS" else 1
    if args.command == "quality-gate":
        result = run_quality_gate(args.baseline, args.improvement, args.allow_known_warnings)
        print_result(result if args.json else quality_gate_to_markdown(result), args.json)
        return 0 if result["status"] == "PASS" else 1
    if args.command == "materialize-quality-os":
        result = create_quality_os_artifacts(args.label)
        print_result(result if args.json else "\n".join(f"{key}: {value}" for key, value in result.items()), args.json)
        return 0 if result["status"] == "PASS" else 1
    if args.command == "validate-quality-os":
        result = validate_quality_os()
        print_result(result if args.json else json_records_to_markdown("Quality OS Contract Validation", result.get("reports", [])), args.json)
        return 0 if result["status"] == "PASS" else 1
    if args.command == "operator-surface":
        result = build_quality_os_operator_surface(write=True)
        print_result(result if args.json else json_records_to_markdown("Quality OS Operator Surface", [{"name": "surface", **result}]), args.json)
        return 0 if result["status"] == "PASS" else 1

    store = GraphStore.load()
    if args.command == "global":
        result = store.global_search(args.query, limit=args.limit)
        print_result(result if args.json else result_to_markdown(store, result), args.json)
    elif args.command == "local":
        result = store.local_search(args.query, depth=args.depth, limit=args.limit)
        print_result(result if args.json else result_to_markdown(store, result), args.json)
    elif args.command == "hybrid":
        result = store.hybrid_search(args.query, depth=args.depth, limit=args.limit)
        print_result(result if args.json else result_to_markdown(store, result), args.json)
    elif args.command == "explain":
        result = store.explain(args.query)
        print_result(result if args.json else explain_to_markdown(store, result), args.json)
    elif args.command == "context-pack":
        output = args.output or OUTPUT_DIR / "context_packs" / f"{safe_slug(args.query)}.md"
        write_context_pack(store, args.query, output)
        print(str(output))
    elif args.command == "drift":
        print(DRIFT_REPORT_PATH.read_text(encoding="utf-8"))
    elif args.command == "risk":
        payload = load_json(AUTOMATION_RISK_PATH, default={})
        print_result(payload if args.json else json_records_to_markdown("Automation Risk Registry", payload.get("items", [])), args.json)
    elif args.command == "decisions":
        if args.decision_item_id:
            if not args.state:
                raise SystemExit("--state is required when --set is used")
            updated = update_decision_state(args.decision_item_id, args.state, args.note)
            print_result({"item_id": args.decision_item_id, **updated}, args.json)
            return 0
        payload = apply_decision_state(load_json(OPERATOR_DECISION_PATH, default={}))
        print_result(payload if args.json else json_records_to_markdown("Operator Decision Inbox", payload.get("items", [])), args.json)
    elif args.command == "coverage":
        payload = load_json(COVERAGE_MANIFEST_PATH, default={})
        print_result(payload if args.json else json_records_to_markdown("Project Intelligence Graph Coverage", payload.get("sources", [])), args.json)
    elif args.command == "policy":
        payload = load_json(POLICY_GATE_PATH, default={})
        print_result(payload if args.json else json_records_to_markdown("Policy & Gate Report", payload.get("items", [])), args.json)
    elif args.command == "planning-quality":
        payload = load_json(CONTRACT_QUALITY_PATH, default={})
        print_result(payload if args.json else json_records_to_markdown("PIG Roadmap / Contract Quality Gate", payload.get("items", [])), args.json)
    elif args.command == "render-views":
        written = render_views(store)
        print_result(written if args.json else "\n".join(written.values()), args.json)
    elif args.command == "selftest":
        result = run_selftest(store)
        print_result(result if args.json else f"{result['status']} {len(result['checks'])} checks", args.json)
        return 0 if result["status"] == "PASS" else 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
