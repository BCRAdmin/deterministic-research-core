import fs from 'node:fs';
import path from 'node:path';

const lioncomRoot = process.cwd();
const pigSurfacePath = process.env.PIG_QUALITY_OS_SURFACE_PATH
  || '/Users/BjornRosinger/Documents/New project/outputs/project_intelligence_graph/quality_os_operator_surface.json';
const componentPath = path.join(lioncomRoot, 'components/portfolio-control-tower-page.tsx');
const appShellPath = path.join(lioncomRoot, 'components/app-shell.tsx');
const liveDataPath = path.join(lioncomRoot, 'lib/control-plane-v2/live-data.ts');
const typesPath = path.join(lioncomRoot, 'lib/types.ts');

const checks = [];

function add(name, pass, detail) {
  checks.push({ name, pass, detail });
}

function read(filePath) {
  return fs.readFileSync(filePath, 'utf8');
}

function readJson(filePath) {
  return JSON.parse(read(filePath));
}

const surface = fs.existsSync(pigSurfacePath) ? readJson(pigSurfacePath) : null;
const component = read(componentPath);
const appShell = read(appShellPath);
const liveData = read(liveDataPath);
const types = read(typesPath);

add('PIG Planning Quality Surface existiert', Boolean(surface), pigSurfacePath);
add('Surface hat PASS/WARN/FAIL Status', ['PASS', 'WARN', 'FAIL'].includes(surface?.status), surface?.status || 'missing');
add('Surface listet Workflow Runs', Array.isArray(surface?.workflow_runs) && surface.workflow_runs.length > 0, String(surface?.workflow_runs?.length || 0));
add('Surface listet Approval Nodes', Array.isArray(surface?.approval_nodes) && surface.approval_nodes.length > 0, String(surface?.approval_nodes?.length || 0));
add('Surface nennt naechsten sicheren Schritt', Boolean(surface?.next_safe_step), surface?.next_safe_step || 'missing');
add('Surface enthaelt Contract-Quality PASS', surface?.contract_quality?.status === 'PASS', surface?.contract_quality?.status || 'missing');
add('Surface ist V3 control-ready', surface?.surface_version === 'v3', surface?.surface_version || 'missing');
add('Surface listet Operator Actions', Array.isArray(surface?.operator_actions) && surface.operator_actions.length > 0, String(surface?.operator_actions?.length || 0));
add('Surface listet Pause/Resume/Retry Controls', Array.isArray(surface?.run_controls) && surface.run_controls.length >= 3, String(surface?.run_controls?.length || 0));
add('Surface enthaelt Fresh-Session-Handoff', Boolean(surface?.fresh_session_handoff?.path) && surface.fresh_session_handoff.status !== 'missing', surface?.fresh_session_handoff?.status || 'missing');
add('Surface blockt n8n Runtime', surface?.control_capabilities?.n8n_runtime === false, JSON.stringify(surface?.control_capabilities || {}));
add('Surface enthaelt Governance CLEAR/PASS Daten', surface?.governance?.coverage_status === 'PASS' && surface?.governance?.decisions_status === 'CLEAR', JSON.stringify(surface?.governance || {}));
add('Surface enthaelt Complete-Context Items', Number(surface?.governance?.complete_context_items || 0) > 0, String(surface?.governance?.complete_context_items || 0));
add('Type PlanningQualitySurface vorhanden', types.includes('export interface PlanningQualitySurface'), 'lib/types.ts');
add('Type enthaelt Operator Actions', types.includes('operator_actions') && types.includes('fresh_session_handoff'), 'lib/types.ts');
add('Control Plane liest PIG Surface', liveData.includes('PIG_QUALITY_OS_SURFACE_PATH') && liveData.includes('planningQuality'), 'live-data.ts');
add('Control Plane mappt V3 Felder', liveData.includes('operator_actions') && liveData.includes('run_controls') && liveData.includes('fresh_session_handoff') && liveData.includes('governance'), 'live-data.ts');
add('Portfolio UI zeigt Planning Quality Panel', component.includes('PlanningQualityPanel') && component.includes('Planning Quality / Workflow Runs'), 'portfolio-control-tower-page.tsx');
add('Portfolio UI zeigt V3 Controls', component.includes('Operator Actions') && component.includes('Pause / Resume / Retry') && component.includes('Fresh-Session-Übergabe') && component.includes('PIG Governance'), 'portfolio-control-tower-page.tsx');
add('Surface enthält Quality OS Job-Schiene', surface?.systemwide_rule_propagation?.fresh_data_intake?.status && surface?.systemwide_rule_propagation?.vivi_job_card_queue?.status && surface?.systemwide_rule_propagation?.vivi_runner_mvp?.status && surface?.systemwide_rule_propagation?.vivi_supervisor_audit?.status, JSON.stringify(surface?.systemwide_rule_propagation || {}));
add('Portfolio UI zeigt Quality OS Job-Schiene', component.includes('Quality OS Job-Schiene') && component.includes('Fresh Data') && component.includes('Job Cards') && component.includes('Supervisor'), 'portfolio-control-tower-page.tsx');
add('Type enthält Vivi Supervisor Surface', types.includes('vivi_supervisor_audit') && types.includes('vivi_supervisor_truth_status') && types.includes('fresh_data_intake'), 'lib/types.ts');
add('Surface enthält Dirt-Verifier-Summary', Number(surface?.systemwide_rule_propagation?.autonomy_dirt_backlog_scan?.verifier_executed_count || 0) > 0 && Number(surface?.systemwide_rule_propagation?.autonomy_dirt_backlog_scan?.verifier_planned_count || 0) === 0, JSON.stringify(surface?.systemwide_rule_propagation?.autonomy_dirt_backlog_scan || {}));
add('Portfolio UI zeigt Dirt-Verifier-Summary', component.includes('Dirt / Übergabe / Verifier') && component.includes('Dirty Projekte') && component.includes('Noch geplant'), 'portfolio-control-tower-page.tsx');
add('Type enthält Dirt-Verifier-Surface', types.includes('autonomy_dirt_backlog_scan') && types.includes('autonomy_dirt_verifier_executed_count'), 'lib/types.ts');
const dirtQueueStatus = surface?.systemwide_rule_propagation?.autonomy_dirt_backlog_scan?.handoff_decision_queue_status;
const dirtSafeCount = Number(surface?.systemwide_rule_propagation?.autonomy_dirt_backlog_scan?.handoff_safe_queue_count || 0);
const dirtReviewedCount = Number(surface?.systemwide_rule_propagation?.autonomy_dirt_backlog_scan?.handoff_reviewed_queue_count || 0);
const dirtGateCount = Number(surface?.systemwide_rule_propagation?.autonomy_dirt_backlog_scan?.handoff_operator_gate_queue_count || 0);
add(
  'Surface enthält Dirt-Entscheidungsqueue',
  (dirtQueueStatus === 'ready_for_local_review' && dirtSafeCount > 0)
    || (dirtQueueStatus === 'operator_gated_only' && dirtSafeCount === 0 && dirtReviewedCount > 0 && dirtGateCount > 0)
    || dirtQueueStatus === 'empty',
  JSON.stringify(surface?.systemwide_rule_propagation?.autonomy_dirt_backlog_scan || {}),
);
add('Portfolio UI zeigt Dirt-Entscheidungsqueue', component.includes('Nächste Dirt-Entscheidung') && component.includes('Lokale Review-Queue') && component.includes('Gate-Queue'), 'portfolio-control-tower-page.tsx');
add('Type enthält Dirt-Entscheidungsqueue', types.includes('safe_work_queue') && types.includes('next_safe_review') && types.includes('handoff_safe_queue_count'), 'lib/types.ts');
add('Surface enthält Commit/Cleanup Operator-Go Paket', ['operator_go_required', 'needs_local_review', 'blocked_by_missing_evidence', 'closed_no_action'].includes(surface?.systemwide_rule_propagation?.commit_cleanup_go_package?.status) && surface?.systemwide_rule_propagation?.commit_cleanup_go_package?.runtime_action_executed === false, JSON.stringify(surface?.systemwide_rule_propagation?.commit_cleanup_go_package || {}));
add('Portfolio UI zeigt Operator-Go Paket', component.includes('Operator-Go Paket') && component.includes('Commit/Cleanup') && component.includes('Runtime-Aktion'), 'portfolio-control-tower-page.tsx');
add('Type enthält Commit/Cleanup Operator-Go Surface', types.includes('commit_cleanup_go_package') && types.includes('commit_cleanup_go_package_status') && types.includes('operator_gate_queue_count'), 'lib/types.ts');
add('Surface enthält Vivi Worker MVP', surface?.systemwide_rule_propagation?.vivi_worker_mvp?.runtime_action_executed === false && ['completed_verified', 'closed_no_action', 'waiting_for_operator', 'failed_safe'].includes(surface?.systemwide_rule_propagation?.vivi_worker_mvp?.status), JSON.stringify(surface?.systemwide_rule_propagation?.vivi_worker_mvp || {}));
add('Portfolio UI zeigt Vivi Worker MVP', component.includes('Vivi Worker') && component.includes('Worker Queue') && component.includes('Worker Supervisor'), 'portfolio-control-tower-page.tsx');
add('Type enthält Vivi Worker Surface', types.includes('vivi_worker_mvp') && types.includes('vivi_worker_supervisor_audit') && types.includes('local_artifact_write_executed'), 'lib/types.ts');
add('Surface enthält Endgame Makro-Roadmap', surface?.control_capabilities?.endgame_roadmap === true && surface?.systemwide_rule_propagation?.endgame_roadmap?.safe_work_remaining === true && Number(surface?.systemwide_rule_propagation?.endgame_roadmap?.macro_completion_percent ?? -1) >= 0 && Array.isArray(surface?.systemwide_rule_propagation?.endgame_roadmap?.macro_backlog) && surface.systemwide_rule_propagation.endgame_roadmap.macro_backlog.length >= 3, JSON.stringify(surface?.systemwide_rule_propagation?.endgame_roadmap || {}));
add('Portfolio UI zeigt Endgame Makro-Roadmap', component.includes('Endgame Makro-Roadmap') && component.includes('Foundation Completion') && component.includes('Makro Completion') && component.includes('Safe Next Blocks') && component.includes('Foundation-Grün ist nicht Endprodukt'), 'portfolio-control-tower-page.tsx');
add('Type enthält Endgame Makro-Roadmap Surface', types.includes('endgame_roadmap') && types.includes('macro_completion_percent') && types.includes('macro_backlog') && types.includes('completion_note'), 'lib/types.ts');
add('Surface enthält OpenJarvis Capability Lab', surface?.control_capabilities?.openjarvis_capability_lab === true && surface?.systemwide_rule_propagation?.openjarvis_capability_lab?.runtime_action_executed === false && surface?.systemwide_rule_propagation?.openjarvis_capability_lab?.source_of_truth === false, JSON.stringify(surface?.systemwide_rule_propagation?.openjarvis_capability_lab || {}));
add('Portfolio UI zeigt OpenJarvis Capability Lab', component.includes('OpenJarvis Capability-Lab Zustand') && component.includes('Planning Quality / PIG Operator Surface') && component.includes('Retrieval Benchmark') && component.includes('Source of Truth'), 'portfolio-control-tower-page.tsx');
add('Type enthält OpenJarvis Capability Surface', types.includes('openjarvis_capability_lab') && types.includes('openjarvis_retrieval_pass_count') && types.includes('runtime_execution_attempted'), 'lib/types.ts');
add('Surface enthält OpenJarvis Capability Arena', surface?.control_capabilities?.openjarvis_capability_arena === true && surface?.systemwide_rule_propagation?.openjarvis_capability_arena?.runtime_action_executed === false && surface?.systemwide_rule_propagation?.openjarvis_capability_arena?.source_of_truth === false && surface?.systemwide_rule_propagation?.openjarvis_capability_arena?.shadow_fail_count === 0, JSON.stringify(surface?.systemwide_rule_propagation?.openjarvis_capability_arena || {}));
add('Portfolio UI zeigt OpenJarvis Capability Arena', component.includes('OpenJarvis Capability Arena') && component.includes('Shadow Tournament gegen PIG / Obsidian') && component.includes('Shadow Wins') && component.includes('Baseline Wins'), 'portfolio-control-tower-page.tsx');
add('Type enthält OpenJarvis Capability Arena Surface', types.includes('openjarvis_capability_arena') && types.includes('openjarvis_arena_shadow_wins') && types.includes('shadow_average_score'), 'lib/types.ts');
add('Portfolio UI nutzt sichtbare Umlaute', !component.includes('naechster sicherer') && !component.includes('Naechster Sicherer') && !component.includes('fuer Measurement') && !component.includes('Groessere Laeufe') && !component.includes('Build-Vertraege'), 'portfolio-control-tower-page.tsx');
add('Portfolio Surface ist direkt verlinkbar', appShell.includes("searchParams.get('view')") && appShell.includes('setSelectedView(requestedView)'), '/control-plane-v2?view=portfolio');
add('UI zeigt keine n8n Runtime-Freigabe', !component.toLowerCase().includes('n8n-runtime'), 'no runtime wording');

const failed = checks.filter((check) => !check.pass);
for (const check of checks) {
  const marker = check.pass ? 'PASS' : 'FAIL';
  console.log(`${marker} ${check.name}: ${check.detail}`);
}

if (failed.length) {
  process.exitCode = 1;
}
