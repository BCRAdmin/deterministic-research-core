'use client';

import { Archive, BarChart3, CalendarDays, ClipboardCheck, GitBranch, Hourglass, ListChecks, ShieldCheck, ShieldX } from 'lucide-react';

import { StatusChip } from '@/components/status-chip';
import { Card, CardDescription, CardTitle } from '@/components/ui/card';
import { useControlPlaneData } from '@/components/use-control-plane-data';
import { cn } from '@/lib/cn';
import type { PlanningQualitySurface, PortfolioExecutionContract, PortfolioMetricCardId, PortfolioRepositoryStatus, PortfolioReviewCalendarItem, PortfolioStreamMetric, Severity } from '@/lib/types';

const portfolioMetricCards: Array<{
  id: PortfolioMetricCardId;
  title: string;
  description: string;
}> = [
  { id: 'utility-revenue-funnel', title: 'Utility Revenue/Funnel', description: 'Measurement, Conversion-Signale und Revenue-Gates.' },
  { id: 'trust-rule-coverage', title: 'Trust/Rule Coverage', description: 'Quellenmatrix, Regelabdeckung und fachliche Review-Luecken.' },
  { id: 'membership-readiness', title: 'Membership Readiness', description: 'Lokale Launch-Pruefung ohne Credentials, Provider- oder Payment-Go.' },
  { id: 'review-queue', title: 'Review Queue', description: 'Interne Dossier-Pruefung, Gate-Reasons und manuelle Aktionen.' },
  { id: 'outcome-horizons', title: 'Outcome Horizons', description: '5D/10D/20D/60D-Schnittstelle ohne Live- oder Advice-Go.' },
  { id: 'opportunity-backlog', title: 'Opportunity Backlog', description: 'Scorecard, Kandidaten und Scaffold-Grenzen.' },
  { id: 'maintenance-governance', title: 'Maintenance/Governance', description: 'GitHub-Planblocker, generated state und No-Touch-Policy.' },
];

function SummaryStrip({ repositories }: { repositories: PortfolioRepositoryStatus[] }) {
  const active = repositories.filter((repo) => repo.lifecycle === 'active').length;
  const archived = repositories.filter((repo) => repo.lifecycle === 'archived').length;
  const greenCi = repositories.filter((repo) => repo.ciStatus === 'green').length;
  const operatorGated = repositories.filter((repo) => repo.publicGate === 'operator_gated').length;
  const branchBlocked = repositories.filter((repo) => repo.branchProtectionStatus === 'blocked_plan_or_public_required').length;
  const secretScanningUnavailable = repositories.filter((repo) => repo.secretScanningStatus === 'unavailable_private_repo').length;

  const metrics = [
    ['Aktive Repos', active, 'success'],
    ['Archiviert', archived, 'warning'],
    ['CI grün', greenCi, 'success'],
    ['Operator-Gates', operatorGated, 'warning'],
    ['Branch-Schutz blockiert', branchBlocked, 'warning'],
    ['Secret-Scanning blockiert', secretScanningUnavailable, 'warning'],
  ] as const;

  return (
    <div className="grid gap-3 md:grid-cols-3 2xl:grid-cols-6">
      {metrics.map(([label, value, tone]) => (
        <Card key={label} className="rounded-2xl p-4">
          <div className="hud-label text-muted">{label}</div>
          <div className="mt-3 flex items-end justify-between gap-3">
            <div className="text-3xl font-semibold text-text">{value}</div>
            <StatusChip label={String(value)} tone={tone} />
          </div>
        </Card>
      ))}
    </div>
  );
}

function PortfolioGrid({ repositories }: { repositories: PortfolioRepositoryStatus[] }) {
  return (
    <div className="col-span-12 grid gap-3">
      <Card className="rounded-2xl p-4">
        <CardTitle className="text-sm text-vega">Portfolio-Baseline</CardTitle>
        <CardDescription>Repo-Status, Gates, Sicherheitslage und nächste Aktion pro BCRAdmin-Projekt.</CardDescription>
      </Card>
      <div className="grid gap-3 xl:grid-cols-2">
        {repositories.map((repo) => (
          <RepoCard key={repo.id} repo={repo} />
        ))}
      </div>
    </div>
  );
}

function PortfolioMetricsGrid({ streams }: { streams: PortfolioStreamMetric[] }) {
  return (
    <div className="col-span-12 grid gap-3">
      <Card className="rounded-2xl p-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <CardTitle className="text-sm text-vega">Portfolio Control Tower V2</CardTitle>
            <CardDescription>Stream-Ergebnisse für Measurement, Trust, Review, Outcomes, Opportunities und Governance.</CardDescription>
          </div>
          <StatusChip label={`${streams.length} Streams`} tone="info" />
        </div>
      </Card>
      <div className="grid gap-3 xl:grid-cols-2 2xl:grid-cols-3">
        {portfolioMetricCards.map((card) => (
          <PortfolioMetricCard
            key={card.id}
            card={card}
            streams={streams.filter((stream) => stream.cardId === card.id)}
          />
        ))}
      </div>
    </div>
  );
}

function ReviewCalendarPanel({ reviews }: { reviews: PortfolioReviewCalendarItem[] }) {
  const orderedReviews = [...reviews].sort((a, b) => a.dueDate.localeCompare(b.dueDate));

  return (
    <div className="col-span-12 grid gap-3">
      <Card className="rounded-2xl p-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <CardTitle className="text-sm text-vega">Review Calendar</CardTitle>
            <CardDescription>Nächste Review-Fenster, erwartete Daten und geschlossene Decision-/Operator-Gates pro Stream.</CardDescription>
          </div>
          <StatusChip label={`${orderedReviews.length} Termine`} tone="info" />
        </div>
      </Card>
      <div className="grid gap-3 xl:grid-cols-2 2xl:grid-cols-3">
        {orderedReviews.map((review) => (
          <div key={review.id} className="rounded-2xl border border-border bg-elevated/45 p-4">
            <div className="flex min-w-0 items-start justify-between gap-3">
              <div className="flex min-w-0 items-start gap-3">
                <div className={cn('grid size-10 shrink-0 place-items-center rounded-xl border', reviewGroupClass(review.streamGroup))}>
                  <CalendarDays className="size-5" />
                </div>
                <div className="min-w-0">
                  <div className="break-all font-mono text-[0.68rem] text-vega">{review.streamId}</div>
                  <div className="mt-1 text-sm font-semibold text-text">{review.reviewLabel}</div>
                  <div className="mt-1 text-xs leading-5 text-muted">{review.streamLabel} · {review.windowLabel}</div>
                </div>
              </div>
              <StatusChip label={reviewStatusLabel(review.status)} tone={reviewStatusTone(review.status)} />
            </div>

            <div className="mt-4 grid gap-2 sm:grid-cols-2">
              <CalendarInfoRow label="Fällig" value={formatReviewDate(review.dueDate)} />
              <CalendarInfoRow label="No-Data" value={review.noDataStatus} />
            </div>

            <div className="mt-3 rounded-xl border border-border bg-cpbg/30 p-3">
              <div className="hud-label text-muted">Erwartete Daten</div>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {review.expectedData.map((item) => (
                  <span key={`${review.id}-${item}`} className="rounded-lg border border-border bg-elevated/55 px-2 py-1 font-mono text-[0.66rem] text-muted">{item}</span>
                ))}
              </div>
            </div>

            <div className="mt-3 grid gap-2">
              <CalendarGateRow label="Decision Gate" value={review.decisionGate} />
              <CalendarGateRow label="Operator Gate" value={review.operatorGate} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function PortfolioMetricCard({
  card,
  streams,
}: {
  card: { id: PortfolioMetricCardId; title: string; description: string };
  streams: PortfolioStreamMetric[];
}) {
  const tone = metricCardTone(streams);

  return (
    <Card className="rounded-2xl p-4">
      <div className="flex min-w-0 items-start justify-between gap-3">
        <div className="flex min-w-0 items-start gap-3">
          <div className={cn('grid size-10 shrink-0 place-items-center rounded-xl border', metricIconClass(tone))}>
            <MetricCardIcon id={card.id} />
          </div>
          <div className="min-w-0">
            <div className="hud-title break-words text-sm text-vega">{card.title}</div>
            <div className="mt-1 text-xs leading-5 text-muted">{card.description}</div>
          </div>
        </div>
        <StatusChip label={metricCardLabel(tone)} tone={tone} />
      </div>

      <div className="mt-4 grid gap-3">
        {streams.map((stream) => (
          <div key={stream.id} className="rounded-xl border border-border bg-cpbg/30 p-3">
            <div className="flex min-w-0 flex-wrap items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="break-all font-mono text-[0.68rem] text-vega">{stream.id}</div>
                <div className="mt-1 text-sm font-semibold text-text">{stream.title}</div>
              </div>
              <StatusChip label={metricStatusLabel(stream.status)} tone={stream.health} />
            </div>

            <div className="mt-3 grid gap-2 sm:grid-cols-3">
              {stream.signals.map((signal) => (
                <div key={`${stream.id}-${signal.label}`} className="rounded-lg border border-border bg-elevated/40 p-2">
                  <div className="hud-label text-muted">{signal.label}</div>
                  <div className={cn('mt-1 break-words font-mono text-sm', signal.tone ? metricTextClass(signal.tone) : 'text-text')}>{signal.value}</div>
                  <div className="mt-1 text-[0.68rem] leading-4 text-muted">{signal.detail}</div>
                </div>
              ))}
            </div>

            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              <GuardState label="Production-Go" open={stream.productionGo} />
              <GuardState label="Public Ready" open={stream.publicReady} />
            </div>

            <div className="mt-3 flex flex-wrap gap-1.5">
              {stream.gates.map((gate) => (
                <span key={`${stream.id}-${gate}`} className="rounded-lg border border-border bg-elevated/50 px-2 py-1 font-mono text-[0.66rem] text-muted">{gate}</span>
              ))}
            </div>

            <div className="mt-3 grid gap-1.5 text-xs leading-5">
              <div className="break-words text-muted">{stream.evidence}</div>
              <div className="break-words font-mono text-vivi">{stream.verifier}</div>
              {stream.remoteCi ? <div className="break-words font-mono text-vega">{stream.remoteCi}</div> : null}
              <div className="break-words text-text">{stream.nextAction}</div>
            </div>
          </div>
        ))}
        {streams.length === 0 ? <div className="rounded-xl border border-border bg-cpbg/30 p-3 text-sm text-muted">Stream noch nicht registriert.</div> : null}
      </div>
    </Card>
  );
}

function GuardState({ label, open }: { label: string; open: boolean }) {
  return (
    <div className="flex items-center justify-between gap-2 rounded-lg border border-border bg-elevated/40 p-2 text-xs">
      <span className="text-muted">{label}</span>
      <StatusChip label={open ? 'offen' : 'geschlossen'} tone={open ? 'critical' : 'success'} />
    </div>
  );
}

function RepoCard({ repo }: { repo: PortfolioRepositoryStatus }) {
  return (
    <Card className="rounded-2xl p-4">
      <div className="flex min-w-0 items-start justify-between gap-3">
        <div className="flex min-w-0 items-start gap-3">
          <div className={cn('grid size-10 shrink-0 place-items-center rounded-xl border', repo.lifecycle === 'archived' ? 'border-warning/40 bg-warning/10 text-warning' : 'border-vega/40 bg-vega-soft text-vega')}>
            {repo.lifecycle === 'archived' ? <Archive className="size-5" /> : <GitBranch className="size-5" />}
          </div>
          <div className="min-w-0">
            <div className="break-all font-mono text-xs text-vega">{repo.repo}</div>
            <div className="mt-1 text-sm font-semibold text-text">{repo.product}</div>
            <div className="mt-1 break-all text-xs leading-5 text-muted">{repo.localPath}</div>
          </div>
        </div>
        <StatusChip label={repo.lifecycle === 'active' ? 'aktiv' : 'archiviert'} tone={repo.lifecycle === 'active' ? 'success' : 'warning'} />
      </div>

      <div className="mt-4 grid gap-2 sm:grid-cols-2">
        <InfoRow label="Branch" value={repo.branch} />
        <InfoRow label="Snapshot-SHA" value={repo.lastKnownSha} />
        <ChipRow label="CI" labelValue={statusLabel(repo.ciStatus)} tone={statusTone(repo.ciStatus)} />
        <ChipRow label="E2E" labelValue={statusLabel(repo.e2eStatus)} tone={statusTone(repo.e2eStatus)} />
        <ChipRow label="Risiko" labelValue={riskLabel(repo.risk)} tone={riskTone(repo.risk)} />
        <InfoRow label="Gate" value={publicGateLabel(repo.publicGate)} />
      </div>

      <div className="mt-4 grid gap-2 rounded-xl border border-border bg-cpbg/30 p-3">
        <SecurityRow label="Dependabot" value={securityLabel(repo.dependabotStatus)} good={repo.dependabotStatus === 'active'} />
        <SecurityRow label="Branch-Schutz" value={branchProtectionLabel(repo.branchProtectionStatus)} good={repo.branchProtectionStatus === 'not_applicable'} />
        <SecurityRow label="Secret-Scan" value={secretScanningLabel(repo.secretScanningStatus)} good={repo.secretScanningStatus === 'not_applicable'} />
      </div>

      <div className="mt-4 flex flex-wrap gap-1.5">
        {repo.requiredChecks.map((check) => (
          <span key={check} className="rounded-lg border border-border bg-elevated/50 px-2 py-1 font-mono text-[0.66rem] text-muted">{check}</span>
        ))}
        {repo.requiredChecks.length === 0 ? <span className="text-xs text-muted">keine laufenden Checks</span> : null}
      </div>

      <div className="mt-4 rounded-xl border border-border bg-cpbg/30 p-3">
        <div className="hud-label text-muted">Nächste Aktion</div>
        <div className="mt-2 text-sm leading-6 text-text">{repo.nextAction}</div>
      </div>
    </Card>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-border bg-cpbg/30 p-3">
      <div className="hud-label text-muted">{label}</div>
      <div className="mt-1 break-words font-mono text-xs leading-5 text-text">{value}</div>
    </div>
  );
}

function ChipRow({ label, labelValue, tone }: { label: string; labelValue: string; tone: Severity | 'neutral' }) {
  return (
    <div className="rounded-xl border border-border bg-cpbg/30 p-3">
      <div className="hud-label text-muted">{label}</div>
      <div className="mt-2">
        <StatusChip label={labelValue} tone={tone} />
      </div>
    </div>
  );
}

function SecurityRow({ good, label, value }: { good: boolean; label: string; value: string }) {
  return (
    <div className="grid grid-cols-[22px_96px_minmax(0,1fr)] items-center gap-2 text-xs">
      {good ? <ShieldCheck className="size-4 text-vivi" /> : <ShieldX className="size-4 text-warning" />}
      <span className="text-muted">{label}</span>
      <span className={cn('truncate', good ? 'text-vivi' : 'text-warning')}>{value}</span>
    </div>
  );
}

function ExecutionContractPanel({ contract }: { contract: PortfolioExecutionContract }) {
  const topTruth = contract.truthHierarchy.slice(0, 5);

  return (
    <Card className="rounded-2xl p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="hud-title text-sm text-vega">EXECUTION CONTRACT</div>
          <div className="mt-2 max-w-4xl text-sm leading-6 text-muted">
            Kanonische Arbeitsweise für Vega, Vega 0, Vivi, Room16, Deterministic-Core, Utility-Webseiten, Microtool-Starter, LIONCOM und Operator-Go-Prozesse.
          </div>
        </div>
        <StatusChip label={contract.status === 'canonical' ? 'kanonisch' : contract.status} tone="success" />
      </div>

      <div className="mt-4 grid gap-3 lg:grid-cols-[1.15fr_1fr]">
        <div className="rounded-xl border border-border bg-cpbg/30 p-3">
          <div className="hud-label text-muted">Truth-Hierarchy</div>
          <div className="mt-3 grid gap-2">
            {topTruth.map((item, index) => (
              <div key={item} className="grid grid-cols-[32px_minmax(0,1fr)] items-center gap-2 text-sm">
                <span className="grid size-7 place-items-center rounded-lg border border-vega/35 bg-vega-soft font-mono text-xs text-vega">{index + 1}</span>
                <span className="break-words text-text">{truthHierarchyLabel(item)}</span>
              </div>
            ))}
          </div>
          <div className="mt-3 text-xs leading-5 text-muted">{handoffRuleLabel(contract.handoffRule)}</div>
        </div>

        <div className="grid gap-3">
          <div className="rounded-xl border border-border bg-cpbg/30 p-3">
            <div className="hud-label text-muted">Version und Verifier</div>
            <div className="mt-2 font-mono text-xs leading-6 text-text">{contract.version}</div>
            <div className="mt-1 font-mono text-xs leading-6 text-vivi">{contract.verifier}</div>
          </div>
          <div className="rounded-xl border border-border bg-cpbg/30 p-3">
            <div className="hud-label text-muted">Kanonische Doku</div>
            <div className="mt-2 grid gap-2 text-xs leading-5">
              <a className="break-all font-mono text-vega hover:text-text" href={contract.githubDocUrl} target="_blank" rel="noreferrer">{contract.contractDocPath}</a>
              <a className="break-all font-mono text-vega hover:text-text" href={contract.githubRoleRegistryUrl} target="_blank" rel="noreferrer">{contract.roleRegistryDocPath}</a>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}

function GatePanel({ repositories }: { repositories: PortfolioRepositoryStatus[] }) {
  const blockedSecurity = repositories.filter((repo) =>
    repo.branchProtectionStatus === 'blocked_plan_or_public_required'
    || repo.secretScanningStatus === 'unavailable_private_repo',
  );
  const archived = repositories.find((repo) => repo.id === 'vivi-os-v1');

  return (
    <div className="grid gap-3 xl:grid-cols-4">
      <Card className="rounded-2xl p-4">
        <div className="hud-title text-sm text-vega">Maintenance-Baseline</div>
        <div className="mt-3 text-sm leading-6 text-muted">
          LIONCOM ist auf Next 15.5.18, React 19.2.6 und Electron 39.8.10 eingefroren. Build-ID OuFrDueeo4aN4umXaAhjV bleibt der verifizierte Desktop-/Runtime-Anker.
        </div>
      </Card>
      <Card className="rounded-2xl p-4">
        <div className="hud-title text-sm text-vega">GitHub-Gates</div>
        <div className="mt-3 text-sm leading-6 text-muted">
          {blockedSecurity.length} aktive Repos warten auf GitHub-Pro/öffentlich-Entscheid für Branch Protection oder Secret Scanning. Dependabot und Automated Security Fixes bleiben aktiv.
        </div>
      </Card>
      <Card className="rounded-2xl p-4">
        <div className="hud-title text-sm text-warning">Public-/Production-Gates</div>
        <div className="mt-3 text-sm leading-6 text-muted">
          Keine grüne CI öffnet automatisch Production, Public Output, Monetarisierung oder Financial-Advice-Flächen. Jede Freigabe bleibt Operator-Gate.
        </div>
      </Card>
      <Card className="rounded-2xl p-4">
        <div className="hud-title text-sm text-warning">Legacy-Schutz</div>
        <div className="mt-3 text-sm leading-6 text-muted">
          {archived?.repo ?? 'BCRAdmin/Vivi-os-v1'} bleibt archiviert, read-only und ohne Roadmap. Führende Vivi-/Control-Plane-Wahrheit bleibt LIONCOM.
        </div>
      </Card>
    </div>
  );
}

export function PortfolioControlTowerPage() {
  const { portfolioRepositories, portfolioExecutionContract, portfolioMetrics, portfolioReviewCalendar, planningQuality } = useControlPlaneData();

  return (
    <div className="grid min-h-full grid-cols-12 gap-3">
      <Card className="col-span-12 rounded-2xl p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="hud-title text-3xl text-vega">PORTFOLIO CONTROL TOWER</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-muted">BCRAdmin-Portfolio-Baseline für aktive Repos, Legacy-Schutz, CI-/Gate-Lage und die nächste sinnvolle Aktion pro Projekt.</p>
          </div>
          <StatusChip label={`${portfolioRepositories.length} Repos`} tone="info" />
        </div>
      </Card>
      <div className="col-span-12">
        <SummaryStrip repositories={portfolioRepositories} />
      </div>
      <PlanningQualityPanel planningQuality={planningQuality} />
      <ReviewCalendarPanel reviews={portfolioReviewCalendar} />
      <PortfolioMetricsGrid streams={portfolioMetrics} />
      <PortfolioGrid repositories={portfolioRepositories} />
      <div className="col-span-12">
        <ExecutionContractPanel contract={portfolioExecutionContract} />
      </div>
      <div className="col-span-12">
        <GatePanel repositories={portfolioRepositories} />
      </div>
    </div>
  );
}

function PlanningQualityPanel({ planningQuality }: { planningQuality: PlanningQualitySurface }) {
  const latestRun = planningQuality.workflow_runs[0];
  const lastVerifier = planningQuality.last_verifier;
  const qualityStatus = planningQuality.contract_quality.status || planningQuality.status;
  const operatorActions = planningQuality.operator_actions ?? [];
  const runControls = planningQuality.run_controls ?? [];
  const handoff = planningQuality.fresh_session_handoff;
  const governance = planningQuality.governance;
  const autonomy = planningQuality.systemwide_rule_propagation?.autonomy_governor;
  const viviHandoff = planningQuality.systemwide_rule_propagation?.vivi_vega_handoff_inbox;
  const freshSession = planningQuality.systemwide_rule_propagation?.fresh_session_readiness;
  const freshData = planningQuality.systemwide_rule_propagation?.fresh_data_intake;
  const jobQueue = planningQuality.systemwide_rule_propagation?.vivi_job_card_queue;
  const runner = planningQuality.systemwide_rule_propagation?.vivi_runner_mvp;
  const supervisor = planningQuality.systemwide_rule_propagation?.vivi_supervisor_audit;
  const dirtScan = planningQuality.systemwide_rule_propagation?.autonomy_dirt_backlog_scan;
  const commitPackage = planningQuality.systemwide_rule_propagation?.commit_cleanup_go_package;
  const viviWorkerQueue = planningQuality.systemwide_rule_propagation?.vivi_worker_queue;
  const viviWorker = planningQuality.systemwide_rule_propagation?.vivi_worker_mvp;
  const viviWorkerSupervisor = planningQuality.systemwide_rule_propagation?.vivi_worker_supervisor_audit;
  const endgame = planningQuality.systemwide_rule_propagation?.endgame_roadmap;
  const endgameSafeBlocks = endgame?.safe_next_blocks ?? [];
  const macroBacklog = endgame?.macro_backlog ?? [];
  const openjarvisLab = planningQuality.systemwide_rule_propagation?.openjarvis_capability_lab;
  const openjarvisArena = planningQuality.systemwide_rule_propagation?.openjarvis_capability_arena;

  return (
    <div className="col-span-12 grid gap-3">
      <Card className="rounded-2xl p-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <CardTitle className="text-sm text-vega">Planning Quality / Workflow Runs</CardTitle>
            <CardDescription>Build Contracts, Approval Actions, Run Controls, letzter Verifier und nächster sicherer Schritt aus PIG.</CardDescription>
          </div>
          <div className="flex flex-wrap gap-2">
            <StatusChip label={planningQuality.surface_version || 'v2'} tone="info" />
            <StatusChip label={qualityStatus || 'UNKNOWN'} tone={planningQualityTone(planningQuality.status)} />
          </div>
        </div>
      </Card>

      <div className="grid gap-3 xl:grid-cols-4">
        <Card className="rounded-2xl p-4">
          <div className="hud-label text-muted">Aktive Contracts</div>
          <div className="mt-3 text-3xl font-semibold text-text">{planningQuality.active_build_contracts.length}</div>
          <div className="mt-2 text-xs leading-5 text-muted">Offene Build-Verträge ohne Abschlussstatus.</div>
        </Card>
        <Card className="rounded-2xl p-4">
          <div className="hud-label text-muted">Zielbildfragen</div>
          <div className="mt-3 text-3xl font-semibold text-text">{planningQuality.needs_target_picture.length}</div>
          <div className="mt-2 text-xs leading-5 text-muted">`needs_target_picture` statt stiller Roadmap-Drift.</div>
        </Card>
        <Card className="rounded-2xl p-4">
          <div className="hud-label text-muted">Approval Nodes</div>
          <div className="mt-3 text-3xl font-semibold text-text">{planningQuality.approval_nodes.length}</div>
          <div className="mt-2 text-xs leading-5 text-muted">Public, Production, Geld, Credentials/Auth und externe Sends bleiben Gates.</div>
        </Card>
        <Card className="rounded-2xl p-4">
          <div className="hud-label text-muted">Workflow Runs</div>
          <div className="mt-3 text-3xl font-semibold text-text">{planningQuality.workflow_runs.length}</div>
          <div className="mt-2 text-xs leading-5 text-muted">Größere Läufe existieren lokal, nicht nur im Chat.</div>
        </Card>
      </div>

      <div className="grid gap-3 xl:grid-cols-2">
        <Card className="rounded-2xl p-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <CardTitle className="text-sm text-vega">Aktueller Workflow Run</CardTitle>
              <CardDescription>{latestRun?.run_id || 'Kein Run geladen'}</CardDescription>
            </div>
            <StatusChip label={latestRun?.status || 'missing'} tone={planningQualityTone(latestRun?.status || 'WARN')} />
          </div>
          <div className="mt-4 grid gap-2 sm:grid-cols-2">
            <InfoRow label="Current Step" value={latestRun?.current_step || planningQuality.stopped_reason || 'missing'} />
            <InfoRow label="Effect Scope" value={planningQuality.effect_scope || 'unknown'} />
            <InfoRow label="Control State" value={latestRun?.control_state || 'missing'} />
            <InfoRow label="Retry Count" value={String(latestRun?.retry_count ?? 0)} />
            <InfoRow label="Letzter Verifier" value={lastVerifier.command || lastVerifier.name || 'missing'} />
            <ChipRow label="Verifier Status" labelValue={lastVerifier.status || 'UNKNOWN'} tone={planningQualityTone(lastVerifier.status || 'WARN')} />
          </div>
        </Card>

        <Card className="rounded-2xl p-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <CardTitle className="text-sm text-vega">Nächster Sicherer Schritt</CardTitle>
              <CardDescription>Lokaler Contract-/Gate-Pfad ohne Runtime- oder Public-Go.</CardDescription>
            </div>
            <StatusChip label={`${planningQuality.job_cards.length} Job Cards`} tone="info" />
          </div>
          <div className="mt-3 text-sm leading-6 text-text">{planningQuality.next_safe_step}</div>
          {planningQuality.stopped_reason ? <div className="mt-3 rounded-xl border border-warning/35 bg-warning/10 p-3 text-xs leading-5 text-warning">{planningQuality.stopped_reason}</div> : null}
        </Card>
      </div>

      <div className="grid gap-3 xl:grid-cols-2">
        <div className="rounded-2xl border border-border bg-elevated/45 p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="hud-label text-muted">PIG Governance</div>
              <div className="mt-1 text-sm font-semibold text-text">{governance?.overall || 'UNKNOWN'}</div>
            </div>
            <StatusChip label={governance?.decisions_status || 'UNKNOWN'} tone={planningQualityTone(governance?.decisions_status || 'WARN')} />
          </div>
          <div className="mt-3 grid gap-2">
            <ChipRow label="Coverage" labelValue={governance?.coverage_status || 'UNKNOWN'} tone={planningQualityTone(governance?.coverage_status || 'WARN')} />
            <ChipRow label="Decisions" labelValue={String(governance?.unresolved_decisions ?? 0)} tone={(governance?.unresolved_decisions ?? 0) === 0 ? 'success' : 'warning'} />
            <InfoRow label="Complete Context" value={`${governance?.complete_context_items ?? 0} Items`} />
            <InfoRow label="Workbenches" value={`${governance?.guardrail_policy_gates ?? 0} Gates · ${governance?.memory_promotion_batches ?? 0} Memory-Batches`} />
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-elevated/45 p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="hud-label text-muted">Autonomy Governor</div>
              <div className="mt-1 text-sm font-semibold text-text">{autonomy?.autonomy_state || governance?.autonomy_state || 'UNKNOWN'}</div>
            </div>
            <StatusChip label={autonomy?.status || governance?.autonomy_governor_status || 'UNKNOWN'} tone={planningQualityTone(autonomy?.status || governance?.autonomy_governor_status || 'WARN')} />
          </div>
          <div className="mt-3 grid gap-2">
            <InfoRow label="Sichere Arbeit" value={`${governance?.autonomy_safe_work_remaining ?? autonomy?.next_safe_steps?.length ?? 0} Workstreams`} />
            <InfoRow label="Fresh Session" value={`${freshSession?.status || governance?.fresh_session_readiness_status || 'UNKNOWN'} · ${freshSession?.warning_count ?? governance?.fresh_session_readiness_warnings ?? 0} Warnungen`} />
            {(autonomy?.next_safe_steps ?? []).slice(0, 2).map((step) => (
              <div key={step.workstream_id || step.next_safe_step} className="rounded-lg border border-border/80 bg-surface/45 p-3">
                <div className="text-[0.68rem] font-semibold text-vega">{step.priority || 'P?' } · {step.workstream_id || 'workstream'}</div>
                <div className="mt-1 text-xs leading-5 text-muted">{step.next_safe_step || 'Kein nächster Schritt geladen.'}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-elevated/45 p-4 xl:col-span-2">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="hud-label text-muted">Endgame Makro-Roadmap</div>
              <div className="mt-1 text-sm font-semibold text-text">
                {operatorVisibleText(endgame?.current_phase || governance?.endgame_current_phase || 'Makrophase fehlt')}
              </div>
            </div>
            <StatusChip
              label={endgame?.status || governance?.endgame_roadmap_status || 'UNKNOWN'}
              tone={planningQualityTone(endgame?.status || governance?.endgame_roadmap_status || 'WARN')}
            />
          </div>
          <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
            <ChipRow
              label="Roadmap Completion"
              labelValue={`${endgame?.completion_percent ?? governance?.endgame_roadmap_completion_percent ?? 0}%`}
              tone={(endgame?.safe_work_remaining ?? false) ? 'warning' : 'success'}
            />
            <ChipRow
              label="Foundation Completion"
              labelValue={`${endgame?.foundation_completion_percent ?? governance?.endgame_foundation_completion_percent ?? 0}%`}
              tone={(endgame?.foundation_completion_percent ?? governance?.endgame_foundation_completion_percent ?? 0) >= 100 ? 'success' : 'warning'}
            />
            <ChipRow
              label="Makro Completion"
              labelValue={`${endgame?.macro_completion_percent ?? governance?.endgame_macro_completion_percent ?? 0}%`}
              tone={(endgame?.macro_completion_percent ?? governance?.endgame_macro_completion_percent ?? 0) >= 100 ? 'success' : 'warning'}
            />
            <ChipRow
              label="Safe Next Blocks"
              labelValue={String(endgameSafeBlocks.length || governance?.endgame_safe_next_blocks || 0)}
              tone={(endgameSafeBlocks.length || governance?.endgame_safe_next_blocks || 0) > 0 ? 'warning' : 'success'}
            />
          </div>
          <div className="mt-3 rounded-lg border border-warning/35 bg-warning/10 p-3 text-xs leading-5 text-warning">
            {operatorVisibleText(endgame?.completion_note || 'Foundation-Grün ist nicht Endprodukt: LIONCOM Operator Cockpit v2, Produktvertikalen und Launch-/Revenue-Vorbereitung bleiben eigene Makroblöcke.')}
          </div>
          <div className="mt-3 grid gap-3 lg:grid-cols-2">
            <div className="rounded-lg border border-border/80 bg-surface/45 p-3">
              <div className="hud-label text-muted">Nächste sichere Großblöcke</div>
              <div className="mt-2 grid gap-2">
                {endgameSafeBlocks.slice(0, 3).map((block) => (
                  <div key={block.block_id || block.title} className="rounded-lg border border-border/70 bg-elevated/45 p-3">
                    <div className="flex min-w-0 items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="break-all font-mono text-[0.68rem] text-vega">{operatorVisibleText(block.block_id || 'safe-block')}</div>
                        <div className="mt-1 text-xs font-semibold text-text">{operatorVisibleText(block.title || 'Unbenannter Block')}</div>
                      </div>
                      <StatusChip label={block.priority || 'P?'} tone="warning" />
                    </div>
                    <div className="mt-2 text-xs leading-5 text-muted">{operatorVisibleText(block.next_safe_step || '')}</div>
                  </div>
                ))}
                {endgameSafeBlocks.length === 0 ? <div className="rounded-lg border border-border/70 bg-elevated/45 p-3 text-xs leading-5 text-muted">Keine sicheren Großblöcke geladen.</div> : null}
              </div>
            </div>
            <div className="rounded-lg border border-border/80 bg-surface/45 p-3">
              <div className="hud-label text-muted">Makro-Backlog</div>
              <div className="mt-2 grid gap-2">
                {macroBacklog.slice(0, 4).map((block) => (
                  <div key={block.block_id || block.title} className="rounded-lg border border-border/70 bg-elevated/45 p-3">
                    <div className="flex min-w-0 items-center justify-between gap-2">
                      <div className="truncate text-xs font-semibold text-text">{operatorVisibleText(block.title || block.block_id || 'Makroblock')}</div>
                      <StatusChip label={block.status || 'unknown'} tone={planningQualityTone(block.status || 'WARN')} />
                    </div>
                    <div className="mt-1 break-all font-mono text-[0.68rem] text-vega">{operatorVisibleText(block.block_id || '')}</div>
                  </div>
                ))}
                {macroBacklog.length === 0 ? <div className="rounded-lg border border-border/70 bg-elevated/45 p-3 text-xs leading-5 text-muted">Makro-Backlog fehlt im PIG Surface.</div> : null}
              </div>
            </div>
          </div>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {(endgame?.operator_gates ?? []).slice(0, 8).map((gate) => (
              <span key={`${gate.phase_id}-${gate.gate}`} className="rounded-lg border border-warning/35 bg-warning/10 px-2 py-1 font-mono text-[0.66rem] text-warning">
                {operatorVisibleText(gate.phase_id || 'phase')} · {operatorVisibleText(gate.gate || 'Gate')}
              </span>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-elevated/45 p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="hud-label text-muted">Vivi -&gt; Vega Inbox</div>
              <div className="mt-1 text-sm font-semibold text-text">{viviHandoff?.action_item_count ?? governance?.vivi_vega_handoff_action_items ?? 0} Reaktionskarten</div>
            </div>
            <StatusChip
              label={viviHandoff?.status || governance?.vivi_vega_handoff_inbox_status || 'UNKNOWN'}
              tone={(viviHandoff?.operator_gate_count ?? governance?.vivi_operator_gate_count ?? 0) > 0 ? 'critical' : planningQualityTone(viviHandoff?.status || governance?.vivi_vega_handoff_inbox_status || 'WARN')}
            />
          </div>
          <div className="mt-3 grid gap-2 sm:grid-cols-3">
            <ChipRow label="Vega Review" labelValue={String(viviHandoff?.needs_vega_review_count ?? governance?.vivi_needs_vega_review_count ?? 0)} tone={(viviHandoff?.needs_vega_review_count ?? governance?.vivi_needs_vega_review_count ?? 0) > 0 ? 'warning' : 'success'} />
            <ChipRow label="Verifier" labelValue={String(viviHandoff?.needs_verifier_count ?? governance?.vivi_needs_verifier_count ?? 0)} tone={(viviHandoff?.needs_verifier_count ?? governance?.vivi_needs_verifier_count ?? 0) > 0 ? 'warning' : 'success'} />
            <ChipRow label="Operator-Gate" labelValue={String(viviHandoff?.operator_gate_count ?? governance?.vivi_operator_gate_count ?? 0)} tone={(viviHandoff?.operator_gate_count ?? governance?.vivi_operator_gate_count ?? 0) > 0 ? 'critical' : 'success'} />
          </div>
          <div className="mt-3 grid gap-2">
            {(viviHandoff?.action_items ?? []).slice(0, 3).map((item) => (
              <div key={item.item_id || item.title} className="rounded-lg border border-border/80 bg-surface/45 p-3">
                <div className="flex min-w-0 items-center justify-between gap-2">
                  <div className="truncate text-xs font-semibold text-text">{operatorVisibleText(item.title || item.item_id)}</div>
                  <StatusChip label={item.classification || 'review'} tone={item.operator_gate_required ? 'critical' : planningQualityTone(item.classification || 'WARN')} />
                </div>
                <div className="mt-1 break-all font-mono text-[0.68rem] text-vega">{operatorVisibleText(item.command_ref || item.source_kind || 'no-ref')}</div>
                <div className="mt-1 text-xs leading-5 text-muted">{operatorVisibleText(item.next_safe_step || 'PIG Inbox prüfen.')}</div>
              </div>
            ))}
            {(viviHandoff?.action_items ?? []).length === 0 ? <div className="rounded-lg border border-border/80 bg-surface/45 p-3 text-xs leading-5 text-muted">Keine Vivi-Reaktionskarte geladen.</div> : null}
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-elevated/45 p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="hud-label text-muted">Quality OS Job-Schiene</div>
              <div className="mt-1 text-sm font-semibold text-text">{supervisor?.truth_status || governance?.vivi_supervisor_truth_status || 'UNKNOWN'}</div>
            </div>
            <StatusChip label={supervisor?.status || governance?.vivi_supervisor_status || 'UNKNOWN'} tone={planningQualityTone(supervisor?.status || governance?.vivi_supervisor_status || 'WARN')} />
          </div>
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            <ChipRow label="Fresh Data" labelValue={`${freshData?.action_item_count ?? governance?.fresh_data_action_items ?? 0} Aktion`} tone={(freshData?.operator_gate_count ?? governance?.fresh_data_operator_gates ?? 0) > 0 ? 'critical' : planningQualityTone(freshData?.status || governance?.fresh_data_intake_status || 'WARN')} />
            <ChipRow label="Job Cards" labelValue={`${jobQueue?.ready_count ?? governance?.vivi_job_cards_ready ?? 0} ready`} tone={planningQualityTone(jobQueue?.status || governance?.vivi_job_card_queue_status || 'WARN')} />
            <ChipRow label="Runner" labelValue={runner?.status || governance?.vivi_runner_status || 'UNKNOWN'} tone={planningQualityTone(runner?.status || governance?.vivi_runner_status || 'WARN')} />
            <ChipRow label="Supervisor" labelValue={supervisor?.status || governance?.vivi_supervisor_status || 'UNKNOWN'} tone={planningQualityTone(supervisor?.status || governance?.vivi_supervisor_status || 'WARN')} />
          </div>
          <div className="mt-3 rounded-lg border border-border/80 bg-surface/45 p-3">
            <div className="hud-label text-muted">Nächster sicherer Schritt</div>
            <div className="mt-1 text-xs leading-5 text-muted">
              {operatorVisibleText(supervisor?.next_safe_step || runner?.next_safe_step || freshData?.action_items?.[0]?.next_safe_step || planningQuality.next_safe_step)}
            </div>
          </div>
          <div className="mt-3 grid gap-2">
            {(freshData?.action_items ?? []).slice(0, 2).map((item) => (
              <div key={item.item_id || item.summary} className="rounded-lg border border-border/80 bg-surface/45 p-3">
                <div className="flex min-w-0 items-center justify-between gap-2">
                  <div className="truncate text-xs font-semibold text-text">{operatorVisibleText(item.project_id || item.artifact_kind || 'fresh-data')}</div>
                  <StatusChip label={item.classification || 'review'} tone={item.operator_gate_required ? 'critical' : planningQualityTone(item.classification || 'WARN')} />
                </div>
                <div className="mt-1 text-xs leading-5 text-muted">{operatorVisibleText(item.summary || item.next_safe_step || '')}</div>
              </div>
            ))}
            {(supervisor?.findings ?? []).slice(0, 2).map((finding) => (
              <div key={finding.code || finding.message} className="rounded-lg border border-warning/35 bg-warning/10 p-3">
                <div className="text-xs font-semibold text-warning">{finding.code || 'Supervisor-Fund'}</div>
                <div className="mt-1 text-xs leading-5 text-warning">{operatorVisibleText(finding.message || '')}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-elevated/45 p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="hud-label text-muted">Dirt / Übergabe / Verifier</div>
              <div className="mt-1 text-sm font-semibold text-text">
                {dirtScan?.verifier_pass_count ?? governance?.autonomy_dirt_verifier_pass_count ?? 0}/{dirtScan?.verifier_executed_count ?? governance?.autonomy_dirt_verifier_executed_count ?? 0} Verifier grün
              </div>
            </div>
            <StatusChip
              label={dirtScan?.status || governance?.autonomy_dirt_backlog_scan_status || 'UNKNOWN'}
              tone={(dirtScan?.verifier_fail_count ?? governance?.autonomy_dirt_verifier_fail_count ?? 0) > 0 ? 'critical' : planningQualityTone(dirtScan?.status || governance?.autonomy_dirt_backlog_scan_status || 'WARN')}
            />
          </div>
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            <ChipRow label="Dirty Projekte" labelValue={String(dirtScan?.dirty_project_count ?? governance?.autonomy_dirty_project_count ?? 0)} tone={(dirtScan?.dirty_project_count ?? governance?.autonomy_dirty_project_count ?? 0) > 0 ? 'warning' : 'success'} />
            <ChipRow label="Übergabe-Karten" labelValue={String(dirtScan?.handoff_card_count ?? governance?.autonomy_dirt_handoff_card_count ?? 0)} tone={(dirtScan?.handoff_card_count ?? governance?.autonomy_dirt_handoff_card_count ?? 0) > 0 ? 'info' : 'success'} />
            <ChipRow label="Verifier FAIL" labelValue={String(dirtScan?.verifier_fail_count ?? governance?.autonomy_dirt_verifier_fail_count ?? 0)} tone={(dirtScan?.verifier_fail_count ?? governance?.autonomy_dirt_verifier_fail_count ?? 0) > 0 ? 'critical' : 'success'} />
            <ChipRow label="Noch geplant" labelValue={String(dirtScan?.verifier_planned_count ?? governance?.autonomy_dirt_verifier_planned_count ?? 0)} tone={(dirtScan?.verifier_planned_count ?? governance?.autonomy_dirt_verifier_planned_count ?? 0) > 0 ? 'warning' : 'success'} />
            <ChipRow label="Lokale Review-Queue" labelValue={String(dirtScan?.handoff_safe_queue_count ?? 0)} tone={(dirtScan?.handoff_safe_queue_count ?? 0) > 0 ? 'warning' : 'success'} />
            <ChipRow label="Gate-Queue" labelValue={String(dirtScan?.handoff_operator_gate_queue_count ?? 0)} tone={(dirtScan?.handoff_operator_gate_queue_count ?? 0) > 0 ? 'critical' : 'success'} />
          </div>
          {dirtScan?.next_safe_review?.queue_id ? (
            <div className="mt-3 rounded-lg border border-warning/35 bg-warning/10 p-3">
              <div className="flex min-w-0 items-center justify-between gap-2">
                <div className="truncate text-xs font-semibold text-warning">Nächste Dirt-Entscheidung</div>
                <StatusChip label={dirtScan.next_safe_review.priority || 'P?'} tone="warning" />
              </div>
              <div className="mt-1 break-all font-mono text-[0.68rem] text-warning">{operatorVisibleText(dirtScan.next_safe_review.queue_id)}</div>
              <div className="mt-2 text-xs leading-5 text-warning">{operatorVisibleText(dirtScan.next_safe_review.safe_review_step || '')}</div>
              <div className="mt-2 text-xs leading-5 text-muted">{operatorVisibleText(dirtScan.next_safe_review.done_definition || '')}</div>
            </div>
          ) : null}
          <div className="mt-3 grid gap-2">
            {(dirtScan?.safe_work_queue ?? []).slice(0, 3).map((item) => (
              <div key={item.queue_id || item.card_id} className="rounded-lg border border-border/80 bg-surface/45 p-3">
                <div className="flex min-w-0 items-center justify-between gap-2">
                  <div className="truncate text-xs font-semibold text-text">{operatorVisibleText(item.queue_id || item.card_id || item.project_id || 'dirt-card')}</div>
                  <StatusChip label={`${item.count ?? 0} Dateien`} tone="info" />
                </div>
                <div className="mt-1 text-xs leading-5 text-muted">{operatorVisibleText(item.safe_review_step || item.decision_type || '')}</div>
              </div>
            ))}
            {(dirtScan?.safe_work_queue ?? []).length === 0
              ? (dirtScan?.handoff_cards ?? []).slice(0, 3).map((card) => (
                  <div key={card.card_id || card.ownership} className="rounded-lg border border-border/80 bg-surface/45 p-3">
                    <div className="flex min-w-0 items-center justify-between gap-2">
                      <div className="truncate text-xs font-semibold text-text">{operatorVisibleText(card.card_id || card.project_id || 'dirt-card')}</div>
                      <StatusChip label={`${card.count ?? 0} Dateien`} tone={card.operator_gate_required ? 'critical' : 'info'} />
                    </div>
                    <div className="mt-1 text-xs leading-5 text-muted">{operatorVisibleText(card.recommended_action || '')}</div>
                  </div>
                ))
              : null}
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-elevated/45 p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="hud-label text-muted">Operator-Go Paket</div>
              <div className="mt-1 text-sm font-semibold text-text">{commitPackage?.package_id || 'Commit/Cleanup wartet auf PIG'}</div>
            </div>
            <StatusChip
              label={commitPackage?.status || governance?.commit_cleanup_go_package_status || 'UNKNOWN'}
              tone={(commitPackage?.summary?.operator_gate_queue_count ?? 0) > 0 ? 'critical' : planningQualityTone(commitPackage?.status || governance?.commit_cleanup_go_package_status || 'WARN')}
            />
          </div>
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            <ChipRow label="Entscheidungen" labelValue={String(commitPackage?.summary?.decision_card_count ?? governance?.commit_cleanup_go_package_decisions ?? 0)} tone="info" />
            <ChipRow label="Dirty Projekte" labelValue={String(commitPackage?.summary?.dirty_project_count ?? 0)} tone={(commitPackage?.summary?.dirty_project_count ?? 0) > 0 ? 'warning' : 'success'} />
            <ChipRow label="Review fertig" labelValue={String(commitPackage?.summary?.reviewed_queue_count ?? 0)} tone="info" />
            <ChipRow label="Operator-Gates" labelValue={String(commitPackage?.summary?.operator_gate_queue_count ?? 0)} tone={(commitPackage?.summary?.operator_gate_queue_count ?? 0) > 0 ? 'critical' : 'success'} />
            <ChipRow label="Runtime-Aktion" labelValue={String(commitPackage?.runtime_action_executed ?? governance?.commit_cleanup_go_runtime_action_executed ?? 'unknown')} tone={commitPackage?.runtime_action_executed ? 'critical' : 'success'} />
            <ChipRow label="Vivi Worker" labelValue={viviWorker?.status || governance?.vivi_worker_status || 'UNKNOWN'} tone={planningQualityTone(viviWorker?.status || governance?.vivi_worker_status || 'WARN')} />
          </div>
          <div className="mt-3 rounded-lg border border-border/80 bg-surface/45 p-3">
            <div className="hud-label text-muted">Nächster sicherer Schritt</div>
            <div className="mt-1 text-xs leading-5 text-muted">{operatorVisibleText(commitPackage?.next_safe_step || 'Operator-Go-Paket fehlt noch.')}</div>
          </div>
          <div className="mt-3 grid gap-2">
            {(commitPackage?.decision_cards ?? []).slice(0, 3).map((decision) => (
              <div key={decision.decision_id || decision.project_id} className="rounded-lg border border-border/80 bg-surface/45 p-3">
                <div className="flex min-w-0 items-center justify-between gap-2">
                  <div className="truncate text-xs font-semibold text-text">{operatorVisibleText(decision.decision_id || decision.project_id || 'decision')}</div>
                  <StatusChip label={`${decision.count ?? 0} Dateien`} tone={decision.operator_gate_required ? 'critical' : 'info'} />
                </div>
                <div className="mt-1 text-xs leading-5 text-muted">{operatorVisibleText(decision.recommended_operator_decision || decision.next_safe_step || '')}</div>
              </div>
            ))}
            {(commitPackage?.decision_cards ?? []).length === 0 ? <div className="rounded-lg border border-border/80 bg-surface/45 p-3 text-xs leading-5 text-muted">Noch kein Commit/Cleanup-Go-Paket geladen.</div> : null}
          </div>
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            <ChipRow label="Worker Queue" labelValue={`${viviWorkerQueue?.ready_count ?? governance?.vivi_worker_ready_count ?? 0} ready`} tone={(viviWorkerQueue?.ready_count ?? governance?.vivi_worker_ready_count ?? 0) > 0 ? 'warning' : 'success'} />
            <ChipRow label="Worker Supervisor" labelValue={viviWorkerSupervisor?.status || governance?.vivi_worker_supervisor_status || 'UNKNOWN'} tone={planningQualityTone(viviWorkerSupervisor?.status || governance?.vivi_worker_supervisor_status || 'WARN')} />
          </div>
          <div className="mt-3 text-xs leading-5 text-muted">
            {operatorVisibleText(viviWorkerSupervisor?.next_safe_step || viviWorker?.next_safe_step || 'Vivi darf hier nur lokale PIG-Artefakte aktualisieren.')}
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-elevated/45 p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="hud-label text-muted">OpenJarvis Capability-Lab Zustand</div>
              <div className="mt-1 text-sm font-semibold text-text">Planning Quality / PIG Operator Surface</div>
            </div>
            <StatusChip
              label={openjarvisLab?.status || governance?.openjarvis_capability_lab_status || 'UNKNOWN'}
              tone={planningQualityTone(openjarvisLab?.status || governance?.openjarvis_capability_lab_status || 'WARN')}
            />
          </div>
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            <ChipRow
              label="Retrieval Benchmark"
              labelValue={`${openjarvisLab?.retrieval_pass_count ?? governance?.openjarvis_retrieval_pass_count ?? 0}/${openjarvisLab?.retrieval_question_count ?? governance?.openjarvis_retrieval_question_count ?? 0}`}
              tone={planningQualityTone(openjarvisLab?.retrieval_status || governance?.openjarvis_retrieval_status || 'WARN')}
            />
            <ChipRow
              label="Code-QA Shadow"
              labelValue={openjarvisLab?.code_qa_status || governance?.openjarvis_code_qa_status || 'UNKNOWN'}
              tone={planningQualityTone(openjarvisLab?.code_qa_status || governance?.openjarvis_code_qa_status || 'WARN')}
            />
            <ChipRow
              label="Preflight"
              labelValue={`${openjarvisLab?.preflight_status || 'UNKNOWN'} · ${openjarvisLab?.preflight_blocker_count ?? 0} Blocker`}
              tone={(openjarvisLab?.preflight_blocker_count ?? 0) > 0 ? 'critical' : planningQualityTone(openjarvisLab?.preflight_status || 'WARN')}
            />
            <ChipRow
              label="Runtime-Aktion"
              labelValue={String(openjarvisLab?.runtime_action_executed ?? governance?.openjarvis_runtime_action_executed ?? false)}
              tone={(openjarvisLab?.runtime_action_executed ?? governance?.openjarvis_runtime_action_executed) ? 'critical' : 'success'}
            />
            <ChipRow
              label="Source of Truth"
              labelValue={String(openjarvisLab?.source_of_truth ?? false)}
              tone={openjarvisLab?.source_of_truth ? 'critical' : 'success'}
            />
            <InfoRow label="Dokumente" value={`${openjarvisLab?.source_document_count ?? governance?.openjarvis_source_documents ?? 0} sichere Quellen`} />
          </div>
          <div className="mt-3 rounded-lg border border-border/80 bg-surface/45 p-3">
            <div className="hud-label text-muted">Nächster sicherer Schritt</div>
            <div className="mt-1 text-xs leading-5 text-muted">
              {operatorVisibleText(openjarvisLab?.next_safe_step || 'OpenJarvis Capability-Lab bleibt Shadow-Read-Only, bis Retrieval besser als PIG/Obsidian belegt ist.')}
            </div>
          </div>
          <div className="mt-3 break-all font-mono text-[0.68rem] text-vega">{operatorVisibleText(openjarvisLab?.path || 'outputs/agent_os_readiness/OPENJARVIS_CAPABILITY_LAB.json')}</div>
        </div>

        <div className="rounded-2xl border border-border bg-elevated/45 p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="hud-label text-muted">OpenJarvis Capability Arena</div>
              <div className="mt-1 text-sm font-semibold text-text">Shadow Tournament gegen PIG / Obsidian</div>
            </div>
            <StatusChip
              label={openjarvisArena?.status || governance?.openjarvis_capability_arena_status || 'UNKNOWN'}
              tone={planningQualityTone(openjarvisArena?.status || governance?.openjarvis_capability_arena_status || 'WARN')}
            />
          </div>
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            <ChipRow
              label="Aufgaben"
              labelValue={String(openjarvisArena?.task_count ?? governance?.openjarvis_arena_task_count ?? 0)}
              tone={(openjarvisArena?.task_count ?? governance?.openjarvis_arena_task_count ?? 0) >= 30 ? 'success' : 'warning'}
            />
            <ChipRow
              label="Shadow PASS"
              labelValue={`${openjarvisArena?.shadow_pass_count ?? governance?.openjarvis_arena_shadow_pass_count ?? 0}/${openjarvisArena?.task_count ?? governance?.openjarvis_arena_task_count ?? 0}`}
              tone={(openjarvisArena?.shadow_fail_count ?? governance?.openjarvis_arena_shadow_fail_count ?? 0) === 0 ? 'success' : 'critical'}
            />
            <ChipRow
              label="Shadow Wins"
              labelValue={String(openjarvisArena?.shadow_win_count ?? governance?.openjarvis_arena_shadow_wins ?? 0)}
              tone={(openjarvisArena?.shadow_win_count ?? governance?.openjarvis_arena_shadow_wins ?? 0) > 0 ? 'success' : 'warning'}
            />
            <ChipRow
              label="Baseline Wins"
              labelValue={String(openjarvisArena?.baseline_win_count ?? governance?.openjarvis_arena_baseline_wins ?? 0)}
              tone={(openjarvisArena?.baseline_win_count ?? governance?.openjarvis_arena_baseline_wins ?? 0) === 0 ? 'success' : 'warning'}
            />
            <InfoRow label="Ø Shadow" value={String(openjarvisArena?.shadow_average_score ?? 'unknown')} />
            <InfoRow label="Ø Baseline" value={String(openjarvisArena?.baseline_average_score ?? 'unknown')} />
            <ChipRow
              label="Runtime-Aktion"
              labelValue={String(openjarvisArena?.runtime_action_executed ?? false)}
              tone={openjarvisArena?.runtime_action_executed ? 'critical' : 'success'}
            />
            <InfoRow label="Ties" value={String(openjarvisArena?.tie_count ?? governance?.openjarvis_arena_ties ?? 0)} />
          </div>
          <div className="mt-3 rounded-lg border border-border/80 bg-surface/45 p-3">
            <div className="hud-label text-muted">Arena-Entscheidung</div>
            <div className="mt-1 text-xs leading-5 text-muted">
              {operatorVisibleText(openjarvisArena?.adoption_recommendation || 'Arena fehlt noch; keine Runtime-Adoption.')}
            </div>
          </div>
          <div className="mt-3 break-all font-mono text-[0.68rem] text-vega">{operatorVisibleText(openjarvisArena?.path || 'outputs/agent_os_readiness/OPENJARVIS_CAPABILITY_ARENA_SCOREBOARD.json')}</div>
        </div>

        <div className="rounded-2xl border border-border bg-elevated/45 p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="hud-label text-muted">Operator Actions</div>
              <div className="mt-1 text-sm font-semibold text-text">{operatorActions.length} lokale Entscheidungspunkte</div>
            </div>
            <StatusChip label={planningQuality.control_capabilities?.approval_actions ? 'ready' : 'missing'} tone={planningQuality.control_capabilities?.approval_actions ? 'success' : 'warning'} />
          </div>
          <div className="mt-3 grid gap-2">
            {operatorActions.slice(0, 4).map((action) => (
              <div key={action.action_id || action.label} className="rounded-lg border border-border/80 bg-surface/45 p-3">
                <div className="flex min-w-0 items-center justify-between gap-2">
                  <div className="truncate text-xs font-semibold text-text">{action.label || action.action_id}</div>
                  <StatusChip label={action.status || 'unknown'} tone={planningQualityTone(action.status || 'WARN')} />
                </div>
                <div className="mt-1 text-[0.68rem] leading-4 text-muted">{action.operator_gate_required ? 'Operator-Go erforderlich' : action.runtime_effect || 'local'}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-elevated/45 p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="hud-label text-muted">Pause / Resume / Retry</div>
              <div className="mt-1 text-sm font-semibold text-text">{runControls.length} Control States</div>
            </div>
            <StatusChip label={planningQuality.control_capabilities?.pause_resume_retry ? 'ready' : 'missing'} tone={planningQuality.control_capabilities?.pause_resume_retry ? 'success' : 'warning'} />
          </div>
          <div className="mt-3 grid gap-2">
            {runControls.slice(0, 3).map((control) => (
              <InfoRow key={control.control || control.status} label={control.control || 'control'} value={control.status || 'unknown'} />
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-elevated/45 p-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="hud-label text-muted">Fresh-Session-Übergabe</div>
              <div className="mt-1 text-sm font-semibold text-text">{operatorVisibleText(handoff?.latest_run || latestRun?.run_id || 'missing')}</div>
            </div>
            <StatusChip label={handoff?.status || 'missing'} tone={planningQualityTone(handoff?.status || 'WARN')} />
          </div>
          <div className="mt-3 text-xs leading-5 text-muted">{operatorVisibleText(handoff?.next_safe_step || 'Keine Übergabe geladen.')}</div>
        </div>
      </div>

      <div className="grid gap-3 xl:grid-cols-2">
        {planningQuality.job_cards.slice(0, 4).map((card) => (
          <div key={card.job_card_id || card.auftrag} className="rounded-2xl border border-border bg-elevated/45 p-4">
            <div className="flex min-w-0 items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="break-all font-mono text-[0.68rem] text-vega">{operatorVisibleText(card.job_card_id)}</div>
                <div className="mt-1 text-sm font-semibold text-text">{operatorVisibleText(card.auftrag)}</div>
              </div>
              <StatusChip label={card.status || 'unknown'} tone={planningQualityTone(card.status || 'WARN')} />
            </div>
            <div className="mt-3 text-xs leading-5 text-muted">{operatorVisibleText(card.naechster_sicherer_schritt)}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function statusLabel(status: PortfolioRepositoryStatus['ciStatus'] | PortfolioRepositoryStatus['e2eStatus']): string {
  if (status === 'green') return 'grün';
  if (status === 'yellow') return 'gelb';
  if (status === 'red') return 'rot';
  return 'n/a';
}

function statusTone(status: PortfolioRepositoryStatus['ciStatus'] | PortfolioRepositoryStatus['e2eStatus']): Severity | 'neutral' {
  if (status === 'green') return 'success';
  if (status === 'yellow') return 'warning';
  if (status === 'red') return 'critical';
  return 'neutral';
}

function planningQualityTone(status: string): Severity {
  const normalized = status.toLowerCase();
  if (normalized.includes('pass') || normalized.includes('completed') || normalized.includes('verified')) return 'success';
  if (normalized.includes('fail') || normalized.includes('blocked')) return 'critical';
  if (normalized.includes('warn') || normalized.includes('waiting') || normalized.includes('need')) return 'warning';
  return 'info';
}

function riskLabel(risk: PortfolioRepositoryStatus['risk']): string {
  if (risk === 'green') return 'grün';
  if (risk === 'yellow') return 'gelb';
  return 'rot';
}

function riskTone(risk: PortfolioRepositoryStatus['risk']): Severity {
  if (risk === 'green') return 'success';
  if (risk === 'yellow') return 'warning';
  return 'critical';
}

function securityLabel(status: PortfolioRepositoryStatus['dependabotStatus']): string {
  if (status === 'active') return 'aktiv';
  return 'n/a';
}

function branchProtectionLabel(status: PortfolioRepositoryStatus['branchProtectionStatus']): string {
  if (status === 'blocked_plan_or_public_required') return 'Plan/API blockiert';
  return 'n/a';
}

function secretScanningLabel(status: PortfolioRepositoryStatus['secretScanningStatus']): string {
  if (status === 'unavailable_private_repo') return 'nicht verfügbar';
  return 'n/a';
}

function publicGateLabel(gate: PortfolioRepositoryStatus['publicGate']): string {
  if (gate === 'operator_gated') return 'Freigabe bleibt beim Operator.';
  if (gate === 'blocked') return 'Freigabe blockiert.';
  return 'nicht anwendbar';
}

function truthHierarchyLabel(item: string): string {
  const labels: Record<string, string> = {
    operator_go_or_hold: 'Operator-Go oder Operator-Hold',
    github_ci_after_push: 'GitHub/CI nach Push',
    local_verifiers_and_domain_gates: 'Lokale Verifier und Domain-Gates',
    lioncom_control_tower: 'LIONCOM Control Tower',
    vega0_canonical_integration: 'Vega-0-Integration und Backbone-Memory',
    project_and_role_registry_docs: 'Projekt- und Role-Registry-Dokumentation',
    handoff_chat_queue_runtime_files: 'Übergabe-, Chat-, Queue- und Runtime-Dateien',
  };
  return labels[item] ?? item;
}

function handoffRuleLabel(rule: string): string {
  if (/sole source of truth/i.test(rule)) {
    return 'Übergaben, Chats, Queues und Runtime-Dateien sind nie alleinige Wahrheit.';
  }
  return rule;
}

function operatorVisibleText(value?: string | null): string {
  if (!value) return '';
  return String(value)
    .replace(/\bFresh Session Handoff\b/gi, 'Fresh-Session-Übergabe')
    .replace(/\bhandoff\b/g, 'Übergabe')
    .replace(/\bHandoff\b/g, 'Übergabe');
}

function metricStatusLabel(status: PortfolioStreamMetric['status']): string {
  if (status === 'active') return 'aktiv';
  if (status === 'watching') return 'beobachtet';
  if (status === 'placeholder') return 'Platzhalter';
  return 'blockiert';
}

function metricCardTone(streams: PortfolioStreamMetric[]): Severity | 'neutral' {
  if (streams.some((stream) => stream.health === 'critical')) return 'critical';
  if (streams.some((stream) => stream.health === 'warning')) return 'warning';
  if (streams.some((stream) => stream.health === 'success')) return 'success';
  if (streams.some((stream) => stream.health === 'info')) return 'info';
  return 'neutral';
}

function metricCardLabel(tone: Severity | 'neutral'): string {
  if (tone === 'success') return 'stabil';
  if (tone === 'warning') return 'watching';
  if (tone === 'critical') return 'blockiert';
  if (tone === 'info') return 'info';
  return 'offen';
}

function metricIconClass(tone: Severity | 'neutral'): string {
  if (tone === 'success') return 'border-vivi/40 bg-vivi-soft text-vivi';
  if (tone === 'warning') return 'border-warning/40 bg-warning/10 text-warning';
  if (tone === 'critical') return 'border-danger/45 bg-danger/10 text-danger';
  return 'border-vega/40 bg-vega-soft text-vega';
}

function metricTextClass(tone: Severity): string {
  if (tone === 'success') return 'text-vivi';
  if (tone === 'warning') return 'text-warning';
  if (tone === 'critical') return 'text-danger';
  return 'text-vega';
}

function reviewStatusLabel(status: PortfolioReviewCalendarItem['status']): string {
  if (status === 'waiting_for_data') return 'wartet auf Daten';
  if (status === 'maintenance_due') return 'maintenance';
  if (status === 'blocked') return 'blockiert';
  return 'terminiert';
}

function reviewStatusTone(status: PortfolioReviewCalendarItem['status']): Severity {
  if (status === 'waiting_for_data') return 'warning';
  if (status === 'maintenance_due') return 'info';
  if (status === 'blocked') return 'critical';
  return 'success';
}

function reviewGroupClass(group: PortfolioReviewCalendarItem['streamGroup']): string {
  if (group === 'materialbedarf') return 'border-vivi/40 bg-vivi-soft text-vivi';
  if (group === 'elterngeld') return 'border-vega/40 bg-vega-soft text-vega';
  if (group === 'membership') return 'border-vivi/40 bg-vivi-soft text-vivi';
  if (group === 'room16') return 'border-warning/40 bg-warning/10 text-warning';
  if (group === 'deterministic') return 'border-danger/45 bg-danger/10 text-danger';
  if (group === 'microtool') return 'border-vivi/40 bg-vivi-soft text-vivi';
  return 'border-border bg-cpbg text-muted';
}

function formatReviewDate(value: string): string {
  const date = new Date(`${value}T12:00:00Z`);
  return new Intl.DateTimeFormat('de-DE', { dateStyle: 'medium', timeZone: 'UTC' }).format(date);
}

function CalendarInfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-border bg-cpbg/30 p-3">
      <div className="hud-label text-muted">{label}</div>
      <div className="mt-1 break-words text-xs leading-5 text-text">{value}</div>
    </div>
  );
}

function CalendarGateRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-border bg-cpbg/30 p-3">
      <div className="hud-label text-muted">{label}</div>
      <div className="mt-1 text-xs leading-5 text-text">{value}</div>
    </div>
  );
}

function MetricCardIcon({ id }: { id: PortfolioMetricCardId }) {
  if (id === 'utility-revenue-funnel') return <BarChart3 className="size-5" />;
  if (id === 'trust-rule-coverage') return <ShieldCheck className="size-5" />;
  if (id === 'membership-readiness') return <ClipboardCheck className="size-5" />;
  if (id === 'review-queue') return <ClipboardCheck className="size-5" />;
  if (id === 'outcome-horizons') return <Hourglass className="size-5" />;
  if (id === 'opportunity-backlog') return <ListChecks className="size-5" />;
  return <GitBranch className="size-5" />;
}
