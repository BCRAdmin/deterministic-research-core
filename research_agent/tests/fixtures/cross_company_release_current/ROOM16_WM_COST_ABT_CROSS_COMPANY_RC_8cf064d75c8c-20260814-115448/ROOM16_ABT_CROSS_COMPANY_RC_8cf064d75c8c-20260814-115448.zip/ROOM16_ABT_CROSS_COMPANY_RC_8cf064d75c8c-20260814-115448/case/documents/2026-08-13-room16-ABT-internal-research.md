# ABT Research Report
## Instrument Identity
| Identity field | Verified value |
| --- | --- |
| Legal company name | ABBOTT LABORATORIES |
| Ticker | ABT |
| Listing venue | NYSE |
| Jurisdiction | US / incorporation Illinois (IL) |
| SEC CIK | 0000001800 |
| Reporting / price currency | USD |
| Analysis cutoff | 2026-08-13 |
| Price date | 2026-08-13 |
| ISIN | not available |
| WKN | not available |

## Executive Summary
ABT enters the report at a frozen close of $111.27 with a Provisional — Hold stance. The available evidence anchors are revenue TTM of $46.59B, FCF TTM of $7.82B, EV/Sales of 4.71x; the technical evidence indicates unscored raw moving-average observations; no bullish or bearish technical conclusion is activated because corporate-action adjustment is not confirmed. The standardized DCF is an uncalibrated illustration outside the rating logic. The action language should stay consistent with the Provisional — Hold stance. <!-- room16-lineage claim=ABT_CLAIM_001 evidence=ABT_CSV_PRICE_CLOSE_2026-08-13,ABT_DETERMINISTIC_CLOSE_2026-08-13,ABT_DETERMINISTIC_REVENUE_TTM_2026-08-13,ABT_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13,ABT_DETERMINISTIC_EV_TO_SALES_2026-08-13 -->

The resulting stance is Provisional — Hold: the report weighs current fundamentals against valuation and cash-flow conversion. Technical inputs are unscored raw observations. They do not enter the rating or timing until corporate-action adjustment of the price series is confirmed.

## Investment Thesis
ABT's central investment debate is whether revenue scale of $46.59B can translate into durable cash generation; positive FCF of $7.82B provides measured cash-conversion support. The Provisional — Hold stance combines a mixed fundamental picture: positive FCF alongside weaker current-period profit comparisons with illustrative-only valuation evidence. Technical inputs are excluded from rating and timing because the price-series adjustment is unconfirmed.

**Issuer-specific proof test.**
**Capital allocation:** Reported evidence: Issuer-filed business context: On June 12, 2026, the board of directors of Abbott declared the company's quarterly dividend of $0.63 per share; This is the source-bound operating test for the thesis. <!-- room16-lineage claim=ABT_CLAIM_033 evidence=ABT_NEWS_2026-07-16_47_KPI_01 -->
**Transaction financing:** Reported evidence: Issuer-filed business context: On March 23, 2026, Abbott completed the acquisition of Exact Sciences for approximately $20.6 billion; This is the source-bound operating test for the thesis. <!-- room16-lineage claim=ABT_CLAIM_016 evidence=ABT_NEWS_2026-07-28_14_KPI_01,ABT_NEWS_2026-07-28_14_KPI_02,ABT_NEWS_2026-07-28_14_KPI_03,ABT_NEWS_2026-07-28_14_KPI_04 -->
The thesis weakens if these source-bound drivers stop persisting or no longer translate into cash conversion.

Issuer-filed business context: Abbott’s principal business is the discovery, development, manufacture, and sale of a broad and diversified line of healthcare products. <!-- room16-lineage claim=ABT_CLAIM_006 evidence=ABT_SEC_BUSINESS_000162828026010185_01 -->

Issuer-filed business context: Abbott has four reportable segments: Established Pharmaceutical Products, Diagnostic Products, Nutritional Products, and Medical Devices. <!-- room16-lineage claim=ABT_CLAIM_007 evidence=ABT_SEC_BUSINESS_000162828026010185_02 -->

## Current Period KPIs
ABT's latest reported period FY2026_Q2 includes revenue of $12.59B, operating income of $1.69B and net income of $928.0M. Against the matching prior-year quarter, revenue increased by 13.0%, operating income declined by 17.5% and net income declined by 47.8%. These are arithmetic year-over-year comparisons, not causal conclusions. One year-over-year comparison does not establish a durable multi-period trend. Use the latest period as current context, not as standalone evidence for an upgrade or downgrade. <!-- room16-lineage claim=ABT_CLAIM_002 evidence=ABT_SEC_revenue_FY2026_Q2_2026-04-01_2026-06-30_us-gaap_RevenueFromContractWithCustomerExcludingAssessedTax_0001628280-26-050134,ABT_SEC_operating_income_FY2026_Q2_2026-04-01_2026-06-30_us-gaap_OperatingIncomeLoss_0001628280-26-050134,ABT_SEC_net_income_FY2026_Q2_2026-04-01_2026-06-30_us-gaap_NetIncomeLoss_0001628280-26-050134,ABT_DETERMINISTIC_CURRENT_PERIOD_REVENUE_GROWTH_YOY_2026-08-13,ABT_DETERMINISTIC_CURRENT_PERIOD_OPERATING_INCOME_GROWTH_YOY_2026-08-13,ABT_DETERMINISTIC_CURRENT_PERIOD_NET_INCOME_GROWTH_YOY_2026-08-13 -->

For the latest reported period (year to date), ABT generated $3.80B of operating cash flow and reported $896.0M of capital expenditure. Year-to-date cash flow can be seasonal and is not the same measurement window as TTM free cash flow. Keep current cash generation visible while preserving the separate TTM valuation denominator. <!-- room16-lineage claim=ABT_CLAIM_003 evidence=ABT_SEC_operating_cash_flow_FY2026_Q2_2026-01-01_2026-06-30_us-gaap_NetCashProvidedByUsedInOperatingActivities_0001628280-26-050134,ABT_SEC_capex_FY2026_Q2_2026-01-01_2026-06-30_us-gaap_PaymentsToAcquirePropertyPlantAndEquipment_0001628280-26-050134 -->

## Operating Drivers & Capital Allocation
- **Capital allocation:** Issuer-filed business context: On June 12, 2026, the board of directors of Abbott declared the company's quarterly dividend of $0.63 per share. Abbott's cash dividend is payable Aug. 17, 2026, to shareholders of record at the close of business on July 15, 2026. <!-- room16-lineage claim=ABT_CLAIM_033 evidence=ABT_NEWS_2026-07-16_47_KPI_01 -->
- **Reported segment growth:** Issuer-filed business context: Segment Reported Sales Growth: 3M ended 2026-06-30 · total_company: 13.0%; 3M ended 2026-06-30 · nutrition: -3.1%; 3M ended 2026-06-30 · diagnostics: 42.3%; 3M ended 2026-06-30 · established_pharmaceuticals: 8.4%; 3M ended 2026-06-30 · medical_devices: 9.0%. <!-- room16-lineage claim=ABT_CLAIM_029 evidence=ABT_NEWS_2026-07-16_43_KPI_01,ABT_NEWS_2026-07-16_43_KPI_02,ABT_NEWS_2026-07-16_43_KPI_03,ABT_NEWS_2026-07-16_43_KPI_04,ABT_NEWS_2026-07-16_43_KPI_05 -->
- **Comparable segment growth:** Issuer-filed business context: Comparable Sales Growth: 3M ended 2026-06-30 · total_company: 4.8%; 3M ended 2026-06-30 · nutrition: -3.6%; 3M ended 2026-06-30 · diagnostics: 2.9%; 3M ended 2026-06-30 · established_pharmaceuticals: 8.7%; 3M ended 2026-06-30 · medical_devices: 8.4%. <!-- room16-lineage claim=ABT_CLAIM_030 evidence=ABT_NEWS_2026-07-16_44_KPI_01,ABT_NEWS_2026-07-16_44_KPI_02,ABT_NEWS_2026-07-16_44_KPI_03,ABT_NEWS_2026-07-16_44_KPI_04,ABT_NEWS_2026-07-16_44_KPI_05 -->
- **Transaction financing:** Issuer-filed business context: On March 23, 2026, Abbott completed the acquisition of Exact Sciences for approximately $20.6 billion. The acquisition was funded primarily through the issuance of $20.0 billion of long-term debt in March 2026, with the remainder funded by cash on hand. Under the terms of the agreement, Abbott paid $105 per common share in cash. As part of the acquisition, Abbott assumed approximately $2.8 billion of Exact Sciences’ debt, nearly all of which was repaid as of June 30, 2026. The acquisition of Exact Sciences has established Abbott's position in the cancer diagnostics market and expands its portfolio to include products such as Cologuard®, Oncotype DX®, and Cancerguard®. <!-- room16-lineage claim=ABT_CLAIM_016 evidence=ABT_NEWS_2026-07-28_14_KPI_01,ABT_NEWS_2026-07-28_14_KPI_02,ABT_NEWS_2026-07-28_14_KPI_03,ABT_NEWS_2026-07-28_14_KPI_04 -->

## Fundamental Analysis
FCF TTM is $7.82B. SBC equals 9.2% of that FCF, an arithmetic comparison that qualifies rather than invalidates the reported cash generation. FCF may be company-defined or period-sensitive and can require reconciliation review. Treat FCF as a rating input only after its source, period and formula have passed validation. <!-- room16-lineage claim=ABT_CLAIM_045 evidence=ABT_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13,ABT_DETERMINISTIC_SBC_TO_FCF_2026-08-13 -->

TTM shareholder distributions are $6.09B; FCF exceeds shareholder distributions; the signed distributions-minus-FCF comparison is -$1.73B. This is an arithmetic comparison and does not identify a funding source. This period surplus does not prove that every distribution was funded from FCF or that the relationship is durable. Capital-return sustainability should be discussed without inventing a financing bridge. <!-- room16-lineage claim=ABT_CLAIM_046 evidence=ABT_DETERMINISTIC_SHAREHOLDER_DISTRIBUTIONS_TTM_2026-08-13,ABT_DETERMINISTIC_SHAREHOLDER_DISTRIBUTIONS_MINUS_FCF_TTM_2026-08-13 -->

SBC/Revenue is 1.5%. The diluted weighted-average share count decreased by 0.4% against the matching prior-year period. This measures the net share-base change; it does not attribute the move solely to SBC or repurchases. Without a sector or lifecycle benchmark, this is a dilution input rather than evidence that SBC is high or low. Sector and lifecycle matter, but persistent dilution can still reduce equity quality. Treat SBC as a risk modifier rather than an automatic rating override. <!-- room16-lineage claim=ABT_CLAIM_047 evidence=ABT_DETERMINISTIC_SBC_TO_REVENUE_2026-08-13,ABT_DETERMINISTIC_DILUTED_SHARE_COUNT_YOY_2026-08-13 -->

The balance-sheet position includes net debt of $27.00B and total debt of $32.61B. This is a leverage input, not evidence of financial flexibility. Interpret liquidity or leverage only from the signed net position and its underlying debt evidence. <!-- room16-lineage claim=ABT_CLAIM_048 evidence=ABT_DETERMINISTIC_NET_CASH_2026-08-13,ABT_DETERMINISTIC_TOTAL_DEBT_2026-08-13 -->

## Free Cash Flow Definitions
| Definition | Measurement window | Value | Use in this report |
|---|---|---:|---|
| Room16 normalized FCF (operating cash flow minus capital expenditure) | 2025-07-01 to 2026-06-30 | $7.82B | Valuation denominator and normalized cash-conversion analysis |
Room16 and issuer-defined FCF are separate measures. Differences can reflect measurement windows, capital-expenditure definitions, sustainability investments or other issuer adjustments.
<!-- room16-table-lineage id=FCF_DEFINITION_RECONCILIATION evidence=ABT_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13 -->

## Capital Allocation, Transactions & Contingencies
From 2026-01-01 through 2026-06-30, shareholder distributions were $3.42B and period-matched acquisition cash was $19.96B. Against Room16 normalized same-period FCF of $2.91B, these outflows leave -$20.48B. This is a period-matched capital-allocation bridge, not a TTM claim. One interim period can be seasonal and does not establish a durable payout policy. Track repurchases, dividends and FCF on the same reporting window before judging funding pressure. <!-- room16-lineage claim=ABT_CLAIM_005 evidence=ABT_DETERMINISTIC_SHAREHOLDER_DISTRIBUTIONS_CURRENT_PERIOD_2026-08-13,ABT_DETERMINISTIC_FREE_CASH_FLOW_CURRENT_PERIOD_2026-08-13,ABT_DETERMINISTIC_BUYBACKS_CURRENT_PERIOD_2026-08-13,ABT_DETERMINISTIC_DIVIDENDS_PAID_CURRENT_PERIOD_2026-08-13,ABT_CAPITAL_ALLOCATION_ACQUISITION_CASH_2026-06-30,ABT_CAPITAL_ALLOCATION_ROOM16_RESIDUAL_2026-06-30 -->

The goodwill is primarily attributable to future growth opportunities, assembled workforce, potential future technologies, and other intangible assets that do not qualify for separate recognition, as well as expected synergies from combining operations. The acquired net tangible assets consist primarily of property and equipment, trade accounts receivable, trade accounts payable, other current liabilities, and other non-current liabilities. If the acquisition had occurred as of the beginning of 2025, unaudited pro forma consolidated net sales would have been approximately $11.9 billion and $23.0 billion for the three and six months ended June 30, 2025, respectively. Unaudited pro forma earnings before taxes for the three months ended June 30, 2025, would have been approximately $1.6 billion, reflecting interest expense of approximately $0.2 billion and amortization expense related to acquired intangible assets of approximately $0.3 billion. Unaudited pro forma earnings before taxes for the six months ended June 30, 2025, would have been approximately $2.3 billion, reflecting transaction-related costs of approximately $0.5 billion, interest expense of approximately $0.5 billion, and amortization expense related to acquired intangible assets of approximately $0.5 billion. Unaudited pro forma consolidated net sales would have been approximately $12.6 billion and $24.5 billion for the three and six months ended June 30, 2026, respectively. Unaudited pro forma earnings before taxes would have been approximately $1.6 billion and $2.9 billion for the three and six months ended June 30, 2026, respectively, after giving effect to interest expense of approximately $0.2 billion and amortization expense related to acquired intangible assets of approximately $0.2 billion, and excluding transaction-related expenses of $0.5 billion that were directly attributable to the acquisition. The unaudited pro forma information is not necessarily indicative of the consolidated results of operations that would have been realized had the Exact Sciences acquisition been completed as of the beginning of 2025, nor is it intended to be indicative of future results of operations of the combined entity. <!-- room16-lineage claim=ABT_CLAIM_008 evidence=ABT_NEWS_2026-07-28_04_KPI_01,ABT_NEWS_2026-07-28_04_KPI_02,ABT_NEWS_2026-07-28_04_KPI_03,ABT_NEWS_2026-07-28_04_KPI_04,ABT_NEWS_2026-07-28_04_KPI_05,ABT_NEWS_2026-07-28_04_KPI_06,ABT_NEWS_2026-07-28_04_KPI_07,ABT_NEWS_2026-07-28_04_KPI_08,ABT_NEWS_2026-07-28_04_KPI_09,ABT_NEWS_2026-07-28_04_KPI_10,ABT_NEWS_2026-07-28_04_KPI_11,ABT_NEWS_2026-07-28_04_KPI_12,ABT_NEWS_2026-07-28_04_KPI_13,ABT_NEWS_2026-07-28_04_KPI_14,ABT_NEWS_2026-07-28_04_KPI_15,ABT_NEWS_2026-07-28_04_KPI_16 -->

Note 6 — Business Acquisition (Continued) The preliminary allocation of the fair value of the Exact Sciences acquisition is shown in the table below. Allocation of the purchase price of the acquisition will be finalized when the valuation of assets and liabilities is completed and differences between the preliminary and final allocation could be material. (in billions) Acquired intangible assets, non-deductible $12.8M Goodwill, non-deductible 11.4 Acquired net tangible assets 0.4 Deferred income taxes recorded at acquisition (2.0) Net debt (2.0) Total preliminary allocation of fair value <!-- room16-lineage claim=ABT_CLAIM_009 evidence=ABT_NEWS_2026-07-28_06_KPI_01,ABT_NEWS_2026-07-28_06_KPI_02,ABT_NEWS_2026-07-28_06_KPI_03 -->

On September 15, 2025, Abbott repaid the $500 million outstanding principal amount of its 3.875% Notes upon maturity. On March 17, 2025, Abbott repaid the $1.0 billion outstanding principal amount of its 2.95% Notes upon maturity. <!-- room16-lineage claim=ABT_CLAIM_010 evidence=ABT_NEWS_2026-07-28_07_KPI_01,ABT_NEWS_2026-07-28_07_KPI_02,ABT_NEWS_2026-07-28_07_KPI_03,ABT_NEWS_2026-07-28_07_KPI_04 -->

## Valuation / Risk-Reward
EV/Sales is 4.71x, derived from enterprise value and TTM revenue. Without a validated peer, history or cycle benchmark, this records a multiple level but does not label the company cheap or expensive. A benchmark can change the interpretation, but must be present in the authority packet before it affects the rating. Treat EV/Sales as an observation until comparison evidence exists. <!-- room16-lineage claim=ABT_CLAIM_049 evidence=ABT_DETERMINISTIC_EV_TO_SALES_2026-08-13,ABT_DETERMINISTIC_ENTERPRISE_VALUE_2026-08-13,ABT_DETERMINISTIC_REVENUE_TTM_2026-08-13 -->

For ABT, P/FCF is 24.61x, derived from market capitalization and TTM FCF. This records the cash-flow valuation level without labeling it cheap or expensive. A valuation conclusion requires sector comparison and cash-flow durability evidence. <!-- room16-lineage claim=ABT_CLAIM_050 evidence=ABT_DETERMINISTIC_PRICE_TO_FCF_2026-08-13,ABT_DETERMINISTIC_MARKET_CAP_2026-08-13,ABT_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13 -->

Standardized equity-DCF sensitivity, not a company forecast: bear $57.66B, base $116.34B and bull $275.41B. In the base case, discounted terminal value contributes 70.1% of scenario equity value, exposing the model's dependence on long-duration assumptions. The standardized reverse DCF implies a five-year FCF growth rate of 18.3% at a 10% discount rate and 2% terminal growth. DCF results are highly sensitive to growth, discount-rate and terminal assumptions and require business-model review. Compare the current equity value with the whole range; do not treat the base case as a precise price target. <!-- room16-lineage claim=ABT_CLAIM_051 evidence=ABT_DETERMINISTIC_DCF_BEAR_EQUITY_VALUE_2026-08-13,ABT_DETERMINISTIC_DCF_BASE_EQUITY_VALUE_2026-08-13,ABT_DETERMINISTIC_DCF_BULL_EQUITY_VALUE_2026-08-13,ABT_DETERMINISTIC_DCF_BASE_TERMINAL_VALUE_SHARE_2026-08-13,ABT_DETERMINISTIC_DCF_BASE_DISCOUNT_RATE_2026-08-13,ABT_DETERMINISTIC_DCF_BASE_TERMINAL_GROWTH_RATE_2026-08-13,ABT_DETERMINISTIC_REVERSE_DCF_GROWTH_2026-08-13 -->

## Scenario / Sensitivity
| Scenario | FCF growth | Discount rate | Terminal growth | Valuation implication | Rating implication |
|---|---:|---:|---:|---:|---|
| Bear | -4.3% | 12.0% | 1.0% | Equity value $57.66B | Would weaken the case only if primary evidence supports the adverse assumptions |
| Base | 5.7% | 10.0% | 2.0% | Equity value $116.34B | No automatic change to the current Provisional — Hold research rating |
| Bull | 15.7% | 8.0% | 3.0% | Equity value $275.41B | The rating would become more constructive if primary evidence supports the assumptions |

The table is a standardized sensitivity, not management guidance or a precise price target.
<!-- room16-table-lineage id=DCF_SCENARIO_VIEW evidence=ROOM16_ABT_DETERMINISTIC_CALCULATIONS_DCF_BASE_DISCOUNT_RATE,ROOM16_ABT_DETERMINISTIC_CALCULATIONS_DCF_BASE_EQUITY_VALUE,ROOM16_ABT_DETERMINISTIC_CALCULATIONS_DCF_BASE_FREE_CASH_FLOW_GROWTH_RATE,ROOM16_ABT_DETERMINISTIC_CALCULATIONS_DCF_BASE_TERMINAL_GROWTH_RATE,ROOM16_ABT_DETERMINISTIC_CALCULATIONS_DCF_BASE_TERMINAL_VALUE_SHARE,ROOM16_ABT_DETERMINISTIC_CALCULATIONS_DCF_BEAR_DISCOUNT_RATE,ROOM16_ABT_DETERMINISTIC_CALCULATIONS_DCF_BEAR_EQUITY_VALUE,ROOM16_ABT_DETERMINISTIC_CALCULATIONS_DCF_BEAR_FREE_CASH_FLOW_GROWTH_RATE,ROOM16_ABT_DETERMINISTIC_CALCULATIONS_DCF_BEAR_TERMINAL_GROWTH_RATE,ROOM16_ABT_DETERMINISTIC_CALCULATIONS_DCF_BEAR_TERMINAL_VALUE_SHARE,ROOM16_ABT_DETERMINISTIC_CALCULATIONS_DCF_BULL_DISCOUNT_RATE,ROOM16_ABT_DETERMINISTIC_CALCULATIONS_DCF_BULL_EQUITY_VALUE,ROOM16_ABT_DETERMINISTIC_CALCULATIONS_DCF_BULL_FREE_CASH_FLOW_GROWTH_RATE,ROOM16_ABT_DETERMINISTIC_CALCULATIONS_DCF_BULL_TERMINAL_GROWTH_RATE,ROOM16_ABT_DETERMINISTIC_CALCULATIONS_DCF_BULL_TERMINAL_VALUE_SHARE,ABT_DETERMINISTIC_DCF_BEAR_EQUITY_VALUE_2026-08-13,ABT_DETERMINISTIC_DCF_BEAR_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13,ABT_DETERMINISTIC_DCF_BEAR_DISCOUNT_RATE_2026-08-13,ABT_DETERMINISTIC_DCF_BEAR_TERMINAL_GROWTH_RATE_2026-08-13,ABT_DETERMINISTIC_DCF_BEAR_TERMINAL_VALUE_SHARE_2026-08-13,ABT_DETERMINISTIC_DCF_BASE_EQUITY_VALUE_2026-08-13,ABT_DETERMINISTIC_DCF_BASE_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13,ABT_DETERMINISTIC_DCF_BASE_TERMINAL_VALUE_SHARE_2026-08-13,ABT_DETERMINISTIC_DCF_BULL_EQUITY_VALUE_2026-08-13,ABT_DETERMINISTIC_DCF_BULL_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13,ABT_DETERMINISTIC_DCF_BULL_DISCOUNT_RATE_2026-08-13,ABT_DETERMINISTIC_DCF_BULL_TERMINAL_GROWTH_RATE_2026-08-13,ABT_DETERMINISTIC_DCF_BULL_TERMINAL_VALUE_SHARE_2026-08-13,ABT_DETERMINISTIC_DCF_BASE_DISCOUNT_RATE_2026-08-13,ABT_DETERMINISTIC_DCF_BASE_TERMINAL_GROWTH_RATE_2026-08-13 -->

## Technical Setup
The technical setup records raw observations only: close $111.27, 50-SMA $97.14, 200-SMA $107.44 and RSI 72.90. No bullish, bearish or mixed technical conclusion is activated. Corporate-action adjustment is not confirmed, so no directional conclusion or numeric policy level is activated. Do not use these raw observations for timing until the corporate-action adjustment is confirmed. <!-- room16-lineage claim=ABT_CLAIM_052 evidence=ABT_CSV_PRICE_CLOSE_2026-08-13,ABT_DETERMINISTIC_CLOSE_2026-08-13,ABT_DETERMINISTIC_SMA_50_2026-08-13,ABT_DETERMINISTIC_SMA_200_2026-08-13,ABT_DETERMINISTIC_RSI_14_2026-08-13 -->

ABT's close of $111.27 and moving-average position record unscored raw moving-average observations; no bullish or bearish technical conclusion is activated because corporate-action adjustment is not confirmed; this does not prescribe an entry, trim or position size. Technical weakness can be temporary if fundamentals and catalysts improve. No technical divergence or timing condition is activated until the price-series basis is confirmed. <!-- room16-lineage claim=ABT_CLAIM_053 evidence=ABT_CSV_PRICE_CLOSE_2026-08-13,ABT_DETERMINISTIC_CLOSE_2026-08-13,ABT_DETERMINISTIC_SMA_50_2026-08-13,ABT_DETERMINISTIC_SMA_200_2026-08-13,ABT_DETERMINISTIC_RSI_14_2026-08-13 -->

## Bull Case
Matching-quarter evidence reports revenue growth 13.0%, operating-income decline 17.5%, net-income decline 47.8%. The current-period comparisons are mixed; segment, margin or one-off context is needed before treating the negative comparisons as business direction. Revenue TTM is $46.59B and FCF TTM is $7.82B; positive FCF establishes cash generation, but does not turn mixed comparisons into broad-based operating improvement. A more constructive rating requires revenue and profit measures to improve together, plus stronger verified technical or benchmarked valuation support. Reported comparisons and scale do not by themselves prove durable cash conversion or justify an unbenchmarked valuation. The bull case remains a research scenario, not an action plan. <!-- room16-lineage claim=ABT_CLAIM_054 evidence=ABT_DETERMINISTIC_REVENUE_TTM_2026-08-13,ABT_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13,ABT_DETERMINISTIC_CURRENT_PERIOD_REVENUE_GROWTH_YOY_2026-08-13,ABT_DETERMINISTIC_CURRENT_PERIOD_OPERATING_INCOME_GROWTH_YOY_2026-08-13,ABT_DETERMINISTIC_CURRENT_PERIOD_NET_INCOME_GROWTH_YOY_2026-08-13 -->

No constructive technical bull path is activated for ABT. The current RSI of 72.90 and moving-average observations remain unscored until the corporate-action adjustment is confirmed. A more constructive research stance should require confirmation when the preferred rating is not Buy. <!-- room16-lineage claim=ABT_CLAIM_055 evidence=ABT_DETERMINISTIC_RSI_14_2026-08-13,ABT_DETERMINISTIC_SMA_50_2026-08-13,ABT_DETERMINISTIC_SMA_200_2026-08-13,ABT_CSV_PRICE_CLOSE_2026-08-13,ABT_DETERMINISTIC_CLOSE_2026-08-13 -->

**Issuer-specific confirmation path.**
**Capital allocation:** Reported evidence: Issuer-filed business context: On June 12, 2026, the board of directors of Abbott declared the company's quarterly dividend of $0.63 per share; The next comparable filing must confirm the stated improvement. <!-- room16-lineage claim=ABT_CLAIM_033 evidence=ABT_NEWS_2026-07-16_47_KPI_01 -->
**Transaction financing:** Reported evidence: Issuer-filed business context: On March 23, 2026, Abbott completed the acquisition of Exact Sciences for approximately $20.6 billion; The next comparable filing must confirm the stated improvement. <!-- room16-lineage claim=ABT_CLAIM_016 evidence=ABT_NEWS_2026-07-28_14_KPI_01,ABT_NEWS_2026-07-28_14_KPI_02,ABT_NEWS_2026-07-28_14_KPI_03,ABT_NEWS_2026-07-28_14_KPI_04 -->
A stronger case requires these issuer-bound signals to confirm one another and continue converting into cash.

## Bear Case
ABT's current-period operating-income and net-income declines are current downside evidence. Positive FCF TTM of $7.82B is counterevidence, but does not erase the profit weakness. A durable bear case requires persistence or weaker cash conversion. Technical timing context is unscored raw moving-average observations; no bullish or bearish technical conclusion is activated because corporate-action adjustment is not confirmed; it does not establish operating deterioration or change the company rating. Issuer disclosure identifies a separate exposure: Disruptions to Abbott’s global supply chain, which is large and complex, could negatively affect Abbott’s results of operations. This identifies a risk, not evidence that the adverse outcome has occurred. Treat the bear case as evidence to monitor, not as proof of permanent business deterioration. <!-- room16-lineage claim=ABT_CLAIM_056 evidence=ABT_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13,ABT_DETERMINISTIC_CURRENT_PERIOD_OPERATING_INCOME_GROWTH_YOY_2026-08-13,ABT_DETERMINISTIC_CURRENT_PERIOD_NET_INCOME_GROWTH_YOY_2026-08-13,ABT_CSV_PRICE_CLOSE_2026-08-13,ABT_DETERMINISTIC_CLOSE_2026-08-13,ABT_DETERMINISTIC_SMA_50_2026-08-13,ABT_DETERMINISTIC_SMA_200_2026-08-13,ABT_DETERMINISTIC_RSI_14_2026-08-13,ABT_SEC_RISK_000162828026010185_01 -->

## Material Events & Governance
SEC Form 8-K Item 5.03. Amendments to Articles of Incorporation or Bylaws; Change in Fiscal Year. On February 20, 2026, Abbott’s Board of Directors amended the first sentence of Article III, Section 2 of Abbott’s By-Laws to provide that Abbott’s Board of Directors shall consist of twelve persons, effective April 24, 2026. Abbott’s By-Laws currently provide that the Board of Directors consists of thirteen persons. <!-- room16-lineage claim=ABT_CLAIM_034 evidence=ABT_NEWS_2026-02-20_49 -->

SEC Form 8-K Item 1.01. The issuer entered into a pricing agreement for a public senior-notes offering. <!-- room16-lineage claim=ABT_CLAIM_035 evidence=ABT_NEWS_2026-02-26_50 -->

SEC Form 8-K Item 1.01. The issuer completed a public senior-notes offering and issuance under the disclosed agreement. <!-- room16-lineage claim=ABT_CLAIM_036 evidence=ABT_NEWS_2026-03-09_51 -->

SEC Form 8-K Item 2.03. The issuer incorporated the financing-obligation disclosure from Item 1.01 by reference. <!-- room16-lineage claim=ABT_CLAIM_037 evidence=ABT_NEWS_2026-03-09_52 -->

SEC Form 8-K Item 5.02. On April 24, 2026, Kevin Conroy was named to the Abbott Laboratories’ (“Abbott”) Board of Directors. <!-- room16-lineage claim=ABT_CLAIM_038 evidence=ABT_NEWS_2026-04-27_56 -->

SEC Form 8-K Item 5.03. Amendments to Articles of Incorporation or Bylaws; Change in Fiscal Year. On April 24, 2026, Abbott’s Board of Directors amended the first sentence of Article III, Section 2 of Abbott’s by-laws to provide that Abbott’s Board of Directors shall consist of thirteen persons, effective April 24, 2026. Abbott’s by-laws previously provided that the Board of Directors consisted of twelve persons. <!-- room16-lineage claim=ABT_CLAIM_039 evidence=ABT_NEWS_2026-04-27_57 -->

## Risks
Current issuer-filed risk context: In the K, Abbott reported that it is a defendant in numerous lawsuits alleging that preterm infants developed necrotizing enterocolitis as a result of being administered Abbott’s preterm infant formula products.. <!-- room16-lineage claim=ABT_CLAIM_011 evidence=ABT_NEWS_2026-07-28_09_NARRATIVE -->

Current issuer-filed risk context: Abbott is involved in various claims and legal proceedings, including being a defendant in a civil qui tam lawsuit related, in part, to Abbott’s manufacturing of powdered infant formula products at its facility in Sturgis, Michigan. In that matter, the U.S. Department of Justice and several states have partially intervened, alleging violations of certain federal and state laws, including the Federal False Claims Act. Abbott estimates the range of possible loss for all of its various legal proceedings and environmental exposures to be from approximately $120 million to $530 million. The recorded accrual balance at June 30, 2026, for these proceedings and exposures was approximately $510 million. This accrual represents management’s best estimate of probable loss, as defined by FASB ASC No. 450, “Contingencies.” Within the next year, legal proceedings may occur that could result in a change in the estimated loss accrued by Abbott. While it is not feasible to predict the outcome of all such proceedings and exposures with certainty, management believes that their ultimate disposition should not have a material adverse effect on Abbott’s financial position, cash flows, or results of operations, except for the matters discussed in the second paragraph of this note, the resolution of which could be material to Abbott’s financial position, cash flows, or results of operations. <!-- room16-lineage claim=ABT_CLAIM_012 evidence=ABT_NEWS_2026-07-28_10_KPI_01,ABT_NEWS_2026-07-28_10_KPI_02,ABT_NEWS_2026-07-28_10_KPI_03 -->

Current issuer-filed risk context: Abbott has been named as a defendant in a number of lawsuits alleging that its preterm infant formula and human milk fortifier products that contain cow’s milk ingredients cause an intestinal disease known as necrotizing enterocolitis (NEC) and inadequately warn about the risk of NEC.. <!-- room16-lineage claim=ABT_CLAIM_013 evidence=ABT_NEWS_2026-07-28_11_NARRATIVE -->

Issuer-disclosed risk: Disruptions to Abbott’s global supply chain, which is large and complex, could negatively affect Abbott’s results of operations. This identifies an exposure; it does not establish that the adverse outcome has occurred. <!-- room16-lineage claim=ABT_CLAIM_040 evidence=ABT_SEC_RISK_000162828026010185_01 -->

Issuer-disclosed risk: Abbott may acquire other businesses, license rights to technologies or products, form alliances, or dispose of or spin-off businesses, which could cause it to incur significant expenses and could negatively affect profitability. <!-- room16-lineage claim=ABT_CLAIM_041 evidence=ABT_SEC_RISK_000162828026010185_02 -->

## Catalysts
ABT issuer-filed FY2026 guidance calls for comparable-sales growth of 6.5% to 7.5% and adjusted EPS of $5.45 to $5.60. Guidance is forward-looking and remains exposed to execution, currency and demand changes. Future reported results should be measured against the filed range rather than against an unsourced expectation. <!-- room16-lineage claim=ABT_CLAIM_004 evidence=ABT_SEC_CIK0000001800_000162828026048377_ABT_2026Q2XEXHIBITX991_guidance_comparable_sales_growth_low_FY2026,ABT_SEC_CIK0000001800_000162828026048377_ABT_2026Q2XEXHIBITX991_guidance_comparable_sales_growth_high_FY2026,ABT_SEC_CIK0000001800_000162828026048377_ABT_2026Q2XEXHIBITX991_guidance_adjusted_eps_low_FY2026,ABT_SEC_CIK0000001800_000162828026048377_ABT_2026Q2XEXHIBITX991_guidance_adjusted_eps_high_FY2026 -->

Operating catalyst under review: In May 2026, Abbott announced it secured CE Mark for Libre® Duo, its dual glucose-ketone biowearable sensor. An announced strategy is forward-looking intent; execution and financial contribution remain unproven. Reassess only when subsequent reported evidence shows whether the stated objectives are being achieved. <!-- room16-lineage claim=ABT_CLAIM_017 evidence=ABT_NEWS_2026-07-28_17 -->

Operating catalyst under review: In April, Abbott completed enrollment in its TECTONIC U.S. pivotal trial. An announced strategy is forward-looking intent; execution and financial contribution remain unproven. Reassess only when subsequent reported evidence shows whether the stated objectives are being achieved. <!-- room16-lineage claim=ABT_CLAIM_025 evidence=ABT_NEWS_2026-07-16_40 -->

Operating catalyst under review: In May, Abbott completed its submission to the U.S. Food and Drug Administration (FDA) seeking approval for the company's Amulet™ 360 left atrial appendage (LAA) device. An announced strategy is forward-looking intent; execution and financial contribution remain unproven. Reassess only when subsequent reported evidence shows whether the stated objectives are being achieved. <!-- room16-lineage claim=ABT_CLAIM_028 evidence=ABT_NEWS_2026-07-16_42 -->

The raw moving-average observations are 50-SMA $97.14 and 200-SMA $107.44. They are not validated support, resistance, risk or trigger levels because corporate-action adjustment is not confirmed. No separate evidence-backed price target is present in the packet. Withhold technical trigger language until the price-series basis is confirmed. <!-- room16-lineage claim=ABT_CLAIM_057 evidence=ABT_DETERMINISTIC_SMA_50_2026-08-13,ABT_DETERMINISTIC_SMA_200_2026-08-13 -->

## Final Rating & Review Conditions
Final Rating: Provisional — Hold. Constructive fundamentals are not enough for an overweight rating without calibrated valuation evidence; unverified technical inputs are excluded from rating and timing.

Factual anchors are revenue of $46.59B, FCF of $7.82B. Separately, raw technical observations include RSI of 72.90; direction and timing are not activated because corporate-action adjustment is not confirmed; raw indicators remain provisional observations.

The standardized equity-DCF range is $57.66B to $275.41B. It is an uncalibrated illustration outside the rating logic and does not create an automatic rating signal.

Why not more constructive? Current-period operating-income and net-income declines are current downside evidence; positive FCF does not erase those reported comparisons. A more constructive rating requires profit comparisons to improve, that improvement to persist, and benchmarked valuation support.

Why not more cautious? The operating-income and net-income declines are not dismissed, but positive FCF is measured counterevidence. A more cautious rating requires the profit weakness to persist or be corroborated by weaker cash conversion. The rating already monitors these named current risks: Gill NEC verdict affirmed; Missouri Supreme Court review sought; Sturgis infant-formula qui tam litigation and recorded legal-loss range; Broader NEC litigation with mixed state outcomes, federal bellwether wins, and no recorded reserve. A more cautious rating requires new primary evidence that their reserve, compliance, operating or cash-flow transmission outweighs the measured counterevidence; an issuer counterposition is context, not independent proof.

Review condition: retain the ABT research rating while the measured evidence state is unchanged. Reassess only when new primary evidence changes fundamentals, calibrated valuation or issuer risk. Technical timing remains unavailable until the price-series basis is confirmed.

**Formal rating evidence binding:** <!-- room16-lineage claim=ABT_CLAIM_058 evidence=ABT_CSV_PRICE_CLOSE_2026-08-13,ABT_DETERMINISTIC_CLOSE_2026-08-13,ABT_DETERMINISTIC_REVENUE_TTM_2026-08-13,ABT_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13,ABT_DETERMINISTIC_EV_TO_SALES_2026-08-13,ABT_DETERMINISTIC_TRAILING_PE_2026-08-13,ABT_DETERMINISTIC_PRICE_TO_FCF_2026-08-13,ABT_DETERMINISTIC_DCF_BEAR_EQUITY_VALUE_2026-08-13,ABT_DETERMINISTIC_DCF_BEAR_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13,ABT_DETERMINISTIC_DCF_BEAR_DISCOUNT_RATE_2026-08-13,ABT_DETERMINISTIC_DCF_BEAR_TERMINAL_GROWTH_RATE_2026-08-13,ABT_DETERMINISTIC_DCF_BEAR_TERMINAL_VALUE_SHARE_2026-08-13,ABT_DETERMINISTIC_DCF_BASE_EQUITY_VALUE_2026-08-13,ABT_DETERMINISTIC_DCF_BASE_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13,ABT_DETERMINISTIC_DCF_BASE_DISCOUNT_RATE_2026-08-13,ABT_DETERMINISTIC_DCF_BASE_TERMINAL_GROWTH_RATE_2026-08-13,ABT_DETERMINISTIC_DCF_BASE_TERMINAL_VALUE_SHARE_2026-08-13,ABT_DETERMINISTIC_DCF_BULL_EQUITY_VALUE_2026-08-13,ABT_DETERMINISTIC_DCF_BULL_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13,ABT_DETERMINISTIC_DCF_BULL_DISCOUNT_RATE_2026-08-13,ABT_DETERMINISTIC_DCF_BULL_TERMINAL_GROWTH_RATE_2026-08-13,ABT_DETERMINISTIC_DCF_BULL_TERMINAL_VALUE_SHARE_2026-08-13,ABT_DETERMINISTIC_REVERSE_DCF_GROWTH_2026-08-13,ABT_NEWS_2026-07-28_09_NARRATIVE,ABT_NEWS_2026-07-28_10_NARRATIVE,ABT_NEWS_2026-07-28_11_NARRATIVE -->

## Data Limits & Review Status

- Internal status: `manual_review`.
- Public release: `blocked`.
- Active review points:
  - `EARNINGS_DATE_UNAVAILABLE`: Next earnings date is unavailable. No confirmed issuer or exchange date was captured.
  - `BALANCE_SHEET_DATE_MISMATCH_EXCLUDED`: Excluded lease_liability_current from 2025-12-31 because the latest financial-statement balance date is 2026-06-30.

## Evidence Appendix
The complete claim text, evidence IDs, metric mappings and source IDs are stored in the separately hash-bound `analyst_claims.json`. This appendix is the compact human-readable index.

| Claim ID | Section | Claim Type | Evidence Count | Source Types | Confidence |
|---|---|---|---:|---|---|
| ABT_CLAIM_001 | Executive Summary | rating | 5 | deterministic calculation, exchange ohlcv | high |
| ABT_CLAIM_002 | Fundamental Analysis | financial metric | 6 | deterministic calculation, sec filing | high |
| ABT_CLAIM_003 | Fundamental Analysis | financial metric | 2 | sec filing | high |
| ABT_CLAIM_004 | Catalysts & Triggers | guidance | 4 | sec filing | high |
| ABT_CLAIM_005 | Capital Allocation, Transactions & Contingencies | financial metric | 6 | derived calculation, deterministic calculation | high |
| ABT_CLAIM_006 | Business & Segment Context | news | 1 | sec filing | high |
| ABT_CLAIM_007 | Business & Segment Context | news | 1 | sec filing | high |
| ABT_CLAIM_008 | Capital Allocation, Transactions & Contingencies | news | 16 | sec filing | high |
| ABT_CLAIM_009 | Capital Allocation, Transactions & Contingencies | news | 3 | sec filing | high |
| ABT_CLAIM_010 | Capital Allocation, Transactions & Contingencies | news | 4 | sec filing | high |
| ABT_CLAIM_011 | Key Risks | risk | 1 | sec filing | high |
| ABT_CLAIM_012 | Key Risks | risk | 3 | sec filing | high |
| ABT_CLAIM_013 | Key Risks | risk | 1 | sec filing | high |
| ABT_CLAIM_014 | Business & Segment Context | news | 2 | sec filing | high |
| ABT_CLAIM_015 | Business & Segment Context | news | 2 | sec filing | high |
| ABT_CLAIM_016 | Business & Segment Context | news | 4 | sec filing | high |
| ABT_CLAIM_017 | Catalysts & Triggers | news | 1 | sec filing | high |
| ABT_CLAIM_018 | Business & Segment Context | news | 1 | sec filing | high |
| ABT_CLAIM_019 | Business & Segment Context | news | 1 | sec filing | high |
| ABT_CLAIM_020 | Business & Segment Context | news | 2 | sec filing | high |
| ABT_CLAIM_021 | Business & Segment Context | news | 3 | sec filing | high |
| ABT_CLAIM_022 | Business & Segment Context | news | 2 | sec filing | high |
| ABT_CLAIM_023 | Business & Segment Context | news | 1 | sec filing | high |
| ABT_CLAIM_024 | Business & Segment Context | news | 1 | sec filing | high |
| ABT_CLAIM_025 | Catalysts & Triggers | news | 1 | sec filing | high |
| ABT_CLAIM_026 | Business & Segment Context | news | 1 | sec filing | high |
| ABT_CLAIM_027 | Catalysts & Triggers | news | 1 | sec filing | high |
| ABT_CLAIM_028 | Catalysts & Triggers | news | 1 | sec filing | high |
| ABT_CLAIM_029 | Business & Segment Context | news | 5 | sec filing | high |
| ABT_CLAIM_030 | Business & Segment Context | news | 5 | sec filing | high |
| ABT_CLAIM_031 | Business & Segment Context | news | 5 | sec filing | high |
| ABT_CLAIM_032 | Business & Segment Context | news | 5 | sec filing | high |
| ABT_CLAIM_033 | Business & Segment Context | news | 1 | sec filing | high |
| ABT_CLAIM_034 | Material Events & Governance | news | 1 | sec filing | high |
| ABT_CLAIM_035 | Material Events & Governance | news | 1 | sec filing | high |
| ABT_CLAIM_036 | Material Events & Governance | news | 1 | sec filing | high |
| ABT_CLAIM_037 | Material Events & Governance | news | 1 | sec filing | high |
| ABT_CLAIM_038 | Material Events & Governance | news | 1 | sec filing | high |
| ABT_CLAIM_039 | Material Events & Governance | news | 1 | sec filing | high |
| ABT_CLAIM_040 | Key Risks | risk | 1 | sec filing | high |
| ABT_CLAIM_041 | Key Risks | risk | 1 | sec filing | high |
| ABT_CLAIM_042 | Key Risks | risk | 1 | sec filing | high |
| ABT_CLAIM_043 | Key Risks | risk | 1 | sec filing | high |
| ABT_CLAIM_044 | Key Risks | risk | 2 | deterministic calculation | medium |
| ABT_CLAIM_045 | Fundamental Analysis | financial metric | 2 | deterministic calculation | high |
| ABT_CLAIM_046 | Fundamental Analysis | financial metric | 2 | deterministic calculation | high |
| ABT_CLAIM_047 | Fundamental Analysis | financial metric | 2 | deterministic calculation | medium |
| ABT_CLAIM_048 | Fundamental Analysis | financial metric | 2 | deterministic calculation | medium |
| ABT_CLAIM_049 | Valuation / Multiples | valuation metric | 3 | deterministic calculation | medium |
| ABT_CLAIM_050 | Valuation / Multiples | valuation metric | 3 | deterministic calculation | medium |
| ABT_CLAIM_051 | Valuation / Multiples | valuation metric | 7 | deterministic calculation | medium |
| ABT_CLAIM_052 | Technical Setup | technical metric | 5 | exchange ohlcv | high |
| ABT_CLAIM_053 | Technical Setup | technical metric | 5 | exchange ohlcv | medium |
| ABT_CLAIM_054 | Bull Case | financial metric | 5 | deterministic calculation | medium |
| ABT_CLAIM_055 | Bull Case | technical metric | 5 | exchange ohlcv | medium |
| ABT_CLAIM_056 | Bear Case | financial metric | 9 | deterministic calculation, exchange ohlcv, sec filing | medium |
| ABT_CLAIM_057 | Catalysts & Triggers | technical metric | 2 | exchange ohlcv | medium |
| ABT_CLAIM_058 | Final Rating & Action Plan | rating | 26 | deterministic calculation, exchange ohlcv, sec filing | high |
