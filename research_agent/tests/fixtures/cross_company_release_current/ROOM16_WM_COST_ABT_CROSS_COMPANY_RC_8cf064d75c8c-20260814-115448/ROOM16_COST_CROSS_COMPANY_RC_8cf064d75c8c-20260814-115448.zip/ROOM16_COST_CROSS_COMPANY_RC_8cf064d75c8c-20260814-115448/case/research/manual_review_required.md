# Manual Review Required

This report is internal and must not be published before operator review.

## Active Review Reasons

- `BALANCE_SHEET_DATE_MISMATCH_EXCLUDED`: Excluded lease_liability_current from 2025-08-31 because the latest financial-statement balance date is 2026-05-10.

---

# COST Research Report
## Instrument Identity
| Identity field | Verified value |
| --- | --- |
| Legal company name | COSTCO WHOLESALE CORP |
| Ticker | COST |
| Listing venue | Nasdaq |
| Jurisdiction | US / incorporation Washington (WA) |
| SEC CIK | 0000909832 |
| Reporting / price currency | USD |
| Analysis cutoff | 2026-08-13 |
| Price date | 2026-08-13 |
| ISIN | not available |
| WKN | not available |

## Executive Summary
- COST enters the report at a frozen close of $961.85 with a Provisional — Hold stance. The available evidence anchors are revenue TTM of $293.59B, FCF TTM of $8.81B, EV/Sales of 1.40x; the technical evidence indicates unscored raw moving-average observations; no bullish or bearish technical conclusion is activated because corporate-action adjustment is not confirmed. The standardized DCF is an uncalibrated illustration outside the rating logic. <!-- room16-lineage claim=COST_CLAIM_001 evidence=COST_CSV_PRICE_CLOSE_2026-08-13,COST_DETERMINISTIC_CLOSE_2026-08-13,COST_DETERMINISTIC_REVENUE_TTM_2026-08-13,COST_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13,COST_DETERMINISTIC_EV_TO_SALES_2026-08-13 -->
  Investment implication: The action language should stay consistent with the Provisional — Hold stance.
  Source labels: `COST_US_MARKET_DAILY_OHLCV, ROOM16_COST_DETERMINISTIC_CALCULATIONS`.

## Investment Thesis
- Thesis anchor: `Provisional — Hold` follows the measured fundamentals, valuation status and financial-risk screen. Technical evidence is a separate timing overlay.
- Evidence anchor: `ROOM16_COST_DETERMINISTIC_CALCULATIONS`.
- Fundamental basis: revenue scale is `$293.59B`.
- Cash-conversion basis: free cash flow is `$8.81B`.
- Valuation sensitivity: the standardized equity-DCF range is `$71.99B` to `$342.60B`. It is an uncalibrated illustration outside the rating logic; it is not a company-specific fair-value estimate.
- Technical boundary: status is `partial`; raw indicators cannot inform timing until the price-series adjustment is confirmed.
- Research implication: the stance for `COST` remains conditional on business evidence, valuation calibration and issuer risk.

## Data / Source Quality Note
- Report as-of date: `2026-08-13`.
- Price basis: `2026-08-13` close via `COST_US_MARKET_DAILY_OHLCV`.
- True unresolved source disagreements: `0`.

## Validated Metric Table
| Metric | Value |
|---|---:|
| Close | 961.85 USD |
| 50 SMA | 950.59 |
| 200 SMA | 958.35 |
| RSI 14 | 55.88 |
| FCF TTM | 8,806,000,000 USD |
| SBC / Revenue | 0.3% |
| EV / Sales | 1.40 |
| P / FCF | 48.44 |
Table claim `VALIDATED_METRIC_TABLE` · Evidence: `COST_US_MARKET_DAILY_OHLCV_CLOSE, COST_US_MARKET_DAILY_OHLCV_RSI_14, COST_US_MARKET_DAILY_OHLCV_SMA_200, COST_US_MARKET_DAILY_OHLCV_SMA_50, SEC_0000909832_0000909832-25-000101_SBC_TO_REVENUE, SEC_0000909832_0000909832-26-000029_SBC_TO_REVENUE, SEC_0000909832_0000909832-26-000051_SBC_TO_REVENUE, SEC_0000909832_0000909832-25-000033_SBC_TO_REVENUE, ROOM16_COST_DETERMINISTIC_CALCULATIONS_CLOSE, ROOM16_COST_DETERMINISTIC_CALCULATIONS_EV_TO_SALES, ROOM16_COST_DETERMINISTIC_CALCULATIONS_FREE_CASH_FLOW_TTM, ROOM16_COST_DETERMINISTIC_CALCULATIONS_PRICE_TO_FCF, ROOM16_COST_DETERMINISTIC_CALCULATIONS_SBC_TO_REVENUE, COST_CSV_PRICE_CLOSE_2026-08-13, COST_DETERMINISTIC_CLOSE_2026-08-13, COST_DETERMINISTIC_SMA_50_2026-08-13, COST_DETERMINISTIC_SMA_200_2026-08-13, COST_DETERMINISTIC_RSI_14_2026-08-13, COST_DETERMINISTIC_SBC_TO_REVENUE_2026-08-13, COST_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13, COST_DETERMINISTIC_EV_TO_SALES_2026-08-13, COST_DETERMINISTIC_PRICE_TO_FCF_2026-08-13`.

## Business & Segment Context
- Issuer-filed business context: We operate membership warehouses and e-commerce sites based on the concept that offering low prices on a limited selection of nationally-branded and private-label products in a wide range of categories will produce high sales volumes and rapid inventory turnover. <!-- room16-lineage claim=COST_CLAIM_005 evidence=COST_SEC_BUSINESS_000090983225000101_01 -->
  Source labels: `SEC filing`.
- Issuer-filed business context: Costco Travel offers vacation packages, car rentals, cruises and other travel products exclusively for Costco members (offered to varying degrees in the U.S., Canada, Australia, and the U.K.). <!-- room16-lineage claim=COST_CLAIM_006 evidence=COST_SEC_BUSINESS_000090983225000101_02 -->
  Source labels: `SEC filing`.
- Issuer-filed business context: Net sales increased $7.189B or 12%, and $17.894B or 10% during the third quarter and first thirty-six weeks of 2026. The improvement was primarily attributable to an increase in comparable sales of $6.055B or 10% and $14.553B or 8% during the third quarter and thirty-six weeks of 2026. Comparable sales were positively impacted by increases of approximately 7% and 5% in average ticket and 2% and 3% in shopping frequency in the third quarter and first thirty-six weeks of 2026. The remaining increase was driven by sales at the 23 net new warehouses opened since the end of the third quarter of 2025. <!-- room16-lineage claim=COST_CLAIM_010 evidence=COST_NEWS_2026-06-03_11_KPI_01,COST_NEWS_2026-06-03_11_KPI_02,COST_NEWS_2026-06-03_11_KPI_03,COST_NEWS_2026-06-03_11_KPI_04,COST_NEWS_2026-06-03_11_KPI_05,COST_NEWS_2026-06-03_11_KPI_06,COST_NEWS_2026-06-03_11_KPI_07,COST_NEWS_2026-06-03_11_KPI_08,COST_NEWS_2026-06-03_11_KPI_09,COST_NEWS_2026-06-03_11_KPI_10,COST_NEWS_2026-06-03_11_KPI_11,COST_NEWS_2026-06-03_11_KPI_12,COST_NEWS_2026-06-03_11_KPI_13 -->
  Source labels: `SEC filing`.
- Issuer-filed business context: Total paid members (000s)82,900: 12W ended 2026-05-10: 82.9 million; 12W ended 2025-05-11: 79.6 million. <!-- room16-lineage claim=COST_CLAIM_011 evidence=COST_NEWS_2026-06-03_14_KPI_01,COST_NEWS_2026-06-03_14_KPI_02 -->
  Source labels: `SEC filing`.
- Issuer-filed business context: Total cardholders (000s)148,500: 12W ended 2026-05-10: 148.5 million; 12W ended 2025-05-11: 142.8 million. <!-- room16-lineage claim=COST_CLAIM_012 evidence=COST_NEWS_2026-06-03_15_KPI_01,COST_NEWS_2026-06-03_15_KPI_02 -->
  Source labels: `SEC filing`.
- Issuer-filed business context: Membership fee revenue increased 11% and 13% in the third quarter and first thirty-six weeks of 2026, driven by new member sign-ups, membership fee increases and upgrades to Executive Membership. At the end of the third quarter of 2026, our renewal rates were 92.2% in the U.S. and Canada and 89.7% worldwide. Renewal rates were negatively impacted by a higher number of memberships sold online, including through digital promotions, entering the renewal rate calculation. These memberships renew at a slightly lower rate on average. <!-- room16-lineage claim=COST_CLAIM_013 evidence=COST_NEWS_2026-06-03_16_KPI_01,COST_NEWS_2026-06-03_16_KPI_02,COST_NEWS_2026-06-03_16_KPI_03,COST_NEWS_2026-06-03_16_KPI_04 -->
  Source labels: `SEC filing`.
- Issuer-filed business context: Our operating hours are shorter than many other retailers, and due to other efficiencies inherent in a warehouse club operation, we believe labor costs are lower relative to the volume of sales. In the U.S., we recently added exclusive shopping hours for our Executive members and our gasoline operations generally have extended hours. Merchandise is generally stored on racks above the sales floor and displayed on pallets containing large quantities, reducing labor required. In general, with variations by country, our warehouses accept certain credit cards, including Costco co-branded cards, debit cards, cash and checks, Executive member 2% reward certificates, co-brand cardholder rebates, and our proprietary stored-value card (shop card). <!-- room16-lineage claim=COST_CLAIM_014 evidence=COST_NEWS_2025-10-08_18_KPI_01 -->
  Source labels: `SEC filing`.
- Issuer-filed business context: Our other businesses sell products and services that largely complement our warehouse operations. Our e-commerce operations give members convenience and a broader selection of goods and services. Net sales for e-commerce represented approximately 7% of total net sales in 2025. <!-- room16-lineage claim=COST_CLAIM_015 evidence=COST_NEWS_2025-10-08_19_KPI_01 -->
  Source labels: `SEC filing`.
- Issuer-filed business context: Our members may utilize their memberships at all of our warehouses and e-commerce sites. Gold Star memberships are available to individuals; Business memberships are limited to businesses, including individuals with a business license or comparable document. Business members may add additional cardholders (affiliates), to which the same annual fee applies. Affiliates are not available for Gold Star members. Our annual fee for these memberships is $65 in the U.S. and varies in other countries. All paid memberships include a free household card. <!-- room16-lineage claim=COST_CLAIM_016 evidence=COST_NEWS_2025-10-08_20_KPI_01 -->
  Source labels: `SEC filing`.
- Issuer-filed business context: Paid members (except affiliates) are eligible to upgrade to an Executive membership in the U.S., for an additional annual fee of $65. Executive memberships are also available in Canada, Mexico, the U.K., Japan, Korea, Taiwan, and Australia, for which the additional fee varies. Executive members earn a 2% reward on qualified purchases (generally up to a maximum reward of $1,250 per year), redeemable at Costco warehouses. The sales penetration of Executive members represented approximately 73.6% of worldwide net sales in 2025. <!-- room16-lineage claim=COST_CLAIM_017 evidence=COST_NEWS_2025-10-08_21_KPI_01,COST_NEWS_2025-10-08_21_KPI_02,COST_NEWS_2025-10-08_21_KPI_03,COST_NEWS_2025-10-08_21_KPI_04 -->
  Source labels: `SEC filing`.
- Issuer-filed business context: Total paid members: FY2025: 81.0 million; FY2024: 76.2 million; FY2023: 71.0 million. <!-- room16-lineage claim=COST_CLAIM_018 evidence=COST_NEWS_2025-10-08_22_KPI_01,COST_NEWS_2025-10-08_22_KPI_02,COST_NEWS_2025-10-08_22_KPI_03 -->
  Source labels: `SEC filing`.
- Issuer-filed business context: Total cardholders: FY2025: 145.2 million; FY2024: 136.8 million; FY2023: 127.9 million. <!-- room16-lineage claim=COST_CLAIM_019 evidence=COST_NEWS_2025-10-08_23_KPI_01,COST_NEWS_2025-10-08_23_KPI_02,COST_NEWS_2025-10-08_23_KPI_03 -->
  Source labels: `SEC filing`.
- Issuer-filed business context: Executive members represented: FY2025: 38.7 million; FY2024: 35.4 million; FY2023: 32.3 million. <!-- room16-lineage claim=COST_CLAIM_020 evidence=COST_NEWS_2025-10-08_24_KPI_01,COST_NEWS_2025-10-08_24_KPI_02,COST_NEWS_2025-10-08_24_KPI_03 -->
  Source labels: `SEC filing`.
- Issuer-filed business context: Our member renewal rate was 92.3% in the U.S. and Canada and 89.8% worldwide at the end of 2025. That rate, which excludes affiliates of Business members, is a trailing calculation that captures renewals during the period seven to eighteen months prior to the reporting date. Memberships that have an expiration date in the six months prior to the end of our reporting period are excluded from this calculation, regardless of whether or not they have been renewed. Although most members renew prior to expiration, the vast majority of those who renew late do so within six months of expiration. The timing of <!-- room16-lineage claim=COST_CLAIM_021 evidence=COST_NEWS_2025-10-08_25_KPI_01,COST_NEWS_2025-10-08_25_KPI_02 -->
  Source labels: `SEC filing`.
- Issuer-filed business context: We believe that the most important driver of our profitability is increasing net sales, particularly comparable sales. Net sales includes our core merchandise categories (foods and sundries, non-foods, and fresh foods), warehouse ancillary (gasoline, pharmacy, optical, food court, hearing aids, and tire installation) and other businesses (e-commerce, business centers, travel, and other). E-commerce and business center sales are allocated to the appropriate merchandise categories in the Net Sales discussion. The 2% reward associated with Executive membership reduces net sales and is allocated to the category in which the reward is generated (core merchandise categories, warehouse ancillary, and other businesses). Comparable sales is defined as net sales from warehouses open for more than one year, including remodels, relocations and expansions, and sales related to e-commerce sites operating for more than one year. The measure is intended as supplemental information and is not a substitute for net sales presented in accordance with U.S. generally accepted accounting principles (U.S. GAAP) and should be reviewed in conjunction with results reported in accordance with U.S. GAAP. Comparable sales growth is achieved through increasing shopping frequency from new and existing members and the amount they spend on each visit (average ticket). Sales comparisons can also be particularly influenced by certain factors that are beyond our control: fluctuations in currency exchange rates (with respect to our international operations) and inflation or deflation in the cost of gasoline and associated competitive conditions. <!-- room16-lineage claim=COST_CLAIM_022 evidence=COST_NEWS_2025-10-08_27_KPI_01 -->
  Source labels: `SEC filing`.
- Issuer-filed business context: Net sales increased $20.287B or 8% during 2025. The improvement was primarily attributable to an increase in comparable sales of $14.788B or 6%. Comparable sales were positively impacted by increases of 5% in shopping frequency and approximately 1% in average ticket. The remaining increase in net sales was driven by sales at the 24 net new warehouses opened since the end of 2024. <!-- room16-lineage claim=COST_CLAIM_023 evidence=COST_NEWS_2025-10-08_29_KPI_01,COST_NEWS_2025-10-08_29_KPI_02,COST_NEWS_2025-10-08_29_KPI_03,COST_NEWS_2025-10-08_29_KPI_04,COST_NEWS_2025-10-08_29_KPI_05,COST_NEWS_2025-10-08_29_KPI_06,COST_NEWS_2025-10-08_29_KPI_07 -->
  Source labels: `SEC filing`.
- Issuer-filed business context: Membership fee revenue increased 10% in 2025, driven by new member sign-ups and membership fee increases. At the end of 2025, our member renewal rates were 92.3% in the U.S. and Canada and 89.8% worldwide. <!-- room16-lineage claim=COST_CLAIM_024 evidence=COST_NEWS_2025-10-08_31_KPI_01,COST_NEWS_2025-10-08_31_KPI_02,COST_NEWS_2025-10-08_31_KPI_03 -->
  Source labels: `SEC filing`.

## Fundamental Analysis
- COST's latest reported period FY2026_Q3 includes revenue of $70.53B, operating income of $2.81B and net income of $2.19B. Against the matching prior-year quarter, revenue increased by 11.6%, operating income increased by 11.3% and net income increased by 15.2%. These are arithmetic year-over-year comparisons, not causal conclusions. <!-- room16-lineage claim=COST_CLAIM_002 evidence=COST_SEC_revenue_FY2026_Q3_2026-02-16_2026-05-10_us-gaap_RevenueFromContractWithCustomerExcludingAssessedTax_0000909832-26-000051,COST_SEC_operating_income_FY2026_Q3_2026-02-16_2026-05-10_us-gaap_OperatingIncomeLoss_0000909832-26-000051,COST_SEC_net_income_FY2026_Q3_2026-02-16_2026-05-10_us-gaap_NetIncomeLoss_0000909832-26-000051,COST_DETERMINISTIC_CURRENT_PERIOD_REVENUE_GROWTH_YOY_2026-08-13,COST_DETERMINISTIC_CURRENT_PERIOD_OPERATING_INCOME_GROWTH_YOY_2026-08-13,COST_DETERMINISTIC_CURRENT_PERIOD_NET_INCOME_GROWTH_YOY_2026-08-13 -->
  Counterargument: One year-over-year comparison does not establish a durable multi-period trend.
  Investment implication: Use the latest period as current context, not as standalone evidence for an upgrade or downgrade.
  Source labels: `SEC filing, ROOM16_COST_DETERMINISTIC_CALCULATIONS`.
- For the latest reported period (year to date), COST generated $11.13B of operating cash flow and reported $4.23B of capital expenditure. <!-- room16-lineage claim=COST_CLAIM_003 evidence=COST_SEC_operating_cash_flow_FY2026_Q3_2025-09-01_2026-05-10_us-gaap_NetCashProvidedByUsedInOperatingActivities_0000909832-26-000051,COST_SEC_capex_FY2026_Q3_2025-09-01_2026-05-10_us-gaap_PaymentsToAcquirePropertyPlantAndEquipment_0000909832-26-000051 -->
  Counterargument: Year-to-date cash flow can be seasonal and is not the same measurement window as TTM free cash flow.
  Investment implication: Keep current cash generation visible while preserving the separate TTM valuation denominator.
  Source labels: `SEC filing`.
- FCF TTM is $8.81B. SBC equals 10.3% of that FCF, an arithmetic comparison that qualifies rather than invalidates the reported cash generation. <!-- room16-lineage claim=COST_CLAIM_030 evidence=COST_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13,COST_DETERMINISTIC_SBC_TO_FCF_2026-08-13 -->
  Counterargument: FCF may be company-defined or period-sensitive and can require reconciliation review.
  Investment implication: Treat FCF as a rating input only after its source, period and formula have passed validation.
  Source labels: `ROOM16_COST_DETERMINISTIC_CALCULATIONS`.
- TTM shareholder distributions are $3.19B; FCF exceeds shareholder distributions; the signed distributions-minus-FCF comparison is -$5.62B. This is an arithmetic comparison and does not identify a funding source. <!-- room16-lineage claim=COST_CLAIM_031 evidence=COST_DETERMINISTIC_SHAREHOLDER_DISTRIBUTIONS_TTM_2026-08-13,COST_DETERMINISTIC_SHAREHOLDER_DISTRIBUTIONS_MINUS_FCF_TTM_2026-08-13 -->
  Counterargument: This period surplus does not prove that every distribution was funded from FCF or that the relationship is durable.
  Investment implication: Capital-return sustainability should be discussed without inventing a financing bridge.
  Source labels: `ROOM16_COST_DETERMINISTIC_CALCULATIONS`.
- SBC/Revenue is 0.3%. The diluted weighted-average share count decreased by 0.1% against the matching prior-year period. This measures the net share-base change; it does not attribute the move solely to SBC or repurchases. Without a sector or lifecycle benchmark, this is a dilution input rather than evidence that SBC is high or low. <!-- room16-lineage claim=COST_CLAIM_032 evidence=COST_DETERMINISTIC_SBC_TO_REVENUE_2026-08-13,COST_DETERMINISTIC_DILUTED_SHARE_COUNT_YOY_2026-08-13 -->
  Counterargument: Sector and lifecycle matter, but persistent dilution can still reduce equity quality.
  Investment implication: Treat SBC as a risk modifier rather than an automatic rating override.
  Source labels: `ROOM16_COST_DETERMINISTIC_CALCULATIONS`.
- The balance-sheet position includes net cash of $14.33B and total debt of $5.67B. This is a liquidity input, not a standalone rating signal. <!-- room16-lineage claim=COST_CLAIM_033 evidence=COST_DETERMINISTIC_NET_CASH_2026-08-13,COST_DETERMINISTIC_TOTAL_DEBT_2026-08-13 -->
  Investment implication: Interpret liquidity or leverage only from the signed net position and its underlying debt evidence.
  Source labels: `ROOM16_COST_DETERMINISTIC_CALCULATIONS`.
- Separately disclosed available noncurrent lease liabilities are $2.47B; a complete lease-liability total is unavailable. Finance-lease amounts can overlap with issuer debt concepts, so this figure is not added to total debt or enterprise value here. <!-- room16-lineage claim=COST_CLAIM_034 evidence=COST_SEC_lease_liability_noncurrent_FY2026_Q3_instant_2026-05-10_us-gaap_OperatingLeaseLiabilityNoncurrent_0000909832-26-000051 -->
  Counterargument: Lease obligations can support normal operations and are not identical to unsecured borrowing.
  Investment implication: Assess debt, lease obligations, liquidity and cash-flow coverage together.
  Source labels: `SEC filing`.

## Capital Allocation, Transactions & Contingencies
- From 2025-09-01 through 2026-05-10, shareholder distributions were $1.76B versus Room16 normalized same-period FCF of $6.91B; distributions were covered by Room16 normalized same-period FCF with $5.15B remaining. No source-bound acquisition-cash component was available for this period. This is a period-matched capital-allocation bridge, not a TTM claim. <!-- room16-lineage claim=COST_CLAIM_004 evidence=COST_DETERMINISTIC_SHAREHOLDER_DISTRIBUTIONS_CURRENT_PERIOD_2026-08-13,COST_DETERMINISTIC_FREE_CASH_FLOW_CURRENT_PERIOD_2026-08-13,COST_DETERMINISTIC_SHAREHOLDER_DISTRIBUTIONS_MINUS_FCF_CURRENT_PERIOD_2026-08-13,COST_DETERMINISTIC_BUYBACKS_CURRENT_PERIOD_2026-08-13,COST_DETERMINISTIC_DIVIDENDS_PAID_CURRENT_PERIOD_2026-08-13 -->
  Counterargument: One interim period can be seasonal and does not establish a durable payout policy.
  Investment implication: Track repurchases, dividends and FCF on the same reporting window before judging funding pressure.
  Source labels: `ROOM16_COST_DETERMINISTIC_CALCULATIONS`.

## Valuation / Multiples
- EV/Sales is 1.40x, derived from enterprise value and TTM revenue. Without a validated peer, history or cycle benchmark, this records a multiple level but does not label the company cheap or expensive. <!-- room16-lineage claim=COST_CLAIM_035 evidence=COST_DETERMINISTIC_EV_TO_SALES_2026-08-13,COST_DETERMINISTIC_ENTERPRISE_VALUE_2026-08-13,COST_DETERMINISTIC_REVENUE_TTM_2026-08-13 -->
  Counterargument: A benchmark can change the interpretation, but must be present in the authority packet before it affects the rating.
  Investment implication: Treat EV/Sales as an observation until comparison evidence exists.
  Source labels: `ROOM16_COST_DETERMINISTIC_CALCULATIONS`.
- For COST, P/FCF is 48.44x, derived from market capitalization and TTM FCF. This records the cash-flow valuation level without labeling it cheap or expensive. <!-- room16-lineage claim=COST_CLAIM_036 evidence=COST_DETERMINISTIC_PRICE_TO_FCF_2026-08-13,COST_DETERMINISTIC_MARKET_CAP_2026-08-13,COST_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13 -->
  Investment implication: A valuation conclusion requires sector comparison and cash-flow durability evidence.
  Source labels: `ROOM16_COST_DETERMINISTIC_CALCULATIONS`.
- Standardized equity-DCF sensitivity, not a company forecast: bear $71.99B, base $145.11B and bull $342.60B. In the base case, discounted terminal value contributes 71.1% of scenario equity value, exposing the model's dependence on long-duration assumptions. The standardized reverse DCF implies a five-year FCF growth rate of 37.1% at a 10% discount rate and 2% terminal growth. <!-- room16-lineage claim=COST_CLAIM_037 evidence=COST_DETERMINISTIC_DCF_BEAR_EQUITY_VALUE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_EQUITY_VALUE_2026-08-13,COST_DETERMINISTIC_DCF_BULL_EQUITY_VALUE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_TERMINAL_VALUE_SHARE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_DISCOUNT_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_TERMINAL_GROWTH_RATE_2026-08-13,COST_DETERMINISTIC_REVERSE_DCF_GROWTH_2026-08-13 -->
  Counterargument: DCF results are highly sensitive to growth, discount-rate and terminal assumptions and require business-model review.
  Investment implication: Compare the current equity value with the whole range; do not treat the base case as a precise price target.
  Source labels: `ROOM16_COST_DETERMINISTIC_CALCULATIONS`.

## Technical Setup
- The technical setup records raw observations only: close $961.85, 50-SMA $950.59, 200-SMA $958.35 and RSI 55.88. No bullish, bearish or mixed technical conclusion is activated. Corporate-action adjustment is not confirmed, so no directional conclusion or numeric policy level is activated. <!-- room16-lineage claim=COST_CLAIM_038 evidence=COST_CSV_PRICE_CLOSE_2026-08-13,COST_DETERMINISTIC_CLOSE_2026-08-13,COST_DETERMINISTIC_SMA_50_2026-08-13,COST_DETERMINISTIC_SMA_200_2026-08-13,COST_DETERMINISTIC_RSI_14_2026-08-13 -->
  Investment implication: Do not use these raw observations for timing until the corporate-action adjustment is confirmed.
  Source labels: `COST_US_MARKET_DAILY_OHLCV`.
- COST's close of $961.85 and moving-average position record unscored raw moving-average observations; no bullish or bearish technical conclusion is activated because corporate-action adjustment is not confirmed; this does not prescribe an entry, trim or position size. <!-- room16-lineage claim=COST_CLAIM_039 evidence=COST_CSV_PRICE_CLOSE_2026-08-13,COST_DETERMINISTIC_CLOSE_2026-08-13,COST_DETERMINISTIC_SMA_50_2026-08-13,COST_DETERMINISTIC_SMA_200_2026-08-13,COST_DETERMINISTIC_RSI_14_2026-08-13 -->
  Counterargument: Technical weakness can be temporary if fundamentals and catalysts improve.
  Investment implication: No technical divergence or timing condition is activated until the price-series basis is confirmed.
  Source labels: `COST_US_MARKET_DAILY_OHLCV`.

## Bull Case
- Matching-quarter evidence shows revenue growth 11.6%, operating-income growth 11.3%, net-income growth 15.2%. Together with revenue TTM of $293.59B and FCF TTM of $8.81B, this records aligned current-period direction, scale and positive cash generation, but does not establish durability or cause. A more constructive rating still requires those comparisons to persist and stronger durable fundamental and benchmarked valuation support. <!-- room16-lineage claim=COST_CLAIM_040 evidence=COST_DETERMINISTIC_REVENUE_TTM_2026-08-13,COST_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13,COST_DETERMINISTIC_CURRENT_PERIOD_REVENUE_GROWTH_YOY_2026-08-13,COST_DETERMINISTIC_CURRENT_PERIOD_OPERATING_INCOME_GROWTH_YOY_2026-08-13,COST_DETERMINISTIC_CURRENT_PERIOD_NET_INCOME_GROWTH_YOY_2026-08-13 -->
  Counterargument: Reported comparisons and scale do not by themselves prove durable cash conversion or justify an unbenchmarked valuation.
  Investment implication: The bull case remains a research scenario, not an action plan.
  Source labels: `ROOM16_COST_DETERMINISTIC_CALCULATIONS`.
- No constructive technical bull path is activated for COST. The current RSI of 55.88 and moving-average observations remain unscored until the corporate-action adjustment is confirmed. <!-- room16-lineage claim=COST_CLAIM_041 evidence=COST_DETERMINISTIC_RSI_14_2026-08-13,COST_DETERMINISTIC_SMA_50_2026-08-13,COST_DETERMINISTIC_SMA_200_2026-08-13,COST_CSV_PRICE_CLOSE_2026-08-13,COST_DETERMINISTIC_CLOSE_2026-08-13 -->
  Investment implication: A more constructive research stance should require confirmation when the preferred rating is not Buy.
  Source labels: `COST_US_MARKET_DAILY_OHLCV`.

## Bear Case
- Separate balance-sheet or issuer-disclosed downside evidence anchors the bear case for COST. FCF TTM of $8.81B is counterevidence and the available evidence does not by itself prove current operating deterioration. Technical timing context is unscored raw moving-average observations; no bullish or bearish technical conclusion is activated because corporate-action adjustment is not confirmed; it does not establish operating deterioration or change the company rating. Issuer disclosure identifies a separate exposure: We may be unsuccessful implementing our growth strategy, including expanding our business in existing markets and new markets, and integrating acquisitions, which could have an adverse impact on our business, financial condition and results of operations. This identifies a risk, not evidence that the adverse outcome has occurred. <!-- room16-lineage claim=COST_CLAIM_042 evidence=COST_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13,COST_CSV_PRICE_CLOSE_2026-08-13,COST_DETERMINISTIC_CLOSE_2026-08-13,COST_DETERMINISTIC_SMA_50_2026-08-13,COST_DETERMINISTIC_SMA_200_2026-08-13,COST_DETERMINISTIC_RSI_14_2026-08-13,COST_SEC_RISK_000090983225000101_01 -->
  Investment implication: Treat the bear case as evidence to monitor, not as proof of permanent business deterioration.
  Source labels: `ROOM16_COST_DETERMINISTIC_CALCULATIONS, COST_US_MARKET_DAILY_OHLCV, SEC filing`.

## Key Risks
- Current issuer-filed risk context: two class actions were filed against the Company alleging violations of consumer protection and other laws arising from the Company’s sale of Kirkland Signature tequila products in the United States: Glazer v.. <!-- room16-lineage claim=COST_CLAIM_007 evidence=COST_NEWS_2026-06-03_05_NARRATIVE -->
  Source labels: `SEC filing`.
- Current issuer-filed risk context: four class actions were filed against the Company seeking a refund of tariffs paid by the Company under the International Emergency Economic Powers Act (“IEEPA”) that were passed on to members through higher prices.. <!-- room16-lineage claim=COST_CLAIM_008 evidence=COST_NEWS_2026-06-03_06_NARRATIVE -->
  Source labels: `SEC filing`.
- Current issuer-filed risk context: The Company does not believe that any pending claim, proceeding or litigation, either alone or in the aggregate, will have a material adverse effect on the Company’s financial position, results of operations or cash flows; it is possible that an unfavorable outcome of some or all of the matters, however unlikely, could result in a charge that might be material to the results of an individual fiscal quarter or year. <!-- room16-lineage claim=COST_CLAIM_009 evidence=COST_NEWS_2026-06-03_07 -->
  Source labels: `SEC filing`.
- Issuer-disclosed risk: We may be unsuccessful implementing our growth strategy, including expanding our business in existing markets and new markets, and integrating acquisitions, which could have an adverse impact on our business, financial condition and results of operations. This identifies an exposure; it does not establish that the adverse outcome has occurred. <!-- room16-lineage claim=COST_CLAIM_025 evidence=COST_SEC_RISK_000090983225000101_01 -->
  Source labels: `SEC filing`.
- Issuer-disclosed risk: Our failure to maintain membership growth, loyalty and brand recognition could adversely affect our results of operations. <!-- room16-lineage claim=COST_CLAIM_026 evidence=COST_SEC_RISK_000090983225000101_02 -->
  Source labels: `SEC filing`.
- Issuer-disclosed risk: Disruptions in merchandise distribution or processing, packaging, manufacturing, and other facilities could adversely affect sales and member satisfaction. <!-- room16-lineage claim=COST_CLAIM_027 evidence=COST_SEC_RISK_000090983225000101_03 -->
  Source labels: `SEC filing`.
- Issuer-disclosed risk: We may not timely identify or effectively respond to consumer tastes and preferences, which could negatively affect our relationship with our members, the demand for our products and services, and our market share. <!-- room16-lineage claim=COST_CLAIM_028 evidence=COST_SEC_RISK_000090983225000101_04 -->
  Source labels: `SEC filing`.
- The deterministic financial-risk screen is 23.3/100 (low measured financial-statement risk) with 100% financial-input coverage. The financial-input screen is complete. This is not a probability of loss; qualitative business-risk severity remains a human-review item. <!-- room16-lineage claim=COST_CLAIM_029 evidence=COST_DETERMINISTIC_FINANCIAL_RISK_SCORE_2026-08-13,COST_DETERMINISTIC_FINANCIAL_RISK_COVERAGE_2026-08-13 -->
  Counterargument: A financial-statement screen cannot quantify competitive, regulatory, governance or execution severity.
  Investment implication: Use the score as a comparable downside screen and review the issuer-disclosed risk factors separately.
  Source labels: `ROOM16_COST_DETERMINISTIC_CALCULATIONS`.

## Catalysts & Triggers
- The raw moving-average observations are 50-SMA $950.59 and 200-SMA $958.35. They are not validated support, resistance, risk or trigger levels because corporate-action adjustment is not confirmed. No separate evidence-backed price target is present in the packet. <!-- room16-lineage claim=COST_CLAIM_043 evidence=COST_DETERMINISTIC_SMA_50_2026-08-13,COST_DETERMINISTIC_SMA_200_2026-08-13 -->
  Investment implication: Withhold technical trigger language until the price-series basis is confirmed.
  Source labels: `COST_US_MARKET_DAILY_OHLCV`.

- Confirmed earnings date: `2026-09-24` via `COST_IR_Q4_2026_EARNINGS_CALL`.

## Scenario View
| Scenario | FCF growth | Discount rate | Terminal growth | Equity value |
| --- | ---: | ---: | ---: | ---: |
| Bear | -1.8% | 12.0% | 1.0% | $71.99B |
| Base | 8.2% | 10.0% | 2.0% | $145.11B |
| Bull | 18.2% | 8.0% | 3.0% | $342.60B |

These are standardized sensitivities, not management guidance or price targets.
The current `Provisional — Hold` stance does not change automatically with one model cell.
Table claim `DCF_SCENARIO_VIEW` · Evidence: `ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BASE_DISCOUNT_RATE, ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BASE_EQUITY_VALUE, ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BASE_FREE_CASH_FLOW_GROWTH_RATE, ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BASE_TERMINAL_GROWTH_RATE, ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BASE_TERMINAL_VALUE_SHARE, ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BEAR_DISCOUNT_RATE, ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BEAR_EQUITY_VALUE, ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BEAR_FREE_CASH_FLOW_GROWTH_RATE, ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BEAR_TERMINAL_GROWTH_RATE, ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BEAR_TERMINAL_VALUE_SHARE, ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BULL_DISCOUNT_RATE, ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BULL_EQUITY_VALUE, ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BULL_FREE_CASH_FLOW_GROWTH_RATE, ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BULL_TERMINAL_GROWTH_RATE, ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BULL_TERMINAL_VALUE_SHARE, COST_DETERMINISTIC_DCF_BEAR_EQUITY_VALUE_2026-08-13, COST_DETERMINISTIC_DCF_BEAR_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13, COST_DETERMINISTIC_DCF_BEAR_DISCOUNT_RATE_2026-08-13, COST_DETERMINISTIC_DCF_BEAR_TERMINAL_GROWTH_RATE_2026-08-13, COST_DETERMINISTIC_DCF_BEAR_TERMINAL_VALUE_SHARE_2026-08-13, COST_DETERMINISTIC_DCF_BASE_EQUITY_VALUE_2026-08-13, COST_DETERMINISTIC_DCF_BASE_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13, COST_DETERMINISTIC_DCF_BASE_TERMINAL_VALUE_SHARE_2026-08-13, COST_DETERMINISTIC_DCF_BULL_EQUITY_VALUE_2026-08-13, COST_DETERMINISTIC_DCF_BULL_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13, COST_DETERMINISTIC_DCF_BULL_DISCOUNT_RATE_2026-08-13, COST_DETERMINISTIC_DCF_BULL_TERMINAL_GROWTH_RATE_2026-08-13, COST_DETERMINISTIC_DCF_BULL_TERMINAL_VALUE_SHARE_2026-08-13, COST_DETERMINISTIC_DCF_BASE_DISCOUNT_RATE_2026-08-13, COST_DETERMINISTIC_DCF_BASE_TERMINAL_GROWTH_RATE_2026-08-13`.

## Final Rating & Action Plan
Final Rating: Provisional — Hold

- Why this rating? `Provisional — Hold`: Constructive fundamentals are not enough for an overweight rating without calibrated valuation evidence; unverified technical inputs are excluded from rating and timing.
- Fundamental anchors: revenue is `$293.59B` and FCF is `$8.81B`.
- Valuation status: standardized equity-DCF range `$71.99B` to `$342.60B`; illustrative and uncalibrated; outside the rating logic. The base case derives `71.1%` of value from discounted terminal value. The reverse DCF requires `37.1%` annual FCF growth for five years under standardized base assumptions. Observed P/FCF `48.44x`, trailing P/E `48.38x`, EV/Sales `1.40x`. The multiples are unbenchmarked observations. The DCF is screening evidence with material model uncertainty, not a price target, and no unbenchmarked multiple creates an automatic rating signal.
- Technical context: raw RSI is `55.88`; no direction or numeric timing level is activated because the price-series adjustment is not confirmed.
- Why not more constructive? A rating change requires stronger measured fundamentals and, where valuation is relevant, benchmark evidence. Technical confirmation is unavailable until the price-series basis is confirmed.
- Why not more cautious? A raw multiple or an isolated price signal cannot establish business deterioration.
- Review condition: retain `COST` at `Provisional — Hold` while the measured evidence state is unchanged; reassess the company rating only when new primary evidence changes fundamentals, calibrated valuation or issuer risk. Technical timing remains unavailable until the price-series basis is confirmed.

Research stance: Neutral bias pending stronger confirmation or a better risk/reward setup.

- We rate COST Provisional — Hold at the latest close of $961.85. Constructive fundamentals are not enough for an overweight rating without calibrated valuation evidence; unverified technical inputs are excluded from rating and timing. The factual anchors are revenue TTM of $293.59B, FCF TTM of $8.81B, EV/Sales of 1.40x. The measured fundamental signal is constructive. The standardized DCF is an uncalibrated illustration outside the rating logic and therefore does not move the rating. Valuation reconciliation: the standardized DCF spans $71.99B to $342.60B, with the current equity value positioned `above_model_range`. The base case derives 71.1% of value from the discounted terminal value, so model uncertainty is high and the DCF is screening evidence rather than a price target. The reverse DCF requires 37.1% annual FCF growth for five years under the standardized base assumptions; this is a market-implied expectation, not issuer guidance. Observed multiples are P/FCF 48.44x, trailing P/E 48.38x, EV/Sales 1.40x; they remain unbenchmarked observations. Without a validated peer, history or cycle benchmark, they do not independently move the rating. Separately, raw technical observations indicate unscored raw moving-average observations; no bullish or bearish technical conclusion is activated because corporate-action adjustment is not confirmed. They are excluded from rating and timing until the price-series basis is confirmed. The decision packet retains 3 current issuer-risk records; 3 include an explicit reassessment trigger. <!-- room16-lineage claim=COST_CLAIM_044 evidence=COST_CSV_PRICE_CLOSE_2026-08-13,COST_DETERMINISTIC_CLOSE_2026-08-13,COST_DETERMINISTIC_REVENUE_TTM_2026-08-13,COST_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13,COST_DETERMINISTIC_EV_TO_SALES_2026-08-13,COST_DETERMINISTIC_TRAILING_PE_2026-08-13,COST_DETERMINISTIC_PRICE_TO_FCF_2026-08-13,COST_DETERMINISTIC_DCF_BEAR_EQUITY_VALUE_2026-08-13,COST_DETERMINISTIC_DCF_BEAR_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BEAR_DISCOUNT_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BEAR_TERMINAL_GROWTH_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BEAR_TERMINAL_VALUE_SHARE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_EQUITY_VALUE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_DISCOUNT_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_TERMINAL_GROWTH_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_TERMINAL_VALUE_SHARE_2026-08-13,COST_DETERMINISTIC_DCF_BULL_EQUITY_VALUE_2026-08-13,COST_DETERMINISTIC_DCF_BULL_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BULL_DISCOUNT_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BULL_TERMINAL_GROWTH_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BULL_TERMINAL_VALUE_SHARE_2026-08-13,COST_DETERMINISTIC_REVERSE_DCF_GROWTH_2026-08-13,COST_NEWS_2026-06-03_05_NARRATIVE,COST_NEWS_2026-06-03_06_NARRATIVE,COST_NEWS_2026-06-03_07 -->
  Counterargument: A more bullish rating needs durable current-period evidence plus benchmarked valuation evidence; a more bearish rating needs deteriorating fundamentals or unresolved data errors.
  Investment implication: Reassess the Provisional — Hold research stance for COST only when new fundamental, calibrated valuation or issuer-risk evidence changes; technical timing remains unavailable until the price-series basis is confirmed.
  Source labels: `COST_US_MARKET_DAILY_OHLCV, ROOM16_COST_DETERMINISTIC_CALCULATIONS, SEC filing`.

## Rating Permission Appendix
Allowed ratings: Strong Buy, Buy, Accumulate, Hold, Tactical Trim, Tactical Underweight, Underweight, Sell, Avoid. Blocked ratings: .

## Evidence Appendix
| Claim ID | Evidence IDs | Source Type | Confidence | Metric Refs |
|---|---|---|---|---|
| COST_CLAIM_001 | COST_CSV_PRICE_CLOSE_2026-08-13, COST_DETERMINISTIC_CLOSE_2026-08-13, COST_DETERMINISTIC_REVENUE_TTM_2026-08-13, COST_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13, COST_DETERMINISTIC_EV_TO_SALES_2026-08-13 | deterministic_calculation, exchange_ohlcv | high | close, revenue_ttm, free_cash_flow_ttm, ev_to_sales |
| COST_CLAIM_002 | COST_SEC_revenue_FY2026_Q3_2026-02-16_2026-05-10_us-gaap_RevenueFromContractWithCustomerExcludingAssessedTax_0000909832-26-000051, COST_SEC_operating_income_FY2026_Q3_2026-02-16_2026-05-10_us-gaap_OperatingIncomeLoss_0000909832-26-000051, COST_SEC_net_income_FY2026_Q3_2026-02-16_2026-05-10_us-gaap_NetIncomeLoss_0000909832-26-000051, COST_DETERMINISTIC_CURRENT_PERIOD_REVENUE_GROWTH_YOY_2026-08-13, COST_DETERMINISTIC_CURRENT_PERIOD_OPERATING_INCOME_GROWTH_YOY_2026-08-13, COST_DETERMINISTIC_CURRENT_PERIOD_NET_INCOME_GROWTH_YOY_2026-08-13 | deterministic_calculation, sec_filing | high | revenue, operating_income, net_income, current_period_revenue_growth_yoy, current_period_operating_income_growth_yoy, current_period_net_income_growth_yoy |
| COST_CLAIM_003 | COST_SEC_operating_cash_flow_FY2026_Q3_2025-09-01_2026-05-10_us-gaap_NetCashProvidedByUsedInOperatingActivities_0000909832-26-000051, COST_SEC_capex_FY2026_Q3_2025-09-01_2026-05-10_us-gaap_PaymentsToAcquirePropertyPlantAndEquipment_0000909832-26-000051 | sec_filing | high | operating_cash_flow, capex |
| COST_CLAIM_004 | COST_DETERMINISTIC_SHAREHOLDER_DISTRIBUTIONS_CURRENT_PERIOD_2026-08-13, COST_DETERMINISTIC_FREE_CASH_FLOW_CURRENT_PERIOD_2026-08-13, COST_DETERMINISTIC_SHAREHOLDER_DISTRIBUTIONS_MINUS_FCF_CURRENT_PERIOD_2026-08-13, COST_DETERMINISTIC_BUYBACKS_CURRENT_PERIOD_2026-08-13, COST_DETERMINISTIC_DIVIDENDS_PAID_CURRENT_PERIOD_2026-08-13 | deterministic_calculation | high | shareholder_distributions_current_period, free_cash_flow_current_period, shareholder_distributions_minus_fcf_current_period, buybacks_current_period, dividends_paid_current_period |
| COST_CLAIM_005 | COST_SEC_BUSINESS_000090983225000101_01 | sec_filing | high |  |
| COST_CLAIM_006 | COST_SEC_BUSINESS_000090983225000101_02 | sec_filing | high |  |
| COST_CLAIM_007 | COST_NEWS_2026-06-03_05_NARRATIVE | sec_filing | high |  |
| COST_CLAIM_008 | COST_NEWS_2026-06-03_06_NARRATIVE | sec_filing | high |  |
| COST_CLAIM_009 | COST_NEWS_2026-06-03_07 | sec_filing | high |  |
| COST_CLAIM_010 | COST_NEWS_2026-06-03_11_KPI_01, COST_NEWS_2026-06-03_11_KPI_02, COST_NEWS_2026-06-03_11_KPI_03, COST_NEWS_2026-06-03_11_KPI_04, COST_NEWS_2026-06-03_11_KPI_05, COST_NEWS_2026-06-03_11_KPI_06, COST_NEWS_2026-06-03_11_KPI_07, COST_NEWS_2026-06-03_11_KPI_08, COST_NEWS_2026-06-03_11_KPI_09, COST_NEWS_2026-06-03_11_KPI_10, COST_NEWS_2026-06-03_11_KPI_11, COST_NEWS_2026-06-03_11_KPI_12, COST_NEWS_2026-06-03_11_KPI_13 | sec_filing | high | operating_kpi_revenue_yoy_change_12w_2026-05-10_amount, operating_kpi_revenue_yoy_change_12w_2026-05-10_ratio, operating_kpi_revenue_yoy_change_36w_2026-05-10_amount, operating_kpi_revenue_yoy_change_36w_2026-05-10_ratio, operating_kpi_comparable_sales_yoy_change_12w_2026-05-10_amount, operating_kpi_comparable_sales_yoy_change_12w_2026-05-10_ratio, operating_kpi_comparable_sales_yoy_change_36w_2026-05-10_amount, operating_kpi_comparable_sales_yoy_change_36w_2026-05-10_ratio, operating_kpi_average_ticket_yoy_change_12w_2026-05-10_ratio, operating_kpi_average_ticket_yoy_change_36w_2026-05-10_ratio, operating_kpi_traffic_frequency_yoy_change_12w_2026-05-10_ratio, operating_kpi_traffic_frequency_yoy_change_36w_2026-05-10_ratio, operating_kpi_net_new_warehouses_yoy_change_12w_2026-05-10 |
| COST_CLAIM_011 | COST_NEWS_2026-06-03_14_KPI_01, COST_NEWS_2026-06-03_14_KPI_02 | sec_filing | high | operating_kpi_paid_members_asof_2026-05-10_12w_ended_2026_05_10, operating_kpi_paid_members_asof_2025-05-11_12w_ended_2025_05_11 |
| COST_CLAIM_012 | COST_NEWS_2026-06-03_15_KPI_01, COST_NEWS_2026-06-03_15_KPI_02 | sec_filing | high | operating_kpi_cardholders_asof_2026-05-10_12w_ended_2026_05_10, operating_kpi_cardholders_asof_2025-05-11_12w_ended_2025_05_11 |
| COST_CLAIM_013 | COST_NEWS_2026-06-03_16_KPI_01, COST_NEWS_2026-06-03_16_KPI_02, COST_NEWS_2026-06-03_16_KPI_03, COST_NEWS_2026-06-03_16_KPI_04 | sec_filing | high | operating_kpi_membership_fee_revenue_yoy_change_12w_2026-05-10_ratio, operating_kpi_membership_fee_revenue_yoy_change_36w_2026-05-10_ratio, operating_kpi_renewal_rate_asof_2026-05-10_us_canada_ratio, operating_kpi_renewal_rate_asof_2026-05-10_worldwide_ratio |
| COST_CLAIM_014 | COST_NEWS_2025-10-08_18_KPI_01 | sec_filing | high | operating_kpi_membership_reward_rate_12m_2025-08-31_ratio |
| COST_CLAIM_015 | COST_NEWS_2025-10-08_19_KPI_01 | sec_filing | high | operating_kpi_digital_sales_12m_2025-08-31_fy2025_ratio |
| COST_CLAIM_016 | COST_NEWS_2025-10-08_20_KPI_01 | sec_filing | high | operating_kpi_membership_annual_fee_12m_2025-08-31_amount |
| COST_CLAIM_017 | COST_NEWS_2025-10-08_21_KPI_01, COST_NEWS_2025-10-08_21_KPI_02, COST_NEWS_2025-10-08_21_KPI_03, COST_NEWS_2025-10-08_21_KPI_04 | sec_filing | high | operating_kpi_membership_annual_fee_12m_2025-08-31_amount, operating_kpi_membership_reward_rate_12m_2025-08-31_ratio, operating_kpi_membership_reward_cap_12m_2025-08-31_amount, operating_kpi_executive_member_sales_penetration_12m_2025-08-31_fy2025_ratio |
| COST_CLAIM_018 | COST_NEWS_2025-10-08_22_KPI_01, COST_NEWS_2025-10-08_22_KPI_02, COST_NEWS_2025-10-08_22_KPI_03 | sec_filing | high | operating_kpi_total_paid_members_asof_2025-08-31_reported_value, operating_kpi_total_paid_members_asof_2024-08-31_reported_value, operating_kpi_total_paid_members_asof_2023-08-31_reported_value |
| COST_CLAIM_019 | COST_NEWS_2025-10-08_23_KPI_01, COST_NEWS_2025-10-08_23_KPI_02, COST_NEWS_2025-10-08_23_KPI_03 | sec_filing | high | operating_kpi_total_cardholders_asof_2025-08-31_reported_value, operating_kpi_total_cardholders_asof_2024-08-31_reported_value, operating_kpi_total_cardholders_asof_2023-08-31_reported_value |
| COST_CLAIM_020 | COST_NEWS_2025-10-08_24_KPI_01, COST_NEWS_2025-10-08_24_KPI_02, COST_NEWS_2025-10-08_24_KPI_03 | sec_filing | high | operating_kpi_executive_members_asof_2025-08-31_fy2025, operating_kpi_executive_members_asof_2024-08-31_fy2024, operating_kpi_executive_members_asof_2023-08-31_fy2023_fy2025 |
| COST_CLAIM_021 | COST_NEWS_2025-10-08_25_KPI_01, COST_NEWS_2025-10-08_25_KPI_02 | sec_filing | high | operating_kpi_renewal_rate_asof_2025-08-31_us_canada_ratio, operating_kpi_renewal_rate_asof_2025-08-31_worldwide_ratio |
| COST_CLAIM_022 | COST_NEWS_2025-10-08_27_KPI_01 | sec_filing | high | operating_kpi_membership_reward_rate_12m_2025-08-31_ratio |
| COST_CLAIM_023 | COST_NEWS_2025-10-08_29_KPI_01, COST_NEWS_2025-10-08_29_KPI_02, COST_NEWS_2025-10-08_29_KPI_03, COST_NEWS_2025-10-08_29_KPI_04, COST_NEWS_2025-10-08_29_KPI_05, COST_NEWS_2025-10-08_29_KPI_06, COST_NEWS_2025-10-08_29_KPI_07 | sec_filing | high | operating_kpi_revenue_yoy_change_12m_2025-08-31_amount, operating_kpi_revenue_yoy_change_12m_2025-08-31_ratio, operating_kpi_comparable_sales_yoy_change_12m_2025-08-31_amount, operating_kpi_comparable_sales_yoy_change_12m_2025-08-31_ratio, operating_kpi_traffic_frequency_yoy_change_12m_2025-08-31_ratio, operating_kpi_average_ticket_yoy_change_12m_2025-08-31_ratio, operating_kpi_net_new_warehouses_12m_2025-08-31 |
| COST_CLAIM_024 | COST_NEWS_2025-10-08_31_KPI_01, COST_NEWS_2025-10-08_31_KPI_02, COST_NEWS_2025-10-08_31_KPI_03 | sec_filing | high | operating_kpi_membership_fee_revenue_yoy_change_12m_2025-08-31_fy2025_ratio, operating_kpi_renewal_rate_asof_2025-08-31_us_canada_ratio, operating_kpi_renewal_rate_asof_2025-08-31_worldwide_ratio |
| COST_CLAIM_025 | COST_SEC_RISK_000090983225000101_01 | sec_filing | high |  |
| COST_CLAIM_026 | COST_SEC_RISK_000090983225000101_02 | sec_filing | high |  |
| COST_CLAIM_027 | COST_SEC_RISK_000090983225000101_03 | sec_filing | high |  |
| COST_CLAIM_028 | COST_SEC_RISK_000090983225000101_04 | sec_filing | high |  |
| COST_CLAIM_029 | COST_DETERMINISTIC_FINANCIAL_RISK_SCORE_2026-08-13, COST_DETERMINISTIC_FINANCIAL_RISK_COVERAGE_2026-08-13 | deterministic_calculation | medium | financial_risk_score, financial_risk_coverage |
| COST_CLAIM_030 | COST_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13, COST_DETERMINISTIC_SBC_TO_FCF_2026-08-13 | deterministic_calculation | high | free_cash_flow_ttm, sbc_to_fcf |
| COST_CLAIM_031 | COST_DETERMINISTIC_SHAREHOLDER_DISTRIBUTIONS_TTM_2026-08-13, COST_DETERMINISTIC_SHAREHOLDER_DISTRIBUTIONS_MINUS_FCF_TTM_2026-08-13 | deterministic_calculation | high | shareholder_distributions_ttm, shareholder_distributions_minus_fcf_ttm |
| COST_CLAIM_032 | COST_DETERMINISTIC_SBC_TO_REVENUE_2026-08-13, COST_DETERMINISTIC_DILUTED_SHARE_COUNT_YOY_2026-08-13 | deterministic_calculation | medium | sbc_to_revenue, diluted_share_count_yoy |
| COST_CLAIM_033 | COST_DETERMINISTIC_NET_CASH_2026-08-13, COST_DETERMINISTIC_TOTAL_DEBT_2026-08-13 | deterministic_calculation | medium | net_cash, total_debt |
| COST_CLAIM_034 | COST_SEC_lease_liability_noncurrent_FY2026_Q3_instant_2026-05-10_us-gaap_OperatingLeaseLiabilityNoncurrent_0000909832-26-000051 | sec_filing | medium | lease_liability_noncurrent |
| COST_CLAIM_035 | COST_DETERMINISTIC_EV_TO_SALES_2026-08-13, COST_DETERMINISTIC_ENTERPRISE_VALUE_2026-08-13, COST_DETERMINISTIC_REVENUE_TTM_2026-08-13 | deterministic_calculation | medium | ev_to_sales, enterprise_value, revenue_ttm |
| COST_CLAIM_036 | COST_DETERMINISTIC_PRICE_TO_FCF_2026-08-13, COST_DETERMINISTIC_MARKET_CAP_2026-08-13, COST_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13 | deterministic_calculation | medium | price_to_fcf, market_cap, free_cash_flow_ttm |
| COST_CLAIM_037 | COST_DETERMINISTIC_DCF_BEAR_EQUITY_VALUE_2026-08-13, COST_DETERMINISTIC_DCF_BASE_EQUITY_VALUE_2026-08-13, COST_DETERMINISTIC_DCF_BULL_EQUITY_VALUE_2026-08-13, COST_DETERMINISTIC_DCF_BASE_TERMINAL_VALUE_SHARE_2026-08-13, COST_DETERMINISTIC_DCF_BASE_DISCOUNT_RATE_2026-08-13, COST_DETERMINISTIC_DCF_BASE_TERMINAL_GROWTH_RATE_2026-08-13, COST_DETERMINISTIC_REVERSE_DCF_GROWTH_2026-08-13 | deterministic_calculation | medium | dcf_bear_equity_value, dcf_base_equity_value, dcf_bull_equity_value, dcf_base_terminal_value_share, dcf_base_discount_rate, dcf_base_terminal_growth_rate, reverse_dcf_implied_fcf_growth |
| COST_CLAIM_038 | COST_CSV_PRICE_CLOSE_2026-08-13, COST_DETERMINISTIC_CLOSE_2026-08-13, COST_DETERMINISTIC_SMA_50_2026-08-13, COST_DETERMINISTIC_SMA_200_2026-08-13, COST_DETERMINISTIC_RSI_14_2026-08-13 | exchange_ohlcv | high | close, sma_50, sma_200, rsi_14 |
| COST_CLAIM_039 | COST_CSV_PRICE_CLOSE_2026-08-13, COST_DETERMINISTIC_CLOSE_2026-08-13, COST_DETERMINISTIC_SMA_50_2026-08-13, COST_DETERMINISTIC_SMA_200_2026-08-13, COST_DETERMINISTIC_RSI_14_2026-08-13 | exchange_ohlcv | medium | close, sma_50, sma_200, rsi_14 |
| COST_CLAIM_040 | COST_DETERMINISTIC_REVENUE_TTM_2026-08-13, COST_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13, COST_DETERMINISTIC_CURRENT_PERIOD_REVENUE_GROWTH_YOY_2026-08-13, COST_DETERMINISTIC_CURRENT_PERIOD_OPERATING_INCOME_GROWTH_YOY_2026-08-13, COST_DETERMINISTIC_CURRENT_PERIOD_NET_INCOME_GROWTH_YOY_2026-08-13 | deterministic_calculation | medium | revenue_ttm, free_cash_flow_ttm, current_period_revenue_growth_yoy, current_period_operating_income_growth_yoy, current_period_net_income_growth_yoy |
| COST_CLAIM_041 | COST_DETERMINISTIC_RSI_14_2026-08-13, COST_DETERMINISTIC_SMA_50_2026-08-13, COST_DETERMINISTIC_SMA_200_2026-08-13, COST_CSV_PRICE_CLOSE_2026-08-13, COST_DETERMINISTIC_CLOSE_2026-08-13 | exchange_ohlcv | medium | rsi_14, sma_50, sma_200, close |
| COST_CLAIM_042 | COST_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13, COST_CSV_PRICE_CLOSE_2026-08-13, COST_DETERMINISTIC_CLOSE_2026-08-13, COST_DETERMINISTIC_SMA_50_2026-08-13, COST_DETERMINISTIC_SMA_200_2026-08-13, COST_DETERMINISTIC_RSI_14_2026-08-13, COST_SEC_RISK_000090983225000101_01 | deterministic_calculation, exchange_ohlcv, sec_filing | medium | free_cash_flow_ttm, close, sma_50, sma_200, rsi_14 |
| COST_CLAIM_043 | COST_DETERMINISTIC_SMA_50_2026-08-13, COST_DETERMINISTIC_SMA_200_2026-08-13 | exchange_ohlcv | medium | sma_50, sma_200 |
| COST_CLAIM_044 | COST_CSV_PRICE_CLOSE_2026-08-13, COST_DETERMINISTIC_CLOSE_2026-08-13, COST_DETERMINISTIC_REVENUE_TTM_2026-08-13, COST_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13, COST_DETERMINISTIC_EV_TO_SALES_2026-08-13, COST_DETERMINISTIC_TRAILING_PE_2026-08-13, COST_DETERMINISTIC_PRICE_TO_FCF_2026-08-13, COST_DETERMINISTIC_DCF_BEAR_EQUITY_VALUE_2026-08-13, COST_DETERMINISTIC_DCF_BEAR_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13, COST_DETERMINISTIC_DCF_BEAR_DISCOUNT_RATE_2026-08-13, COST_DETERMINISTIC_DCF_BEAR_TERMINAL_GROWTH_RATE_2026-08-13, COST_DETERMINISTIC_DCF_BEAR_TERMINAL_VALUE_SHARE_2026-08-13, COST_DETERMINISTIC_DCF_BASE_EQUITY_VALUE_2026-08-13, COST_DETERMINISTIC_DCF_BASE_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13, COST_DETERMINISTIC_DCF_BASE_DISCOUNT_RATE_2026-08-13, COST_DETERMINISTIC_DCF_BASE_TERMINAL_GROWTH_RATE_2026-08-13, COST_DETERMINISTIC_DCF_BASE_TERMINAL_VALUE_SHARE_2026-08-13, COST_DETERMINISTIC_DCF_BULL_EQUITY_VALUE_2026-08-13, COST_DETERMINISTIC_DCF_BULL_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13, COST_DETERMINISTIC_DCF_BULL_DISCOUNT_RATE_2026-08-13, COST_DETERMINISTIC_DCF_BULL_TERMINAL_GROWTH_RATE_2026-08-13, COST_DETERMINISTIC_DCF_BULL_TERMINAL_VALUE_SHARE_2026-08-13, COST_DETERMINISTIC_REVERSE_DCF_GROWTH_2026-08-13, COST_NEWS_2026-06-03_05_NARRATIVE, COST_NEWS_2026-06-03_06_NARRATIVE, COST_NEWS_2026-06-03_07 | deterministic_calculation, exchange_ohlcv, sec_filing | high | close, revenue_ttm, free_cash_flow_ttm, ev_to_sales, trailing_pe, price_to_fcf, dcf_bear_equity_value, dcf_bear_free_cash_flow_growth_rate, dcf_bear_discount_rate, dcf_bear_terminal_growth_rate, dcf_bear_terminal_value_share, dcf_base_equity_value, dcf_base_free_cash_flow_growth_rate, dcf_base_discount_rate, dcf_base_terminal_growth_rate, dcf_base_terminal_value_share, dcf_bull_equity_value, dcf_bull_free_cash_flow_growth_rate, dcf_bull_discount_rate, dcf_bull_terminal_growth_rate, dcf_bull_terminal_value_share, reverse_dcf_implied_fcf_growth |
