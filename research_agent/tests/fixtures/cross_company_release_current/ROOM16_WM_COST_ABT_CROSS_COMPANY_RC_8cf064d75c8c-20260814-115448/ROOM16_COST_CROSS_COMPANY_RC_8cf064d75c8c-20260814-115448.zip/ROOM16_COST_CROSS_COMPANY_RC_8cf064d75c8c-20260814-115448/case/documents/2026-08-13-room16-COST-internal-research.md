# COST Research Report
## Instrument Identity
| Identity field | Verified value |
| --- | --- |
| Legal company name | COSTCO WHOLESALE CORP |
| Ticker | COST |
| Listing venue | Nasdaq |
| Jurisdiction | US / incorporation Washington (WA) |
| SEC CIK | 0000909832 |
| Reporting / price currency | USD |
| Analysis cutoff | 2026-08-13 |
| Price date | 2026-08-13 |
| ISIN | not available |
| WKN | not available |

## Executive Summary
COST enters the report at a frozen close of $961.85 with a Provisional — Hold stance. The available evidence anchors are revenue TTM of $293.59B, FCF TTM of $8.81B, EV/Sales of 1.40x; the technical evidence indicates unscored raw moving-average observations; no bullish or bearish technical conclusion is activated because corporate-action adjustment is not confirmed. The standardized DCF is an uncalibrated illustration outside the rating logic. The action language should stay consistent with the Provisional — Hold stance. <!-- room16-lineage claim=COST_CLAIM_001 evidence=COST_CSV_PRICE_CLOSE_2026-08-13,COST_DETERMINISTIC_CLOSE_2026-08-13,COST_DETERMINISTIC_REVENUE_TTM_2026-08-13,COST_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13,COST_DETERMINISTIC_EV_TO_SALES_2026-08-13 -->

The resulting stance is Provisional — Hold: the report weighs current fundamentals against valuation and cash-flow conversion. Technical inputs are unscored raw observations. They do not enter the rating or timing until corporate-action adjustment of the price series is confirmed.

## Investment Thesis
COST's central investment debate is whether revenue scale of $293.59B can translate into durable cash generation; positive FCF of $8.81B provides measured cash-conversion support. The Provisional — Hold stance combines a constructive fundamental signal with illustrative-only valuation evidence. Technical inputs are excluded from rating and timing because the price-series adjustment is unconfirmed.

**Issuer-specific proof test.**
**Paid members:** Reported evidence: Issuer-filed business context: Total paid members (000s)82,900: 12W ended 2026-05-10: 82.9 million; 12W ended 2025-05-11: 79.6 million; This is the source-bound operating test for the thesis. <!-- room16-lineage claim=COST_CLAIM_011 evidence=COST_NEWS_2026-06-03_14_KPI_01,COST_NEWS_2026-06-03_14_KPI_02 -->
**Cardholders:** Reported evidence: Issuer-filed business context: Total cardholders (000s)148,500: 12W ended 2026-05-10: 148.5 million; 12W ended 2025-05-11: 142.8 million; This is the source-bound operating test for the thesis. <!-- room16-lineage claim=COST_CLAIM_012 evidence=COST_NEWS_2026-06-03_15_KPI_01,COST_NEWS_2026-06-03_15_KPI_02 -->
**Renewal rate:** Reported evidence: Issuer-filed business context: Membership fee revenue increased 11% and 13% in the third quarter and first thirty-six weeks of 2026, driven by new member sign-ups, membership fee increases and upgrades to Executive Membership. At the end of the third quarter of 2026, our renewal rates were 92.2% in the U.S. and Canada and 89.7% worldwide; This is the source-bound operating test for the thesis. <!-- room16-lineage claim=COST_CLAIM_013 evidence=COST_NEWS_2026-06-03_16_KPI_01,COST_NEWS_2026-06-03_16_KPI_02,COST_NEWS_2026-06-03_16_KPI_03,COST_NEWS_2026-06-03_16_KPI_04 -->
**Comparable sales / traffic / ticket:** Reported evidence: Issuer-filed business context: Net sales increased $7.189B or 12%, and $17.894B or 10% during the third quarter and first thirty-six weeks of 2026; This is the source-bound operating test for the thesis. <!-- room16-lineage claim=COST_CLAIM_010 evidence=COST_NEWS_2026-06-03_11_KPI_01,COST_NEWS_2026-06-03_11_KPI_02,COST_NEWS_2026-06-03_11_KPI_03,COST_NEWS_2026-06-03_11_KPI_04,COST_NEWS_2026-06-03_11_KPI_05,COST_NEWS_2026-06-03_11_KPI_06,COST_NEWS_2026-06-03_11_KPI_07,COST_NEWS_2026-06-03_11_KPI_08,COST_NEWS_2026-06-03_11_KPI_09,COST_NEWS_2026-06-03_11_KPI_10,COST_NEWS_2026-06-03_11_KPI_11,COST_NEWS_2026-06-03_11_KPI_12,COST_NEWS_2026-06-03_11_KPI_13 -->
The thesis weakens if these source-bound drivers stop persisting or no longer translate into cash conversion.

Issuer-filed business context: We operate membership warehouses and e-commerce sites based on the concept that offering low prices on a limited selection of nationally-branded and private-label products in a wide range of categories will produce high sales volumes and rapid inventory turnover. <!-- room16-lineage claim=COST_CLAIM_005 evidence=COST_SEC_BUSINESS_000090983225000101_01 -->

Issuer-filed business context: Costco Travel offers vacation packages, car rentals, cruises and other travel products exclusively for Costco members (offered to varying degrees in the U.S., Canada, Australia, and the U.K.). <!-- room16-lineage claim=COST_CLAIM_006 evidence=COST_SEC_BUSINESS_000090983225000101_02 -->

## Current Period KPIs
COST's latest reported period FY2026_Q3 includes revenue of $70.53B, operating income of $2.81B and net income of $2.19B. Against the matching prior-year quarter, revenue increased by 11.6%, operating income increased by 11.3% and net income increased by 15.2%. These are arithmetic year-over-year comparisons, not causal conclusions. One year-over-year comparison does not establish a durable multi-period trend. Use the latest period as current context, not as standalone evidence for an upgrade or downgrade. <!-- room16-lineage claim=COST_CLAIM_002 evidence=COST_SEC_revenue_FY2026_Q3_2026-02-16_2026-05-10_us-gaap_RevenueFromContractWithCustomerExcludingAssessedTax_0000909832-26-000051,COST_SEC_operating_income_FY2026_Q3_2026-02-16_2026-05-10_us-gaap_OperatingIncomeLoss_0000909832-26-000051,COST_SEC_net_income_FY2026_Q3_2026-02-16_2026-05-10_us-gaap_NetIncomeLoss_0000909832-26-000051,COST_DETERMINISTIC_CURRENT_PERIOD_REVENUE_GROWTH_YOY_2026-08-13,COST_DETERMINISTIC_CURRENT_PERIOD_OPERATING_INCOME_GROWTH_YOY_2026-08-13,COST_DETERMINISTIC_CURRENT_PERIOD_NET_INCOME_GROWTH_YOY_2026-08-13 -->

For the latest reported period (year to date), COST generated $11.13B of operating cash flow and reported $4.23B of capital expenditure. Year-to-date cash flow can be seasonal and is not the same measurement window as TTM free cash flow. Keep current cash generation visible while preserving the separate TTM valuation denominator. <!-- room16-lineage claim=COST_CLAIM_003 evidence=COST_SEC_operating_cash_flow_FY2026_Q3_2025-09-01_2026-05-10_us-gaap_NetCashProvidedByUsedInOperatingActivities_0000909832-26-000051,COST_SEC_capex_FY2026_Q3_2025-09-01_2026-05-10_us-gaap_PaymentsToAcquirePropertyPlantAndEquipment_0000909832-26-000051 -->

## Operating Drivers & Capital Allocation
- **Paid members:** Issuer-filed business context: Total paid members (000s)82,900: 12W ended 2026-05-10: 82.9 million; 12W ended 2025-05-11: 79.6 million. <!-- room16-lineage claim=COST_CLAIM_011 evidence=COST_NEWS_2026-06-03_14_KPI_01,COST_NEWS_2026-06-03_14_KPI_02 -->
- **Cardholders:** Issuer-filed business context: Total cardholders (000s)148,500: 12W ended 2026-05-10: 148.5 million; 12W ended 2025-05-11: 142.8 million. <!-- room16-lineage claim=COST_CLAIM_012 evidence=COST_NEWS_2026-06-03_15_KPI_01,COST_NEWS_2026-06-03_15_KPI_02 -->
- **Renewal rate:** Issuer-filed business context: Membership fee revenue increased 11% and 13% in the third quarter and first thirty-six weeks of 2026, driven by new member sign-ups, membership fee increases and upgrades to Executive Membership. At the end of the third quarter of 2026, our renewal rates were 92.2% in the U.S. and Canada and 89.7% worldwide. Renewal rates were negatively impacted by a higher number of memberships sold online, including through digital promotions, entering the renewal rate calculation. These memberships renew at a slightly lower rate on average. <!-- room16-lineage claim=COST_CLAIM_013 evidence=COST_NEWS_2026-06-03_16_KPI_01,COST_NEWS_2026-06-03_16_KPI_02,COST_NEWS_2026-06-03_16_KPI_03,COST_NEWS_2026-06-03_16_KPI_04 -->
- **Comparable sales / traffic / ticket:** Issuer-filed business context: Net sales increased $7.189B or 12%, and $17.894B or 10% during the third quarter and first thirty-six weeks of 2026. The improvement was primarily attributable to an increase in comparable sales of $6.055B or 10% and $14.553B or 8% during the third quarter and thirty-six weeks of 2026. Comparable sales were positively impacted by increases of approximately 7% and 5% in average ticket and 2% and 3% in shopping frequency in the third quarter and first thirty-six weeks of 2026. The remaining increase was driven by sales at the 23 net new warehouses opened since the end of the third quarter of 2025. <!-- room16-lineage claim=COST_CLAIM_010 evidence=COST_NEWS_2026-06-03_11_KPI_01,COST_NEWS_2026-06-03_11_KPI_02,COST_NEWS_2026-06-03_11_KPI_03,COST_NEWS_2026-06-03_11_KPI_04,COST_NEWS_2026-06-03_11_KPI_05,COST_NEWS_2026-06-03_11_KPI_06,COST_NEWS_2026-06-03_11_KPI_07,COST_NEWS_2026-06-03_11_KPI_08,COST_NEWS_2026-06-03_11_KPI_09,COST_NEWS_2026-06-03_11_KPI_10,COST_NEWS_2026-06-03_11_KPI_11,COST_NEWS_2026-06-03_11_KPI_12,COST_NEWS_2026-06-03_11_KPI_13 -->
- **Digital sales:** Issuer-filed business context: Our other businesses sell products and services that largely complement our warehouse operations. Our e-commerce operations give members convenience and a broader selection of goods and services. Net sales for e-commerce represented approximately 7% of total net sales in 2025. <!-- room16-lineage claim=COST_CLAIM_015 evidence=COST_NEWS_2025-10-08_19_KPI_01 -->

## Fundamental Analysis
FCF TTM is $8.81B. SBC equals 10.3% of that FCF, an arithmetic comparison that qualifies rather than invalidates the reported cash generation. FCF may be company-defined or period-sensitive and can require reconciliation review. Treat FCF as a rating input only after its source, period and formula have passed validation. <!-- room16-lineage claim=COST_CLAIM_030 evidence=COST_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13,COST_DETERMINISTIC_SBC_TO_FCF_2026-08-13 -->

TTM shareholder distributions are $3.19B; FCF exceeds shareholder distributions; the signed distributions-minus-FCF comparison is -$5.62B. This is an arithmetic comparison and does not identify a funding source. This period surplus does not prove that every distribution was funded from FCF or that the relationship is durable. Capital-return sustainability should be discussed without inventing a financing bridge. <!-- room16-lineage claim=COST_CLAIM_031 evidence=COST_DETERMINISTIC_SHAREHOLDER_DISTRIBUTIONS_TTM_2026-08-13,COST_DETERMINISTIC_SHAREHOLDER_DISTRIBUTIONS_MINUS_FCF_TTM_2026-08-13 -->

SBC/Revenue is 0.3%. The diluted weighted-average share count decreased by 0.1% against the matching prior-year period. This measures the net share-base change; it does not attribute the move solely to SBC or repurchases. Without a sector or lifecycle benchmark, this is a dilution input rather than evidence that SBC is high or low. Sector and lifecycle matter, but persistent dilution can still reduce equity quality. Treat SBC as a risk modifier rather than an automatic rating override. <!-- room16-lineage claim=COST_CLAIM_032 evidence=COST_DETERMINISTIC_SBC_TO_REVENUE_2026-08-13,COST_DETERMINISTIC_DILUTED_SHARE_COUNT_YOY_2026-08-13 -->

The balance-sheet position includes net cash of $14.33B and total debt of $5.67B. This is a liquidity input, not a standalone rating signal. Interpret liquidity or leverage only from the signed net position and its underlying debt evidence. <!-- room16-lineage claim=COST_CLAIM_033 evidence=COST_DETERMINISTIC_NET_CASH_2026-08-13,COST_DETERMINISTIC_TOTAL_DEBT_2026-08-13 -->

Separately disclosed available noncurrent lease liabilities are $2.47B; a complete lease-liability total is unavailable. Finance-lease amounts can overlap with issuer debt concepts, so this figure is not added to total debt or enterprise value here. Lease obligations can support normal operations and are not identical to unsecured borrowing. Assess debt, lease obligations, liquidity and cash-flow coverage together. <!-- room16-lineage claim=COST_CLAIM_034 evidence=COST_SEC_lease_liability_noncurrent_FY2026_Q3_instant_2026-05-10_us-gaap_OperatingLeaseLiabilityNoncurrent_0000909832-26-000051 -->

## Free Cash Flow Definitions
| Definition | Measurement window | Value | Use in this report |
|---|---|---:|---|
| Room16 normalized FCF (operating cash flow minus capital expenditure) | 2025-05-12 to 2026-05-10 | $8.81B | Valuation denominator and normalized cash-conversion analysis |
Room16 and issuer-defined FCF are separate measures. Differences can reflect measurement windows, capital-expenditure definitions, sustainability investments or other issuer adjustments.
<!-- room16-table-lineage id=FCF_DEFINITION_RECONCILIATION evidence=COST_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13 -->

## Capital Allocation, Transactions & Contingencies
From 2025-09-01 through 2026-05-10, shareholder distributions were $1.76B versus Room16 normalized same-period FCF of $6.91B; distributions were covered by Room16 normalized same-period FCF with $5.15B remaining. No source-bound acquisition-cash component was available for this period. This is a period-matched capital-allocation bridge, not a TTM claim. One interim period can be seasonal and does not establish a durable payout policy. Track repurchases, dividends and FCF on the same reporting window before judging funding pressure. <!-- room16-lineage claim=COST_CLAIM_004 evidence=COST_DETERMINISTIC_SHAREHOLDER_DISTRIBUTIONS_CURRENT_PERIOD_2026-08-13,COST_DETERMINISTIC_FREE_CASH_FLOW_CURRENT_PERIOD_2026-08-13,COST_DETERMINISTIC_SHAREHOLDER_DISTRIBUTIONS_MINUS_FCF_CURRENT_PERIOD_2026-08-13,COST_DETERMINISTIC_BUYBACKS_CURRENT_PERIOD_2026-08-13,COST_DETERMINISTIC_DIVIDENDS_PAID_CURRENT_PERIOD_2026-08-13 -->

## Valuation / Risk-Reward
EV/Sales is 1.40x, derived from enterprise value and TTM revenue. Without a validated peer, history or cycle benchmark, this records a multiple level but does not label the company cheap or expensive. A benchmark can change the interpretation, but must be present in the authority packet before it affects the rating. Treat EV/Sales as an observation until comparison evidence exists. <!-- room16-lineage claim=COST_CLAIM_035 evidence=COST_DETERMINISTIC_EV_TO_SALES_2026-08-13,COST_DETERMINISTIC_ENTERPRISE_VALUE_2026-08-13,COST_DETERMINISTIC_REVENUE_TTM_2026-08-13 -->

For COST, P/FCF is 48.44x, derived from market capitalization and TTM FCF. This records the cash-flow valuation level without labeling it cheap or expensive. A valuation conclusion requires sector comparison and cash-flow durability evidence. <!-- room16-lineage claim=COST_CLAIM_036 evidence=COST_DETERMINISTIC_PRICE_TO_FCF_2026-08-13,COST_DETERMINISTIC_MARKET_CAP_2026-08-13,COST_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13 -->

Standardized equity-DCF sensitivity, not a company forecast: bear $71.99B, base $145.11B and bull $342.60B. In the base case, discounted terminal value contributes 71.1% of scenario equity value, exposing the model's dependence on long-duration assumptions. The standardized reverse DCF implies a five-year FCF growth rate of 37.1% at a 10% discount rate and 2% terminal growth. DCF results are highly sensitive to growth, discount-rate and terminal assumptions and require business-model review. Compare the current equity value with the whole range; do not treat the base case as a precise price target. <!-- room16-lineage claim=COST_CLAIM_037 evidence=COST_DETERMINISTIC_DCF_BEAR_EQUITY_VALUE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_EQUITY_VALUE_2026-08-13,COST_DETERMINISTIC_DCF_BULL_EQUITY_VALUE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_TERMINAL_VALUE_SHARE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_DISCOUNT_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_TERMINAL_GROWTH_RATE_2026-08-13,COST_DETERMINISTIC_REVERSE_DCF_GROWTH_2026-08-13 -->

## Scenario / Sensitivity
| Scenario | FCF growth | Discount rate | Terminal growth | Valuation implication | Rating implication |
|---|---:|---:|---:|---:|---|
| Bear | -1.8% | 12.0% | 1.0% | Equity value $71.99B | Would weaken the case only if primary evidence supports the adverse assumptions |
| Base | 8.2% | 10.0% | 2.0% | Equity value $145.11B | No automatic change to the current Provisional — Hold research rating |
| Bull | 18.2% | 8.0% | 3.0% | Equity value $342.60B | The rating would become more constructive if primary evidence supports the assumptions |

The table is a standardized sensitivity, not management guidance or a precise price target.
<!-- room16-table-lineage id=DCF_SCENARIO_VIEW evidence=ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BASE_DISCOUNT_RATE,ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BASE_EQUITY_VALUE,ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BASE_FREE_CASH_FLOW_GROWTH_RATE,ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BASE_TERMINAL_GROWTH_RATE,ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BASE_TERMINAL_VALUE_SHARE,ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BEAR_DISCOUNT_RATE,ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BEAR_EQUITY_VALUE,ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BEAR_FREE_CASH_FLOW_GROWTH_RATE,ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BEAR_TERMINAL_GROWTH_RATE,ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BEAR_TERMINAL_VALUE_SHARE,ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BULL_DISCOUNT_RATE,ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BULL_EQUITY_VALUE,ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BULL_FREE_CASH_FLOW_GROWTH_RATE,ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BULL_TERMINAL_GROWTH_RATE,ROOM16_COST_DETERMINISTIC_CALCULATIONS_DCF_BULL_TERMINAL_VALUE_SHARE,COST_DETERMINISTIC_DCF_BEAR_EQUITY_VALUE_2026-08-13,COST_DETERMINISTIC_DCF_BEAR_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BEAR_DISCOUNT_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BEAR_TERMINAL_GROWTH_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BEAR_TERMINAL_VALUE_SHARE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_EQUITY_VALUE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_TERMINAL_VALUE_SHARE_2026-08-13,COST_DETERMINISTIC_DCF_BULL_EQUITY_VALUE_2026-08-13,COST_DETERMINISTIC_DCF_BULL_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BULL_DISCOUNT_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BULL_TERMINAL_GROWTH_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BULL_TERMINAL_VALUE_SHARE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_DISCOUNT_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_TERMINAL_GROWTH_RATE_2026-08-13 -->

## Technical Setup
The technical setup records raw observations only: close $961.85, 50-SMA $950.59, 200-SMA $958.35 and RSI 55.88. No bullish, bearish or mixed technical conclusion is activated. Corporate-action adjustment is not confirmed, so no directional conclusion or numeric policy level is activated. Do not use these raw observations for timing until the corporate-action adjustment is confirmed. <!-- room16-lineage claim=COST_CLAIM_038 evidence=COST_CSV_PRICE_CLOSE_2026-08-13,COST_DETERMINISTIC_CLOSE_2026-08-13,COST_DETERMINISTIC_SMA_50_2026-08-13,COST_DETERMINISTIC_SMA_200_2026-08-13,COST_DETERMINISTIC_RSI_14_2026-08-13 -->

COST's close of $961.85 and moving-average position record unscored raw moving-average observations; no bullish or bearish technical conclusion is activated because corporate-action adjustment is not confirmed; this does not prescribe an entry, trim or position size. Technical weakness can be temporary if fundamentals and catalysts improve. No technical divergence or timing condition is activated until the price-series basis is confirmed. <!-- room16-lineage claim=COST_CLAIM_039 evidence=COST_CSV_PRICE_CLOSE_2026-08-13,COST_DETERMINISTIC_CLOSE_2026-08-13,COST_DETERMINISTIC_SMA_50_2026-08-13,COST_DETERMINISTIC_SMA_200_2026-08-13,COST_DETERMINISTIC_RSI_14_2026-08-13 -->

## Bull Case
Matching-quarter evidence shows revenue growth 11.6%, operating-income growth 11.3%, net-income growth 15.2%. Together with revenue TTM of $293.59B and FCF TTM of $8.81B, this records aligned current-period direction, scale and positive cash generation, but does not establish durability or cause. A more constructive rating still requires those comparisons to persist and stronger durable fundamental and benchmarked valuation support. Reported comparisons and scale do not by themselves prove durable cash conversion or justify an unbenchmarked valuation. The bull case remains a research scenario, not an action plan. <!-- room16-lineage claim=COST_CLAIM_040 evidence=COST_DETERMINISTIC_REVENUE_TTM_2026-08-13,COST_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13,COST_DETERMINISTIC_CURRENT_PERIOD_REVENUE_GROWTH_YOY_2026-08-13,COST_DETERMINISTIC_CURRENT_PERIOD_OPERATING_INCOME_GROWTH_YOY_2026-08-13,COST_DETERMINISTIC_CURRENT_PERIOD_NET_INCOME_GROWTH_YOY_2026-08-13 -->

No constructive technical bull path is activated for COST. The current RSI of 55.88 and moving-average observations remain unscored until the corporate-action adjustment is confirmed. A more constructive research stance should require confirmation when the preferred rating is not Buy. <!-- room16-lineage claim=COST_CLAIM_041 evidence=COST_DETERMINISTIC_RSI_14_2026-08-13,COST_DETERMINISTIC_SMA_50_2026-08-13,COST_DETERMINISTIC_SMA_200_2026-08-13,COST_CSV_PRICE_CLOSE_2026-08-13,COST_DETERMINISTIC_CLOSE_2026-08-13 -->

**Issuer-specific confirmation path.**
**Paid members:** Reported evidence: Issuer-filed business context: Total paid members (000s)82,900: 12W ended 2026-05-10: 82.9 million; 12W ended 2025-05-11: 79.6 million; The next comparable filing must confirm the stated improvement. <!-- room16-lineage claim=COST_CLAIM_011 evidence=COST_NEWS_2026-06-03_14_KPI_01,COST_NEWS_2026-06-03_14_KPI_02 -->
**Cardholders:** Reported evidence: Issuer-filed business context: Total cardholders (000s)148,500: 12W ended 2026-05-10: 148.5 million; 12W ended 2025-05-11: 142.8 million; The next comparable filing must confirm the stated improvement. <!-- room16-lineage claim=COST_CLAIM_012 evidence=COST_NEWS_2026-06-03_15_KPI_01,COST_NEWS_2026-06-03_15_KPI_02 -->
**Renewal rate:** Reported evidence: Issuer-filed business context: Membership fee revenue increased 11% and 13% in the third quarter and first thirty-six weeks of 2026, driven by new member sign-ups, membership fee increases and upgrades to Executive Membership. At the end of the third quarter of 2026, our renewal rates were 92.2% in the U.S. and Canada and 89.7% worldwide; The next comparable filing must confirm the stated improvement. <!-- room16-lineage claim=COST_CLAIM_013 evidence=COST_NEWS_2026-06-03_16_KPI_01,COST_NEWS_2026-06-03_16_KPI_02,COST_NEWS_2026-06-03_16_KPI_03,COST_NEWS_2026-06-03_16_KPI_04 -->
**Comparable sales / traffic / ticket:** Reported evidence: Issuer-filed business context: Net sales increased $7.189B or 12%, and $17.894B or 10% during the third quarter and first thirty-six weeks of 2026; The next comparable filing must confirm the stated improvement. <!-- room16-lineage claim=COST_CLAIM_010 evidence=COST_NEWS_2026-06-03_11_KPI_01,COST_NEWS_2026-06-03_11_KPI_02,COST_NEWS_2026-06-03_11_KPI_03,COST_NEWS_2026-06-03_11_KPI_04,COST_NEWS_2026-06-03_11_KPI_05,COST_NEWS_2026-06-03_11_KPI_06,COST_NEWS_2026-06-03_11_KPI_07,COST_NEWS_2026-06-03_11_KPI_08,COST_NEWS_2026-06-03_11_KPI_09,COST_NEWS_2026-06-03_11_KPI_10,COST_NEWS_2026-06-03_11_KPI_11,COST_NEWS_2026-06-03_11_KPI_12,COST_NEWS_2026-06-03_11_KPI_13 -->
A stronger case requires these issuer-bound signals to confirm one another and continue converting into cash.

## Bear Case
Separate balance-sheet or issuer-disclosed downside evidence anchors the bear case for COST. FCF TTM of $8.81B is counterevidence and the available evidence does not by itself prove current operating deterioration. Technical timing context is unscored raw moving-average observations; no bullish or bearish technical conclusion is activated because corporate-action adjustment is not confirmed; it does not establish operating deterioration or change the company rating. Issuer disclosure identifies a separate exposure: We may be unsuccessful implementing our growth strategy, including expanding our business in existing markets and new markets, and integrating acquisitions, which could have an adverse impact on our business, financial condition and results of operations. This identifies a risk, not evidence that the adverse outcome has occurred. Treat the bear case as evidence to monitor, not as proof of permanent business deterioration. <!-- room16-lineage claim=COST_CLAIM_042 evidence=COST_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13,COST_CSV_PRICE_CLOSE_2026-08-13,COST_DETERMINISTIC_CLOSE_2026-08-13,COST_DETERMINISTIC_SMA_50_2026-08-13,COST_DETERMINISTIC_SMA_200_2026-08-13,COST_DETERMINISTIC_RSI_14_2026-08-13,COST_SEC_RISK_000090983225000101_01 -->

## Risks
Current issuer-filed risk context: two class actions were filed against the Company alleging violations of consumer protection and other laws arising from the Company’s sale of Kirkland Signature tequila products in the United States: Glazer v.. <!-- room16-lineage claim=COST_CLAIM_007 evidence=COST_NEWS_2026-06-03_05_NARRATIVE -->

Current issuer-filed risk context: four class actions were filed against the Company seeking a refund of tariffs paid by the Company under the International Emergency Economic Powers Act (“IEEPA”) that were passed on to members through higher prices.. <!-- room16-lineage claim=COST_CLAIM_008 evidence=COST_NEWS_2026-06-03_06_NARRATIVE -->

Current issuer-filed risk context: The Company does not believe that any pending claim, proceeding or litigation, either alone or in the aggregate, will have a material adverse effect on the Company’s financial position, results of operations or cash flows; it is possible that an unfavorable outcome of some or all of the matters, however unlikely, could result in a charge that might be material to the results of an individual fiscal quarter or year. <!-- room16-lineage claim=COST_CLAIM_009 evidence=COST_NEWS_2026-06-03_07 -->

Issuer-disclosed risk: We may be unsuccessful implementing our growth strategy, including expanding our business in existing markets and new markets, and integrating acquisitions, which could have an adverse impact on our business, financial condition and results of operations. This identifies an exposure; it does not establish that the adverse outcome has occurred. <!-- room16-lineage claim=COST_CLAIM_025 evidence=COST_SEC_RISK_000090983225000101_01 -->

Issuer-disclosed risk: Our failure to maintain membership growth, loyalty and brand recognition could adversely affect our results of operations. <!-- room16-lineage claim=COST_CLAIM_026 evidence=COST_SEC_RISK_000090983225000101_02 -->

## Catalysts
The raw moving-average observations are 50-SMA $950.59 and 200-SMA $958.35. They are not validated support, resistance, risk or trigger levels because corporate-action adjustment is not confirmed. No separate evidence-backed price target is present in the packet. Withhold technical trigger language until the price-series basis is confirmed. <!-- room16-lineage claim=COST_CLAIM_043 evidence=COST_DETERMINISTIC_SMA_50_2026-08-13,COST_DETERMINISTIC_SMA_200_2026-08-13 -->

## Final Rating & Review Conditions
Final Rating: Provisional — Hold. Constructive fundamentals are not enough for an overweight rating without calibrated valuation evidence; unverified technical inputs are excluded from rating and timing.

Factual anchors are revenue of $293.59B, FCF of $8.81B. Separately, raw technical observations include RSI of 55.88; direction and timing are not activated because corporate-action adjustment is not confirmed; raw indicators remain provisional observations.

The standardized equity-DCF range is $71.99B to $342.60B. It is an uncalibrated illustration outside the rating logic and does not create an automatic rating signal.

Why not more constructive? Constructive fundamentals and positive FCF are not enough without calibrated valuation support. Technical timing is unavailable until the price-series basis is confirmed.

Why not more cautious? Positive FCF and the constructive fundamental signal are measured counterevidence. A more cautious rating requires corroborating fundamental, valuation or issuer-risk deterioration. The rating already monitors these named current risks: Kirkland Signature tequila consumer class actions and dismissal motions; IEEPA tariff-refund consumer class actions and dismissal motions; Current filing contains a legal or contingency disclosure. A more cautious rating requires new primary evidence that their reserve, compliance, operating or cash-flow transmission outweighs the measured counterevidence; an issuer counterposition is context, not independent proof.

Review condition: retain the COST research rating while the measured evidence state is unchanged. Reassess only when new primary evidence changes fundamentals, calibrated valuation or issuer risk. Technical timing remains unavailable until the price-series basis is confirmed.

**Formal rating evidence binding:** <!-- room16-lineage claim=COST_CLAIM_044 evidence=COST_CSV_PRICE_CLOSE_2026-08-13,COST_DETERMINISTIC_CLOSE_2026-08-13,COST_DETERMINISTIC_REVENUE_TTM_2026-08-13,COST_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-13,COST_DETERMINISTIC_EV_TO_SALES_2026-08-13,COST_DETERMINISTIC_TRAILING_PE_2026-08-13,COST_DETERMINISTIC_PRICE_TO_FCF_2026-08-13,COST_DETERMINISTIC_DCF_BEAR_EQUITY_VALUE_2026-08-13,COST_DETERMINISTIC_DCF_BEAR_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BEAR_DISCOUNT_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BEAR_TERMINAL_GROWTH_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BEAR_TERMINAL_VALUE_SHARE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_EQUITY_VALUE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_DISCOUNT_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_TERMINAL_GROWTH_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BASE_TERMINAL_VALUE_SHARE_2026-08-13,COST_DETERMINISTIC_DCF_BULL_EQUITY_VALUE_2026-08-13,COST_DETERMINISTIC_DCF_BULL_FREE_CASH_FLOW_GROWTH_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BULL_DISCOUNT_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BULL_TERMINAL_GROWTH_RATE_2026-08-13,COST_DETERMINISTIC_DCF_BULL_TERMINAL_VALUE_SHARE_2026-08-13,COST_DETERMINISTIC_REVERSE_DCF_GROWTH_2026-08-13,COST_NEWS_2026-06-03_05_NARRATIVE,COST_NEWS_2026-06-03_06_NARRATIVE,COST_NEWS_2026-06-03_07 -->

## Data Limits & Review Status

- Internal status: `manual_review`.
- Public release: `blocked`.
- Active review points:
  - `BALANCE_SHEET_DATE_MISMATCH_EXCLUDED`: Excluded lease_liability_current from 2025-08-31 because the latest financial-statement balance date is 2026-05-10.

## Evidence Appendix
The complete claim text, evidence IDs, metric mappings and source IDs are stored in the separately hash-bound `analyst_claims.json`. This appendix is the compact human-readable index.

| Claim ID | Section | Claim Type | Evidence Count | Source Types | Confidence |
|---|---|---|---:|---|---|
| COST_CLAIM_001 | Executive Summary | rating | 5 | deterministic calculation, exchange ohlcv | high |
| COST_CLAIM_002 | Fundamental Analysis | financial metric | 6 | deterministic calculation, sec filing | high |
| COST_CLAIM_003 | Fundamental Analysis | financial metric | 2 | sec filing | high |
| COST_CLAIM_004 | Capital Allocation, Transactions & Contingencies | financial metric | 5 | deterministic calculation | high |
| COST_CLAIM_005 | Business & Segment Context | news | 1 | sec filing | high |
| COST_CLAIM_006 | Business & Segment Context | news | 1 | sec filing | high |
| COST_CLAIM_007 | Key Risks | risk | 1 | sec filing | high |
| COST_CLAIM_008 | Key Risks | risk | 1 | sec filing | high |
| COST_CLAIM_009 | Key Risks | risk | 1 | sec filing | high |
| COST_CLAIM_010 | Business & Segment Context | news | 13 | sec filing | high |
| COST_CLAIM_011 | Business & Segment Context | news | 2 | sec filing | high |
| COST_CLAIM_012 | Business & Segment Context | news | 2 | sec filing | high |
| COST_CLAIM_013 | Business & Segment Context | news | 4 | sec filing | high |
| COST_CLAIM_014 | Business & Segment Context | news | 1 | sec filing | high |
| COST_CLAIM_015 | Business & Segment Context | news | 1 | sec filing | high |
| COST_CLAIM_016 | Business & Segment Context | news | 1 | sec filing | high |
| COST_CLAIM_017 | Business & Segment Context | news | 4 | sec filing | high |
| COST_CLAIM_018 | Business & Segment Context | news | 3 | sec filing | high |
| COST_CLAIM_019 | Business & Segment Context | news | 3 | sec filing | high |
| COST_CLAIM_020 | Business & Segment Context | news | 3 | sec filing | high |
| COST_CLAIM_021 | Business & Segment Context | news | 2 | sec filing | high |
| COST_CLAIM_022 | Business & Segment Context | news | 1 | sec filing | high |
| COST_CLAIM_023 | Business & Segment Context | news | 7 | sec filing | high |
| COST_CLAIM_024 | Business & Segment Context | news | 3 | sec filing | high |
| COST_CLAIM_025 | Key Risks | risk | 1 | sec filing | high |
| COST_CLAIM_026 | Key Risks | risk | 1 | sec filing | high |
| COST_CLAIM_027 | Key Risks | risk | 1 | sec filing | high |
| COST_CLAIM_028 | Key Risks | risk | 1 | sec filing | high |
| COST_CLAIM_029 | Key Risks | risk | 2 | deterministic calculation | medium |
| COST_CLAIM_030 | Fundamental Analysis | financial metric | 2 | deterministic calculation | high |
| COST_CLAIM_031 | Fundamental Analysis | financial metric | 2 | deterministic calculation | high |
| COST_CLAIM_032 | Fundamental Analysis | financial metric | 2 | deterministic calculation | medium |
| COST_CLAIM_033 | Fundamental Analysis | financial metric | 2 | deterministic calculation | medium |
| COST_CLAIM_034 | Fundamental Analysis | financial metric | 1 | sec filing | medium |
| COST_CLAIM_035 | Valuation / Multiples | valuation metric | 3 | deterministic calculation | medium |
| COST_CLAIM_036 | Valuation / Multiples | valuation metric | 3 | deterministic calculation | medium |
| COST_CLAIM_037 | Valuation / Multiples | valuation metric | 7 | deterministic calculation | medium |
| COST_CLAIM_038 | Technical Setup | technical metric | 5 | exchange ohlcv | high |
| COST_CLAIM_039 | Technical Setup | technical metric | 5 | exchange ohlcv | medium |
| COST_CLAIM_040 | Bull Case | financial metric | 5 | deterministic calculation | medium |
| COST_CLAIM_041 | Bull Case | technical metric | 5 | exchange ohlcv | medium |
| COST_CLAIM_042 | Bear Case | financial metric | 7 | deterministic calculation, exchange ohlcv, sec filing | medium |
| COST_CLAIM_043 | Catalysts & Triggers | technical metric | 2 | exchange ohlcv | medium |
| COST_CLAIM_044 | Final Rating & Action Plan | rating | 26 | deterministic calculation, exchange ohlcv, sec filing | high |
