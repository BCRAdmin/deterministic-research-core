# WM Research Report
## Instrument Identity
| Identity field | Verified value |
| --- | --- |
| Legal company name | WASTE MANAGEMENT INC |
| Ticker | WM |
| Listing venue | NYSE |
| Jurisdiction | US / incorporation Delaware (DE) |
| SEC CIK | 0000823768 |
| Reporting / price currency | USD |
| Analysis cutoff | 2026-08-11 |
| Price date | 2026-08-11 |
| ISIN | not available |
| WKN | not available |

## Executive Summary
WM enters the report at a frozen close of $226.85 with a Provisional — Hold stance. The available evidence anchors are revenue TTM of $25.67B, FCF TTM of $3.57B, EV/Sales of 4.42x; the technical evidence indicates unscored raw moving-average observations; no bullish or bearish technical conclusion is activated because corporate-action adjustment is not confirmed. The standardized DCF is an uncalibrated illustration outside the rating logic. The action language should stay consistent with the Provisional — Hold stance. <!-- room16-lineage claim=WM_CLAIM_001 evidence=WM_CSV_PRICE_CLOSE_2026-08-11,WM_DETERMINISTIC_CLOSE_2026-08-11,WM_DETERMINISTIC_REVENUE_TTM_2026-08-11,WM_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-11,WM_DETERMINISTIC_EV_TO_SALES_2026-08-11 -->

The resulting stance is Provisional — Hold: the report weighs current fundamentals against valuation and cash-flow conversion. Technical inputs are unscored raw observations. They do not enter the rating or timing until corporate-action adjustment of the price series is confirmed.

## Investment Thesis
WM's central investment debate is whether revenue scale of $25.67B can translate into durable cash generation; positive FCF of $3.57B provides measured cash-conversion support. The Provisional — Hold stance combines a constructive fundamental signal with illustrative-only valuation evidence. Technical inputs are excluded from rating and timing because the price-series adjustment is unconfirmed.

**Issuer-specific proof test.**
**Pricing / yield:** Reported evidence: Issuer-filed business context: Our overall pricing efforts are focused on keeping pace with the increasing costs and capital intensity of our business; This is the source-bound operating test for the thesis. <!-- room16-lineage claim=WM_CLAIM_017 evidence=WM_NEWS_2026-07-29_14_KPI_01,WM_NEWS_2026-07-29_14_KPI_02 -->
**Volume:** Reported evidence: Issuer-filed business context: Our revenues from volume (excluding volumes from acquisitions and divestitures, as well as Healthcare Solutions) decreased $22 million, or 0.3%, and $10 million, or 0.1%, for the three and six months ended June 30, 2026, respectively, as compared to the prior year periods; This is the source-bound operating test for the thesis. <!-- room16-lineage claim=WM_CLAIM_018 evidence=WM_NEWS_2026-07-29_15_KPI_01,WM_NEWS_2026-07-29_15_KPI_02,WM_NEWS_2026-07-29_15_KPI_03,WM_NEWS_2026-07-29_15_KPI_04 -->
**Margin:** Reported evidence: Issuer-filed business context: “Second quarter earnings growth, margin expansion, and cash flow generation reflect the strength of our business model and consistent execution from the WM team,” said Jim Fish, WM’s CEO; This is the source-bound operating test for the thesis. <!-- room16-lineage claim=WM_CLAIM_024 evidence=WM_NEWS_2026-07-28_32_KPI_01,WM_NEWS_2026-07-28_32_KPI_02 -->
The thesis weakens if these source-bound drivers stop persisting or no longer translate into cash conversion.

Issuer-filed business context: Waste Management, Inc. is a holding company and all operations are conducted by its subsidiaries. <!-- room16-lineage claim=WM_CLAIM_006 evidence=WM_SEC_BUSINESS_000110465926012049_01 -->

Issuer-filed business context: Our senior management evaluates, oversees and manages the financial performance of our business through five reportable segments, referred to as (i) Collection and Disposal - East Tier (“East Tier”); (ii) Collection and Disposal - West Tier (“West Tier”); (iii) Recycling Processing and Sales; (iv) Renewable Energy and (v) Healthcare Solutions. <!-- room16-lineage claim=WM_CLAIM_007 evidence=WM_SEC_BUSINESS_000110465926012049_02 -->

## Current Period KPIs
WM's latest reported period FY2026_Q2 includes revenue of $6.68B, operating income of $1.25B and net income of $785.0M. Against the matching prior-year quarter, revenue increased by 4.0%, operating income increased by 8.9% and net income increased by 8.1%. These are arithmetic year-over-year comparisons, not causal conclusions. One year-over-year comparison does not establish a durable multi-period trend. Use the latest period as current context, not as standalone evidence for an upgrade or downgrade. <!-- room16-lineage claim=WM_CLAIM_002 evidence=WM_SEC_revenue_FY2026_Q2_2026-04-01_2026-06-30_us-gaap_RevenueFromContractWithCustomerExcludingAssessedTax_0001104659-26-088016,WM_SEC_operating_income_FY2026_Q2_2026-04-01_2026-06-30_us-gaap_OperatingIncomeLoss_0001104659-26-088016,WM_SEC_net_income_FY2026_Q2_2026-04-01_2026-06-30_us-gaap_NetIncomeLoss_0001104659-26-088016,WM_DETERMINISTIC_CURRENT_PERIOD_REVENUE_GROWTH_YOY_2026-08-11,WM_DETERMINISTIC_CURRENT_PERIOD_OPERATING_INCOME_GROWTH_YOY_2026-08-11,WM_DETERMINISTIC_CURRENT_PERIOD_NET_INCOME_GROWTH_YOY_2026-08-11 -->

For the latest reported period (year to date), WM generated $3.23B of operating cash flow and reported $1.28B of capital expenditure. Year-to-date cash flow can be seasonal and is not the same measurement window as TTM free cash flow. Keep current cash generation visible while preserving the separate TTM valuation denominator. <!-- room16-lineage claim=WM_CLAIM_003 evidence=WM_SEC_operating_cash_flow_FY2026_Q2_2026-01-01_2026-06-30_us-gaap_NetCashProvidedByUsedInOperatingActivities_0001104659-26-088016,WM_SEC_capex_FY2026_Q2_2026-01-01_2026-06-30_us-gaap_PaymentsToAcquireProductiveAssets_0001104659-26-088016 -->

Issuer-filed business context: Operating EBITDA: Q2 2026 as reported: $2.03B; Q2 2026 as adjusted: $2.067B; Q2 2025 as reported: $1.895B; Q2 2025 as adjusted: $1.959B. <!-- room16-lineage claim=WM_CLAIM_023 evidence=WM_NEWS_2026-07-28_31_KPI_01,WM_NEWS_2026-07-28_31_KPI_02,WM_NEWS_2026-07-28_31_KPI_03,WM_NEWS_2026-07-28_31_KPI_04 -->

Issuer-filed business context: With two quarters of the year complete, the Company remains confident in its ability to deliver its full-year outlook for adjusted operating EBITDA between $8.15B and $8.25 billion and free cash flow of between $3.75B and $3.85 billion. Revenue is now expected to be between $26.275B and $26.475 billion dollars, reflecting a reduction of approximately 0.6% compared to the prior outlook, primarily driven by lower volume expectations, partially offset by higher energy surcharges. Accordingly, adjusted operating EBITDA margin in 2026 is now expected to be between 31.0% and 31.2%, representing an increase of 20 basis points. Despite a slightly lower revenue outlook, the resilience of the Company’s operating model, including a proven ability to flex costs and drive productivity, supports continued confidence in achieving original profitability and cash flow targets. <!-- room16-lineage claim=WM_CLAIM_029 evidence=WM_NEWS_2026-07-28_38_KPI_01,WM_NEWS_2026-07-28_38_KPI_02,WM_NEWS_2026-07-28_38_KPI_03,WM_NEWS_2026-07-28_38_KPI_04,WM_NEWS_2026-07-28_38_KPI_05,WM_NEWS_2026-07-28_38_KPI_06,WM_NEWS_2026-07-28_38_KPI_07,WM_NEWS_2026-07-28_38_KPI_08,WM_NEWS_2026-07-28_38_KPI_09,WM_NEWS_2026-07-28_38_KPI_10 -->

## Operating Drivers & Capital Allocation
- **Pricing / yield:** Issuer-filed business context: Our overall pricing efforts are focused on keeping pace with the increasing costs and capital intensity of our business. We continue to see yield growth in our landfill business primarily driven by municipal solid waste, which achieved average yield of 5.2% and 5.9% for the three and six months ended June 30, 2026, respectively. <!-- room16-lineage claim=WM_CLAIM_017 evidence=WM_NEWS_2026-07-29_14_KPI_01,WM_NEWS_2026-07-29_14_KPI_02 -->
- **Volume:** Issuer-filed business context: Our revenues from volume (excluding volumes from acquisitions and divestitures, as well as Healthcare Solutions) decreased $22 million, or 0.3%, and $10 million, or 0.1%, for the three and six months ended June 30, 2026, respectively, as compared to the prior year periods. Volume increased in both our Recycling Processing Sales and our Renewable Energy segments primarily due to contributions from recycling automation and growth projects and new renewable natural gas plants. These volume increases were largely offset by special waste volume declines compared to the prior year periods, which benefited from wildfire cleanup activities in the West Tier, and volume declines in our collection business primarily due to our intentional shedding of lower-margin residential business. Additionally, the six months ended June 30, 2026 was negatively impacted by harsh winter weather conditions in the first quarter of 2026. <!-- room16-lineage claim=WM_CLAIM_018 evidence=WM_NEWS_2026-07-29_15_KPI_01,WM_NEWS_2026-07-29_15_KPI_02,WM_NEWS_2026-07-29_15_KPI_03,WM_NEWS_2026-07-29_15_KPI_04 -->
- **Margin:** Issuer-filed business context: “Second quarter earnings growth, margin expansion, and cash flow generation reflect the strength of our business model and consistent execution from the WM team,” said Jim Fish, WM’s CEO. “Adjusted operating EBITDA grew 5.5%, or 9.1% when removing contributions from wildfire cleanup activities in the prior year. Each of our operating segments contributed to growth in adjusted operating EBITDA and margin, led by the Collection and Disposal business and bolstered by our healthcare and sustainability businesses. The momentum across our operations and our confidence in the ability to execute our strategy position us well to achieve strong 2026 results.” <!-- room16-lineage claim=WM_CLAIM_024 evidence=WM_NEWS_2026-07-28_32_KPI_01,WM_NEWS_2026-07-28_32_KPI_02 -->
- **Capital allocation:** Issuer-filed business context: The Company returned $1.04 billion to shareholders in the second quarter, consisting of $659 million in share repurchases and $379 million in cash dividends. <!-- room16-lineage claim=WM_CLAIM_028 evidence=WM_NEWS_2026-07-28_37_KPI_01,WM_NEWS_2026-07-28_37_KPI_02,WM_NEWS_2026-07-28_37_KPI_03 -->
- **Landfill depletable tons:** Issuer-filed business context: Landfill depletable tons (in millions): 3M ended 2026-06-30: 33.5 million; 3M ended 2025-06-30: 34.7 million; 6M ended 2026-06-30: 62.3 million; 6M ended 2025-06-30: 64.0 million. <!-- room16-lineage claim=WM_CLAIM_035 evidence=WM_NEWS_2026-07-28_43_KPI_01,WM_NEWS_2026-07-28_43_KPI_02,WM_NEWS_2026-07-28_43_KPI_03,WM_NEWS_2026-07-28_43_KPI_04 -->
- **Acquired annualized revenue:** Issuer-filed business context: Gross annualized revenue acquired: 3M ended 2026-06-30: $123M; 3M ended 2025-06-30: $131M; 6M ended 2026-06-30: $123M; 6M ended 2025-06-30: $142M. <!-- room16-lineage claim=WM_CLAIM_036 evidence=WM_NEWS_2026-07-28_44_KPI_01,WM_NEWS_2026-07-28_44_KPI_02,WM_NEWS_2026-07-28_44_KPI_03,WM_NEWS_2026-07-28_44_KPI_04 -->

## Fundamental Analysis
FCF TTM is $3.57B. SBC equals 4.9% of that FCF, an arithmetic comparison that qualifies rather than invalidates the reported cash generation. FCF may be company-defined or period-sensitive and can require reconciliation review. Treat FCF as a rating input only after its source, period and formula have passed validation. <!-- room16-lineage claim=WM_CLAIM_047 evidence=WM_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-11,WM_DETERMINISTIC_SBC_TO_FCF_2026-08-11 -->

SBC/Revenue is 0.7%. The diluted weighted-average share count decreased by 0.5% against the matching prior-year period. This measures the net share-base change; it does not attribute the move solely to SBC or repurchases. Without a sector or lifecycle benchmark, this is a dilution input rather than evidence that SBC is high or low. Sector and lifecycle matter, but persistent dilution can still reduce equity quality. Treat SBC as a risk modifier rather than an automatic rating override. <!-- room16-lineage claim=WM_CLAIM_048 evidence=WM_DETERMINISTIC_SBC_TO_REVENUE_2026-08-11,WM_DETERMINISTIC_DILUTED_SHARE_COUNT_YOY_2026-08-11 -->

The balance-sheet position includes net debt of $22.80B and total debt of $23.36B. This is a leverage input, not evidence of financial flexibility. Interpret liquidity or leverage only from the signed net position and its underlying debt evidence. <!-- room16-lineage claim=WM_CLAIM_049 evidence=WM_DETERMINISTIC_NET_CASH_2026-08-11,WM_SEC_total_debt_FY2026_Q2_instant_2026-06-30_us-gaap_DebtAndCapitalLeaseObligations_0001104659-26-088016 -->

The current ratio is 0.91x. A current ratio below 1.0x is material liquidity context, but does not by itself establish an inability to meet obligations. Business models with recurring receipts or rapid working-capital turnover can operate with current liabilities above current assets. Assess the working-capital model, cash conversion, debt maturities and lease obligations together. <!-- room16-lineage claim=WM_CLAIM_050 evidence=WM_DETERMINISTIC_CURRENT_RATIO_2026-08-11 -->

## Free Cash Flow Definitions
| Definition | Measurement window | Value | Use in this report |
|---|---|---:|---|
| Room16 normalized FCF (operating cash flow minus capital expenditure) | 2025-07-01 to 2026-06-30 | $3.57B | Valuation denominator and normalized cash-conversion analysis |
| Issuer-defined FCF guidance | 2026-01-01 to 2026-12-31 | $3.75B–$3.85B | Forward-looking issuer range; not substituted for normalized TTM FCF |
| Issuer-defined FCF | 2026-01-01 to 2026-06-30 | $2.02B | Issuer presentation only; not substituted for normalized TTM FCF without a period-matched bridge |
| Issuer-defined FCF | 2026-04-01 to 2026-06-30 | $1.10B | Issuer presentation only; not substituted for normalized TTM FCF without a period-matched bridge |
| FCF before sustainability growth | 2026-01-01 to 2026-06-30 | $2.16B | Issuer presentation before sustainability-growth investment; not substituted for normalized TTM FCF |
Room16 and issuer-defined FCF are separate measures. Differences can reflect measurement windows, capital-expenditure definitions, sustainability investments or other issuer adjustments.
<!-- room16-table-lineage id=FCF_DEFINITION_RECONCILIATION evidence=WM_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-11,WM_SEC_CIK0000823768_000110465926087575_TM2621414D1_EX99_1_guidance_fcf_bridge_free_cash_flow_scenario_1_FY2026,WM_SEC_CIK0000823768_000110465926087575_TM2621414D1_EX99_1_guidance_fcf_bridge_free_cash_flow_scenario_2_FY2026,WM_SEC_CIK0000823768_000110465926087575_TM2621414D1_EX99_1_guidance_free_cash_flow_high_FY2026,WM_SEC_CIK0000823768_000110465926087575_TM2621414D1_EX99_1_guidance_free_cash_flow_low_FY2026,WM_NEWS_2026-07-28_38_KPI_03,WM_NEWS_2026-07-28_38_KPI_04,WM_NEWS_2026-07-28_42_KPI_03,WM_NEWS_2026-07-28_42_KPI_01,WM_NEWS_2026-07-28_41_KPI_03 -->

## Projected FCF Guidance Bridge
| Issuer bridge component | Scenario 1 | Scenario 2 |
|---|---:|---:|
| Operating cash flow | $6.30B | $6.45B |
| Support capital expenditure | -$2.40B | -$2.50B |
| Divestiture proceeds | $100.0M | $150.0M |
| FCF before sustainability growth | $4.00B | $4.10B |
| Sustainability-growth capital expenditure | -$250.0M | -$250.0M |
| Issuer-defined free cash flow | $3.75B | $3.85B |
Both issuer scenarios reconcile arithmetically. These forward-looking non-GAAP scenarios remain separate from Room16 normalized trailing-twelve-month FCF.
<!-- room16-table-lineage id=PROJECTED_FCF_GUIDANCE_BRIDGE evidence=WM_SEC_CIK0000823768_000110465926087575_TM2621414D1_EX99_1_guidance_fcf_bridge_divestiture_proceeds_scenario_1_FY2026,WM_SEC_CIK0000823768_000110465926087575_TM2621414D1_EX99_1_guidance_fcf_bridge_divestiture_proceeds_scenario_2_FY2026,WM_SEC_CIK0000823768_000110465926087575_TM2621414D1_EX99_1_guidance_fcf_bridge_fcf_before_sustainability_growth_scenario_1_FY2026,WM_SEC_CIK0000823768_000110465926087575_TM2621414D1_EX99_1_guidance_fcf_bridge_fcf_before_sustainability_growth_scenario_2_FY2026,WM_SEC_CIK0000823768_000110465926087575_TM2621414D1_EX99_1_guidance_fcf_bridge_free_cash_flow_scenario_1_FY2026,WM_SEC_CIK0000823768_000110465926087575_TM2621414D1_EX99_1_guidance_fcf_bridge_free_cash_flow_scenario_2_FY2026,WM_SEC_CIK0000823768_000110465926087575_TM2621414D1_EX99_1_guidance_fcf_bridge_operating_cash_flow_scenario_1_FY2026,WM_SEC_CIK0000823768_000110465926087575_TM2621414D1_EX99_1_guidance_fcf_bridge_operating_cash_flow_scenario_2_FY2026,WM_SEC_CIK0000823768_000110465926087575_TM2621414D1_EX99_1_guidance_fcf_bridge_support_capex_scenario_1_FY2026,WM_SEC_CIK0000823768_000110465926087575_TM2621414D1_EX99_1_guidance_fcf_bridge_support_capex_scenario_2_FY2026,WM_SEC_CIK0000823768_000110465926087575_TM2621414D1_EX99_1_guidance_fcf_bridge_sustainability_growth_capex_scenario_1_FY2026,WM_SEC_CIK0000823768_000110465926087575_TM2621414D1_EX99_1_guidance_fcf_bridge_sustainability_growth_capex_scenario_2_FY2026 -->

## Capital Allocation, Transactions & Contingencies
From 2026-01-01 through 2026-06-30, shareholder distributions were $1.77B and period-matched acquisition cash was $98.0M. Against Room16 normalized same-period FCF of $1.95B, these outflows leave $82.0M. Issuer-defined same-period FCF was $2.02B; the same outflows leave $159.0M. The two FCF definitions differ by $77.0M; this is an intentional definition difference, not an unresolved value mismatch. This is a period-matched capital-allocation bridge, not a TTM claim. One interim period can be seasonal and does not establish a durable payout policy. Track repurchases, dividends and FCF on the same reporting window before judging funding pressure. <!-- room16-lineage claim=WM_CLAIM_005 evidence=WM_DETERMINISTIC_SHAREHOLDER_DISTRIBUTIONS_CURRENT_PERIOD_2026-08-11,WM_DETERMINISTIC_FREE_CASH_FLOW_CURRENT_PERIOD_2026-08-11,WM_DETERMINISTIC_BUYBACKS_CURRENT_PERIOD_2026-08-11,WM_DETERMINISTIC_DIVIDENDS_PAID_CURRENT_PERIOD_2026-08-11,WM_CAPITAL_ALLOCATION_ACQUISITION_CASH_2026-06-30,WM_CAPITAL_ALLOCATION_ROOM16_RESIDUAL_2026-06-30,WM_ISSUER_DEFINED_FCF_CURRENT_PERIOD_2026-06-30,WM_CAPITAL_ALLOCATION_ISSUER_RESIDUAL_2026-06-30,WM_FCF_DEFINITION_DIFFERENCE_2026-06-30 -->

Canadian Senior Notes — In June 2026, Waste Management of Canada Corporation, an indirect wholly-owned subsidiary of WM, issued C$700 million, or $493 million, of 3.944% senior notes due July 15, 2033, all of which are fully and unconditionally guaranteed on a senior unsecured basis by WM and WM Holdings. The net proceeds from the debt issuance were C$696 million, or $490 million, which were used to redeem the previously outstanding C$500 million 2.60% Canadian senior notes that would have matured in September 2026, and we intend to use the remainder of the proceeds for general corporate purposes. <!-- room16-lineage claim=WM_CLAIM_009 evidence=WM_NEWS_2026-07-29_06_KPI_01,WM_NEWS_2026-07-29_06_KPI_02,WM_NEWS_2026-07-29_06_KPI_03,WM_NEWS_2026-07-29_06_KPI_04,WM_NEWS_2026-07-29_06_KPI_05,WM_NEWS_2026-07-29_06_KPI_06,WM_NEWS_2026-07-29_06_KPI_07 -->

## Valuation / Risk-Reward
EV/Sales is 4.42x, derived from enterprise value and TTM revenue. Without a validated peer, history or cycle benchmark, this records a multiple level but does not label the company cheap or expensive. A benchmark can change the interpretation, but must be present in the authority packet before it affects the rating. Treat EV/Sales as an observation until comparison evidence exists. <!-- room16-lineage claim=WM_CLAIM_051 evidence=WM_DETERMINISTIC_EV_TO_SALES_2026-08-11,WM_DETERMINISTIC_ENTERPRISE_VALUE_2026-08-11,WM_DETERMINISTIC_REVENUE_TTM_2026-08-11 -->

For WM, P/FCF is 25.38x, derived from market capitalization and TTM FCF. This records the cash-flow valuation level without labeling it cheap or expensive. A valuation conclusion requires sector comparison and cash-flow durability evidence. <!-- room16-lineage claim=WM_CLAIM_052 evidence=WM_DETERMINISTIC_PRICE_TO_FCF_2026-08-11,WM_DETERMINISTIC_MARKET_CAP_2026-08-11,WM_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-11 -->

Standardized equity-DCF sensitivity, not a company forecast: bear $37.38B, base $75.07B and bull $175.99B. In the base case, discounted terminal value contributes 73.3% of scenario equity value, exposing the model's dependence on long-duration assumptions. The standardized reverse DCF implies a five-year FCF growth rate of 19.1% at a 10% discount rate and 2% terminal growth. DCF results are highly sensitive to growth, discount-rate and terminal assumptions and require business-model review. Compare the current equity value with the whole range; do not treat the base case as a precise price target. <!-- room16-lineage claim=WM_CLAIM_053 evidence=WM_DETERMINISTIC_DCF_BEAR_EQUITY_VALUE_2026-08-11,WM_DETERMINISTIC_DCF_BASE_EQUITY_VALUE_2026-08-11,WM_DETERMINISTIC_DCF_BULL_EQUITY_VALUE_2026-08-11,WM_DETERMINISTIC_DCF_BASE_TERMINAL_VALUE_SHARE_2026-08-11,WM_DETERMINISTIC_DCF_BASE_DISCOUNT_RATE_2026-08-11,WM_DETERMINISTIC_DCF_BASE_TERMINAL_GROWTH_RATE_2026-08-11,WM_DETERMINISTIC_REVERSE_DCF_GROWTH_2026-08-11 -->

## Scenario / Sensitivity
| Scenario | FCF growth | Discount rate | Terminal growth | Valuation implication | Rating implication |
|---|---:|---:|---:|---:|---|
| Bear | 4.2% | 12.0% | 1.0% | Equity value $37.38B | Would weaken the case only if primary evidence supports the adverse assumptions |
| Base | 14.2% | 10.0% | 2.0% | Equity value $75.07B | No automatic change to the current Provisional — Hold research rating |
| Bull | 24.2% | 8.0% | 3.0% | Equity value $175.99B | The rating would become more constructive if primary evidence supports the assumptions |

The table is a standardized sensitivity, not management guidance or a precise price target.
<!-- room16-table-lineage id=DCF_SCENARIO_VIEW evidence=ROOM16_WM_DETERMINISTIC_CALCULATIONS_DCF_BASE_DISCOUNT_RATE,ROOM16_WM_DETERMINISTIC_CALCULATIONS_DCF_BASE_EQUITY_VALUE,ROOM16_WM_DETERMINISTIC_CALCULATIONS_DCF_BASE_FREE_CASH_FLOW_GROWTH_RATE,ROOM16_WM_DETERMINISTIC_CALCULATIONS_DCF_BASE_TERMINAL_GROWTH_RATE,ROOM16_WM_DETERMINISTIC_CALCULATIONS_DCF_BASE_TERMINAL_VALUE_SHARE,ROOM16_WM_DETERMINISTIC_CALCULATIONS_DCF_BEAR_DISCOUNT_RATE,ROOM16_WM_DETERMINISTIC_CALCULATIONS_DCF_BEAR_EQUITY_VALUE,ROOM16_WM_DETERMINISTIC_CALCULATIONS_DCF_BEAR_FREE_CASH_FLOW_GROWTH_RATE,ROOM16_WM_DETERMINISTIC_CALCULATIONS_DCF_BEAR_TERMINAL_GROWTH_RATE,ROOM16_WM_DETERMINISTIC_CALCULATIONS_DCF_BEAR_TERMINAL_VALUE_SHARE,ROOM16_WM_DETERMINISTIC_CALCULATIONS_DCF_BULL_DISCOUNT_RATE,ROOM16_WM_DETERMINISTIC_CALCULATIONS_DCF_BULL_EQUITY_VALUE,ROOM16_WM_DETERMINISTIC_CALCULATIONS_DCF_BULL_FREE_CASH_FLOW_GROWTH_RATE,ROOM16_WM_DETERMINISTIC_CALCULATIONS_DCF_BULL_TERMINAL_GROWTH_RATE,ROOM16_WM_DETERMINISTIC_CALCULATIONS_DCF_BULL_TERMINAL_VALUE_SHARE,WM_DETERMINISTIC_DCF_BEAR_EQUITY_VALUE_2026-08-11,WM_DETERMINISTIC_DCF_BEAR_FREE_CASH_FLOW_GROWTH_RATE_2026-08-11,WM_DETERMINISTIC_DCF_BEAR_DISCOUNT_RATE_2026-08-11,WM_DETERMINISTIC_DCF_BEAR_TERMINAL_GROWTH_RATE_2026-08-11,WM_DETERMINISTIC_DCF_BEAR_TERMINAL_VALUE_SHARE_2026-08-11,WM_DETERMINISTIC_DCF_BASE_EQUITY_VALUE_2026-08-11,WM_DETERMINISTIC_DCF_BASE_FREE_CASH_FLOW_GROWTH_RATE_2026-08-11,WM_DETERMINISTIC_DCF_BASE_TERMINAL_VALUE_SHARE_2026-08-11,WM_DETERMINISTIC_DCF_BULL_EQUITY_VALUE_2026-08-11,WM_DETERMINISTIC_DCF_BULL_FREE_CASH_FLOW_GROWTH_RATE_2026-08-11,WM_DETERMINISTIC_DCF_BULL_DISCOUNT_RATE_2026-08-11,WM_DETERMINISTIC_DCF_BULL_TERMINAL_GROWTH_RATE_2026-08-11,WM_DETERMINISTIC_DCF_BULL_TERMINAL_VALUE_SHARE_2026-08-11,WM_DETERMINISTIC_DCF_BASE_DISCOUNT_RATE_2026-08-11,WM_DETERMINISTIC_DCF_BASE_TERMINAL_GROWTH_RATE_2026-08-11 -->

## Technical Setup
The technical setup records raw observations only: close $226.85, 50-SMA $226.81, 200-SMA $223.58 and RSI 45.36. No bullish, bearish or mixed technical conclusion is activated. Corporate-action adjustment is not confirmed, so no directional conclusion or numeric policy level is activated. Do not use these raw observations for timing until the corporate-action adjustment is confirmed. <!-- room16-lineage claim=WM_CLAIM_054 evidence=WM_CSV_PRICE_CLOSE_2026-08-11,WM_DETERMINISTIC_CLOSE_2026-08-11,WM_DETERMINISTIC_SMA_50_2026-08-11,WM_DETERMINISTIC_SMA_200_2026-08-11,WM_DETERMINISTIC_RSI_14_2026-08-11 -->

WM's close of $226.85 and moving-average position record unscored raw moving-average observations; no bullish or bearish technical conclusion is activated because corporate-action adjustment is not confirmed; this does not prescribe an entry, trim or position size. Technical weakness can be temporary if fundamentals and catalysts improve. No technical divergence or timing condition is activated until the price-series basis is confirmed. <!-- room16-lineage claim=WM_CLAIM_055 evidence=WM_CSV_PRICE_CLOSE_2026-08-11,WM_DETERMINISTIC_CLOSE_2026-08-11,WM_DETERMINISTIC_SMA_50_2026-08-11,WM_DETERMINISTIC_SMA_200_2026-08-11,WM_DETERMINISTIC_RSI_14_2026-08-11 -->

## Bull Case
Matching-quarter evidence shows revenue growth 4.0%, operating-income growth 8.9%, net-income growth 8.1%. Together with revenue TTM of $25.67B and FCF TTM of $3.57B, this records aligned current-period direction, scale and positive cash generation, but does not establish durability or cause. A more constructive rating still requires those comparisons to persist and stronger durable fundamental and benchmarked valuation support. Reported comparisons and scale do not by themselves prove durable cash conversion or justify an unbenchmarked valuation. The bull case remains a research scenario, not an action plan. <!-- room16-lineage claim=WM_CLAIM_056 evidence=WM_DETERMINISTIC_REVENUE_TTM_2026-08-11,WM_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-11,WM_DETERMINISTIC_CURRENT_PERIOD_REVENUE_GROWTH_YOY_2026-08-11,WM_DETERMINISTIC_CURRENT_PERIOD_OPERATING_INCOME_GROWTH_YOY_2026-08-11,WM_DETERMINISTIC_CURRENT_PERIOD_NET_INCOME_GROWTH_YOY_2026-08-11 -->

No constructive technical bull path is activated for WM. The current RSI of 45.36 and moving-average observations remain unscored until the corporate-action adjustment is confirmed. A more constructive research stance should require confirmation when the preferred rating is not Buy. <!-- room16-lineage claim=WM_CLAIM_057 evidence=WM_DETERMINISTIC_RSI_14_2026-08-11,WM_DETERMINISTIC_SMA_50_2026-08-11,WM_DETERMINISTIC_SMA_200_2026-08-11,WM_CSV_PRICE_CLOSE_2026-08-11,WM_DETERMINISTIC_CLOSE_2026-08-11 -->

**Issuer-specific confirmation path.**
**Pricing / yield:** Reported evidence: Issuer-filed business context: Our overall pricing efforts are focused on keeping pace with the increasing costs and capital intensity of our business; The next comparable filing must confirm the stated improvement. <!-- room16-lineage claim=WM_CLAIM_017 evidence=WM_NEWS_2026-07-29_14_KPI_01,WM_NEWS_2026-07-29_14_KPI_02 -->
**Volume:** Reported evidence: Issuer-filed business context: Our revenues from volume (excluding volumes from acquisitions and divestitures, as well as Healthcare Solutions) decreased $22 million, or 0.3%, and $10 million, or 0.1%, for the three and six months ended June 30, 2026, respectively, as compared to the prior year periods; The next comparable filing must confirm the stated improvement. <!-- room16-lineage claim=WM_CLAIM_018 evidence=WM_NEWS_2026-07-29_15_KPI_01,WM_NEWS_2026-07-29_15_KPI_02,WM_NEWS_2026-07-29_15_KPI_03,WM_NEWS_2026-07-29_15_KPI_04 -->
**Margin:** Reported evidence: Issuer-filed business context: “Second quarter earnings growth, margin expansion, and cash flow generation reflect the strength of our business model and consistent execution from the WM team,” said Jim Fish, WM’s CEO; The next comparable filing must confirm the stated improvement. <!-- room16-lineage claim=WM_CLAIM_024 evidence=WM_NEWS_2026-07-28_32_KPI_01,WM_NEWS_2026-07-28_32_KPI_02 -->
A stronger case requires these issuer-bound signals to confirm one another and continue converting into cash.

## Bear Case
Separate balance-sheet or issuer-disclosed downside evidence anchors the bear case for WM. FCF TTM of $3.57B is counterevidence and the available evidence does not by itself prove current operating deterioration. Technical timing context is unscored raw moving-average observations; no bullish or bearish technical conclusion is activated because corporate-action adjustment is not confirmed; it does not establish operating deterioration or change the company rating. A current ratio of 0.91x is material liquidity context, but does not by itself establish an inability to meet obligations. Issuer disclosure identifies a separate exposure: If we fail to implement our business strategy, our financial performance and our growth could be materially and adversely affected. This identifies a risk, not evidence that the adverse outcome has occurred. Treat the bear case as evidence to monitor, not as proof of permanent business deterioration. <!-- room16-lineage claim=WM_CLAIM_058 evidence=WM_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-11,WM_DETERMINISTIC_CURRENT_RATIO_2026-08-11,WM_CSV_PRICE_CLOSE_2026-08-11,WM_DETERMINISTIC_CLOSE_2026-08-11,WM_DETERMINISTIC_SMA_50_2026-08-11,WM_DETERMINISTIC_SMA_200_2026-08-11,WM_DETERMINISTIC_RSI_14_2026-08-11,WM_SEC_RISK_000110465926012049_01 -->

## Material Events & Governance
SEC Form 8-K Item 1.01. Entry into a Material Definitive Agreement On March 20, 2026, Waste Management, Inc. (the “Company”) entered into Amendment No. 2 (the “Amendment”) to its Seventh Amended and Restated Revolving Credit Agreement dated May 8, 2024 (as amended and restated, the “Credit Agreement”) among the Company, Waste Management of Canada Corporation and WM Quebec Inc., as the Borrowers, Waste Management Holdings, Inc., as Guarantor, the banks party thereto from time to time, and Bank of America, N.A., as Administrative Agent. The Amendment modifies the definitions of EBIT and EBITDA in the Credit Agreement to allow for the add back of equity-based compensation and interest accretion as non-cash items for purposes of the leverage ratio financial covenant calculation, as set forth in Section 9 of the Credit Agreement. <!-- room16-lineage claim=WM_CLAIM_040 evidence=WM_NEWS_2026-03-25_51 -->

SEC Form 8-K Item 5.02. Retirement of Mr. Carrasco On May 8, 2026, Mr. Rafael E. Carrasco, Senior Vice President, Enterprise Strategy and President, WM Healthcare Solutions of Waste Management, Inc. (the “Company”), provided notice of his decision to retire as of July 17, 2026. Promotion of Ms. Hemmer On May 13, 2026, the Company announced that its Board of Directors (the “Board”) has promoted Ms. Tara J. Hemmer to the position of Executive Vice President and Chief Operating Officer, reporting to President John J. Morris, Jr. Mr. Morris voluntarily resigned from the position of Chief Operating Officer. <!-- room16-lineage claim=WM_CLAIM_041 evidence=WM_NEWS_2026-05-13_53 -->

## Risks
Current issuer-filed risk context: In 2018, both of McGinnes Industrial Maintenance Corporation (“MIMC”), a subsidiary of Waste Management of Texas, Inc., and International Paper Company (“IPC”) entered into an Administrative Order on Consent with the EPA as PRPs to develop a remedial design for the San Jacinto River Waste Pits Superfund Site in Harris County, Texas. We recorded a liability for MIMC’s estimated potential share of the EPA’s proposed remedy and related costs, although allocation of responsibility among the PRPs for the proposed remedy has not been established. In November 2024, MIMC and IPC publicly issued a proposed revised full remedial design that was approved by the EPA in September 2025. The EPA issued a Unilateral Administrative Order for the site cleanup in April 2026. The issuance of this order was anticipated, and MIMC and IPC have communicated to the EPA their intention to comply. The recorded liability as of June 30, 2026, and December 31, 2025, was approximately $100 million. MIMC’s ultimate liability could be materially different from current estimates, including potential increases resulting from MIMC’s continued engagement with the EPA as construction contracting and planning proceed. <!-- room16-lineage claim=WM_CLAIM_010 evidence=WM_NEWS_2026-07-29_07_KPI_01 -->

Current issuer-filed risk context: On February 11, 2020, Stericycle, Inc. (“Stericycle”), a now wholly-owned subsidiary, received an administrative subpoena from the U.S. Drug Enforcement Administration, which executed a search warrant at a facility in Rancho Cordova, California and an administrative inspection warrant at a facility in Indianapolis, Indiana for materials related to Stericycle’s now-divested Domestic Environmental Solutions business of collecting, transporting, and destroying controlled substances from retail customers (the “ESOL Retail Controlled Substances Business”). On that same day, agents from the California Department of Toxic Substances Control executed a separate search warrant at the Rancho Cordova facility. Since that time, the U.S. Attorney’s Office for the Eastern District of California has been overseeing criminal and civil investigations of the ESOL Retail Controlled Substances Business. Stericycle cooperated with the investigations, which were limited to the period of Stericycle’s historical operation and ownership of the ESOL Retail Controlled Substances Business from 2015 through 2020. In May 2026, Stericycle entered into certain settlement agreements, including a one-year deferred prosecution agreement, with the U.S. Department of Justice resolving the criminal and civil investigations. Stericycle has made the agreed-upon penalty and settlement payments and is subject to certain continuing compliance, reporting and cooperation obligations during the term of the deferred prosecution agreement. We do not currently believe this matter will have a material adverse effect on the Company’s business, financial condition, results of operations or cash flows. <!-- room16-lineage claim=WM_CLAIM_011 evidence=WM_NEWS_2026-07-29_08 -->

Current issuer-filed risk context: We do not currently believe that the eventual outcome of this matter will have a material adverse effect on the Company’s business, financial condition, results of operations or cash flows. On April 26, 2026, the Delaware Department of Natural Resources and Environmental Control issued an order against Delaware Recyclable Products, Inc., an indirect, wholly-owned subsidiary of WMI, alleging certain environmental violations related to landfill cover and erosion control, stormwater management, the management of prohibited waste, and other permitting and operational matters. The order seeks compliance with a modified permit, certain remedial actions and the payment of an administrative penalty. Our appeal of this order is pending. <!-- room16-lineage claim=WM_CLAIM_012 evidence=WM_NEWS_2026-07-29_09 -->

Issuer-disclosed risk: If we fail to implement our business strategy, our financial performance and our growth could be materially and adversely affected. This identifies an exposure; it does not establish that the adverse outcome has occurred. <!-- room16-lineage claim=WM_CLAIM_042 evidence=WM_SEC_RISK_000110465926012049_01 -->

Issuer-disclosed risk: We may not realize the strategic benefits, revenue and earnings growth, or cost synergies anticipated from the Stericycle acquisition. <!-- room16-lineage claim=WM_CLAIM_043 evidence=WM_SEC_RISK_000110465926012049_02 -->

## Catalysts
WM issuer-filed FY2026 guidance calls for sales of $26.27B to $26.48B. Guidance is forward-looking and remains exposed to execution, currency and demand changes. Future reported results should be measured against the filed range rather than against an unsourced expectation. <!-- room16-lineage claim=WM_CLAIM_004 evidence=WM_SEC_CIK0000823768_000110465926087575_TM2621414D1_EX99_1_guidance_revenue_low_FY2026,WM_SEC_CIK0000823768_000110465926087575_TM2621414D1_EX99_1_guidance_revenue_high_FY2026 -->

Operating catalyst under review: With two quarters of the year complete, the Company remains confident in its ability to deliver its full-year outlook for adjusted operating EBITDA between $8.15B and $8.25 billion and free cash flow of between $3.75B and $3.85 billion. An announced strategy is forward-looking intent; execution and financial contribution remain unproven. Reassess only when subsequent reported evidence shows whether the stated objectives are being achieved. <!-- room16-lineage claim=WM_CLAIM_030 evidence=WM_NEWS_2026-07-28_38_KPI_01,WM_NEWS_2026-07-28_38_KPI_02,WM_NEWS_2026-07-28_38_KPI_03,WM_NEWS_2026-07-28_38_KPI_04 -->

The raw moving-average observations are 50-SMA $226.81 and 200-SMA $223.58. They are not validated support, resistance, risk or trigger levels because corporate-action adjustment is not confirmed. No separate evidence-backed price target is present in the packet. Withhold technical trigger language until the price-series basis is confirmed. <!-- room16-lineage claim=WM_CLAIM_059 evidence=WM_DETERMINISTIC_SMA_50_2026-08-11,WM_DETERMINISTIC_SMA_200_2026-08-11 -->

## Final Rating & Review Conditions
Final Rating: Provisional — Hold. Constructive fundamentals are not enough for an overweight rating without calibrated valuation evidence; unverified technical inputs are excluded from rating and timing.

Factual anchors are revenue of $25.67B, FCF of $3.57B. Separately, raw technical observations include RSI of 45.36; direction and timing are not activated because corporate-action adjustment is not confirmed; raw indicators remain provisional observations.

The standardized equity-DCF range is $37.38B to $175.99B. It is an uncalibrated illustration outside the rating logic and does not create an automatic rating signal.

Why not more constructive? Constructive fundamentals and positive FCF are not enough without calibrated valuation support. Technical timing is unavailable until the price-series basis is confirmed.

Why not more cautious? Positive FCF and the constructive fundamental signal are measured counterevidence. A more cautious rating requires corroborating fundamental, valuation or issuer-risk deterioration. The rating already monitors these named current risks: San Jacinto River Waste Pits remediation and EPA cleanup order; Stericycle deferred-prosecution and continuing-compliance obligations; Delaware environmental order and pending appeal. A more cautious rating requires new primary evidence that their reserve, compliance, operating or cash-flow transmission outweighs the measured counterevidence; an issuer counterposition is context, not independent proof.

Review condition: retain the WM research rating while the measured evidence state is unchanged. Reassess only when new primary evidence changes fundamentals, calibrated valuation or issuer risk. Technical timing remains unavailable until the price-series basis is confirmed.

**Formal rating evidence binding:** <!-- room16-lineage claim=WM_CLAIM_060 evidence=WM_CSV_PRICE_CLOSE_2026-08-11,WM_DETERMINISTIC_CLOSE_2026-08-11,WM_DETERMINISTIC_REVENUE_TTM_2026-08-11,WM_DETERMINISTIC_FREE_CASH_FLOW_TTM_2026-08-11,WM_DETERMINISTIC_EV_TO_SALES_2026-08-11,WM_DETERMINISTIC_TRAILING_PE_2026-08-11,WM_DETERMINISTIC_PRICE_TO_FCF_2026-08-11,WM_DETERMINISTIC_DCF_BEAR_EQUITY_VALUE_2026-08-11,WM_DETERMINISTIC_DCF_BEAR_FREE_CASH_FLOW_GROWTH_RATE_2026-08-11,WM_DETERMINISTIC_DCF_BEAR_DISCOUNT_RATE_2026-08-11,WM_DETERMINISTIC_DCF_BEAR_TERMINAL_GROWTH_RATE_2026-08-11,WM_DETERMINISTIC_DCF_BEAR_TERMINAL_VALUE_SHARE_2026-08-11,WM_DETERMINISTIC_DCF_BASE_EQUITY_VALUE_2026-08-11,WM_DETERMINISTIC_DCF_BASE_FREE_CASH_FLOW_GROWTH_RATE_2026-08-11,WM_DETERMINISTIC_DCF_BASE_DISCOUNT_RATE_2026-08-11,WM_DETERMINISTIC_DCF_BASE_TERMINAL_GROWTH_RATE_2026-08-11,WM_DETERMINISTIC_DCF_BASE_TERMINAL_VALUE_SHARE_2026-08-11,WM_DETERMINISTIC_DCF_BULL_EQUITY_VALUE_2026-08-11,WM_DETERMINISTIC_DCF_BULL_FREE_CASH_FLOW_GROWTH_RATE_2026-08-11,WM_DETERMINISTIC_DCF_BULL_DISCOUNT_RATE_2026-08-11,WM_DETERMINISTIC_DCF_BULL_TERMINAL_GROWTH_RATE_2026-08-11,WM_DETERMINISTIC_DCF_BULL_TERMINAL_VALUE_SHARE_2026-08-11,WM_DETERMINISTIC_REVERSE_DCF_GROWTH_2026-08-11,WM_NEWS_2026-07-29_07_NARRATIVE,WM_NEWS_2026-07-29_08,WM_NEWS_2026-07-29_09 -->

## Data Limits & Review Status

- Internal status: `manual_review`.
- Public release: `blocked`.
- Active review points:
  - `BUSINESS_MODEL_KPI_COVERAGE_INCOMPLETE`: Required business-model KPIs are missing: internalization
  - `EARNINGS_DATE_UNAVAILABLE`: Next earnings date is unavailable. The official investor-relations page was observed through a read-only render proxy after the origin returned HTTP 403. No future earnings date was visible in that captured page. This is bounded negative evidence from the rendered snapshot, not proof that the origin published no future date.
  - `BALANCE_SHEET_DATE_MISMATCH_EXCLUDED`: Excluded lease_liability_current from 2025-12-31 because the latest financial-statement balance date is 2026-06-30.

## Evidence Appendix
The complete claim text, evidence IDs, metric mappings and source IDs are stored in the separately hash-bound `analyst_claims.json`. This appendix is the compact human-readable index.

| Claim ID | Section | Claim Type | Evidence Count | Source Types | Confidence |
|---|---|---|---:|---|---|
| WM_CLAIM_001 | Executive Summary | rating | 5 | deterministic calculation, exchange ohlcv | high |
| WM_CLAIM_002 | Fundamental Analysis | financial metric | 6 | deterministic calculation, sec filing | high |
| WM_CLAIM_003 | Fundamental Analysis | financial metric | 2 | sec filing | high |
| WM_CLAIM_004 | Catalysts & Triggers | guidance | 2 | sec filing | high |
| WM_CLAIM_005 | Capital Allocation, Transactions & Contingencies | financial metric | 9 | derived calculation, deterministic calculation | high |
| WM_CLAIM_006 | Business & Segment Context | news | 1 | sec filing | high |
| WM_CLAIM_007 | Business & Segment Context | news | 1 | sec filing | high |
| WM_CLAIM_008 | Business & Segment Context | news | 1 | sec filing | high |
| WM_CLAIM_009 | Capital Allocation, Transactions & Contingencies | news | 7 | sec filing | high |
| WM_CLAIM_010 | Key Risks | risk | 1 | sec filing | high |
| WM_CLAIM_011 | Key Risks | risk | 1 | sec filing | high |
| WM_CLAIM_012 | Key Risks | risk | 1 | sec filing | high |
| WM_CLAIM_013 | Business & Segment Context | news | 1 | sec filing | high |
| WM_CLAIM_014 | Business & Segment Context | news | 4 | sec filing | high |
| WM_CLAIM_015 | Business & Segment Context | news | 5 | sec filing | high |
| WM_CLAIM_016 | Business & Segment Context | news | 5 | sec filing | high |
| WM_CLAIM_017 | Business & Segment Context | news | 2 | sec filing | high |
| WM_CLAIM_018 | Business & Segment Context | news | 4 | sec filing | high |
| WM_CLAIM_019 | Business & Segment Context | news | 1 | sec filing | high |
| WM_CLAIM_020 | Business & Segment Context | news | 4 | sec filing | high |
| WM_CLAIM_021 | Business & Segment Context | news | 4 | sec filing | high |
| WM_CLAIM_022 | Business & Segment Context | news | 2 | sec filing | high |
| WM_CLAIM_023 | Business & Segment Context | news | 4 | sec filing | high |
| WM_CLAIM_024 | Business & Segment Context | news | 2 | sec filing | high |
| WM_CLAIM_025 | Business & Segment Context | news | 3 | sec filing | high |
| WM_CLAIM_026 | Business & Segment Context | news | 4 | sec filing | high |
| WM_CLAIM_027 | Business & Segment Context | news | 3 | sec filing | high |
| WM_CLAIM_028 | Business & Segment Context | news | 3 | sec filing | high |
| WM_CLAIM_029 | Business & Segment Context | news | 10 | sec filing | high |
| WM_CLAIM_030 | Catalysts & Triggers | news | 4 | sec filing | high |
| WM_CLAIM_031 | Business & Segment Context | news | 2 | sec filing | high |
| WM_CLAIM_032 | Business & Segment Context | news | 4 | sec filing | high |
| WM_CLAIM_033 | Business & Segment Context | news | 4 | sec filing | high |
| WM_CLAIM_034 | Business & Segment Context | news | 4 | sec filing | high |
| WM_CLAIM_035 | Business & Segment Context | news | 4 | sec filing | high |
| WM_CLAIM_036 | Business & Segment Context | news | 4 | sec filing | high |
| WM_CLAIM_037 | Business & Segment Context | news | 4 | sec filing | high |
| WM_CLAIM_038 | Business & Segment Context | news | 4 | sec filing | high |
| WM_CLAIM_039 | Business & Segment Context | news | 3 | sec filing | high |
| WM_CLAIM_040 | Material Events & Governance | news | 1 | sec filing | high |
| WM_CLAIM_041 | Material Events & Governance | news | 1 | sec filing | high |
| WM_CLAIM_042 | Key Risks | risk | 1 | sec filing | high |
| WM_CLAIM_043 | Key Risks | risk | 1 | sec filing | high |
| WM_CLAIM_044 | Key Risks | risk | 1 | sec filing | high |
| WM_CLAIM_045 | Key Risks | risk | 1 | sec filing | high |
| WM_CLAIM_046 | Key Risks | risk | 2 | deterministic calculation | medium |
| WM_CLAIM_047 | Fundamental Analysis | financial metric | 2 | deterministic calculation | high |
| WM_CLAIM_048 | Fundamental Analysis | financial metric | 2 | deterministic calculation | medium |
| WM_CLAIM_049 | Fundamental Analysis | financial metric | 2 | deterministic calculation, sec filing | medium |
| WM_CLAIM_050 | Fundamental Analysis | financial metric | 1 | deterministic calculation | high |
| WM_CLAIM_051 | Valuation / Multiples | valuation metric | 3 | deterministic calculation | medium |
| WM_CLAIM_052 | Valuation / Multiples | valuation metric | 3 | deterministic calculation | medium |
| WM_CLAIM_053 | Valuation / Multiples | valuation metric | 7 | deterministic calculation | medium |
| WM_CLAIM_054 | Technical Setup | technical metric | 5 | exchange ohlcv | high |
| WM_CLAIM_055 | Technical Setup | technical metric | 5 | exchange ohlcv | medium |
| WM_CLAIM_056 | Bull Case | financial metric | 5 | deterministic calculation | medium |
| WM_CLAIM_057 | Bull Case | technical metric | 5 | exchange ohlcv | medium |
| WM_CLAIM_058 | Bear Case | financial metric | 8 | deterministic calculation, exchange ohlcv, sec filing | medium |
| WM_CLAIM_059 | Catalysts & Triggers | technical metric | 2 | exchange ohlcv | medium |
| WM_CLAIM_060 | Final Rating & Action Plan | rating | 26 | deterministic calculation, exchange ohlcv, sec filing | high |
