import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { createHash, generateKeyPairSync, sign } from "node:crypto";
import { fileURLToPath } from "node:url";

import {
  CompilerArtifactBundleV2Error,
  canonicalJsonV2,
  sha256CanonicalV2,
  verifyCompilerArtifactBundleV2
} from "../server-modules/compiler-artifact-bundle-v2.mjs";
import {
  assertSingleCanonicalRun,
  verifyCompilerArtifactBundleVersioned
} from "../server-modules/compiler-artifact-bundle-router.mjs";

const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const RESEARCH_ROOT = path.resolve(APP_ROOT, "..", "..", "research-agent-ops");

function writeJson(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`);
}

function fixture() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "room16-rfc0008-product-"));
  const { publicKey, privateKey } = generateKeyPairSync("ed25519");
  const publicDer = publicKey.export({ format: "der", type: "spki" });
  const publicKeyHex = publicDer.subarray(publicDer.length - 32).toString("hex");
  const keyBody = {
    contract_id: "room16.compiler.public_key_policy",
    contract_version: 2,
    owner: "research_compiler",
    signature_algorithm: "ed25519",
    keys: [{
      key_id: "research.test.ephemeral",
      not_after_utc: null,
      not_before_utc: "2026-08-21T00:00:00Z",
      public_key_hex: publicKeyHex,
      state: "active"
    }],
    rotation_sequence: ["active", "grace_verify_only", "revoked"]
  };
  const keyPolicy = { ...keyBody, policy_sha256: sha256CanonicalV2(keyBody) };
  const policyBody = {
    allowed_authority_v3_bridge_directions: ["bundle_to_authority_v3_only", "disabled"],
    artifact_bundle_contract_major: 2,
    ba10_v1_freeze_sha256: "29bc0bf2d00aa22d49fd7bb569cf080cc335778c1773b9e63710ecd61dfebc8e",
    ba11_freeze_sha256: "2c0e0e292f2b167e68814e2e2180f9f0823ea8be452be52b95f56db95a4ca1cf",
    canonicalization_profile: "room16.foundation.canonical_json@1",
    contract_id: "room16.compiler.consumer_policy_lock",
    contract_version: 2,
    hash_algorithm: "sha256",
    key_policy_sha256: keyPolicy.policy_sha256,
    legacy_semantic_input_allowed: false,
    mutable_bundle_hash_allowlist_allowed: false,
    owner: "research_compiler",
    product_may_edit_semantics: false,
    schema_version_max: "2.x",
    schema_version_min: "2.0.0",
    source_native_fact_generation_required_for_native: true,
    trusted_emitter_id: "room16.compiler_artifact_bundle_builder_v2"
  };
  const consumerPolicy = { ...policyBody, policy_sha256: sha256CanonicalV2(policyBody) };
  const artifactPayload = Buffer.from("{}", "utf8");
  fs.mkdirSync(path.join(root, "artifacts"));
  fs.writeFileSync(path.join(root, "artifacts/example.json"), artifactPayload);
  const artifactSha = createHash("sha256").update(artifactPayload).digest("hex");
  const artifacts = [{
    artifact_id: "semantic.example",
    artifact_kind: "typed_facts",
    contract_id: "room16.example",
    contract_version: 1,
    layer: "L5_typed_fact",
    producer_pass_id: "rfc0008.fixture",
    relative_path: "artifacts/example.json",
    media_type: "application/json",
    sha256: artifactSha,
    byte_length: artifactPayload.length,
    required: true,
    owner: "research_compiler",
    compatibility_rule: "exact_hash",
    authoritative: true,
    compatibility_only: false,
    dependency_sha256s: [],
    provenance_refs: []
  }];
  const compileIdentity = {
    ticker: "WM",
    as_of_date: "2026-08-11",
    compile_request_sha256: null,
    source_acquisition_sha256: null,
    retrieval_receipt_set_sha256: null,
    source_snapshot_sha256: null,
    final_compile_state_sha256: "a".repeat(64),
    verification_report_sha256: "b".repeat(64),
    replay_sha256: "c".repeat(64),
    migration_v1_bundle_sha256: "d".repeat(64)
  };
  const compilerIdentity = { bundle_abi_version: "2.0.0", compiler_version: "1.0.0", semantic_artifact_origin: "frozen_v1_migration" };
  const emitterIdentity = {
    emitter_id: "room16.compiler_artifact_bundle_builder_v2",
    emitter_version: "2.0.0-rfc0008",
    producer_pass_id: "rfc0008.l11.emit_migration_bundle_v2",
    implementation_sha256: "e".repeat(64),
    schema_sha256: "f".repeat(64),
    consumer_policy_sha256: consumerPolicy.policy_sha256
  };
  const manifestBody = {
    contract_id: "room16.compiler_artifact_bundle",
    contract_version: 2,
    schema_version: "2.0.0",
    canonicalization_profile: "room16.foundation.canonical_json@1",
    hash_algorithm: "sha256",
    compiler_identity: compilerIdentity,
    emitter_identity: emitterIdentity,
    compile_identity: compileIdentity,
    compatibility: {
      mode: "bundle_dual_read",
      compiler_mode: "migration_dual_read",
      source_native_fact_generation: false,
      native_source_production: false,
      legacy_semantic_input_allowed: false,
      authority_v3_semantic_input_allowed: false,
      authority_v3_bridge_direction: "disabled"
    },
    eligibility: {
      compile_allowed: true,
      renderer_eligible: true,
      renderer_cutover: false,
      ba11_frozen: true,
      ba12_cutover_candidate: false,
      release_ready: false,
      publication_allowed: false,
      deploy_allowed: false
    },
    ba10_v1_freeze_sha256: policyBody.ba10_v1_freeze_sha256,
    ba11_freeze_sha256: policyBody.ba11_freeze_sha256,
    artifact_index_sha256: sha256CanonicalV2(artifacts),
    artifacts,
    section_index_sha256: sha256CanonicalV2([]),
    sections: [],
    required_sections: ["typed_facts"],
    optional_sections: [],
    extensions: { migration: { canonical_authority: false } }
  };
  const manifest = { ...manifestBody, bundle_sha256: sha256CanonicalV2(manifestBody) };
  writeJson(path.join(root, "BUNDLE_MANIFEST.json"), manifest);
  const receiptBody = {
    contract_id: "room16.compiler_artifact_bundle_receipt",
    contract_version: 2,
    receipt_id: "rfc0008.product.fixture",
    bundle_sha256: manifest.bundle_sha256,
    compile_identity_sha256: sha256CanonicalV2(compileIdentity),
    compiler_identity_sha256: sha256CanonicalV2(compilerIdentity),
    emitter_identity_sha256: sha256CanonicalV2(emitterIdentity),
    policy_sha256: consumerPolicy.policy_sha256,
    ba10_v1_freeze_sha256: policyBody.ba10_v1_freeze_sha256,
    ba11_freeze_sha256: policyBody.ba11_freeze_sha256,
    research_key_id: "research.test.ephemeral",
    issued_at_utc: "2026-08-21T01:00:00Z",
    not_after_utc: null,
    monotonic_counter: 1,
    nonce: "product-fixture-nonce-0001",
    signature_algorithm: "ed25519"
  };
  const signature = sign(null, Buffer.from(canonicalJsonV2(receiptBody)), privateKey).toString("hex");
  const signed = { ...receiptBody, signature };
  const receipt = { ...signed, receipt_sha256: sha256CanonicalV2({ domain: "room16.compiler_artifact_bundle_receipt@2", value: signed }) };
  const policyPath = path.join(root, "consumer-policy.json");
  const keysPath = path.join(root, "keys.json");
  writeJson(policyPath, consumerPolicy);
  writeJson(keysPath, keyPolicy);
  return { root, manifest, receipt, policyPath, keysPath };
}

test("RFC8 Product v2 verifies a signed migration bundle read-only", () => {
  const value = fixture();
  const before = fs.readFileSync(path.join(value.root, "BUNDLE_MANIFEST.json"));
  const verified = verifyCompilerArtifactBundleV2(value.root, { receipt: value.receipt, consumerPolicyPath: value.policyPath, keyPolicyPath: value.keysPath });
  assert.equal(verified.manifest.contract_version, 2);
  assert.deepEqual(fs.readFileSync(path.join(value.root, "BUNDLE_MANIFEST.json")), before);
});

test("RFC8 Product v2 rejects signature and native-state tamper", () => {
  const value = fixture();
  const badReceipt = { ...value.receipt, signature: `00${value.receipt.signature.slice(2)}` };
  badReceipt.receipt_sha256 = sha256CanonicalV2({ domain: "room16.compiler_artifact_bundle_receipt@2", value: Object.fromEntries(Object.entries(badReceipt).filter(([key]) => key !== "receipt_sha256")) });
  assert.throws(() => verifyCompilerArtifactBundleV2(value.root, { receipt: badReceipt, consumerPolicyPath: value.policyPath, keyPolicyPath: value.keysPath }), (error) => error.diagnosticCode === "RFC8_RECEIPT_SIGNATURE_INVALID");
});

test("RFC8 version router never falls back and rejects dual canonical authority", () => {
  const value = fixture();
  const verified = verifyCompilerArtifactBundleVersioned(value.root, { expectedVersion: 2, receipt: value.receipt, consumerPolicyPath: value.policyPath, keyPolicyPath: value.keysPath });
  assert.equal(verified.version, 2);
  assert.throws(() => verifyCompilerArtifactBundleVersioned(value.root, { expectedVersion: 1, receipt: value.receipt, consumerPolicyPath: value.policyPath, keyPolicyPath: value.keysPath }), (error) => error.diagnosticCode === "RFC8_ROUTER_VERSION_MISMATCH");
  assert.throws(() => assertSingleCanonicalRun([
    { ticker: "WM", asOfDate: "2026-08-11", contractVersion: 1, canonical: true },
    { ticker: "WM", asOfDate: "2026-08-11", contractVersion: 2, canonical: true }
  ]), (error) => error.diagnosticCode === "RFC8_DUAL_CANONICAL_AUTHORITY");
});

test("RFC8 Product public trust mirror is byte-exact and contains no bundle allowlist", () => {
  const pairs = [
    ["room16_compiler_artifact_consumer_policy_v2.json", "consumer_policy_v2.json"],
    ["room16_compiler_artifact_trusted_keys_v2.json", "public_key_policy_v2.json"]
  ];
  for (const [productName, researchName] of pairs) {
    assert.deepEqual(
      fs.readFileSync(path.join(APP_ROOT, "config", productName)),
      fs.readFileSync(path.join(RESEARCH_ROOT, "research_agent/productization_v2/config", researchName))
    );
  }
  const policy = JSON.parse(fs.readFileSync(path.join(APP_ROOT, "config/room16_compiler_artifact_consumer_policy_v2.json")));
  assert.equal(policy.mutable_bundle_hash_allowlist_allowed, false);
  assert.equal(Object.hasOwn(policy, "bundle_hashes"), false);
  assert.ok(CompilerArtifactBundleV2Error);
});
