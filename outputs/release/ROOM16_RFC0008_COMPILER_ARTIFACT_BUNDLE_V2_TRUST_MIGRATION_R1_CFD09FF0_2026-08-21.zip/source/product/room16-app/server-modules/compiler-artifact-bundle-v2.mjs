import fs from "node:fs";
import path from "node:path";
import { createHash, createPublicKey, verify as verifySignature } from "node:crypto";
import { fileURLToPath } from "node:url";

const MODULE_DIR = path.dirname(fileURLToPath(import.meta.url));
const DEFAULT_POLICY = path.resolve(MODULE_DIR, "../config/room16_compiler_artifact_consumer_policy_v2.json");
const DEFAULT_KEYS = path.resolve(MODULE_DIR, "../config/room16_compiler_artifact_trusted_keys_v2.json");

export class CompilerArtifactBundleV2Error extends Error {
  constructor(diagnosticCode, detail = "") {
    super(detail ? `${diagnosticCode}:${detail}` : diagnosticCode);
    this.name = "CompilerArtifactBundleV2Error";
    this.diagnosticCode = diagnosticCode;
    this.detail = detail;
  }
}

function normalize(value) {
  if (value === null || typeof value === "boolean" || typeof value === "string") return value;
  if (typeof value === "number") {
    if (!Number.isFinite(value) || (Number.isInteger(value) && !Number.isSafeInteger(value))) {
      throw new CompilerArtifactBundleV2Error("RFC8_CANONICAL_VALUE_INVALID", String(value));
    }
    return Object.is(value, -0) ? 0 : value;
  }
  if (Array.isArray(value)) return value.map(normalize);
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.keys(value).sort().map((key) => [key, normalize(value[key])]));
  }
  throw new CompilerArtifactBundleV2Error("RFC8_CANONICAL_VALUE_INVALID", typeof value);
}

export function canonicalJsonV2(value) {
  return JSON.stringify(normalize(value));
}

export function sha256CanonicalV2(value) {
  return createHash("sha256").update(canonicalJsonV2(value), "utf8").digest("hex");
}

function sha256File(filePath) {
  return createHash("sha256").update(fs.readFileSync(filePath)).digest("hex");
}

function readJson(filePath, code) {
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch (error) {
    throw new CompilerArtifactBundleV2Error(code, error.message);
  }
}

function safePath(root, relativePath) {
  if (!relativePath || path.isAbsolute(relativePath) || relativePath.split(/[\\/]/).includes("..")) {
    throw new CompilerArtifactBundleV2Error("RFC8_ARTIFACT_PATH_UNSAFE", relativePath);
  }
  const resolved = path.resolve(root, relativePath);
  if (!resolved.startsWith(`${path.resolve(root)}${path.sep}`)) {
    throw new CompilerArtifactBundleV2Error("RFC8_ARTIFACT_PATH_UNSAFE", relativePath);
  }
  return resolved;
}

function readSelfHashedPolicy(filePath, contractId, code) {
  const value = readJson(filePath, code);
  const body = { ...value };
  delete body.policy_sha256;
  if (value.contract_id !== contractId || value.contract_version !== 2 || sha256CanonicalV2(body) !== value.policy_sha256) {
    throw new CompilerArtifactBundleV2Error(code, "identity_or_self_hash");
  }
  return value;
}

function utc(value) {
  const parsed = Date.parse(value);
  if (!Number.isFinite(parsed)) throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_TIME_INVALID", value);
  return parsed;
}

function signatureBody(receipt) {
  const body = { ...receipt };
  delete body.signature;
  delete body.receipt_sha256;
  return body;
}

function receiptDomainHash(receipt) {
  const body = { ...receipt };
  delete body.receipt_sha256;
  return sha256CanonicalV2({
    domain: "room16.compiler_artifact_bundle_receipt@2",
    value: body
  });
}

function rawEd25519PublicKey(hex) {
  const prefix = Buffer.from("302a300506032b6570032100", "hex");
  return createPublicKey({ key: Buffer.concat([prefix, Buffer.from(hex, "hex")]), format: "der", type: "spki" });
}

export function verifyBundleReceiptV2(receipt, manifest, {
  consumerPolicy,
  keyPolicy,
  nowUtc,
  verificationState = { consumedNonces: new Set(), minimumCounterByKey: new Map() },
  consume = false
}) {
  const expected = {
    bundle_sha256: manifest.bundle_sha256,
    compile_identity_sha256: sha256CanonicalV2(manifest.compile_identity),
    compiler_identity_sha256: sha256CanonicalV2(manifest.compiler_identity),
    emitter_identity_sha256: sha256CanonicalV2(manifest.emitter_identity),
    policy_sha256: consumerPolicy.policy_sha256,
    ba10_v1_freeze_sha256: manifest.ba10_v1_freeze_sha256,
    ba11_freeze_sha256: manifest.ba11_freeze_sha256
  };
  for (const [key, value] of Object.entries(expected)) {
    if (receipt[key] !== value) throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_BINDING_MISMATCH", key);
  }
  if (receipt.contract_id !== "room16.compiler_artifact_bundle_receipt" || receipt.contract_version !== 2 || receipt.signature_algorithm !== "ed25519") {
    throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_CONTRACT_INVALID");
  }
  if (receiptDomainHash(receipt) !== receipt.receipt_sha256) {
    throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_HASH_MISMATCH");
  }
  const key = keyPolicy.keys.find((item) => item.key_id === receipt.research_key_id);
  if (!key) throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_UNKNOWN_KEY");
  if (key.state === "revoked") throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_REVOKED_KEY");
  const now = utc(nowUtc);
  if (now < utc(key.not_before_utc) || (key.not_after_utc && now >= utc(key.not_after_utc))) {
    throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_KEY_EXPIRED");
  }
  if (now < utc(receipt.issued_at_utc) || (receipt.not_after_utc && now >= utc(receipt.not_after_utc))) {
    throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_EXPIRED");
  }
  if (verificationState.consumedNonces.has(receipt.nonce)) {
    throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_NONCE_REPLAY");
  }
  if (receipt.monotonic_counter <= (verificationState.minimumCounterByKey.get(receipt.research_key_id) || 0)) {
    throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_COUNTER_REPLAY");
  }
  const valid = verifySignature(
    null,
    Buffer.from(canonicalJsonV2(signatureBody(receipt)), "utf8"),
    rawEd25519PublicKey(key.public_key_hex),
    Buffer.from(receipt.signature, "hex")
  );
  if (!valid) throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_SIGNATURE_INVALID");
  if (consume) {
    verificationState.consumedNonces.add(receipt.nonce);
    verificationState.minimumCounterByKey.set(receipt.research_key_id, receipt.monotonic_counter);
  }
}

export function verifyCompilerArtifactBundleV2(root, {
  receipt,
  consumerPolicyPath = DEFAULT_POLICY,
  keyPolicyPath = DEFAULT_KEYS,
  nowUtc = "2026-08-21T12:00:00Z",
  verificationState,
  consumeReceipt = false
} = {}) {
  const resolvedRoot = path.resolve(root);
  const manifestPath = path.join(resolvedRoot, "BUNDLE_MANIFEST.json");
  if (!fs.existsSync(manifestPath)) throw new CompilerArtifactBundleV2Error("RFC8_BUNDLE_MISSING", resolvedRoot);
  const manifest = readJson(manifestPath, "RFC8_MANIFEST_INVALID");
  const consumerPolicy = readSelfHashedPolicy(consumerPolicyPath, "room16.compiler.consumer_policy_lock", "RFC8_POLICY_INVALID");
  const keyPolicy = readSelfHashedPolicy(keyPolicyPath, "room16.compiler.public_key_policy", "RFC8_KEY_POLICY_INVALID");
  const body = { ...manifest };
  delete body.bundle_sha256;
  if (
    manifest.contract_id !== "room16.compiler_artifact_bundle" ||
    manifest.contract_version !== 2 || manifest.schema_version !== "2.0.0" ||
    sha256CanonicalV2(body) !== manifest.bundle_sha256
  ) throw new CompilerArtifactBundleV2Error("RFC8_MANIFEST_INVALID", "identity_or_hash");
  if (
    consumerPolicy.artifact_bundle_contract_major !== 2 ||
    consumerPolicy.mutable_bundle_hash_allowlist_allowed !== false ||
    consumerPolicy.product_may_edit_semantics !== false ||
    manifest.emitter_identity?.emitter_id !== consumerPolicy.trusted_emitter_id ||
    manifest.emitter_identity?.consumer_policy_sha256 !== consumerPolicy.policy_sha256 ||
    keyPolicy.policy_sha256 !== consumerPolicy.key_policy_sha256 ||
    manifest.ba10_v1_freeze_sha256 !== consumerPolicy.ba10_v1_freeze_sha256 ||
    manifest.ba11_freeze_sha256 !== consumerPolicy.ba11_freeze_sha256
  ) throw new CompilerArtifactBundleV2Error("RFC8_TRUST_POLICY_MISMATCH");
  const compatibility = manifest.compatibility || {};
  if (
    compatibility.legacy_semantic_input_allowed !== false ||
    compatibility.authority_v3_semantic_input_allowed !== false ||
    !consumerPolicy.allowed_authority_v3_bridge_directions.includes(compatibility.authority_v3_bridge_direction)
  ) throw new CompilerArtifactBundleV2Error("RFC8_COMPATIBILITY_DIRECTION_INVALID");
  if (compatibility.mode === "bundle_native") {
    if (compatibility.compiler_mode !== "source_native" || compatibility.source_native_fact_generation !== true || compatibility.native_source_production !== true) {
      throw new CompilerArtifactBundleV2Error("RFC8_NATIVE_STATE_FALSE");
    }
  } else if (compatibility.mode === "bundle_dual_read") {
    if (compatibility.compiler_mode !== "migration_dual_read" || compatibility.source_native_fact_generation !== false || compatibility.native_source_production !== false) {
      throw new CompilerArtifactBundleV2Error("RFC8_MIGRATION_STATE_FALSE");
    }
  } else throw new CompilerArtifactBundleV2Error("RFC8_COMPATIBILITY_MODE_INVALID");
  const artifactHashes = new Set(manifest.artifacts.map((item) => item.sha256));
  const bridgeHashes = new Set(manifest.artifacts.filter((item) => item.artifact_kind === "authority_v3_bridge").map((item) => item.sha256));
  for (const artifact of manifest.artifacts) {
    const artifactPath = safePath(resolvedRoot, artifact.relative_path);
    if (!fs.existsSync(artifactPath) || fs.statSync(artifactPath).size !== artifact.byte_length || sha256File(artifactPath) !== artifact.sha256) {
      throw new CompilerArtifactBundleV2Error("RFC8_ARTIFACT_HASH_MISMATCH", artifact.artifact_id);
    }
    if ((artifact.dependency_sha256s || []).some((value) => !artifactHashes.has(value))) {
      throw new CompilerArtifactBundleV2Error("RFC8_ARTIFACT_DEPENDENCY_UNRESOLVED", artifact.artifact_id);
    }
    if (artifact.authoritative && (artifact.dependency_sha256s || []).some((value) => bridgeHashes.has(value))) {
      throw new CompilerArtifactBundleV2Error("RFC8_INVERSE_AUTHORITY_BRIDGE", artifact.artifact_id);
    }
  }
  if (!receipt) throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_MISSING");
  const receiptValue = typeof receipt === "string" ? readJson(receipt, "RFC8_RECEIPT_INVALID") : receipt;
  verifyBundleReceiptV2(receiptValue, manifest, { consumerPolicy, keyPolicy, nowUtc, verificationState, consume: consumeReceipt });
  return { root: resolvedRoot, manifest, receipt: receiptValue };
}
