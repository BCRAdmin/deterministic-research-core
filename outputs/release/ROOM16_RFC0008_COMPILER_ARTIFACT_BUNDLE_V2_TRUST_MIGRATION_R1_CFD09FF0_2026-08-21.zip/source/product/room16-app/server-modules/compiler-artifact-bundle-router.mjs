import fs from "node:fs";
import path from "node:path";
import { verifyCompilerArtifactBundle } from "./compiler-artifact-bundle.mjs";
import { CompilerArtifactBundleV2Error, verifyCompilerArtifactBundleV2 } from "./compiler-artifact-bundle-v2.mjs";

export function verifyCompilerArtifactBundleVersioned(root, { expectedVersion, ...v2Options } = {}) {
  const manifestPath = path.join(path.resolve(root), "BUNDLE_MANIFEST.json");
  let manifest;
  try {
    manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
  } catch (error) {
    throw new CompilerArtifactBundleV2Error("RFC8_ROUTER_MANIFEST_INVALID", error.message);
  }
  const version = manifest.contract_version;
  if (expectedVersion !== undefined && version !== expectedVersion) {
    throw new CompilerArtifactBundleV2Error("RFC8_ROUTER_VERSION_MISMATCH", `${version}:${expectedVersion}`);
  }
  if (version === 1) return { version: 1, ...verifyCompilerArtifactBundle(root) };
  if (version === 2) return { version: 2, ...verifyCompilerArtifactBundleV2(root, v2Options) };
  throw new CompilerArtifactBundleV2Error("RFC8_ROUTER_VERSION_UNSUPPORTED", String(version));
}

export function assertSingleCanonicalRun(candidates) {
  const canonical = new Map();
  for (const item of candidates) {
    if (!item.canonical) continue;
    const runId = `${item.ticker}:${item.asOfDate}`;
    if (canonical.has(runId)) {
      throw new CompilerArtifactBundleV2Error("RFC8_DUAL_CANONICAL_AUTHORITY", runId);
    }
    canonical.set(runId, item.contractVersion);
  }
  return canonical;
}
