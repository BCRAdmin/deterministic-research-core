# Independent RFC-0008 Rereview Request

Please independently verify the v2 ABI, Research-owned public trust boundary,
v1/v2 isolation, rotation/revocation behavior, three migration canaries,
private-key absence, and unchanged BA10/BA11 freezes. Acceptance may freeze
RFC-0008 and separately authorize BA12 resume; this package does not do so.
