# Independent RFC Decision Required

Approve and independently freeze a versioned additive live-retrieval receipt transport contract or BA3 successor. It must preserve the accepted meanings of `offline_replay` and `offline_fixture`, add a truthful `live_acquisition` transport, define compatibility and replay rules, update the semantic-wave schema/version lock, and require WM/COST/ABT plus live-capture replay evidence. It does not authorize release, publication, deploy, merge, or history rewrite.
