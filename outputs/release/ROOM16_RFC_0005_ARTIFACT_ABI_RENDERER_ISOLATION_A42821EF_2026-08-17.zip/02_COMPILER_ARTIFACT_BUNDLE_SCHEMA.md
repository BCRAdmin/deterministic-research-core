# CompilerArtifactBundle Schema

The strict manifest binds compile identity, compiler/foundation/registry locks,
pass manifest, artifact index, required and optional sections, compatibility,
eligibility and consumer capabilities. Canonical serialization is frozen
Foundation Canonical JSON v1 with NFC strings and SHA-256. Unknown top-level
fields fail closed; future additive data is confined to `extensions` and may
only be ignored when the declared consumer capabilities allow it.

Every required section independently binds `schema_version`, `sha256`,
`owner=research_compiler`, `compatibility_rule`, required/optional state and
its referenced artifact IDs. The section index is itself hash-bound.

Required content includes source provenance, parsed/table IR, typed facts,
metrics, formula evaluations, evidence, claims, decisions, diagnostics,
compile verdict, verification plan/report and the presentation projection.
The complete machine-readable manifests are in `ARTIFACT_MANIFESTS/`.
