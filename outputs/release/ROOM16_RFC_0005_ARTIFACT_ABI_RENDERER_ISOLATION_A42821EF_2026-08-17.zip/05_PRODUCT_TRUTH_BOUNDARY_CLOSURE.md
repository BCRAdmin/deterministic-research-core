# Product Truth Boundary Closure

Product's canonical input is `room16.compiler_artifact_bundle@1`. Product may
validate, select, format and display compiler-owned values. It cannot mint
facts, metrics, claims, evidence, decisions or ratings on this path. Former
semantic Product components are explicitly classified as SEMANTIC_TRANSFORM or
DUPLICATE_TRUTH and have no canonical import or execution edge. They remain
visible only as historical compatibility code, not as a second authority.

Negative renderer fixtures prove the stable blocks
`RENDERER_NEW_FACT_DETECTED`, `RENDERER_NEW_CLAIM_DETECTED`,
`RENDERER_NEW_DECISION_DETECTED`, `RENDERER_NUMERIC_TOKEN_UNBOUND` and
`RENDERER_NEW_TRUTH_DETECTED`.
