# Authority Bundle v3 Bridge

The bridge is one-way: CompilerArtifactBundle → Authority Bundle v3
compatibility view. Every file is copied byte-for-byte from the frozen source
archive, indexed and hash-bound. It is explicitly `semantic_authority=false`.
All WM/COST/ABT files passed source-byte parity. No reverse import promotes v3
to compiler truth and no Authority Bundle v4 was introduced.
