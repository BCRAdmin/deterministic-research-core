# Renderer Migration Matrix

| Surface | Classification | BA10 state |
|---|---|---|
| Markdown | PRESENTATION_TRANSFORM | Compiler-bound canonical input; hash verified |
| DOCX | PRESENTATION_TRANSFORM | Bundle renderer; no-new-truth artifact set |
| PDF | PRESENTATION_TRANSFORM | Bundle renderer; no-new-truth artifact set |
| JSON | PURE_CONSUMER | Verified, deeply frozen bundle document |
| API | PURE_CONSUMER | Verified, deeply frozen API payload and endpoint |
| UI | PURE_CONSUMER | Verified, deeply frozen UI payload and status component |
| Authority v3 readers | LEGACY_BRIDGE | One-way byte-parity view only |

Migration phases 1–6 are closed for the canonical BA10 path: sidecar, shadow
consumers, semantic diff, first renderer, all listed consumer surfaces and
removal of legacy semantic imports/execution edges. Historical compatibility
files remain noncanonical because this RFC explicitly forbids a Big Bang and
requires the Authority v3 bridge to remain available.
