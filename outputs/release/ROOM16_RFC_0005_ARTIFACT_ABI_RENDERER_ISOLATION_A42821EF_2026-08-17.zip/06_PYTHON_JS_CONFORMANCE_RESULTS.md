# Python / JS Conformance Results

The Research-owned corpus covers canonical JSON ordering, Unicode/NFC,
nesting, null/booleans, numeric handling and SHA-256. Python and JavaScript
produce the exact same canonical bytes and hashes. Missing or unknown required
fields or sections, unsafe numbers, non-NFC text, unsafe paths, artifact or
section-index tampering fail closed with stable diagnostic codes.
All three real Canary bundles were independently verified by both runtimes.
