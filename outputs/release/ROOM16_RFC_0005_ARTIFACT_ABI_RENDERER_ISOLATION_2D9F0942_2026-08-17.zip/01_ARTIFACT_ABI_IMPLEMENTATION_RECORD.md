# Artifact ABI Implementation Record

- Contract: `room16.compiler_artifact_bundle@1`
- Manifest schema: `1.1.0`
- Research commit: `2d9f0942facaeb493c7d6658502aa2fd9e30c379`
- Product commit: `2a0bebe5cf968fbe1e815dad41730d218796efe4`
- Producer: Research L11 packaging above frozen BA0–BA9
- Consumers: Product JSON/API/UI projections and Markdown/DOCX/PDF renderers
- Section contract: 17 required semantic sections, each with schema version,
  SHA-256, Research owner, compatibility rule and artifact references
- Failure mode: fail closed on version, field, path, hash, capability, missing
  artifact, Unicode, numeric, compatibility or renderer-invariant violations.
- Current mode: `authority_v3_compatibility_shadow`
