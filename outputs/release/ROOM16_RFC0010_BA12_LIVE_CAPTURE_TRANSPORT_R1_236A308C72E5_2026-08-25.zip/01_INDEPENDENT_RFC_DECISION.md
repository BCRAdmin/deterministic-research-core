# Independent RFC Decision

Verdict: **ACCEPTED_FOR_IMPLEMENTATION**

Selected mechanism: **additive live-capture transport before the frozen BA3
compiler boundary**.

Rejected mechanism: modifying `RetrievalReceiptIR@1.transport`.

Rejected mechanism: `RetrievalReceiptIR@2` / `SourceSnapshotIR@2` plus a
Semantic-Wave version bump.

Reason: a successor BA3 IR would also alter the frozen 91-schema set and then
force a new semantic-wave identity, which would cascade into the already
frozen RFC-0009 native Consumer Policy compiler locks. That is unnecessary.

The existing BA3 contracts already separate:
- live acquisition planning (`CompilePolicyIR.network_mode`);
- live acquisition item intent (`SourceAcquisitionItemIR.retrieval_mode`);
- offline deterministic compiler ingress (`RetrievalReceiptIR.transport`).

RFC-0010 supplies the missing execution/provenance contract between the live
plan and immutable offline compiler ingress.

No frozen contract is reinterpreted or edited.
