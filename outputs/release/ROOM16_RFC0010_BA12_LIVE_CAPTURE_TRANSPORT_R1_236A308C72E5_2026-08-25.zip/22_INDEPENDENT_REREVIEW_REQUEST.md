# Independent Rereview Request

Please independently verify and accept/freeze RFC-0010. Until that separate decision, `rfc0010_frozen=false` and `ba12_resume_authorized=false`. No release, publication or deploy is authorized.
