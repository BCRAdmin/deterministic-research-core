import fs from "node:fs";
import path from "node:path";
import { createHash, createPublicKey, verify as verifySignature } from "node:crypto";
import { fileURLToPath } from "node:url";

const MODULE_DIR = path.dirname(fileURLToPath(import.meta.url));
const CONFIG_DIR = path.resolve(MODULE_DIR, "../config");
const TRUST_ROOT_PATH = path.join(CONFIG_DIR, "room16_compiler_v2_trust_root.json");
const CONSUMER_ENVELOPE_PATH = path.join(CONFIG_DIR, "room16_compiler_artifact_consumer_policy_envelope_v2.json");
const KEY_ENVELOPE_PATH = path.join(CONFIG_DIR, "room16_compiler_artifact_key_policy_envelope_v2.json");
const SCHEMA_PROFILE_PATH = path.join(CONFIG_DIR, "room16_compiler_artifact_bundle_schema_profile_v2.json");

export const PINNED_RFC0008_V2_TRUST_ROOT_SHA256 = "56a94fcd6eede746dc2778f05774bc46f80cd50be02cf3302027aab729f8a356";
export const PINNED_RFC0008_V2_ROOT_PUBLIC_KEY_HEX = "621d4a04fb14f322e2cfd57f650532c43f2d4c0d45c0f4d6834f5b9dd14af034";
export const PINNED_RFC0008_V2_SCHEMA_PROFILE_SHA256 = "2abbedc920bcac4d2470ee1a63e3e258ce7e82c6a9e034d0455330fd6f9b72c3";

const SHA256_RE = /^[0-9a-f]{64}$/;
const RECEIPT_FIELDS = ["ba10_v1_freeze_sha256", "ba11_freeze_sha256", "bundle_sha256", "compile_identity_sha256", "compiler_identity_sha256", "contract_id", "contract_version", "emitter_identity_sha256", "issued_at_utc", "monotonic_counter", "nonce", "not_after_utc", "policy_sha256", "receipt_id", "receipt_sha256", "research_key_id", "signature", "signature_algorithm"];
const ROOT_FIELDS = ["artifact_bundle_contract_major", "ba10_v1_freeze_sha256", "ba11_freeze_sha256", "canonicalization_profile", "consumer_policy_contract_id", "consumer_policy_contract_version", "contract_id", "contract_version", "hash_algorithm", "issued_at_utc", "owner", "public_key_policy_contract_id", "public_key_policy_contract_version", "root_id", "root_key_id", "root_public_key_hex", "root_sha256"];
const ENVELOPE_FIELDS = ["contract_id", "contract_version", "envelope_sha256", "generation", "issued_at_utc", "payload", "previous_envelope_sha256", "root_id", "root_key_id", "signature", "signature_algorithm"];
const CONSUMER_POLICY_FIELDS = ["allowed_authority_v3_bridge_directions", "artifact_bundle_contract_major", "ba10_v1_freeze_sha256", "ba11_freeze_sha256", "canonicalization_profile", "compiler_identity", "contract_id", "contract_version", "hash_algorithm", "key_policy_sha256", "legacy_semantic_input_allowed", "manifest_schema_profile_sha256", "mutable_bundle_hash_allowlist_allowed", "owner", "policy_sha256", "product_may_edit_semantics", "schema_version_max", "schema_version_min", "source_native_fact_generation_required_for_native", "trusted_emitter_id"];
const KEY_POLICY_FIELDS = ["contract_id", "contract_version", "keys", "owner", "policy_sha256", "rotation_sequence", "signature_algorithm"];
const KEY_FIELDS = ["key_id", "not_after_utc", "not_before_utc", "public_key_hex", "state"];

export class CompilerArtifactBundleV2Error extends Error {
  constructor(diagnosticCode, detail = "") {
    super(detail ? `${diagnosticCode}:${detail}` : diagnosticCode);
    this.name = "CompilerArtifactBundleV2Error";
    this.diagnosticCode = diagnosticCode;
    this.detail = detail;
  }
}

function normalize(value) {
  if (value === null || typeof value === "boolean" || typeof value === "string") return value;
  if (typeof value === "number") {
    if (!Number.isFinite(value) || (Number.isInteger(value) && !Number.isSafeInteger(value))) throw new CompilerArtifactBundleV2Error("RFC8_CANONICAL_VALUE_INVALID", String(value));
    return Object.is(value, -0) ? 0 : value;
  }
  if (Array.isArray(value)) return value.map(normalize);
  if (value && typeof value === "object") return Object.fromEntries(Object.keys(value).sort().map((key) => [key, normalize(value[key])]));
  throw new CompilerArtifactBundleV2Error("RFC8_CANONICAL_VALUE_INVALID", typeof value);
}

export function canonicalJsonV2(value) { return JSON.stringify(normalize(value)); }
export function sha256CanonicalV2(value) { return createHash("sha256").update(canonicalJsonV2(value), "utf8").digest("hex"); }
function sha256File(filePath) { return createHash("sha256").update(fs.readFileSync(filePath)).digest("hex"); }

function readJson(filePath, code) {
  try { return JSON.parse(fs.readFileSync(filePath, "utf8")); }
  catch (error) { throw new CompilerArtifactBundleV2Error(code, error.message); }
}

function exactObject(value, fields, code) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new CompilerArtifactBundleV2Error(code, "not_object");
  const actual = Object.keys(value).sort();
  const expected = [...fields].sort();
  if (actual.length !== expected.length || actual.some((item, index) => item !== expected[index])) throw new CompilerArtifactBundleV2Error(code, `fields:${actual.join(",")}`);
}

function safePath(root, relativePath) {
  if (!relativePath || path.isAbsolute(relativePath) || relativePath.split(/[\\/]/).includes("..")) throw new CompilerArtifactBundleV2Error("RFC8_ARTIFACT_PATH_UNSAFE", relativePath);
  const resolved = path.resolve(root, relativePath);
  if (!resolved.startsWith(`${path.resolve(root)}${path.sep}`)) throw new CompilerArtifactBundleV2Error("RFC8_ARTIFACT_PATH_UNSAFE", relativePath);
  return resolved;
}

function rawEd25519PublicKey(hex) {
  const prefix = Buffer.from("302a300506032b6570032100", "hex");
  return createPublicKey({ key: Buffer.concat([prefix, Buffer.from(hex, "hex")]), format: "der", type: "spki" });
}

function utc(value, code = "RFC8_RECEIPT_TIME_INVALID") {
  const parsed = Date.parse(value);
  if (!Number.isFinite(parsed)) throw new CompilerArtifactBundleV2Error(code, value);
  return parsed;
}

function verifySelfHashedPolicy(policy, expectedFields, contractId, code) {
  exactObject(policy, expectedFields, code);
  const body = { ...policy }; delete body.policy_sha256;
  if (policy.contract_id !== contractId || policy.contract_version !== 2 || sha256CanonicalV2(body) !== policy.policy_sha256) throw new CompilerArtifactBundleV2Error(code, "identity_or_self_hash");
}

function envelopeSignatureBody(envelope) { const body = { ...envelope }; delete body.signature; delete body.envelope_sha256; return body; }
function envelopeSignaturePreimage(envelope) { return { domain: `${envelope.contract_id}@${envelope.contract_version}`, value: envelopeSignatureBody(envelope) }; }
function envelopeDomainHash(envelope) { const body = { ...envelope }; delete body.envelope_sha256; return sha256CanonicalV2({ domain: `${envelope.contract_id}.envelope_hash@${envelope.contract_version}`, value: body }); }

function verifyTrustRoot(root) {
  exactObject(root, ROOT_FIELDS, "RFC8_R2_TRUST_ROOT_SCHEMA_INVALID");
  const body = { ...root }; delete body.root_sha256;
  if (root.contract_id !== "room16.compiler.v2_trust_root" || root.contract_version !== 1 || root.root_id !== "room16.compiler.v2_trust_root@1" || root.owner !== "research_compiler" || root.root_sha256 !== PINNED_RFC0008_V2_TRUST_ROOT_SHA256 || root.root_public_key_hex !== PINNED_RFC0008_V2_ROOT_PUBLIC_KEY_HEX || sha256CanonicalV2({ domain: root.root_id, value: body }) !== root.root_sha256) throw new CompilerArtifactBundleV2Error("RFC8_R2_TRUST_ROOT_PIN_MISMATCH");
}

function verifySignedEnvelope(envelope, root, expectedContractId, payloadContractId) {
  exactObject(envelope, ENVELOPE_FIELDS, "RFC8_R2_POLICY_ENVELOPE_SCHEMA_INVALID");
  if (envelope.contract_id !== expectedContractId || envelope.contract_version !== 2 || envelope.root_id !== root.root_id || envelope.root_key_id !== root.root_key_id || envelope.signature_algorithm !== "ed25519") throw new CompilerArtifactBundleV2Error("RFC8_R2_POLICY_ROOT_MISMATCH");
  if (envelopeDomainHash(envelope) !== envelope.envelope_sha256) throw new CompilerArtifactBundleV2Error("RFC8_R2_POLICY_ENVELOPE_HASH_MISMATCH");
  const valid = verifySignature(null, Buffer.from(canonicalJsonV2(envelopeSignaturePreimage(envelope)), "utf8"), rawEd25519PublicKey(root.root_public_key_hex), Buffer.from(envelope.signature, "hex"));
  if (!valid) throw new CompilerArtifactBundleV2Error("RFC8_R2_POLICY_ROOT_SIGNATURE_INVALID");
  if (payloadContractId === "room16.compiler.consumer_policy_lock") verifySelfHashedPolicy(envelope.payload, CONSUMER_POLICY_FIELDS, payloadContractId, "RFC8_R2_CONSUMER_POLICY_INVALID");
  else {
    verifySelfHashedPolicy(envelope.payload, KEY_POLICY_FIELDS, payloadContractId, "RFC8_R2_KEY_POLICY_INVALID");
    if (!Array.isArray(envelope.payload.keys)) throw new CompilerArtifactBundleV2Error("RFC8_R2_KEY_POLICY_INVALID", "keys");
    const ids = []; const publicKeys = [];
    for (const key of envelope.payload.keys) {
      exactObject(key, KEY_FIELDS, "RFC8_R2_KEY_POLICY_INVALID");
      if (!/^[0-9a-f]{64}$/.test(key.public_key_hex) || !["active", "grace_verify_only", "revoked"].includes(key.state)) throw new CompilerArtifactBundleV2Error("RFC8_R2_KEY_POLICY_INVALID", "key");
      ids.push(key.key_id); publicKeys.push(key.public_key_hex);
    }
    if (ids.join("\0") !== [...new Set(ids)].sort().join("\0")) throw new CompilerArtifactBundleV2Error("RFC8_R2_KEY_POLICY_INVALID", "key_order");
    if (publicKeys.length !== new Set(publicKeys).size) throw new CompilerArtifactBundleV2Error("RFC8_R2_KEY_POLICY_INVALID", "duplicate_public_key");
  }
}

export function verifySignedPolicyEnvelopeChainV2(envelopes, root) {
  verifyTrustRoot(root);
  if (!Array.isArray(envelopes) || envelopes.length === 0) throw new CompilerArtifactBundleV2Error("RFC8_R2_POLICY_CHAIN_EMPTY");
  const seen = new Set(); let previous = null;
  for (const envelope of envelopes) {
    const consumer = envelope.contract_id === "room16.compiler.consumer_policy_envelope";
    const expectedEnvelope = consumer ? "room16.compiler.consumer_policy_envelope" : "room16.compiler.public_key_policy_envelope";
    verifySignedEnvelope(envelope, root, expectedEnvelope, consumer ? "room16.compiler.consumer_policy_lock" : "room16.compiler.public_key_policy");
    if (seen.has(envelope.envelope_sha256)) throw new CompilerArtifactBundleV2Error("RFC8_R2_POLICY_CHAIN_FORK");
    seen.add(envelope.envelope_sha256);
    if (!previous) {
      if (envelope.generation !== 1 || envelope.previous_envelope_sha256 !== null) throw new CompilerArtifactBundleV2Error("RFC8_R2_POLICY_CHAIN_GENESIS_INVALID");
    } else if (envelope.generation !== previous.generation + 1 || envelope.previous_envelope_sha256 !== previous.envelope_sha256) throw new CompilerArtifactBundleV2Error("RFC8_R2_POLICY_CHAIN_ROLLBACK_OR_FORK");
    previous = envelope;
  }
  return previous;
}

function loadPinnedTrust() {
  const root = readJson(TRUST_ROOT_PATH, "RFC8_R2_TRUST_ROOT_INVALID"); verifyTrustRoot(root);
  const profile = readJson(SCHEMA_PROFILE_PATH, "RFC8_R2_SCHEMA_PROFILE_INVALID");
  const profileBody = { ...profile }; delete profileBody.profile_sha256;
  if (profile.profile_sha256 !== PINNED_RFC0008_V2_SCHEMA_PROFILE_SHA256 || sha256CanonicalV2(profileBody) !== profile.profile_sha256 || profile.unknown_field_policy !== "fail_closed" || profile.missing_field_policy !== "fail_closed") throw new CompilerArtifactBundleV2Error("RFC8_R2_SCHEMA_PROFILE_PIN_MISMATCH");
  const consumerEnvelope = readJson(CONSUMER_ENVELOPE_PATH, "RFC8_R2_CONSUMER_POLICY_INVALID");
  const keyEnvelope = readJson(KEY_ENVELOPE_PATH, "RFC8_R2_KEY_POLICY_INVALID");
  verifySignedPolicyEnvelopeChainV2([consumerEnvelope], root);
  verifySignedPolicyEnvelopeChainV2([keyEnvelope], root);
  const consumerPolicy = consumerEnvelope.payload; const keyPolicy = keyEnvelope.payload;
  if (consumerPolicy.key_policy_sha256 !== keyPolicy.policy_sha256 || consumerPolicy.manifest_schema_profile_sha256 !== profile.profile_sha256 || consumerPolicy.ba10_v1_freeze_sha256 !== root.ba10_v1_freeze_sha256 || consumerPolicy.ba11_freeze_sha256 !== root.ba11_freeze_sha256) throw new CompilerArtifactBundleV2Error("RFC8_R2_TRUST_CHAIN_BINDING_MISMATCH");
  return { root, profile, consumerPolicy, keyPolicy };
}

function validateManifestSchema(manifest, profile) {
  exactObject(manifest, profile.models.bundle_manifest, "RFC8_R2_MANIFEST_SCHEMA_INVALID");
  exactObject(manifest.compiler_identity, profile.models.compiler_identity, "RFC8_R2_COMPILER_IDENTITY_SCHEMA_INVALID");
  exactObject(manifest.emitter_identity, profile.models.emitter_identity, "RFC8_R2_EMITTER_SCHEMA_INVALID");
  exactObject(manifest.compile_identity, profile.models.compile_identity, "RFC8_R2_COMPILE_IDENTITY_SCHEMA_INVALID");
  exactObject(manifest.compatibility, profile.models.compatibility, "RFC8_R2_COMPATIBILITY_SCHEMA_INVALID");
  exactObject(manifest.eligibility, profile.models.eligibility, "RFC8_R2_ELIGIBILITY_SCHEMA_INVALID");
  if (canonicalJsonV2(manifest.compiler_identity) !== canonicalJsonV2(profile.compiler_identity_lock)) throw new CompilerArtifactBundleV2Error("RFC8_R2_COMPILER_IDENTITY_LOCK_MISMATCH");
  const compileIdentity = manifest.compile_identity;
  const nullableCompileHashes = ["compile_request_sha256", "source_acquisition_sha256", "retrieval_receipt_set_sha256", "source_snapshot_sha256", "migration_v1_bundle_sha256"];
  if (!/^[A-Z0-9.^-]+$/.test(compileIdentity.ticker) || !/^\d{4}-\d{2}-\d{2}$/.test(compileIdentity.as_of_date) || !["final_compile_state_sha256", "verification_report_sha256", "replay_sha256"].every((field) => SHA256_RE.test(compileIdentity[field])) || !nullableCompileHashes.every((field) => compileIdentity[field] === null || SHA256_RE.test(compileIdentity[field]))) throw new CompilerArtifactBundleV2Error("RFC8_R2_COMPILE_IDENTITY_SCHEMA_INVALID", "value");
  const emitter = manifest.emitter_identity;
  if (emitter.emitter_id !== "room16.compiler_artifact_bundle_builder_v2" || emitter.emitter_version !== "2.0.0-rfc0008" || emitter.producer_pass_id !== "rfc0008.l11.emit_migration_bundle_v2" || !["implementation_sha256", "schema_sha256", "consumer_policy_sha256"].every((field) => SHA256_RE.test(emitter[field]))) throw new CompilerArtifactBundleV2Error("RFC8_R2_EMITTER_SCHEMA_INVALID", "value");
  if (manifest.contract_id !== profile.bundle_contract.contract_id || manifest.contract_version !== 2 || manifest.schema_version !== "2.0.0" || manifest.canonicalization_profile !== profile.bundle_contract.canonicalization_profile || manifest.hash_algorithm !== "sha256") throw new CompilerArtifactBundleV2Error("RFC8_MANIFEST_INVALID", "identity");
  for (const field of ["bundle_sha256", "artifact_index_sha256", "section_index_sha256"]) if (!SHA256_RE.test(manifest[field])) throw new CompilerArtifactBundleV2Error("RFC8_R2_MANIFEST_SCHEMA_INVALID", field);
  if (typeof manifest.eligibility.compile_allowed !== "boolean" || typeof manifest.eligibility.renderer_eligible !== "boolean" || manifest.eligibility.ba11_frozen !== true || manifest.eligibility.release_ready !== false || manifest.eligibility.publication_allowed !== false || manifest.eligibility.deploy_allowed !== false || manifest.eligibility.renderer_cutover !== false || manifest.eligibility.ba12_cutover_candidate !== false) throw new CompilerArtifactBundleV2Error("RFC8_R2_ELIGIBILITY_GATE_INVALID");
  const compatibility = manifest.compatibility;
  if (compatibility.legacy_semantic_input_allowed !== false || compatibility.authority_v3_semantic_input_allowed !== false) throw new CompilerArtifactBundleV2Error("RFC8_COMPATIBILITY_DIRECTION_INVALID");
  if (compatibility.mode === "bundle_dual_read") {
    if (compatibility.compiler_mode !== "migration_dual_read" || compatibility.source_native_fact_generation !== false || compatibility.native_source_production !== false || !manifest.compile_identity.migration_v1_bundle_sha256) throw new CompilerArtifactBundleV2Error("RFC8_MIGRATION_STATE_FALSE");
  } else if (compatibility.mode === "bundle_native") {
    if (compatibility.compiler_mode !== "source_native" || compatibility.source_native_fact_generation !== true || compatibility.native_source_production !== true || manifest.compile_identity.migration_v1_bundle_sha256 !== null) throw new CompilerArtifactBundleV2Error("RFC8_NATIVE_STATE_FALSE");
  } else throw new CompilerArtifactBundleV2Error("RFC8_COMPATIBILITY_MODE_INVALID");
  if (!Array.isArray(manifest.artifacts) || !Array.isArray(manifest.sections) || !Array.isArray(manifest.required_sections) || !Array.isArray(manifest.optional_sections)) throw new CompilerArtifactBundleV2Error("RFC8_R2_MANIFEST_SCHEMA_INVALID", "arrays");
  const ids = [], paths = [], hashes = new Set(), requiredKinds = new Set();
  for (const artifact of manifest.artifacts) {
    exactObject(artifact, profile.models.artifact, "RFC8_R2_ARTIFACT_SCHEMA_INVALID");
    if (!/^[a-z][a-z0-9_.-]*$/.test(artifact.artifact_id) || !/^[a-z][a-z0-9_.-]*$/.test(artifact.artifact_kind) || typeof artifact.contract_id !== "string" || (!Number.isSafeInteger(artifact.contract_version) && typeof artifact.contract_version !== "string") || typeof artifact.layer !== "string" || typeof artifact.producer_pass_id !== "string" || typeof artifact.media_type !== "string" || typeof artifact.required !== "boolean" || typeof artifact.authoritative !== "boolean" || typeof artifact.compatibility_only !== "boolean" || !["exact_hash", "byte_identical_compatibility_view"].includes(artifact.compatibility_rule) || !SHA256_RE.test(artifact.sha256) || !Number.isSafeInteger(artifact.byte_length) || artifact.byte_length < 0 || artifact.owner !== "research_compiler" || !Array.isArray(artifact.dependency_sha256s) || !artifact.dependency_sha256s.every((value) => SHA256_RE.test(value)) || !Array.isArray(artifact.provenance_refs) || !artifact.provenance_refs.every((value) => typeof value === "string")) throw new CompilerArtifactBundleV2Error("RFC8_R2_ARTIFACT_SCHEMA_INVALID", artifact.artifact_id);
    if (artifact.authoritative && artifact.compatibility_only) throw new CompilerArtifactBundleV2Error("RFC8_R2_ARTIFACT_AUTHORITY_INVALID", artifact.artifact_id);
    if (artifact.dependency_sha256s.join("\0") !== [...new Set(artifact.dependency_sha256s)].sort().join("\0")) throw new CompilerArtifactBundleV2Error("RFC8_R2_ARTIFACT_DEPENDENCY_INVALID", artifact.artifact_id);
    ids.push(artifact.artifact_id); paths.push(artifact.relative_path); hashes.add(artifact.sha256); if (artifact.required) requiredKinds.add(artifact.artifact_kind);
  }
  if (ids.join("\0") !== [...new Set(ids)].sort().join("\0") || paths.length !== new Set(paths).size) throw new CompilerArtifactBundleV2Error("RFC8_R2_ARTIFACT_INDEX_INVALID");
  if (sha256CanonicalV2(manifest.artifacts) !== manifest.artifact_index_sha256) throw new CompilerArtifactBundleV2Error("RFC8_R2_ARTIFACT_INDEX_HASH_MISMATCH");
  if (canonicalJsonV2(manifest.required_sections) !== canonicalJsonV2(profile.required_artifact_kinds) || profile.required_artifact_kinds.some((kind) => !requiredKinds.has(kind))) throw new CompilerArtifactBundleV2Error("RFC8_R2_REQUIRED_ARTIFACT_CLOSURE_INVALID");
  const sectionIds = [], artifactIdSet = new Set(ids);
  for (const section of manifest.sections) {
    exactObject(section, profile.models.bundle_section, "RFC8_R2_SECTION_SCHEMA_INVALID");
    if (!/^[a-z][a-z0-9_]*$/.test(section.section_id) || !/^\d+\.\d+\.\d+$/.test(section.schema_version) || !SHA256_RE.test(section.sha256) || section.owner !== "research_compiler" || typeof section.required !== "boolean" || !["exact_version", "same_major_additive", "immutable_reference", "byte_identical_compatibility_view"].includes(section.compatibility_rule) || !Array.isArray(section.artifact_ids) || section.artifact_ids.join("\0") !== [...new Set(section.artifact_ids)].sort().join("\0") || section.artifact_ids.some((id) => !artifactIdSet.has(id))) throw new CompilerArtifactBundleV2Error("RFC8_R2_SECTION_CLOSURE_INVALID", section.section_id);
    sectionIds.push(section.section_id);
  }
  if (sectionIds.join("\0") !== [...new Set(sectionIds)].sort().join("\0") || profile.required_bundle_section_ids.some((id) => !manifest.sections.some((item) => item.section_id === id && item.required))) throw new CompilerArtifactBundleV2Error("RFC8_R2_SECTION_INDEX_INVALID");
  if (sha256CanonicalV2(manifest.sections) !== manifest.section_index_sha256) throw new CompilerArtifactBundleV2Error("RFC8_R2_SECTION_INDEX_HASH_MISMATCH");
  const bridgeHashes = new Set(manifest.artifacts.filter((item) => item.artifact_kind === "authority_v3_bridge").map((item) => item.sha256));
  for (const artifact of manifest.artifacts) {
    if (artifact.dependency_sha256s.some((value) => !hashes.has(value))) throw new CompilerArtifactBundleV2Error("RFC8_ARTIFACT_DEPENDENCY_UNRESOLVED", artifact.artifact_id);
    if (artifact.authoritative && artifact.dependency_sha256s.some((value) => bridgeHashes.has(value))) throw new CompilerArtifactBundleV2Error("RFC8_INVERSE_AUTHORITY_BRIDGE", artifact.artifact_id);
  }
  const body = { ...manifest }; delete body.bundle_sha256;
  if (sha256CanonicalV2(body) !== manifest.bundle_sha256) throw new CompilerArtifactBundleV2Error("RFC8_MANIFEST_INVALID", "hash");
}

function signatureBody(receipt) { const body = { ...receipt }; delete body.signature; delete body.receipt_sha256; return body; }
function receiptDomainHash(receipt) { const body = { ...receipt }; delete body.receipt_sha256; return sha256CanonicalV2({ domain: "room16.compiler_artifact_bundle_receipt@2", value: body }); }

export function verifyBundleReceiptV2(receipt, manifest, { consumerPolicy, keyPolicy, nowUtc, verificationState = { consumedNonces: new Set(), minimumCounterByKey: new Map() }, consume = false }) {
  exactObject(receipt, RECEIPT_FIELDS, "RFC8_RECEIPT_SCHEMA_INVALID");
  const expected = { bundle_sha256: manifest.bundle_sha256, compile_identity_sha256: sha256CanonicalV2(manifest.compile_identity), compiler_identity_sha256: sha256CanonicalV2(manifest.compiler_identity), emitter_identity_sha256: sha256CanonicalV2(manifest.emitter_identity), policy_sha256: consumerPolicy.policy_sha256, ba10_v1_freeze_sha256: manifest.ba10_v1_freeze_sha256, ba11_freeze_sha256: manifest.ba11_freeze_sha256 };
  for (const [key, value] of Object.entries(expected)) if (receipt[key] !== value) throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_BINDING_MISMATCH", key);
  if (receipt.contract_id !== "room16.compiler_artifact_bundle_receipt" || receipt.contract_version !== 2 || receipt.signature_algorithm !== "ed25519" || !Number.isSafeInteger(receipt.monotonic_counter) || receipt.monotonic_counter <= 0) throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_CONTRACT_INVALID");
  if (receiptDomainHash(receipt) !== receipt.receipt_sha256) throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_HASH_MISMATCH");
  const key = keyPolicy.keys.find((item) => item.key_id === receipt.research_key_id);
  if (!key) throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_UNKNOWN_KEY");
  if (key.state === "revoked") throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_REVOKED_KEY");
  const now = utc(nowUtc); if (now < utc(key.not_before_utc) || (key.not_after_utc && now >= utc(key.not_after_utc))) throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_KEY_EXPIRED");
  if (now < utc(receipt.issued_at_utc) || (receipt.not_after_utc && now >= utc(receipt.not_after_utc))) throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_EXPIRED");
  if (verificationState.consumedNonces.has(receipt.nonce)) throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_NONCE_REPLAY");
  if (receipt.monotonic_counter <= (verificationState.minimumCounterByKey.get(receipt.research_key_id) || 0)) throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_COUNTER_REPLAY");
  const valid = verifySignature(null, Buffer.from(canonicalJsonV2(signatureBody(receipt)), "utf8"), rawEd25519PublicKey(key.public_key_hex), Buffer.from(receipt.signature, "hex"));
  if (!valid) throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_SIGNATURE_INVALID");
  if (consume) { verificationState.consumedNonces.add(receipt.nonce); verificationState.minimumCounterByKey.set(receipt.research_key_id, receipt.monotonic_counter); }
}

export function verifyCompilerArtifactBundleV2(root, options = {}) {
  if (!options || typeof options !== "object" || Array.isArray(options)) throw new CompilerArtifactBundleV2Error("RFC8_R2_VERIFIER_OPTIONS_INVALID");
  const allowed = new Set(["receipt", "nowUtc", "verificationState", "consumeReceipt"]);
  const forbidden = Object.keys(options).filter((key) => !allowed.has(key));
  if (forbidden.length) throw new CompilerArtifactBundleV2Error("RFC8_R2_CALLER_TRUST_INPUT_FORBIDDEN", forbidden.join(","));
  const { receipt, nowUtc = "2026-08-21T12:00:00Z", verificationState, consumeReceipt = false } = options;
  const trust = loadPinnedTrust();
  const resolvedRoot = path.resolve(root); const manifestPath = path.join(resolvedRoot, "BUNDLE_MANIFEST.json");
  if (!fs.existsSync(manifestPath)) throw new CompilerArtifactBundleV2Error("RFC8_BUNDLE_MISSING", resolvedRoot);
  const manifest = readJson(manifestPath, "RFC8_MANIFEST_INVALID"); validateManifestSchema(manifest, trust.profile);
  const consumerPolicy = trust.consumerPolicy;
  if (manifest.emitter_identity.emitter_id !== consumerPolicy.trusted_emitter_id || manifest.emitter_identity.consumer_policy_sha256 !== consumerPolicy.policy_sha256 || canonicalJsonV2(manifest.compiler_identity) !== canonicalJsonV2(consumerPolicy.compiler_identity) || manifest.ba10_v1_freeze_sha256 !== consumerPolicy.ba10_v1_freeze_sha256 || manifest.ba11_freeze_sha256 !== consumerPolicy.ba11_freeze_sha256 || !consumerPolicy.allowed_authority_v3_bridge_directions.includes(manifest.compatibility.authority_v3_bridge_direction) || consumerPolicy.product_may_edit_semantics !== false || consumerPolicy.mutable_bundle_hash_allowlist_allowed !== false) throw new CompilerArtifactBundleV2Error("RFC8_TRUST_POLICY_MISMATCH");
  for (const artifact of manifest.artifacts) {
    const artifactPath = safePath(resolvedRoot, artifact.relative_path);
    if (!fs.existsSync(artifactPath) || fs.statSync(artifactPath).size !== artifact.byte_length || sha256File(artifactPath) !== artifact.sha256) throw new CompilerArtifactBundleV2Error("RFC8_ARTIFACT_HASH_MISMATCH", artifact.artifact_id);
  }
  if (!receipt) throw new CompilerArtifactBundleV2Error("RFC8_RECEIPT_MISSING");
  const receiptValue = typeof receipt === "string" ? readJson(receipt, "RFC8_RECEIPT_INVALID") : receipt;
  verifyBundleReceiptV2(receiptValue, manifest, { consumerPolicy, keyPolicy: trust.keyPolicy, nowUtc, verificationState, consume: consumeReceipt });
  return { root: resolvedRoot, manifest, receipt: receiptValue, trustRootSha256: trust.root.root_sha256 };
}
