import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const appRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const roots = ["server.mjs", "server-modules", "src"].map((item) => path.join(appRoot, item));
const files = [];
function collect(target) {
  if (!fs.existsSync(target)) return;
  const stat = fs.statSync(target);
  if (stat.isFile() && /\.(?:mjs|js|ts|tsx)$/.test(target)) files.push(target);
  else if (stat.isDirectory()) for (const item of fs.readdirSync(target)) collect(path.join(target, item));
}
roots.forEach(collect);

function topLevelArgumentCount(source, start) {
  let depth = 1, nested = 0, commas = 0, quote = null, escaped = false;
  for (let index = start; index < source.length; index += 1) {
    const char = source[index];
    if (quote) {
      if (escaped) escaped = false;
      else if (char === "\\") escaped = true;
      else if (char === quote) quote = null;
      continue;
    }
    if (["\"", "'", "`"].includes(char)) { quote = char; continue; }
    if (char === "(") depth += 1;
    else if (char === ")") { depth -= 1; if (depth === 0) return commas + 1; }
    else if (["{", "["].includes(char)) nested += 1;
    else if (["}", "]"].includes(char)) nested -= 1;
    else if (char === "," && depth === 1 && nested === 0) commas += 1;
  }
  return Number.POSITIVE_INFINITY;
}

const violations = [];
for (const file of files) {
  const source = fs.readFileSync(file, "utf8");
  const pattern = /verifyCompilerArtifactBundle(?:V2|Versioned)?\s*\(/g;
  for (const match of source.matchAll(pattern)) {
    const count = topLevelArgumentCount(source, match.index + match[0].length);
    if (count > 2) violations.push({ file: path.relative(appRoot, file), argument_count: count });
  }
  for (const forbidden of ["consumerPolicyPath", "keyPolicyPath"]) {
    if (source.includes(forbidden)) {
      violations.push({
        file: path.relative(appRoot, file),
        forbidden_trust_input: forbidden
      });
    }
  }
}
const result = {
  status: violations.length === 0 ? "PASS" : "FAIL",
  contract_id: "room16.product.runtime_trust_api_scan",
  contract_version: 2,
  scanned_file_count: files.length,
  alternative_trust_argument_calls: violations.length,
  violations
};
process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
if (violations.length) process.exitCode = 1;
