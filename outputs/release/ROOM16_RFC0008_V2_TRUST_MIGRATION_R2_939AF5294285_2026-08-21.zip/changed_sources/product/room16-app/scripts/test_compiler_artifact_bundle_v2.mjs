import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { fileURLToPath, pathToFileURL } from "node:url";

import {
  CompilerArtifactBundleV2Error,
  PINNED_RFC0008_V2_ROOT_PUBLIC_KEY_HEX,
  PINNED_RFC0008_V2_SCHEMA_PROFILE_SHA256,
  PINNED_RFC0008_V2_TRUST_ROOT_SHA256,
  sha256CanonicalV2,
  verifyCompilerArtifactBundleV2,
  verifySignedPolicyEnvelopeChainV2
} from "../server-modules/compiler-artifact-bundle-v2.mjs";
import {
  assertSingleCanonicalRun,
  verifyCompilerArtifactBundleVersioned
} from "../server-modules/compiler-artifact-bundle-router.mjs";

const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const RESEARCH_ROOT = path.resolve(APP_ROOT, "..", "..", "research-agent-ops");
const FIXTURE_ROOT = path.join(APP_ROOT, "fixtures/compiler-artifact-bundle-v2-pinned");
const CONFIG = path.join(APP_ROOT, "config");
const CHAIN_FIXTURES = path.join(APP_ROOT, "fixtures/rfc0008-v2-policy-chain");

function json(filePath) { return JSON.parse(fs.readFileSync(filePath, "utf8")); }
function pinnedReceipt() { return json(path.join(FIXTURE_ROOT, "RECEIPT.json")); }
function trustRoot() { return json(path.join(CONFIG, "room16_compiler_v2_trust_root.json")); }
function consumerEnvelope() { return json(path.join(CONFIG, "room16_compiler_artifact_consumer_policy_envelope_v2.json")); }
function keyEnvelope() { return json(path.join(CONFIG, "room16_compiler_artifact_key_policy_envelope_v2.json")); }

function mutableFixture() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "room16-rfc0008-r2-product-"));
  fs.cpSync(FIXTURE_ROOT, root, { recursive: true });
  return root;
}

function mutateManifest(root, mutate) {
  const manifestPath = path.join(root, "BUNDLE_MANIFEST.json");
  const manifest = json(manifestPath);
  mutate(manifest);
  const body = { ...manifest }; delete body.bundle_sha256;
  manifest.bundle_sha256 = sha256CanonicalV2(body);
  fs.writeFileSync(manifestPath, JSON.stringify(manifest));
}

async function isolatedVerifier(mutateConfig) {
  const isolated = fs.mkdtempSync(path.join(os.tmpdir(), "room16-rfc0008-r2-verifier-"));
  const moduleDir = path.join(isolated, "server-modules");
  const configDir = path.join(isolated, "config");
  fs.mkdirSync(moduleDir);
  fs.mkdirSync(configDir);
  fs.copyFileSync(path.join(APP_ROOT, "server-modules/compiler-artifact-bundle-v2.mjs"), path.join(moduleDir, "compiler-artifact-bundle-v2.mjs"));
  for (const name of [
    "room16_compiler_v2_trust_root.json",
    "room16_compiler_artifact_consumer_policy_envelope_v2.json",
    "room16_compiler_artifact_key_policy_envelope_v2.json",
    "room16_compiler_artifact_bundle_schema_profile_v2.json"
  ]) fs.copyFileSync(path.join(CONFIG, name), path.join(configDir, name));
  mutateConfig(configDir);
  return import(`${pathToFileURL(path.join(moduleDir, "compiler-artifact-bundle-v2.mjs")).href}?isolation=${Date.now()}-${Math.random()}`);
}

test("RFC8-R2 Product verifies only the pinned Research trust root", () => {
  const verified = verifyCompilerArtifactBundleV2(FIXTURE_ROOT, { receipt: pinnedReceipt() });
  assert.equal(verified.manifest.contract_version, 2);
  assert.equal(verified.trustRootSha256, PINNED_RFC0008_V2_TRUST_ROOT_SHA256);
});

test("RFC8-R2 blocks caller-selected attacker policy and key paths", () => {
  assert.throws(
    () => verifyCompilerArtifactBundleV2(FIXTURE_ROOT, {
      receipt: pinnedReceipt(),
      consumerPolicyPath: "/tmp/attacker-consumer-policy.json",
      keyPolicyPath: "/tmp/attacker-key-policy.json"
    }),
    (error) => error.diagnosticCode === "RFC8_R2_CALLER_TRUST_INPUT_FORBIDDEN"
  );
});

test("RFC8-R2 blocks replacement of both self-hashed Product policies", async () => {
  const module = await isolatedVerifier((configDir) => {
    const consumerPath = path.join(configDir, "room16_compiler_artifact_consumer_policy_envelope_v2.json");
    const keyPath = path.join(configDir, "room16_compiler_artifact_key_policy_envelope_v2.json");
    const consumer = json(consumerPath);
    const keys = json(keyPath);
    keys.payload.keys[0].state = "grace_verify_only";
    const keyPolicyBody = { ...keys.payload }; delete keyPolicyBody.policy_sha256;
    keys.payload.policy_sha256 = sha256CanonicalV2(keyPolicyBody);
    const keyEnvelopeBody = { ...keys }; delete keyEnvelopeBody.envelope_sha256;
    keys.envelope_sha256 = sha256CanonicalV2({ domain: `${keys.contract_id}.envelope_hash@${keys.contract_version}`, value: keyEnvelopeBody });
    consumer.payload.key_policy_sha256 = keys.payload.policy_sha256;
    const consumerPolicyBody = { ...consumer.payload }; delete consumerPolicyBody.policy_sha256;
    consumer.payload.policy_sha256 = sha256CanonicalV2(consumerPolicyBody);
    const consumerEnvelopeBody = { ...consumer }; delete consumerEnvelopeBody.envelope_sha256;
    consumer.envelope_sha256 = sha256CanonicalV2({ domain: `${consumer.contract_id}.envelope_hash@${consumer.contract_version}`, value: consumerEnvelopeBody });
    fs.writeFileSync(keyPath, JSON.stringify(keys));
    fs.writeFileSync(consumerPath, JSON.stringify(consumer));
  });
  assert.throws(() => module.verifyCompilerArtifactBundleV2(FIXTURE_ROOT, { receipt: pinnedReceipt() }), (error) => error.diagnosticCode === "RFC8_R2_POLICY_ROOT_SIGNATURE_INVALID");
});

test("RFC8-R2 blocks a tampered committed Product trust-root file", async () => {
  const module = await isolatedVerifier((configDir) => {
    const rootPath = path.join(configDir, "room16_compiler_v2_trust_root.json");
    const root = json(rootPath); root.root_public_key_hex = "0".repeat(64);
    fs.writeFileSync(rootPath, JSON.stringify(root));
  });
  assert.throws(() => module.verifyCompilerArtifactBundleV2(FIXTURE_ROOT, { receipt: pinnedReceipt() }), (error) => error.diagnosticCode === "RFC8_R2_TRUST_ROOT_PIN_MISMATCH");
});

test("RFC8-R2 root and signed policy envelopes are immutable and chained", () => {
  const root = trustRoot();
  assert.equal(root.root_sha256, PINNED_RFC0008_V2_TRUST_ROOT_SHA256);
  assert.equal(root.root_public_key_hex, PINNED_RFC0008_V2_ROOT_PUBLIC_KEY_HEX);
  const consumerTwo = json(path.join(CHAIN_FIXTURES, "consumer_policy_envelope_v2_generation_2.json"));
  const keyTwo = json(path.join(CHAIN_FIXTURES, "public_key_policy_envelope_v2_generation_2.json"));
  assert.equal(verifySignedPolicyEnvelopeChainV2([consumerEnvelope(), consumerTwo], root).generation, 2);
  assert.equal(verifySignedPolicyEnvelopeChainV2([keyEnvelope(), keyTwo], root).generation, 2);
  assert.throws(() => verifySignedPolicyEnvelopeChainV2([consumerTwo], root), (error) => error.diagnosticCode === "RFC8_R2_POLICY_CHAIN_GENESIS_INVALID");
  assert.throws(() => verifySignedPolicyEnvelopeChainV2([consumerEnvelope(), consumerEnvelope()], root), (error) => error.diagnosticCode === "RFC8_R2_POLICY_CHAIN_FORK");
  assert.throws(() => verifySignedPolicyEnvelopeChainV2([consumerEnvelope(), keyTwo], root), (error) => error.diagnosticCode === "RFC8_R2_POLICY_CHAIN_ROLLBACK_OR_FORK");
  const changedRoot = { ...root, root_public_key_hex: "0".repeat(64) };
  assert.throws(() => verifySignedPolicyEnvelopeChainV2([consumerEnvelope()], changedRoot), (error) => error.diagnosticCode === "RFC8_R2_TRUST_ROOT_PIN_MISMATCH");
  const changedEnvelope = consumerEnvelope(); changedEnvelope.payload.product_may_edit_semantics = true;
  assert.throws(() => verifySignedPolicyEnvelopeChainV2([changedEnvelope], root));
});

test("RFC8-R2 Product schema is strict for unknown and missing fields", () => {
  const unknown = mutableFixture();
  mutateManifest(unknown, (manifest) => { manifest.compiler_identity.attacker_field = true; });
  assert.throws(() => verifyCompilerArtifactBundleV2(unknown, { receipt: pinnedReceipt() }), (error) => error.diagnosticCode === "RFC8_R2_COMPILER_IDENTITY_SCHEMA_INVALID");
  const missing = mutableFixture();
  mutateManifest(missing, (manifest) => { delete manifest.eligibility.deploy_allowed; });
  assert.throws(() => verifyCompilerArtifactBundleV2(missing, { receipt: pinnedReceipt() }), (error) => error.diagnosticCode === "RFC8_R2_ELIGIBILITY_SCHEMA_INVALID");
});

test("RFC8-R2 Product pins every frozen CompilerIdentity value", () => {
  const fields = ["foundation_version", "registry_foundation_version", "semantic_wave_version", "semantic_wave_version_lock", "compiler_version", "pass_manifest_sha256", "ir_schema_set_sha256", "registry_authority_sha256", "bundle_abi_version", "semantic_artifact_origin"];
  for (const field of fields) {
    const root = mutableFixture();
    mutateManifest(root, (manifest) => { manifest.compiler_identity[field] = field.endsWith("sha256") || field.endsWith("lock") ? "0".repeat(64) : "attacker"; });
    assert.throws(() => verifyCompilerArtifactBundleV2(root, { receipt: pinnedReceipt() }), (error) => error.diagnosticCode === "RFC8_R2_COMPILER_IDENTITY_LOCK_MISMATCH");
  }
});

test("RFC8-R2 Product validates indexes, closure, authority and release gates", () => {
  const cases = [
    [(manifest) => { manifest.artifact_index_sha256 = "0".repeat(64); }, "RFC8_R2_ARTIFACT_INDEX_HASH_MISMATCH"],
    [(manifest) => { manifest.section_index_sha256 = "0".repeat(64); }, "RFC8_R2_SECTION_INDEX_HASH_MISMATCH"],
    [(manifest) => { manifest.required_sections = manifest.required_sections.slice(1); }, "RFC8_R2_REQUIRED_ARTIFACT_CLOSURE_INVALID"],
    [(manifest) => { manifest.eligibility.release_ready = true; }, "RFC8_R2_ELIGIBILITY_GATE_INVALID"],
    [(manifest) => { manifest.eligibility.publication_allowed = true; }, "RFC8_R2_ELIGIBILITY_GATE_INVALID"],
    [(manifest) => { manifest.eligibility.deploy_allowed = true; }, "RFC8_R2_ELIGIBILITY_GATE_INVALID"]
  ];
  for (const [mutate, code] of cases) {
    const root = mutableFixture(); mutateManifest(root, mutate);
    assert.throws(() => verifyCompilerArtifactBundleV2(root, { receipt: pinnedReceipt() }), (error) => error.diagnosticCode === code);
  }
});

test("RFC8-R2 receipt signature remains leaf-key-bound", () => {
  const receipt = pinnedReceipt(); receipt.signature = `00${receipt.signature.slice(2)}`;
  const hashBody = { ...receipt }; delete hashBody.receipt_sha256;
  receipt.receipt_sha256 = sha256CanonicalV2({ domain: "room16.compiler_artifact_bundle_receipt@2", value: hashBody });
  assert.throws(() => verifyCompilerArtifactBundleV2(FIXTURE_ROOT, { receipt }), (error) => error.diagnosticCode === "RFC8_RECEIPT_SIGNATURE_INVALID");
});

test("RFC8-R2 version router never falls back and rejects dual authority", () => {
  const verified = verifyCompilerArtifactBundleVersioned(FIXTURE_ROOT, { expectedVersion: 2, receipt: pinnedReceipt() });
  assert.equal(verified.version, 2);
  assert.throws(() => verifyCompilerArtifactBundleVersioned(FIXTURE_ROOT, { expectedVersion: 1, receipt: pinnedReceipt() }), (error) => error.diagnosticCode === "RFC8_ROUTER_VERSION_MISMATCH");
  assert.throws(() => assertSingleCanonicalRun([
    { ticker: "WM", asOfDate: "2026-08-11", contractVersion: 1, canonical: true },
    { ticker: "WM", asOfDate: "2026-08-11", contractVersion: 2, canonical: true }
  ]), (error) => error.diagnosticCode === "RFC8_DUAL_CANONICAL_AUTHORITY");
});

test("RFC8-R2 Research trust files are byte-exact Product mirrors", () => {
  const pairs = [
    ["room16_compiler_v2_trust_root.json", "trust_root_v2.json"],
    ["room16_compiler_artifact_consumer_policy_envelope_v2.json", "consumer_policy_envelope_v2.json"],
    ["room16_compiler_artifact_key_policy_envelope_v2.json", "public_key_policy_envelope_v2.json"],
    ["room16_compiler_artifact_bundle_schema_profile_v2.json", "manifest_schema_profile_v2.json"]
  ];
  for (const [productName, researchName] of pairs) assert.deepEqual(fs.readFileSync(path.join(CONFIG, productName)), fs.readFileSync(path.join(RESEARCH_ROOT, "research_agent/productization_v2/config", researchName)));
  const profile = json(path.join(CONFIG, "room16_compiler_artifact_bundle_schema_profile_v2.json"));
  assert.equal(profile.profile_sha256, PINNED_RFC0008_V2_SCHEMA_PROFILE_SHA256);
  assert.ok(CompilerArtifactBundleV2Error);
});
