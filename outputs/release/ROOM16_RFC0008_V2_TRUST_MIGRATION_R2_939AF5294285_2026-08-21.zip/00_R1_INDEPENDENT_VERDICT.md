# RFC-0008 R1 Independent Rereview

Verdict: `CHANGES_REQUIRED`.

The major-successor decision is correct and the implementation is additive.
The package has 45/45 declared acceptance rows, full regressions, unchanged
BA10/BA11 freezes, v1/v2 routing and signed bundle receipts.

It is not freeze-ready because the Product trust bootstrap is not independently
rooted: the production API accepts caller-selected policy/key paths and only
checks self-hashes. The Product test itself demonstrates that an arbitrary
ephemeral key/policy pair can become trusted.

Additionally, v2 must restore the frozen compiler identity locks, mirror the
full strict manifest contract in Product, cryptographically chain policy/key
rotation, and repair the evidence manifest self-identity.

No BA12 resume is authorized until R2 passes independent rereview and is frozen.
