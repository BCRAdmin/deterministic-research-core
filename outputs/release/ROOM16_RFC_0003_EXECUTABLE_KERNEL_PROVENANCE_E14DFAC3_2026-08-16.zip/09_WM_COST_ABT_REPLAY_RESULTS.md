# WM / COST / ABT Replay Results

- WM: archive `a6b6d15ad7004573a56ad057884563cfbeeb2c3162dae0641a1b361b5e416d72` unchanged; final state `f6b453cd9a60a831aae6f8e69e9d854ebad761f94e707b243e578d14cfca3c2f`; executed/replayed/cache_hit all equal; compile allowed.
- COST: archive `b97e6024855c7a772713ff9af4889987e4a9a8e5a3afca0d56a42a1ba8092ea4` unchanged; final state `b10b5fd2341463b7a846aa5f5a9409d0971ad9748bb852edd2d1ac0e60e94f8c`; executed/replayed/cache_hit all equal; compile allowed.
- ABT: archive `0926d3cafd312556ec267b2b25214d255ff9352daed77a01b7852addbb48dc45` unchanged; final state `2c21c208528447ceeb2a2b8f10420babbabec4674e47bd020fb21f7b73ce9d6a`; executed/replayed/cache_hit all equal; compile allowed.
