# Compile State IR and Contract

`SemanticCompileStateIR@1` carries sorted content-addressed artifacts through one linear Foundation PassKernel chain. Parsed payload, table and cell references retain their producing IR hashes without duplicating immutable SEC bodies in every envelope.
