# Room16 BA11 — Zwingende Architekturrevision vor Implementierungs-Go

## 1. Contract Catalog vervollständigen

Mindestens folgende Records müssen eine eindeutige Contract-ID, Version,
JSON-Schema-Datei, Canonicalization-Regel, Hashformel, Unknown-Field-Policy und
Negativ-Fixtures erhalten:

- Registry Entry und immutable Registry Snapshot
- Registry Head / Generation Commit
- Genesis Import Receipt
- Change Classification
- Promotion Candidate
- Independent Review Attestation
- Operator Approval
- Promotion Event
- Rejection Event
- Freeze Record
- Supersession Event
- Stale Detection Event
- Recovery/Clear Event
- Accepted Debt Entry
- Debt Membership/Carry-Forward
- Debt Resolution
- Compare/Regression Verdict

## 2. Drei Identitätsebenen trennen

```text
technical_baseline_sha256
  = source + compiler/registry/semantic/ABI/source/consumer/renderer locks
    + bundle/rendered artifacts + semantic outputs

governance_envelope_sha256
  = technical_baseline_sha256 + debt set + change class + review + approval
    + predecessor references

freeze_sha256
  = canonical immutable freeze record
```

Review oder Approval darf nicht rückwirkend die technische Output-Identität
ändern.

## 3. Freeze-Record bereinigen

- Keine später mutierbaren `stale_state`- oder `superseded_state`-Objekte im
  Freeze.
- Stale, Recovery und Supersession als separate append-only Events.
- Der Freeze referenziert nur zum Erstellungszeitpunkt vorhandene immutable
  Inputs.
- `freeze_id` und `freeze_sha256` erhalten eine einzige exakte Ableitungsregel.

## 4. Registry als Derived Snapshot definieren

Die Authority liegt im append-only Event Ledger. Ein Registry Snapshot wird
reproduzierbar daraus erzeugt und enthält mindestens:

- `registry_generation`
- `previous_registry_sha256`
- `ledger_head_sha256`
- `snapshot_sha256`
- deterministisch sortierte Entries
- normative State-Priority und Transition-Validierung

Publikation erfolgt per Compare-and-Swap oder atomarem Rename. Ein zweiter Writer
mit veraltetem Head muss fail-closed blockieren.

## 5. Product-Mirror entkoppeln

```text
Research canonical baseline mismatch -> canary stale/blocked
Product mirror mismatch             -> consumer_mirror_invalid
```

Ein Consumer-Fehler darf niemals den kanonischen Research-Freeze oder dessen
Hash ändern.

## 6. Debt vollständig append-only modellieren

- Debt Entry bleibt bytegleich.
- Aktive Membership wird pro Baseline/Freeze referenziert.
- Carry-Forward ist keine mutierbare Bool-Eigenschaft des Debt Entry.
- Resolution ist ein separater Record mit Root Cause, Fix, Tests, Review und
  optional Operator-Entscheidung.
- `accepted_debt_set_sha256` erhält eine exakte, domain-separierte Hashformel.

## 7. Authentizität und Replay-Schutz festlegen

Review und Operator Approval benötigen mindestens:

- eindeutige Subject-/Role-ID
- Key-ID und Signaturalgorithmus oder gleichwertigen externen Trust Anchor
- Candidate Hash, Review Hash und vorherigen Registry Head
- Nonce / monotonen Counter
- Ablauf-/Revocation-/Rotation-Regel
- Policy für Reviewer-Unabhängigkeit

Ein normaler selbstgehashter JSON-Record ist keine Autorisierung.

## 8. Zeit und Reproduzierbarkeit normieren

- Zeitpunkte sind fixierte Attestation-Inputs, keine Build-Uhr.
- Alle Archive verwenden normalisierte Reihenfolge, Rechte, Pfade und
  Zeitstempel.
- `SOURCE_DATE_EPOCH` oder gleichwertige Regel festlegen.
- Zwei Builds aus identischen Inputs müssen byteidentisch sein.

## 9. Renderer- und Stale-Semantik aufspalten

Mindestens getrennte Locks für:

- Renderer semantic/no-new-truth contract
- Presentation contract
- Renderer implementation/artifact

Ein presentation-only Change darf nur dann Ordinary bleiben, wenn technische
und semantische Locks unverändert sind und der unabhängige Compare keinen neuen
Fact/Claim/Decision/Lineage-Diff feststellt.

## 10. Tests erweitern

Zusätzlich zu BA11-T001–T022 zwingend:

- Ledger truncation / rollback
- Duplicate event/canary/freeze ID
- Baseline version rollback, skip und downgrade
- Registry-head race / stale writer
- Partial write und crash recovery
- Approval/review replay
- Reviewer-not-independent
- Unknown field / schema downgrade / hash algorithm downgrade
- Stale-clear forgery
- Mirror mutation ohne Research-stale
- forged no-new-truth counters gegen unabhängige Ableitung
- deterministic timestamp and archive build
- Genesis import bijection und second-import rejection
- chain fork, branch approval und merge prohibition

## 11. R1-Evidence-Paket

Die korrigierte Architekturrevision muss mindestens enthalten:

- alle Schemas und Contract Catalog
- normative State Machine
- Hash-/ID-/SemVer-Spezifikation
- Storage-/Mirror-/Atomic-Commit-Design
- vollständige Diagnostic Registry
- positive und negative Fixtures
- Implementierungsdatei- und Testplan
- Raw BA10 freeze-verifier JSON inklusive Command Receipt
- Package-Hash und Manifest-Selbstschutz

## Autorisierungsregel

Erst nach einem unabhängigen Review der korrigierten R1-Artefakte darf der
Operator BA11-Implementierung autorisieren. BA0–BA10 bleiben dabei unverändert.
