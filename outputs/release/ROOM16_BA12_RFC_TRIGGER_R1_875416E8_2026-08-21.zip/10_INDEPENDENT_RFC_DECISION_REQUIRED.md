# Independent RFC Decision Required

Approve and independently review one explicit trust migration before BA12 is
resumed:

1. a BA10 successor ABI/consumer-policy major version that supports native
   compilation and live receipt issuance; or
2. a Research-owned BA12 trust envelope, independently accepted and mirrored by
   Product, that authorizes native bundle emitters without impersonating or
   bypassing the frozen BA10 emitter.

The decision must specify receipt rotation, Product mirror pinning, native
canary migration, Authority-v3 output-only compatibility, rollback-before-
freeze, and the acceptance/freeze sequence. It must not authorize merge,
deploy, publication, release, or history rewrite.
