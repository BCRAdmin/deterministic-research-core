import express from "express";
import os from "node:os";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

import { createBa12ApiPayload, findBa12NativeReport, renderBa12NativeMarkdown, scanBa12NativeReports } from "./server-modules/ba12-native-report.mjs";

const APP_ROOT = path.dirname(fileURLToPath(import.meta.url));
const DEFAULT_RESEARCH_ROOT = path.join(os.homedir(), "Documents", "DreamFactory", "Room16", "research-agent-ops");
export const DEFAULT_BUNDLE_ROOT = path.join(DEFAULT_RESEARCH_ROOT, "outputs", "ba12", "native-canaries");

function reports(root) {
  return scanBa12NativeReports(root).map(createBa12ApiPayload);
}

function companies(root) {
  return reports(root).map((report) => ({ ticker: report.ticker, companyName: report.companyName, reportCount: 1, latestReport: report, reports: [report], deterministicReports: [report], nativeAuthority: true }));
}

export function createBa12NativeApp({ bundleRoot = process.env.ROOM16_BA12_NATIVE_BUNDLE_ROOT || DEFAULT_BUNDLE_ROOT } = {}) {
  const app = express();
  app.disable("x-powered-by");
  app.get("/api/health", (_req, res) => res.json({ ok: true, authority: "room16.compiler_artifact_bundle@2", trustEpoch: "rfc0009_native_gen2", rendererCutover: true, legacyTruthFallback: false }));
  app.get("/api/state", (_req, res) => { const nativeReports = reports(bundleRoot); res.json({ companies: companies(bundleRoot), deterministicReports: nativeReports, canonicalAuthority: "native_bundle_v2", legacyTruthFallback: false }); });
  app.get("/api/companies", (_req, res) => res.json({ companies: companies(bundleRoot) }));
  app.get("/api/deterministic-reports", (_req, res) => res.json({ reports: reports(bundleRoot) }));
  app.get("/api/companies/:ticker", (req, res) => { const report = findBa12NativeReport(bundleRoot, req.params.ticker); if (!report) return res.status(404).json({ error: "Verified native company report not found." }); const payload = createBa12ApiPayload(report); return res.json({ company: { ticker: payload.ticker, companyName: payload.companyName, reportCount: 1, latestReport: payload, reports: [payload], deterministicReports: [payload], nativeAuthority: true } }); });
  app.get("/api/compiler-artifacts/:ticker/:date", (req, res) => { const report = findBa12NativeReport(bundleRoot, req.params.ticker, req.params.date); if (!report) return res.status(404).json({ error: "Verified native CompilerArtifactBundle not found." }); return res.json({ compilerArtifact: createBa12ApiPayload(report) }); });
  app.get("/api/reports/latest/:ticker", (req, res) => { const report = findBa12NativeReport(bundleRoot, req.params.ticker); if (!report) return res.status(404).json({ error: "Verified native report not found." }); return res.json({ report: createBa12ApiPayload(report) }); });
  app.get("/api/reports/latest/:ticker/markdown", (req, res) => { const report = findBa12NativeReport(bundleRoot, req.params.ticker); if (!report) return res.status(404).type("text/plain").send("Verified native report not found."); return res.type("text/markdown; charset=utf-8").send(renderBa12NativeMarkdown(report)); });
  app.get("/api/reports/latest/:ticker/pdf", (_req, res) => res.status(404).send("No hash-bound native PDF was emitted."));
  app.get("/api/reports/:id", (_req, res) => res.status(410).json({ error: "Legacy report path is archived and never a canonical fallback." }));
  app.get("/api/archive/*", (_req, res) => res.status(410).json({ error: "Archive surfaces are disabled on the BA12 canonical server." }));
  return app;
}

async function main() {
  const port = Number(process.env.PORT || 4517);
  const host = process.env.HOST || "127.0.0.1";
  createBa12NativeApp().listen(port, host, () => console.log(`Room16 BA12 native server listening at http://${host}:${port}`));
}

if (import.meta.url === pathToFileURL(process.argv[1] || "").href) await main();
