#!/usr/bin/env python3
import hashlib,json,sys,zipfile
from pathlib import PurePosixPath
p=sys.argv[1]
with zipfile.ZipFile(p) as z:
 names=z.namelist()
 if len(names)!=len(set(names)): raise SystemExit("duplicate entries")
 if any(PurePosixPath(n).is_absolute() or ".." in PurePosixPath(n).parts for n in names): raise SystemExit("unsafe path")
 m=json.loads(z.read("MANIFEST.json"))
 body={k:v for k,v in m.items() if k!="manifest_sha256"}
 canon=json.dumps(body,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()
 if hashlib.sha256(canon).hexdigest()!=m["manifest_sha256"]: raise SystemExit("manifest hash")
 for item in m["files"]:
  data=z.read(item["path"])
  if len(data)!=item["bytes"] or hashlib.sha256(data).hexdigest()!=item["sha256"]: raise SystemExit("file hash:"+item["path"])
 flags=m["final_flags"]
 if not flags["ready_for_independent_rereview"] or not flags["release_ready_candidate"]: raise SystemExit("candidate flags")
 if any(flags[k] for k in ("ba12_implementation_ready","ba12_frozen","release_ready","release_authorized","publication_authorized","deploy_authorized")): raise SystemExit("forbidden flag")
 print(json.dumps({"contract_id":"room16.ba12.independent_verifier_receipt","status":"PASS","manifest_sha256":m["manifest_sha256"],"verified_file_count":len(m["files"])},sort_keys=True))
