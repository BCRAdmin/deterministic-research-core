# Table Discovery Coverage

- WM: detected=1225, registered=931, excluded=294, closed=True
- COST: detected=657, registered=657, excluded=0, closed=True
- ABT: detected=826, registered=793, excluded=33, closed=True
