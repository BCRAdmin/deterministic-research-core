# Connected IR Spine Proof

- WM: normalized=171, typed=171, compile_allowed=True
- COST: normalized=95, typed=95, compile_allowed=True
- ABT: normalized=116, typed=116, compile_allowed=True
