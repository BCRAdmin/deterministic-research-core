# Verification Plan

Each canary binds all L3–L9 IR hashes into VerificationPlanIR. Actual plans, Diagnostics and reports are in `08_DIAGNOSTIC_IR_ARCHIVE.zip`.
