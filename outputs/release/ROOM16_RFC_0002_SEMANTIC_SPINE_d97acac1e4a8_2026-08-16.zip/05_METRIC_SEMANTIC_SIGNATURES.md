# Metric Semantic Signatures

- Legacy Metric IDs: 282
- Exact Semantic Signatures: 283
- Authority SHA-256: `5cc245523701a9fbbec9a3a20cffc8adc557d3bbc4d3048b9fa938b2ba32edbf`
- Computed gate: `pass`
