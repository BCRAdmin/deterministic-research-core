# Decision Reconstruction Roundtrip

- WM: graph reconstruction equal=True, embedded legacy payload=False
- COST: graph reconstruction equal=True, embedded legacy payload=False
- ABT: graph reconstruction equal=True, embedded legacy payload=False
