# Graph Lineage Results

- WM: numeric paths=198, missing claims=0, missing bindings=0, unknown sources=0
- COST: numeric paths=137, missing claims=0, missing bindings=0, unknown sources=0
- ABT: numeric paths=156, missing claims=0, missing bindings=0, unknown sources=0
