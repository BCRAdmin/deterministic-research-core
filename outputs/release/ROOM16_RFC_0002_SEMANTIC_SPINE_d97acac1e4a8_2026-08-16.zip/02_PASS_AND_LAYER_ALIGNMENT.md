# Pass and Layer Alignment

Der hashgebundene Passvertrag liegt vollständig in `08_DIAGNOSTIC_IR_ARCHIVE.zip`. Der zehnte und letzte Pass ist `ba9.l10.verify_semantics`; BA10 ist false.
