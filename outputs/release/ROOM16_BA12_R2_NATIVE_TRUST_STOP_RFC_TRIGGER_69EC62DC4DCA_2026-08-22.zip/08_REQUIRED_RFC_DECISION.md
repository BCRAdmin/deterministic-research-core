# Required RFC Decision

Independently define and accept a signed source-native CompilerIdentityV2 policy generation or successor trust root. The current migration trust boundary must remain immutable and Product must not choose or weaken the root.
