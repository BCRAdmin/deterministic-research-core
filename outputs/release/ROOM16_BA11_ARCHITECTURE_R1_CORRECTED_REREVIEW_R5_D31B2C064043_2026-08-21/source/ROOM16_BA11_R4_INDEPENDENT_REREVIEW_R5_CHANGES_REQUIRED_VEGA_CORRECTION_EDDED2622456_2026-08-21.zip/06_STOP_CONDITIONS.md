# Stop Conditions

Fail closed if:
- source R4 ZIP/hash or repository origins differ;
- pre-swap crash can still influence later published ledger authority;
- a second/third valid promotion cycle cannot complete;
- rollback to an older valid RegistryHead is accepted;
- alternate publication from an old base succeeds;
- exact pytest node ID coverage is incomplete;
- any R4 test regresses;
- Research/Product full regression or BA10 verifier fails;
- deterministic rebuild differs;
- the materialbedarf foreign worktree would be modified;
- push requires force/history rewrite.

On stop: no BA11-ready, BA12, merge, deploy, release or publication.
