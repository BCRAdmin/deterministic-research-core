# Vega Execution Runbook — R5

1. Verify the embedded R4 result ZIP and SHA-256 `cd45138728ec20c2c9a6cad2fbce5e25a56c99b599da58606098560753d80f46`.
2. Verify local origins:
   - BCRAdmin/deterministic-research-core
   - BCRAdmin/company-dossier-lab
3. Start Research from current main `571637099dec4545d660c03cc003a1d8bfcbc4af` or an explicitly documented additive successor.
4. Preserve the R4 evidence; do not rewrite or delete it.
5. Reproduce all four findings before fixing.
6. Implement CD-R5-01 through CD-R5-04 root-cause-first.
7. Execute all rows in `03_REQUIRED_TEST_MATRIX.json`.
8. Re-run the complete R4 54-row suite, full Research regression, Product verification and BA10 raw freeze verifier.
9. Build the R5 evidence package twice from identical inputs and require identical bytes.
10. Additive commit and push only after PASS.

The materialbedarf-rechner.de worktree is foreign scope:
read-only evidence only; no cleanup, checkout, reset, stash, commit, push, merge or deploy.

No BA11 ready flag may be set by Vega. R5 may only claim:
`ready_for_independent_rereview=true`.
