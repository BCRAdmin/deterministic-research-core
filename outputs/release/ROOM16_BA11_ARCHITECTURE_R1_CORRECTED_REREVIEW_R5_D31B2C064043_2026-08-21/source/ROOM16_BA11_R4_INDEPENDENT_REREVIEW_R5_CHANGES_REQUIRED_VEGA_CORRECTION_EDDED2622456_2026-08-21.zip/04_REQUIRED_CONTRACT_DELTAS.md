# Required Contract Deltas

## CD-R5-01 — Staging vs Published Ledger Authority

Candidate/staged ledger heads, sets and event objects must not be interpreted
as published authority before the registry publication point.

Preferred invariant:

```text
content-addressed candidate objects may branch
published authority may not branch
current pointer resolves only a published receipt/head chain
```

A crash before publication must permit:
- safe retry of the same transaction, and
- a different later valid transaction/append without poisoning the store.

Do not solve this by deleting immutable evidence opportunistically.

## CD-R5-02 — Multi-generation Promotion Lifecycle

The append-only ledger must support repeated legitimate promotion cycles.

`RegistryAuthorityGraph.promotion_event_sha256` identifies the current target
promotion. Verification must resolve that exact event from the full ledger and
bind it to the current candidate/review/approval/freeze.

Historical PromotionEvents remain in the ledger and must not cause
`promotion_event_count` failure.

Required lifecycle coverage:
- generation 0 / baseline 1.0.0;
- generation 1 / governance 1.1.0;
- at least one further valid cycle;
- full-history snapshot replay byte-identical.

## CD-R5-03 — Published RegistryHead Chain

Add a machine-verifiable publication chain for top-level RegistryHead state.

At minimum bind:
- generation;
- current head sha256;
- previous published head/receipt sha256;
- transaction sha256;
- commit receipt sha256;
- publication state.

`read_head()` must reject rollback to an older valid current.json when a newer
published authority exists. Publication from an old base must fail closed.

Candidate/staged RegistryHead objects are not equivalent to published heads.

## CD-R5-04 — Exact Acceptance Node IDs

Every acceptance requirement binds:
- stable requirement ID;
- exact pytest node ID including parameter ID;
- collect-only manifest hash;
- execution result for that node;
- command receipt;
- expected/actual diagnostic;
- git tree.

The verifier rejects duplicate, missing, uncollected, unexecuted or generic mappings.
