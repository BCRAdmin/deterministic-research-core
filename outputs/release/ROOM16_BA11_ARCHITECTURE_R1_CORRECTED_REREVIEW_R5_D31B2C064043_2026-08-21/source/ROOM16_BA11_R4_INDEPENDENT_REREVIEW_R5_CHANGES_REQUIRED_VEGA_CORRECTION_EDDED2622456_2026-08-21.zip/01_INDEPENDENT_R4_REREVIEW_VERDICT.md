# Independent R4 Rereview Verdict

R4 package mechanics, manifest, 10/10 closure register, 54/54 declared tests,
full regression receipts, BA10 verifier and Git bindings were inspected.

Independent execution also re-ran the packaged R4 governance tests in an
isolated compatibility harness: 83 tests passed after restoring unchanged
dependencies from the nested prior evidence.

Verdict: `CHANGES_REQUIRED`.

Three runtime/authority defects remain:
1. abandoned pre-swap ledger staging can poison later publication;
2. a second legitimate promotion cycle cannot be represented;
3. the top-level RegistryHead current pointer has no rollback/fork publication chain.

One evidence-hardening defect remains:
4. requirement rows are not uniquely bound to exact pytest node IDs.

This is a narrow final operational closure block, not a new architecture phase.
