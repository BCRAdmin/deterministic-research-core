# R5 Evidence Bundle Contract

Deliver:

```text
ROOM16_BA11_ARCHITECTURE_R1_CORRECTED_REREVIEW_R5_<SHORTSHA>_2026-08-21.zip
<ZIP>.sha256
<ZIP>.identity.json
```

Required members:

```text
00_R5_CORRECTION_VERDICT.md
01_INPUT_LOCK.json
02_R5_FINDINGS.json
03_R5_FINDING_CLOSURE_REGISTER.json
04_STAGING_PUBLICATION_ISOLATION_REPORT.json
05_MULTI_GENERATION_LIFECYCLE_REPORT.json
06_REGISTRY_HEAD_ROLLBACK_REPORT.json
07_ACCEPTANCE_NODEID_REPORT.json
08_TEST_MATRIX_EXECUTED.json
09_R4_REGRESSION_REPORT.json
10_FULL_REGRESSION_RECEIPTS.json
11_BA10_RAW_VERIFIER_RECEIPT.json
12_SOURCE_TREE_BINDINGS.json
13_CHANGED_FILES_PER_FINDING.json
14_DETERMINISTIC_BUILD_REPORT.json
15_FOREIGN_WORKTREE_BOUNDARY_REPORT.json
16_REREVIEW_REQUEST.md
MANIFEST.json
independent_verifier/VERIFIER_RECEIPT.json
```

Also include:
- all changed implementation/contracts/schemas/tests/verifiers;
- exact source R4 result ZIP;
- this R5 execution contract or its byte-identical ZIP.

Closure status must be verifier-derived, not builder-authored.

Final allowed gate:
`ready_for_independent_rereview=true`
with BA11/BA12/release/publication still false.
