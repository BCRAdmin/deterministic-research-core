# Python / JS Conformance Results

The Research-owned corpus covers canonical JSON ordering, Unicode/NFC,
nesting, null/booleans, numeric handling and SHA-256. Python and JavaScript
produce the exact same canonical bytes and hashes. Missing or unknown required
fields, unsafe numbers, non-NFC text, unsafe paths and tampering fail closed.
All three real Canary bundles were independently verified by both runtimes.
