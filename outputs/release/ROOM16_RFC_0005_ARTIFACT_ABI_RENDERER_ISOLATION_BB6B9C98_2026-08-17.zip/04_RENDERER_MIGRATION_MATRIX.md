# Renderer Migration Matrix

| Surface | Classification | BA10 state |
|---|---|---|
| Markdown | PRESENTATION_TRANSFORM | Compiler-bound canonical input; hash verified |
| DOCX | PRESENTATION_TRANSFORM | Bundle renderer; no-new-truth artifact set |
| PDF | PRESENTATION_TRANSFORM | Bundle renderer; no-new-truth artifact set |
| JSON | PURE_CONSUMER | Verified manifest/artifact reads only |
| API | PURE_CONSUMER | Frozen read-only projection |
| UI | PURE_CONSUMER | Frozen read-only projection |
| Authority v3 readers | LEGACY_BRIDGE | One-way byte-parity view only |

Migration phases 1–4 are implemented: sidecar, shadow consumer, semantic
inventory diff and first renderer. The canonical Product execution path now
requires the bundle. Legacy semantic modules are classified and retired from
that path. Physical deletion remains a later staged cleanup only after the
compatibility bridge is no longer required.
