# Artifact ABI Implementation Record

- Contract: `room16.compiler_artifact_bundle@1`
- Schema: `1.0.0`
- Research commit: `bb6b9c9813b411bac6f3df47d183ac797e7337e9`
- Product commit: `442a30792724c6d7fa0f4e097765e1b75dc97a15`
- Producer: Research L11 packaging above frozen BA0–BA9
- Consumers: Product API/UI projection and deterministic document renderer
- Failure mode: fail closed on version, field, path, hash, capability, missing
  artifact, Unicode, numeric, compatibility or renderer-invariant violations.
- Current mode: `authority_v3_compatibility_shadow`
