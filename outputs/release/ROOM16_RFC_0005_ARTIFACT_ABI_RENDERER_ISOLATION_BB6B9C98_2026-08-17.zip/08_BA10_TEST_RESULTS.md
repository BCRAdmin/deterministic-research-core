# BA10 Test Results

- `research_targeted`: exit `0`
- `research_full`: exit `0`
- `semantic_freeze`: exit `0`
- `registry_freeze`: exit `0`
- `product_hardening_once`: exit `0`
- `product_verify`: exit `0`
- `product_build`: exit `0`
- `product_python`: exit `0`

WM/COST/ABT each passed deterministic double-build, Product consumer validation, v3 byte parity and frozen archive checks.
WM additionally passed the compiler-bound Markdown/DOCX/PDF renderer and Product validation of its rendered artifact set.
