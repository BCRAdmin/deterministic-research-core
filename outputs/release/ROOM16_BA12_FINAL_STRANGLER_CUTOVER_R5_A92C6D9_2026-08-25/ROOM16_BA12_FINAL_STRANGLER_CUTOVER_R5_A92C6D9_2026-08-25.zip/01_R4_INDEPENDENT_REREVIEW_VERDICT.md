# BA12 R4 Independent Rereview

Verdict: **CHANGES_REQUIRED — 2 P0 / 1 P1**

The following R4 areas independently passed:

- ZIP integrity: `56` entries;
- outer SHA-256 `2fb1162eac600f3a979f191b5b68a30566315873332e9ba7c19e93cee084737e`;
- all 55 manifest payload hashes;
- reproducible manifest self-hash `cdc5a0eadbec0c39d3aa746a8d4bec9e6a87db2ceb77a8f2d08075ec22215656`;
- bundled standalone verifier executed successfully;
- BA12 matrix 50/50 PASS;
- RFC-0010 resume delta 14/14 PASS;
- actual live WM/COST/ABT SEC + Nasdaq acquisition/capture lineage;
- frozen BA3 / Semantic Wave;
- native Bundle@2 generation;
- dynamic Research emitter identity;
- signed native receipts;
- Product native Bundle@2 verifier;
- active-legacy scan for the **alternate native server**;
- dependency/security audits;
- Boundary Gate v2;
- all prior freezes.

Remote identities are also present:
- Research R4 implementation `c2382adb91f261a593bbcb694736ccc94de86bc1`, with an evidence-only
  successor currently at `f9a063c9aa6f75a24a6e26a4d378273d92443ae4`;
- Product `27393e2e2cfe6178b443bfce6d76fac9b0db9517`.

## Blocking reality check

At Product `27393e2e2cfe6178b443bfce6d76fac9b0db9517`, `room16-app/package.json` still declares:

```text
dev   = node server.mjs --dev --port 4516
start = node server.mjs --static --port 4516
```

The R4 Product patch adds only:
- `ba12-native-server.mjs`
- `server-modules/ba12-native-report.mjs`
- `scripts/test_ba12_native_cutover.mjs`

The native server is API-only and does not provide the standard UI static/Vite
serving.

Therefore the actual normal Product runtime has **not** been cut over.

The legacy `server.mjs` remains the default operational entrypoint and still
contains legacy semantic imports/read paths. Consequently the R4 reports
`canonical_entrypoint=ba12-native-server.mjs` and
`active_legacy_semantic_readers=0` are not valid for the default launched
runtime.

R5 must close only this final Product activation gap.
