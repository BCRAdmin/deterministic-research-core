import fs from "node:fs";
import path from "node:path";
import { createHash } from "node:crypto";

import { verifyCompilerArtifactBundleV2Native } from "./compiler-artifact-bundle-v2-native.mjs";

export class Ba12NativeReportError extends Error {
  constructor(code, detail = "") {
    super(detail ? `${code}:${detail}` : code);
    this.code = code;
  }
}

function readJson(filePath, code) {
  try { return JSON.parse(fs.readFileSync(filePath, "utf8")); }
  catch (error) { throw new Ba12NativeReportError(code, error.message); }
}

function sha256File(filePath) {
  return createHash("sha256").update(fs.readFileSync(filePath)).digest("hex");
}

export function resolveBa12NativeReport(bundleRoot) {
  const root = path.resolve(bundleRoot);
  const receiptPath = path.join(root, "RECEIPT.json");
  const receipt = readJson(receiptPath, "BA12_NATIVE_RECEIPT_INVALID");
  const verified = verifyCompilerArtifactBundleV2Native(root, {
    receipt,
    nowUtc: `${readJson(path.join(root, "BUNDLE_MANIFEST.json"), "BA12_NATIVE_MANIFEST_INVALID").compile_identity.as_of_date}T23:30:00Z`
  });
  const trustEpoch = "rfc0009_native_gen2";
  const manifest = verified.manifest;
  if (manifest.compatibility?.legacy_semantic_input_allowed !== false || manifest.compatibility?.authority_v3_semantic_input_allowed !== false || manifest.compatibility?.source_native_fact_generation !== true || manifest.eligibility?.renderer_cutover !== true) throw new Ba12NativeReportError("BA12_NATIVE_CUTOVER_INELIGIBLE");
  const projectionEntry = manifest.artifacts.find((item) => item.artifact_kind === "renderer_projection" && item.authoritative === true);
  const lineageEntry = manifest.artifacts.find((item) => item.artifact_kind === "renderer_lineage_expectation" && item.authoritative === true);
  if (!projectionEntry || !lineageEntry) throw new Ba12NativeReportError("BA12_RENDERER_ARTIFACT_MISSING");
  const projectionPath = path.join(root, projectionEntry.relative_path);
  const lineagePath = path.join(root, lineageEntry.relative_path);
  if (sha256File(projectionPath) !== projectionEntry.sha256 || sha256File(lineagePath) !== lineageEntry.sha256) throw new Ba12NativeReportError("BA12_RENDERER_ARTIFACT_HASH_MISMATCH");
  const projection = readJson(projectionPath, "BA12_RENDERER_PROJECTION_INVALID");
  const lineage = readJson(lineagePath, "BA12_RENDERER_LINEAGE_INVALID");
  const projectedFactIds = (projection.facts || []).map((item) => item.fact_id);
  if (projectedFactIds.some((id) => !lineage.fact_ids.includes(id)) || projection.decision?.semantic_owner !== "research_compiler") throw new Ba12NativeReportError("BA12_RENDERER_SEMANTIC_MUTATION");
  return Object.freeze({ root, manifest, receipt, projection, lineage, trustEpoch });
}

export function scanBa12NativeReports(root) {
  const resolved = path.resolve(root);
  if (!fs.existsSync(resolved)) return [];
  return fs.readdirSync(resolved, { withFileTypes: true })
    .filter((entry) => entry.isDirectory())
    .map((entry) => resolveBa12NativeReport(path.join(resolved, entry.name)))
    .sort((left, right) => left.manifest.compile_identity.ticker.localeCompare(right.manifest.compile_identity.ticker));
}

export function renderBa12NativeMarkdown(report) {
  const { projection, manifest } = report;
  const lines = [
    `# ${projection.title}`,
    "",
    `- Stichtag: \`${projection.as_of_date}\``,
    `- Native Bundle@2: \`${manifest.bundle_sha256}\``,
    `- Trust Epoch: \`rfc0009_native_gen2\``,
    `- Entscheidung: \`${projection.decision.rating}\``,
    "",
    "## Verifizierte Fakten",
    ""
  ];
  for (const fact of projection.facts || []) lines.push(`- ${fact.label}: **${fact.value} ${fact.unit}** (${fact.period_end})`);
  lines.push("", "## Evidenzgebundene Aussagen", "");
  for (const claim of projection.claims || []) lines.push(`- ${claim.statement}`);
  lines.push("", "_Die Darstellung projiziert ausschließlich Research-Semantik; sie verändert keine Fakten, Kennzahlen, Aussagen oder Ratings._", "");
  return lines.join("\n");
}

export function createBa12ApiPayload(report) {
  const { manifest, projection, receipt } = report;
  return Object.freeze({
    id: `ba12-native-${manifest.bundle_sha256}`,
    ticker: manifest.compile_identity.ticker,
    companyName: projection.title.replace(/ native research dossier$/, ""),
    asOfDate: manifest.compile_identity.as_of_date,
    title: projection.title,
    reportKind: "native_bundle_v2",
    finalRating: projection.decision.rating,
    facts: projection.facts,
    claims: projection.claims,
    decision: projection.decision,
    bindingStatus: "verified",
    trustEpoch: "rfc0009_native_gen2",
    bundleSha256: manifest.bundle_sha256,
    receiptSha256: receipt.receipt_sha256,
    rendererCutover: true,
    legacyTruthFallback: false,
    markdownUrl: `/api/reports/latest/${encodeURIComponent(manifest.compile_identity.ticker)}/markdown`,
    pdfUrl: null,
    docxUrl: null,
    documentsRendered: false
  });
}

export function findBa12NativeReport(root, ticker, asOfDate = null) {
  const symbol = String(ticker || "").toUpperCase();
  return scanBa12NativeReports(root).find((report) => report.manifest.compile_identity.ticker === symbol && (!asOfDate || report.manifest.compile_identity.as_of_date === asOfDate)) || null;
}
