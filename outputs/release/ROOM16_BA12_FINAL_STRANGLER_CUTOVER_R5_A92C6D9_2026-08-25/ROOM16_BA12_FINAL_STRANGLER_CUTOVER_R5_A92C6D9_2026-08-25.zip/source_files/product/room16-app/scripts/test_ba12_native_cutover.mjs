import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

import { createBa12NativeApp } from "../ba12-native-server.mjs";
import { Ba12NativeReportError, scanBa12NativeReports } from "../server-modules/ba12-native-report.mjs";

const APP = path.resolve(import.meta.dirname, "..");

test("BA12 Product canonical server is additive above frozen server", () => {
  assert.equal(fs.existsSync(path.join(APP, "ba12-native-server.mjs")), true);
  assert.equal(fs.existsSync(path.join(APP, "server.mjs")), true);
});

test("BA12 missing bundle root fails closed without legacy fallback", () => {
  assert.deepEqual(scanBa12NativeReports(path.join(os.tmpdir(), "ba12-no-such-root")), []);
});

test("BA12 malformed bundle cannot become Product truth", () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "ba12-malformed-"));
  fs.mkdirSync(path.join(root, "WM"));
  assert.throws(() => scanBa12NativeReports(root), Ba12NativeReportError);
});

test("BA12 canonical server imports only native report authority", () => {
  const source = fs.readFileSync(path.join(APP, "ba12-native-server.mjs"), "utf8");
  assert.match(source, /ba12-native-report\.mjs/);
  assert.doesNotMatch(source, /deterministic-research-report|research-authority-bundle/);
});

test("BA12 canonical legacy report path is explicit gone response", () => {
  const source = fs.readFileSync(path.join(APP, "ba12-native-server.mjs"), "utf8");
  assert.match(source, /app\.get\("\/api\/reports\/:id"/);
  assert.match(source, /status\(410\)/);
});

test("BA12 app construction performs no external action and keeps operator gates false", () => {
  const app = createBa12NativeApp({ bundleRoot: path.join(os.tmpdir(), "ba12-no-such-root") });
  assert.ok(app);
  const source = fs.readFileSync(path.join(APP, "ba12-native-server.mjs"), "utf8");
  assert.doesNotMatch(source, /child_process|spawn\(|exec\(/);
  assert.match(source, /releaseAuthorized: false/);
  assert.match(source, /publicationAuthorized: false/);
  assert.match(source, /deployAuthorized: false/);
  assert.match(source, /commerceAuthorized: false/);
});
