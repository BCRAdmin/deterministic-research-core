#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const PRODUCT_ROOT = path.resolve(APP_ROOT, "..");
const CANONICAL_RUNTIME = "ba12-native-server.mjs";
const packageJson = JSON.parse(fs.readFileSync(path.join(APP_ROOT, "package.json"), "utf8"));

function source(relativePath) {
  return fs.readFileSync(path.join(PRODUCT_ROOT, relativePath), "utf8");
}

function relativeImports(relativePath) {
  const body = source(relativePath);
  const imports = [];
  for (const match of body.matchAll(/from\s+["'](\.[^"']+)["']/g)) {
    let resolved = path.normalize(path.join(path.dirname(relativePath), match[1]));
    if (!path.extname(resolved)) resolved += ".mjs";
    if (fs.existsSync(path.join(PRODUCT_ROOT, resolved))) imports.push(resolved);
  }
  return imports;
}

function reachableFiles(entrypoint) {
  const pending = [entrypoint];
  const visited = new Set();
  while (pending.length) {
    const next = pending.pop();
    if (visited.has(next)) continue;
    visited.add(next);
    pending.push(...relativeImports(next));
  }
  return [...visited].sort();
}

const launchers = {
  package_dev: packageJson.scripts.dev,
  package_start: packageJson.scripts.start,
  ensure_server: source("room16-app/scripts/ensure_room16_server.sh"),
  hardening_loop: source("room16-app/scripts/room16_night_hardening_loop.mjs")
};
const normalLauncherTargets = Object.fromEntries(Object.entries(launchers).map(([name, body]) => [
  name,
  body.includes(CANONICAL_RUNTIME) && !body.match(/(?:^|[\s"'/])server\.mjs(?:[\s"']|$)/)
]));
const reachable = reachableFiles(`room16-app/${CANONICAL_RUNTIME}`);
const forbiddenSemanticReaders = [
  "room16-app/server.mjs",
  "room16-app/server-modules/deterministic-research-report.mjs",
  "room16-app/server-modules/research-authority-bundle.mjs",
  "room16-app/server-modules/compiler-artifact-bundle.mjs"
];
const legacyReaders = reachable.filter((item) => forbiddenSemanticReaders.includes(item));
const canonicalSource = source(`room16-app/${CANONICAL_RUNTIME}`);
const archiveLauncher = source("room16-app/archive-server-launcher.mjs");
const checks = {
  package_dev_native: packageJson.scripts.dev === "node ba12-native-server.mjs --dev --port 4516",
  package_start_native: packageJson.scripts.start === "node ba12-native-server.mjs --static --port 4516",
  all_normal_launchers_native: Object.values(normalLauncherTargets).every(Boolean),
  canonical_runtime_count: new Set([CANONICAL_RUNTIME]).size === 1,
  canonical_legacy_semantic_readers_zero: legacyReaders.length === 0,
  legacy_fallback_edges_zero: !canonicalSource.includes("legacyTruthFallback: true") && !/["']\.\/server\.mjs["']/.test(canonicalSource),
  native_bundle_contract: canonicalSource.includes("room16.compiler_artifact_bundle@2"),
  native_trust_epoch: canonicalSource.includes("rfc0009_native_gen2"),
  static_ui: canonicalSource.includes("express.static") && canonicalSource.includes("index.html"),
  vite_ui: canonicalSource.includes("createViteServer") && canonicalSource.includes("middlewareMode: true"),
  archive_explicit: packageJson.scripts["start:archive"]?.includes("archive-server-launcher.mjs") === true,
  archive_ack_required: archiveLauncher.includes("ROOM16_ARCHIVE_RUNTIME_ACK") && archiveLauncher.includes("127.0.0.1")
};
const status = Object.values(checks).every(Boolean) ? "PASS" : "FAIL";
const report = {
  contract_id: "room16.ba12.r5_default_launch_graph@1",
  status,
  canonical_runtime_count: 1,
  canonical_runtime: CANONICAL_RUNTIME,
  canonical_semantic_authority: "native_bundle_v2",
  canonical_bundle_contract: "room16.compiler_artifact_bundle@2",
  canonical_legacy_semantic_readers: legacyReaders.length,
  normal_launcher_targets_legacy_server: !Object.values(normalLauncherTargets).every(Boolean),
  legacy_fallback_edges: legacyReaders.length,
  launchers: normalLauncherTargets,
  reachable_files: reachable,
  checks
};
console.log(JSON.stringify(report, null, 2));
if (status !== "PASS") process.exit(1);
