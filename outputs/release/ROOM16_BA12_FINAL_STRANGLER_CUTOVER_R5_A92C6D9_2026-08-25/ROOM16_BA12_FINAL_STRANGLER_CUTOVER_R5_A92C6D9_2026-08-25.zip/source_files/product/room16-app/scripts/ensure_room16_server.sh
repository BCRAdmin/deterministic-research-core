#!/usr/bin/env bash
set -euo pipefail

APP_ROOT="/Users/BjornRosinger/Documents/DreamFactory/Room16/company-dossier-lab/room16-app"
BASE_URL="${ROOM16_APP_BASE_URL:-http://127.0.0.1:4516}"
LOG_DIR="/Users/BjornRosinger/Library/Logs"
SERVER_LOG="$LOG_DIR/room16-app-server.log"
SERVER_ERR="$LOG_DIR/room16-app-server.err.log"
NODE_BIN="/opt/homebrew/bin/node"
SERVER_FRESHNESS_PATH="/Users/BjornRosinger/Documents/DreamFactory/Room16/company-dossier-lab/.runtime/room16-app/server-freshness.json"

health_ok() {
  /usr/bin/curl -fsS --max-time 2 "$BASE_URL/api/health" 2>/dev/null | /usr/bin/grep -q '"ok":true'
}

restart_required() {
  /usr/bin/curl -sS --max-time 2 "$BASE_URL/api/health" 2>/dev/null | /usr/bin/grep -q '"restartRequired":true'
}

restart_deferred() {
  /usr/bin/curl -fsS --max-time 2 "$BASE_URL/api/health" 2>/dev/null | /usr/bin/grep -q '"restartDeferred":true'
}

server_sources_changed() {
  if [ ! -f "$SERVER_FRESHNESS_PATH" ]; then
    return 0
  fi
  /usr/bin/find \
    "$APP_ROOT/ba12-native-server.mjs" \
    "$APP_ROOT/server-modules" \
    -type f -name '*.mjs' -newer "$SERVER_FRESHNESS_PATH" -print -quit |
    /usr/bin/grep -q .
}

stop_stale_server() {
  local listener_pid
  local listener_command
  local listener_cwd
  listener_pid="$(/usr/sbin/lsof -tiTCP:4516 -sTCP:LISTEN | /usr/bin/head -n 1 || true)"
  case "$listener_pid" in
    ''|*[!0-9]*) return 1 ;;
  esac
  listener_command="$(/bin/ps -p "$listener_pid" -o command=)"
  listener_cwd="$(
    /usr/sbin/lsof -a -p "$listener_pid" -d cwd -Fn 2>/dev/null |
      /usr/bin/sed -n 's/^n//p' |
      /usr/bin/head -n 1
  )"
  case "$listener_command" in
    *"$APP_ROOT/ba12-native-server.mjs --static --port 4516") ;;
    *"node ba12-native-server.mjs --static --port 4516")
      [ "$listener_cwd" = "$APP_ROOT" ] || return 1
      ;;
    *) return 1 ;;
  esac
  /bin/kill -TERM "$listener_pid"
  for _ in $(/usr/bin/seq 1 40); do
    if ! /usr/sbin/lsof -tiTCP:4516 -sTCP:LISTEN >/dev/null 2>&1; then
      return 0
    fi
    /bin/sleep 0.1
  done
  return 1
}

if health_ok; then
  if restart_deferred; then
    exit 0
  fi
  if ! server_sources_changed; then
    exit 0
  fi
  stop_stale_server
elif restart_required; then
  stop_stale_server
elif /usr/sbin/lsof -tiTCP:4516 -sTCP:LISTEN >/dev/null 2>&1; then
  exit 1
fi

/bin/mkdir -p "$LOG_DIR"
if [ ! -x "$NODE_BIN" ]; then
  NODE_BIN="$(/usr/bin/which node)"
fi
/usr/bin/nohup "$NODE_BIN" "$APP_ROOT/ba12-native-server.mjs" --static --port 4516 >>"$SERVER_LOG" 2>>"$SERVER_ERR" &

for _ in $(/usr/bin/seq 1 30); do
  if health_ok; then
    exit 0
  fi
  /bin/sleep 0.35
done

exit 1
