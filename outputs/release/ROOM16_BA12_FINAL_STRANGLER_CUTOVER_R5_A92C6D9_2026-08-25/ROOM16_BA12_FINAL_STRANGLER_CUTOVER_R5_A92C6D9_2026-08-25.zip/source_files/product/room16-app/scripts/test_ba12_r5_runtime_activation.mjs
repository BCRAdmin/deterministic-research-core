import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test, { after, before } from "node:test";
import { fileURLToPath } from "node:url";

const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const RESEARCH_ROOT = path.resolve(APP_ROOT, "..", "..", "research-agent-ops");
const BUNDLE_ROOT = path.join(RESEARCH_ROOT, "outputs", "ba12", "native-canaries");
const STATIC_PORT = 4561;
const DEV_PORT = 4562;
const staticBase = `http://127.0.0.1:${STATIC_PORT}`;
const devBase = `http://127.0.0.1:${DEV_PORT}`;
let staticServer;
let devServer;

async function waitFor(baseUrl) {
  for (let attempt = 0; attempt < 100; attempt += 1) {
    try {
      const response = await fetch(`${baseUrl}/api/health`);
      if (response.ok) return;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw new Error(`Runtime did not become ready: ${baseUrl}`);
}

function start(script, port, bundleRoot = BUNDLE_ROOT) {
  const child = spawn("npm", ["run", script, "--silent"], {
    cwd: APP_ROOT,
    env: {
      ...process.env,
      PORT: String(port),
      HOST: "127.0.0.1",
      ROOM16_BA12_NATIVE_BUNDLE_ROOT: bundleRoot
    },
    detached: true,
    stdio: ["ignore", "pipe", "pipe"]
  });
  return child;
}

function stop(child) {
  if (!child || child.exitCode !== null) return;
  try { process.kill(-child.pid, "SIGTERM"); } catch {}
}

async function json(url, options = {}) {
  const response = await fetch(url, options);
  const body = await response.json();
  return { response, body };
}

before(async () => {
  staticServer = start("start", STATIC_PORT);
  await waitFor(staticBase);
  devServer = start("dev", DEV_PORT);
  await waitFor(devBase);
});

after(() => {
  stop(staticServer);
  stop(devServer);
});

test("BA12-R5-T-001 package normal start resolves to canonical native semantic runtime", async () => {
  const { body } = await json(`${staticBase}/api/health`);
  assert.equal(body.canonicalRuntime, "ba12-native-server.mjs");
});

test("BA12-R5-T-002 package normal dev resolves to canonical native semantic runtime", async () => {
  const { body } = await json(`${devBase}/api/health`);
  assert.equal(body.canonicalRuntime, "ba12-native-server.mjs");
});

test("BA12-R5-T-003 normal launcher does not resolve to legacy semantic server", () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(APP_ROOT, "package.json"), "utf8"));
  assert.doesNotMatch(`${pkg.scripts.start}\n${pkg.scripts.dev}`, /(?:^|\s)server\.mjs/);
});

test("BA12-R5-T-004 exactly one normal canonical runtime", () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(APP_ROOT, "package.json"), "utf8"));
  assert.equal(new Set([pkg.scripts.start.split(" ")[1], pkg.scripts.dev.split(" ")[1]]).size, 1);
});

test("BA12-R5-T-005 standard static runtime starts on ephemeral loopback port", async () => {
  const { response } = await json(`${staticBase}/api/health`);
  assert.equal(response.status, 200);
});

test("BA12-R5-T-006 standard static runtime serves built UI", async () => {
  const response = await fetch(`${staticBase}/`);
  assert.equal(response.status, 200);
  assert.match(await response.text(), /<div id="root"><\/div>/);
});

test("BA12-R5-T-007 health declares Bundle@2 native authority", async () => {
  const { body } = await json(`${staticBase}/api/health`);
  assert.deepEqual([body.authority, body.trustEpoch, body.rendererCutover, body.legacyTruthFallback], ["room16.compiler_artifact_bundle@2", "rfc0009_native_gen2", true, false]);
});

test("BA12-R5-T-008 state declares native_bundle_v2 and no legacy fallback", async () => {
  const { body } = await json(`${staticBase}/api/state`);
  assert.deepEqual([body.canonicalAuthority, body.legacyTruthFallback], ["native_bundle_v2", false]);
});

for (const [id, ticker] of [["009", "WM"], ["010", "COST"], ["011", "ABT"]]) {
  test(`BA12-R5-T-${id} ${ticker} signed R4 native bundle served`, async () => {
    const { response, body } = await json(`${staticBase}/api/reports/latest/${ticker}`);
    assert.equal(response.status, 200);
    assert.deepEqual([body.report.ticker, body.report.trustEpoch, body.report.legacyTruthFallback], [ticker, "rfc0009_native_gen2", false]);
  });
}

test("BA12-R5-T-012 missing native bundle never falls back", async () => {
  const { response, body } = await json(`${staticBase}/api/reports/latest/MISSING`);
  assert.equal(response.status, 404);
  assert.equal(body.report, undefined);
});

test("BA12-R5-T-013 tampered Bundle@2 fails closed without fallback", async () => {
  const temporaryRoot = fs.mkdtempSync(path.join(os.tmpdir(), "room16-r5-tamper-"));
  fs.cpSync(BUNDLE_ROOT, temporaryRoot, { recursive: true });
  const projection = path.join(temporaryRoot, "WM", "artifacts", "renderer_projection.json");
  fs.appendFileSync(projection, "\n");
  const port = 4563;
  const child = start("start", port, temporaryRoot);
  try {
    await waitFor(`http://127.0.0.1:${port}`);
    const { response, body } = await json(`http://127.0.0.1:${port}/api/state`);
    assert.equal(response.status, 500);
    assert.equal(body.legacyTruthFallback, false);
  } finally {
    stop(child);
  }
});

test("BA12-R5-T-014 normal legacy report path is archive-only", async () => {
  const { response, body } = await json(`${staticBase}/api/reports/legacy-id`);
  assert.equal(response.status, 410);
  assert.equal(body.legacyTruthFallback, false);
});

test("BA12-R5-T-017 development runtime preserves Vite UI", async () => {
  const response = await fetch(`${devBase}/`);
  assert.equal(response.status, 200);
  assert.match(await response.text(), /@vite\/client/);
});

test("BA12-R5-T-018 static runtime preserves UI deep-link fallback", async () => {
  const response = await fetch(`${staticBase}/operator/native-review`);
  assert.equal(response.status, 200);
  assert.match(await response.text(), /<div id="root"><\/div>/);
});

test("BA12-R5-T-019 required non-semantic runtime status and review feedback surfaces are preserved", async () => {
  const state = await json(`${staticBase}/api/state`);
  const feedback = await json(`${staticBase}/api/private-beta/feedback`);
  assert.equal(state.body.reportMachine.ready, true);
  assert.equal(feedback.response.status, 200);
});

test("BA12-R5-T-020 legacy server launcher is explicit acknowledgement-gated archive-only", () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(APP_ROOT, "package.json"), "utf8"));
  const launcher = fs.readFileSync(path.join(APP_ROOT, "archive-server-launcher.mjs"), "utf8");
  assert.match(pkg.scripts["start:archive"], /archive-server-launcher\.mjs/);
  assert.match(launcher, /ROOM16_ARCHIVE_RUNTIME_ACK/);
});

test("BA12-R5-T-024 canonical runtime verifier is included in Product verification", () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(APP_ROOT, "package.json"), "utf8"));
  assert.match(pkg.scripts.verify, /verify:ba12-runtime/);
});

test("BA12-R5-T-031 release publication deploy and commerce remain false", async () => {
  const { body } = await json(`${staticBase}/api/health`);
  assert.deepEqual([body.releaseAuthorized, body.publicationAuthorized, body.deployAuthorized, body.commerceAuthorized], [false, false, false, false]);
  const checkout = await json(`${staticBase}/api/checkout/session`, { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
  assert.equal(checkout.response.status, 403);
});
