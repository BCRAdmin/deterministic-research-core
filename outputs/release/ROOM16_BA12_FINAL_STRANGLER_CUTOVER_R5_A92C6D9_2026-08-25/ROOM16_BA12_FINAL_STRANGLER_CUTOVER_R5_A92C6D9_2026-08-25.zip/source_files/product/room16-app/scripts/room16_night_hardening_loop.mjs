import fs from "node:fs";
import path from "node:path";
import { spawn, spawnSync } from "node:child_process";
import { fileURLToPath, pathToFileURL } from "node:url";

const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const PROJECT_ROOT = path.resolve(APP_ROOT, "..");
const RESEARCH_ROOT = path.resolve(PROJECT_ROOT, "..", "research-agent-ops");
const OUT_ROOT = path.join(PROJECT_ROOT, ".runtime", "room16-app", "hardening");
const ACTIVE_CYCLE_PATH = path.join(OUT_ROOT, "active-cycle.json");
const LATEST_CYCLE_PATH = path.join(OUT_ROOT, "latest-cycle.json");

function argValue(name, fallback) {
  const index = process.argv.indexOf(name);
  return index >= 0 ? process.argv[index + 1] : fallback;
}

function hasFlag(name) {
  return process.argv.includes(name);
}

const cycles = Number(argValue("--cycles", "1"));
const intervalMs = Number(argValue("--interval-ms", "120000"));
const retainCycles = Number(argValue("--retain-cycles", process.env.ROOM16_HARDENING_RETAIN_CYCLES || "20"));
const port = Number(argValue("--port", process.env.PORT || "4516"));
const baseUrl = process.env.ROOM16_APP_BASE_URL || `http://127.0.0.1:${port}`;
const screenshotsEnabled = !hasFlag("--no-screenshots");
const continueOnFail = hasFlag("--continue-on-fail");
const nodeBin = process.env.ROOM16_NODE_BIN || process.env.NODE || "/opt/homebrew/bin/node";
const MAX_CYCLES_PER_INVOCATION = 24;
const MAX_RETAINED_CYCLES = 120;
const MAX_LOG_ENTRIES = 200;

let managedServer = null;

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function writeJsonAtomic(filePath, value) {
  const tempPath = `${filePath}.${process.pid}.tmp`;
  fs.writeFileSync(tempPath, `${JSON.stringify(value, null, 2)}\n`, { encoding: "utf8", mode: 0o600 });
  fs.renameSync(tempPath, filePath);
}

function timestamp() {
  return new Date().toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
}

function assertBoundedConfiguration() {
  if (!Number.isInteger(cycles) || cycles < 1 || cycles > MAX_CYCLES_PER_INVOCATION) {
    throw new Error(`--cycles must be between 1 and ${MAX_CYCLES_PER_INVOCATION}; unbounded cycles=0 is disabled`);
  }
  if (!Number.isInteger(retainCycles) || retainCycles < 1 || retainCycles > MAX_RETAINED_CYCLES) {
    throw new Error(`--retain-cycles must be between 1 and ${MAX_RETAINED_CYCLES}`);
  }
  if (!Number.isFinite(intervalMs) || intervalMs < 0) {
    throw new Error("--interval-ms must be a non-negative number");
  }
}

function generatedCycleDirs() {
  return fs.readdirSync(OUT_ROOT, { withFileTypes: true })
    .filter((entry) => entry.isDirectory() && /^\d{8}T\d{6}Z-cycle-\d+$/.test(entry.name))
    .map((entry) => entry.name)
    .sort()
    .reverse();
}

function enforceArtifactBudget() {
  const staleCycleDirs = generatedCycleDirs().slice(retainCycles);
  for (const cycleDir of staleCycleDirs) {
    fs.rmSync(path.join(OUT_ROOT, cycleDir), { recursive: true, force: true });
  }

  const logPath = path.join(OUT_ROOT, "HARDENING_LOG.md");
  if (!fs.existsSync(logPath)) return;
  const entries = fs.readFileSync(logPath, "utf8")
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => line.startsWith("- "))
    .slice(-MAX_LOG_ENTRIES);
  fs.writeFileSync(logPath, ["# Room 16 Hardening Log", "", ...entries, ""].join("\n"), "utf8");
}

async function sleep(ms) {
  await new Promise((resolve) => setTimeout(resolve, ms));
}

async function healthOk() {
  try {
    const response = await fetch(`${baseUrl}/api/health`);
    if (!response.ok) return false;
    const json = await response.json();
    return Boolean(json.ok);
  } catch {
    return false;
  }
}

async function latestReaderUrl() {
  try {
    const response = await fetch(`${baseUrl}/api/state`);
    if (!response.ok) return `${baseUrl}?reader=latest`;
    const state = await response.json();
    const company = Array.isArray(state.companies)
      ? state.companies.find((item) => item.latestReport?.id)
      : null;
    return company ? `${baseUrl}?ticker=${encodeURIComponent(company.ticker)}&reader=latest` : baseUrl;
  } catch {
    return `${baseUrl}?reader=latest`;
  }
}

async function ensureServer() {
  if (await healthOk()) {
    return { started: false, detail: "existing server healthy" };
  }
  const logPath = path.join(PROJECT_ROOT, ".runtime", "room16-app", "managed-server.log");
  ensureDir(path.dirname(logPath));
  const log = fs.openSync(logPath, "a");
  managedServer = spawn(nodeBin, ["ba12-native-server.mjs", "--static", "--port", String(port)], {
    cwd: APP_ROOT,
    stdio: ["ignore", log, log],
    detached: false
  });
  for (let attempt = 0; attempt < 20; attempt += 1) {
    if (await healthOk()) {
      return { started: true, detail: `managed server pid ${managedServer.pid}` };
    }
    await sleep(500);
  }
  throw new Error(`Room 16 app server did not become healthy at ${baseUrl}`);
}

function runCommand(label, command, args, options = {}) {
  const startedAt = new Date().toISOString();
  const result = spawnSync(command, args, {
    cwd: options.cwd || APP_ROOT,
    env: { ...process.env, ROOM16_APP_BASE_URL: baseUrl, ...options.env },
    encoding: "utf8"
  });
  return {
    label,
    command: [command, ...args],
    startedAt,
    completedAt: new Date().toISOString(),
    exitCode: result.status,
    signal: result.signal,
    error: result.error?.message || null,
    stdout: result.stdout?.slice(-12000) || "",
    stderr: result.stderr?.slice(-12000) || ""
  };
}

function commandPassed(commandResult) {
  return commandResult.exitCode === 0;
}

function gitSourceState(repoRoot) {
  const head = spawnSync("git", ["rev-parse", "HEAD"], {
    cwd: repoRoot,
    encoding: "utf8"
  });
  const status = spawnSync("git", ["status", "--porcelain"], {
    cwd: repoRoot,
    encoding: "utf8"
  });
  if (head.status !== 0 || status.status !== 0) {
    throw new Error(`Cannot bind hardening cycle to git source at ${repoRoot}`);
  }
  return {
    head: head.stdout.trim(),
    clean: status.stdout.trim() === ""
  };
}

async function runCycle(index) {
  const cycleId = `${timestamp()}-cycle-${String(index).padStart(2, "0")}`;
  const outDir = path.join(OUT_ROOT, cycleId);
  ensureDir(outDir);
  writeJsonAtomic(ACTIVE_CYCLE_PATH, {
    cycleId,
    createdAt: new Date().toISOString(),
    baseUrl,
    verdict: "running",
    commands: []
  });

  const server = await ensureServer();
  const sourceSnapshot = {
    product: gitSourceState(PROJECT_ROOT),
    research: gitSourceState(RESEARCH_ROOT)
  };
  const commands = [];
  commands.push(runCommand("build", "npm", ["run", "build"]));
  commands.push(runCommand("verify_golden_standard", "npm", ["run", "verify:golden-standard"]));
  commands.push(runCommand("verify_dependency_audit", "npm", ["run", "verify:dependency-audit"]));
  commands.push(runCommand("verify", "npm", ["run", "verify"], {
    env: { ROOM16_VERIFY_SKIP_HARDENING_STATE: "1" }
  }));
  commands.push(runCommand("verify_review_state", "npm", ["run", "verify:review-state"]));
  commands.push(runCommand("verify_authority_resolver", "npm", ["run", "verify:authority-resolver"]));
  commands.push(runCommand("verify_market_capabilities", "npm", ["run", "verify:market-capabilities"]));
  commands.push(runCommand("verify_authority_interpretation", "npm", ["run", "verify:authority-interpretation"]));
  commands.push(runCommand("verify_public_legal_review", "npm", ["run", "verify:public-legal-review"]));
  commands.push(runCommand("verify_publication_handoff", "npm", ["run", "verify:publication-handoff"]));
  commands.push(runCommand("verify_paid_product", "npm", ["run", "verify:paid-product"]));
  commands.push(runCommand("verify_commerce_contract", "npm", ["run", "verify:commerce-contract"]));
  commands.push(runCommand("verify_checkout_gateway", "npm", ["run", "verify:checkout-gateway"]));
  commands.push(runCommand("verify_payment_webhook", "npm", ["run", "verify:payment-webhook"]));
  commands.push(runCommand("verify_customer_portal", "npm", ["run", "verify:customer-portal"]));
  commands.push(runCommand("verify_customer_operation_gateway", "npm", ["run", "verify:customer-operation-gateway"]));
  commands.push(runCommand("verify_sales_activation_pack", "npm", ["run", "verify:sales-activation-pack"]));
  commands.push(runCommand("verify_customer_access_ui", "npm", ["run", "verify:customer-access-ui"]));
  commands.push(runCommand("verify_p4_technical_closure", "npm", ["run", "verify:p4-technical-closure"]));
  commands.push(runCommand("verify_p5_technical_closure", "npm", ["run", "verify:p5-technical-closure"]));
  commands.push(runCommand("verify_p6_technical_closure", "npm", ["run", "verify:p6-technical-closure"]));
  commands.push(runCommand("verify_entitlement_ledger", "npm", ["run", "verify:entitlement-ledger"]));
  commands.push(runCommand("verify_entitlement_version_access", "npm", ["run", "verify:entitlement-version-access"]));
  commands.push(runCommand("verify_product_version_registry", "npm", ["run", "verify:product-version-registry"]));
  commands.push(runCommand("verify_delivery_access", "npm", ["run", "verify:delivery-access"]));
  commands.push(runCommand("verify_delivery_http", "npm", ["run", "verify:delivery-http"]));
  commands.push(runCommand("verify_customer_operations", "npm", ["run", "verify:customer-operations"]));
  commands.push(runCommand("verify_paid_operations_readiness", "npm", ["run", "verify:paid-operations-readiness"]));
  commands.push(runCommand("verify_private_beta", "npm", ["run", "verify:private-beta"], {
    env: { ROOM16_VERIFY_SKIP_HARDENING_STATE: "1" }
  }));

  if (screenshotsEnabled) {
    const readerUrl = await latestReaderUrl();
    const customerAccessUrl = pathToFileURL(
      path.join(PROJECT_ROOT, ".runtime", "room16-customer-access-dist", "index.html")
    ).href;
    commands.push(
      runCommand("screenshot_desktop", "npx", [
        "playwright",
        "screenshot",
        "--viewport-size=1280,720",
        "--wait-for-timeout=1800",
        baseUrl,
        path.join(outDir, "desktop.png")
      ])
    );
    commands.push(
      runCommand("screenshot_medium_edge", "npx", [
        "playwright",
        "screenshot",
        "--viewport-size=1360,720",
        "--wait-for-timeout=1800",
        baseUrl,
        path.join(outDir, "medium-edge.png")
      ])
    );
    commands.push(
      runCommand("screenshot_rail_edge", "npx", [
        "playwright",
        "screenshot",
        "--viewport-size=1761,720",
        "--wait-for-timeout=1800",
        baseUrl,
        path.join(outDir, "rail-edge.png")
      ])
    );
    commands.push(
      runCommand("screenshot_reader_desktop", "npx", [
        "playwright",
        "screenshot",
        "--viewport-size=1280,720",
        "--wait-for-timeout=1800",
        readerUrl,
        path.join(outDir, "reader-desktop.png")
      ])
    );
    commands.push(
      runCommand("screenshot_mobile", "npx", [
        "playwright",
        "screenshot",
        "--viewport-size=390,844",
        "--wait-for-timeout=1800",
        baseUrl,
        path.join(outDir, "mobile.png")
      ])
    );
    commands.push(
      runCommand("screenshot_reader_mobile", "npx", [
        "playwright",
        "screenshot",
        "--viewport-size=390,844",
        "--wait-for-timeout=1800",
        readerUrl,
        path.join(outDir, "reader-mobile.png")
      ])
    );
    commands.push(
      runCommand("screenshot_customer_access_mobile", "npx", [
        "playwright",
        "screenshot",
        "--viewport-size=390,844",
        "--wait-for-timeout=800",
        customerAccessUrl,
        path.join(outDir, "customer-access-mobile.png")
      ])
    );
    commands.push(runCommand("verify_layout", "npm", ["run", "verify:layout", "--", "--screenshot-dir", outDir]));
  } else {
    commands.push(runCommand("verify_layout", "npm", ["run", "verify:layout"], {
      env: { ROOM16_VERIFY_SKIP_HARDENING_STATE: "1" }
    }));
  }

  const verdict = commands.every(commandPassed) ? "pass" : "fail";
  const report = {
    cycleId,
    createdAt: new Date().toISOString(),
    baseUrl,
    server,
    sourceSnapshot,
    screenshotsEnabled,
    verdict,
    commands
  };
  fs.writeFileSync(path.join(outDir, "report.json"), JSON.stringify(report, null, 2), "utf8");
  fs.writeFileSync(
    path.join(outDir, "report.md"),
    [
      `# Room 16 Night Hardening Cycle ${cycleId}`,
      "",
      `Created: ${report.createdAt}`,
      `Base URL: ${baseUrl}`,
      `Verdict: ${verdict}`,
      `Server: ${server.detail}`,
      "",
      "## Commands",
      "",
      ...commands.flatMap((command) => [
        `### ${command.label}`,
        "",
        `- Exit: ${command.exitCode}`,
        `- Command: \`${command.command.join(" ")}\``,
        command.stdout.trim() ? `- Stdout tail:\n\n\`\`\`text\n${command.stdout.trim()}\n\`\`\`` : "- Stdout tail: empty",
        command.stderr.trim() ? `- Stderr tail:\n\n\`\`\`text\n${command.stderr.trim()}\n\`\`\`` : "- Stderr tail: empty",
        ""
      ]),
      screenshotsEnabled
        ? "## Screenshots\n\n- `desktop.png`\n- `medium-edge.png`\n- `rail-edge.png`\n- `reader-desktop.png`\n- `mobile.png`\n- `reader-mobile.png`"
        : "## Screenshots\n\nDisabled for this run."
    ].join("\n"),
    "utf8"
  );
  writeJsonAtomic(LATEST_CYCLE_PATH, report);
  fs.rmSync(ACTIVE_CYCLE_PATH, { force: true });
  fs.appendFileSync(
    path.join(OUT_ROOT, "HARDENING_LOG.md"),
    `\n- ${report.createdAt} ${cycleId}: ${verdict} (${commands.map((command) => `${command.label}=${command.exitCode}`).join(", ")})\n`,
    "utf8"
  );
  enforceArtifactBudget();
  console.log(JSON.stringify({ cycleId, verdict, outDir }, null, 2));
  if (verdict !== "pass" && !continueOnFail) {
    process.exitCode = 1;
  }
  return verdict;
}

function cleanupManagedServer() {
  if (managedServer?.pid) {
    try {
      managedServer.kill();
    } catch {
      // Best effort cleanup only.
    }
  }
}

async function main() {
  assertBoundedConfiguration();
  ensureDir(OUT_ROOT);
  const total = cycles;
  for (let index = 1; index <= total; index += 1) {
    const verdict = await runCycle(index);
    if (verdict !== "pass" && !continueOnFail) {
      break;
    }
    if (index < total) {
      await sleep(intervalMs);
    }
  }
}

process.on("exit", () => {
  cleanupManagedServer();
});

main()
  .finally(() => {
    cleanupManagedServer();
  })
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
