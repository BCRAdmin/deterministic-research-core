import { spawn } from "node:child_process";
import process from "node:process";

const HOST = "127.0.0.1";
const PORT = 4571;
const BASE_URL = `http://${HOST}:${PORT}`;
const ACK = "ROOM16_LEGACY_ARCHIVE_ONLY";

function run(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: "inherit", ...options });
    child.once("error", reject);
    child.once("exit", (code, signal) => {
      if (signal) reject(new Error(`${command} stopped by ${signal}`));
      else resolve(code ?? 1);
    });
  });
}

async function waitForArchive(child) {
  for (let attempt = 0; attempt < 150; attempt += 1) {
    if (child.exitCode !== null) throw new Error("archive compatibility runtime stopped during startup");
    try {
      const response = await fetch(`${BASE_URL}/api/health`);
      const body = await response.json();
      if (response.ok && body?.preflight?.ok) return;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw new Error("archive compatibility runtime did not become ready");
}

function stop(child) {
  if (!child || child.exitCode !== null) return;
  try { process.kill(-child.pid, "SIGTERM"); }
  catch { child.kill("SIGTERM"); }
}

const environment = {
  ...process.env,
  HOST,
  PORT: String(PORT),
  ROOM16_ARCHIVE_RUNTIME_ACK: ACK,
  ROOM16_APP_BASE_URL: BASE_URL
};
const archive = spawn(
  process.execPath,
  ["archive-server-launcher.mjs", "--static", "--port", String(PORT)],
  { env: environment, detached: true, stdio: "inherit" }
);

let exitCode = 1;
try {
  await waitForArchive(archive);
  exitCode = await run("npm", ["run", "verify:archive-compat"], { env: environment });
} finally {
  stop(archive);
}
process.exitCode = exitCode;
