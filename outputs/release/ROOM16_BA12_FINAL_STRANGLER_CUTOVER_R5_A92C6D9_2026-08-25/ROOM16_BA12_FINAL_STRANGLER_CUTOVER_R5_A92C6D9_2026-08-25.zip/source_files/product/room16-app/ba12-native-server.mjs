import express from "express";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { createServer as createViteServer } from "vite";

import {
  createBa12ApiPayload,
  findBa12NativeReport,
  renderBa12NativeMarkdown,
  scanBa12NativeReports
} from "./server-modules/ba12-native-report.mjs";
import {
  createMutatingApiGuard,
  enforceNetworkBindingPolicy
} from "./server-modules/mutating-api-guard.mjs";
import { createPrivateBetaFeedbackStore } from "./server-modules/private-beta-feedback.mjs";
import { createSymbolResolver } from "./server-modules/symbol-resolver.mjs";

const APP_ROOT = path.dirname(fileURLToPath(import.meta.url));
const PROJECT_ROOT = path.resolve(APP_ROOT, "..");
const RUNTIME_ROOT = path.join(PROJECT_ROOT, ".runtime", "room16-app");
const FEEDBACK_ROOT = path.join(RUNTIME_ROOT, "private-beta-feedback");
const DEFAULT_RESEARCH_ROOT = path.join(
  os.homedir(),
  "Documents",
  "DreamFactory",
  "Room16",
  "research-agent-ops"
);

export const DEFAULT_BUNDLE_ROOT = path.join(
  DEFAULT_RESEARCH_ROOT,
  "outputs",
  "ba12",
  "native-canaries"
);

const AUTHORITY = "room16.compiler_artifact_bundle@2";
const TRUST_EPOCH = "rfc0009_native_gen2";

function reports(root) {
  return scanBa12NativeReports(root).map(createBa12ApiPayload);
}

function companies(root) {
  return reports(root).map((report) => ({
    ticker: report.ticker,
    companyName: report.companyName,
    reportCount: 1,
    latestReport: report,
    reports: [report],
    qualityRuns: [],
    latestQuality: null,
    deterministicReports: [report],
    nativeAuthority: true
  }));
}

function emptySummary(nativeReports) {
  return {
    totalReports: nativeReports.length,
    companies: new Set(nativeReports.map((report) => report.ticker)).size,
    publicReady: 0,
    memberReady: 0,
    manualReview: nativeReports.length,
    needsHumanReview: nativeReports.length,
    rejected: 0,
    internalOnly: nativeReports.length,
    hiddenByGate: nativeReports.length,
    effectivePublic: 0,
    effectiveMember: 0,
    speculative_deep_tech_profile_count: 0,
    accounting_gain_not_operating_turnaround_count: 0,
    vendor_only_hard_metrics_count: 0,
    order_materiality_missing_count: 0,
    technical_overweight_in_thesis_count: 0
  };
}

function runtimeState(bundleRoot, feedbackStore) {
  const nativeReports = reports(bundleRoot);
  const nativeCompanies = companies(bundleRoot);
  const analysisDate = nativeReports.map((report) => report.asOfDate).sort().at(-1) || "";
  const reportFlow = [
    "live_capture",
    "offline_replay",
    "source_native_compile",
    "signed_bundle_v2",
    "product_verify",
    "independent_review"
  ];
  return {
    companies: nativeCompanies,
    deterministicReports: nativeReports,
    jobs: [],
    comparisons: [],
    canonicalAuthority: "native_bundle_v2",
    authority: AUTHORITY,
    trustEpoch: TRUST_EPOCH,
    rendererCutover: true,
    legacyTruthFallback: false,
    reportMachine: {
      generatedAt: `${analysisDate || "1970-01-01"}T23:59:00Z`,
      ready: true,
      activeJobId: null,
      runningJobs: 0,
      queuedJobs: 0,
      failedJobs: 0,
      canceledJobs: 0,
      recoverableJobs: 0,
      supersededJobs: 0,
      recoverableByTicker: {},
      supersededByTicker: {},
      nextAction: "Native Bundle@2-Berichte unabhängig prüfen; neue Läufe bleiben außerhalb dieser Product-Runtime.",
      policy: {
        newModelProfilesVisible: false,
        paidModelProfilesRequireConfirmation: true,
        deepseekIsOllamaCloud: false,
        publicReadyRequires: ["independent_ba12_acceptance", "operator_release_go"],
        manualReviewProfiles: ["ba12-native-bundle-v2"],
        failedQualityVisibility: "hidden",
        reportFlow,
        reportFlowLabels: reportFlow.map((id) => ({ id, label: id.replaceAll("_", " ") }))
      }
    },
    reportLibrary: {
      version: "native-bundle-v2-review-only",
      generatedAt: `${analysisDate || "1970-01-01"}T23:59:00Z`,
      shelfDir: bundleRoot,
      summary: emptySummary(nativeReports),
      entries: []
    },
    privateBeta: {
      contractId: "room16-private-beta-v1",
      milestone: "private_beta_candidate",
      status: "not_ready",
      technicalReady: false,
      audience: {
        operatorCount: 1,
        supervisedReviewerLimit: 3,
        anonymousAccessAllowed: false,
        customerSelfServiceAllowed: false
      },
      checks: [{ id: "ba12-independent-acceptance", pass: false, detail: "Independent R5 acceptance required." }],
      operatorGates: ["ba12_acceptance", "release", "publication", "deploy"],
      permittedCapabilities: ["native_bundle_v2_review", "review_feedback"],
      prohibitedCapabilities: ["legacy_semantic_generation", "release", "publication", "deploy", "commerce"],
      publicReleaseAllowed: false,
      paymentAllowed: false,
      providerSpendAllowed: false,
      feedbackCount: feedbackStore.list().length
    },
    valuationCalibration: {
      operationMode: "paused_no_cost",
      providerSpendAllowed: false,
      blocksReportGeneration: false,
      available: false,
      verdict: "not_ready",
      sourceSha256: null,
      snapshotCount: 0,
      eligibleSnapshotCount: 0,
      retrospectiveReplayCount: 0,
      validMaturedOutcomeCount: 0,
      effectiveSampleCount: 0,
      uniqueIssuerCount: 0,
      sectorCount: 0,
      liveActivationAllowed: false,
      readinessReasons: ["ba12_independent_acceptance_required"],
      nextAction: "Keine Aktivierung vor unabhängiger BA12-Abnahme."
    },
    modelProfiles: [{
      id: "ba12-native-bundle-v2",
      label: "BA12 Native Bundle@2",
      provider: "research_compiler",
      quickModel: "none",
      deepModel: "none",
      default: true,
      requiresPaidConfirmation: false,
      authorityInterpretationStatus: "not_applicable",
      track: "native_bundle_v2",
      badge: "Native",
      summary: "Verifizierte Research-Semantik ohne Product-Neuberechnung.",
      tags: ["source_native", "signed", "review_only"]
    }],
    tickerAliases: { aliasEntries: 0, uniqueTickers: nativeCompanies.length },
    defaults: {
      analysisDate,
      provider: "research_compiler",
      quickModel: "none",
      deepModel: "none",
      modelProfileId: "ba12-native-bundle-v2",
      shelfDir: bundleRoot
    },
    preflight: {
      ok: nativeReports.length > 0,
      checks: [
        { name: "native_bundle_v2", ok: nativeReports.length > 0, detail: `${nativeReports.length} verified native bundles` },
        { name: "legacy_truth_fallback", ok: true, detail: "disabled" },
        { name: "release_publication_deploy", ok: true, detail: "all false" }
      ]
    },
    hardening: {
      available: false,
      verdict: "independent_rereview_required",
      latestCycleId: null,
      createdAt: null,
      commands: []
    },
    releaseGates: {
      ba12ImplementationReady: false,
      ba12Frozen: false,
      releaseReady: false,
      releaseAuthorized: false,
      publicationAuthorized: false,
      deployAuthorized: false,
      commerceAuthorized: false
    }
  };
}

function blockArchivedOperation(_req, res) {
  res.status(410).json({
    error: "This legacy semantic operation is archive-only after BA12 runtime activation.",
    legacyTruthFallback: false
  });
}

function blockOperatorGate(_req, res) {
  res.status(403).json({
    error: "Operator authorization is required; this capability is not activated.",
    releaseAuthorized: false,
    publicationAuthorized: false,
    deployAuthorized: false,
    commerceAuthorized: false
  });
}

export function createBa12NativeApp({
  bundleRoot = process.env.ROOM16_BA12_NATIVE_BUNDLE_ROOT || DEFAULT_BUNDLE_ROOT,
  host = process.env.HOST || "127.0.0.1"
} = {}) {
  const app = express();
  const requireMutatingApiAccess = createMutatingApiGuard({ host, env: process.env });
  const resolveSymbol = createSymbolResolver();
  const feedbackStore = createPrivateBetaFeedbackStore({
    storageDir: FEEDBACK_ROOT,
    reportLookup: (id) => reports(bundleRoot).find((report) => report.id === id) || null
  });

  app.disable("x-powered-by");
  app.use(express.json({ limit: "1mb" }));

  app.get("/api/health", (_req, res) => res.json({
    ok: true,
    authority: AUTHORITY,
    trustEpoch: TRUST_EPOCH,
    rendererCutover: true,
    legacyTruthFallback: false,
    canonicalRuntime: "ba12-native-server.mjs",
    releaseAuthorized: false,
    publicationAuthorized: false,
    deployAuthorized: false,
    commerceAuthorized: false
  }));
  app.get("/api/state", (_req, res) => res.json(runtimeState(bundleRoot, feedbackStore)));
  app.get("/api/companies", (_req, res) => res.json({ companies: companies(bundleRoot) }));
  app.get("/api/deterministic-reports", (_req, res) => res.json({ reports: reports(bundleRoot) }));
  app.get("/api/companies/:ticker", (req, res) => {
    const report = findBa12NativeReport(bundleRoot, req.params.ticker);
    if (!report) return res.status(404).json({ error: "Verified native company report not found." });
    const payload = createBa12ApiPayload(report);
    return res.json({ company: {
      ticker: payload.ticker,
      companyName: payload.companyName,
      reportCount: 1,
      latestReport: payload,
      reports: [payload],
      qualityRuns: [],
      latestQuality: null,
      deterministicReports: [payload],
      nativeAuthority: true
    } });
  });
  app.get("/api/compiler-artifacts/:ticker/:date", (req, res) => {
    const report = findBa12NativeReport(bundleRoot, req.params.ticker, req.params.date);
    if (!report) return res.status(404).json({ error: "Verified native CompilerArtifactBundle not found." });
    return res.json({ compilerArtifact: createBa12ApiPayload(report) });
  });
  app.get("/api/reports/latest/:ticker", (req, res) => {
    const report = findBa12NativeReport(bundleRoot, req.params.ticker);
    if (!report) return res.status(404).json({ error: "Verified native report not found." });
    return res.json({ report: createBa12ApiPayload(report) });
  });
  app.get("/api/reports/latest/:ticker/markdown", (req, res) => {
    const report = findBa12NativeReport(bundleRoot, req.params.ticker);
    if (!report) return res.status(404).type("text/plain").send("Verified native report not found.");
    return res.type("text/markdown; charset=utf-8").send(renderBa12NativeMarkdown(report));
  });
  app.get("/api/reports/latest/:ticker/pdf", (_req, res) => res.status(404).send("No hash-bound native PDF was emitted."));

  app.get("/api/public-library", (_req, res) => {
    const state = runtimeState(bundleRoot, feedbackStore);
    res.json({ reportLibrary: state.reportLibrary });
  });
  app.get("/api/private-beta", (_req, res) => {
    const state = runtimeState(bundleRoot, feedbackStore);
    res.json({ privateBeta: state.privateBeta, feedback: feedbackStore.list() });
  });
  app.get("/api/private-beta/feedback", (_req, res) => res.json({ feedback: feedbackStore.list() }));
  app.post("/api/private-beta/feedback", (req, res) => {
    if (!requireMutatingApiAccess(req, res)) return;
    try { res.status(201).json({ feedback: feedbackStore.create(req.body || {}) }); }
    catch (error) { res.status(error.statusCode || 500).json({ error: error.message || String(error) }); }
  });
  app.get("/api/report-machine", (_req, res) => {
    const state = runtimeState(bundleRoot, feedbackStore);
    res.json({ reportMachine: state.reportMachine });
  });
  app.get("/api/jobs", (_req, res) => res.json({ jobs: [] }));
  app.get("/api/comparisons", (_req, res) => res.json({ comparisons: [] }));
  app.get("/api/symbols/resolve", async (req, res) => {
    try { res.json(await resolveSymbol(req.query.q)); }
    catch (error) { res.status(503).json({ error: error.message || String(error) }); }
  });

  for (const route of [
    "/api/jobs", "/api/jobs/:id/cancel", "/api/jobs/:id/retry",
    "/api/jobs/retry-failed", "/api/comparisons", "/api/comparisons/:id/evaluate"
  ]) app.post(route, blockArchivedOperation);
  app.delete("/api/jobs/:id", blockArchivedOperation);
  app.get("/api/jobs/:id", blockArchivedOperation);
  app.get("/api/jobs/:id/log", blockArchivedOperation);
  app.get("/api/comparisons/:id", blockArchivedOperation);
  app.get("/api/reports/:id", blockArchivedOperation);
  app.get("/api/documents/:id", blockArchivedOperation);
  app.get("/api/failures/:id", blockArchivedOperation);
  app.get("/api/artifacts/:id/markdown", blockArchivedOperation);
  app.get("/api/archive/*", blockArchivedOperation);

  for (const route of [
    "/api/public-library/:id/review",
    "/api/public-library/:id/publication-handoff",
    "/api/paid-delivery/:productId/:productVersion/:artifact",
    "/api/checkout/session",
    "/api/customer-portal/access",
    "/api/payment-webhook/:providerId",
    "/api/customer-operations-webhook/:providerId"
  ]) app.post(route, blockOperatorGate);
  app.delete("/api/public-library/:id", blockOperatorGate);
  app.get("/api/membership-scope", (_req, res) => res.status(404).json({ error: "Membership scope is not part of Room16." }));

  app.use((error, _req, res, _next) => res.status(500).json({
    error: error.code || "BA12_NATIVE_RUNTIME_FAILURE",
    detail: error.message || String(error),
    legacyTruthFallback: false
  }));
  return app;
}

export async function installBa12Ui(app, { devMode = false } = {}) {
  if (devMode) {
    const vite = await createViteServer({
      root: APP_ROOT,
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
    return vite;
  }
  const distDir = path.join(APP_ROOT, "dist");
  const indexPath = path.join(distDir, "index.html");
  app.use(express.static(distDir, {
    etag: false,
    lastModified: false,
    setHeaders(res) { res.setHeader("Cache-Control", "no-store, max-age=0"); }
  }));
  app.use((_req, res) => {
    res.setHeader("Cache-Control", "no-store, max-age=0");
    if (!fs.existsSync(indexPath)) return res.status(503).send("Product UI build is missing. Run npm run build.");
    return res.sendFile(indexPath);
  });
  return null;
}

async function main() {
  const args = new Set(process.argv.slice(2));
  const devMode = args.has("--dev") || (!args.has("--static") && process.env.NODE_ENV !== "production");
  const portArgIndex = process.argv.indexOf("--port");
  const hostArgIndex = process.argv.indexOf("--host");
  const port = Number(process.env.PORT || (portArgIndex >= 0 ? process.argv[portArgIndex + 1] : "") || 4516);
  const host = process.env.HOST || (hostArgIndex >= 0 ? process.argv[hostArgIndex + 1] : "") || "127.0.0.1";
  enforceNetworkBindingPolicy({ host, env: process.env });
  const app = createBa12NativeApp({ host });
  const vite = await installBa12Ui(app, { devMode });
  fs.mkdirSync(RUNTIME_ROOT, { recursive: true });
  const freshnessPath = path.join(RUNTIME_ROOT, "server-freshness.json");
  const server = app.listen(port, host, () => {
    fs.writeFileSync(freshnessPath, `${JSON.stringify({
      schema_version: 2,
      pid: process.pid,
      started_at: new Date().toISOString(),
      host,
      port,
      canonical_runtime: "ba12-native-server.mjs",
      authority: AUTHORITY,
      trust_epoch: TRUST_EPOCH
    }, null, 2)}\n`);
    console.log(`Room16 BA12 canonical server listening at http://${host}:${port}`);
  });
  const close = async () => {
    server.close();
    if (vite) await vite.close();
  };
  process.once("SIGTERM", close);
  process.once("SIGINT", close);
}

if (import.meta.url === pathToFileURL(process.argv[1] || "").href) await main();
