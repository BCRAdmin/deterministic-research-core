import { spawn } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ACK = "ROOM16_LEGACY_ARCHIVE_ONLY";
if (process.env.ROOM16_ARCHIVE_RUNTIME_ACK !== ACK) {
  console.error(`Archive runtime requires ROOM16_ARCHIVE_RUNTIME_ACK=${ACK}.`);
  process.exit(1);
}

const root = path.dirname(fileURLToPath(import.meta.url));
const forwarded = process.argv.slice(2).filter((value, index, values) => {
  if (values[index - 1] === "--host") return false;
  return value !== "--host";
});
const child = spawn(process.execPath, [path.join(root, "server.mjs"), ...forwarded, "--host", "127.0.0.1"], {
  cwd: root,
  env: { ...process.env, HOST: "127.0.0.1" },
  stdio: "inherit"
});
child.once("exit", (code, signal) => {
  if (signal) process.kill(process.pid, signal);
  else process.exit(code ?? 1);
});
for (const signal of ["SIGINT", "SIGTERM"]) {
  process.once(signal, () => child.kill(signal));
}
