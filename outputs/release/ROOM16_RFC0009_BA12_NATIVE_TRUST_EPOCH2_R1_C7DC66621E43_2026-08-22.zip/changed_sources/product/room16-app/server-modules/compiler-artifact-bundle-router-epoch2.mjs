import fs from "node:fs";
import path from "node:path";

import { verifyCompilerArtifactBundle } from "./compiler-artifact-bundle.mjs";
import { CompilerArtifactBundleV2Error, verifyCompilerArtifactBundleV2 } from "./compiler-artifact-bundle-v2.mjs";
import { verifyCompilerArtifactBundleV2Native } from "./compiler-artifact-bundle-v2-native.mjs";

export function verifyCompilerArtifactBundleEpoch2(root, options = {}) {
  const manifestPath = path.join(path.resolve(root), "BUNDLE_MANIFEST.json");
  let manifest;
  try { manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8")); }
  catch (error) { throw new CompilerArtifactBundleV2Error("RFC9_ROUTER_MANIFEST_INVALID", error.message); }
  if (manifest.contract_version === 1) return { version: 1, epoch: "v1_frozen", ...verifyCompilerArtifactBundle(root) };
  if (manifest.contract_version !== 2) throw new CompilerArtifactBundleV2Error("RFC9_ROUTER_VERSION_UNSUPPORTED", String(manifest.contract_version));
  const origin = manifest.compiler_identity?.semantic_artifact_origin;
  if (origin === "frozen_v1_migration") return { version: 2, epoch: "rfc0008_migration_gen1", ...verifyCompilerArtifactBundleV2(root, options) };
  if (origin === "source_native") return { version: 2, epoch: "rfc0009_native_gen2", ...verifyCompilerArtifactBundleV2Native(root, options) };
  throw new CompilerArtifactBundleV2Error("RFC9_ROUTER_TRUST_EPOCH_AMBIGUOUS", String(origin));
}

export function assertSingleCanonicalRunEpoch2(candidates) {
  const canonical = new Map();
  for (const item of candidates) {
    if (!item.canonical) continue;
    const runId = `${item.ticker}:${item.asOfDate}`;
    if (canonical.has(runId)) throw new CompilerArtifactBundleV2Error("RFC9_DUAL_CANONICAL_AUTHORITY", runId);
    canonical.set(runId, `${item.contractVersion}:${item.trustEpoch}`);
  }
  return canonical;
}
