import fs from "node:fs";
import path from "node:path";
import { createHash } from "node:crypto";
import { fileURLToPath } from "node:url";

import {
  CompilerArtifactBundleV2Error,
  PINNED_RFC0008_V2_ROOT_PUBLIC_KEY_HEX,
  PINNED_RFC0008_V2_TRUST_ROOT_SHA256,
  canonicalJsonV2,
  sha256CanonicalV2,
  verifyBundleReceiptV2,
  verifySignedPolicyEnvelopeChainV2
} from "./compiler-artifact-bundle-v2.mjs";

const MODULE_DIR = path.dirname(fileURLToPath(import.meta.url));
const CONFIG_DIR = path.resolve(MODULE_DIR, "../config");
const PATHS = Object.freeze({
  root: path.join(CONFIG_DIR, "room16_compiler_v2_trust_root.json"),
  gen1: path.join(CONFIG_DIR, "room16_compiler_artifact_consumer_policy_envelope_v2.json"),
  gen2: path.join(CONFIG_DIR, "room16_compiler_artifact_consumer_policy_envelope_v2_generation_2_native.json"),
  key: path.join(CONFIG_DIR, "room16_compiler_artifact_key_policy_envelope_v2.json"),
  profile: path.join(CONFIG_DIR, "room16_compiler_artifact_bundle_schema_profile_v2_generation_2_native.json"),
  emitter: path.join(CONFIG_DIR, "room16_compiler_native_emitter_profile_v2.json")
});

export const PINNED_RFC0009_GEN1_ENVELOPE_SHA256 = "7f16189fdfd6b676fd3cb58acf9c6c51a9a1b66671dbb7c1f76156dffc5cd8c9";
export const PINNED_RFC0009_GEN2_ENVELOPE_SHA256 = "4b21ad3936ccd2ba178c5b3964e3adc34b2ea56e125ec6f8a600e6df3c16ae85";
export const PINNED_RFC0009_NATIVE_SCHEMA_PROFILE_SHA256 = "3787c243a10817e774ca055b18275bc1386520fe86ef4ee51defadd60f37794f";
export const PINNED_RFC0009_NATIVE_EMITTER_PROFILE_SHA256 = "9208d33b95a035ae7cd0dcffcc6a1c3357cb1209f5bb501ca01eb16b0b6c12e3";

const SHA256_RE = /^[0-9a-f]{64}$/;
const NATIVE_EMITTER = Object.freeze({
  emitter_id: "room16.compiler_artifact_bundle_builder_v2_native",
  emitter_version: "2.1.0-ba12",
  producer_pass_id: "ba12.l11.emit_native_bundle_v2"
});

function readJson(filePath, code) {
  try { return JSON.parse(fs.readFileSync(filePath, "utf8")); }
  catch (error) { throw new CompilerArtifactBundleV2Error(code, error.message); }
}

function exactObject(value, fields, code) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new CompilerArtifactBundleV2Error(code, "not_object");
  const actual = Object.keys(value).sort();
  const expected = [...fields].sort();
  if (actual.length !== expected.length || actual.some((item, index) => item !== expected[index])) throw new CompilerArtifactBundleV2Error(code, `fields:${actual.join(",")}`);
}

function safePath(root, relativePath) {
  if (!relativePath || path.isAbsolute(relativePath) || relativePath.split(/[\\/]/).includes("..")) throw new CompilerArtifactBundleV2Error("RFC9_ARTIFACT_PATH_UNSAFE", relativePath);
  const resolved = path.resolve(root, relativePath);
  if (!resolved.startsWith(`${path.resolve(root)}${path.sep}`)) throw new CompilerArtifactBundleV2Error("RFC9_ARTIFACT_PATH_UNSAFE", relativePath);
  return resolved;
}

function sha256File(filePath) { return createHash("sha256").update(fs.readFileSync(filePath)).digest("hex"); }

function verifyProfile(profile, expectedHash, code) {
  const body = { ...profile }; delete body.profile_sha256;
  if (profile.profile_sha256 !== expectedHash || sha256CanonicalV2(body) !== expectedHash) throw new CompilerArtifactBundleV2Error(code);
}

function loadPinnedNativeTrust() {
  const root = readJson(PATHS.root, "RFC9_TRUST_ROOT_INVALID");
  if (root.root_sha256 !== PINNED_RFC0008_V2_TRUST_ROOT_SHA256 || root.root_public_key_hex !== PINNED_RFC0008_V2_ROOT_PUBLIC_KEY_HEX) throw new CompilerArtifactBundleV2Error("RFC9_ROOT_SUBSTITUTION");
  const gen1 = readJson(PATHS.gen1, "RFC9_GEN1_POLICY_INVALID");
  const gen2 = readJson(PATHS.gen2, "RFC9_GEN2_POLICY_INVALID");
  const keyEnvelope = readJson(PATHS.key, "RFC9_KEY_POLICY_INVALID");
  if (gen1.envelope_sha256 !== PINNED_RFC0009_GEN1_ENVELOPE_SHA256 || gen2.envelope_sha256 !== PINNED_RFC0009_GEN2_ENVELOPE_SHA256) throw new CompilerArtifactBundleV2Error("RFC9_POLICY_CHAIN_PIN_MISMATCH");
  const terminal = verifySignedPolicyEnvelopeChainV2([gen1, gen2], root);
  verifySignedPolicyEnvelopeChainV2([keyEnvelope], root);
  if (terminal.generation !== 2 || terminal.previous_envelope_sha256 !== gen1.envelope_sha256) throw new CompilerArtifactBundleV2Error("RFC9_POLICY_CHAIN_INVALID");
  const profile = readJson(PATHS.profile, "RFC9_NATIVE_SCHEMA_PROFILE_INVALID");
  const emitterProfile = readJson(PATHS.emitter, "RFC9_NATIVE_EMITTER_PROFILE_INVALID");
  verifyProfile(profile, PINNED_RFC0009_NATIVE_SCHEMA_PROFILE_SHA256, "RFC9_NATIVE_SCHEMA_PROFILE_PIN_MISMATCH");
  verifyProfile(emitterProfile, PINNED_RFC0009_NATIVE_EMITTER_PROFILE_SHA256, "RFC9_NATIVE_EMITTER_PROFILE_PIN_MISMATCH");
  const policy = terminal.payload;
  if (policy.manifest_schema_profile_sha256 !== profile.profile_sha256 || policy.key_policy_sha256 !== keyEnvelope.payload.policy_sha256 || policy.trusted_emitter_id !== NATIVE_EMITTER.emitter_id || policy.compiler_identity.semantic_artifact_origin !== "source_native") throw new CompilerArtifactBundleV2Error("RFC9_NATIVE_TRUST_BINDING_MISMATCH");
  const allowedPolicyDelta = new Set(["trusted_emitter_id", "manifest_schema_profile_sha256", "policy_sha256"]);
  for (const key of new Set([...Object.keys(gen1.payload), ...Object.keys(policy)])) {
    if (key === "compiler_identity") {
      for (const identityKey of new Set([...Object.keys(gen1.payload.compiler_identity), ...Object.keys(policy.compiler_identity)])) {
        if (identityKey !== "semantic_artifact_origin" && gen1.payload.compiler_identity[identityKey] !== policy.compiler_identity[identityKey]) throw new CompilerArtifactBundleV2Error("RFC9_FROZEN_COMPILER_LOCK_DRIFT", identityKey);
      }
    } else if (!allowedPolicyDelta.has(key) && canonicalJsonV2(gen1.payload[key]) !== canonicalJsonV2(policy[key])) throw new CompilerArtifactBundleV2Error("RFC9_FORBIDDEN_POLICY_DELTA", key);
  }
  const emitterLock = profile.native_emitter_lock;
  if (canonicalJsonV2(emitterLock) !== canonicalJsonV2(emitterProfile.emitter_identity) || emitterLock.emitter_id !== NATIVE_EMITTER.emitter_id || emitterLock.emitter_version !== NATIVE_EMITTER.emitter_version || emitterLock.producer_pass_id !== NATIVE_EMITTER.producer_pass_id) throw new CompilerArtifactBundleV2Error("RFC9_NATIVE_EMITTER_BINDING_MISMATCH");
  return { root, gen1, gen2, policy, keyPolicy: keyEnvelope.payload, profile, emitterProfile };
}

function validateNativeManifest(manifest, trust) {
  const { profile, policy, emitterProfile } = trust;
  exactObject(manifest, profile.models.bundle_manifest, "RFC9_MANIFEST_SCHEMA_INVALID");
  for (const [field, model] of [["compiler_identity", "compiler_identity"], ["emitter_identity", "emitter_identity"], ["compile_identity", "compile_identity"], ["compatibility", "compatibility"], ["eligibility", "eligibility"]]) exactObject(manifest[field], profile.models[model], "RFC9_MANIFEST_SCHEMA_INVALID");
  if (manifest.contract_id !== "room16.compiler_artifact_bundle" || manifest.contract_version !== 2 || manifest.schema_version !== "2.0.0" || manifest.canonicalization_profile !== "room16.foundation.canonical_json@1" || manifest.hash_algorithm !== "sha256") throw new CompilerArtifactBundleV2Error("RFC9_MANIFEST_IDENTITY_INVALID");
  if (canonicalJsonV2(manifest.compiler_identity) !== canonicalJsonV2(policy.compiler_identity)) throw new CompilerArtifactBundleV2Error("RFC9_COMPILER_IDENTITY_LOCK_MISMATCH");
  const expectedEmitter = { ...emitterProfile.emitter_identity, consumer_policy_sha256: policy.policy_sha256 };
  if (canonicalJsonV2(manifest.emitter_identity) !== canonicalJsonV2(expectedEmitter)) throw new CompilerArtifactBundleV2Error("RFC9_NATIVE_EMITTER_IDENTITY_MISMATCH");
  const compile = manifest.compile_identity;
  const nativeHashes = ["compile_request_sha256", "source_acquisition_sha256", "retrieval_receipt_set_sha256", "source_snapshot_sha256", "final_compile_state_sha256", "verification_report_sha256", "replay_sha256"];
  if (!/^[A-Z0-9.^-]+$/.test(compile.ticker) || !/^\d{4}-\d{2}-\d{2}$/.test(compile.as_of_date) || nativeHashes.some((field) => !SHA256_RE.test(compile[field])) || compile.migration_v1_bundle_sha256 !== null) throw new CompilerArtifactBundleV2Error("RFC9_NATIVE_COMPILE_IDENTITY_INVALID");
  const expectedCompatibility = { authority_v3_bridge_direction: "bundle_to_authority_v3_only", authority_v3_semantic_input_allowed: false, compiler_mode: "source_native", legacy_semantic_input_allowed: false, mode: "bundle_native", native_source_production: true, source_native_fact_generation: true };
  if (canonicalJsonV2(manifest.compatibility) !== canonicalJsonV2(expectedCompatibility)) throw new CompilerArtifactBundleV2Error("RFC9_NATIVE_COMPATIBILITY_INVALID");
  if (manifest.eligibility.ba11_frozen !== true || manifest.eligibility.release_ready !== false || manifest.eligibility.publication_allowed !== false || manifest.eligibility.deploy_allowed !== false || manifest.eligibility.renderer_cutover !== false || manifest.eligibility.ba12_cutover_candidate !== false || typeof manifest.eligibility.compile_allowed !== "boolean" || typeof manifest.eligibility.renderer_eligible !== "boolean") throw new CompilerArtifactBundleV2Error("RFC9_NATIVE_ELIGIBILITY_INVALID");
  if (!Array.isArray(manifest.artifacts) || !Array.isArray(manifest.sections) || !Array.isArray(manifest.required_sections) || !Array.isArray(manifest.optional_sections)) throw new CompilerArtifactBundleV2Error("RFC9_MANIFEST_ARRAYS_INVALID");
  const ids = [], paths = [], hashes = new Set(), requiredKinds = new Set();
  for (const artifact of manifest.artifacts) {
    exactObject(artifact, profile.models.artifact, "RFC9_ARTIFACT_SCHEMA_INVALID");
    if (!/^[a-z][a-z0-9_.-]*$/.test(artifact.artifact_id) || !/^[a-z][a-z0-9_.-]*$/.test(artifact.artifact_kind) || !SHA256_RE.test(artifact.sha256) || !Number.isSafeInteger(artifact.byte_length) || artifact.byte_length < 0 || artifact.owner !== "research_compiler" || typeof artifact.required !== "boolean" || typeof artifact.authoritative !== "boolean" || typeof artifact.compatibility_only !== "boolean" || (artifact.authoritative && artifact.compatibility_only) || !Array.isArray(artifact.dependency_sha256s) || artifact.dependency_sha256s.some((value) => !SHA256_RE.test(value)) || artifact.dependency_sha256s.join("\0") !== [...new Set(artifact.dependency_sha256s)].sort().join("\0")) throw new CompilerArtifactBundleV2Error("RFC9_ARTIFACT_SCHEMA_INVALID", artifact.artifact_id);
    ids.push(artifact.artifact_id); paths.push(artifact.relative_path); hashes.add(artifact.sha256); if (artifact.required) requiredKinds.add(artifact.artifact_kind);
  }
  if (ids.join("\0") !== [...new Set(ids)].sort().join("\0") || paths.length !== new Set(paths).size || sha256CanonicalV2(manifest.artifacts) !== manifest.artifact_index_sha256) throw new CompilerArtifactBundleV2Error("RFC9_ARTIFACT_INDEX_INVALID");
  if (canonicalJsonV2(manifest.required_sections) !== canonicalJsonV2(profile.required_artifact_kinds) || profile.required_artifact_kinds.some((kind) => !requiredKinds.has(kind))) throw new CompilerArtifactBundleV2Error("RFC9_REQUIRED_ARTIFACT_CLOSURE_INVALID");
  const sectionIds = [], artifactIds = new Set(ids);
  for (const section of manifest.sections) {
    exactObject(section, profile.models.bundle_section, "RFC9_SECTION_SCHEMA_INVALID");
    if (!/^[a-z][a-z0-9_]*$/.test(section.section_id) || !SHA256_RE.test(section.sha256) || section.owner !== "research_compiler" || !Array.isArray(section.artifact_ids) || section.artifact_ids.join("\0") !== [...new Set(section.artifact_ids)].sort().join("\0") || section.artifact_ids.some((id) => !artifactIds.has(id))) throw new CompilerArtifactBundleV2Error("RFC9_SECTION_SCHEMA_INVALID", section.section_id);
    sectionIds.push(section.section_id);
  }
  if (sectionIds.join("\0") !== [...new Set(sectionIds)].sort().join("\0") || profile.required_bundle_section_ids.some((id) => !manifest.sections.some((item) => item.section_id === id && item.required)) || sha256CanonicalV2(manifest.sections) !== manifest.section_index_sha256) throw new CompilerArtifactBundleV2Error("RFC9_SECTION_INDEX_INVALID");
  const bridgeHashes = new Set(manifest.artifacts.filter((item) => item.artifact_kind === "authority_v3_bridge").map((item) => item.sha256));
  for (const artifact of manifest.artifacts) {
    if (artifact.dependency_sha256s.some((value) => !hashes.has(value))) throw new CompilerArtifactBundleV2Error("RFC9_ARTIFACT_DEPENDENCY_UNRESOLVED", artifact.artifact_id);
    if (artifact.authoritative && artifact.dependency_sha256s.some((value) => bridgeHashes.has(value))) throw new CompilerArtifactBundleV2Error("RFC9_INVERSE_AUTHORITY_BRIDGE", artifact.artifact_id);
  }
  const body = { ...manifest }; delete body.bundle_sha256;
  if (!SHA256_RE.test(manifest.bundle_sha256) || sha256CanonicalV2(body) !== manifest.bundle_sha256) throw new CompilerArtifactBundleV2Error("RFC9_MANIFEST_HASH_MISMATCH");
}

export function verifyCompilerArtifactBundleV2Native(root, options = {}) {
  if (!options || typeof options !== "object" || Array.isArray(options)) throw new CompilerArtifactBundleV2Error("RFC9_VERIFIER_OPTIONS_INVALID");
  const allowed = new Set(["receipt", "nowUtc", "verificationState", "consumeReceipt"]);
  const forbidden = Object.keys(options).filter((key) => !allowed.has(key));
  if (forbidden.length) throw new CompilerArtifactBundleV2Error("RFC9_CALLER_TRUST_INPUT_FORBIDDEN", forbidden.join(","));
  const { receipt, nowUtc = "2026-08-22T12:00:00Z", verificationState, consumeReceipt = false } = options;
  const trust = loadPinnedNativeTrust();
  const resolvedRoot = path.resolve(root);
  const manifest = readJson(path.join(resolvedRoot, "BUNDLE_MANIFEST.json"), "RFC9_MANIFEST_INVALID");
  validateNativeManifest(manifest, trust);
  for (const artifact of manifest.artifacts) {
    const artifactPath = safePath(resolvedRoot, artifact.relative_path);
    if (!fs.existsSync(artifactPath) || fs.statSync(artifactPath).size !== artifact.byte_length || sha256File(artifactPath) !== artifact.sha256) throw new CompilerArtifactBundleV2Error("RFC9_ARTIFACT_HASH_MISMATCH", artifact.artifact_id);
  }
  if (!receipt) throw new CompilerArtifactBundleV2Error("RFC9_RECEIPT_MISSING");
  const receiptValue = typeof receipt === "string" ? readJson(receipt, "RFC9_RECEIPT_INVALID") : receipt;
  verifyBundleReceiptV2(receiptValue, manifest, { consumerPolicy: trust.policy, keyPolicy: trust.keyPolicy, nowUtc, verificationState, consume: consumeReceipt });
  return { root: resolvedRoot, manifest, receipt: receiptValue, trustEpoch: 2, trustRootSha256: trust.root.root_sha256, consumerPolicyEnvelopeSha256: trust.gen2.envelope_sha256 };
}
