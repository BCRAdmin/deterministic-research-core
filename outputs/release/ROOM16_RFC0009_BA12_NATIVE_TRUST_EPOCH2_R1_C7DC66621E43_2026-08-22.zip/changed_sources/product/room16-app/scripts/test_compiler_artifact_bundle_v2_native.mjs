import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { fileURLToPath, pathToFileURL } from "node:url";

import {
  PINNED_RFC0008_V2_TRUST_ROOT_SHA256,
  sha256CanonicalV2,
  verifySignedPolicyEnvelopeChainV2
} from "../server-modules/compiler-artifact-bundle-v2.mjs";
import {
  PINNED_RFC0009_GEN1_ENVELOPE_SHA256,
  PINNED_RFC0009_GEN2_ENVELOPE_SHA256,
  PINNED_RFC0009_NATIVE_SCHEMA_PROFILE_SHA256,
  verifyCompilerArtifactBundleV2Native
} from "../server-modules/compiler-artifact-bundle-v2-native.mjs";
import {
  assertSingleCanonicalRunEpoch2,
  verifyCompilerArtifactBundleEpoch2
} from "../server-modules/compiler-artifact-bundle-router-epoch2.mjs";

const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const CONFIG = path.join(APP_ROOT, "config");
const NATIVE = path.join(APP_ROOT, "fixtures/rfc0009-native-probe");
const MIGRATION = path.join(APP_ROOT, "fixtures/compiler-artifact-bundle-v2-pinned");

function json(filePath) { return JSON.parse(fs.readFileSync(filePath, "utf8")); }
function receipt(root = NATIVE) { return json(path.join(root, "RECEIPT.json")); }
function mutableNative() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "room16-rfc0009-native-"));
  fs.cpSync(NATIVE, root, { recursive: true });
  return root;
}
function mutateManifest(root, mutate) {
  const file = path.join(root, "BUNDLE_MANIFEST.json");
  const manifest = json(file); mutate(manifest);
  const body = { ...manifest }; delete body.bundle_sha256;
  manifest.bundle_sha256 = sha256CanonicalV2(body);
  fs.writeFileSync(file, JSON.stringify(manifest));
  return manifest;
}

async function isolatedVerifier(mutateConfig) {
  const isolated = fs.mkdtempSync(path.join(os.tmpdir(), "room16-rfc0009-verifier-"));
  const moduleDir = path.join(isolated, "server-modules");
  const configDir = path.join(isolated, "config");
  fs.mkdirSync(moduleDir); fs.mkdirSync(configDir);
  for (const name of ["compiler-artifact-bundle-v2.mjs", "compiler-artifact-bundle-v2-native.mjs"]) fs.copyFileSync(path.join(APP_ROOT, "server-modules", name), path.join(moduleDir, name));
  for (const name of [
    "room16_compiler_v2_trust_root.json",
    "room16_compiler_artifact_consumer_policy_envelope_v2.json",
    "room16_compiler_artifact_consumer_policy_envelope_v2_generation_2_native.json",
    "room16_compiler_artifact_key_policy_envelope_v2.json",
    "room16_compiler_artifact_bundle_schema_profile_v2_generation_2_native.json",
    "room16_compiler_native_emitter_profile_v2.json"
  ]) fs.copyFileSync(path.join(CONFIG, name), path.join(configDir, name));
  mutateConfig(configDir);
  return import(`${pathToFileURL(path.join(moduleDir, "compiler-artifact-bundle-v2-native.mjs")).href}?rfc9=${Date.now()}-${Math.random()}`);
}

test("[RFC9-T-003] same pinned RFC-0008 root is used", () => {
  const result = verifyCompilerArtifactBundleV2Native(NATIVE, { receipt: receipt() });
  assert.equal(result.trustRootSha256, PINNED_RFC0008_V2_TRUST_ROOT_SHA256);
});

test("[RFC9-T-004] a replaced root is blocked", async () => {
  const module = await isolatedVerifier((dir) => {
    const file = path.join(dir, "room16_compiler_v2_trust_root.json");
    const value = json(file); value.root_public_key_hex = "0".repeat(64); fs.writeFileSync(file, JSON.stringify(value));
  });
  assert.throws(() => module.verifyCompilerArtifactBundleV2Native(NATIVE, { receipt: receipt() }), (error) => error.diagnosticCode === "RFC9_ROOT_SUBSTITUTION");
});

test("[RFC9-T-005] root-signed Gen1 to Gen2 chain passes", () => {
  const root = json(path.join(CONFIG, "room16_compiler_v2_trust_root.json"));
  const gen1 = json(path.join(CONFIG, "room16_compiler_artifact_consumer_policy_envelope_v2.json"));
  const gen2 = json(path.join(CONFIG, "room16_compiler_artifact_consumer_policy_envelope_v2_generation_2_native.json"));
  assert.equal(verifySignedPolicyEnvelopeChainV2([gen1, gen2], root).envelope_sha256, PINNED_RFC0009_GEN2_ENVELOPE_SHA256);
});

test("[RFC9-T-006] wrong Gen2 predecessor is blocked", () => {
  const root = json(path.join(CONFIG, "room16_compiler_v2_trust_root.json"));
  const gen1 = json(path.join(CONFIG, "room16_compiler_artifact_consumer_policy_envelope_v2.json"));
  const gen2 = json(path.join(CONFIG, "room16_compiler_artifact_consumer_policy_envelope_v2_generation_2_native.json"));
  gen2.previous_envelope_sha256 = "0".repeat(64);
  assert.throws(() => verifySignedPolicyEnvelopeChainV2([gen1, gen2], root));
});

test("[RFC9-T-007] wrong Gen2 generation is blocked", () => {
  const root = json(path.join(CONFIG, "room16_compiler_v2_trust_root.json"));
  const gen1 = json(path.join(CONFIG, "room16_compiler_artifact_consumer_policy_envelope_v2.json"));
  const gen2 = json(path.join(CONFIG, "room16_compiler_artifact_consumer_policy_envelope_v2_generation_2_native.json"));
  gen2.generation = 3;
  assert.throws(() => verifySignedPolicyEnvelopeChainV2([gen1, gen2], root));
});

test("[RFC9-T-008] a parallel Gen2 fork is blocked", () => {
  const root = json(path.join(CONFIG, "room16_compiler_v2_trust_root.json"));
  const gen1 = json(path.join(CONFIG, "room16_compiler_artifact_consumer_policy_envelope_v2.json"));
  const gen2 = json(path.join(CONFIG, "room16_compiler_artifact_consumer_policy_envelope_v2_generation_2_native.json"));
  assert.throws(() => verifySignedPolicyEnvelopeChainV2([gen1, gen2, { ...gen2 }], root));
});

test("[RFC9-T-009] a non-root Gen2 signature is blocked", () => {
  const root = json(path.join(CONFIG, "room16_compiler_v2_trust_root.json"));
  const gen1 = json(path.join(CONFIG, "room16_compiler_artifact_consumer_policy_envelope_v2.json"));
  const gen2 = json(path.join(CONFIG, "room16_compiler_artifact_consumer_policy_envelope_v2_generation_2_native.json"));
  gen2.signature = receipt().signature;
  assert.throws(() => verifySignedPolicyEnvelopeChainV2([gen1, gen2], root));
});

for (const [id, label, mutate] of [
  ["010", "BA10 anchor", (policy) => { policy.ba10_v1_freeze_sha256 = "0".repeat(64); }],
  ["011", "semantic compiler lock", (policy) => { policy.compiler_identity.semantic_wave_version_lock = "0".repeat(64); }]
]) test(`[RFC9-T-${id}] changed ${label} is blocked`, async () => {
  const module = await isolatedVerifier((dir) => {
    const file = path.join(dir, "room16_compiler_artifact_consumer_policy_envelope_v2_generation_2_native.json");
    const value = json(file); mutate(value.payload); fs.writeFileSync(file, JSON.stringify(value));
  });
  assert.throws(() => module.verifyCompilerArtifactBundleV2Native(NATIVE, { receipt: receipt() }));
});

test("[RFC9-T-012] Gen2 locks source_native origin", () => {
  const gen2 = json(path.join(CONFIG, "room16_compiler_artifact_consumer_policy_envelope_v2_generation_2_native.json"));
  assert.equal(gen2.payload.compiler_identity.semantic_artifact_origin, "source_native");
});

test("[RFC9-T-013] native schema profile is hash-bound by Gen2", () => {
  const gen2 = json(path.join(CONFIG, "room16_compiler_artifact_consumer_policy_envelope_v2_generation_2_native.json"));
  assert.equal(gen2.payload.manifest_schema_profile_sha256, PINNED_RFC0009_NATIVE_SCHEMA_PROFILE_SHA256);
});

test("[RFC9-T-014] migration origin in native profile is blocked", async () => {
  const module = await isolatedVerifier((dir) => {
    const file = path.join(dir, "room16_compiler_artifact_bundle_schema_profile_v2_generation_2_native.json");
    const value = json(file); value.compiler_identity_lock.semantic_artifact_origin = "frozen_v1_migration"; fs.writeFileSync(file, JSON.stringify(value));
  });
  assert.throws(() => module.verifyCompilerArtifactBundleV2Native(NATIVE, { receipt: receipt() }));
});

test("[RFC9-T-015] native emitter is distinct from migration emitter", () => {
  const native = json(path.join(CONFIG, "room16_compiler_native_emitter_profile_v2.json"));
  assert.equal(native.emitter_identity.emitter_id, "room16.compiler_artifact_bundle_builder_v2_native");
  assert.notEqual(native.emitter_identity.emitter_id, "room16.compiler_artifact_bundle_builder_v2");
});

test("[RFC9-T-016] migration emitter issuing bundle_native is blocked", () => {
  const root = mutableNative(); mutateManifest(root, (m) => { m.emitter_identity.emitter_id = "room16.compiler_artifact_bundle_builder_v2"; });
  assert.throws(() => verifyCompilerArtifactBundleV2Native(root, { receipt: receipt() }), (error) => error.diagnosticCode === "RFC9_NATIVE_EMITTER_IDENTITY_MISMATCH");
});

test("[RFC9-T-017] native emitter issuing migration bundle is blocked", () => {
  const root = mutableNative(); mutateManifest(root, (m) => { m.compatibility.mode = "bundle_dual_read"; m.compatibility.compiler_mode = "migration_dual_read"; m.compatibility.source_native_fact_generation = false; m.compatibility.native_source_production = false; });
  assert.throws(() => verifyCompilerArtifactBundleV2Native(root, { receipt: receipt() }));
});

test("[RFC9-T-018] truthful source_native identity is accepted", () => {
  assert.equal(verifyCompilerArtifactBundleV2Native(NATIVE, { receipt: receipt() }).manifest.compiler_identity.semantic_artifact_origin, "source_native");
});

test("[RFC9-T-019] truthful native compatibility flags are accepted", () => {
  assert.equal(verifyCompilerArtifactBundleV2Native(NATIVE, { receipt: receipt() }).manifest.compatibility.native_source_production, true);
});

for (const [id, mutate] of [
  ["020", (m) => { m.compatibility.source_native_fact_generation = false; }],
  ["021", (m) => { m.compatibility.native_source_production = false; }],
  ["022", (m) => { m.compatibility.legacy_semantic_input_allowed = true; }],
  ["023", (m) => { m.compatibility.authority_v3_semantic_input_allowed = true; }],
  ["024", (m) => { m.eligibility.release_ready = true; }],
  ["025", (m) => { m.eligibility.publication_allowed = true; m.eligibility.deploy_allowed = true; }]
]) test(`[RFC9-T-${id}] forbidden native state is blocked`, () => {
  const root = mutableNative(); mutateManifest(root, mutate);
  assert.throws(() => verifyCompilerArtifactBundleV2Native(root, { receipt: receipt() }));
});

test("[RFC9-T-026] Product native verifier uses fixed trust paths", () => {
  assert.equal(verifyCompilerArtifactBundleV2Native(NATIVE, { receipt: receipt() }).trustEpoch, 2);
});

test("[RFC9-T-027] caller-selected trust paths are forbidden", () => {
  assert.throws(() => verifyCompilerArtifactBundleV2Native(NATIVE, { receipt: receipt(), policyPath: "/tmp/attacker" }), (error) => error.diagnosticCode === "RFC9_CALLER_TRUST_INPUT_FORBIDDEN");
});

test("[RFC9-T-028] Bundle@1 dispatches the frozen v1 verifier", () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "room16-rfc0009-v1-route-"));
  fs.writeFileSync(path.join(root, "BUNDLE_MANIFEST.json"), JSON.stringify({ contract_version: 1 }));
  assert.throws(
    () => verifyCompilerArtifactBundleEpoch2(root),
    (error) => error.diagnosticCode?.startsWith("ABI_") && !error.diagnosticCode.startsWith("RFC9_ROUTER_")
  );
});

test("[RFC9-T-029] migration Bundle@2 dispatches RFC-0008", () => {
  assert.equal(verifyCompilerArtifactBundleEpoch2(MIGRATION, { receipt: receipt(MIGRATION) }).epoch, "rfc0008_migration_gen1");
});

test("[RFC9-T-030] native Bundle@2 dispatches RFC-0009", () => {
  assert.equal(verifyCompilerArtifactBundleEpoch2(NATIVE, { receipt: receipt() }).epoch, "rfc0009_native_gen2");
});

test("[RFC9-T-031] native failure never falls back", () => {
  const root = mutableNative(); mutateManifest(root, (m) => { m.emitter_identity.emitter_id = "attacker"; });
  assert.throws(() => verifyCompilerArtifactBundleEpoch2(root, { receipt: receipt() }), (error) => error.diagnosticCode === "RFC9_NATIVE_EMITTER_IDENTITY_MISMATCH");
});

test("[RFC9-T-032] ambiguous semantic origin is blocked", () => {
  const root = mutableNative(); mutateManifest(root, (m) => { delete m.compiler_identity.semantic_artifact_origin; });
  assert.throws(() => verifyCompilerArtifactBundleEpoch2(root, { receipt: receipt() }), (error) => error.diagnosticCode === "RFC9_ROUTER_TRUST_EPOCH_AMBIGUOUS");
});

test("[RFC9-T-033] Gen1 and Gen2 cannot both be canonical", () => {
  assert.throws(() => assertSingleCanonicalRunEpoch2([
    { ticker: "WM", asOfDate: "2026-08-11", contractVersion: 2, trustEpoch: 1, canonical: true },
    { ticker: "WM", asOfDate: "2026-08-11", contractVersion: 2, trustEpoch: 2, canonical: true }
  ]), (error) => error.diagnosticCode === "RFC9_DUAL_CANONICAL_AUTHORITY");
});

test("[RFC9-T-034] Gen1 leaf key policy is reused unchanged", () => {
  const gen1 = json(path.join(CONFIG, "room16_compiler_artifact_consumer_policy_envelope_v2.json"));
  const gen2 = json(path.join(CONFIG, "room16_compiler_artifact_consumer_policy_envelope_v2_generation_2_native.json"));
  assert.equal(gen2.payload.key_policy_sha256, gen1.payload.key_policy_sha256);
  assert.equal(gen1.envelope_sha256, PINNED_RFC0009_GEN1_ENVELOPE_SHA256);
});

test("[RFC9-T-035] signed native receipt verifies under rooted Gen2 policy", () => {
  assert.match(verifyCompilerArtifactBundleV2Native(NATIVE, { receipt: receipt() }).receipt.receipt_sha256, /^[0-9a-f]{64}$/);
});

test("[RFC9-T-036] receipt compiler identity mismatch is blocked", () => {
  const value = receipt(); value.compiler_identity_sha256 = "0".repeat(64);
  assert.throws(() => verifyCompilerArtifactBundleV2Native(NATIVE, { receipt: value }), (error) => error.diagnosticCode === "RFC8_RECEIPT_BINDING_MISMATCH");
});

test("[RFC9-T-037] Gen1 policy identity on native receipt is blocked", () => {
  const value = receipt(MIGRATION);
  assert.throws(() => verifyCompilerArtifactBundleV2Native(NATIVE, { receipt: value }), (error) => error.diagnosticCode === "RFC8_RECEIPT_BINDING_MISMATCH");
});
