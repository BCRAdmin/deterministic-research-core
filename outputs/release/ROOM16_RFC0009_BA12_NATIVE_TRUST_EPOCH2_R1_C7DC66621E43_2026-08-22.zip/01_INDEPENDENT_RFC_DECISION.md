# Independent RFC Decision

Verdict: **ACCEPTED_FOR_IMPLEMENTATION**

## Chosen architecture

Keep the RFC-0008 bootstrap Research trust root unchanged.

Add:

```text
Consumer Policy Envelope Generation 2
Native Manifest Schema Profile Generation 2
Native Emitter Trust Profile
Product Native Bundle@2 Verifier
Product Native v1/v2 Trust Router Successor
```

All are anchored to the existing RFC-0008 root.

## Why this is correct

The stop evidence proves that `CompilerArtifactBundle@2` already accepts a
truthful native identity. The conflict exists only because RFC-0008 Generation
1 intentionally pinned:

`semantic_artifact_origin=frozen_v1_migration`.

That value was correct for migration canaries and must remain frozen.

A root replacement is unnecessary and would create avoidable trust churn.
A Bundle major bump is unnecessary because Bundle@2 already contains the
native state model.

## Authority model

```text
RFC-0008 Root
├── Consumer Policy Gen 1 -> migration trust
└── Consumer Policy Gen 2 -> source-native BA12 trust
```

Generation 2 must be root-signed and chain-linked to Generation 1.

The same root does **not** mean the two policy generations are interchangeable.
Product must select the required trust epoch explicitly and fail closed.

RFC-0009 needs independent acceptance/freeze before BA12 resumes.
