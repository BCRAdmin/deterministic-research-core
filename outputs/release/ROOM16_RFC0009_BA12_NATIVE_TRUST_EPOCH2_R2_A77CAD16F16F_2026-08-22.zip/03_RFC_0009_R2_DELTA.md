# RFC-0009 R2 Delta

R2 retains the same RFC-0008 root, Bundle@2 major, Generation 2, source-native policy, fixed router dispatch, and closed release/publication/deploy gates. It replaces the unfrozen R1 static implementation pin with a frozen emitter contract lock and a Research-signed dynamic implementation SHA-256. It also permits strict-boolean BA12 candidate/renderer state transitions without setting them. BA12 remains paused.
