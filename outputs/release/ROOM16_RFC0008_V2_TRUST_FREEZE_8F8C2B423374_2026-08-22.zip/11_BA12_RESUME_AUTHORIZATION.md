# BA12 Resume Authorization

RFC-0008 is accepted and frozen. BA12 RFC-0007 may resume.

This does not authorize release, publication or deploy.
