#!/usr/bin/env python3
import hashlib,json,sys,zipfile
from pathlib import PurePosixPath
p=sys.argv[1]
with zipfile.ZipFile(p) as z:
 names=z.namelist()
 if len(names)!=len(set(names)): raise SystemExit("duplicate entries")
 if any(PurePosixPath(n).is_absolute() or ".." in PurePosixPath(n).parts for n in names): raise SystemExit("unsafe path")
 m=json.loads(z.read("MANIFEST.json"))
 body={k:v for k,v in m.items() if k!="manifest_sha256"}
 canonical=json.dumps(body,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()
 if hashlib.sha256(canonical).hexdigest()!=m["manifest_sha256"]: raise SystemExit("manifest hash")
 if any(n not in names for n in m["required_files"]): raise SystemExit("required files")
 for item in m["files"]:
  data=z.read(item["path"])
  if len(data)!=item["bytes"] or hashlib.sha256(data).hexdigest()!=item["sha256"]: raise SystemExit("file hash:"+item["path"])
 freeze=json.loads(z.read("02_WHOLE_SYSTEM_FREEZE_RECORD.json"))
 matrix=json.loads(z.read("04_FREEZE_TEST_MATRIX_EXECUTED.json"))
 gates=json.loads(z.read("14_RELEASE_GATE_STATE.json"))
 deterministic=json.loads(z.read("16_DETERMINISTIC_BUILD_REPORT.json"))
 if freeze["status"]!="accepted_frozen" or not freeze["ba12_frozen"]: raise SystemExit("freeze state")
 if matrix["status"]!="PASS" or matrix["row_count"]!=30 or any(r["status"]!="PASS" for r in matrix["rows"]): raise SystemExit("matrix")
 flags=gates["flags"]
 if not all(flags[k] for k in ("ba0_ba12_rebuild_complete","ba12_implementation_ready","ba12_frozen","release_ready")): raise SystemExit("technical flags")
 if any(flags[k] for k in ("release_authorized","deploy_authorized","publication_authorized","public_member_visibility_authorized","commerce_authorized","payment_authorized","external_communication_authorized")): raise SystemExit("operational flags")
 if not deterministic["two_clean_builds_byte_identical"]: raise SystemExit("determinism")
 print(json.dumps({"contract_id":"room16.ba12.whole_system_freeze.independent_verifier@1","status":"PASS","freeze_sha256":freeze["freeze_sha256"],"manifest_sha256":m["manifest_sha256"],"verified_file_count":len(m["files"])},sort_keys=True))
