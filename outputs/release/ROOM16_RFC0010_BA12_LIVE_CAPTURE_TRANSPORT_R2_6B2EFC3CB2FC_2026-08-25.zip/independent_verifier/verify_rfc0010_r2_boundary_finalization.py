#!/usr/bin/env python3
"""Standalone boundary-finalization verifier for the RFC-0010 R2 package."""

from __future__ import annotations

import hashlib
import json
import sys
import zipfile
from pathlib import Path
from typing import Any

SNAPSHOT_DOMAIN = b"room16.rfc0010.r2_foreign_boundary_snapshot@1\0"
STOP_SHA256 = "c3e32493ca669fa61efcef9cf3e73f461c55bdf387b6b192429f9441ff269581"
FOREIGN_ORIGIN = "https://github.com/BCRAdmin/materialbedarf-rechner.de.git"
FINALIZATION_MEMBERS = {
    "21_FOREIGN_BOUNDARY_BEFORE.json",
    "22_FOREIGN_BOUNDARY_PRE_PUSH.json",
    "23_FOREIGN_BOUNDARY_AFTER.json",
    "24_FOREIGN_BOUNDARY_EQUALITY_RECEIPT.json",
    "25_PREVIOUS_STOP_REFERENCE.json",
    "independent_verifier/verify_rfc0010_r2_boundary_finalization.py",
}


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def snapshot_hash(value: dict[str, Any]) -> str:
    body = {**value}
    body.pop("snapshot_sha256", None)
    encoded = json.dumps(body, sort_keys=True, separators=(",", ":")).encode()
    return sha256(SNAPSHOT_DOMAIN + encoded)


def object_from(archive: zipfile.ZipFile, name: str) -> dict[str, Any]:
    value = json.loads(archive.read(name))
    if not isinstance(value, dict):
        raise ValueError(f"RFC10_R2_FINALIZATION_JSON_OBJECT_REQUIRED:{name}")
    return value


def verify(package: Path) -> dict[str, Any]:
    package_bytes = package.read_bytes()
    with zipfile.ZipFile(package) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or not FINALIZATION_MEMBERS.issubset(names):
            raise ValueError("RFC10_R2_FINALIZATION_MEMBER_SET_INVALID")

        core_source = archive.read("independent_verifier/verify_rfc0010_r2_evidence.py")
        namespace: dict[str, Any] = {
            "__file__": "independent_verifier/verify_rfc0010_r2_evidence.py",
            "__name__": "rfc0010_r2_core_verifier",
        }
        exec(compile(core_source, namespace["__file__"], "exec"), namespace)
        namespace["REQUIRED"] = set(names)
        core_result = namespace["verify_package"](package)
        if core_result.get("status") != "PASS":
            raise ValueError("RFC10_R2_CORE_VERIFIER_FAILED")

        snapshot_names = [
            "21_FOREIGN_BOUNDARY_BEFORE.json",
            "22_FOREIGN_BOUNDARY_PRE_PUSH.json",
            "23_FOREIGN_BOUNDARY_AFTER.json",
        ]
        raw_snapshots = [archive.read(name) for name in snapshot_names]
        if not (raw_snapshots[0] == raw_snapshots[1] == raw_snapshots[2]):
            raise ValueError("RFC10_R2_FOREIGN_BOUNDARY_NOT_IDENTICAL")
        snapshots = [object_from(archive, name) for name in snapshot_names]
        for snapshot in snapshots:
            if (
                snapshot_hash(snapshot) != snapshot.get("snapshot_sha256")
                or snapshot.get("origin") != FOREIGN_ORIGIN
                or snapshot.get("foreign_mutation_commands_executed") != []
            ):
                raise ValueError("RFC10_R2_FOREIGN_SNAPSHOT_INVALID")

        equality = object_from(archive, "24_FOREIGN_BOUNDARY_EQUALITY_RECEIPT.json")
        stop = object_from(archive, "25_PREVIOUS_STOP_REFERENCE.json")
        expected_snapshot_hashes = {
            "after": snapshots[2]["snapshot_sha256"],
            "before": snapshots[0]["snapshot_sha256"],
            "pre_push": snapshots[1]["snapshot_sha256"],
        }
        expected_file_hashes = {
            "after": sha256(raw_snapshots[2]),
            "before": sha256(raw_snapshots[0]),
            "pre_push": sha256(raw_snapshots[1]),
        }
        if (
            equality.get("status") != "PASS"
            or equality.get("unchanged") is not True
            or equality.get("previous_stop_sha256") != STOP_SHA256
            or equality.get("snapshot_sha256") != expected_snapshot_hashes
            or equality.get("snapshot_file_sha256") != expected_file_hashes
            or equality.get("foreign_mutation_commands_executed") != []
            or stop.get("sha256") != STOP_SHA256
            or stop.get("verified") is not True
        ):
            raise ValueError("RFC10_R2_FOREIGN_EQUALITY_RECEIPT_INVALID")

    return {
        "ba12_resume_authorized": False,
        "boundary_snapshot_sha256": snapshots[0]["snapshot_sha256"],
        "contract_id": "room16.rfc0010.r2_boundary_finalization_verifier@1",
        "manifest_sha256": core_result["manifest_sha256"],
        "matrix_rows_passed": 37,
        "package": package.name,
        "package_bytes": len(package_bytes),
        "package_sha256": sha256(package_bytes),
        "ready_for_independent_rereview": True,
        "rfc0010_frozen": False,
        "rfc0010_implementation_ready": False,
        "status": "PASS",
        "unchanged": True,
        "zip_entries": len(names),
    }


def main() -> int:
    if len(sys.argv) != 2:
        raise SystemExit("usage: verify_boundary_final_evidence.py PACKAGE")
    print(json.dumps(verify(Path(sys.argv[1]).resolve()), indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
