# Required R3 Contract Deltas

Die maschinenlesbaren Findings in `03_REREVIEW_FINDINGS.json` sind führend.
Diese Datei beschreibt die verbindliche Zielarchitektur.

## 1. Product Authority Anchor

Product prüft **nicht** mehr zwei frei übergebene Objekte.

```text
trusted_research_anchor
  -> research_snapshot_sha256
  -> exact mirrored snapshot bytes
  -> consumer verdict
```

Der Trust Anchor muss aus einer Research-owned, hash-/signaturgebundenen
Receipt oder dem bestehenden Product Runtime Trust API stammen. Product darf
den erwarteten Hash nicht im selben Call selbst bestimmen.

## 2. Approval und Independent Review

Beide Attestation-Typen benötigen getrennte Sign-/Verify-Pfade.

Verifier-Inputs mindestens:

```text
expected_decision
expected_scope
expected_subject_ids
expected_subject_sha256s
expected_finding_set_sha256
expected_previous_registry_head_sha256
trusted_role_key_policy
revoked_keys
consumed_nonce_store
minimum_monotonic_counter
fixed_now_utc
```

Eine `decision=reject`-Receipt darf niemals Promotion autorisieren.
Reviewer-Key, Operator-Key und Research-Key müssen policy-seitig getrennt sein.

## 3. Azyklischer Identitätsgraph

Empfohlene Reihenfolge:

```text
TechnicalBaseline
  -> GovernanceEnvelope
  -> FreezeCore
  -> RegistryEvent / RegistryEntry
  -> RegistrySnapshot
  -> RegistryTransaction / CommitReceipt
  -> RegistryHead
```

`FreezeCore` darf nicht den Snapshot referenzieren, der seinerseits den
Freeze-Hash enthält. Die gemeinsame Bindung gehört in Transaction/CommitReceipt.

## 4. Atomare Registry Transaction

Der produktive Commit nimmt ausschließlich eine vollständig validierte
`RegistryTransaction` entgegen. Die Transaktion bindet:

```text
base_head
candidate_snapshot
event_set / ledger_head
freeze
comparison_result
independent_review
operator_approval
debt_head
archive_receipt
artifact_set
```

Ablauf: immutable staging -> verify -> prepared receipt -> fsync -> CAS ->
atomic head rename -> directory fsync -> readback -> committed receipt.
Recovery ist idempotent; ein Fehler nach dem Swap darf keinen unbekannten
Commitstatus erzeugen.

## 5. Append-only Ledgers

Registry und Debt besitzen persistente Head-Records mit:

```text
generation
event_count
previous_head_sha256
current_event_sha256
ledger_content_sha256
```

Ein gültiger Präfix ist ohne den erwarteten Authority Head **kein**
vollständiger Ledger. Truncation, rollback, fork, duplicate und merge blockieren.

## 6. Record-by-Record Contract Catalog

Mindestens eigene Contract-IDs/Schemas:

```text
PromotionEvent
RejectionEvent
StaleEvent
RecoveryEvent
SupersessionEvent
EvidenceManifest
```

Jeder Katalogeintrag enthält:

```text
contract_id
schema_version
authority_owner
schema_file_sha256
canonicalization_profile
hash_domain
hash_preimage_fields
hash_excluded_fields
unknown_field_policy
diagnostics
positive_fixture_refs
negative_fixture_refs
```

`CanaryRegistryEntry` erhält `entry_sha256`.

## 7. Derived Snapshot

Ein einziger normativer `ledger_to_snapshot`-Fold erzeugt die Entries.
Snapshot-Constructoren akzeptieren keine frei erfundenen Derived States.
Alle Event-States besitzen eine eindeutige Snapshot-Projektion.

## 8. No-new-truth

`ComparisonResult` erzwingt:

```text
ordinary_change =>
  fact_diff_count == 0
  claim_diff_count == 0
  decision_diff_count == 0
  lineage_diff_count == 0
```

`ChangeClassification` wird aus dem verifizierten Result abgeleitet; doppelte,
unabhängig manipulierbare Counter entfallen.

## 9. ID / SemVer / Genesis

- exakte Cross-Language Subject-Normalisierung,
- vollständige ID-Preimage,
- Collision Gate,
- SemVer-Delta aus ChangeClass,
- persistenter einmaliger Genesis-Import-Head.

## 10. Evidence Builder vs Verifier

Der Builder sammelt nur Artefakte. Ein separater Verifier leitet Verdict und
Finding-Closure ab. Hardcodierte `closed_verified`-/PASS-Werte sind verboten.

Jede Finding-Zeile bindet präzise:

```text
exact changed files + hashes
actual test IDs
command receipts
negative fixtures
evidence members
closure verifier result
```

## 11. Source / Regression Receipts

Receipts binden den vollständigen Commit und Tree, kompletten Worktree-Status,
Tool-/Dependency-Versionen, fachliche Inputs, Verifier-Skripte sowie Raw- und
normalisierte Outputs.

## 12. Manifest / Package Identity

`EvidenceManifest` besitzt eine explizite Self-Hash-Preimage-Regel.
ZIP und detached `.zip.sha256` sind gemeinsam das Auslieferungsset.
