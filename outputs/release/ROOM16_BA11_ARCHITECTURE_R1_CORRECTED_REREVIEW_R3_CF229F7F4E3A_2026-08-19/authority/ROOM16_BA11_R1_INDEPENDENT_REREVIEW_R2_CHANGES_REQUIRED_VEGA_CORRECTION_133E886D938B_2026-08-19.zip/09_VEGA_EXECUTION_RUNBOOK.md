# Vega Execution Runbook — BA11 R3

## Phase A — Lock and Reproduce

1. Source ZIP per `02_INPUT_LOCK.json` hashen und testen.
2. Reviewed Research/Product Heads auschecken oder deren direkte additive
   Nachfolger verwenden.
3. `tools/audit_source_result.py` ausführen.
4. Aktuelle P0-Gegenbeweise aus `tools/reproduce_current_failures.py` und
   `tools/reproduce_product_trust_root.mjs` reproduzieren.
5. Keine Baseline-/Ready-Markierung ändern.

## Phase B — P0 Root Causes

Reihenfolge:

1. `BA11-RR2-P0-006` Identitätszyklus brechen.
2. `BA11-RR2-P0-005` vollständigen Maschinenvertrag herstellen.
3. `BA11-RR2-P0-002` Approval/Review Trust.
4. `BA11-RR2-P0-004` persistente Ledgers.
5. `BA11-RR2-P0-003` Transaction-Orchestrator.
6. `BA11-RR2-P0-001` Product Trust Anchor.
7. `BA11-RR2-P0-007` unabhängigen Evidence-Verifier.

Keine kosmetischen Einzelpatches vor Root-Cause-Closure.

## Phase C — P1/P2

- no-new-truth Cross-Binding,
- ledger_to_snapshot Projection,
- ID/SemVer/Genesis,
- vollständige R1-Adversarial-Matrix,
- Source-Tree-/Raw-Receipt-Bindung,
- SourceContractLock typing,
- EvidenceManifest/Package Identity.

## Phase D — Verification

1. Alle Zeilen aus `08_REQUIRED_TEST_MATRIX.json`.
2. Vollständige Research Regression.
3. Vollständige Product Regression mit gesundem lokalen Server.
4. BA10 Freeze-Verifier gegen unveränderte Authority.
5. Ruff/Lint/Schema generation.
6. Deterministic build zweimal; ZIP-Bytes und Package-Hash identisch.
7. `tools/verify_r3_evidence.py` gegen das neue Paket.

## Phase E — Git

- additive Commits,
- keine fremden Änderungen überschreiben,
- kein Force-Push,
- Push erst nach vollständigem PASS,
- Commit- und Tree-IDs in Evidence binden.

## Phase F — Output

Erzeuge genau das Paket aus `10_R3_EVIDENCE_BUNDLE_CONTRACT.md`.

Erlaubter finaler lokaler Status:

```text
correction_candidate=ready_for_independent_rereview
next_gate=corrected_ba11_architecture_r1_and_independent_rereview
```

Nicht erlaubt:

```text
ba11_implementation_ready=true
ba12_authorized=true
release_authorized=true
publication_authorized=true
```
