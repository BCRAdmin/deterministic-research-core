# Stop Conditions

Vega stoppt fail-closed, ohne Ready-/Promotion-/Release-Status, wenn:

1. das Source-Ergebnis-ZIP fehlt oder SHA-256 abweicht;
2. Review-/Execution-Authority im Source-ZIP nicht exakt gebunden ist;
3. der Identity Graph nicht azyklisch geschlossen werden kann;
4. kein externer Research Trust Anchor für Product verfügbar ist;
5. Operator-/Reviewer-Key-Policy nicht eindeutig ermittelbar ist;
6. Nonce/Counter nicht atomar persistierbar sind;
7. Registry-/Debt-Rollback weiterhin als gültiger Präfix akzeptiert wird;
8. eine Transaction nach Crash einen unbekannten Commitstatus hinterlässt;
9. ein ursprüngliches R1- oder RR2-Finding keine exakte Test-/Evidence-Bindung besitzt;
10. BA10 Freeze oder Research Authority regressiert;
11. vollständige Research-/Product-Regression nicht grün ist;
12. Deterministic Build zweimal unterschiedliche ZIP-Hashes erzeugt;
13. ein Push History Rewrite oder fremde Änderungen erfordern würde.

Bei Stop wird ein manifestiertes Stop-Evidence-Paket erzeugt. Kein
`best effort PASS`, kein `closed_verified`, kein BA11-Go.
