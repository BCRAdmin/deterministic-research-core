#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, posixpath, stat, sys, zipfile
from pathlib import Path

EXPECTED = "a714f870b28ff5bccc44083125495a24166224f5c6d32154bf93ad9ca889e4ed"
EXPECTED_REVIEW = "e828b1bf30f60c9af86971a8e69434fc69876831610c5b21316e67edeac46639"
EXPECTED_CONTRACT = "4f7b43a32006b5a39d1726b05c6e77a7a599ee607fba87fd6fc9c3e773947424"

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def main() -> int:
    if len(sys.argv) != 2:
        print("usage: audit_source_result.py RESULT.zip", file=sys.stderr)
        return 2
    path = Path(sys.argv[1])
    raw = path.read_bytes()
    if sha(raw) != EXPECTED:
        print(json.dumps({"status":"STOP","reason":"source_hash","actual":sha(raw),"expected":EXPECTED}, indent=2))
        return 10
    with zipfile.ZipFile(path) as z:
        if z.testzip():
            return 11
        names = z.namelist()
        if len(names) != len(set(names)):
            return 12
        for name in names:
            norm = posixpath.normpath(name)
            if name.startswith("/") or norm.startswith("../"):
                return 13
        manifest = json.loads(z.read("MANIFEST.json"))
        listed = {row["path"]: row for row in manifest["files"]}
        for name in names:
            if name == "MANIFEST.json":
                continue
            data = z.read(name)
            row = listed.get(name)
            if not row or row["bytes"] != len(data) or row["sha256"] != sha(data):
                return 14
        review = z.read("authority/ROOM16_BA11_ARCHITECTURE_REVIEW_R1_REQUIRED_2026-08-19.zip")
        contract = z.read("authority/ROOM16_BA11_R1_CORRECTION_EXECUTION_CONTRACT_R2_2026-08-19.zip")
        if sha(review) != EXPECTED_REVIEW or sha(contract) != EXPECTED_CONTRACT:
            return 15
    print(json.dumps({"status":"PASS","source_sha256":EXPECTED,"entries":len(names)}, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
