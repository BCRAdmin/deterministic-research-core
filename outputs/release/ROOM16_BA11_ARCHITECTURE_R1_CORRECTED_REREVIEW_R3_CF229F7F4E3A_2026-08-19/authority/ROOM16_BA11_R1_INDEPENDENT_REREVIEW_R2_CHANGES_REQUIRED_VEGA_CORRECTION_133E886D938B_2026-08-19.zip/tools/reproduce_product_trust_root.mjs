// Run from room16-app after the reviewed Product commit.
import { createHash } from "node:crypto";
import {
  canonicalJson,
  verifyCanaryRegistryMirror,
} from "./server-modules/canary-registry-mirror.mjs";

const body = {
  contract_id: "room16.canary_registry_snapshot",
  schema_version: 1,
  authority_owner: "research",
  registry_generation: 999,
  previous_registry_sha256: null,
  ledger_head_sha256: "1".repeat(64),
  entries: [],
  product_invented_truth: "accepted because caller supplies alleged Research source",
};
const snapshot = {
  ...body,
  snapshot_sha256: createHash("sha256")
    .update(canonicalJson({
      domain: "room16.canary_registry_snapshot@1",
      payload: body,
    }))
    .digest("hex"),
};

const verdict = verifyCanaryRegistryMirror(snapshot, structuredClone(snapshot));
console.log(JSON.stringify({
  status: "VULNERABILITY_CONFIRMED",
  receipt_state: verdict.receipt_state,
  research_snapshot_sha256: verdict.research_snapshot_sha256,
}, null, 2));
