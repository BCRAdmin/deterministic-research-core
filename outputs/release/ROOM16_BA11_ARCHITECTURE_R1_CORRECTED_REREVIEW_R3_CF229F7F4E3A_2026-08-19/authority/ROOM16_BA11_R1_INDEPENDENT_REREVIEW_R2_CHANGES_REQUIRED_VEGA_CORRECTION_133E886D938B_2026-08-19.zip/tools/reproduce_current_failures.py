#!/usr/bin/env python3
"""Run against the reviewed Research repository before fixes.

Current vulnerable state: every check below prints CONFIRMED.
After remediation, convert these reproductions into negative tests that
require the corresponding operation to block.
"""
from __future__ import annotations

import inspect
from pathlib import Path
from tempfile import TemporaryDirectory

from nacl.signing import SigningKey

from research_agent.canary_governance.approval import sign_approval, verify_approval
from research_agent.canary_governance.contracts import (
    AcceptedDebtEvent,
    CanaryFreezeRecord,
    CanaryRegistryEntry,
    ChangeClassification,
    ComparisonResult,
    RegistryEvent,
    RegistrySnapshot,
)
from research_agent.canary_governance.ledger import fold_registry_events, verify_debt_ledger
from research_agent.canary_governance.storage import ContentAddressedRegistryStore

H = lambda c: c * 64

def event(seq, kind, previous):
    return RegistryEvent.create(
        event_id=f"event.{seq}",
        canary_id="canary.company.test",
        sequence=seq,
        event_type=kind,
        subject_sha256=H("1"),
        previous_event_sha256=previous,
        effective_at_utc=f"2026-08-19T00:00:{seq:02d}Z",
    )

def debt(seq, kind, previous, before, after):
    return AcceptedDebtEvent.create(
        debt_id="debt.test",
        event_id=f"debt.event.{seq}",
        sequence=seq,
        event_type=kind,
        previous_event_sha256=previous,
        finding_id="F",
        debt_type="ux.debt",
        scope="x",
        state_before=before,
        state_after=after,
        reason="x",
        evidence_refs=("e",),
        approval_receipt_sha256=H("2") if kind == "accepted" else None,
        recorded_at_utc=f"2026-08-19T00:01:{seq:02d}Z",
    )

checks = []

comparison = ComparisonResult.create(
    request_sha256=H("1"),
    verdict="ordinary_change",
    fact_diff_count=1,
    claim_diff_count=0,
    decision_diff_count=0,
    lineage_diff_count=0,
    diagnostic_codes=(),
)
classification = ChangeClassification.create(
    classification_id="change.forged",
    change_class="ordinary",
    semantic_lock_changed=False,
    presentation_contract_changed=False,
    renderer_artifact_changed=True,
    source_contract_changed=False,
    new_truth_count=0,
    lineage_diff_count=0,
    independent_compare_sha256=comparison.result_sha256,
)
checks.append(("FORGED_NO_NEW_TRUTH_ACCEPTED", comparison.fact_diff_count == 1 and bool(classification)))

key = SigningKey.generate()
receipt = sign_approval(
    {
        "approval_id": "approval.reject",
        "decision": "reject",
        "scope": "ba11_canary_promotion",
        "subject_ids": ("subject.test",),
        "subject_sha256s": (H("1"),),
        "review_finding_set_sha256": H("2"),
        "previous_registry_head_sha256": H("3"),
        "approver_key_id": "operator.primary",
        "issued_at_utc": "2026-08-19T00:00:00Z",
        "expires_at_utc": "2026-08-20T00:00:00Z",
        "nonce": "0123456789abcdef",
        "monotonic_counter": 7,
    },
    key,
)
verify_approval(
    receipt,
    trusted_keys={"operator.primary": key.verify_key},
    revoked_key_ids=set(),
    consumed_nonces=set(),
    minimum_counter=6,
    expected_scope="ba11_canary_promotion",
    expected_subject_sha256s=(H("1"),),
    now_utc="2026-08-19T12:00:00Z",
)
checks.append(("REJECT_RECEIPT_VERIFIES_AS_APPROVAL", True))
checks.append(("REVIEW_AND_HEAD_NOT_VERIFIED", True))

e0 = event(0, "genesis", None)
e1 = event(1, "candidate", e0.event_sha256)
e2 = event(2, "review_accepted", e1.event_sha256)
e3 = event(3, "operator_approved", e2.event_sha256)
e4 = event(4, "frozen", e3.event_sha256)
fold_registry_events((e0, e1, e2, e3, e4))
prefix = fold_registry_events((e0, e1, e2))
checks.append(("VALID_PREFIX_REGISTRY_ROLLBACK_ACCEPTED", prefix["canary.company.test"] == "review_accepted"))

d0 = debt(0, "opened", None, None, "opened")
d1 = debt(1, "accepted", d0.event_sha256, "opened", "accepted")
d2 = debt(2, "closed", d1.event_sha256, "accepted", "closed")
verify_debt_ledger((d0, d1, d2))
debt_prefix = verify_debt_ledger((d0, d1))
checks.append(("VALID_PREFIX_DEBT_ROLLBACK_ACCEPTED", debt_prefix["debt.test"] == "accepted"))

with TemporaryDirectory() as td:
    store = ContentAddressedRegistryStore(Path(td))
    snapshot = RegistrySnapshot.create(
        registry_generation=0,
        previous_registry_sha256=None,
        ledger_head_sha256=H("1"),
        entries=(),
    )
    raised = False
    try:
        store.commit_snapshot(
            snapshot,
            expected_head_sha256=None,
            fault=lambda step: (_ for _ in ()).throw(RuntimeError("crash"))
            if step == "after_pointer_swap"
            else None,
        )
    except RuntimeError:
        raised = True
    checks.append(("AMBIGUOUS_COMMIT_AFTER_SWAP", raised and store.read_head() is not None))

entry_fields = set(CanaryRegistryEntry.model_fields)
freeze_fields = set(CanaryFreezeRecord.model_fields)
checks.append(("FREEZE_SNAPSHOT_HASH_CYCLE", "freeze_sha256" in entry_fields and "registry_snapshot_sha256" in freeze_fields))

signature = str(inspect.signature(ContentAddressedRegistryStore.commit_snapshot))
checks.append(("TRANSACTION_APPROVAL_ARCHIVE_NOT_BOUND_TO_COMMIT", "transaction" not in signature and "approval" not in signature))

for name, confirmed in checks:
    print(f"{name}={'CONFIRMED' if confirmed else 'NOT_CONFIRMED'}")
raise SystemExit(0 if all(value for _, value in checks) else 1)
