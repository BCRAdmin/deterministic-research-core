#!/usr/bin/env python3
"""Structural fail-closed verifier for the next R3 evidence ZIP.

This is a baseline structural gate. Repository-specific semantic verifiers
and the complete test matrix remain additionally mandatory.
"""
from __future__ import annotations

import hashlib
import json
import posixpath
import sys
import zipfile
from pathlib import Path

REQUIRED = {
    "00_R3_CORRECTION_VERDICT.md",
    "01_INPUT_LOCK.json",
    "02_RR2_FINDINGS.json",
    "03_ORIGINAL_18_CLOSURE_MATRIX.json",
    "04_RR2_FINDING_CLOSURE_REGISTER.json",
    "05_CONTRACT_CATALOG.json",
    "06_IDENTITY_GRAPH.json",
    "07_APPROVAL_AND_REVIEW_TRUST_REPORT.json",
    "08_PRODUCT_AUTHORITY_ANCHOR_REPORT.json",
    "09_LEDGER_ROLLBACK_AND_REPLAY_REPORT.json",
    "10_REGISTRY_TRANSACTION_FAULT_INJECTION_REPORT.json",
    "11_DERIVED_SNAPSHOT_REPORT.json",
    "12_NO_NEW_TRUTH_REPORT.json",
    "13_TEST_MATRIX_EXECUTED.json",
    "14_FULL_REGRESSION_RECEIPTS.json",
    "15_BA10_RAW_VERIFIER_RECEIPT.json",
    "16_SOURCE_TREE_BINDINGS.json",
    "17_CHANGED_FILES_PER_FINDING.json",
    "18_DETERMINISTIC_BUILD_REPORT.json",
    "19_REREVIEW_REQUEST.md",
    "MANIFEST.json",
}

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def main() -> int:
    if len(sys.argv) != 2:
        print("usage: verify_r3_evidence.py R3.zip", file=sys.stderr)
        return 2
    path = Path(sys.argv[1])
    with zipfile.ZipFile(path) as z:
        bad = z.testzip()
        if bad:
            print(f"STOP bad member: {bad}", file=sys.stderr)
            return 10
        names = z.namelist()
        if len(names) != len(set(names)):
            return 11
        for name in names:
            if name.startswith("/") or posixpath.normpath(name).startswith("../"):
                return 12
        missing = sorted(REQUIRED - set(names))
        if missing:
            print(json.dumps({"status":"STOP","missing":missing}, indent=2))
            return 13
        manifest = json.loads(z.read("MANIFEST.json"))
        listed = {row["path"]: row for row in manifest["files"]}
        for name in names:
            if name == "MANIFEST.json":
                continue
            data = z.read(name)
            row = listed.get(name)
            if not row or row["bytes"] != len(data) or row["sha256"] != sha(data):
                return 14
        findings = json.loads(z.read("04_RR2_FINDING_CLOSURE_REGISTER.json"))
        rows = findings.get("findings", [])
        if len(rows) != 14 or any(row.get("closure_status") != "closed_verified" for row in rows):
            return 15
        for row in rows:
            for key in (
                "finding_id",
                "changed_files_with_sha256",
                "exact_executed_test_ids",
                "command_receipts",
                "evidence_refs",
                "verifier_receipt",
            ):
                if not row.get(key):
                    print(json.dumps({"status":"STOP","finding":row.get("finding_id"),"missing":key}, indent=2))
                    return 16
        matrix = json.loads(z.read("03_ORIGINAL_18_CLOSURE_MATRIX.json"))
        originals = matrix.get("findings", [])
        if len(originals) != 18 or any(row.get("status") != "CLOSED_VERIFIED" for row in originals):
            return 17
        state = json.loads(z.read("01_INPUT_LOCK.json"))
        if state.get("ba11_implementation_ready") is True:
            return 18
    print(json.dumps({"status":"STRUCTURAL_PASS","zip_sha256":sha(path.read_bytes())}, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
