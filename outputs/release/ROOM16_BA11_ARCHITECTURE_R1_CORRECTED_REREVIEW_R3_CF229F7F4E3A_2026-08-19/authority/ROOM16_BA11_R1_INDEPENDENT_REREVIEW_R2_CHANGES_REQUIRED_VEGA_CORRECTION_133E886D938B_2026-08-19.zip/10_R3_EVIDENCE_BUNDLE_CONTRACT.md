# R3 Evidence Bundle Contract

Empfohlener Name:

`ROOM16_BA11_ARCHITECTURE_R1_CORRECTED_REREVIEW_R3_<ARTIFACT_SHORT_SHA>_2026-08-19.zip`

## Pflichtinhalt

```text
00_R3_CORRECTION_VERDICT.md
01_INPUT_LOCK.json
02_RR2_FINDINGS.json
03_ORIGINAL_18_CLOSURE_MATRIX.json
04_RR2_FINDING_CLOSURE_REGISTER.json
05_CONTRACT_CATALOG.json
06_IDENTITY_GRAPH.json
07_APPROVAL_AND_REVIEW_TRUST_REPORT.json
08_PRODUCT_AUTHORITY_ANCHOR_REPORT.json
09_LEDGER_ROLLBACK_AND_REPLAY_REPORT.json
10_REGISTRY_TRANSACTION_FAULT_INJECTION_REPORT.json
11_DERIVED_SNAPSHOT_REPORT.json
12_NO_NEW_TRUTH_REPORT.json
13_TEST_MATRIX_EXECUTED.json
14_FULL_REGRESSION_RECEIPTS.json
15_BA10_RAW_VERIFIER_RECEIPT.json
16_SOURCE_TREE_BINDINGS.json
17_CHANGED_FILES_PER_FINDING.json
18_DETERMINISTIC_BUILD_REPORT.json
19_REREVIEW_REQUEST.md
MANIFEST.json
```

Zusätzlich:

- alle geänderten Contracts/Schemas/Fixtures,
- alle neuen produktiven Module,
- vollständige Git-Patches oder manifestgebundene Enddateien,
- dieses R2-Handoff bzw. dessen Manifest-Identity,
- das geprüfte R1-Ergebnis-ZIP mit SHA-256
  `a714f870b28ff5bccc44083125495a24166224f5c6d32154bf93ad9ca889e4ed`.

## Finding Closure

Für alle 14 RR2-Findings und alle 18 ursprünglichen AR-Findings:

```text
finding_id
source_finding_ids
exact_root_cause
contract_delta_ids
changed_files_with_sha256
exact_executed_test_ids
negative_fixture_ids
command_receipts
evidence_refs
verifier_derived_status
remaining_debt
```

`closed_verified` darf nur der unabhängige Bundle-Verifier setzen.

## Regression Receipt

Jede Command Receipt enthält:

```text
relative_command
relative_cwd
exit_code
git_commit
git_tree
full_worktree_status
tool_versions
complete_input_manifest_sha256
raw_stdout
raw_stdout_sha256
normalized_stdout
normalized_stdout_sha256
raw_stderr
raw_stderr_sha256
started_at_attested_utc
finished_at_attested_utc
```

## Package Identity

- Manifest self-exclusion/preimage maschinenlesbar.
- ZIP plus detached `.zip.sha256` ausliefern.
- Zwei Builds mit denselben Inputs müssen denselben ZIP-Hash erzeugen.

## Gate State

Das R3-Paket darf ausschließlich behaupten:

```text
ready_for_independent_rereview=true
ba11_implementation_ready=false
ba12_authorized=false
release_authorized=false
publication_authorized=false
```
