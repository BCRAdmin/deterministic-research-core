Problem-cases bundle is empty for Batch 002; excluded data gaps are documented in batch root-cause files.
