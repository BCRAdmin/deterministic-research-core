# Stop Conditions

Vega muss fail-closed stoppen und **keine Partial-Promotion** durchführen, wenn:

1. R1-Review-ZIP fehlt.
2. SHA-256 ≠ gepinnter Wert.
3. ZIP-Integrität fehlschlägt.
4. Findings nicht exakt 7 P0 / 8 P1 / 3 P2 / 18 total ergeben.
5. originale Finding-IDs nicht eindeutig extrahierbar sind.
6. bekannte sieben P0-Root-Causes nicht mit dem Review übereinstimmen.
7. ein Finding eine Änderung an eingefrorener Authority verlangt, die dem R1-Review widerspricht.
8. Approval-Schlüssel/Authentizitätsmechanismus nicht sicher bestimmt werden kann.
9. atomare Registry-Commit-Semantik auf der vorhandenen Storage-Abstraktion nicht fail-closed implementierbar ist.
10. vollständige Regression eine neue P0/P1-Regression zeigt.
11. Evidence-Manifest/Hashes nicht geschlossen werden können.

Bei Stop:
- keine BA11-Ready-Markierung,
- keine Baseline-Promotion,
- keine BA12-Arbeit,
- kein Release/Publicationsstatus,
- Evidence der Stop-Ursache schreiben,
- keine "best effort"-Schließung behaupten.
