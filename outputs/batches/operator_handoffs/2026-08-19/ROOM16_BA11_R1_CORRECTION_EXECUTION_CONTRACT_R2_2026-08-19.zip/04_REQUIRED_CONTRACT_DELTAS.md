# Required BA11 Contract Deltas

Diese Datei legt die Mindestarchitektur fest. Die **exakten Review-Findings bleiben führend**.
Falls ein Source-Finding strengere Anforderungen enthält, gilt die strengere Source-Anforderung.

## CD-P0-FREEZE — Freeze Consistency

Baue/normalisiere einen maschinenlesbaren Freeze Contract, der mindestens bindet:

```text
foundation_version_lock
registry_authority_sha256
semantic_wave_version_lock
compiler_artifact_bundle_contract
ba10_freeze_identity
canary_registry_snapshot_sha256
governance_contract_version
allowed_change_classes
breaking_change_requires_independent_rereview
```

Regeln:

- Kein BA11-Registry-/Baseline-Stand darf einen älteren oder abweichenden BA10/Semantic Lock tragen.
- Freeze-Identität wird aus Authority-Artefakten abgeleitet, nicht von Product gesetzt.
- Drift = fail-closed Diagnostic + keine Promotion.

Pflichttests:
`freeze_lock_drift`, `ba10_identity_relabel`, `stale_registry_snapshot`,
`semantic_lock_mismatch`.

## CD-P0-AUTHORITY — Research/Product Authority Boundary

Maschinenvertrag muss mindestens festlegen:

```text
research_authoritative_artifact_kinds
product_read_only_artifact_kinds
forbidden_product_truth_kinds
producer_identity
authority_class
source_artifact_sha256
mirror_of_sha256
```

Regeln:

- Research besitzt fachliche Truth/Canary-Baselines.
- Product darf Governance-/UI-/Delivery-Zustände erzeugen, aber keine neuen Facts, Claims,
  Decisions oder Research-Baseline-Wahrheit.
- Jeder Product-Mirror bindet byte-/hashgenau an Research Authority.
- Product-seitige Truth-Promotion = fail-closed.

Pflichttests:
`product_truth_injection`, `authority_class_promotion`, `mirror_hash_drift`,
`research_owner_relabel`.

## CD-P0-DEBT — Append-only Accepted Debt Events

Debt ist ein Event Ledger, kein mutierbarer Status-Blob.

Mindestfelder je Event:

```text
debt_id
event_id
event_type
previous_event_sha256
finding_id
scope
state_before
state_after
reason
evidence_refs
approval_receipt_sha256
recorded_at_utc
event_sha256
```

Erlaubte Eventtypen mindestens:
`opened`, `accepted`, `amended`, `superseded`, `closed`.

Regeln:

- alte Events nie überschreiben/löschen,
- Hash-Chain geschlossen,
- Current State ausschließlich aus Replay ableiten,
- Closing darf Historie nicht unsichtbar machen.

Pflichttests:
`debt_event_mutation`, `debt_event_delete`, `broken_hash_chain`,
`history_rewrite`, `close_without_prior_open`.

## CD-P0-MACHINE — Complete Machine Contracts

BA11 darf zentrale Governance nicht nur in Markdown tragen.
Mindestens maschinenlesbare Schemas/Contracts für:

```text
CanaryRegistryEntry
CanaryFreezeSnapshot
ChangeClassification
ChangeTrigger
ComparisonRequest
ComparisonResult
PromotionCandidate
PromotionDecision
OperatorApprovalReceipt
AcceptedDebtEvent
IndependentRereviewRequirement
ArchiveReceipt
RegistryTransaction
```

Jeder Vertrag braucht:
`contract_id`, `schema_version`, `authority_owner`, `canonicalization_profile`,
`hash_algorithm`, `required_fields`, `fail_closed_rules`.

Pflichttest:
Schema validation für positive Fixtures + missing/extra/wrong-type/unknown-version negative fixtures.

## CD-P0-APPROVAL — Approval Authenticity

Approval ist ein eigenes gebundenes Artefakt und darf weder aus Chattext noch Dateiexistenz
abgeleitet werden.

Mindestfelder:

```text
approval_id
decision
scope
subject_ids
subject_sha256s
review_finding_set_sha256
approver_key_id
issued_at_utc
expires_at_utc_or_null
nonce
signature_algorithm
signature
```

Bevorzugt: detached Ed25519-Signatur über kanonische Approval-Bytes.
Wenn das Repository bereits einen gleichwertigen stärkeren Approval-Mechanismus besitzt,
diesen beibehalten statt Parallelmechanismus einzuführen.

Regeln:
- Approval muss exakten Subject-Hash binden.
- Replay eines Approval auf anderen Registry-/Baseline-Stand blockieren.
- Expired/revoked/wrong-scope/wrong-key blockieren.

Pflichttests:
`approval_replay_other_subject`, `approval_scope_escalation`,
`approval_signature_tamper`, `approval_wrong_key`, `approval_expired`,
`approval_missing_subject_hash`.

## CD-P0-ATOMIC — Atomic Registry Commit

Registry-/Baseline-Promotion darf nie einen partiell sichtbaren Zustand erzeugen.

Vertrag:

```text
transaction_id
base_registry_sha256
candidate_registry_sha256
candidate_artifact_set_sha256
comparison_result_sha256
approval_receipt_sha256
debt_ledger_head_sha256
archive_receipt_sha256
transaction_state
commit_receipt_sha256
```

Commit-Protokoll:

1. candidate vollständig in temporärem/content-addressed Staging erzeugen,
2. alle Schemas, Hashes, Vergleiche, Approval und Archive-Evidence prüfen,
3. Transaction Receipt erzeugen,
4. Current Registry Pointer **einmal atomar** auf content-addressed Snapshot umschalten,
5. nach Umschaltung read-back + hash verify,
6. Fehler vor Schritt 4 => keinerlei Current-State-Änderung,
7. Fehler nach Schritt 4 => fail-closed Recovery anhand Receipt; kein Mischzustand.

Pflichttests:
fault injection an jedem Schritt, insbesondere `crash_before_pointer_swap`,
`crash_after_pointer_swap`, `partial_candidate_write`,
`stale_base_compare_and_swap`.

## CD-P0-TIME-ARCHIVE — Deterministic Time & Archive

Zeit ist ein injizierter Input für Logik; Archividentität ist content-addressed.

Mindestfelder:

```text
clock_source
effective_at_utc
recorded_at_utc
source_time_zone
archive_content_sha256
archive_contract_version
archive_member_manifest_sha256
retention_class
supersedes_archive_sha256_or_null
```

Regeln:

- produktive Zeitstempel UTC/RFC3339,
- Tests verwenden expliziten FixedClock,
- keine fachliche Entscheidung hängt von implizitem `now()` ab,
- Archive werden über Content Hash identifiziert,
- Dateiname/Zeitstempel allein ist keine Identität,
- Replay mit gleichen Inputs + gleicher Clock ergibt gleichen fachlichen Output,
- Archivmutation unter gleicher Identität blockiert.

Pflichttests:
`wall_clock_drift`, `timezone_drift`, `same_name_different_bytes`,
`archive_mutation`, `fixed_clock_replay`.

## P1/P2 Contract-Delta-Pflicht

Nach autoritativer Extraktion muss Vega **für jeden P1- und P2-Slot** ein eigenes
`contract_delta`-Objekt erzeugen:

```text
delta_id
source_finding_id
current_contract
required_change
affected_authority
affected_schemas
affected_code
affected_docs
migration_or_backfill
negative_fixtures
positive_tests
regression_tests
evidence_outputs
```

Kein P1/P2 darf mit einem Sammelpunkt "misc hardening" geschlossen werden.
