# Vega Execution Runbook

## Phase A — Input Lock

```text
A1 hash review ZIP
A2 zip integrity
A3 inventory members
A4 extract exact findings
A5 build authoritative_findings.json
A6 assert 7/8/3/18
A7 bind each finding to source member hash + locator
```

Keine Codeänderung vor A6/A7 PASS.

## Phase B — Per-Finding Plan Materialization

Für P0-01..P0-07, P1-01..P1-08, P2-01..P2-03:

1. originale ID/Titel/Text übernehmen,
2. Root Cause klassifizieren,
3. Current Contract bestimmen,
4. exakten Contract Delta definieren,
5. betroffene Dateien/Schemas nennen,
6. positive Tests definieren,
7. negative/adversariale Fixture definieren, sofern anwendbar,
8. Regression Coverage definieren,
9. Evidence Output definieren.

Schreibe `.runtime/ba11_r1/correction_plan.json`.
Der Plan ist machine-readable und vollständig; kein Operator-Zwischen-Go nötig, sofern kein Stop eintritt.

## Phase C — Implementierung

Reihenfolge:

1. Freeze / Authority,
2. Machine Contracts,
3. Debt Ledger,
4. Approval Authenticity,
5. Atomic Registry Transaction,
6. Deterministic Time / Archive,
7. verbleibende P1,
8. verbleibende P2,
9. Docs/Runbook nur als Derivate der Contracts.

Arbeite Root-Cause-first. Keine kosmetischen Einzelpatches.

## Phase D — Verification

1. Schema conformance.
2. Positive tests.
3. Vollständig re-gehashte negative/adversariale Fixtures.
4. Fault injection Registry Transaction.
5. Debt replay/hash-chain.
6. FixedClock/archive replay.
7. Approval tamper/replay tests.
8. Authority boundary injection tests.
9. Full existing relevant suite unskipped.
10. Finding coverage verifier: 18/18.

## Phase E — Evidence Build

Erzeuge den Vertrag aus `06_EVIDENCE_AND_REREVIEW_BUNDLE.md`.
Manifest zuletzt aus den finalen Bytes bauen.
Keine stale Reports kopieren.

## Phase F — Final State

Erlaubt:

```text
correction_candidate = ready_for_independent_rereview
next_gate = corrected_ba11_architecture_r1_and_independent_rereview
```

Nicht erlaubt:

```text
ba11_implementation_ready = true
ba12_authorized = true
release_authorized = true
publication_authorized = true
```

## Git

Der Auftrag autorisiert lokale Änderungen für den Korrekturblock.
Commit/Push nur, wenn die lokale Room16-Operator-/Repository-Policy dies für diesen
ausdrücklich als EXECUTE markierten Handoff bereits erlaubt. Fehlt diese Policy-Evidence,
ändere/verifiziere lokal und liefere Evidence, aber führe **keinen Push** aus.
Kein Force Push, kein Rebase fremder Arbeit.
