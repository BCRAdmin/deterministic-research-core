#!/usr/bin/env python3
from pathlib import Path
import sys, hashlib, json, zipfile

EXPECTED_REVIEW = "e828b1bf30f60c9af86971a8e69434fc69876831610c5b21316e67edeac46639"

def h(p):
    x=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): x.update(b)
    return x.hexdigest()

def main():
    if len(sys.argv)!=2:
        print("usage: verify_handoff_and_input.py REVIEW.zip", file=sys.stderr); return 2
    p=Path(sys.argv[1])
    actual=h(p)
    if actual!=EXPECTED_REVIEW:
        print(json.dumps({"status":"STOP","reason":"review_hash_mismatch","actual":actual,"expected":EXPECTED_REVIEW},indent=2)); return 10
    try:
        with zipfile.ZipFile(p) as z:
            bad=z.testzip()
            members=[i.filename for i in z.infolist()]
    except Exception as e:
        print(json.dumps({"status":"STOP","reason":"zip_error","error":str(e)},indent=2)); return 11
    if bad:
        print(json.dumps({"status":"STOP","reason":"bad_zip_member","member":bad},indent=2)); return 12
    print(json.dumps({"status":"PASS","review_sha256":actual,"member_count":len(members)},indent=2))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
