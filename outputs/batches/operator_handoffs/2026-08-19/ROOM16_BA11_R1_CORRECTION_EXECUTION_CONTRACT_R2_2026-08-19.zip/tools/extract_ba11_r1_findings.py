#!/usr/bin/env python3
"""
Fail-closed extractor for the authoritative BA11 Architecture Review R1 ZIP.

It does NOT invent finding IDs. It scans JSON/JSONL/Markdown/text members,
collects explicit finding-like records/headings/table rows, and requires the
expected 7/8/3 count before emitting an authoritative register.
"""
from __future__ import annotations
import sys, json, zipfile, hashlib, re
from pathlib import Path

EXPECTED_SHA = "e828b1bf30f60c9af86971a8e69434fc69876831610c5b21316e67edeac46639"
EXPECTED = {"P0": 7, "P1": 8, "P2": 3}
TEXT_EXTS = {".md",".txt",".json",".jsonl",".yaml",".yml",".tsv",".csv"}

ID_RE = re.compile(r"\b(BA11[-_A-Z0-9.]*?(?:P0|P1|P2)[-_A-Z0-9.]*)\b", re.I)
GENERIC_ID_RE = re.compile(r"\b([A-Z0-9][A-Z0-9._-]{3,80})\b")
PRIO_RE = re.compile(r"\b(P0|P1|P2)\b", re.I)

def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def walk_json(obj, path="$"):
    if isinstance(obj, dict):
        yield path, obj
        for k,v in obj.items():
            yield from walk_json(v, f"{path}.{k}")
    elif isinstance(obj, list):
        for i,v in enumerate(obj):
            yield from walk_json(v, f"{path}[{i}]")

def record_from_dict(d, member, member_sha, locator):
    keys = {str(k).lower(): k for k in d}
    id_key = next((keys[k] for k in ["finding_id","id","findingid"] if k in keys), None)
    sev_key = next((keys[k] for k in ["priority","severity","prio"] if k in keys), None)
    title_key = next((keys[k] for k in ["title","titel","name","summary"] if k in keys), None)
    if id_key is None or sev_key is None:
        return None
    fid = str(d[id_key]).strip()
    sev_raw = str(d[sev_key]).upper()
    m = PRIO_RE.search(sev_raw)
    if not m:
        # accept explicit high/medium/low only when ID itself contains P0/P1/P2
        m = PRIO_RE.search(fid.upper())
    if not m:
        return None
    prio = m.group(1).upper()
    title = str(d.get(title_key, "")).strip() if title_key else ""
    return {
        "finding_id": fid,
        "priority": prio,
        "title": title,
        "source_member": member,
        "source_member_sha256": member_sha,
        "source_locator": locator,
        "source_object": d
    }

def scan_markdown(text, member, member_sha):
    out=[]
    lines=text.splitlines()
    for idx,line in enumerate(lines, start=1):
        # Table rows with explicit P0/P1/P2 and a stable ID-like token.
        if "|" in line and PRIO_RE.search(line):
            cells=[c.strip() for c in line.strip().strip("|").split("|")]
            pr = next((PRIO_RE.fullmatch(c.upper()).group(1).upper()
                       for c in cells if PRIO_RE.fullmatch(c.upper())), None)
            if pr:
                # Prefer BA11-ish IDs, then a token containing the priority.
                fid=None
                for c in cells:
                    if c.upper().startswith("BA11") and re.fullmatch(r"[A-Za-z0-9._-]+", c):
                        fid=c; break
                if not fid:
                    for c in cells:
                        if pr in c.upper() and re.fullmatch(r"[A-Za-z0-9._-]+", c) and len(c) >= 5:
                            fid=c; break
                if fid:
                    title = cells[-1] if cells[-1] != fid else ""
                    out.append({
                        "finding_id": fid, "priority": pr, "title": title,
                        "source_member": member, "source_member_sha256": member_sha,
                        "source_locator": f"line:{idx}", "source_exact_line": line
                    })
        # Headings such as "### BA11-... — P0 — title"
        if line.lstrip().startswith("#"):
            pm=PRIO_RE.search(line)
            if pm:
                im=ID_RE.search(line)
                if im:
                    out.append({
                        "finding_id": im.group(1), "priority": pm.group(1).upper(),
                        "title": line.lstrip("# ").strip(),
                        "source_member": member, "source_member_sha256": member_sha,
                        "source_locator": f"line:{idx}", "source_exact_line": line
                    })
    return out

def main():
    if len(sys.argv) != 3:
        print("usage: extract_ba11_r1_findings.py REVIEW.zip OUT.json", file=sys.stderr)
        return 2
    src=Path(sys.argv[1]); outp=Path(sys.argv[2])
    raw=src.read_bytes()
    actual=sha256_bytes(raw)
    if actual != EXPECTED_SHA:
        print(f"STOP hash mismatch: {actual}", file=sys.stderr); return 10
    candidates=[]
    with zipfile.ZipFile(src) as z:
        bad=z.testzip()
        if bad:
            print(f"STOP bad zip member: {bad}", file=sys.stderr); return 11
        for zi in z.infolist():
            if zi.is_dir(): continue
            ext=Path(zi.filename).suffix.lower()
            if ext not in TEXT_EXTS: continue
            b=z.read(zi.filename)
            msha=sha256_bytes(b)
            text=b.decode("utf-8", errors="replace")
            if ext in {".json",".jsonl"}:
                objs=[]
                if ext==".json":
                    try: objs=[json.loads(text)]
                    except Exception: objs=[]
                else:
                    for n,line in enumerate(text.splitlines(),1):
                        try: objs.append(json.loads(line))
                        except Exception: pass
                for obj in objs:
                    for loc,d in walk_json(obj):
                        if isinstance(d,dict):
                            rec=record_from_dict(d,zi.filename,msha,loc)
                            if rec: candidates.append(rec)
            candidates.extend(scan_markdown(text,zi.filename,msha))
    # Deduplicate by original finding id, prefer richer record.
    dedup={}
    for r in candidates:
        fid=r["finding_id"]
        score=len(json.dumps(r,ensure_ascii=False))
        if fid not in dedup or score > dedup[fid][0]:
            dedup[fid]=(score,r)
    recs=[v[1] for v in dedup.values()]
    recs.sort(key=lambda r: ({"P0":0,"P1":1,"P2":2}[r["priority"]],
                             r["source_member"], r["source_locator"], r["finding_id"]))
    counts={k:sum(1 for r in recs if r["priority"]==k) for k in EXPECTED}
    if counts != EXPECTED or len(recs)!=18:
        debug=outp.with_suffix(".candidates.json")
        debug.parent.mkdir(parents=True,exist_ok=True)
        debug.write_text(json.dumps({"actual_sha256":actual,"counts":counts,"candidates":recs},
                                    indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
        print(f"STOP finding count mismatch: {counts}, total={len(recs)}; candidates={debug}", file=sys.stderr)
        return 12
    payload={
        "contract_id":"room16.ba11_r1.authoritative_findings@1",
        "authority_zip_sha256":actual,
        "counts":{**counts,"total":18},
        "findings":recs
    }
    outp.parent.mkdir(parents=True,exist_ok=True)
    outp.write_text(json.dumps(payload,indent=2,ensure_ascii=False,sort_keys=True)+"\n",encoding="utf-8")
    print(outp)
    return 0

if __name__=="__main__":
    raise SystemExit(main())
