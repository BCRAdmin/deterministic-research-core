# Manifest Policy

Dieses Handoff verwendet eine nicht-zirkuläre Manifestregel:

- `MANIFEST.json` bindet alle Payload-Dateien **außer** `MANIFEST.json` und `SHA256SUMS.txt`.
- `SHA256SUMS.txt` bindet alle Dateien **außer sich selbst**, also auch `MANIFEST.json`.
- ZIP-Entry-Reihenfolge ist lexikographisch.
- ZIP-Zeitstempel sind fest.
- Regular file mode 0644.
- Keine Duplikate.
- Input-Authority wird zusätzlich über `01_INPUT_LOCK.json` gepinnt.

Der spätere Vega-Evidence-Build soll dieselbe oder eine strengere explizite
Self-Reference-Policy verwenden.
