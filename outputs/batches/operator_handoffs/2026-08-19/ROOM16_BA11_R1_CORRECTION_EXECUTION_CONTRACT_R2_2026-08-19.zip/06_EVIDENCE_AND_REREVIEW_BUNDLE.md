# Evidence / Independent Rereview Bundle Contract

Vega erzeugt am Ende ein selbsttragendes Paket, empfohlen:

`ROOM16_BA11_ARCHITECTURE_R1_CORRECTED_REREVIEW_<SHORTSHA>_2026-08-19.zip`

## Pflichtinhalt

```text
00_CORRECTION_VERDICT.md
01_AUTHORITY_INPUT_LOCK.json
02_AUTHORITATIVE_FINDINGS.json
03_FINDING_CLOSURE_REGISTER.json
04_CONTRACT_DELTAS.json
05_TEST_MATRIX_EXECUTED.json
06_FULL_REGRESSION_REPORT.json
07_NEGATIVE_FIXTURE_REPORT.json
08_SCHEMA_CONFORMANCE_REPORT.json
09_AUTHORITY_BOUNDARY_REPORT.json
10_APPROVAL_AUTHENTICITY_REPORT.json
11_REGISTRY_ATOMICITY_FAULT_INJECTION_REPORT.json
12_DEBT_LEDGER_REPLAY_REPORT.json
13_TIME_ARCHIVE_REPLAY_REPORT.json
14_CHANGED_FILES.json
15_GIT_DIFF_SUMMARY.txt
16_SOURCE_STATE.json
17_REREVIEW_REQUEST.md
MANIFEST.json
```

Zusätzlich alle neuen/änderten maschinenlesbaren Contracts/Schemas/Fixtures oder deren
manifestgebundene Kopien, wenn ein unabhängiger Reviewer sie sonst nicht prüfen kann.

## Finding Closure Register

Für **alle 18**:

```text
source_finding_id
priority
source_exact_title
source_member
source_member_sha256
source_locator
root_cause
contract_delta_ids[]
changed_files[]
test_ids[]
negative_fixture_ids[]
evidence_refs[]
closure_status
closure_rationale
remaining_debt
```

Erlaubter finaler `closure_status` für Gate-Vorbereitung:
`closed_verified`.

`accepted_debt` zählt **nicht** als geschlossen, außer das ursprüngliche R1-Finding
erlaubt dies ausdrücklich und die Debt-Akzeptanz besitzt ein authentisches Approval-Artefakt.

## Full Regression

- keine bewusst übersprungenen Tests, die BA11/BA10 Governance berühren,
- Exit Codes erfassen,
- Commands erfassen,
- Commit/Worktree-State erfassen,
- Source/Input Hashes erfassen,
- Reports selbst hashen.

## Rereview Request

Der Rereview-Auftrag muss eng sein:

1. Prüfe exakt die 18 R1-Findings auf Closure.
2. Prüfe Regression der eingefrorenen BA10-/Research-Authority-Grenzen.
3. Prüfe keine BA12-Features.
4. Ergebnis nur:
   - `ACCEPTED`, oder
   - `CHANGES_REQUIRED`.
5. Erst `ACCEPTED` darf BA11 Implementation Readiness wieder öffnen.

## Keine Status-Eskalation durch Vega

Im Korrekturpaket bleiben zwingend:

```text
ba11_implementation_ready=false
ba12_authorized=false
release_authorized=false
publication_authorized=false
```
