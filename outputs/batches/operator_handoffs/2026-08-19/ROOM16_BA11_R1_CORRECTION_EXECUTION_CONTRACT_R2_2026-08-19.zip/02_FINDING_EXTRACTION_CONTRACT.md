# Authoritative Finding Extraction Contract

Der Handoff darf die fehlenden P1/P2-Bezeichnungen **nicht erfinden**.
Die einzige normative Wahrheit ist das R1-Review-ZIP mit dem in `01_INPUT_LOCK.json`
gepinnten SHA-256.

## Pflichtablauf vor der ersten Codeänderung

1. SHA-256 des Review-ZIPs bilden.
2. Exakt mit `e828b1bf30f60c9af86971a8e69434fc69876831610c5b21316e67edeac46639` vergleichen.
3. ZIP-Integrität prüfen.
4. Alle textuellen JSON/JSONL/MD/TXT/YAML/TSV/CSV-Inhalte scannen.
5. Finding-Objekte/-Tabellen/-Headings extrahieren.
6. Deduplizieren ausschließlich über die **originale Finding-ID**.
7. Exakte Source-Formulierung erhalten; nicht paraphrasieren.
8. Severity/priority normalisieren auf P0/P1/P2, ohne die Quelle zu überschreiben.
9. Ergebnis nach `.runtime/ba11_r1/authoritative_findings.json` schreiben.
10. Zwingend prüfen:
   - 7 P0
   - 8 P1
   - 3 P2
   - 18 total
   - jede ID eindeutig
   - jede Finding-ID besitzt Source-Datei + Source-SHA + Locator/Zeile/JSON-Pointer soweit bestimmbar.

## Individuelle Findings

Die 18 Einzelpunkte werden **source-ordinal** gebunden, damit auch ohne erfundene IDs ein
vollständiger Vertrag vorliegt:

```text
P0-01 ... P0-07  -> die sieben P0-Findings in stabiler Source-Reihenfolge
P1-01 ... P1-08  -> die acht P1-Findings in stabiler Source-Reihenfolge
P2-01 ... P2-03  -> die drei P2-Findings in stabiler Source-Reihenfolge
```

Jeder Slot MUSS nach Extraktion die originale Review-Finding-ID enthalten.
Ein Slot ohne originale ID ist ein harter STOP.

## Bekannte P0-Root-Cause-Bindung

Die sieben P0-Slots müssen inhaltlich die bereits bestätigten Root Causes abdecken:

- Freeze-Konsistenz,
- Research/Product-Authority,
- append-only Debt-Events,
- fehlende Maschinenverträge,
- Approval-Authentizität,
- atomare Registry-Commits,
- deterministische Zeit-/Archivregeln.

Wenn die extrahierten sieben P0-Findings nicht genau diese Root-Cause-Menge abdecken:
**STOP / SOURCE_CONFLICT**.

## Kein "nur P0"-Abschluss

P1-01 ... P1-08 und P2-01 ... P2-03 sind ebenso verpflichtende
Korrekturpunkte dieses Blocks. Ein Paket mit offenen P1/P2 darf den
Korrektur-Gate nicht als bestanden markieren.
