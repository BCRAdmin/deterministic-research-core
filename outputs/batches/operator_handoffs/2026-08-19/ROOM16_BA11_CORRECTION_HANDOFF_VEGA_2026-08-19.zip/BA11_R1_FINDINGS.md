# BA11 Architecture Review R1 Findings

P0:
- Freeze consistency
- Research/Product authority separation
- Append-only debt events
- Missing machine contracts
- Approval authenticity
- Atomic registry commits
- Deterministic time/archive rules

P1:
- Address after P0 closure.

P2:
- Address after architecture stability.

Acceptance:
All findings require evidence, not only code changes.
