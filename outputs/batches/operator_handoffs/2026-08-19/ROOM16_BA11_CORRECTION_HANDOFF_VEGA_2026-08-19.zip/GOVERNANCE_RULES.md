# Governance Rules

Truth hierarchy:
1. Approved evidence artifacts
2. Frozen contracts
3. Registry state
4. Consumer renderings

No consumer may become an authority source.

All approvals must be traceable:
- identity
- version
- timestamp
- artifact reference
- decision state

All debt events are append-only.
