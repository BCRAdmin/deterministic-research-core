# Vega Execution Order

Phase 1 - Freeze and Authority Repair
1. Restore freeze consistency between BA10, RFC-0005 and BA11 contracts.
2. Establish Research Authority vs Product Authority boundaries.
3. Ensure Consumer layer remains read-only.

Phase 2 - Contract Hardening
4. Add append-only debt event model.
5. Complete machine-readable contracts.
6. Harden approval authenticity.
7. Make registry commits atomic.
8. Define deterministic time and archive rules.

Phase 3 - Verification
- Run full verification suite.
- Produce evidence bundle.
- Prepare independent rereview package.

Forbidden:
- No BA12 work.
- No release.
- No publication.
- No silent schema changes.
