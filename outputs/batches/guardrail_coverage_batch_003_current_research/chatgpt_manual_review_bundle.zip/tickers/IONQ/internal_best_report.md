# IONQ Research Report
## Executive Summary
IONQ has revenue TTM of $132.8M, so the business discussion should focus on company-specific growth, margin quality and source-quality drivers rather than generic scale language. Revenue scale alone does not prove attractive returns or valuation discipline. Use revenue evidence as context, not as a standalone buy signal.

FCF TTM is $-233.3M, making cash conversion a direct rating input for IONQ. FCF may be company-defined or period-sensitive and can require reconciliation review. FCF quality supports the thesis only if no data-quality check blocks the report.

The resulting stance is Hold: the report weighs current fundamentals against valuation, cash-flow conversion and timing risk. Technically, IONQ carries an RSI of 58.58 with price at 51.95, so timing remains part of the rating debate.

## Investment Thesis
IONQ enters the report at a frozen close of 51.95 with a Hold stance; the action should reflect company-specific growth, margin quality and source-quality drivers, valuation discipline and the current technical setup. The action language should stay consistent with the Hold stance.

## Current Period KPIs
IONQ has revenue TTM of $132.8M, so the business discussion should focus on company-specific growth, margin quality and source-quality drivers rather than generic scale language. Revenue scale alone does not prove attractive returns or valuation discipline. Use revenue evidence as context, not as a standalone buy signal.

FCF TTM is $-233.3M, making cash conversion a direct rating input for IONQ. FCF may be company-defined or period-sensitive and can require reconciliation review. FCF quality supports the thesis only if no data-quality check blocks the report.

SBC/Revenue is 146.2%, which should be interpreted through sector-specific quality and valuation context rather than a one-size-fits-all compensation lens. Sector and lifecycle matter, but persistent dilution can still reduce equity quality. Treat SBC as a risk modifier rather than an automatic rating override.

The bull case is that validated growth and cash-flow quality combines with revenue of $132.8M to support the allowed upside rating path when cash conversion quality also holds. Strong scale does not resolve valuation or reconciliation anomalies. Bullish language should remain bounded by the evidence-backed action plan.

The bear case is that source concerns, valuation risk or technical weakness overwhelms reported FCF quality and leaves the stock vulnerable if SBC/Revenue at 146.2% or source concerns persist. further review remains appropriate when financial-data-quality checks fire.

## Fundamental Analysis
IONQ has revenue TTM of $132.8M, so the business discussion should focus on company-specific growth, margin quality and source-quality drivers rather than generic scale language. Revenue scale alone does not prove attractive returns or valuation discipline. Use revenue evidence as context, not as a standalone buy signal.

FCF TTM is $-233.3M, making cash conversion a direct rating input for IONQ. FCF may be company-defined or period-sensitive and can require reconciliation review. FCF quality supports the thesis only if no data-quality check blocks the report.

SBC/Revenue is 146.2%, which should be interpreted through sector-specific quality and valuation context rather than a one-size-fits-all compensation lens. Sector and lifecycle matter, but persistent dilution can still reduce equity quality. Treat SBC as a risk modifier rather than an automatic rating override.

Balance-sheet flexibility is anchored in net cash of $1.70B and debt evidence, which affects how much downside tolerance the action plan can carry. A stronger liquidity position can widen the acceptable holding corridor.

## Valuation / Risk-Reward
Valuation is framed by EV/Sales of 132.41x; this directly limits how aggressive the Hold stance should be. Reported valuation can still be blocked by data-quality checks when source reconciliation is suspect. Do not upgrade rating solely from valuation language if review shows financial data concerns.

For IONQ, P/FCF is not available in evidence set and should be read against validated growth, cash-flow and risk context; missing or extreme cash-flow multiples should reduce conviction rather than invite a stronger rating. The rating should stay conservative when multiples are expensive, missing or flagged.

## Scenario / Sensitivity
| Scenario | KPI trigger | Valuation implication | Rating implication |
|---|---|---|---|
| Bull | Current-period KPIs improve while free-cash-flow conversion holds | The current multiple becomes easier to defend | Move more constructive |
| Base | Fundamentals remain intact but valuation and timing stay balanced | Current risk/reward supports discipline | Keep the current stance |
| Bear | Growth, margins, cash conversion or technical trend weakens | Multiple support deteriorates | Reduce risk / downgrade |

## Technical Setup
The technical setup uses close 51.95, 50-SMA 38.98, 200-SMA 46.98 and RSI 58.58, creating timing risk if price cannot reclaim trend support. Timing language should follow the technical trend state.

IONQ's close of 51.95 and moving-average position imply constructive momentum but still requires valuation and risk discipline, so entries should be staged, delayed or trimmed according to business evidence and risk/reward. Technical weakness can be temporary if fundamentals and catalysts improve. Use staged entries or trims when technical and fundamental signals diverge.

## Bull Case
The bull case is that validated growth and cash-flow quality combines with revenue of $132.8M to support the allowed upside rating path when cash conversion quality also holds. Strong scale does not resolve valuation or reconciliation anomalies. Bullish language should remain bounded by the evidence-backed action plan.

A constructive technical bull path for IONQ requires confirmation beyond the current RSI of 58.58 and moving-average setup. Add or accumulate language should require confirmation when the preferred rating is not Buy.

## Bear Case
The bear case is that source concerns, valuation risk or technical weakness overwhelms reported FCF quality and leaves the stock vulnerable if SBC/Revenue at 146.2% or source concerns persist. further review remains appropriate when financial-data-quality checks fire.

Valuation risk for IONQ is a discipline constraint; expensive or missing EV/Sales and P/FCF context should not be translated into a blocked rating. Avoid full-exit language when the evidence supports only trim or hold actions.

## Risks
Data quality is part of the IONQ research view; any unresolved data issue should override a superficially complete report. unresolved data issues should keep the report in further review.

Source disagreement or current-period mismatch can reduce conviction for IONQ, especially where revenue $132.8M is a key valuation denominator. Source limitations belong in the final action plan.

## Catalysts
Catalysts for IONQ at the latest close of 51.95 should be limited to confirmed evidence; missing earnings or forward company data should be stated as unavailable rather than converted into event-risk claims. If earnings are unavailable, the report should state that limitation rather than inventing timing.

Trigger language should use evidence-backed levels such as 50-SMA 38.98 and 200-SMA 46.98, not unvalidated price targets. Use confirmation language instead of hard price targets unless risk/reward levels are validated.

## Final Rating & Action Plan
Final Rating: Hold. The central debate is whether IONQ's current business momentum can overcome valuation and timing constraints.

Why this rating? Revenue of $132.8M and FCF of $-233.3M support the base case, but EV/Sales of 132.41x, P/FCF of not available and RSI of 58.58 argue against chasing the stock.

Why not more bullish? A more constructive stance needs either a better entry point, stronger cash-flow conversion after investment needs, or clearer technical confirmation.

Why not more bearish? The evidence still supports a functioning business with defensible cash generation; the rating is about position discipline, not a rejection of the company.

Action plan for existing holders: maintain exposure if it fits the target allocation, but avoid adding solely on momentum.

Action plan for new capital: wait for better risk/reward, a technical reset, or evidence that current-period KPIs are converting into durable free cash flow.

Upgrade/downgrade triggers: improve the stance if fundamentals accelerate with cleaner FCF conversion; cut risk if source quality deteriorates, valuation expands further, or the technical setup breaks down.

## Evidence Appendix
| Claim | Evidence IDs | Source Type | Confidence |
|---|---|---|---|
| IONQ enters the report at a frozen close of 51.95 with a Hold stance; the action should reflect company-specific growth, margin quality and source-quality drivers, valuation discipline and the current technical setup. | IONQ_YAHOO_CHART_PRICE_CSV_CLOSE, IONQ_YAHOO_CHART_PRICE_CSV_OHLCV, IONQ_YAHOO_CHART_PRICE_CSV_PRICE, IONQ_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, IONQ_YAHOO_CHART_PRICE_CSV_PRICE_DATA, IONQ_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | high |
| IONQ has revenue TTM of $132.8M, so the business discussion should focus on company-specific growth, margin quality and source-quality drivers rather than generic scale language. | IONQ_SEC_COMPANYFACTS_1824920_REVENUE, IONQ_SEC_COMPANYFACTS_1824920_REVENUE_TTM, IONQ_SEC_COMPANYFACTS_1824920_SALES, IONQ_SEC_COMPANYFACTS_1824920_UMSATZ, IONQ_SEC_revenue_FY2025_FY_0001193125-26-071562, IONQ_SEC_revenue_FY2025_Q2_0000950170-25-104066, IONQ_SEC_revenue_FY2025_Q3_0001193125-25-266942, IONQ_SEC_revenue_FY2026_Q1_0001193125-26-211876 | sec_filing | high |
| FCF TTM is $-233.3M, making cash conversion a direct rating input for IONQ. | IONQ_SEC_COMPANYFACTS_1824920_CASHFLOW, IONQ_SEC_COMPANYFACTS_1824920_FCF, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASH_FLOW, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASH_FLOW_TTM, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASHFLOW, IONQ_SEC_DERIVED_FREE_CASH_FLOW_TTM | sec_filing | high |
| SBC/Revenue is 146.2%, which should be interpreted through sector-specific quality and valuation context rather than a one-size-fits-all compensation lens. | IONQ_SEC_COMPANYFACTS_1824920_SBC_TO_REVENUE, IONQ_SEC_DERIVED_SBC_TO_REVENUE | sec_filing | medium |
| Balance-sheet flexibility is anchored in net cash of $1.70B and debt evidence, which affects how much downside tolerance the action plan can carry. | IONQ_SEC_COMPANYFACTS_1824920_CASH, IONQ_SEC_COMPANYFACTS_1824920_CASH_AND_EQUIVALENTS, IONQ_SEC_COMPANYFACTS_1824920_CASH_AND_INVESTMENTS, IONQ_SEC_COMPANYFACTS_1824920_NET_CASH, IONQ_SEC_cash_and_equivalents_FY2025_FY_0001193125-26-071562, IONQ_SEC_cash_and_equivalents_FY2026_Q1_0001193125-26-211876, IONQ_SEC_COMPANYFACTS_1824920_DEBT, IONQ_SEC_COMPANYFACTS_1824920_NET_DEBT, IONQ_SEC_COMPANYFACTS_1824920_TOTAL_DEBT | sec_filing | medium |
| Valuation is framed by EV/Sales of 132.41x; this directly limits how aggressive the Hold stance should be. | IONQ_SEC_COMPANYFACTS_1824920_REVENUE, IONQ_SEC_COMPANYFACTS_1824920_REVENUE_TTM, IONQ_SEC_COMPANYFACTS_1824920_SALES, IONQ_SEC_COMPANYFACTS_1824920_UMSATZ, IONQ_SEC_revenue_FY2025_FY_0001193125-26-071562, IONQ_SEC_revenue_FY2025_Q2_0000950170-25-104066, IONQ_SEC_revenue_FY2025_Q3_0001193125-25-266942, IONQ_SEC_revenue_FY2026_Q1_0001193125-26-211876, IONQ_SEC_COMPANYFACTS_1824920_CASHFLOW, IONQ_SEC_COMPANYFACTS_1824920_FCF, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASH_FLOW, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASH_FLOW_TTM, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASHFLOW, IONQ_SEC_DERIVED_FREE_CASH_FLOW_TTM, IONQ_YAHOO_CHART_PRICE_CSV_CLOSE, IONQ_YAHOO_CHART_PRICE_CSV_OHLCV, IONQ_YAHOO_CHART_PRICE_CSV_PRICE, IONQ_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, IONQ_YAHOO_CHART_PRICE_CSV_PRICE_DATA, IONQ_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv, sec_filing | medium |
| For IONQ, P/FCF is not available in evidence set and should be read against validated growth, cash-flow and risk context; missing or extreme cash-flow multiples should reduce conviction rather than invite a stronger rating. | IONQ_SEC_COMPANYFACTS_1824920_CASHFLOW, IONQ_SEC_COMPANYFACTS_1824920_FCF, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASH_FLOW, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASH_FLOW_TTM, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASHFLOW, IONQ_SEC_DERIVED_FREE_CASH_FLOW_TTM, IONQ_SEC_COMPANYFACTS_1824920_REVENUE, IONQ_SEC_COMPANYFACTS_1824920_REVENUE_TTM, IONQ_SEC_COMPANYFACTS_1824920_SALES, IONQ_SEC_COMPANYFACTS_1824920_UMSATZ, IONQ_SEC_revenue_FY2025_FY_0001193125-26-071562, IONQ_SEC_revenue_FY2025_Q2_0000950170-25-104066, IONQ_SEC_revenue_FY2025_Q3_0001193125-25-266942, IONQ_SEC_revenue_FY2026_Q1_0001193125-26-211876 | sec_filing | medium |
| The technical setup uses close 51.95, 50-SMA 38.98, 200-SMA 46.98 and RSI 58.58, creating timing risk if price cannot reclaim trend support. | IONQ_YAHOO_CHART_PRICE_CSV_TECHNICAL_INDICATORS, IONQ_YAHOO_CHART_PRICE_CSV_CLOSE, IONQ_YAHOO_CHART_PRICE_CSV_OHLCV, IONQ_YAHOO_CHART_PRICE_CSV_PRICE, IONQ_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, IONQ_YAHOO_CHART_PRICE_CSV_PRICE_DATA, IONQ_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | high |
| IONQ's close of 51.95 and moving-average position imply constructive momentum but still requires valuation and risk discipline, so entries should be staged, delayed or trimmed according to business evidence and risk/reward. | IONQ_YAHOO_CHART_PRICE_CSV_TECHNICAL_INDICATORS, IONQ_YAHOO_CHART_PRICE_CSV_CLOSE, IONQ_YAHOO_CHART_PRICE_CSV_OHLCV, IONQ_YAHOO_CHART_PRICE_CSV_PRICE, IONQ_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, IONQ_YAHOO_CHART_PRICE_CSV_PRICE_DATA, IONQ_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | medium |
| The bull case is that validated growth and cash-flow quality combines with revenue of $132.8M to support the allowed upside rating path when cash conversion quality also holds. | IONQ_SEC_COMPANYFACTS_1824920_REVENUE, IONQ_SEC_COMPANYFACTS_1824920_REVENUE_TTM, IONQ_SEC_COMPANYFACTS_1824920_SALES, IONQ_SEC_COMPANYFACTS_1824920_UMSATZ, IONQ_SEC_revenue_FY2025_FY_0001193125-26-071562, IONQ_SEC_revenue_FY2025_Q2_0000950170-25-104066, IONQ_SEC_revenue_FY2025_Q3_0001193125-25-266942, IONQ_SEC_revenue_FY2026_Q1_0001193125-26-211876, IONQ_SEC_COMPANYFACTS_1824920_CASHFLOW, IONQ_SEC_COMPANYFACTS_1824920_FCF, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASH_FLOW, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASH_FLOW_TTM, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASHFLOW, IONQ_SEC_DERIVED_FREE_CASH_FLOW_TTM | sec_filing | medium |
| A constructive technical bull path for IONQ requires confirmation beyond the current RSI of 58.58 and moving-average setup. | IONQ_YAHOO_CHART_PRICE_CSV_TECHNICAL_INDICATORS, IONQ_YAHOO_CHART_PRICE_CSV_CLOSE, IONQ_YAHOO_CHART_PRICE_CSV_OHLCV, IONQ_YAHOO_CHART_PRICE_CSV_PRICE, IONQ_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, IONQ_YAHOO_CHART_PRICE_CSV_PRICE_DATA, IONQ_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | medium |
| The bear case is that source concerns, valuation risk or technical weakness overwhelms reported FCF quality and leaves the stock vulnerable if SBC/Revenue at 146.2% or source concerns persist. | IONQ_SEC_COMPANYFACTS_1824920_CASHFLOW, IONQ_SEC_COMPANYFACTS_1824920_FCF, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASH_FLOW, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASH_FLOW_TTM, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASHFLOW, IONQ_SEC_DERIVED_FREE_CASH_FLOW_TTM, IONQ_SEC_COMPANYFACTS_1824920_SBC_TO_REVENUE, IONQ_SEC_DERIVED_SBC_TO_REVENUE | sec_filing | medium |
| Valuation risk for IONQ is a discipline constraint; expensive or missing EV/Sales and P/FCF context should not be translated into a blocked rating. | IONQ_SEC_COMPANYFACTS_1824920_REVENUE, IONQ_SEC_COMPANYFACTS_1824920_REVENUE_TTM, IONQ_SEC_COMPANYFACTS_1824920_SALES, IONQ_SEC_COMPANYFACTS_1824920_UMSATZ, IONQ_SEC_revenue_FY2025_FY_0001193125-26-071562, IONQ_SEC_revenue_FY2025_Q2_0000950170-25-104066, IONQ_SEC_revenue_FY2025_Q3_0001193125-25-266942, IONQ_SEC_revenue_FY2026_Q1_0001193125-26-211876, IONQ_SEC_COMPANYFACTS_1824920_CASHFLOW, IONQ_SEC_COMPANYFACTS_1824920_FCF, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASH_FLOW, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASH_FLOW_TTM, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASHFLOW, IONQ_SEC_DERIVED_FREE_CASH_FLOW_TTM | sec_filing | medium |
| Data quality is part of the IONQ research view; any unresolved data issue should override a superficially complete report. | IONQ_YAHOO_CHART_PRICE_CSV_CLOSE, IONQ_YAHOO_CHART_PRICE_CSV_OHLCV, IONQ_YAHOO_CHART_PRICE_CSV_PRICE, IONQ_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, IONQ_YAHOO_CHART_PRICE_CSV_PRICE_DATA, IONQ_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | high |
| Source disagreement or current-period mismatch can reduce conviction for IONQ, especially where revenue $132.8M is a key valuation denominator. | IONQ_SEC_COMPANYFACTS_1824920_REVENUE, IONQ_SEC_COMPANYFACTS_1824920_REVENUE_TTM, IONQ_SEC_COMPANYFACTS_1824920_SALES, IONQ_SEC_COMPANYFACTS_1824920_UMSATZ, IONQ_SEC_revenue_FY2025_FY_0001193125-26-071562, IONQ_SEC_revenue_FY2025_Q2_0000950170-25-104066, IONQ_SEC_revenue_FY2025_Q3_0001193125-25-266942, IONQ_SEC_revenue_FY2026_Q1_0001193125-26-211876, IONQ_SEC_COMPANYFACTS_1824920_CASHFLOW, IONQ_SEC_COMPANYFACTS_1824920_FCF, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASH_FLOW, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASH_FLOW_TTM, IONQ_SEC_COMPANYFACTS_1824920_FREE_CASHFLOW, IONQ_SEC_DERIVED_FREE_CASH_FLOW_TTM | sec_filing | medium |
| Catalysts for IONQ at the latest close of 51.95 should be limited to confirmed evidence; missing earnings or forward company data should be stated as unavailable rather than converted into event-risk claims. | IONQ_YAHOO_CHART_PRICE_CSV_CLOSE, IONQ_YAHOO_CHART_PRICE_CSV_OHLCV, IONQ_YAHOO_CHART_PRICE_CSV_PRICE, IONQ_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, IONQ_YAHOO_CHART_PRICE_CSV_PRICE_DATA, IONQ_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | high |
| Trigger language should use evidence-backed levels such as 50-SMA 38.98 and 200-SMA 46.98, not unvalidated price targets. | IONQ_YAHOO_CHART_PRICE_CSV_TECHNICAL_INDICATORS, IONQ_YAHOO_CHART_PRICE_CSV_CLOSE, IONQ_YAHOO_CHART_PRICE_CSV_OHLCV, IONQ_YAHOO_CHART_PRICE_CSV_PRICE, IONQ_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, IONQ_YAHOO_CHART_PRICE_CSV_PRICE_DATA, IONQ_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | medium |
| We rate IONQ Hold at the latest close of 51.95 because company-specific growth, margin quality and source-quality drivers supports the base case, while valuation and technical risk limit the case for a more bullish rating. | IONQ_YAHOO_CHART_PRICE_CSV_CLOSE, IONQ_YAHOO_CHART_PRICE_CSV_OHLCV, IONQ_YAHOO_CHART_PRICE_CSV_PRICE, IONQ_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, IONQ_YAHOO_CHART_PRICE_CSV_PRICE_DATA, IONQ_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | high |
