# LCID Research Report
## Executive Summary
LCID has revenue TTM of $1.11B, so the business discussion should focus on company-specific growth, margin quality and source-quality drivers rather than generic scale language. Revenue scale alone does not prove attractive returns or valuation discipline. Use revenue evidence as context, not as a standalone buy signal.

FCF TTM is $-3.79B, making cash conversion a direct rating input for LCID. FCF may be company-defined or period-sensitive and can require reconciliation review. FCF quality supports the thesis only if no data-quality check blocks the report.

The resulting stance is Underweight: the report weighs current fundamentals against valuation, cash-flow conversion and timing risk. Technically, LCID carries an RSI of 37.43 with price at 6.04, so timing remains part of the rating debate.

## Investment Thesis
LCID enters the report at a frozen close of 6.04 with a Underweight stance; the action should reflect company-specific growth, margin quality and source-quality drivers, valuation discipline and the current technical setup. The action language should stay consistent with the Underweight stance.

## Current Period KPIs
LCID has revenue TTM of $1.11B, so the business discussion should focus on company-specific growth, margin quality and source-quality drivers rather than generic scale language. Revenue scale alone does not prove attractive returns or valuation discipline. Use revenue evidence as context, not as a standalone buy signal.

FCF TTM is $-3.79B, making cash conversion a direct rating input for LCID. FCF may be company-defined or period-sensitive and can require reconciliation review. FCF quality supports the thesis only if no data-quality check blocks the report.

SBC/Revenue is 18.5%, which should be interpreted through sector-specific quality and valuation context rather than a one-size-fits-all compensation lens. Sector and lifecycle matter, but persistent dilution can still reduce equity quality. Treat SBC as a risk modifier rather than an automatic rating override.

The bull case is that validated growth and cash-flow quality combines with revenue of $1.11B to support the allowed upside rating path when cash conversion quality also holds. Strong scale does not resolve valuation or reconciliation anomalies. Bullish language should remain bounded by the evidence-backed action plan.

The bear case is that source concerns, valuation risk or technical weakness overwhelms reported FCF quality and leaves the stock vulnerable if SBC/Revenue at 18.5% or source concerns persist. further review remains appropriate when financial-data-quality checks fire.

## Fundamental Analysis
LCID has revenue TTM of $1.11B, so the business discussion should focus on company-specific growth, margin quality and source-quality drivers rather than generic scale language. Revenue scale alone does not prove attractive returns or valuation discipline. Use revenue evidence as context, not as a standalone buy signal.

FCF TTM is $-3.79B, making cash conversion a direct rating input for LCID. FCF may be company-defined or period-sensitive and can require reconciliation review. FCF quality supports the thesis only if no data-quality check blocks the report.

SBC/Revenue is 18.5%, which should be interpreted through sector-specific quality and valuation context rather than a one-size-fits-all compensation lens. Sector and lifecycle matter, but persistent dilution can still reduce equity quality. Treat SBC as a risk modifier rather than an automatic rating override.

Balance-sheet flexibility is anchored in net cash of $1.86B and debt evidence, which affects how much downside tolerance the action plan can carry. A stronger liquidity position can widen the acceptable holding corridor.

## Valuation / Risk-Reward
Valuation is framed by EV/Sales of 0.11x; this directly limits how aggressive the Underweight stance should be. Reported valuation can still be blocked by data-quality checks when source reconciliation is suspect. Do not upgrade rating solely from valuation language if review shows financial data concerns.

For LCID, P/FCF is not available in evidence set and should be read against validated growth, cash-flow and risk context; missing or extreme cash-flow multiples should reduce conviction rather than invite a stronger rating. The rating should stay conservative when multiples are expensive, missing or flagged.

## Scenario / Sensitivity
| Scenario | KPI trigger | Valuation implication | Rating implication |
|---|---|---|---|
| Bull | Current-period KPIs improve while free-cash-flow conversion holds | The current multiple becomes easier to defend | Move more constructive |
| Base | Fundamentals remain intact but valuation and timing stay balanced | Current risk/reward supports discipline | Keep the current stance |
| Bear | Growth, margins, cash conversion or technical trend weakens | Multiple support deteriorates | Reduce risk / downgrade |

## Technical Setup
The technical setup uses close 6.04, 50-SMA 8.24, 200-SMA 14.00 and RSI 37.43, creating timing risk if price cannot reclaim trend support. Timing language should follow the technical trend state.

LCID's close of 6.04 and moving-average position imply a damaged trend that requires confirmation before adding exposure, so entries should be staged, delayed or trimmed according to business evidence and risk/reward. Technical weakness can be temporary if fundamentals and catalysts improve. Use staged entries or trims when technical and fundamental signals diverge.

## Bull Case
The bull case is that validated growth and cash-flow quality combines with revenue of $1.11B to support the allowed upside rating path when cash conversion quality also holds. Strong scale does not resolve valuation or reconciliation anomalies. Bullish language should remain bounded by the evidence-backed action plan.

A constructive technical bull path for LCID requires confirmation beyond the current RSI of 37.43 and moving-average setup. Add or accumulate language should require confirmation when the preferred rating is not Buy.

## Bear Case
The bear case is that source concerns, valuation risk or technical weakness overwhelms reported FCF quality and leaves the stock vulnerable if SBC/Revenue at 18.5% or source concerns persist. further review remains appropriate when financial-data-quality checks fire.

Valuation risk for LCID is a discipline constraint; expensive or missing EV/Sales and P/FCF context should not be translated into a blocked rating. Avoid full-exit language when the evidence supports only trim or hold actions.

## Risks
Data quality is part of the LCID research view; any unresolved data issue should override a superficially complete report. unresolved data issues should keep the report in further review.

Source disagreement or current-period mismatch can reduce conviction for LCID, especially where revenue $1.11B is a key valuation denominator. Source limitations belong in the final action plan.

## Catalysts
Catalysts for LCID at the latest close of 6.04 should be limited to confirmed evidence; missing earnings or forward company data should be stated as unavailable rather than converted into event-risk claims. If earnings are unavailable, the report should state that limitation rather than inventing timing.

Trigger language should use evidence-backed levels such as 50-SMA 8.24 and 200-SMA 14.00, not unvalidated price targets. Use confirmation language instead of hard price targets unless risk/reward levels are validated.

## Final Rating & Action Plan
Final Rating: Underweight. The central debate is whether LCID's current business momentum can overcome valuation and timing constraints.

Why this rating? Revenue of $1.11B and FCF of $-3.79B support the base case, but EV/Sales of 0.11x, P/FCF of not available and RSI of 37.43 argue against chasing the stock.

Why not more bullish? A more constructive stance needs either a better entry point, stronger cash-flow conversion after investment needs, or clearer technical confirmation.

Why not more bearish? The evidence still supports a functioning business with defensible cash generation; the rating is about position discipline, not a rejection of the company.

Action plan for existing holders: maintain exposure if it fits the target allocation, but avoid adding solely on momentum.

Action plan for new capital: wait for better risk/reward, a technical reset, or evidence that current-period KPIs are converting into durable free cash flow.

Upgrade/downgrade triggers: improve the stance if fundamentals accelerate with cleaner FCF conversion; cut risk if source quality deteriorates, valuation expands further, or the technical setup breaks down.

## Evidence Appendix
| Claim | Evidence IDs | Source Type | Confidence |
|---|---|---|---|
| LCID enters the report at a frozen close of 6.04 with a Underweight stance; the action should reflect company-specific growth, margin quality and source-quality drivers, valuation discipline and the current technical setup. | LCID_YAHOO_CHART_PRICE_CSV_CLOSE, LCID_YAHOO_CHART_PRICE_CSV_OHLCV, LCID_YAHOO_CHART_PRICE_CSV_PRICE, LCID_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, LCID_YAHOO_CHART_PRICE_CSV_PRICE_DATA, LCID_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | high |
| LCID has revenue TTM of $1.11B, so the business discussion should focus on company-specific growth, margin quality and source-quality drivers rather than generic scale language. | LCID_SEC_COMPANYFACTS_1811210_REVENUE, LCID_SEC_COMPANYFACTS_1811210_REVENUE_TTM, LCID_SEC_COMPANYFACTS_1811210_SALES, LCID_SEC_COMPANYFACTS_1811210_UMSATZ, LCID_SEC_revenue_FY2025_FY_0001628280-26-011053, LCID_SEC_revenue_FY2025_Q2_0001811210-25-000007, LCID_SEC_revenue_FY2025_Q3_0001628280-25-049571, LCID_SEC_revenue_FY2026_Q1_0001628280-26-030517 | sec_filing | high |
| FCF TTM is $-3.79B, making cash conversion a direct rating input for LCID. | LCID_SEC_COMPANYFACTS_1811210_CASHFLOW, LCID_SEC_COMPANYFACTS_1811210_FCF, LCID_SEC_COMPANYFACTS_1811210_FREE_CASH_FLOW, LCID_SEC_COMPANYFACTS_1811210_FREE_CASH_FLOW_TTM, LCID_SEC_COMPANYFACTS_1811210_FREE_CASHFLOW, LCID_SEC_DERIVED_FREE_CASH_FLOW_TTM | sec_filing | high |
| SBC/Revenue is 18.5%, which should be interpreted through sector-specific quality and valuation context rather than a one-size-fits-all compensation lens. | LCID_SEC_COMPANYFACTS_1811210_SBC_TO_REVENUE, LCID_SEC_DERIVED_SBC_TO_REVENUE | sec_filing | medium |
| Balance-sheet flexibility is anchored in net cash of $1.86B and debt evidence, which affects how much downside tolerance the action plan can carry. | LCID_SEC_COMPANYFACTS_1811210_CASH, LCID_SEC_COMPANYFACTS_1811210_CASH_AND_EQUIVALENTS, LCID_SEC_COMPANYFACTS_1811210_CASH_AND_INVESTMENTS, LCID_SEC_COMPANYFACTS_1811210_NET_CASH, LCID_SEC_cash_and_equivalents_FY2025_FY_0001628280-26-011053, LCID_SEC_cash_and_equivalents_FY2026_Q1_0001628280-26-030517, LCID_SEC_COMPANYFACTS_1811210_DEBT, LCID_SEC_COMPANYFACTS_1811210_NET_DEBT, LCID_SEC_COMPANYFACTS_1811210_TOTAL_DEBT | sec_filing | medium |
| Valuation is framed by EV/Sales of 0.11x; this directly limits how aggressive the Underweight stance should be. | LCID_SEC_COMPANYFACTS_1811210_REVENUE, LCID_SEC_COMPANYFACTS_1811210_REVENUE_TTM, LCID_SEC_COMPANYFACTS_1811210_SALES, LCID_SEC_COMPANYFACTS_1811210_UMSATZ, LCID_SEC_revenue_FY2025_FY_0001628280-26-011053, LCID_SEC_revenue_FY2025_Q2_0001811210-25-000007, LCID_SEC_revenue_FY2025_Q3_0001628280-25-049571, LCID_SEC_revenue_FY2026_Q1_0001628280-26-030517, LCID_SEC_COMPANYFACTS_1811210_CASHFLOW, LCID_SEC_COMPANYFACTS_1811210_FCF, LCID_SEC_COMPANYFACTS_1811210_FREE_CASH_FLOW, LCID_SEC_COMPANYFACTS_1811210_FREE_CASH_FLOW_TTM, LCID_SEC_COMPANYFACTS_1811210_FREE_CASHFLOW, LCID_SEC_DERIVED_FREE_CASH_FLOW_TTM, LCID_YAHOO_CHART_PRICE_CSV_CLOSE, LCID_YAHOO_CHART_PRICE_CSV_OHLCV, LCID_YAHOO_CHART_PRICE_CSV_PRICE, LCID_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, LCID_YAHOO_CHART_PRICE_CSV_PRICE_DATA, LCID_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv, sec_filing | medium |
| For LCID, P/FCF is not available in evidence set and should be read against validated growth, cash-flow and risk context; missing or extreme cash-flow multiples should reduce conviction rather than invite a stronger rating. | LCID_SEC_COMPANYFACTS_1811210_CASHFLOW, LCID_SEC_COMPANYFACTS_1811210_FCF, LCID_SEC_COMPANYFACTS_1811210_FREE_CASH_FLOW, LCID_SEC_COMPANYFACTS_1811210_FREE_CASH_FLOW_TTM, LCID_SEC_COMPANYFACTS_1811210_FREE_CASHFLOW, LCID_SEC_DERIVED_FREE_CASH_FLOW_TTM, LCID_SEC_COMPANYFACTS_1811210_REVENUE, LCID_SEC_COMPANYFACTS_1811210_REVENUE_TTM, LCID_SEC_COMPANYFACTS_1811210_SALES, LCID_SEC_COMPANYFACTS_1811210_UMSATZ, LCID_SEC_revenue_FY2025_FY_0001628280-26-011053, LCID_SEC_revenue_FY2025_Q2_0001811210-25-000007, LCID_SEC_revenue_FY2025_Q3_0001628280-25-049571, LCID_SEC_revenue_FY2026_Q1_0001628280-26-030517 | sec_filing | medium |
| The technical setup uses close 6.04, 50-SMA 8.24, 200-SMA 14.00 and RSI 37.43, creating timing risk if price cannot reclaim trend support. | LCID_YAHOO_CHART_PRICE_CSV_TECHNICAL_INDICATORS, LCID_YAHOO_CHART_PRICE_CSV_CLOSE, LCID_YAHOO_CHART_PRICE_CSV_OHLCV, LCID_YAHOO_CHART_PRICE_CSV_PRICE, LCID_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, LCID_YAHOO_CHART_PRICE_CSV_PRICE_DATA, LCID_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | high |
| LCID's close of 6.04 and moving-average position imply a damaged trend that requires confirmation before adding exposure, so entries should be staged, delayed or trimmed according to business evidence and risk/reward. | LCID_YAHOO_CHART_PRICE_CSV_TECHNICAL_INDICATORS, LCID_YAHOO_CHART_PRICE_CSV_CLOSE, LCID_YAHOO_CHART_PRICE_CSV_OHLCV, LCID_YAHOO_CHART_PRICE_CSV_PRICE, LCID_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, LCID_YAHOO_CHART_PRICE_CSV_PRICE_DATA, LCID_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | medium |
| The bull case is that validated growth and cash-flow quality combines with revenue of $1.11B to support the allowed upside rating path when cash conversion quality also holds. | LCID_SEC_COMPANYFACTS_1811210_REVENUE, LCID_SEC_COMPANYFACTS_1811210_REVENUE_TTM, LCID_SEC_COMPANYFACTS_1811210_SALES, LCID_SEC_COMPANYFACTS_1811210_UMSATZ, LCID_SEC_revenue_FY2025_FY_0001628280-26-011053, LCID_SEC_revenue_FY2025_Q2_0001811210-25-000007, LCID_SEC_revenue_FY2025_Q3_0001628280-25-049571, LCID_SEC_revenue_FY2026_Q1_0001628280-26-030517, LCID_SEC_COMPANYFACTS_1811210_CASHFLOW, LCID_SEC_COMPANYFACTS_1811210_FCF, LCID_SEC_COMPANYFACTS_1811210_FREE_CASH_FLOW, LCID_SEC_COMPANYFACTS_1811210_FREE_CASH_FLOW_TTM, LCID_SEC_COMPANYFACTS_1811210_FREE_CASHFLOW, LCID_SEC_DERIVED_FREE_CASH_FLOW_TTM | sec_filing | medium |
| A constructive technical bull path for LCID requires confirmation beyond the current RSI of 37.43 and moving-average setup. | LCID_YAHOO_CHART_PRICE_CSV_TECHNICAL_INDICATORS, LCID_YAHOO_CHART_PRICE_CSV_CLOSE, LCID_YAHOO_CHART_PRICE_CSV_OHLCV, LCID_YAHOO_CHART_PRICE_CSV_PRICE, LCID_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, LCID_YAHOO_CHART_PRICE_CSV_PRICE_DATA, LCID_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | medium |
| The bear case is that source concerns, valuation risk or technical weakness overwhelms reported FCF quality and leaves the stock vulnerable if SBC/Revenue at 18.5% or source concerns persist. | LCID_SEC_COMPANYFACTS_1811210_CASHFLOW, LCID_SEC_COMPANYFACTS_1811210_FCF, LCID_SEC_COMPANYFACTS_1811210_FREE_CASH_FLOW, LCID_SEC_COMPANYFACTS_1811210_FREE_CASH_FLOW_TTM, LCID_SEC_COMPANYFACTS_1811210_FREE_CASHFLOW, LCID_SEC_DERIVED_FREE_CASH_FLOW_TTM, LCID_SEC_COMPANYFACTS_1811210_SBC_TO_REVENUE, LCID_SEC_DERIVED_SBC_TO_REVENUE | sec_filing | medium |
| Valuation risk for LCID is a discipline constraint; expensive or missing EV/Sales and P/FCF context should not be translated into a blocked rating. | LCID_SEC_COMPANYFACTS_1811210_REVENUE, LCID_SEC_COMPANYFACTS_1811210_REVENUE_TTM, LCID_SEC_COMPANYFACTS_1811210_SALES, LCID_SEC_COMPANYFACTS_1811210_UMSATZ, LCID_SEC_revenue_FY2025_FY_0001628280-26-011053, LCID_SEC_revenue_FY2025_Q2_0001811210-25-000007, LCID_SEC_revenue_FY2025_Q3_0001628280-25-049571, LCID_SEC_revenue_FY2026_Q1_0001628280-26-030517, LCID_SEC_COMPANYFACTS_1811210_CASHFLOW, LCID_SEC_COMPANYFACTS_1811210_FCF, LCID_SEC_COMPANYFACTS_1811210_FREE_CASH_FLOW, LCID_SEC_COMPANYFACTS_1811210_FREE_CASH_FLOW_TTM, LCID_SEC_COMPANYFACTS_1811210_FREE_CASHFLOW, LCID_SEC_DERIVED_FREE_CASH_FLOW_TTM | sec_filing | medium |
| Data quality is part of the LCID research view; any unresolved data issue should override a superficially complete report. | LCID_YAHOO_CHART_PRICE_CSV_CLOSE, LCID_YAHOO_CHART_PRICE_CSV_OHLCV, LCID_YAHOO_CHART_PRICE_CSV_PRICE, LCID_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, LCID_YAHOO_CHART_PRICE_CSV_PRICE_DATA, LCID_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | high |
| Source disagreement or current-period mismatch can reduce conviction for LCID, especially where revenue $1.11B is a key valuation denominator. | LCID_SEC_COMPANYFACTS_1811210_REVENUE, LCID_SEC_COMPANYFACTS_1811210_REVENUE_TTM, LCID_SEC_COMPANYFACTS_1811210_SALES, LCID_SEC_COMPANYFACTS_1811210_UMSATZ, LCID_SEC_revenue_FY2025_FY_0001628280-26-011053, LCID_SEC_revenue_FY2025_Q2_0001811210-25-000007, LCID_SEC_revenue_FY2025_Q3_0001628280-25-049571, LCID_SEC_revenue_FY2026_Q1_0001628280-26-030517, LCID_SEC_COMPANYFACTS_1811210_CASHFLOW, LCID_SEC_COMPANYFACTS_1811210_FCF, LCID_SEC_COMPANYFACTS_1811210_FREE_CASH_FLOW, LCID_SEC_COMPANYFACTS_1811210_FREE_CASH_FLOW_TTM, LCID_SEC_COMPANYFACTS_1811210_FREE_CASHFLOW, LCID_SEC_DERIVED_FREE_CASH_FLOW_TTM | sec_filing | medium |
| Catalysts for LCID at the latest close of 6.04 should be limited to confirmed evidence; missing earnings or forward company data should be stated as unavailable rather than converted into event-risk claims. | LCID_YAHOO_CHART_PRICE_CSV_CLOSE, LCID_YAHOO_CHART_PRICE_CSV_OHLCV, LCID_YAHOO_CHART_PRICE_CSV_PRICE, LCID_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, LCID_YAHOO_CHART_PRICE_CSV_PRICE_DATA, LCID_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | high |
| Trigger language should use evidence-backed levels such as 50-SMA 8.24 and 200-SMA 14.00, not unvalidated price targets. | LCID_YAHOO_CHART_PRICE_CSV_TECHNICAL_INDICATORS, LCID_YAHOO_CHART_PRICE_CSV_CLOSE, LCID_YAHOO_CHART_PRICE_CSV_OHLCV, LCID_YAHOO_CHART_PRICE_CSV_PRICE, LCID_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, LCID_YAHOO_CHART_PRICE_CSV_PRICE_DATA, LCID_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | medium |
| We rate LCID Underweight at the latest close of 6.04 because company-specific growth, margin quality and source-quality drivers supports the base case, while valuation and technical risk limit the case for a more bullish rating. | LCID_YAHOO_CHART_PRICE_CSV_CLOSE, LCID_YAHOO_CHART_PRICE_CSV_OHLCV, LCID_YAHOO_CHART_PRICE_CSV_PRICE, LCID_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, LCID_YAHOO_CHART_PRICE_CSV_PRICE_DATA, LCID_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | high |
