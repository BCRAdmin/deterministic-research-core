# Evidence Report - RKLB

## Hard Metrics

| Metric | Value | Period | Basis | Source Type | Source ID | Evidence ID | Confidence | Status |
|---|---:|---|---|---|---|---|---|---|
| revenue_ttm | 622,495,000.00 | n/a | company-defined | company_ir | RKLB_IR_CURRENT_PERIOD_FIXTURE | RKLB_IR_CURRENT_PERIOD_FIXTURE_REVENUE_TTM | high | OK |
| free_cash_flow_ttm | -220,123,000.00 | n/a | company-defined | company_ir | RKLB_IR_CURRENT_PERIOD_FIXTURE | RKLB_IR_CURRENT_PERIOD_FIXTURE_FREE_CASH_FLOW_TTM | high | OK |
| sbc_to_revenue | 12.0% | n/a | GAAP | sec_filing | RKLB_SEC_COMPANYFACTS_1819994 | RKLB_SEC_COMPANYFACTS_1819994_SBC_TO_REVENUE | high | OK |

## Warnings

- No evidence warnings.
