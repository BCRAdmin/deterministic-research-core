# RGTI Research Report
## Executive Summary
RGTI has revenue TTM of $9.2M, so the business discussion should focus on company-specific growth, margin quality and source-quality drivers rather than generic scale language. Revenue scale alone does not prove attractive returns or valuation discipline. Use revenue evidence as context, not as a standalone buy signal.

FCF TTM is $-75.8M, making cash conversion a direct rating input for RGTI. FCF may be company-defined or period-sensitive and can require reconciliation review. FCF quality supports the thesis only if no data-quality check blocks the report.

The resulting stance is Underweight: the report weighs current fundamentals against valuation, cash-flow conversion and timing risk. Technically, RGTI carries an RSI of 50.00 with price at 17.85, so timing remains part of the rating debate.

## Investment Thesis
RGTI enters the report at a frozen close of 17.85 with a Underweight stance; the action should reflect company-specific growth, margin quality and source-quality drivers, valuation discipline and the current technical setup. The action language should stay consistent with the Underweight stance.

## Current Period KPIs
RGTI has revenue TTM of $9.2M, so the business discussion should focus on company-specific growth, margin quality and source-quality drivers rather than generic scale language. Revenue scale alone does not prove attractive returns or valuation discipline. Use revenue evidence as context, not as a standalone buy signal.

FCF TTM is $-75.8M, making cash conversion a direct rating input for RGTI. FCF may be company-defined or period-sensitive and can require reconciliation review. FCF quality supports the thesis only if no data-quality check blocks the report.

SBC/Revenue is 159.7%, which should be interpreted through sector-specific quality and valuation context rather than a one-size-fits-all compensation lens. Sector and lifecycle matter, but persistent dilution can still reduce equity quality. Treat SBC as a risk modifier rather than an automatic rating override.

The bull case is that validated growth and cash-flow quality combines with revenue of $9.2M to support the allowed upside rating path when cash conversion quality also holds. Strong scale does not resolve valuation or reconciliation anomalies. Bullish language should remain bounded by the evidence-backed action plan.

The bear case is that source concerns, valuation risk or technical weakness overwhelms reported FCF quality and leaves the stock vulnerable if SBC/Revenue at 159.7% or source concerns persist. further review remains appropriate when financial-data-quality checks fire.

## Fundamental Analysis
RGTI has revenue TTM of $9.2M, so the business discussion should focus on company-specific growth, margin quality and source-quality drivers rather than generic scale language. Revenue scale alone does not prove attractive returns or valuation discipline. Use revenue evidence as context, not as a standalone buy signal.

FCF TTM is $-75.8M, making cash conversion a direct rating input for RGTI. FCF may be company-defined or period-sensitive and can require reconciliation review. FCF quality supports the thesis only if no data-quality check blocks the report.

SBC/Revenue is 159.7%, which should be interpreted through sector-specific quality and valuation context rather than a one-size-fits-all compensation lens. Sector and lifecycle matter, but persistent dilution can still reduce equity quality. Treat SBC as a risk modifier rather than an automatic rating override.

Balance-sheet flexibility is anchored in net cash of $131.9M and debt evidence, which affects how much downside tolerance the action plan can carry. A stronger liquidity position can widen the acceptable holding corridor.

## Valuation / Risk-Reward
Valuation is framed by EV/Sales of 633.52x; this directly limits how aggressive the Underweight stance should be. Reported valuation can still be blocked by data-quality checks when source reconciliation is suspect. Do not upgrade rating solely from valuation language if review shows financial data concerns.

For RGTI, P/FCF is not available in evidence set and should be read against validated growth, cash-flow and risk context; missing or extreme cash-flow multiples should reduce conviction rather than invite a stronger rating. The rating should stay conservative when multiples are expensive, missing or flagged.

## Scenario / Sensitivity
| Scenario | KPI trigger | Valuation implication | Rating implication |
|---|---|---|---|
| Bull | Current-period KPIs improve while free-cash-flow conversion holds | The current multiple becomes easier to defend | Move more constructive |
| Base | Fundamentals remain intact but valuation and timing stay balanced | Current risk/reward supports discipline | Keep the current stance |
| Bear | Growth, margins, cash conversion or technical trend weakens | Multiple support deteriorates | Reduce risk / downgrade |

## Technical Setup
The technical setup uses close 17.85, 50-SMA 16.65, 200-SMA 23.01 and RSI 50.00, creating timing risk if price cannot reclaim trend support. Timing language should follow the technical trend state.

RGTI's close of 17.85 and moving-average position imply a damaged trend that requires confirmation before adding exposure, so entries should be staged, delayed or trimmed according to business evidence and risk/reward. Technical weakness can be temporary if fundamentals and catalysts improve. Use staged entries or trims when technical and fundamental signals diverge.

## Bull Case
The bull case is that validated growth and cash-flow quality combines with revenue of $9.2M to support the allowed upside rating path when cash conversion quality also holds. Strong scale does not resolve valuation or reconciliation anomalies. Bullish language should remain bounded by the evidence-backed action plan.

A constructive technical bull path for RGTI requires confirmation beyond the current RSI of 50.00 and moving-average setup. Add or accumulate language should require confirmation when the preferred rating is not Buy.

## Bear Case
The bear case is that source concerns, valuation risk or technical weakness overwhelms reported FCF quality and leaves the stock vulnerable if SBC/Revenue at 159.7% or source concerns persist. further review remains appropriate when financial-data-quality checks fire.

Valuation risk for RGTI is a discipline constraint; expensive or missing EV/Sales and P/FCF context should not be translated into a blocked rating. Avoid full-exit language when the evidence supports only trim or hold actions.

## Risks
Data quality is part of the RGTI research view; any unresolved data issue should override a superficially complete report. unresolved data issues should keep the report in further review.

Source disagreement or current-period mismatch can reduce conviction for RGTI, especially where revenue $9.2M is a key valuation denominator. Source limitations belong in the final action plan.

## Catalysts
Catalysts for RGTI at the latest close of 17.85 should be limited to confirmed evidence; missing earnings or forward company data should be stated as unavailable rather than converted into event-risk claims. If earnings are unavailable, the report should state that limitation rather than inventing timing.

Trigger language should use evidence-backed levels such as 50-SMA 16.65 and 200-SMA 23.01, not unvalidated price targets. Use confirmation language instead of hard price targets unless risk/reward levels are validated.

## Final Rating & Action Plan
Final Rating: Underweight. The central debate is whether RGTI's current business momentum can overcome valuation and timing constraints.

Why this rating? Revenue of $9.2M and FCF of $-75.8M support the base case, but EV/Sales of 633.52x, P/FCF of not available and RSI of 50.00 argue against chasing the stock.

Why not more bullish? A more constructive stance needs either a better entry point, stronger cash-flow conversion after investment needs, or clearer technical confirmation.

Why not more bearish? The evidence still supports a functioning business with defensible cash generation; the rating is about position discipline, not a rejection of the company.

Action plan for existing holders: maintain exposure if it fits the target allocation, but avoid adding solely on momentum.

Action plan for new capital: wait for better risk/reward, a technical reset, or evidence that current-period KPIs are converting into durable free cash flow.

Upgrade/downgrade triggers: improve the stance if fundamentals accelerate with cleaner FCF conversion; cut risk if source quality deteriorates, valuation expands further, or the technical setup breaks down.

## Evidence Appendix
| Claim | Evidence IDs | Source Type | Confidence |
|---|---|---|---|
| RGTI enters the report at a frozen close of 17.85 with a Underweight stance; the action should reflect company-specific growth, margin quality and source-quality drivers, valuation discipline and the current technical setup. | RGTI_YAHOO_CHART_PRICE_CSV_CLOSE, RGTI_YAHOO_CHART_PRICE_CSV_OHLCV, RGTI_YAHOO_CHART_PRICE_CSV_PRICE, RGTI_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, RGTI_YAHOO_CHART_PRICE_CSV_PRICE_DATA, RGTI_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | high |
| RGTI has revenue TTM of $9.2M, so the business discussion should focus on company-specific growth, margin quality and source-quality drivers rather than generic scale language. | RGTI_SEC_COMPANYFACTS_1838359_REVENUE, RGTI_SEC_COMPANYFACTS_1838359_REVENUE_TTM, RGTI_SEC_COMPANYFACTS_1838359_SALES, RGTI_SEC_COMPANYFACTS_1838359_UMSATZ, RGTI_SEC_revenue_FY2022_FY_0001193125-23-080486, RGTI_SEC_revenue_FY2022_Q2_0001193125-22-218918, RGTI_SEC_revenue_FY2022_Q3_0001193125-22-290115, RGTI_SEC_revenue_FY2023_Q1_0001193125-23-142055 | sec_filing | high |
| FCF TTM is $-75.8M, making cash conversion a direct rating input for RGTI. | RGTI_SEC_COMPANYFACTS_1838359_CASHFLOW, RGTI_SEC_COMPANYFACTS_1838359_FCF, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASH_FLOW, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASH_FLOW_TTM, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASHFLOW, RGTI_SEC_DERIVED_FREE_CASH_FLOW_TTM | sec_filing | high |
| SBC/Revenue is 159.7%, which should be interpreted through sector-specific quality and valuation context rather than a one-size-fits-all compensation lens. | RGTI_SEC_COMPANYFACTS_1838359_SBC_TO_REVENUE, RGTI_SEC_DERIVED_SBC_TO_REVENUE | sec_filing | medium |
| Balance-sheet flexibility is anchored in net cash of $131.9M and debt evidence, which affects how much downside tolerance the action plan can carry. | RGTI_SEC_COMPANYFACTS_1838359_CASH, RGTI_SEC_COMPANYFACTS_1838359_CASH_AND_EQUIVALENTS, RGTI_SEC_COMPANYFACTS_1838359_CASH_AND_INVESTMENTS, RGTI_SEC_COMPANYFACTS_1838359_NET_CASH, RGTI_SEC_cash_and_equivalents_FY2025_FY_0001104659-26-023454, RGTI_SEC_cash_and_equivalents_FY2025_Q2_0001558370-25-011224, RGTI_SEC_cash_and_equivalents_FY2025_Q3_0001104659-25-109141, RGTI_SEC_cash_and_equivalents_FY2026_Q1_0001104659-26-058641, RGTI_SEC_COMPANYFACTS_1838359_DEBT, RGTI_SEC_COMPANYFACTS_1838359_NET_DEBT, RGTI_SEC_COMPANYFACTS_1838359_TOTAL_DEBT | sec_filing | medium |
| Valuation is framed by EV/Sales of 633.52x; this directly limits how aggressive the Underweight stance should be. | RGTI_SEC_COMPANYFACTS_1838359_REVENUE, RGTI_SEC_COMPANYFACTS_1838359_REVENUE_TTM, RGTI_SEC_COMPANYFACTS_1838359_SALES, RGTI_SEC_COMPANYFACTS_1838359_UMSATZ, RGTI_SEC_revenue_FY2022_FY_0001193125-23-080486, RGTI_SEC_revenue_FY2022_Q2_0001193125-22-218918, RGTI_SEC_revenue_FY2022_Q3_0001193125-22-290115, RGTI_SEC_revenue_FY2023_Q1_0001193125-23-142055, RGTI_SEC_COMPANYFACTS_1838359_CASHFLOW, RGTI_SEC_COMPANYFACTS_1838359_FCF, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASH_FLOW, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASH_FLOW_TTM, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASHFLOW, RGTI_SEC_DERIVED_FREE_CASH_FLOW_TTM, RGTI_YAHOO_CHART_PRICE_CSV_CLOSE, RGTI_YAHOO_CHART_PRICE_CSV_OHLCV, RGTI_YAHOO_CHART_PRICE_CSV_PRICE, RGTI_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, RGTI_YAHOO_CHART_PRICE_CSV_PRICE_DATA, RGTI_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv, sec_filing | medium |
| For RGTI, P/FCF is not available in evidence set and should be read against validated growth, cash-flow and risk context; missing or extreme cash-flow multiples should reduce conviction rather than invite a stronger rating. | RGTI_SEC_COMPANYFACTS_1838359_CASHFLOW, RGTI_SEC_COMPANYFACTS_1838359_FCF, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASH_FLOW, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASH_FLOW_TTM, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASHFLOW, RGTI_SEC_DERIVED_FREE_CASH_FLOW_TTM, RGTI_SEC_COMPANYFACTS_1838359_REVENUE, RGTI_SEC_COMPANYFACTS_1838359_REVENUE_TTM, RGTI_SEC_COMPANYFACTS_1838359_SALES, RGTI_SEC_COMPANYFACTS_1838359_UMSATZ, RGTI_SEC_revenue_FY2022_FY_0001193125-23-080486, RGTI_SEC_revenue_FY2022_Q2_0001193125-22-218918, RGTI_SEC_revenue_FY2022_Q3_0001193125-22-290115, RGTI_SEC_revenue_FY2023_Q1_0001193125-23-142055 | sec_filing | medium |
| The technical setup uses close 17.85, 50-SMA 16.65, 200-SMA 23.01 and RSI 50.00, creating timing risk if price cannot reclaim trend support. | RGTI_YAHOO_CHART_PRICE_CSV_TECHNICAL_INDICATORS, RGTI_YAHOO_CHART_PRICE_CSV_CLOSE, RGTI_YAHOO_CHART_PRICE_CSV_OHLCV, RGTI_YAHOO_CHART_PRICE_CSV_PRICE, RGTI_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, RGTI_YAHOO_CHART_PRICE_CSV_PRICE_DATA, RGTI_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | high |
| RGTI's close of 17.85 and moving-average position imply a damaged trend that requires confirmation before adding exposure, so entries should be staged, delayed or trimmed according to business evidence and risk/reward. | RGTI_YAHOO_CHART_PRICE_CSV_TECHNICAL_INDICATORS, RGTI_YAHOO_CHART_PRICE_CSV_CLOSE, RGTI_YAHOO_CHART_PRICE_CSV_OHLCV, RGTI_YAHOO_CHART_PRICE_CSV_PRICE, RGTI_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, RGTI_YAHOO_CHART_PRICE_CSV_PRICE_DATA, RGTI_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | medium |
| The bull case is that validated growth and cash-flow quality combines with revenue of $9.2M to support the allowed upside rating path when cash conversion quality also holds. | RGTI_SEC_COMPANYFACTS_1838359_REVENUE, RGTI_SEC_COMPANYFACTS_1838359_REVENUE_TTM, RGTI_SEC_COMPANYFACTS_1838359_SALES, RGTI_SEC_COMPANYFACTS_1838359_UMSATZ, RGTI_SEC_revenue_FY2022_FY_0001193125-23-080486, RGTI_SEC_revenue_FY2022_Q2_0001193125-22-218918, RGTI_SEC_revenue_FY2022_Q3_0001193125-22-290115, RGTI_SEC_revenue_FY2023_Q1_0001193125-23-142055, RGTI_SEC_COMPANYFACTS_1838359_CASHFLOW, RGTI_SEC_COMPANYFACTS_1838359_FCF, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASH_FLOW, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASH_FLOW_TTM, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASHFLOW, RGTI_SEC_DERIVED_FREE_CASH_FLOW_TTM | sec_filing | medium |
| A constructive technical bull path for RGTI requires confirmation beyond the current RSI of 50.00 and moving-average setup. | RGTI_YAHOO_CHART_PRICE_CSV_TECHNICAL_INDICATORS, RGTI_YAHOO_CHART_PRICE_CSV_CLOSE, RGTI_YAHOO_CHART_PRICE_CSV_OHLCV, RGTI_YAHOO_CHART_PRICE_CSV_PRICE, RGTI_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, RGTI_YAHOO_CHART_PRICE_CSV_PRICE_DATA, RGTI_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | medium |
| The bear case is that source concerns, valuation risk or technical weakness overwhelms reported FCF quality and leaves the stock vulnerable if SBC/Revenue at 159.7% or source concerns persist. | RGTI_SEC_COMPANYFACTS_1838359_CASHFLOW, RGTI_SEC_COMPANYFACTS_1838359_FCF, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASH_FLOW, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASH_FLOW_TTM, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASHFLOW, RGTI_SEC_DERIVED_FREE_CASH_FLOW_TTM, RGTI_SEC_COMPANYFACTS_1838359_SBC_TO_REVENUE, RGTI_SEC_DERIVED_SBC_TO_REVENUE | sec_filing | medium |
| Valuation risk for RGTI is a discipline constraint; expensive or missing EV/Sales and P/FCF context should not be translated into a blocked rating. | RGTI_SEC_COMPANYFACTS_1838359_REVENUE, RGTI_SEC_COMPANYFACTS_1838359_REVENUE_TTM, RGTI_SEC_COMPANYFACTS_1838359_SALES, RGTI_SEC_COMPANYFACTS_1838359_UMSATZ, RGTI_SEC_revenue_FY2022_FY_0001193125-23-080486, RGTI_SEC_revenue_FY2022_Q2_0001193125-22-218918, RGTI_SEC_revenue_FY2022_Q3_0001193125-22-290115, RGTI_SEC_revenue_FY2023_Q1_0001193125-23-142055, RGTI_SEC_COMPANYFACTS_1838359_CASHFLOW, RGTI_SEC_COMPANYFACTS_1838359_FCF, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASH_FLOW, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASH_FLOW_TTM, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASHFLOW, RGTI_SEC_DERIVED_FREE_CASH_FLOW_TTM | sec_filing | medium |
| Data quality is part of the RGTI research view; any unresolved data issue should override a superficially complete report. | RGTI_YAHOO_CHART_PRICE_CSV_CLOSE, RGTI_YAHOO_CHART_PRICE_CSV_OHLCV, RGTI_YAHOO_CHART_PRICE_CSV_PRICE, RGTI_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, RGTI_YAHOO_CHART_PRICE_CSV_PRICE_DATA, RGTI_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | high |
| Source disagreement or current-period mismatch can reduce conviction for RGTI, especially where revenue $9.2M is a key valuation denominator. | RGTI_SEC_COMPANYFACTS_1838359_REVENUE, RGTI_SEC_COMPANYFACTS_1838359_REVENUE_TTM, RGTI_SEC_COMPANYFACTS_1838359_SALES, RGTI_SEC_COMPANYFACTS_1838359_UMSATZ, RGTI_SEC_revenue_FY2022_FY_0001193125-23-080486, RGTI_SEC_revenue_FY2022_Q2_0001193125-22-218918, RGTI_SEC_revenue_FY2022_Q3_0001193125-22-290115, RGTI_SEC_revenue_FY2023_Q1_0001193125-23-142055, RGTI_SEC_COMPANYFACTS_1838359_CASHFLOW, RGTI_SEC_COMPANYFACTS_1838359_FCF, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASH_FLOW, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASH_FLOW_TTM, RGTI_SEC_COMPANYFACTS_1838359_FREE_CASHFLOW, RGTI_SEC_DERIVED_FREE_CASH_FLOW_TTM | sec_filing | medium |
| Catalysts for RGTI at the latest close of 17.85 should be limited to confirmed evidence; missing earnings or forward company data should be stated as unavailable rather than converted into event-risk claims. | RGTI_YAHOO_CHART_PRICE_CSV_CLOSE, RGTI_YAHOO_CHART_PRICE_CSV_OHLCV, RGTI_YAHOO_CHART_PRICE_CSV_PRICE, RGTI_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, RGTI_YAHOO_CHART_PRICE_CSV_PRICE_DATA, RGTI_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | high |
| Trigger language should use evidence-backed levels such as 50-SMA 16.65 and 200-SMA 23.01, not unvalidated price targets. | RGTI_YAHOO_CHART_PRICE_CSV_TECHNICAL_INDICATORS, RGTI_YAHOO_CHART_PRICE_CSV_CLOSE, RGTI_YAHOO_CHART_PRICE_CSV_OHLCV, RGTI_YAHOO_CHART_PRICE_CSV_PRICE, RGTI_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, RGTI_YAHOO_CHART_PRICE_CSV_PRICE_DATA, RGTI_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | medium |
| We rate RGTI Underweight at the latest close of 17.85 because company-specific growth, margin quality and source-quality drivers supports the base case, while valuation and technical risk limit the case for a more bullish rating. | RGTI_YAHOO_CHART_PRICE_CSV_CLOSE, RGTI_YAHOO_CHART_PRICE_CSV_OHLCV, RGTI_YAHOO_CHART_PRICE_CSV_PRICE, RGTI_YAHOO_CHART_PRICE_CSV_PRICE_BASIS, RGTI_YAHOO_CHART_PRICE_CSV_PRICE_DATA, RGTI_CSV_PRICE_CLOSE_2026-05-15 | exchange_ohlcv | high |
