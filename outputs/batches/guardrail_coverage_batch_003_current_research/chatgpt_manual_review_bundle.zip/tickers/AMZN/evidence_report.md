# Evidence Report - AMZN

## Hard Metrics

| Metric | Value | Period | Basis | Source Type | Source ID | Evidence ID | Confidence | Status |
|---|---:|---|---|---|---|---|---|---|
| revenue_ttm | 685,057,000,000.00 | n/a | company-defined | company_ir | AMZN_IR_CURRENT_PERIOD_FIXTURE | AMZN_IR_CURRENT_PERIOD_FIXTURE_REVENUE_TTM | high | OK |
| free_cash_flow_ttm | 1,232,000,000.00 | n/a | company-defined | company_ir | AMZN_IR_CURRENT_PERIOD_FIXTURE | AMZN_IR_CURRENT_PERIOD_FIXTURE_FREE_CASH_FLOW_TTM | high | OK |
| sbc_to_revenue | 2.8% | n/a | GAAP | sec_filing | AMZN_SEC_COMPANYFACTS_1018724 | AMZN_SEC_COMPANYFACTS_1018724_SBC_TO_REVENUE | high | OK |

## Warnings

- No evidence warnings.
