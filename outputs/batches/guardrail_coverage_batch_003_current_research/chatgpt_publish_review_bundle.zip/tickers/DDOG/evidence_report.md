# Evidence Report - DDOG

## Hard Metrics

| Metric | Value | Period | Basis | Source Type | Source ID | Evidence ID | Confidence | Status |
|---|---:|---|---|---|---|---|---|---|
| revenue_ttm | 3,430,000,000.00 | n/a | company-defined | company_ir | DDOG_IR_CURRENT_PERIOD_FIXTURE | DDOG_IR_CURRENT_PERIOD_FIXTURE_REVENUE_TTM | high | OK |
| free_cash_flow_ttm | 914,717,000.00 | n/a | company-defined | company_ir | DDOG_IR_CURRENT_PERIOD_FIXTURE | DDOG_IR_CURRENT_PERIOD_FIXTURE_FREE_CASH_FLOW_TTM | high | OK |
| sbc_to_revenue | 750,671,000.00 | FY2025 | company-defined | earnings_release | DDOG_IR_FY2025_Q4_RELEASE | DDOG_DDOG_IR_FY2025_Q4_RELEASE_sbc_FY2025 | high | OK |

## Warnings

- No evidence warnings.
