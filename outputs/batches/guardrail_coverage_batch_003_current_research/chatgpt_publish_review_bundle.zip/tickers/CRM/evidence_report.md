# Evidence Report - CRM

## Hard Metrics

| Metric | Value | Period | Basis | Source Type | Source ID | Evidence ID | Confidence | Status |
|---|---:|---|---|---|---|---|---|---|
| revenue_ttm | 41,500,000,000.00 | n/a | company-defined | company_ir | CRM_IR_CURRENT_PERIOD_FIXTURE | CRM_IR_CURRENT_PERIOD_FIXTURE_REVENUE_TTM | high | OK |
| free_cash_flow_ttm | 14,402,000,000.00 | n/a | company-defined | company_ir | CRM_IR_CURRENT_PERIOD_FIXTURE | CRM_IR_CURRENT_PERIOD_FIXTURE_FREE_CASH_FLOW_TTM | high | OK |
| sbc_to_revenue | 3,509,000,000.00 | FY2026 | company-defined | earnings_release | CRM_IR_FY2026_Q4_RELEASE | CRM_CRM_IR_FY2026_Q4_RELEASE_sbc_FY2026 | high | OK |

## Warnings

- No evidence warnings.
