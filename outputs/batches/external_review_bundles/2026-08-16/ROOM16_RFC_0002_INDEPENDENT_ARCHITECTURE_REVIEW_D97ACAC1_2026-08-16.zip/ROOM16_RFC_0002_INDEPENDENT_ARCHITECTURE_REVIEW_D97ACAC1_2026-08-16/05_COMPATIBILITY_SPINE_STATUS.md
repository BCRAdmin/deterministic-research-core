# Compatibility-Spine-Status

Der aktuelle Stand ist eine explizite, hashgebundene
`compatibility_shadow_semantic_spine`.

- Typed Facts: 382
- Fact-Ursprung: `authority_bundle_v3.fact_ledger`
- `source_native_fact_generation=false`
- `parser_tables_are_fact_authority=false`
- `legacy_fact_ledger_removed=false`

Dies ist unter der genehmigten Shadow-/Strangler-Migration zulässig. Es darf
jedoch nicht als source-nativer Cutover bezeichnet werden.
