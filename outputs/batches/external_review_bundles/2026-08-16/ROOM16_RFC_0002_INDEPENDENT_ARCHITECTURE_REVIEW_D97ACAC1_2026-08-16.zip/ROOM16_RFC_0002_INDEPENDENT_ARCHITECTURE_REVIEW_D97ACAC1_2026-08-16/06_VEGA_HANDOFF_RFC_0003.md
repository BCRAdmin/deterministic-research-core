# Vega Handoff — RFC-0003 Executable Kernel and Provenance Closure

## Entscheidung

```text
RFC-0002 direction = accepted
Compatibility Shadow Spine = retain
Semantic Compiler Wave = not yet complete
BA10 = not authorized
No report rebuild = required
No company-specific patch = authorized
```

Arbeite die folgenden Punkte als **einen einzigen Abschlussblock** ab. Kein
Zwischenstopp und kein Copy-Paste-Zyklus, solange keine Stoppbedingung eintritt.

## 1. PassKernel als einzige Ausführungswahrheit

Die zehn RFC-0002-Passes müssen tatsächlich über den eingefrorenen Foundation
PassKernel laufen. Additiv zulässig ist ein `SemanticCompileStateIR@1` oder
`CompilerIRSetEnvelope@1`, damit der lineare Kernel die mehrteiligen IRs trägt.

Pflicht:

```text
PassExecutionRecord je Pass
Input-/Output-Hash
Cache-Key
executed/replayed/cache_hit
upstream-failure propagation
kein manueller zweiter Orchestrator
```

## 2. Formula-Provenienz

Sämtliche Formula Operands müssen reale IR-Objekte sein:

```text
TypedFactIR(role=formula_operand)
oder FormulaOperandIR
```

Mit Rolle, Wert, Dimension, Unit, Periode, Source-/Evidence-Lineage und Hash.

## 3. Vollständiger Provenienzgraph

Ergänze:

```text
Parsed Payload/Record
Table
Cell
Normalized Record
Metric
Formula Evaluation
```

zu Source/Evidence/Fact/Claim/Locator. Compatibility- und source-native-origin
bleiben unterscheidbar.

## 4. Semantischer Decision-Layer

Den verlustfreien JSON-Graph behalten. Zusätzlich typisierte Registry-Bindings
für Inputs, Rules, Risks, Counterevidence, Score, Timing, Permission,
Non-Advice und Rationale erzeugen.

## 5. L10 erweitern

Neue Pflicht-Invariants:

```text
PASS_KERNEL_EXECUTION_COMPLETE
PARSED_IR_BOUND_IN_VERIFICATION_PLAN
FORMULA_OPERAND_LINEAGE_COMPLETE
EVIDENCE_GRAPH_REQUIRED_NODE_TYPES_COMPLETE
TABLE_FACT_LINEAGE_TRUTHFUL
DECISION_REGISTRY_BINDINGS_COMPLETE
FIXTURE_DIAGNOSTIC_CODES_STABLE
COMPATIBILITY_MODE_STATUS_TRUTHFUL
```

## 6. Stable Diagnostic ABI

`closure_proven=true` nur bei Rot/Grün/Rot **und** exakter Übereinstimmung von
actual und expected Diagnostic Code. Keine rohen Exception-Texte als ABI.

## 7. Product-Baseline

Vor BA10 muss `npm run verify` ungeskippt mit Exit Code 0 bestehen und ein
frischer hashgebundener Hardening Verdict vorliegen.

## 8. Unveränderliche Grenzen

```text
Foundation 1.0.0 immutable
Registry Foundation 1.1.0 retained
Authority Bundle v3 unchanged
WM/COST/ABT archives unchanged
Product parallel truth absent
release_ready=false
publication_allowed=false
renderer_cutover=false
compiler_mode=compatibility_shadow
```

## Stoppbedingungen

Nur stoppen, wenn Foundation 1.0.0, Authority Bundle v3 oder Canary-Archive
geändert werden müssten, Product fachliche Authority erhalten müsste oder
ticker-spezifischer Code nötig wäre.

## Pflichtbundle

```text
00_EXECUTIVE_SUMMARY.md
01_RFC_0003_IMPLEMENTATION_RECORD.md
02_PASS_KERNEL_EXECUTION_RECORDS/
03_COMPILE_STATE_IR_AND_CONTRACT.md
04_FORMULA_OPERAND_LINEAGE.json
05_COMPLETE_EVIDENCE_GRAPH_AUDIT.json
06_SEMANTIC_DECISION_GRAPH_AUDIT.json
07_VERIFICATION_PLAN_AND_DIAGNOSTICS/
08_STABLE_DIAGNOSTIC_FIXTURE_RESULTS.json
09_WM_COST_ABT_REPLAY_RESULTS.md
10_PRODUCT_FULL_REGRESSION.md
11_FOUNDATION_REGISTRY_ABI_IMMUTABILITY.md
12_SEMANTIC_WAVE_FINAL_VERDICT.json
RESULT_MANIFEST.json
```

Danach genau eine enge unabhängige Abschlussprüfung. BA10 erst nach PASS.
