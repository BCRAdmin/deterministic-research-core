# Vega Prompt — Speculative Deep-Tech / Microcap Manual-Review Profile

Implementiere einen Speculative Deep-Tech / Microcap Manual-Review Profile Sprint anhand RGTI.

Ziel:
RGTI-artige Titel dürfen nicht als clean publishable Research Reports durchgehen, wenn harte SEC/IR-Daten fehlen oder der Investment Case stark von Vendor-Daten, Narrativ und Accounting-Effekten abhängt.

Keine neue Architektur.
Nur bestehende Gates/Claim-Templates/Quality-Regeln erweitern.

## Aufgaben

### 1. Neues Risk Profile

Neues Profil:

```text
SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE
```

Aktivieren, wenn mindestens 3 dieser Bedingungen erfüllt sind:

```text
market_cap / revenue > 100
revenue_ttm < 50M
operating_income_ttm < 0
free_cash_flow_ttm < 0
sbc_to_revenue > 0.50
vendor-only hard financial metrics
derivative / warrant fair-value effects detected
no SEC/IR current-period evidence
lumpy revenue / non-scaled commercial adoption language
beta > 1.5 or high-volatility flag
```

### 2. Verhalten bei aktivem Profil

Wenn aktiv:

```text
publishable = false, außer SEC/IR evidence is complete
external_display_rating = "Manual Review / Preliminary Underweight"
clean Buy/Accumulate blockieren
Underweight nur als preliminary zulassen
final_report darf erstellt werden
publish_report nur mit clear manual_review banner
```

### 3. Accounting Gain Guard

Wenn Net Income positiv oder verbessert ist, aber Operating Income negativ und Other Income / warrant / derivative gain wesentlich ist:

```text
Issue = ACCOUNTING_GAIN_NOT_OPERATING_TURNAROUND
```

### 4. Order Materiality Section

Für Quantum / Deep Tech / Defense-Hardware-Titel muss der Report, wenn Aufträge erwähnt werden, enthalten:

```text
contract value
expected delivery / revenue timing if available
contract value vs market cap
contract value vs annual revenue
why it does or does not support valuation
```

Fehlt diese Sektion:

```text
Issue = ORDER_MATERIALITY_MISSING
quality_score cap = 80
```

### 5. Technical Dominance Guard

Bei early-commercial / speculative deep-tech darf Technical Analysis nicht mehr als 30% der final rating rationale ausmachen.

Issue:

```text
TECHNICAL_OVERWEIGHT_IN_FUNDAMENTAL_THESIS
```

### 6. RGTI Regression Fixture

Nutze den hochgeladenen RGTI-Report als Regression Case.

Erwartung:

```text
status = manual_review
not clean publishable
ACCOUNTING_GAIN_NOT_OPERATING_TURNAROUND erkannt
VENDOR_ONLY_HARD_METRICS erkannt
SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE erkannt
external display = "Manual Review / Preliminary Underweight"
```

### 7. Quality Score Caps

```text
Speculative Deep-Tech Profile aktiv + SEC/IR fehlt:
quality_score cap = 75

Accounting Gain Caveat fehlt:
quality_score cap = 70

Order Materiality fehlt, obwohl Aufträge erwähnt werden:
quality_score cap = 80
```

### 8. Dashboard Counts

Neue Counts:

```text
speculative_deep_tech_profile_count
accounting_gain_not_operating_turnaround_count
vendor_only_hard_metrics_count
order_materiality_missing_count
technical_overweight_in_thesis_count
```

### 9. Testlauf

Run:

```text
batch_id = rgti_deeptech_profile_check
Ticker: RGTI
mode = source_ingestion_mode falls SEC/IR verfügbar, sonst vendor/manual fallback mit manual_review
```

### Akzeptanz

```text
pytest grün
compileall grün
RGTI darf nicht clean passed sein ohne SEC/IR
RGTI external display = Manual Review / Preliminary Underweight
keine Guard-Lockerung
```
