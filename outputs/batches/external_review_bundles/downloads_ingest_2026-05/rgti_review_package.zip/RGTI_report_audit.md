# RGTI Report Review Package

## Executive Verdict

Das RGTI-Dossier kommt in der Richtung nicht falsch raus: `Untergewichten / Halten` ist nachvollziehbar. Der Bericht erkennt technische Schwäche, extreme Bewertung und hohe spekulative Qualität.

Aber: Der Bericht ist nicht publishable und sollte in eurer Pipeline manual_review auslösen, weil er mehrfach selbst zugibt, dass harte Finanzkennzahlen auf Vendor-/Medienquellen beruhen und SEC/IR-Fallback fehlt. Bei RGTI ist das kein kleiner Datenqualitätsmangel, sondern ein zentraler Blocker.

Korrigierte finale Einordnung:

> Manual Review / Preliminary Underweight. Keine Neuaufnahme. Bestehende Kleinstposition höchstens als spekulative Option halten. Reduktion in Stärke rational. SEC/IR-Bestätigung zwingend.

---

## Was der Report richtig macht

- Die technische Richtung ist brauchbar: Death Cross, Kurs unter 200-SMA, Momentumverlust und RSI-Divergenz werden erkannt.
- Das Bewertungsproblem wird erkannt: Milliardenbewertung bei sehr kleinem Umsatz.
- Es gibt keine aggressive Buy-These; die Grundrichtung `Untergewichten / Halten` ist näher an der Realität als ein Momentum-Buy.

---

## Harte Probleme

### 1. Vendor-only harte Finanzdaten trotz konkretem Rating

Der Report sagt selbst, dass für eine institutionelle Entscheidung SEC/IR-Fallback nötig ist. Trotzdem folgt eine konkrete finale Entscheidung mit Underweight-/Reduktionsplan.

Neue Regel:

```text
Wenn Small/Micro-Cap + pre-profit + vendor-only hard metrics:
status = manual_review
publishable = false
external_rating = Manual Review / Preliminary
```

### 2. Q1 2026 wird operativ zu freundlich beschrieben

Die QC-Ausarbeitung korrigiert das sauber:

- Q1-Umsatzsprung ist real.
- Operativer Verlust bleibt hoch.
- Positiver GAAP-Nettoeffekt stammt wesentlich aus Fair-Value-/Warrant-Liability-Effekten.
- Kein operativer Turnaround.

Neue Regel:

```text
ACCOUNTING_GAIN_NOT_OPERATING_TURNAROUND
```

### 3. Cash-Runway wird als Investment-Stütze zu stark gewichtet

Liquidität ist ein Schutzfaktor, aber kein Bewertungsargument.

Korrigierte Formulierung:

> Die Liquidität reduziert kurzfristiges Insolvenz- und unmittelbares Verwässerungsrisiko. Sie rechtfertigt aber keine Milliardenbewertung bei weiterhin minimalem Umsatz, negativem operativen Ergebnis und hohem Cashburn.

### 4. Auftragslage fehlt als Materiality-Analyse

RGTI hat reale Aufträge/Deals, aber die Größenordnung muss ins Verhältnis zur Bewertung gesetzt werden.

Neue Pflichtsektion für Deep-Tech:

```text
Order / Contract Materiality
- contract value
- expected timing
- contract value / market cap
- contract value / annual revenue
- revenue recognition uncertainty
- why it does or does not support valuation
```

### 5. Technische Analyse dominiert zu stark

Technik ist bei RGTI nützlich für Timing, aber nicht für die Investment-These.

Neue Regel:

```text
Bei pre-profit / early-commercial deep-tech darf Technical Analysis nur Timing/Risk Management liefern, nicht die fundamentale Investment-These tragen.
```

Issue:

```text
TECHNICAL_OVERWEIGHT_IN_FUNDAMENTAL_THESIS
```

---

## Neues Pipeline-Profil

```text
SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE
```

Aktivieren, wenn mindestens 3 Bedingungen erfüllt sind:

```text
market_cap / revenue > 100
revenue_ttm < 50M
operating_income_ttm < 0
free_cash_flow_ttm < 0
sbc_to_revenue > 0.50
vendor-only hard financial metrics
derivative / warrant fair-value effects detected
no SEC/IR current-period evidence
lumpy revenue / non-scaled commercial adoption language
beta > 1.5 or high-volatility flag
```

Wenn aktiv:

```text
publishable = false unless SEC/IR evidence complete
external_display_rating = Manual Review / Preliminary Underweight
clean Buy/Accumulate blocked
Underweight only preliminary
quality_score cap = 75 if SEC/IR missing
```

---

## Korrigiertes RGTI-Urteil

### Für neue Investoren

Kein Kauf auf fundamentaler Basis.

### Für bestehende Positionen

Nur als kleine spekulative Restposition haltbar. Keine Aufstockung. Reduktion bei Stärke rational.

### Für Long-Term

RGTI ist derzeit kein klassischer Long-Term-Compounder, sondern eine technologische Optionswette.

### Korrigiertes Rating

```text
Manual Review / Preliminary Underweight
No New Buy
Small speculative hold only if already owned
Reduce into strength
SEC/IR confirmation required
```
