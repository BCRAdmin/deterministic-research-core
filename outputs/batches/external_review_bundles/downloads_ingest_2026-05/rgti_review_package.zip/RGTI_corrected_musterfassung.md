# RGTI — Korrigierte Musterfassung

## Executive Summary

Rigetti Computing ist technologisch interessant, aber aktuell fundamental kein investierbarer Compounder. Das Unternehmen hat eine starke Liquiditätsposition und erste kommerzielle Aktivität, aber noch kein skalierendes Umsatzmodell. Die Bewertung steht in keinem vernünftigen Verhältnis zum aktuellen Umsatzniveau.

Die technische Lage bestätigt das Risiko: Death-Cross-Struktur, Kurs unter 200-SMA, Momentum-Verlust und RSI-Divergenz sprechen gegen aggressive Neuengagements. Die technische Erholung reicht nicht aus, um die fundamentale Bewertungsdiskrepanz zu kompensieren.

**Korrigierte Einordnung:** Manual Review / Preliminary Underweight. Keine Neuaufnahme. Bestehende Kleinstposition höchstens als spekulative Option halten. Reduktion in Stärke rational.

---

## Investment Thesis

RGTI ist keine klassische Wachstumsaktie, sondern eine Optionswette auf einen zukünftigen Quantencomputing-Durchbruch. Die Aktie kann stark steigen, wenn das Sektor-Narrativ dreht oder technische Meilensteine neue Partnerschaften auslösen. Fundamental ist die aktuelle Bewertung aber extrem schwer zu rechtfertigen.

Die wichtigste Trennung:

```text
Technologisch spannend: ja
Cash-stark relativ zum Burn: ja
Fundamental investierbar: aktuell nein
```

---

## Fundamental Reality Check

Der Umsatzsprung in Q1 2026 ist positiv, aber kein operativer Turnaround. Ein Umsatz von wenigen Millionen Dollar pro Quartal reicht nicht aus, um eine Milliardenbewertung zu stützen, solange operative Verluste, negativer Free Cash Flow und hohe SBC bestehen.

Ein positiver oder verbesserter GAAP-Nettoeffekt darf bei RGTI nicht mit operativer Profitabilität verwechselt werden, wenn er wesentlich aus Fair-Value-/Warrant-Liability-Effekten stammt.

---

## Cash and Runway

Die Liquidität ist ein echter Schutzfaktor. Sie reduziert kurzfristiges Insolvenz- und unmittelbares Verwässerungsrisiko. Sie ist aber kein Investment-Argument für den Kurs.

Eine starke Bilanz bedeutet:

```text
Das Unternehmen kann weiterforschen.
Nicht:
Die aktuelle Bewertung ist gerechtfertigt.
```

---

## Order / Contract Materiality

RGTI hat reale kommerzielle Aktivität. Verträge wie C-DAC Indien oder AFRL/U.S. Air Force sind wichtig als Proof-of-Concept.

Aber: Die absolute Vertragsgröße ist klein im Verhältnis zur Marktkapitalisierung. Solche Aufträge können Vertrauen schaffen, aber sie tragen die Bewertung nur dann, wenn aus ihnen wiederholbare, skalierende Umsätze entstehen.

---

## Technical Setup

Die technische Lage ist schwach bis gemischt:

- Kurs unter 200-SMA.
- Death Cross aktiv.
- Preis kurzfristig über 50-SMA, aber unter 10-EMA.
- MACD positiv, aber Momentum lässt nach.
- RSI-Divergenz deutet auf Ermüdung der Rally hin.

Technische Schlussfolgerung:

```text
Nicht jetzt aggressiv rein.
Wenn bereits investiert: Risiko reduzieren oder Stops definieren.
```

Technik kann aber nur Timing liefern, nicht die Investment-These.

---

## Bull Case

Der Bull Case basiert auf Quantencomputing als langfristigem Megatrend, RGTI als Pure-Play, starker Liquiditätsposition, technischen Meilensteinen und ersten kommerziellen Aufträgen.

Dieser Bull Case bleibt eine Option, aber noch kein bewiesenes Geschäftsmodell.

---

## Bear Case

Der Bear Case ist aktuell stärker:

- Umsatzbasis extrem klein.
- Bewertung extrem hoch.
- operativer Verlust hoch.
- FCF negativ.
- SBC/Verwässerung hoch.
- kommerzielle Adoption begrenzt.
- Roadmap- und Technologieausführungsrisiko.
- Sektor stark hype- und retail-getrieben.

---

## Final Rating and Action

**Rating:** Manual Review / Preliminary Underweight

**Warum dieses Rating:** Die Bewertung ist fundamental nicht tragfähig, solange Umsatz, Cashflow und kommerzielle Adoption so klein bleiben. Die Bilanz schützt vor kurzfristigem Finanzierungsschock, aber nicht vor Multiple-Kompression.

**Warum nicht bullish:** Technologische Optionalität reicht nicht aus, wenn Umsatzskalierung, FCF-Pfad und kommerzielle Adoption fehlen.

**Warum nicht kompletter Sell:** Die Liquidität und mögliche technische/strategische Durchbrüche geben der Aktie Optionscharakter. Eine kleine Restposition kann bewusst als Spekulation gehalten werden.

**Action Plan:**

```text
Neue Käufe: nein.
Bestehende große Position: reduzieren.
Kleinstposition: nur spekulativ halten.
Aufstockung erst nach SEC/IR-bestätigter Umsatzskalierung und klarer kommerzieller Pipeline.
```
