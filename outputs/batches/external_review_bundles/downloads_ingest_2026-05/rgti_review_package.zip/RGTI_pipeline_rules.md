# RGTI-derived Pipeline Rules

## Rule 1 — Speculative Deep-Tech Manual Review

If a company is early-commercial / pre-profit and has market_cap / revenue > 100, revenue_ttm < 50M, negative operating income, negative FCF, vendor-only hard metrics or derivative/warrant fair-value effects, then:

```text
status = manual_review
publishable = false
external_display_rating = Manual Review / Preliminary
```

## Rule 2 — Accounting Gain Caveat

If net income improves because of warrant/derivative fair-value gains while operating income remains negative:

```text
ACCOUNTING_GAIN_NOT_OPERATING_TURNAROUND
```

Block uncaveated claims such as:
- loss narrowed
- earnings improved
- profitable quarter
- turnaround

## Rule 3 — Order Materiality Required

For deep-tech / defense / hardware names mentioning contracts, report must include:
- contract value
- delivery/revenue timing
- value vs market cap
- value vs revenue
- whether it proves scalability

## Rule 4 — Technical Analysis Cannot Drive Long-Term Thesis

For speculative deep-tech:

```text
technical analysis = timing/risk
fundamental thesis = commercial adoption + cash burn + contracts + dilution
```

## Rule 5 — Vendor-only Hard Metrics Block Publish

If no SEC/IR evidence exists for revenue, cash, SBC, OCF/FCF:

```text
publish_report.md not allowed
manual_review required
```
