# MSFT Current-Period Reconciliation Summary

## Run Metadata

- Run: `20260516-144258-msft-6fdeaa7c`
- TradingAgents-Datum: `None`

## Status

- Review-Status: `manual_review`
- Publishable: `false`
- Evidence-Status: aktuelle Finanzdaten im Source Ledger überwiegend `vendor:yfinance`; keine aktuelle SEC/IR-Primärbelegkette im Run.

## Aktuelle Periodenbasis aus dem Dossier

- Fundamentale Datenbasis laut Dossier: Quartalsdaten bis Q3 GJ2026, endend 31.03.2026.
- Marktdaten/technische Daten: Vendor-Daten per 15.05.2026.
- News/Sentiment: Event-Fenster 08.05.2026 bis 15.05.2026.

## Reconciliation-Befund

Die im Dossier verwendeten Kennzahlen sind intern konsistent dargestellt, aber für Gold-v1 nicht ausreichend primärquellenbestätigt. Besonders relevant ist die im Bericht genannte Abweichung zwischen Vendor-Übersicht zum Free Cash Flow und der aus Quartalsdaten aggregierten TTM-Rechnung. Außerdem wird ein nicht-operativer Q2-Effekt von rund 9,9 Mrd. USD als Verzerrung des Nettoergebnisses genannt.

## Gold-v1-Reife

Nicht erfüllt. Für Gold-v1 fehlen im aktuellen Run SEC/IR-bestätigte current-period Financials und eine saubere Public-Report-Freigabe. Der Run ist deshalb ein Near-Gold-/Manual-Review-Kandidat, kein Gold-v1-Kandidat zur direkten Hochstufung.
