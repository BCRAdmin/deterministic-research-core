# Evidence Report - MSFT

## Current Status Snapshot

- Ticker: `MSFT`
- Review status: `manual_review`
- Publishable: `false`
- Internal rating: `Hold`
- External display rating: `Manual Review / Hold Pending Primary Evidence`
- Public rating: `null`
- Company archetype: `MEGA_CAP_PLATFORM`
- Quality score: `75`

## Current Manual-Review Reasons

- `EVIDENCE_INCOMPLETE_FOR_GOLD`

## Evidence Status

The current bundle marks MSFT as manual review because hard financial metrics require current-period SEC/IR or IR evidence before Gold-v1 publication. This is an evidence-completeness issue, not a speculative deep-tech or preliminary-underweight classification.

## Source of Truth

- `report_manifest.json`
- `decision_packet.json`
- `dashboard_status.json`
- `quality_score.json`
