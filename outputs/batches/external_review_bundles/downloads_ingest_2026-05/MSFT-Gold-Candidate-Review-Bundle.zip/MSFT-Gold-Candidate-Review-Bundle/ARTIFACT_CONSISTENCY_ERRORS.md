# ARTIFACT_CONSISTENCY_ERRORS

- Bundle: `/Users/BjornRosinger/Documents/New project/company-dossier-lab/reports/room16/runs/20260516-144258-msft-6fdeaa7c/MSFT/MSFT-Gold-Candidate-Review-Bundle`
- Status: `artifact_inconsistent`
- Error count: `1`

## Issues

### STALE_DIAGNOSTIC_STATUS_REFERENCE

- Ticker: `MSFT`
- Artifact: `current_period_reconciliation_summary.md`
- Message: Diagnostic artifact contains runtime/provider language outside an approved diagnostic section.
- Expected: `['diagnostics', 'run metadata', 'historical / legacy context', 'false positive check']`
- Found: `runtime/provider language`
