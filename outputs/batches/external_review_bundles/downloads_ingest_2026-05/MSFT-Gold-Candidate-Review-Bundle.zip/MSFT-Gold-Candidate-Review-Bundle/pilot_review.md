# MSFT Pilot Review

## Status

- Ticker: `MSFT`
- Review status: `manual_review`
- Publishable: `false`
- Internal rating: `Hold`
- External display rating: `Manual Review / Hold Pending Primary Evidence`
- Public rating: `null`
- Company archetype: `MEGA_CAP_PLATFORM`
- Quality score: `75`

## Current Finding

MSFT is classified as `MEGA_CAP_PLATFORM`. The current manual-review state is caused by incomplete primary evidence for Gold-v1, represented by `EVIDENCE_INCOMPLETE_FOR_GOLD`. MSFT is not a speculative deep-tech manual-review case and does not carry a bearish preliminary display.

## Bundle Consistency

The dashboard, quality score, decision packet, report manifest, publish stub, evidence report and pilot review now use the same external display rating: `Manual Review / Hold Pending Primary Evidence`.
