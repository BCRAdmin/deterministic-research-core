# ROOM 16 - Vollständiges Research-Dossier

Erstellt: 2026-05-16 14:57 Europe/Berlin
TradingAgents-Datum: 2026-05-15
Run-Verzeichnis: `/Users/BjornRosinger/Documents/New project/company-dossier-lab/.runtime/bcr-company-batches/20260516-144258-msft-6fdeaa7c`

> Interner Research-Output. Keine Finanzberatung, keine Handelsanweisung, keine externe Veröffentlichung ohne Review.

## Laufkontext

- Provider: `ollama`
- Quick-Modell: `deepseek-v4-pro:cloud`
- Deep-Modell: `deepseek-v4-pro:cloud`
- Analysten: `market, social, news, fundamentals`

## Entscheidungsmatrix

| Unternehmen | Status | Laufzeit | Rating | Trader-Signal |
| --- | ---: | ---: | --- | --- |
| `MSFT` | ok | 706.4s | Halten | Halten |

<!-- PAGEBREAK -->

# Detailreports

## MSFT

**Rating:** Halten
**Trader-Signal:** Halten
**Laufzeit:** 706.4s

### Markt- und Techniklage

# Technische Analyse: Microsoft (MSFT) – Stand 15. Mai 2026

---

## 1. Auswahl der Indikatoren und Begründung

Für eine umfassende, nicht-redundante Analyse von MSFT wurden folgende acht Indikatoren gewählt:

| # | Indikator | Kategorie | Begründung |
|---|-----------|-----------|------------|
| 1 | **close_50_sma** | Moving Averages | Mittel-/langfristiger Trend; Dynamic Support/Resistance; Death-Cross-Prüfung |
| 2 | **close_200_sma** | Moving Averages | Strategischer Trend-Benchmark; Golden/Death Cross; strukturelle Marktphase |
| 3 | **close_10_ema** | Moving Averages | Kurzfristige Dynamik; schnelle Momentum-Shifts; Ergänzung zu den langsameren SMAs |
| 4 | **macd** | MACD | Momentum-Tiefe; Crossovers; Divergenzen; ergänzt RSI ohne Redundanz |
| 5 | **rsi** | Momentum | Überkauft/Überverkauft (70/30); Divergenzen; keine Überschneidung mit MACD-Rohwert |
| 6 | **boll_ub** | Volatilität | Dynamische Überkauft-Zonen; Breakout-Bestätigung; Bandbreiten-Analyse |
| 7 | **boll_lb** | Volatilität | Dynamische Überverkauft-Zonen; Support-Bereiche; Squeeze-Erkennung |
| 8 | **atr** | Volatilität | Risikomanagement; Stop-Loss-Setzung; Positionsgrößensteuerung |

Die Auswahl vermeidet bewusst Redundanzen: MACD Signal und MACD Histogram wurden weggelassen (im MACD-Rohwert bereits enthalten), ebenso der Bollinger-Mittelwert (deckt sich weitgehend mit 20 SMA). VWMA wurde nicht gewählt, da Volumenanalyse hier nicht im Fokus steht.

---

## 2. Detaillierte Analyse

### 2.1 Kursverlauf – Sechsmonatsübersicht (Nov 2025 – Mai 2026)

Die Daten zeigen einen **dramatischen Kursverfall**, gefolgt von einer Erholungsrally:

| Phase | Zeitraum | Kursentwicklung |
|-------|----------|-----------------|
| Plateau | Nov–Dez 2025 | ~$505 -> $482 |
| Crash | Jan–Feb 2026 | $483 -> $392 (Höhepunkt: **29.01.2026: -$48/Tag** auf $432, Volumen 128,9 Mio.) |
| Bodenbildung | Feb–März 2026 | Tiefststand **$356,77 am 27.03.2026** |
| Erholungsrally | April 2026 | $357 -> $433 (+21,3 % in ~3 Wochen) |
| Rücklauf | Mai 2026 | $433 -> $409,43 (aktuell) |

### 2.2 Trendstruktur – Death Cross bestätigt

**50 SMA: $399,06 | 200 SMA: $461,91 | Spread: -$62,85 (-13,6 %)**

> **Es liegt ein aktiver Death Cross vor**: Die 50 SMA unterschreitet die 200 SMA seit etwa Ende März/Anfang April signifikant. Dies ist ein strukturell negativer Langzeittrend-Indikator.

- Der Abstand zwischen beiden SMAs beträgt ~$62,85 und **weitet sich noch aus** – die 50 SMA fällt weiter, die 200 SMA sinkt langsamer.
- Die 200 SMA liegt ca. **12,8 % über dem aktuellen Kurs**. Eine Rückkehr zum 200 SMA erfordert eine Rally von über $50.

### 2.3 Kurzfristiger Trend – Positiv aber fragil

- **Preis ($409,43) > 50 SMA ($399,06)**: Kurzfristig bullishes Signal. Der Kurs hat die 50 SMA Mitte April nach oben durchbrochen und hält sich seitdem darüber.
- **Preis ($409,43) < 10 EMA ($413,65)**: Der Kurs liegt leicht *unter* der 10 EMA. Das signalisiert kurzfristige Schwäche – die Erholung hat an Momentum verloren.
- Seit dem Hoch bei ~$433 (22.04.) fiel der Kurs um ~5,4 %. Der 10 EMA fällt seit dem 1. Mai kontinuierlich.

### 2.4 Momentum-Analyse (MACD)

| Datum | MACD-Wert | Phase |
|-------|-----------|-------|
| 06.04. | -10,72 | Tiefster Punkt, maximal bärisch |
| 15.04. | -1,87 | Annäherung an Nulllinie |
| 16.04. | +1,24 | **Bullisher Crossover** (MACD > 0) |
| 29.04. | +10,75 | Höchststand des MACD |
| 15.05. | **+3,38** | Deutlich fallend, aber noch positiv |

> **MACD-Verlust an Momentum**: Der MACD hat seit seinem Hoch Ende April fast 70 % seines Wertes eingebüßt. Er ist noch positiv, aber die Rate des Rückgangs (ca. -0,5 bis -1,0 pro Tag) deutet auf einen möglichen baldigen **bearishen Crossover unter die Nulllinie** hin, sollte sich der Rückgang fortsetzen.

### 2.5 RSI – Neutral mit bärischer Vergangenheit

- **Aktueller RSI: 57,90** – moderat, weder überkauft noch überverkauft.
- Während des Crashs: RSI fiel auf **22,29 (27.03.)** – extremes Überverkauft-Signal, das die Rally korrekt antizipierte.
- Während des Rally-Hochs: RSI erreichte **73,10 (22.04.)** – überkauft, danach setzte der Rücklauf ein.
- Der RSI liegt nun im neutralen Bereich. Es gibt weder bullishe noch bärische Divergenzen zum Kurs.

### 2.6 Bollinger Bänder – Squeeze und Unterstützung

| Band | Wert | Abstand zum Kurs |
|------|------|------------------|
| Upper Band | $432,73 | +5,7 % |
| Lower Band | $402,08 | -1,8 % |
| **Bandbreite** | **$30,64** | — |

- Die Bandbreite hat sich von ~$108 (Ende April) auf ~$31 verengt – ein **Bollinger Squeeze** ist im Gange. Dies deutet auf eine bevorstehende **starke Richtungsbewegung** hin.
- Der Kurs liegt näher am unteren Band (-1,8 %) als am oberen (+5,7 %). Dies spricht für einen kurzfristig bärischen Bias.
- Das untere Band bei $402 dient als **unmittelbare Unterstützung** und deckt sich ungefähr mit dem letzten Swing-Tief (~$401 am 13.05.).

### 2.7 ATR – Erhöhte Volatilität

- **ATR: $11,06** – entspricht etwa **2,7 % des aktuellen Kurses**.
- Zum Vergleich: In ruhigeren Phasen (vor dem Crash) lag der ATR bei ca. $7–8.
- Die erhöhte Volatilität bedeutet: **Weite Stop-Losses sind erforderlich**. Ein ATR-basierter Stop (z. B. 1,5x ATR = $16,59) bedeutet einen Stop-Abstand von ~4 %.

---

## 3. Zentrale Unterstützungs- und Widerstandsniveaus

| Typ | Niveau | Begründung |
|-----|--------|------------|
| **Widerstand 1** | $413,65 | 10 EMA – kurzfristige dynamische Hürde |
| **Widerstand 2** | $432–433 | Bollinger Upper + letztes Swing-Hoch (22.04.) |
| **Widerstand 3** | $461,91 | 200 SMA – struktureller Langfrist-Widerstand |
| **Unterstützung 1** | $402,08 | Bollinger Lower Band |
| **Unterstützung 2** | $399,06 | 50 SMA – mittelfristige dynamische Unterstützung |
| **Unterstützung 3** | $381–384 | Swing-Tief vom 20.03.2026 und Bereich der Konsolidierung |
| **Unterstützung 4** | $356,77 | Jahrestief (27.03.2026) |

---

## 4. Synthese und Interpretation

### Narrativ der Marktstruktur:

1. **Langfristig (strukturell)**: BÄRISCH. Der Death Cross (50 < 200 SMA) mit weitem Abstand signalisiert einen intakten Abwärtstrend. Die 200 SMA fällt und liegt $62 über dem Kurs.

2. **Mittelfristig (taktisch)**: NEUTRAL MIT BÄRISCHEM BIAS. Der Kurs liegt zwar über der 50 SMA, aber die Erholungsdynamik erodiert sichtbar. MACD fällt rapide. Der Preis notiert unter der 10 EMA.

3. **Kurzfristig (operativ)**: VORSICHTIG BÄRISCH. Der Bollinger Squeeze kündigt einen Ausbruch an. Die Nähe zum unteren Band und das fallende MACD-Momentum sprechen für ein mögliches Unterschreiten der $402/$399-Zone.

### Risikoszenarien:

- **Bärisches Szenario**: Bruch unter $399 (50 SMA) -> Test von $381–384 -> möglicher Retest des Jahrestiefs um $357.
- **Bullishes Szenario**: Halten über $399 -> Überwindung der 10 EMA ($414) -> Rally Richtung $433 (Oberes Bollinger Band) -> nur ein Bruch über $462 (200 SMA) würde den strukturellen Trend drehen.
- **Seitwärts-Konsolidierung**: $399–$415 Range-Trading während des Squeeze, bis ein Ausbruch erfolgt.

---

## 5. Zusammenfassung der Kernaussagen

| Kategorie | Signal | Bewertung |
|-----------|--------|-----------|
| Death Cross (50/200 SMA) | Aktiv, Abstand $62,85 | Strukturell bärisch |
| Kurs vs. 50 SMA | Darüber (+$10,37) | Kurzfristiger Support |
| Kurs vs. 10 EMA | Darunter (-$4,22) | Kurzfristige Schwäche |
| MACD | +3,38, fallend | Momentum-Verlust |
| RSI | 57,90 | Neutral |
| Bollinger Squeeze | Bandbreite nur $30,64 | Ausbruch steht bevor |
| ATR | $11,06 (2,7 %) | Erhöhte Volatilität |
| Nächster Support | $402 (LB) / $399 (50 SMA) | Kritische Zone |
| Nächster Widerstand | $414 (10 EMA) / $433 (UB) | Kurzfristige Hürden |

---

## 6. Handlungsempfehlung (Entwurf, nicht finales Investmentkomitee)

**Einschätzung: HOLD mit Abwärtsbias**

Die technische Gesamtlage ist widersprüchlich: Der Kurs hat eine beachtliche Erholung vom Jahrestief hingelegt, aber die Rally-Dynamik erodiert. Der aktive Death Cross und der fallende MACD warnen vor erneutem Abwärtsdruck. Der Bollinger Squeeze signalisiert, dass eine entscheidende Bewegung unmittelbar bevorsteht. Die Richtung ist aus den vorliegenden Indikatoren nicht eindeutig ableitbar – das Risiko eines Bruchs unter $399 ist jedoch real.

**Kritische Marken für die nächsten Handelstage:**
- **Breakout long**: Nur bei Schlusskurs über $414 (10 EMA) mit Volumenbestätigung
- **Breakdown short**: Bei Bruch unter $399 (50 SMA) mit Ziel $381
- **Stop-Loss long**: Unter $398 (unterhalb 50 SMA + ATR-Puffer)
- **ATR-basierter Stop-Abstand**: $16,59 (1,5x ATR)

---

| Indikator | Wert (15.05.2026) | Signal | Interpretation | Confidence |
|-----------|-------------------|--------|----------------|------------|
| close_50_sma | $399,06 | Neutral-Bullish | Kurs darüber; Dynamic Support | Hoch |
| close_200_sma | $461,91 | Bearish | Death Cross; Kurs -12,8 % darunter | Hoch |
| close_10_ema | $413,65 | Bearish | Kurs darunter; kurzfristige Schwäche | Mittel |
| macd | +3,38 | Bearish (fallend) | Momentum-Verlust; nähert sich Nulllinie | Mittel |
| rsi | 57,90 | Neutral | Kein Extrem; keine Divergenz | Mittel |
| boll_ub | $432,73 | Neutral | Fernwiderstand; +5,7 % | Mittel |
| boll_lb | $402,08 | Bearish | Kurs nahe LB; Squeeze | Mittel |
| atr | $11,06 (2,7 %) | Warnung | Erhöhte Volatilität; weite Stops nötig | Hoch |

*Quelle: vendor:yfinance, asof: 2026-05-15, period_type: daily/calculated. Die Schlusskurse basieren auf dem offiziellen Nasdaq-Close. Alle technischen Indikatoren sind vendor-berechnete Werte. Keine SEC/IR-Quellen für technische Analyse anwendbar.*

<!-- PAGEBREAK -->

### Sentiment und Marktstimmung

# Microsoft (MSFT) – Social-Media- & Nachrichtenanalyse
## Berichtszeitraum: 8. Mai – 15. Mai 2026

---

## 1. Zusammenfassung (Kurzfazit)

Die Berichtswoche war für Microsoft (MSFT) von **widersprüchlichen institutionellen Signalen** geprägt – ausgelöst durch die 13F-Offenlegungssaison für das erste Quartal 2026. Während **Bill Ackmans Pershing Square eine neue Kernposition in MSFT aufbaute**, verkaufte die **Gates Foundation ihren gesamten verbliebenen Anteil von 7,7 Millionen Aktien**. Parallel reduzierte **Tiger Global Management** seine MSFT-Position. Die fundamentale KI-Erzählung bleibt intakt, wird jedoch von makroökonomischen Gegenwinden (Inflationsängste, steigende Renditen) überlagert.

**Vorläufiges Sentiment-Fazit: HOLD – gemischte Signale, kein klarer Katalysator für unmittelbare Richtungsentscheidung.**

---

## 2. Detaillierte Nachrichtenanalyse

### 2.1 Gates Foundation: Kompletter MSFT-Ausstieg ( Bärisch)

| Attribut | Wert |
|---|---|
| **Quelle** | Barrons.com (via SEC Filing) |
| **Quellen-Tier** | Tier 2 (Medienbericht über SEC 13F) |
| **Datum** | 15. Mai 2026 (Offenlegung), Q1 2026 (Transaktionszeitraum) |
| **Ereignis** | Die Gates Foundation Trust verkaufte ihre verbliebenen **7,7 Millionen MSFT-Aktien** im Wert von ca. **3,2 Milliarden USD** |

**Analyse:** Dies ist ein symbolträchtiger Schritt. Bill Gates ist Microsoft-Gründer, und dass seine Stiftung nun keinerlei MSFT-Aktien mehr hält, sendet ein Signal – ob bewusst oder nicht. Die Stiftung diversifiziert seit Jahren, aber der finale Ausstieg könnte von einigen Marktteilnehmern als mangelndes Vertrauen in die Bewertung oder die Zukunftsaussichten interpretiert werden. **Kausalität zum Kurs ist nicht belegbar**, da die Transaktion im Stillen im Q1 stattfand und erst jetzt öffentlich wurde.

### 2.2 Pershing Square (Bill Ackman): Neue Kernposition ( Bullisch)

| Attribut | Wert |
|---|---|
| **Quelle** | WSJ, Barrons.com (via SEC 13F) |
| **Quellen-Tier** | Tier 2 |
| **Datum** | 15. Mai 2026 (Offenlegung) |
| **Ereignis** | Pershing Square nahm MSFT als **neue Kernposition** auf. Gesamtwert des US-Portfolios: **13,71 Mrd. USD**. Ackman wettet auf MSFT als **KI-Gewinner**. |

**Analyse:** Ackman positioniert MSFT als „unterbewertet" im KI-Kontext. Pershing hält nur 11 US-Positionen – eine Neuaufnahme ist daher hoch selektiv und signalisiert starke Überzeugung. Ackmans Erfolgsbilanz verleiht dieser Positionierung Gewicht.

### 2.3 Tiger Global Management: Reduzierung ( Neutral-bärisch)

| Attribut | Wert |
|---|---|
| **Quelle** | Reuters, GuruFocus.com (via SEC 13F) |
| **Quellen-Tier** | Tier 2 |
| **Datum** | 15. Mai 2026 (Offenlegung), Q1 2026 (Transaktion) |
| **Ereignis** | Tiger Global **reduzierte** MSFT-Bestand und liquidierte andere Positionen. Chase Colemans Portfolio-Impact: **-4,85 %** durch MSFT-Reduzierung. |

**Analyse:** Tiger Global ist ein bedeutender Tech-Investor. Die Reduzierung kann auf Gewinnmitnahmen, Portfolio-Rebalancing oder reduzierte KI-Überzeugung hindeuten – die genaue Motivation geht aus den öffentlichen Quellen nicht hervor.

### 2.4 Makro-Kontext: Breiter Markt unter Druck ()

| Attribut | Wert |
|---|---|
| **Quellen** | Barchart, MT Newswires, Yahoo Finance |
| **Datum** | 15. Mai 2026 (Freitag) |
| **Ereignis** | S&P 500: **-1,24 %**, Nasdaq 100: **-1,54 %**, Dow: **-1,07 %**. Ursachen: steigende Anleiherenditen, Inflationsängste, Trump-Xi-Gipfel-Ende. Tech-Sektor fiel am Nachmittag. |

**Analyse:** Der Tech-Sektor wurde am Freitag flächendeckend abverkauft. Dies ist ein **marktweites Phänomen**, kein MSFT-spezifisches. Ohne Intraday-Preisvergleich MSFT vs. Nasdaq kann keine Über-/Unterperformance-Aussage getroffen werden.

### 2.5 KI-Branchenkontext ( Bullisch)

| Attribut | Wert |
|---|---|
| **Quelle** | MT Newswires |
| **Datum** | 15. Mai 2026 |
| **Ereignis** | KI-Umsätze könnten sich **2026 verfünffachen auf 200 Mrd. USD** weltweit |

**Analyse:** Als einer der größten KI-Profiteure (Azure OpenAI, Copilot, GitHub Copilot) profitiert MSFT strukturell von diesem Trend. Konkrete MSFT-KI-Umsatzzahlen fehlen in den vorliegenden Quellen.

---

## 3. Sentiment-Analyse

Da der `get_news`-Tool keine dedizierten Social-Media-Rohdaten (Reddit, Twitter/X, StockTwits) lieferte, basiert die Sentiment-Einschätzung auf den **Nachrichteninhalten und institutionellen Flussdaten**.

| Tag | Dominantes Sentiment | Treiber |
|---|---|---|
| 8.–14. Mai | Neutral / ruhig | Keine MSFT-spezifischen Schlagzeilen identifiziert |
| 15. Mai | **Gemischt / Konflikt** | Ackman Long vs. Gates Exit vs. Tiger Reduktion ; breiter Marktabverkauf |

**Sentiment-Bewertung nach Quellen-Tier:**
- **13F/SEC-Daten (Tier 2 via Medien):** Gemischt – eine hochkarätige Neuaufnahme, ein vollständiger Ausstieg, eine Reduzierung
- **Makro (Tier 3 Vendor):** Negativ – Inflationsängste dominieren
- **KI-Sektor (Tier 3 Vendor):** Positiv – struktureller Rückenwind

---

## 4. Implikationen für Trader & Investoren

### Key Takeaways

1. **13F-Saison erzeugt Rauschen, keine klaren Signale:** Drei prominente Fonds, drei unterschiedliche Richtungen. 13F-Daten sind rückblickend (Q1-Stichtag), nicht aktuell – Positionen könnten sich seit März bereits geändert haben.

2. **Gates-Exit ist das auffälligste Signal:** Symbolisch schwerwiegend, aber die Stiftung diversifiziert seit Jahren. Kein automatischer Bärentrigger, aber erhöhtes narratives Risiko.

3. **Ackman-Einstieg stützt die KI-These:** Ein selektiver Investor mit hoher Überzeugung setzt auf MSFT als KI-Gewinner – das ist ein Qualitätssignal.

4. **Makro-Druck dominiert kurzfristig:** Solange Renditen steigen, leiden Tech-Bewertungen – MSFT ist hiervon nicht immun.

5. **Fehlende Datenpunkte ( Limitations):**
- Keine MSFT-spezifischen Preisdaten für die Woche (Über-/Unterperformance vs. Nasdaq unklar)
- Keine direkten Social-Media-Rohdaten (Reddit-Kommentare, Tweet-Volumen, Sentiment-Scores) verfügbar
- Keine MSFT-IR/SEC-Quellen (Tier 1) für fundamentale Daten im Berichtszeitraum
- Aktuelle Quartalszahlen/Guidance liegen nicht vor

---

## 5. Institutionelle Positionszusammenfassung (Q1 2026 13F)

| Institution | Aktion | Signal |
|---|---|---|
| **Gates Foundation Trust** | Komplettverkauf: 7,7 Mio. Aktien (~3,2 Mrd. $) | Stark bärisch |
| **Pershing Square (Ackman)** | Neuaufnahme als Kernposition | Stark bullisch |
| **Tiger Global (Coleman)** | Reduzierung (-4,85 % Portfolio-Impact) | Neutral-bärisch |

---

## 6. Abschließende Bewertung

**HOLD.** Die Berichtswoche liefert keine klare Richtungsentscheidung. Die institutionellen Flüsse sind widersprüchlich, das Makroumfeld belastet Tech-Titel kurzfristig, die KI-Story bleibt strukturell intakt. Ein Einstieg oder eine Aufstockung sollte auf einen Pullback in Richtung charttechnischer Unterstützung warten; ein Ausstieg wäre nur bei fundamentaler Verschlechterung der KI-These oder makroökonomischer Eskalation gerechtfertigt.

---

## Übersichtstabelle: Kernpunkte des Berichts

| Kategorie | Detail | Quelle | Datum | Signal |
|---|---|---|---|---|
| **Institutionell** | Gates Foundation verkauft restliche 7,7 Mio. MSFT-Aktien (3,2 Mrd. $) | Barrons / SEC 13F | Q1 2026, gemeldet 15.05. | Bärisch |
| **Institutionell** | Pershing Square (Ackman) eröffnet neue Kernposition in MSFT | WSJ, Barrons / SEC 13F | Q1 2026, gemeldet 15.05. | Bullisch |
| **Institutionell** | Tiger Global reduziert MSFT (-4,85 % Portfolio-Impact) | Reuters, GuruFocus / SEC 13F | Q1 2026, gemeldet 15.05. | Neutral-bärisch |
| **Makro** | S&P 500 -1,24 %, Nasdaq -1,54 % – Inflationsängste, Renditeanstieg | Barchart, MT Newswires | 15.05.2026 | Bärisch |
| **Sektor** | KI-Umsätze könnten sich 2026 auf 200 Mrd. $ verfünffachen | MT Newswires | 15.05.2026 | Bullisch |
| **Social Media** | Keine direkten Sentiment-Rohdaten verfügbar (Tool-Limitierung) | — | — | Unbekannt |
| **MSFT IR/SEC (Tier 1)** | Keine Fundamentaldaten im Berichtszeitraum abgerufen | — | — | Fehlend |
| **Preisdaten** | Keine MSFT-spezifischen Intraweek-Preise verfügbar | — | — | Fehlend |

---

**Hinweis:** Diese Analyse basiert ausschließlich auf Vendor-Nachrichtenquellen (Yahoo Finance, Barrons, WSJ, Reuters, MT Newswires, Barchart). SEC/IR-Primärquellen (Tier 1) wurden nicht direkt konsultiert. Direkte Social-Media-Sentimentdaten (Reddit, X/Twitter) standen über das eingesetzte Tool nicht zur Verfügung. Für eine abschließende Anlageentscheidung sind eine Tier-1-Quellenprüfung und aktuelle Kursdaten erforderlich.

**FINALE TRANSAKTIONSEINORDNUNG: HOLD**

<!-- PAGEBREAK -->

### Nachrichten- und Makrolage

# MSFT-Wochenanalyse: 8.–15. Mai 2026
## Makroökonomisches & unternehmensspezifisches Lagebild
**Erstellt: 15. Mai 2026 | Analyst: News Research Desk (Draft) | Ticker: MSFT**

---

## 1. ZUSAMMENFASSUNG DER WOCHENENTWICKLUNG

Die Berichtswoche stand im Zeichen der **13F-Einreichungsfrist (Q1 2026)** für institutionelle Anleger, die eine ungewöhnlich polarisierte Positionierungslandschaft für MSFT offenbarte: Während **Bill Ackmans Pershing Square eine neue Kernposition** in MSFT aufbaute, stießen sowohl die **Gates Foundation** als auch **Tiger Global (Chase Coleman)** ihre MSFT-Bestände ab. Makroökonomisch belasteten steigende Ölpreise, Inflationssorgen und ein sprunghafter Anstieg der Treasury-Renditen die breiten Aktienmärkte.

> **HINWEIS:** Dies ist ein vorbereitender Analystenentwurf, keine finale Investment-Entscheidung. Harte Finanzkennzahlen aus SEC/IR-Quellen fehlen in diesem Durchlauf; diese sind für eine abschließende Beurteilung nachzureichen.

---

## 2. MSFT-SPEZIFISCHE NACHRICHTEN

### 2.1 Gates Foundation verkauft letzte MSFT-Aktien

| Attribut | Details |
|---|---|
| **Ereignis** | Vollständiger Verkauf aller verbliebenen 7,7 Mio. MSFT-Aktien |
| **Volumen** | ~3,2 Mrd. USD zu aktuellen Kursen |
| **Zeitraum** | Q1 2026 |
| **Quelle** | Barrons.com (via SEC 13F Filing) |
| **Quellentier** | Tier 1 (SEC Filing -> reputable Finanzmedien) |
| **Konfidenz** | Hoch |

**Bewertung:** Die Gates Foundation war historisch einer der größten MSFT-Aktionäre außerhalb von Bill Gates' Privatvermögen. Der vollständige Ausstieg beendet eine jahrzehntelange Bindung. Da es sich um eine Diversifikationsentscheidung einer Stiftung handelt, ist die Signalwirkung für MSFTs operative Entwicklung **begrenzt**. Gleichwohl ist der symbolische Effekt erheblich: Der Gründer-Stiftungsapparat hält nun keinerlei MSFT mehr.

---

### 2.2 Bill Ackman / Pershing Square baut neue MSFT-Kernposition auf

| Attribut | Details |
|---|---|
| **Ereignis** | Neuerwerb einer MSFT-Position |
| **Ackmans Begründung** | MSFT sei „underpriced" und Gewinner des AI-Wettbewerbs |
| **Kontext** | Pershing Square hielt per Q1-Ende 11 US-Positionen mit ~13,71 Mrd. USD Marktwert |
| **Top-3-Positionen** | Brookfield ($2,42 Mrd.), Amazon ($2,39 Mrd.), Uber ($2,15 Mrd.) |
| **Quellen** | WSJ, Barrons.com (via SEC 13F Filing) |
| **Quellentier** | Tier 1 (SEC Filing -> WSJ/Barrons) |
| **Konfidenz** | Hoch |

**Bewertung:** Ackmans Einstieg stellt eine **qualitativ hochwertige bullische Signalquelle** dar. Pershing Square ist bekannt für konzentrierte, langfristige Kernpositionen. Die These, dass MSFT im AI-Wettbewerb unterbewertet sei, deckt sich mit einer breiteren Branchennarrative (s. Abschnitt 3). Die genaue Positionsgröße ist aus den verfügbaren Nachrichten nicht beziffert — das fehlende genaue Exposure ist mit **„missing"** zu kennzeichnen.

---

### 2.3 Tiger Global (Chase Coleman) reduziert MSFT deutlich

| Attribut | Details |
|---|---|
| **Ereignis** | Signifikante Reduktion der MSFT-Position |
| **Portfolio-Impact** | 4,85 % des Portfolios |
| **Fondsgröße** | ~78 Mrd. USD |
| **Sonstige Änderungen** | Neue Positionen: Intel, Robinhood; Ausstieg: Circle Internet, Workday |
| **Quelle** | Reuters, GuruFocus (via SEC 13F Filing) |
| **Quellentier** | Tier 2 (SEC Filing -> Reuters/GuruFocus) |
| **Konfidenz** | Hoch |

**Bewertung:** Tiger Globals MSFT-Reduktion ist Teil einer breiteren Q1-Umschichtung. Der 4,85-%-Portfolio-Impact ist substanziell. Allerdings ist Tiger Global ein stark umschlagender Fonds; solche Rotationen sind nicht ungewöhnlich. Der gleichzeitige Einstieg bei Intel könnte auf einen Shift von etablierten AI-Playern (MSFT) zu Wiederbelebungsgeschichten hindeuten.

---

### 2.4 Trump-Trading-Kontroverse (Randnotiz)

Bloomberg berichtete, dass Donald Trump oder seine Berater im Q1 mehr als 3.700 Trades tätigten, darunter in MSFT. Dies wirft Governance-Fragen auf, hat aber **keinen direkten Einfluss auf MSFTs Fundamentaldaten**. Quellentier: Tier 2 (Bloomberg). Konfidenz des Bezugs zu MSFT: **Niedrig**.

---

## 3. MAKROÖKONOMISCHER KONTEXT (8.–15. Mai 2026)

### 3.1 Inflationsängste & Renditeanstieg

| Attribut | Details |
|---|---|
| **S&P 500** | -1,24 % (Freitag, 15. Mai) |
| **Dow Jones** | -1,07 % |
| **Nasdaq 100** | -1,54 % |
| **Treiber** | Steigende Treasury-Renditen, Inflationssorgen |
| **Quelle** | Barchart, MT Newswires |
| **Quellentier** | Tier 3 (Vendor) |

### 3.2 Ölpreisschock & Rezessionswarnung

| Attribut | Details |
|---|---|
| **Benzinpreis** | Sprung von $2,98 auf $4,39 |
| **El-Erian-Warnung** | „Wir haben Wochen, um eine ausgewachsene Rezession zu vermeiden" |
| **Quelle** | Moneywise / Yahoo Finance |
| **Quellentier** | Tier 3 (Vendor-Medium zitiert Ökonomen) |
| **Konfidenz** | Mittel (Ökonomenmeinung, keine harte Prognose) |

**Implikation für MSFT:** Steigende Energiepreise erhöhen die Betriebskosten für Azure-Rechenzentren. Gleichzeitig dämpfen Rezessionssorgen die Nachfrageerwartungen für Enterprise-Software und Cloud-Dienste.

### 3.3 Trump-Xi-Gipfel abgeschlossen

Der Gipfel endete ohne marktbewegende Durchbrüche, aber die Anspannung im US-China-Verhältnis bleibt. MSFT hat nennenswerte China-Exposure über Azure, LinkedIn und Windows-OEM-Lizenzen.

### 3.4 AI-Branche: Umsatzprognose verfünffacht sich

| Attribut | Details |
|---|---|
| **Prognose** | AI-Umsätze könnten sich 2026 auf $200 Mrd. verfünffachen |
| **Quelle** | MT Newswires (Update-Artikel) |
| **Quellentier** | Tier 3 |
| **Konfidenz** | Mittel (Branchenprognose, kein MSFT-spezifischer Ausblick) |

Dies stützt Ackmans AI-These, sollte aber nicht als MSFT-spezifische Guidance missverstanden werden.

---

## 4. INSTITUTIONELLE POSITIONIERUNG — NETTOBILD

| Institution | Aktion | Signal |
|---|---|---|
| **Gates Foundation** | Vollständiger Ausstieg (~$3,2 Mrd.) | Negativ (symbolisch) |
| **Pershing Square (Ackman)** | Neue Kernposition | Positiv (High-Conviction) |
| **Tiger Global (Coleman)** | Deutliche Reduktion (-4,85 % Portfolio) | Negativ |
| **Appaloosa (Tepper)** | Keine explizite MSFT-Änderung berichtet | Neutral |

**Interpretation:** Die institutionelle Landschaft ist **gespalten**. Es gibt kein klares, richtungsweisendes Signal aus den Q1-13F-Daten. Ackmans Einstieg ist ein starkes bullisches Gegengewicht, aber die Breite der Abflüsse (Gates, Tiger Global) mahnt zur Vorsicht.

---

## 5. RISIKEN & OFFENE FRAGEN

1. **Fehlende Q1-2026-Zahlen:** MSFTs letzte Quartalszahlen (FY2026 Q3, per 31. März 2026) wurden in diesem News-Durchlauf nicht erfasst. Eine IR/SEC-Recherche ist zwingend erforderlich.
2. **Keine Preisbewegungsanalyse:** Ohne Intraday- oder Schlusskursdaten können keine Aussagen zu kursrelevanten Bewegungen getroffen werden.
3. **Keine Bewertungskennzahlen:** Ackman nennt MSFT „underpriced" — dies kann ohne multiples und Forward-Guidance nicht verifiziert werden.
4. **Cerebras-IPO:** Der 68-%-Ersttagssprung eines AI-Chip-Anbieters könnte den AI-Sektor insgesamt stützen, ist aber kein MSFT-spezifischer Katalysator.
5. **SpaceX-IPO (12. Juni):** Kann Kapital von Tech-Werten generell abziehen oder den Sektor beflügeln — beide Szenarien sind möglich.

---

## 6. MARKDOWN-TABELLE: KERNINFORMATIONEN

| Kategorie | Ereignis / Fakt | Datum | Quelle | Tier | Konfidenz | MSFT-Impact |
|---|---|---|---|---|---|---|
| **13F – MSFT** | Gates Foundation verkauft letzte 7,7 Mio. Aktien (~$3,2 Mrd.) | Q1 2026 | Barrons / SEC | 1 | Hoch | Symbolisch negativ |
| **13F – MSFT** | Pershing Square baut neue Kernposition auf („underpriced", AI-These) | Q1 2026 | WSJ, Barrons / SEC | 1 | Hoch | Positiv |
| **13F – MSFT** | Tiger Global reduziert MSFT (-4,85 % Portfolio-Impact) | Q1 2026 | Reuters / SEC | 2 | Hoch | Negativ |
| **Makro** | S&P 500 -1,24 %, Nasdaq -1,54 % (Inflationsängste, Renditeanstieg) | 15. Mai 2026 | Barchart, MT Newswires | 3 | Mittel | Belastend |
| **Makro** | Benzinpreis-Sprung $2,98 -> $4,39; El-Erian warnt vor Rezession | Woche 15. Mai | Moneywise | 3 | Mittel | Belastend |
| **Makro** | Trump-Xi-Gipfel beendet — keine marktbewegenden Ergebnisse | Woche 15. Mai | Global News | 3 | Niedrig | Unklar |
| **Sektor** | AI-Umsätze könnten sich 2026 auf $200 Mrd. verfünffachen | 15. Mai 2026 | MT Newswires | 3 | Mittel | Stützt AI-Narrativ |
| **Sektor** | Cerebras IPO: +68 % erster Tag, dann Rückgang | 14.–15. Mai 2026 | WSJ, IBD, Motley Fool | 2 | Hoch | Neutral (Sektor-Sentiment) |
| **Sektor** | SpaceX visiert IPO am 12. Juni an („größter IPO aller Zeiten") | Ankündigung Mai 2026 | WSJ | 2 | Mittel | Zu beobachten |
| **Governance** | Trump handelte MSFT unter 3.700+ Q1-Trades | Q1 2026 | Bloomberg | 2 | Niedrig (MSFT-Bezug) | Kein direkter Impact |

---

## 7. VORLÄUFIGES FAZIT (DRAFT — NICHT FINAL)

Die Nachrichtenlage für MSFT ist **ambivalent, mit leichter bullischer Tendenz aus der Ackman-Positionierung**. Die makroökonomischen Belastungsfaktoren (Inflation, Renditen, Ölpreis, Rezessionswarnung) sind jedoch akut und könnten kurzfristig überwiegen. Eine finale Beurteilung erfordert zwingend:

- MSFTs aktuelle Quartalszahlen (FY2026 Q3, 31.03.2026) aus SEC/IR-Quellen
- Aktuelle Kursdaten und Bewertungsmultiples
- Analysten-Reaktionen und Forward-Guidance
- Eine Überprüfung, ob die jüngsten Kursbewegungen auf Earnings, Guidance-Änderungen oder reinen Makro-Druck zurückgehen

Diese Lücken sollten durch den nächsten Research-Schritt geschlossen werden, bevor eine Handlungsempfehlung abgegeben wird.

---

**Ende des Analystenentwurfs.** Nächster Schritt: IR/SEC-Recherche zu MSFT-Fundamentaldaten und Kursentwicklung.

<!-- PAGEBREAK -->

### Fundamentale Lage

# Fundamentale Analyse: Microsoft Corporation (MSFT)

**Datum der Analyse:** 15. Mai 2026
**Datenquelle:** Vendor (yfinance) — SEC/IR-Primärdaten sollten zur endgültigen Verifikation herangezogen werden
**Berichtszeitraum:** Quartalsdaten bis Q3 GJ2026 (endend 31. März 2026)

---

## 1. UNTERNEHMENSPROFIL

| Merkmal | Wert |
|---|---|
| Name | Microsoft Corporation |
| Sektor | Technologie |
| Branche | Software – Infrastruktur |
| Marktkapitalisierung | 3,13 Billionen USD |
| Ausstehende Aktien | 7,429 Mrd. (31.03.2026) |

Microsoft ist der weltweit größte Software- und Cloud-Infrastrukturanbieter mit dominanten Positionen in den Bereichen Cloud Computing (Azure), Produktivitätssoftware (Microsoft 365, Office), Betriebssysteme (Windows), Gaming (Xbox) und zunehmend Künstliche Intelligenz (Copilot, OpenAI-Partnerschaft).

---

## 2. BEWERTUNGSKENNZAHLEN

| Kennzahl | Wert | Quelle/Periode |
|---|---|---|
| KGV (TTM) | 25,13 | GAAP, TTM |
| Forward KGV | 21,80 | Konsensschätzung; Forward EPS $19,35 (Quelle: Vendor – ungeprüft) |
| PEG Ratio | 1,26 | Vendor |
| Kurs/Buchwert | 7,56 | Buchwert $55,78/Aktie |
| EPS (TTM, GAAP) | $16,79 | TTM, verwässert |
| Dividendenrendite | 0,86 % | Vendor |
| Beta | 1,09 | Vendor |

**Kommentar zur Forward-Bewertung:** Das Forward-KGV von 21,8 basiert auf einem Forward-EPS von $19,35 (Vendor-Konsens). Die Management-Guidance konnte aus den vorliegenden Daten nicht separat verifiziert werden. Eine Abweichung zwischen Konsens und Unternehmensausblick ist möglich und sollte vor einer Handelsentscheidung über SEC/IR-Quellen geklärt werden.

**Aktueller Kurs (implizit):** ca. $421,90 (abgeleitet aus Marktkapitalisierung / Aktienanzahl)

**52-Wochen-Spanne:**
- Höchst: $555,45
- Tiefst: $356,28
- 50-Tage-Durchschnitt: $399,06
- 200-Tage-Durchschnitt: $463,13

Der aktuelle Kurs liegt **unter dem 200-Tage-Durchschnitt** ($463), was auf einen mittelfristigen Abwärtstrend hindeutet, jedoch über dem 50-Tage-Durchschnitt ($399), was eine kurzfristige Erholung signalisiert.

---

## 3. GEWINN- UND VERLUSTRECHNUNG (QUARTALSWEISE, GAAP)

| Quartal | Umsatz (Mrd.) | Bruttogewinn (Mrd.) | Operatives Ergebnis (Mrd.) | Nettoergebnis (Mrd.) | Verwässertes EPS |
|---|---|---|---|---|---|
| Q3 GJ2026 (31.03.2026) | 82,89 | 56,06 | 38,40 | 31,78 | $4,27 |
| Q2 GJ2026 (31.12.2025) | 81,27 | 55,30 | 38,28 | 38,46 | $5,16 |
| Q1 GJ2026 (30.09.2025) | 77,67 | 53,63 | 37,96 | 27,75 | $3,72 |
| Q4 GJ2025 (30.06.2025) | 76,44 | 52,43 | 34,32 | 27,23 | $3,65 |
| Q3 GJ2025 (31.03.2025) | 70,07 | 48,15 | 32,00 | 25,82 | $3,46 |

### Umsatzwachstum (YoY):
- **Q3 GJ2026 vs. Q3 GJ2025:** 82,89 Mrd. vs. 70,07 Mrd. = **+18,3 %**
- Sequenziell (Q3 vs. Q2 GJ2026): +2,0 %

### TTM-Kennzahlen (Q4 GJ2025 – Q3 GJ2026):

| Kennzahl | TTM-Wert (Mrd.) | Marge |
|---|---|---|
| Umsatz | 318,27 | — |
| Bruttogewinn | 217,41 | 68,3 % |
| Operatives Ergebnis | 148,96 | 46,8 % (Vendor: 46,3 %) |
| EBITDA | 184,46 (Vendor) | — |
| Nettoergebnis | 125,22 | 39,3 % |

**Hinweis zu Q2 GJ2026:** Das Nettoergebnis von $38,46 Mrd. enthält **$9,87 Mrd. sonstige Erträge**, darunter $9,54 Mrd. nicht-operatives Einkommen und $1,52 Mrd. Gewinne aus Wertpapierverkäufen. Dies ist ein Ausreißer und nicht als nachhaltiger operativer Trend zu interpretieren. Das bereinigte Nettoergebnis lag bei $38,20 Mrd.

---

## 4. BILANZANALYSE (STICHTAG: 31.03.2026)

### Vermögensstruktur:

| Position | Wert (Mrd.) |
|---|---|
| **Bilanzsumme** | **694,23** |
| Umlaufvermögen | 175,33 |
| — Liquide Mittel & kurzfristige Anlagen | 78,23 |
| — Forderungen aus L+L | 60,04 |
| Langfristige Vermögenswerte | 518,90 |
| — Sachanlagen (netto) | 307,63 |
| — Goodwill & immaterielle Vermögenswerte | 138,99 |
| — Finanzanlagen | 33,68 |

### Kapitalstruktur:

| Position | Wert (Mrd.) |
|---|---|
| **Fremdkapital gesamt** | **279,86** |
| — Kurzfristige Verbindlichkeiten | 136,66 |
| — Langfristige Verbindlichkeiten | 143,20 |
| — Langfristige Schulden & Leasing | 48,13 |
| **Eigenkapital** | **414,37** |
| — Einbehaltene Gewinne | 302,53 |
| — Grundkapital | 115,07 |

### Liquidität & Verschuldung:

| Kennzahl | Wert |
|---|---|
| Current Ratio | 1,28 |
| Working Capital | 38,67 Mrd. |
| Gesamtverschuldung | 56,97 Mrd. |
| Nettoverschuldung | 8,16 Mrd. |
| Debt/Equity | 30,27 % |
| Tangibler Buchwert | 275,38 Mrd. |

**Beurteilung:** Die Bilanz ist außerordentlich solide. Die Nettoverschuldung von nur $8,16 Mrd. bei einem EBITDA von $184 Mrd. (TTM) ergibt ein **Net Debt/EBITDA von 0,04x** – faktisch schuldenfrei. Microsoft hat enorme finanzielle Flexibilität.

---

## 5. CASHFLOW-ANALYSE (QUARTALSWEISE)

| Quartal | Operativer CF (Mrd.) | CapEx (Mrd.) | FCF (Mrd.) | SBC (Mrd.) | Aktienrückkäufe (Mrd.) | Dividenden (Mrd.) |
|---|---|---|---|---|---|---|
| Q3 GJ2026 | 46,68 | -30,88 | 15,80 | 3,08 | -4,63 | -6,76 |
| Q2 GJ2026 | 35,76 | -29,88 | 5,88 | 3,22 | -7,42 | -6,76 |
| Q1 GJ2026 | 45,06 | -19,39 | 25,66 | 2,98 | -5,65 | -6,17 |
| Q4 GJ2025 | 42,65 | -17,08 | 25,57 | 3,07 | -4,55 | -6,17 |
| Q3 GJ2025 | 37,04 | -16,75 | 20,30 | 2,98 | -4,78 | -6,17 |

### TTM-Cashflow (Q4 GJ2025 – Q3 GJ2026):

| Position | TTM (Mrd.) |
|---|---|
| Operativer Cashflow | 170,14 |
| CapEx | -97,23 |
| **Free Cash Flow** | **72,92** |
| SBC | 12,36 |
| Aktienrückkäufe | -22,25 |
| Dividenden | -25,86 |

**Hinweis:** Der in der Vendor-Übersicht angegebene FCF-Wert von $37,01 Mrd. weicht vom hier berechneten TTM-FCF ($72,92 Mrd.) ab. Dies dürfte auf eine abweichende Periodenabgrenzung (möglicherweise GJ2025 annual) zurückzuführen sein. Für diesen Bericht wird der aus den Quartalsdaten aggregierte TTM-FCF verwendet.

### CapEx-Explosion — DAS KERNTHEMA:

Die Investitionsausgaben haben sich nahezu **verdoppelt**:

| Quartal | CapEx |
|---|---|
| Q3 GJ2025 | $16,75 Mrd. |
| Q4 GJ2025 | $17,08 Mrd. |
| Q1 GJ2026 | $19,39 Mrd. |
| Q2 GJ2026 | $29,88 Mrd. |
| Q3 GJ2026 | $30,88 Mrd. |

Dieser massive Anstieg ist mit höchster Wahrscheinlichkeit auf den Ausbau der KI- und Cloud-Infrastruktur (Azure-Rechenzentren, GPU-Cluster) zurückzuführen. Die FCF-Marge wird hierdurch erheblich komprimiert:

| Quartal | FCF-Marge (FCF/Umsatz) |
|---|---|
| Q3 GJ2025 | 29,0 % |
| Q4 GJ2025 | 33,4 % |
| Q1 GJ2026 | 33,0 % |
| Q2 GJ2026 | 7,2 % |
| Q3 GJ2026 | 19,1 % |

### SBC-Analyse (TTM):

| Kennzahl | Wert |
|---|---|
| SBC/Umsatz | 3,88 % |
| SBC/FCF | 16,94 % |
| SBC/Operatives Ergebnis (non-GAAP) | nicht verfügbar |

SBC ist ein realer wirtschaftlicher Verwässerungsfaktor, auch wenn er nicht-liquid ist. Mit 16,9 % des TTM-FCF ist die Belastung spürbar, aber im Technologievergleich moderat.

---

## 6. RENTABILITÄTSKENNZAHLEN

| Kennzahl | Wert |
|---|---|
| Eigenkapitalrendite (ROE) | 34,0 % |
| Gesamtkapitalrendite (ROA) | 14,8 % |
| Nettomarge | 39,3 % |
| Operative Marge | 46,3 % (Vendor) |

Microsoft gehört zu den profitabelsten Unternehmen der Welt. Die ROE von 34 % wird durch die konservative Bilanz (niedrige Verschuldung) zusätzlich untermauert.

---

## 7. AKTIONÄRSFREUNDLICHE MAẞNAHMEN

| Maßnahme | TTM-Wert |
|---|---|
| Aktienrückkäufe | $22,25 Mrd. |
| Dividenden | $25,86 Mrd. |
| **Gesamtausschüttung** | **$48,11 Mrd.** |

Das entspricht 66 % des TTM-FCF und 38 % des TTM-Nettoergebnisses.

---

## 8. ZUSAMMENFASSENDE BEWERTUNG

### Stärken:
1. **Umsatzwachstum von +18 % YoY** – robust und beschleunigend
2. **Weltklasse-Margen** – 39 % Nettomarge, 46 % operative Marge
3. **Praktisch schuldenfrei** – Net Debt von nur $8 Mrd.
4. **Starke Cash-Generierung** – $170 Mrd. operativer Cashflow (TTM)
5. **Umfangreiche Aktionärsrückflüsse** – $48 Mrd. TTM

### Risiken & Warnsignale:
1. **CapEx-Verdopplung** – FCF wird massiv komprimiert; Investoren müssen auf ROI dieser Investitionen achten
2. **Q2 GJ2026 Non-Operating Income** – $9,9 Mrd. Sondererträge verzerren das Bild
3. **Forward-KGV von 21,8** – moderat, aber abhängig von unbestätigten Konsensschätzungen ($19,35 EPS)
4. **Kurs unter 200-Tage-Linie** – technische Schwäche; Erholung fragil
5. **SBC von $12,4 Mrd./Jahr** – Verwässerungseffekt, wenn auch im Rahmen

---

## 9. KENNZAHLEN-TABELLE

| Kategorie | Kennzahl | Wert | Periode | Datenquelle | Verlässlichkeit |
|---|---|---|---|---|---|
| Unternehmen | Marktkapitalisierung | 3,13 Bio. USD | 15.05.2026 | Vendor | Hoch |
| Bewertung | KGV (TTM) | 25,13 | TTM | Vendor/GAAP | Hoch |
| Bewertung | Forward KGV | 21,80 | Forward | Vendor/Konsens | Mittel (Konsens ungeprüft) |
| Bewertung | Forward EPS | $19,35 | Forward | Vendor/Konsens | Mittel |
| Bewertung | PEG Ratio | 1,26 | — | Vendor | Mittel |
| Bewertung | Kurs/Buchwert | 7,56 | Stichtag | Vendor | Hoch |
| Profitabilität | Nettomarge | 39,3 % | TTM | GAAP, Vendor | Hoch |
| Profitabilität | Operative Marge | 46,3 % | TTM | GAAP, Vendor | Hoch |
| Profitabilität | ROE | 34,0 % | TTM | GAAP, Vendor | Hoch |
| Profitabilität | ROA | 14,8 % | TTM | GAAP, Vendor | Hoch |
| Wachstum | Umsatzwachstum YoY | +18,3 % | Q3 GJ2026 vs. Q3 GJ2025 | GAAP | Hoch |
| Cashflow | Op. Cashflow (TTM) | 170,14 Mrd. | Q4 GJ25–Q3 GJ26 | GAAP | Hoch |
| Cashflow | CapEx (TTM) | -97,23 Mrd. | Q4 GJ25–Q3 GJ26 | GAAP | Hoch |
| Cashflow | FCF (TTM) | 72,92 Mrd. | Q4 GJ25–Q3 GJ26 | Berechnet | Mittel (Abw. zu Vendor) |
| Cashflow | SBC (TTM) | 12,36 Mrd. | Q4 GJ25–Q3 GJ26 | GAAP | Hoch |
| Cashflow | SBC/Umsatz | 3,88 % | TTM | Berechnet | Mittel |
| Cashflow | SBC/FCF | 16,94 % | TTM | Berechnet | Mittel |
| Bilanz | Bilanzsumme | 694,23 Mrd. | 31.03.2026 | GAAP | Hoch |
| Bilanz | Eigenkapital | 414,37 Mrd. | 31.03.2026 | GAAP | Hoch |
| Bilanz | Gesamtverschuldung | 56,97 Mrd. | 31.03.2026 | GAAP | Hoch |
| Bilanz | Nettoverschuldung | 8,16 Mrd. | 31.03.2026 | GAAP | Hoch |
| Bilanz | Current Ratio | 1,28 | 31.03.2026 | GAAP | Hoch |
| Bilanz | Debt/Equity | 30,27 % | 31.03.2026 | GAAP | Hoch |
| Ausschüttung | Rückkäufe (TTM) | 22,25 Mrd. | TTM | GAAP | Hoch |
| Ausschüttung | Dividenden (TTM) | 25,86 Mrd. | TTM | GAAP | Hoch |
| Ausschüttung | Dividendenrendite | 0,86 % | — | Vendor | Mittel |
| Markt | 52-Wochen-Hoch | $555,45 | — | Vendor | Hoch |
| Markt | 52-Wochen-Tief | $356,28 | — | Vendor | Hoch |
| Markt | 200-Tage-Durchschnitt | $463,13 | — | Vendor | Hoch |
| Markt | Beta | 1,09 | — | Vendor | Mittel |

---

## 10. FAZIT FÜR TRADER

Microsoft präsentiert sich fundamental in einer **Transformationsphase**: Der Konzern investiert in noch nie dagewesenem Umfang in Infrastruktur (vermutlich KI/Cloud), was den Free Cash Flow kurzfristig stark belastet. Der operative Cashflow bleibt mit $170 Mrd. TTM jedoch extrem robust. Das Umsatzwachstum von 18 % YoY deutet darauf hin, dass die Nachfrage nach Cloud- und KI-Diensten die Investitionen rechtfertigen könnte.

**Kritische offene Punkte (erfordern SEC/IR-Verifikation):**
- Forward-EPS-Quelle (Management-Guidance vs. Konsens?)
- FCF-Definition und korrekte TTM-Abgrenzung ($37 Mrd. vs. $73 Mrd.)
- Segmentaufteilung (Azure-Wachstum separat?)
- Non-GAAP-Bereinigungen

**Ohne diese Verifikation bleibt die fundamentale Einschätzung: SOLIDE mit CAPEX-RISIKO.** Die hohe Profitabilität und die praktische Schuldenfreiheit bieten einen starken Sicherheitspuffer, während die massive Investitionsoffensive das langfristige Wachstum untermauern soll – vorausgesetzt, die Rendite auf das investierte Kapital materialisiert sich.

---

*Anmerkung: Dieser Bericht ist ein Entwurf auf Basis von Vendor-Daten (yfinance). Für eine endgültige Anlageentscheidung sind SEC-Filings (10-Q, 10-K) und offizielle IR-Materialien von Microsoft als Primärquellen heranzuziehen.*

<!-- PAGEBREAK -->

### Trader-Sicht

**Umsetzung**: Halten

**Begründung**: Der Research-Plan sieht vor, das aktuelle MSFT-Exposure bei etwa 409 $ zu halten, und die Evidenz stützt Zurückhaltung. Das Todeskreuz (Death Cross) bleibt strukturell intakt, wobei der 50-Tage-GD (399 $) um 63 $ unter dem 200-Tage-GD (462 $) notiert – ein historisch breiter Spread, der auf anhaltende institutionelle Distribution hindeutet und nicht auf ein Setup für eine V-förmige Erholung. Der vollständige Ausstieg der Gates Foundation aus ihren verbleibenden 7,7 Mio. Aktien sowie die Reduzierung von Tiger Global mit einer Portfolioauswirkung von 4,85 % untermauern die institutionelle Vorsicht, während die Kompression der Free-Cashflow-Marge von 33 % auf 19 % bei gleichzeitigem Ausblick des Managements auf höhere Investitionsausgaben (CapEx) dem bärischen Szenario im Hier und Jetzt mehr Gewicht verleiht als der bullischen These einer KI-Monetarisierung. Der Bollinger Squeeze warnt vor einer unmittelbar bevorstehenden scharfen Bewegung, die Richtung ist jedoch unbestätigt – frisches Kapital vor der Veröffentlichung der Q4-Zahlen des Geschäftsjahres 2025 einzusetzen, birgt das Risiko, auf der falschen Seite erwischt zu werden. Halten bewahrt Optionalität, bis entweder ein bestätigter Ausbruch über den 200-Tage-GD (etwa 462 $) erfolgt oder sich die Free-Cashflow-Marge im nächsten Quartalsbericht stabilisiert.

**Positionsgröße**: Aktuelle Portfoliogewichtung beibehalten; nicht allein aufgrund von Ackman-Enthusiasmus über die neutrale Gewichtung hinausgehen. Falls die Position bereits übergewichtet ist, sollte eine Reduzierung auf neutral in Abhängigkeit von steuerlichen und portfoliospezifischen Rahmenbedingungen erwogen werden.

**Finale Transaktionsausgabe**: **HALTEN**

<!-- PAGEBREAK -->

### Investment-Plan

**Einordnung**: Halten

**Begründung**: Es handelte sich um eine ausgewogene Debatte. Der Bulle führte überzeugende Argumente für Microsofts KI-getriebenes Wachstum an (18 % Umsatzwachstum, 46 % operative Marge, nahezu keine Nettoverschuldung, Forward-KGV von rund 21,8x) sowie Bill Ackmans engagementreichen Einstieg. Doch der Bär landete härtere Treffer bei den gegenwartsbezogenen Beweisen: Das Todeskreuz ist nicht „vorbei“ – die 50-Tage-Linie (399 USD) liegt 63 USD unter der 200-Tage-Linie (462 USD), eine historisch große Spanne, die auf anhaltende institutionelle Distribution hindeutet, nicht auf eine schnelle V-förmige Erholung. Der Verkauf der *letzten* 7,7 Mio. Aktien durch die Gates-Stiftung ist ein vollständiger Ausstieg des philanthropischen Vehikels des Gründers, keine routinemäßige Umschichtung. Die Reduzierung von Tiger Global mit einer Portfolioauswirkung von 4,85 % bei gleichzeitigem Kauf von Intel verstärkt das institutionelle Vorsichtssignal. Vor allem hat sich die FCF-Marge tatsächlich von 33 % auf 19 % verringert, und das Management stellt weiter steigende Investitionsausgaben in Aussicht – die Behauptung des Bullen, dies sei „vorübergehend“, beruht auf unbewiesener KI-Monetarisierung. Zudem ist der nicht-operative Gewinn von 9,9 Mrd. USD, der das EPS-Wachstum schönte, eine reale buchhalterische Verzerrung. Makro-Gegenwind (Rezessionsrisiko, steigende Energiekosten für GPU-intensive Rechenzentren) erhöht den kurzfristigen Druck.

Der Bulle hat nicht Unrecht mit Microsofts langfristiger KI-Positionierung, doch das Argument erfordert den Blick durch ein Tal, dessen Tiefe und Dauer unbekannt sind. Die Warnungen des Bären vor technischen Schäden, institutionellen Abflüssen und FCF-Erosion sind *jetzt* greifbar. Keine Seite dominiert eindeutig – daher wäre ein Engagement in eine der beiden Richtungen verfrüht. Aktuelle Position beibehalten; weder aufstocken noch reduzieren.

**Operative Schritte**: 1. **Bestehende MSFT-Position beibehalten** – keine neuen Käufe oder Verkäufe auf aktuellem Niveau (~409 USD).
2. **Einen disziplinierten Einstiegsrahmen anwenden** anstelle von „aggressivem Kaufen“:
- *Auslöser für Aufstockung*: Bestätigter Ausbruch über die 200-Tage-Linie (~462 USD) bei überdurchschnittlichem Volumen oder ein erfolgreicher Retest der Zone 380–400 USD mit sich verbesserndem MACD und RSI.
- *Auslöser für Reduzierung*: Ein entscheidender Schlusskurs unter 381 USD (nächste wichtige Unterstützung) bei sich beschleunigendem Rückgang der FCF-Marge im nächsten Quartalsbericht.
3. **Q4 FY2025-Quartalszahlen beobachten** auf drei spezifische Signale vor einer Neubewertung: (a) ob sich die FCF-Marge stabilisiert oder weiter in Richtung 10 % fällt; (b) etwaige Aufwärtsrevisionen der KI-bezogenen Umsatzhochrechnungen (Azure OpenAI, Copilot-Lizenzen); (c) ob die Verzerrung durch den nicht-operativen Gewinn verschwindet und einen sauberen Blick auf das operative EPS ermöglicht.
4. **Positionsgröße**: MSFT auf aktuellem Portfoliogewicht belassen. Die Position nicht allein aufgrund von Ackman-Enthusiasmus über das neutrale Gewicht ansteigen lassen. Falls die Position bereits übergewichtet ist, Reduzierung auf neutral erwägen – jedoch nur, wenn steuerliche und portfoliobezogene Rahmenbedingungen dies stützen.
5. **Absicherungsüberlegung**: Für risikoaverse Konten einen Protective Put oder eine Collar-Struktur mit Verfall nach dem nächsten Quartalsbericht in Betracht ziehen, da der Bollinger-Squeeze eine scharfe Bewegung impliziert, deren Richtung ungewiss bleibt.

<!-- PAGEBREAK -->

### Finale Entscheidung

**Rating**: Hold

**Kurzfazit**: Bestehende MSFT-Position zu aktuellem Gewicht halten. Keine Aufstockung, keine Reduzierung. Der neutrale Analyst hat überzeugend dargelegt, dass das Signal-Rausch-Verhältnis derzeit außergewöhnlich niedrig ist: Death Cross und fallender MACD sprechen für anhaltende Schwäche, während die Erholung vom $356-Tief und die 18%ige Umsatzdynamik für eine Bodenbildung argumentieren. Die institutionellen Flüsse sind widersprüchlich (Ackman kauft, Gates Foundation verkauft vollständig, Tiger Global reduziert), und die fundamentale Lage ist im Übergang – 18% Umsatzwachstum und eine Festungsbilanz stehen einer FCF-Margenkompression von 33% auf 19% gegenüber. Bei einem Kurs von ~$409 ist Abwarten die einzig rationale Kapitalallokation. Klare Trigger definieren: Ausbruch über $414 mit Volumen öffnet den Weg zu $433 und $462; Bruch unter $399 öffnet den Weg zu $381. Vor dem Q4 FY2025-Druck und dem unbestätigten Richtungsausbruch des Bollinger Squeeze ist Stillstand die disziplinierteste Entscheidung.

**Investment-These**: Die Hold-Entscheidung stützt sich auf vier strukturell uneindeutige Signalkomplexe, die der neutrale Analyst in der Debatte überzeugend herausgearbeitet hat:

**1. Technisches Bild – genuin ambivalent:** Der Death Cross ist kein „Rückspiegel", wie der Aggressive behauptet, sondern ein aktives Signal: Die 50-Tage-SMA ($399) notiert $63 unter der 200-Tage-SMA ($462), die Spanne von 13,6% weitet sich gemäß technischem Report noch aus. Der MACD hat seit Ende April 70% seiner Dynamik eingebüßt und steuert auf einen bärischen Crossover zu. Der Kurs liegt unter der 10-EMA. Das spricht für fortgesetzte institutionelle Distribution. Gleichzeitig hat sich der Kurs 15% vom Paniktief bei $356 erholt, notiert über der 50-Tage-SMA, und der RSI steht bei neutralen 57,90. Der neutrale Analyst hat Recht: Weder die „Akkumulations"-These des Aggressiven noch die „strukturell bärische" Lesart des Konservativen ist durch die Daten gedeckt. Der Bollinger Squeeze signalisiert einen bevorstehenden scharfen Ausbruch, dessen Richtung unbestätigt ist – der Kurs tendiert zur unteren Bandbegrenzung, was das kurzfristige Risiko asymmetrisch nach unten neigt.

**2. Institutionelle Flüsse – widersprüchlich:** Die Gates Foundation hat ihre letzten 7,7 Millionen Aktien vollständig abgestoßen – ein Totalausstieg des gründerverbundenen philanthropischen Vehikels, kein routinemäßiges Rebalancing. Tiger Global reduzierte um 4,85% Portfolio-Impact und rotierte parallel in Intel, was auf eine strategische Präferenz für Hardware-Picks-and-Shovels hindeuten könnte. Dem steht Bill Ackmans hochkonzentrierter Neuaufbau einer Kernposition gegenüber – Pershing Square führt nur 11 Positionen und agiert mit jahrzehntelangem Track Record. Der neutrale Analyst hat hier die einzig haltbare Synthese: Widersprüchliche Signale smarter Allokatoren mit unterschiedlichen Zeithorizonten und Mandaten. Keine Seite dominiert.

**3. Fundamentale Übergangsphase – FCF-Kompression vs. Bilanzstärke:** Die FCF-Marge ist von 33% auf 19% komprimiert – das ist kein „schönes" temporäres Phänomen, wie der Aggressive behauptet, sondern eine reale Cashflow-Verschlechterung, die durch Management-Guidance für weiter steigende CapEx ($30,88 Mrd. im letzten Quartal) untermauert wird. Der konservative Analyst hat zudem korrekt auf die $9,9 Mrd. nicht-operativen Erträge hingewiesen, die das Q2-Nettoergebnis aufgebläht haben – die Ertragsqualität ist geringer als die Headline-Zahlen suggerieren. Andererseits verfügt Microsoft über $170 Mrd. operativen Cashflow (TTM), lediglich $8 Mrd. Nettoverschuldung, 39% Nettomargen und 18% Umsatzwachstum. Der neutrale Analyst hat hier präzise formuliert: Die Frage ist nicht, ob das Unternehmen diesen CapEx-Zyklus überleben kann (das kann es), sondern ob die Renditen aus der KI-Infrastruktur materialisieren. Der Forward-KGV von 21,8x (basierend auf unverifizierten Konsens-EPS von $19,35) bietet keinen ausreichenden Sicherheitsabschlag für diese Ungewissheit – weder genug, um aggressiv aufzustocken, noch teuer genug, um panisch zu verkaufen.

**4. Makrokontext – reale, aber unscharfe Bedrohungen:** Inflationsängste, steigende Energiepreise ($4,39 für Öl), El-Erians Rezessionswarnung und Trump-Xi-Spannungen sind keine „transienten Wackler", wie der Aggressive sie abtut. Microsofts China-Exposure via Azure, LinkedIn und Windows-OEM macht das Unternehmen verwundbar. Der Konservative überspannt den Bogen jedoch, wenn er den Sturz von $555 auf $356 als Blaupause für den nächsten Makroschock präsentiert – Unternehmenssoftware mit 39% Nettomarge und missionskritischen Produkten übersteht Abschwünge besser als der Konservative impliziert. Der neutrale Analyst hat hier den ausgewogensten Standpunkt: Makrobedrohungen sind real, aber Microsofts spezifische Exposition ist diskutabel.

**Fazit:** Hold ist die einzig intellektuell ehrliche Position. Der Aggressive verwechselt Risikotoleranz mit Mut, der Konservative Vorsicht mit Weisheit. Beide projizieren Temperament auf die Daten. Die Evidenz rechtfertigt weder eine Übergewichtung noch eine Untergewichtung. Stillstand bei definierten Triggern für beide Richtungen bewahrt optionality, ohne das Portfolio einem unverhältnismäßigen Gap-Risiko (ATR $11 = 2,7% Tagesschwankungen; 1,5x ATR Gap = $16,59) auszusetzen.

**Time Horizon**: 3-6 Monate (Neubewertung nach Q4 FY2025 Earnings Print)

<!-- PAGEBREAK -->

### Pipeline-Source-Ledger

Deterministisch aus Tool-Ausgaben erfasst. Primärquellen bleiben stärker als Vendor-Daten; fehlende SEC/IR-Belege bleiben Review-Punkte.

| source_id | source_type | asof | period_type | formula_id |
| --- | --- | --- | --- | --- |
| callback:get_stock_data:msft:2026-05-15:ohlcv_vendor_raw | vendor:yfinance | 2026-05-15 | daily | ohlcv_vendor_raw |
| callback:get_indicators:msft:2026-05-15:technical_indicator:close_50_sma:lookback_60 | vendor:yfinance | 2026-05-15 | calculated | technical_indicator:close_50_sma:lookback_60 |
| callback:get_indicators:msft:2026-05-15:technical_indicator:close_200_sma:lookback_60 | vendor:yfinance | 2026-05-15 | calculated | technical_indicator:close_200_sma:lookback_60 |
| callback:get_indicators:msft:2026-05-15:technical_indicator:macd:lookback_60 | vendor:yfinance | 2026-05-15 | calculated | technical_indicator:macd:lookback_60 |
| callback:get_indicators:msft:2026-05-15:technical_indicator:close_10_ema:lookback_60 | vendor:yfinance | 2026-05-15 | calculated | technical_indicator:close_10_ema:lookback_60 |
| callback:get_indicators:msft:2026-05-15:technical_indicator:rsi:lookback_60 | vendor:yfinance | 2026-05-15 | calculated | technical_indicator:rsi:lookback_60 |
| callback:get_indicators:msft:2026-05-15:technical_indicator:boll_lb:lookback_60 | vendor:yfinance | 2026-05-15 | calculated | technical_indicator:boll_lb:lookback_60 |
| callback:get_indicators:msft:2026-05-15:technical_indicator:boll_ub:lookback_60 | vendor:yfinance | 2026-05-15 | calculated | technical_indicator:boll_ub:lookback_60 |
| callback:get_indicators:msft:2026-05-15:technical_indicator:atr:lookback_60 | vendor:yfinance | 2026-05-15 | calculated | technical_indicator:atr:lookback_60 |
| callback:get_news:msft:2026-05-15:get_news:raw | vendor:yfinance | 2026-05-15 | event_window | get_news:raw |
| callback:get_global_news:msft:2026-05-15:get_global_news:raw | vendor:yfinance | 2026-05-15 | event_window | get_global_news:raw |
| callback:get_cashflow:msft:2026-05-15:cashflow_vendor_raw | vendor:yfinance | 2026-05-15 | quarterly | cashflow_vendor_raw |
| callback:get_balance_sheet:msft:2026-05-15:balance_sheet_vendor_raw | vendor:yfinance | 2026-05-15 | balance_sheet_spot | balance_sheet_vendor_raw |
| callback:get_income_statement:msft:2026-05-15:income_statement_vendor_raw | vendor:yfinance | 2026-05-15 | quarterly | income_statement_vendor_raw |
| callback:get_fundamentals:msft:2026-05-15:fundamentals_vendor_raw | vendor:yfinance | 2026-05-15 | mixed | fundamentals_vendor_raw |
