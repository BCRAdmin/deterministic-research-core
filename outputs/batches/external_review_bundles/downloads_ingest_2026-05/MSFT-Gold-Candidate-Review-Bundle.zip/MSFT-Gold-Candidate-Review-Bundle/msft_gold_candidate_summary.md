# MSFT Gold Candidate Summary

- Status: `manual_review`
- Rating: Pipeline `Hold`; Dashboard intern `Hold`; externe Anzeige `Manual Review / Hold Pending Primary Evidence`; Public Rating `null`
- Quality Score: `75`
- Quality Gate: `pass`
- current company_archetype: `MEGA_CAP_PLATFORM`
- current external_display_rating: `Manual Review / Hold Pending Primary Evidence`
- Deep-Tech Risk Profile aktiv: `nein`
- Valuation/Sensitivity vorhanden: `ja`
- Action Triggers vorhanden: `ja`
- Interne Systemsprache gefunden: `ja`
- Empfehlung: `manual_review`

## Aktuelle KPIs im Haupttext

Der MSFT-Run weist eine Marktkapitalisierung von 3,13 Billionen USD aus. Die Q3-GJ2026-Revenue liegt laut Dossier bei 82,89 Mrd. USD, die TTM-Revenue bei 318,27 Mrd. USD und das Umsatzwachstum Q3 GJ2026 gegenüber Q3 GJ2025 bei 18,3 %. Das operative TTM-Ergebnis beträgt 148,96 Mrd. USD, der operative Cashflow 170,14 Mrd. USD und der aggregierte TTM-Free-Cash-Flow 72,92 Mrd. USD. Cash und kurzfristige Anlagen werden mit 78,23 Mrd. USD angegeben, die Nettoverschuldung mit 8,16 Mrd. USD. Die Bewertung liegt im Dossier bei einem KGV von 25,13 und einem Forward-KGV von 21,80; die FCF-Kompression durch CapEx bleibt der zentrale Review-Punkt.

## Kurzer Befund

MSFT ist aktuell als `MEGA_CAP_PLATFORM` klassifiziert. Der Run bleibt `manual_review`, weil die harten Finanzkennzahlen im Evidence Report vendor-basiert und ohne aktuelle SEC/IR-Primärbelege markiert sind. Die externe Anzeige ist durchgängig `Manual Review / Hold Pending Primary Evidence`.

## False Positive Check

`SPECULATIVE_DEEP_TECH_EARLY_COMMERCIAL` war ein früherer False Positive und ist nicht aktueller Status. Die frühere bearish-preliminary Anzeige ist ebenfalls behoben und nicht aktuell.

## Diagnostics

Gefundene interne Systemsprache:

- `Deep-Modell`
- `Provider:`
- `Quick-Modell`
- `Run-Verzeichnis`
- `TradingAgents`
- `ollama`
