# publish_report.md - Nicht freigegeben

Für diesen MSFT-Run wurde kein normaler `publish_report.md` erzeugt.

- Ticker: MSFT
- Run: 20260516-144258-msft-6fdeaa7c
- review_status: `manual_review`
- publishable: `false`
- internal_rating: `Hold`
- public_rating: `null`
- external_display_rating: `Manual Review / Hold Pending Primary Evidence`
- company_archetype: `MEGA_CAP_PLATFORM`
- Grund: aktueller Run steht auf Manual Review, weil harte Finanzkennzahlen im Evidence Report vendor-basiert und ohne aktuelle SEC/IR-Primärbelege markiert sind. Es liegt kein Deep-Tech- oder Preliminary-Underweight-Fall vor.

Diese Datei ist ein Review-Hinweis für das Gold-Candidate-Bundle und kein Public-Report.
