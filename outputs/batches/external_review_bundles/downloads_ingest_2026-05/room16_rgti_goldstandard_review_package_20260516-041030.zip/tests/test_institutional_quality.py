from datetime import date, datetime
from pathlib import Path

from tradingagents.quality import (
    AccountingBasis,
    DataPacket,
    InstitutionalRating,
    MANUAL_REVIEW_DISPLAY_RATING,
    CompanyArchetype,
    Metric,
    PeriodType,
    Source,
    SourceTier,
    SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE,
    assess_speculative_deep_tech_profile,
    calculate_fcf,
    calculate_net_cash,
    calculate_sbc_ratios,
    run_institutional_regression_suite,
    validate_company_defined_fcf,
    validate_data_packet,
    validate_earnings_gap_explanation,
    validate_forward_valuation,
    validate_news_causality,
    validate_no_news_fallback,
    validate_price_basis,
    validate_rating_action,
    validate_reentry_ladder,
    validate_sbc_quality,
    validate_scenario_probabilities,
    validate_stop_loss,
    validate_ttm_sum,
)


def test_ddog_long_stop_above_price_blocks():
    result = validate_stop_loss(position_type="long", current_price=132, stop_loss=140)
    assert result.blocked
    assert "invalid_long_stop_loss" in result.blocker_codes()


def test_nvda_ttm_fcf_mismatch_blocks():
    result = validate_ttm_sum([26.19, 13.47, 22.12, 34.90], 58.1)
    assert result.blocked
    assert "ttm_mismatch" in result.blocker_codes()


def test_mdb_causality_date_mismatch_warns():
    result = validate_news_causality(
        news_date=date(2026, 4, 23),
        price_move_date=date(2026, 4, 30),
        causality_claimed=True,
    )
    assert not result.blocked
    assert [issue.code for issue in result.issues] == ["news_causality_not_verified"]


def test_no_news_without_fallback_blocks():
    result = validate_no_news_fallback([], [])
    assert result.blocked
    assert "no_news_without_fallback" in result.blocker_codes()


def test_sell_with_trim_and_core_hold_blocks():
    result = validate_rating_action(
        InstitutionalRating.SELL,
        "Reduce 20-30% but hold core position for long-term investors.",
    )
    assert result.blocked
    assert "rating_action_sell_vs_trim" in result.blocker_codes()


def test_metric_engine_calculates_fcf_sbc_and_net_cash():
    assert calculate_fcf(operating_cash_flow=100, capex=25)["value"] == 75
    assert calculate_fcf(operating_cash_flow=100, capex=25, finance_lease_principal=5)["company_definition_used"]
    assert calculate_net_cash(cash_and_equivalents=50, marketable_securities=20, debt=15)["value"] == 55
    assert calculate_sbc_ratios(sbc=10, revenue=100, fcf=25, non_gaap_operating_income=40) == {
        "sbc_to_revenue": 0.1,
        "sbc_to_fcf": 0.4,
        "sbc_to_non_gaap_operating_income": 0.25,
    }


def test_data_packet_requires_metric_source_and_indicator_date_alignment():
    packet = DataPacket(
        ticker="NVDA",
        company_name="NVIDIA Corporation",
        exchange="NASDAQ",
        currency="USD",
        as_of_date=date(2026, 5, 1),
        last_close=250.83,
        last_close_date=date(2026, 4, 30),
        timezone="America/New_York",
        indicators_calculated_through=date(2026, 5, 1),
        sources=[
            Source(
                source_id="sec_10k",
                name="SEC 10-K",
                tier=SourceTier.SEC,
                accessed_at=datetime(2026, 5, 1, 12, 0),
            )
        ],
        metrics=[
            Metric(
                name="Revenue Q4",
                value=68.127,
                unit="USD bn",
                period_type=PeriodType.QUARTER,
                period_end=date(2026, 1, 25),
                accounting_basis=AccountingBasis.GAAP,
                source_id="missing_source",
            )
        ],
    )
    result = validate_data_packet(packet)
    assert result.blocked
    assert set(result.blocker_codes()) == {"indicator_price_date_mismatch", "metric_source_missing"}
    assert "price_basis_post_close_unchecked" in [issue.code for issue in result.issues]


def test_mdb_price_basis_after_report_date_warns_without_post_close_check():
    result = validate_price_basis(
        as_of_date=date(2026, 5, 1),
        last_close_date=date(2026, 4, 30),
        indicators_calculated_through=date(2026, 4, 30),
        post_close_data_checked=False,
    )
    assert not result.blocked
    assert [issue.code for issue in result.issues] == ["price_basis_post_close_unchecked"]


def test_mdb_company_defined_fcf_blocks_if_finance_lease_is_ignored():
    result = validate_company_defined_fcf(
        operating_cash_flow=179.6,
        capex=1.1,
        finance_lease_principal=1.8,
        reported_fcf=178.5,
        company_definition_checked=True,
    )
    assert result.blocked
    assert "company_fcf_definition_mismatch" in result.blocker_codes()


def test_mdb_forward_eps_guidance_gap_requires_discussion():
    result = validate_forward_valuation(
        forward_pe=37.48,
        forward_eps=7.05,
        eps_source_type="consensus_provider",
        eps_period="FY2027",
        eps_basis="non-GAAP",
        management_guidance_low=5.75,
        management_guidance_high=5.93,
        guidance_gap_discussed=False,
    )
    assert not result.blocked
    assert [issue.code for issue in result.issues] == ["forward_eps_guidance_gap_undiscussed"]


def test_forward_pe_without_eps_source_blocks():
    result = validate_forward_valuation(
        forward_pe=37.48,
        forward_eps=None,
        eps_source_type=None,
        eps_period=None,
        eps_basis=None,
    )
    assert result.blocked
    assert "forward_pe_missing_eps_basis" in result.blocker_codes()


def test_mdb_large_gap_cannot_be_explained_as_distribution_only():
    result = validate_earnings_gap_explanation(price_move_pct=-24.0, explanation_terms=["distribution"])
    assert not result.blocked
    assert [issue.code for issue in result.issues] == ["large_gap_missing_fundamental_explanation"]


def test_mdb_reentry_ladder_needs_tactical_trigger_before_late_200_sma():
    result = validate_reentry_ladder(current_price=250.83, tactical_reentry_level=None, strategic_reentry_level=315.0)
    assert not result.blocked
    assert [issue.code for issue in result.issues] == ["reentry_ladder_too_late"]


def test_mdb_underweight_with_core_hold_should_be_tactical():
    result = validate_rating_action(
        InstitutionalRating.UNDERWEIGHT,
        "Reduce 20-30%, hold core position, and re-entry after confirmation.",
    )
    assert not result.blocked
    assert [issue.code for issue in result.issues] == ["rating_action_underweight_should_be_tactical"]


def test_sbc_quality_requires_dilution_and_buyback_context():
    result = validate_sbc_quality(
        sbc=550.5,
        revenue=2460.0,
        fcf=492.6,
        non_gaap_operating_income=456.2,
        diluted_share_count_yoy_change=None,
        buybacks_vs_sbc=None,
    )
    assert not result.blocked
    assert [issue.code for issue in result.issues] == ["sbc_quality_context_missing"]


def test_scenario_probabilities_must_sum_to_100_or_be_qualitative():
    assert validate_scenario_probabilities([50, 30, 10]).issues[0].code == "scenario_probabilities_not_100"
    assert validate_scenario_probabilities([50, 30, 10], qualitative=True).issues == []


def test_institutional_regression_suite_catches_required_cases():
    assert run_institutional_regression_suite().issues == []


def test_rgti_deeptech_regression_is_manual_review_not_publishable():
    report_path = Path(__file__).resolve().parents[1] / "reports/room16/runs/20260515-223522-rgti-e63b8cca/RGTI/complete/2026-05-15-room16-RGTI-complete-dossier.md"
    report_text = report_path.read_text(encoding="utf-8") if report_path.exists() else """
    RGTI is a quantum hardware early commercial story stock. Market cap / revenue is 600x.
    Revenue TTM was 7.09 million, operating income was negative, and FCF was -77.2 million.
    SBC / revenue was 248.4%. Hard financial metrics are vendor-only from yfinance, with no SEC/IR current-period evidence.
    Derivative and warrant fair-value effects helped GAAP net income and the loss narrowed.
    Beta: 1.80. Commercial adoption is limited and not scaled.
    """
    ledger = [
        {"source_type": "vendor:yfinance", "source_id": "revenue_ttm_vendor", "category": "revenue"},
        {"source_type": "vendor:yfinance", "source_id": "free_cash_flow_ttm_vendor", "category": "fcf"},
    ]
    result = assess_speculative_deep_tech_profile(report_text, source_ledger_entries=ledger)
    codes = {issue.code for issue in result.issues}

    assert result.active
    assert result.status == "manual_review"
    assert result.publishable is False
    assert result.external_display_rating == MANUAL_REVIEW_DISPLAY_RATING
    assert result.company_archetype == CompanyArchetype.SPECULATIVE_DEEP_TECH_EARLY_COMMERCIAL
    assert result.archetype_confidence > 0.25
    assert "vendor_only_hard_financial_metrics" in result.archetype_triggered_rules
    assert SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE in codes
    assert "VENDOR_ONLY_HARD_METRICS" in codes
    assert result.quality_score <= 75


def test_rgti_deeptech_missing_accounting_caveat_is_capped():
    report_text = """
    RGTI is a quantum hardware early commercial story stock. Market cap / revenue is 600x.
    Revenue TTM was 7.09 million, operating income was negative, and FCF was -77.2 million.
    SBC / revenue was 248.4%. Hard financial metrics are vendor-only from yfinance, with no SEC/IR current-period evidence.
    Derivative and warrant fair-value effects helped GAAP net income and the loss narrowed.
    Beta: 1.80. Commercial adoption is limited and not scaled.
    """
    ledger = [
        {"source_type": "vendor:yfinance", "source_id": "revenue_ttm_vendor", "category": "revenue"},
        {"source_type": "vendor:yfinance", "source_id": "free_cash_flow_ttm_vendor", "category": "fcf"},
    ]
    result = assess_speculative_deep_tech_profile(report_text, source_ledger_entries=ledger)
    codes = {issue.code for issue in result.issues}

    assert "ACCOUNTING_GAIN_NOT_OPERATING_TURNAROUND" in codes
    assert result.quality_score <= 70


def test_deeptech_orders_without_materiality_section_are_capped():
    text = """
    Quantum defense hardware company. Market cap / revenue is 140x, revenue TTM was 12 million,
    operating income is negative, free cash flow is negative, beta 1.9, and no SEC/IR current-period evidence.
    The report mentions a defense contract, AFRL roadmap milestone, and a new order, but provides no
    quantified materiality bridge for the valuation.
    """
    result = assess_speculative_deep_tech_profile(text, source_ledger_entries=[])
    codes = {issue.code for issue in result.issues}

    assert result.active
    assert "ORDER_MATERIALITY_MISSING" in codes
    assert result.quality_score <= 80


def test_deeptech_technical_dominance_guard_blocks_chart_led_thesis():
    text = """
    Early commercial quantum company. Market cap / revenue is 180x, revenue TTM was 10 million,
    operating income is negative, free cash flow is negative, beta 2.1, and no SEC/IR current-period evidence.
    """
    rating_text = """
    Rating: Underweight. The rating rationale is technical because the chart is below the 200-day SMA.
    The investment thesis is technical because RSI divergence and MACD momentum dominate the setup.
    The decision is technical because support and resistance define the long-term view.
    Fundamentals are not the center of this rating.
    """
    result = assess_speculative_deep_tech_profile(text, source_ledger_entries=[], rating_text=rating_text)

    assert "TECHNICAL_OVERWEIGHT_IN_FUNDAMENTAL_THESIS" in {issue.code for issue in result.issues}


def test_gold_v1_large_cap_primary_evidence_does_not_trigger_deeptech_profile():
    text = """
    GOOGL/SNOW style institutional report with SEC 10-Q and Investor Relations evidence.
    Revenue TTM was 350 billion, operating income was positive, FCF was positive, SBC/revenue was 4%.
    The rating rationale is based on product moat, margin expansion, and cash generation.
    """
    ledger = [
        {"source_type": "SEC", "source_id": "sec_10q_financials", "category": "financials"},
        {"source_type": "IR", "source_id": "ir_release", "category": "revenue"},
    ]
    result = assess_speculative_deep_tech_profile(text, source_ledger_entries=ledger)

    assert not result.active
    assert result.status == "quality_pass"
    assert result.publishable is True


def test_saas_and_real_revenue_high_growth_do_not_trigger_deeptech_archetype():
    snow_text = """
    SNOW is a SaaS consumption company with revenue TTM of 4.5 billion, positive adjusted FCF,
    SEC 10-Q and Investor Relations evidence, and no derivative/warrant fair-value issue.
    Valuation is high but the company has scaled commercial adoption.
    """
    snow_result = assess_speculative_deep_tech_profile(
        snow_text,
        source_ledger_entries=[{"source_type": "SEC", "source_id": "sec_10q_financials", "category": "financials"}],
    )
    real_revenue_text = """
    High-growth industrial technology company with revenue TTM of 800 million, market cap / revenue of 45x,
    operating losses are still present but commercial adoption is scaled and SEC/IR evidence is available.
    """
    real_result = assess_speculative_deep_tech_profile(
        real_revenue_text,
        source_ledger_entries=[{"source_type": "IR", "source_id": "ir_current_financials", "category": "financials"}],
    )

    assert snow_result.company_archetype != CompanyArchetype.SPECULATIVE_DEEP_TECH_EARLY_COMMERCIAL
    assert not snow_result.active
    assert real_result.company_archetype != CompanyArchetype.SPECULATIVE_DEEP_TECH_EARLY_COMMERCIAL
    assert not real_result.active
