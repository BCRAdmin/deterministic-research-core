# Room 16 Quality Report

Created: `2026-05-16T01:59:41`
Run directory: `.runtime/bcr-company-batches/20260515-223522-rgti-e63b8cca`
Verdict: **pass**

## Metrics

- `ticker_count`: `1`
- `premium_required`: `False`
- `raw_source_words`: `6436`
- `complete_md_words`: `6754`
- `complete_docx_words`: `6750`
- `complete_pdf_words`: `7195`
- `complete_pdf_pages`: `21`
- `pdf_text_backend`: `pymupdf`
- `pdf_render_backend`: `pymupdf`
- `batch_id`: `rgti_deeptech_profile_check`
- `research_integrity_verdict`: `review_required`
- `research_integrity_findings`: `[]`
- `institutional_quality_findings`: `[{'severity': 'high', 'type': 'SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE', 'message': 'Speculative deep-tech early-commercial company archetype requires manual review.', 'details': {'company_archetype': 'SPECULATIVE_DEEP_TECH_EARLY_COMMERCIAL', 'trigger_count': 10, 'triggers': {'market_cap_revenue_gt_100': True, 'revenue_ttm_lt_50m': True, 'operating_income_ttm_negative': True, 'free_cash_flow_ttm_negative': True, 'sbc_to_revenue_gt_050': True, 'vendor_only_hard_financial_metrics': True, 'derivative_warrant_fair_value_effects_detected': True, 'no_sec_ir_current_period_evidence': True, 'lumpy_revenue_non_scaled_adoption_language': True, 'share_dilution_yoy_gt_010': False, 'technical_milestone_language_dominates_news': False, 'high_volatility_or_beta_gt_15': True}}}, {'severity': 'high', 'type': 'VENDOR_ONLY_HARD_METRICS', 'message': 'Hard financial metrics rely on vendor/manual evidence without current-period SEC/IR support.', 'details': {'has_sec_ir_current_period_evidence': False}}, {'severity': 'high', 'type': 'ACCOUNTING_GAIN_NOT_OPERATING_TURNAROUND', 'message': 'Net income improvement language needs a clear non-operating fair-value caveat.', 'details': {'required_caveat': 'GAAP net income was helped by non-operating fair-value effects and does not indicate an operating turnaround.'}}, {'severity': 'high', 'type': 'ORDER_MATERIALITY_MISSING', 'message': 'Orders/contracts/roadmap milestones are mentioned without a contract materiality section.', 'details': {'required_items': ['contract value', 'expected delivery/revenue timing', 'contract value vs market cap', 'contract value vs annual revenue', 'recurring vs one-off', 'commercial vs government/research/prototype', 'valuation support assessment']}}]`
- `institutional_regression_suite`: `{'blocked': False, 'issues': []}`
- `status`: `manual_review`
- `publishable`: `False`
- `external_display_rating`: `Manual Review / Preliminary Underweight`
- `internal_rating`: `Preliminary Underweight`
- `public_rating`: `None`
- `review_status`: `manual_review`
- `risk_profiles`: `['SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE']`
- `company_archetype`: `SPECULATIVE_DEEP_TECH_EARLY_COMMERCIAL`
- `archetype_confidence`: `0.833`
- `archetype_triggered_rules`: `['market_cap_revenue_gt_100', 'revenue_ttm_lt_50m', 'operating_income_ttm_negative', 'free_cash_flow_ttm_negative', 'sbc_to_revenue_gt_050', 'vendor_only_hard_financial_metrics', 'derivative_warrant_fair_value_effects_detected', 'no_sec_ir_current_period_evidence', 'lumpy_revenue_non_scaled_adoption_language', 'high_volatility_or_beta_gt_15']`
- `manual_review_reasons`: `['SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE', 'VENDOR_ONLY_HARD_METRICS', 'ACCOUNTING_GAIN_NOT_OPERATING_TURNAROUND', 'ORDER_MATERIALITY_MISSING']`
- `quality_score`: `70`
- `quality_score_caps`: `{'SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE': 75, 'ACCOUNTING_GAIN_NOT_OPERATING_TURNAROUND': 70, 'ORDER_MATERIALITY_MISSING': 80, 'VENDOR_ONLY_HARD_METRICS': 75}`
- `speculative_deep_tech_assessment`: `{'profile': 'SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE', 'company_archetype': 'SPECULATIVE_DEEP_TECH_EARLY_COMMERCIAL', 'archetype_confidence': 0.833, 'archetype_triggered_rules': ['market_cap_revenue_gt_100', 'revenue_ttm_lt_50m', 'operating_income_ttm_negative', 'free_cash_flow_ttm_negative', 'sbc_to_revenue_gt_050', 'vendor_only_hard_financial_metrics', 'derivative_warrant_fair_value_effects_detected', 'no_sec_ir_current_period_evidence', 'lumpy_revenue_non_scaled_adoption_language', 'high_volatility_or_beta_gt_15'], 'active': True, 'trigger_count': 10, 'triggers': {'market_cap_revenue_gt_100': True, 'revenue_ttm_lt_50m': True, 'operating_income_ttm_negative': True, 'free_cash_flow_ttm_negative': True, 'sbc_to_revenue_gt_050': True, 'vendor_only_hard_financial_metrics': True, 'derivative_warrant_fair_value_effects_detected': True, 'no_sec_ir_current_period_evidence': True, 'lumpy_revenue_non_scaled_adoption_language': True, 'share_dilution_yoy_gt_010': False, 'technical_milestone_language_dominates_news': False, 'high_volatility_or_beta_gt_15': True}, 'issues': [{'code': 'SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE', 'severity': 'warning', 'message': 'Speculative deep-tech early-commercial company archetype requires manual review.', 'details': {'company_archetype': 'SPECULATIVE_DEEP_TECH_EARLY_COMMERCIAL', 'trigger_count': 10, 'triggers': {'market_cap_revenue_gt_100': True, 'revenue_ttm_lt_50m': True, 'operating_income_ttm_negative': True, 'free_cash_flow_ttm_negative': True, 'sbc_to_revenue_gt_050': True, 'vendor_only_hard_financial_metrics': True, 'derivative_warrant_fair_value_effects_detected': True, 'no_sec_ir_current_period_evidence': True, 'lumpy_revenue_non_scaled_adoption_language': True, 'share_dilution_yoy_gt_010': False, 'technical_milestone_language_dominates_news': False, 'high_volatility_or_beta_gt_15': True}}}, {'code': 'VENDOR_ONLY_HARD_METRICS', 'severity': 'warning', 'message': 'Hard financial metrics rely on vendor/manual evidence without current-period SEC/IR support.', 'details': {'has_sec_ir_current_period_evidence': False}}, {'code': 'ACCOUNTING_GAIN_NOT_OPERATING_TURNAROUND', 'severity': 'warning', 'message': 'Net income improvement language needs a clear non-operating fair-value caveat.', 'details': {'required_caveat': 'GAAP net income was helped by non-operating fair-value effects and does not indicate an operating turnaround.'}}, {'code': 'ORDER_MATERIALITY_MISSING', 'severity': 'warning', 'message': 'Orders/contracts/roadmap milestones are mentioned without a contract materiality section.', 'details': {'required_items': ['contract value', 'expected delivery/revenue timing', 'contract value vs market cap', 'contract value vs annual revenue', 'recurring vs one-off', 'commercial vs government/research/prototype', 'valuation support assessment']}}], 'status': 'manual_review', 'publishable': False, 'external_display_rating': 'Manual Review / Preliminary Underweight', 'quality_score': 70, 'quality_score_caps': {'SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE': 75, 'ACCOUNTING_GAIN_NOT_OPERATING_TURNAROUND': 70, 'ORDER_MATERIALITY_MISSING': 80, 'VENDOR_ONLY_HARD_METRICS': 75}, 'counts': {'speculative_deep_tech_profile_count': 1, 'accounting_gain_not_operating_turnaround_count': 1, 'vendor_only_hard_metrics_count': 1, 'order_materiality_missing_count': 1, 'technical_overweight_in_thesis_count': 0}}`
- `speculative_deep_tech_profile_count`: `1`
- `accounting_gain_not_operating_turnaround_count`: `1`
- `vendor_only_hard_metrics_count`: `1`
- `order_materiality_missing_count`: `1`
- `technical_overweight_in_thesis_count`: `0`

## Checks

- **PASS** `manifest_completed`: completed
- **PASS** `manifest_has_tickers`: ['RGTI']
- **PASS** `all_tickers_ok`: [{'ticker': 'RGTI', 'status': 'ok', 'elapsed_seconds': 1295.71, 'decision': 'Underweight'}]
- **PASS** `RGTI_log_exists`: /Users/BjornRosinger/Documents/New project/company-dossier-lab/.runtime/bcr-company-batches/20260515-223522-rgti-e63b8cca/results/RGTI/TradingAgentsStrategy_logs/full_states_log_2026-05-14.json
- **PASS** `RGTI_market_report_has_content`: {'chars': 11214, 'min_chars': 1500}
- **PASS** `RGTI_sentiment_report_has_content`: {'chars': 10867, 'min_chars': 1500}
- **PASS** `RGTI_news_report_has_content`: {'chars': 9457, 'min_chars': 1500}
- **PASS** `RGTI_fundamentals_report_has_content`: {'chars': 13852, 'min_chars': 1500}
- **PASS** `RGTI_trader_investment_decision_has_content`: {'chars': 776, 'min_chars': 300}
- **PASS** `RGTI_investment_plan_has_content`: {'chars': 3753, 'min_chars': 300}
- **PASS** `RGTI_final_trade_decision_has_content`: {'chars': 3191, 'min_chars': 300}
- **PASS** `complete_md_exists`: reports/room16/runs/20260515-223522-rgti-e63b8cca/RGTI/complete/2026-05-15-room16-RGTI-complete-dossier.md
- **PASS** `complete_docx_exists`: reports/room16/runs/20260515-223522-rgti-e63b8cca/RGTI/complete/2026-05-15-room16-RGTI-complete-dossier.docx
- **PASS** `complete_pdf_exists`: reports/room16/runs/20260515-223522-rgti-e63b8cca/RGTI/complete/2026-05-15-room16-RGTI-complete-dossier.pdf
- **PASS** `complete_markdown_word_count`: {'words': 6754, 'min_words': 4500}
- **PASS** `complete_markdown_source_coverage`: {'complete_words': 6754, 'raw_source_words': 6436, 'min_ratio': 0.7}
- **PASS** `complete_docx_word_ratio`: {'docx_words': 6750, 'md_words': 6754, 'min_ratio': 0.75}
- **PASS** `complete_pdf_word_ratio`: {'pdf_words': 7195, 'md_words': 6754, 'min_ratio': 0.75}
- **PASS** `complete_pdf_page_range`: {'pages': 21, 'allowed': '8-30', 'ticker_count': 1}
- **PASS** `complete_md_no_forbidden_labels`: []
- **PASS** `complete_md_no_visible_reasoning_leaks`: []
- **PASS** `complete_md_uses_real_german_umlauts`: []
- **PASS** `complete_md_no_broken_glyphs`: []
- **PASS** `complete_md_no_unsupported_render_glyphs`: []
- **PASS** `complete_md_contains_all_tickers`: []
- **PASS** `complete_docx_no_forbidden_labels`: []
- **PASS** `complete_docx_no_visible_reasoning_leaks`: []
- **PASS** `complete_docx_uses_real_german_umlauts`: []
- **PASS** `complete_docx_no_markdown_tokens`: []
- **PASS** `complete_docx_no_broken_glyphs`: []
- **PASS** `complete_docx_no_unsupported_render_glyphs`: []
- **PASS** `complete_docx_contains_all_tickers`: []
- **PASS** `complete_pdf_no_forbidden_labels`: []
- **PASS** `complete_pdf_no_visible_reasoning_leaks`: []
- **PASS** `complete_pdf_uses_real_german_umlauts`: []
- **PASS** `complete_pdf_no_markdown_tokens`: []
- **PASS** `complete_pdf_no_broken_glyphs`: []
- **PASS** `complete_pdf_no_unsupported_render_glyphs`: []
- **PASS** `complete_pdf_contains_all_tickers`: []
- **PASS** `speculative_deep_tech_profile_recorded`: {'active': True, 'status': 'manual_review', 'publishable': False, 'external_display_rating': 'Manual Review / Preliminary Underweight', 'issue_codes': ['SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE', 'VENDOR_ONLY_HARD_METRICS', 'ACCOUNTING_GAIN_NOT_OPERATING_TURNAROUND', 'ORDER_MATERIALITY_MISSING']}
- **PASS** `manual_review_external_display_locked`: {'external_display_rating': 'Manual Review / Preliminary Underweight', 'publishable': False}
- **PASS** `manual_review_has_internal_best_without_publish_report`: {'internal_best_report': 'reports/room16/runs/20260515-223522-rgti-e63b8cca/RGTI/generated/internal_best_report.md', 'publish_report': None}
- **PASS** `research_integrity_no_critical_contradictions`: []
- **PASS** `institutional_quality_no_critical_blockers`: []
- **PASS** `institutional_regression_suite_passes`: {'blocked': False, 'issues': []}
- **PASS** `research_integrity_source_ledger_review_recorded`: {'strict_ready': False, 'findings': [], 'institutional_findings': [{'severity': 'high', 'type': 'SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE', 'message': 'Speculative deep-tech early-commercial company archetype requires manual review.', 'details': {'company_archetype': 'SPECULATIVE_DEEP_TECH_EARLY_COMMERCIAL', 'trigger_count': 10, 'triggers': {'market_cap_revenue_gt_100': True, 'revenue_ttm_lt_50m': True, 'operating_income_ttm_negative': True, 'free_cash_flow_ttm_negative': True, 'sbc_to_revenue_gt_050': True, 'vendor_only_hard_financial_metrics': True, 'derivative_warrant_fair_value_effects_detected': True, 'no_sec_ir_current_period_evidence': True, 'lumpy_revenue_non_scaled_adoption_language': True, 'share_dilution_yoy_gt_010': False, 'technical_milestone_language_dominates_news': False, 'high_volatility_or_beta_gt_15': True}}}, {'severity': 'high', 'type': 'VENDOR_ONLY_HARD_METRICS', 'message': 'Hard financial metrics rely on vendor/manual evidence without current-period SEC/IR support.', 'details': {'has_sec_ir_current_period_evidence': False}}, {'severity': 'high', 'type': 'ACCOUNTING_GAIN_NOT_OPERATING_TURNAROUND', 'message': 'Net income improvement language needs a clear non-operating fair-value caveat.', 'details': {'required_caveat': 'GAAP net income was helped by non-operating fair-value effects and does not indicate an operating turnaround.'}}, {'severity': 'high', 'type': 'ORDER_MATERIALITY_MISSING', 'message': 'Orders/contracts/roadmap milestones are mentioned without a contract materiality section.', 'details': {'required_items': ['contract value', 'expected delivery/revenue timing', 'contract value vs market cap', 'contract value vs annual revenue', 'recurring vs one-off', 'commercial vs government/research/prototype', 'valuation support assessment']}}], 'note': 'Use --strict-research-integrity for publication/client-grade reports.'}
- **PASS** `pdf_render_outputs_created`: {'count': 5, 'dir': 'reports/room16/runs/20260515-223522-rgti-e63b8cca/RGTI/quality/rendered/2026-05-15-20260515-223522-rgti-e63b8cca', 'render_backend': 'pymupdf', 'text_backend': 'pymupdf', 'allow_missing_pdf_renderer': False, 'note': 'Visual PNG render is mandatory for green Room 16 reports unless explicitly bypassed for debugging.'}

## Rendered Pages

- `reports/room16/runs/20260515-223522-rgti-e63b8cca/RGTI/quality/rendered/2026-05-15-20260515-223522-rgti-e63b8cca/complete-page-1.png`
- `reports/room16/runs/20260515-223522-rgti-e63b8cca/RGTI/quality/rendered/2026-05-15-20260515-223522-rgti-e63b8cca/complete-page-2.png`
- `reports/room16/runs/20260515-223522-rgti-e63b8cca/RGTI/quality/rendered/2026-05-15-20260515-223522-rgti-e63b8cca/complete-page-3.png`
- `reports/room16/runs/20260515-223522-rgti-e63b8cca/RGTI/quality/rendered/2026-05-15-20260515-223522-rgti-e63b8cca/complete-page-11.png`
- `reports/room16/runs/20260515-223522-rgti-e63b8cca/RGTI/quality/rendered/2026-05-15-20260515-223522-rgti-e63b8cca/complete-page-21.png`
