# Room 16 Evidence Report

Tickers: `RGTI`
Review status: `manual_review`
Publishable: `false`

## Source Ledger

| source_id | source_type | asof | period_type | formula_id |
| --- | --- | --- | --- | --- |
| callback:get_stock_data:rgti:2026-05-14:ohlcv_vendor_raw | vendor:yfinance | 2026-05-14 | daily | ohlcv_vendor_raw |
| callback:get_indicators:rgti:2026-05-14:technical_indicator:close_50_sma:lookback_60 | vendor:yfinance | 2026-05-14 | calculated | technical_indicator:close_50_sma:lookback_60 |
| callback:get_indicators:rgti:2026-05-14:technical_indicator:macd:lookback_60 | vendor:yfinance | 2026-05-14 | calculated | technical_indicator:macd:lookback_60 |
| callback:get_indicators:rgti:2026-05-14:technical_indicator:macdh:lookback_60 | vendor:yfinance | 2026-05-14 | calculated | technical_indicator:macdh:lookback_60 |
| callback:get_indicators:rgti:2026-05-14:technical_indicator:close_200_sma:lookback_60 | vendor:yfinance | 2026-05-14 | calculated | technical_indicator:close_200_sma:lookback_60 |
| callback:get_indicators:rgti:2026-05-14:technical_indicator:close_10_ema:lookback_60 | vendor:yfinance | 2026-05-14 | calculated | technical_indicator:close_10_ema:lookback_60 |
| callback:get_indicators:rgti:2026-05-14:technical_indicator:boll_ub:lookback_60 | vendor:yfinance | 2026-05-14 | calculated | technical_indicator:boll_ub:lookback_60 |
| callback:get_indicators:rgti:2026-05-14:technical_indicator:boll_lb:lookback_60 | vendor:yfinance | 2026-05-14 | calculated | technical_indicator:boll_lb:lookback_60 |
| callback:get_indicators:rgti:2026-05-14:technical_indicator:rsi:lookback_60 | vendor:yfinance | 2026-05-14 | calculated | technical_indicator:rsi:lookback_60 |
| callback:get_news:rgti:2026-05-14:get_news:raw | vendor:yfinance | 2026-05-14 | event_window | get_news:raw |
| callback:get_global_news:rgti:2026-05-14:get_global_news:raw | vendor:yfinance | 2026-05-14 | event_window | get_global_news:raw |
| callback:get_cashflow:rgti:2026-05-14:cashflow_vendor_raw | vendor:yfinance | 2026-05-14 | quarterly | cashflow_vendor_raw |
| callback:get_balance_sheet:rgti:2026-05-14:balance_sheet_vendor_raw | vendor:yfinance | 2026-05-14 | balance_sheet_spot | balance_sheet_vendor_raw |
| callback:get_income_statement:rgti:2026-05-14:income_statement_vendor_raw | vendor:yfinance | 2026-05-14 | quarterly | income_statement_vendor_raw |
| callback:get_fundamentals:rgti:2026-05-14:fundamentals_vendor_raw | vendor:yfinance | 2026-05-14 | mixed | fundamentals_vendor_raw |

## Guard Issues

- `SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE`: Speculative deep-tech early-commercial company archetype requires manual review.
- `VENDOR_ONLY_HARD_METRICS`: Hard financial metrics rely on vendor/manual evidence without current-period SEC/IR support.
- `ACCOUNTING_GAIN_NOT_OPERATING_TURNAROUND`: Net income improvement language needs a clear non-operating fair-value caveat.
- `ORDER_MATERIALITY_MISSING`: Orders/contracts/roadmap milestones are mentioned without a contract materiality section.
