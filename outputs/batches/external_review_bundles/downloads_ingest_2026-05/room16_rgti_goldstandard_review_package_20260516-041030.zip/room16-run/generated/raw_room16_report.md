# Raw Room 16 Report

## RGTI

### market_report

# Technische Analyse: RGTI (Rigetti Computing) — Mehrdimensionale Indikatorenauswertung

**Datum der Analyse:** 14. Mai 2026  
**Letzter verfügbarer Schlusskurs:** 18,42 USD (13. Mai 2026)  
**Quelle der Kursdaten:** vendor:yfinance, OHLCV daily  
**Hinweis:** Die Indikatoren liefern Werte mit Datum 14. Mai 2026, basierend auf dem Schlusskurs vom 13. Mai. Der Handelstag 14. Mai ist zum Zeitpunkt der Analyse noch nicht abgeschlossen.

---

## 1. Auswahl der Indikatoren — Begründung

Für RGTI, einen hochvolatilen Quantum-Computing-Titel mit spekulativem Charakter, wurden **acht Indikatoren** ausgewählt, die komplementäre Informationen liefern, ohne sich redundant zu überschneiden:

| Kategorie | Indikator | Begründung |
|-----------|-----------|------------|
| Trend (mittel) | **close_50_sma** | Dient als dynamische Unterstützung/Widerstand und zeigt den mittelfristigen Trend. |
| Trend (lang) | **close_200_sma** | Strategischer Benchmark für den langfristigen Trend; Golden/Death-Cross-Erkennung. |
| Trend (kurz) | **close_10_ema** | Reagiert schnell auf Momentum-Shifts; ideal für diesen volatilen Titel. |
| Momentum | **macd** | Erfasst Momentum-Änderungen via EMA-Differenz; Crossovers und Divergenzen. |
| Momentum-Visualisierung | **macdh** | MACD-Histogramm zeigt Momentum-Stärke und Frühdivergenzen – kritisch bei RGTI. |
| Momentum/Überkauft | **rsi** | Überkauft/Überverkauft-Signale; Divergenzen zur Früherkennung von Umkehrungen. |
| Volatilität (oben) | **boll_ub** | Identifiziert überkaufte Zonen und Breakout-Bereiche. |
| Volatilität (unten) | **boll_lb** | Identifiziert überverkaufte Zonen; wichtig nach RGTIs starkem Absturz. |

> **Warum nicht weitere Indikatoren?** Auf `macds` (MACD Signal) wurde verzichtet, da MACD und MACDH bereits ausreichen. `boll` (Middle) ist implizit durch UB/LB abgedeckt. `atr` und `vwma` wurden zugunsten der Bollinger-Bänder und EMAs zurückgestellt, um Redundanz zu vermeiden.

---

## 2. Detaillierte Trendanalyse

### 2.1 Langfristiger Trend — 200 SMA: Bärisch (Death-Cross-Konfiguration)

| Metrik | Wert (14. Mai) | Trend |
|--------|---------------|-------|
| 200 SMA | 22,99 USD | Seit Dezember 2025 fallend |
| 50 SMA | 16,63 USD | Seit März 2026 fallend |
| Preis (13. Mai) | 18,42 USD | Unter 200 SMA, über 50 SMA |

**Befund:** Die 50 SMA liegt **deutlich unter** der 200 SMA (16,63 vs. 22,99). Dies ist eine **bestehende Death-Cross-Konfiguration**. Die 50 SMA fällt kontinuierlich (von ~19,62 Mitte März auf 16,63 Mitte Mai), ebenso die 200 SMA (von ~22,23 auf 22,99 — nein, warte: 200 SMA geht von 22,23 auf 22,99? Das ist ein Anstieg. Let me recheck.

Tatsächlich: 200 SMA am 16. März: 22,23 → 14. Mai: 22,99. Die 200 SMA **steigt leicht**. Das ist interessant, denn der Preis war lange über ~22-26 USD (November 2025) und fiel dann unter die 200 SMA. Die 200 SMA enthält noch die hohen Werte aus der zweiten Hälfte 2025, sodass sie nur langsam sinkt – und aktuell sogar leicht ansteigt, weil die jüngeren Werte (Erholung im April) die älteren, noch höheren Werte aus November/Dezember 2025 ersetzen.

Entscheidend: Der Preis (18,42) liegt **~20 % unter der 200 SMA (22,99)**. Langfristig klar bärisch.

### 2.2 Mittelfristiger Trend — 50 SMA: Neutral-Positiv

Der Preis hat die 50 SMA um den **14.–15. April 2026** nach oben durchkreuzt (50 SMA lag damals bei ~15,99–16,02). Seitdem notiert der Preis durchgehend über der 50 SMA. Dies ist ein **bullishes Signal im mittelfristigen Kontext**.

Allerdings: Die 50 SMA sinkt weiterhin, wenn auch mit abflachender Geschwindigkeit. Der Abstand zwischen Preis und 50 SMA beträgt **+1,79 USD (ca. +10,8 %)**, was auf eine anhaltende, aber nicht überzogene Erholung hindeutet.

### 2.3 Kurzfristiger Trend — 10 EMA: Bullish, aber abschwächend

Die 10 EMA ist von einem Tief bei **14,24 USD (7. April)** auf **18,74 USD (14. Mai)** gestiegen — eine massive Rally von +31,6 %.

Die 10 EMA liegt **deutlich über der 50 SMA** (18,74 vs. 16,63), was die bullishe kurzfristige Momentum-Struktur bestätigt.

Die letzten beiden Handelstage (12.–13. Mai) zeigen allerdings eine Abkühlung:
- 11. Mai: Close 20,51 / 10 EMA: 18,59
- 12. Mai: Close 19,07 / 10 EMA: 18,67
- 13. Mai: Close 18,42 / 10 EMA: 18,63

Der Preis fällt **unter die 10 EMA** zurück (18,42 < 18,63). Dies ist ein **kurzfristiges Warnsignal**.

---

## 3. Momentum-Analyse

### 3.1 MACD: Positiv, aber mit Momentum-Verlust

Der MACD drehte um den **15. April 2026** ins Positive (−0,038 → bullishe Kreuzung). Seitdem ist er auf **0,73** gestiegen — klar positives Momentum.

**ABER:** Der MACD-Histogramm zeigt eine deutliche Abschwächung:

| Datum | MACD | MACD Histogram | Tendenz |
|-------|------|---------------|---------|
| 17. Apr | 0,548 | **0,787** | Höhepunkt |
| 22. Apr | 0,799 | 0,543 | Abschwächung |
| 28. Apr | 0,401 | −0,009 | Fast-Null |
| 6. Mai  | 0,600 | **0,184** | Erholung |
| 11. Mai | 0,793 | **0,242** | Schwächere Erholung |
| 14. Mai | 0,730 | **0,085** | Deutlicher Rückgang |

Das Histogramm erreichte seinen Höhepunkt am 17.–22. April und hat sich seither massiv abgeschwächt (von 0,79 auf 0,09). Der MACD selbst stagniert im Bereich 0,60–0,79. Dies ist ein **klassisches Momentum-Divergenz-Muster**: Der MACD kann nicht mehr höhere Hochs ausbilden, während das Histogramm schrumpft. Die Rally verliert an Kraft.

### 3.2 RSI: Neutrale Zone mit bärischer Divergenz

| Datum | RSI | Preis (Close) |
|-------|-----|---------------|
| 17. Apr | **70,40** | 19,81 |
| 11. Mai | **63,88** | 20,51 |

**Bärische Divergenz erkannt:** Der Preis bildete am 11. Mai ein höheres Hoch (20,51 > 19,81), aber der RSI ein niedrigeres Hoch (63,88 < 70,40). Dies ist ein klassisches Warnsignal, dass die Aufwärtsdynamik nachlässt und eine Korrektur oder Trendumkehr bevorstehen könnte.

Aktueller RSI (14. Mai): **56,48** — neutrale Zone, weder überkauft noch überverkauft. Kein unmittelbarer Handlungsdruck aus der RSI-Perspektive.

---

## 4. Volatilitäts-Analyse — Bollinger-Bänder

| Datum | Bollinger UB | Bollinger LB | Preis (Close) |
|-------|-------------|-------------|---------------|
| 14. Mai | 20,81 | 15,66 | 18,42 (13. Mai) |

- Der Preis liegt etwa in der **Mitte des Bollinger-Bandes** (Spanne: 5,19 USD).
- Am 11. Mai erreichte der Preis 20,51 und **berührte fast das obere Band** (20,81). Die anschließende Zurückweisung ist typisch.
- Das untere Band bei 15,66 liegt **15 % unter dem aktuellen Preis** — bietet also eine breite Pufferzone.

**Bandbreiten-Expansion:** Die Bollinger-Bänder weiten sich (UB steigt, LB steigt langsamer), was auf zunehmende Volatilität hindeutet. Dies ist konsistent mit der dynamischen Erholungsbewegung seit Anfang April.

---

## 5. Gesamtbewertung und Handlungsimplikationen

### Zusammenfassung der Signalmatrix:

| Signal | Status | Interpretation |
|--------|--------|----------------|
| Preis vs. 200 SMA | Darunter (−20 %) | **Bärisch** — langfristiger Abwärtstrend |
| 50 vs. 200 SMA | Death Cross aktiv | **Bärisch** — strukturell negativ |
| Preis vs. 50 SMA | Darüber (+10,8 %) | **Bullish** — mittelfristige Erholung |
| Preis vs. 10 EMA | Darunter (−1,1 %) | **Kurzfristig warnend** |
| MACD | Positiv (0,73) | **Bullish**, aber stagnierend |
| MACD Histogramm | Schrumpfend (0,09) | **Momentum-Verlust** |
| RSI Divergenz | Bärische Divergenz | **Warnsignal** |
| Bollinger Position | Mitte des Bandes | **Neutral** |

### Szenarioanalyse:

**Bullish-Szenario** (30 % Wahrscheinlichkeit):
- Der Preis hält die 50 SMA (16,63) als Unterstützung und die 10 EMA (18,63) wird zurückerobert.
- Ein Ausbruch über 20,51 mit bestätigendem MACD-Anstieg würde das bullishe Bild festigen.
- Nächster Widerstand: 200 SMA bei 22,99.

**Bearish-Szenario** (45 % Wahrscheinlichkeit):
- Die bärische RSI-Divergenz und das schrumpfende MACD-Histogramm deuten auf eine Korrektur hin.
- Ein Bruch unter die 50 SMA (16,63) würde die Erholung infrage stellen.
- Unterstützungszone: 15,00–15,65 (Bollinger LB und psychologische Marke).

**Seitwärts-Szenario** (25 % Wahrscheinlichkeit):
- Konsolidierung zwischen 16,60 (50 SMA) und 20,50 (Widerstand).

### Wichtige technische Level für Trader:

| Level | Wert | Bedeutung |
|-------|------|-----------|
| Widerstand 2 | 22,99 | 200 SMA — langfristiger Trendwiderstand |
| Widerstand 1 | 20,51 | Letztes Hoch (11. Mai) |
| — | 20,81 | Bollinger UB |
| — | 18,63 | 10 EMA |
| **Preis** | **18,42** | Aktuell (13. Mai) |
| Unterstützung 1 | 16,63 | 50 SMA — mittelfristiger Halt |
| Unterstützung 2 | 15,65 | Bollinger LB |
| Unterstützung 3 | 12,90 | März-Tief |

---

## 📊 Zusammenfassende Übersichtstabelle

| Kategorie | Metrik | Wert | Signal | Hinweis |
|-----------|--------|------|--------|---------|
| Langfrist-Trend | 200 SMA | 22,99 | 🔴 Bärisch | Preis 20 % darunter |
| Mittelfrist-Trend | 50 SMA | 16,63 | 🟢 Bullish | Preis seit 14. Apr. darüber |
| Kurzfrist-Trend | 10 EMA | 18,74 | 🟡 Neutral-warnend | Preis leicht unter 10 EMA |
| Death Cross | 50/200 SMA | Aktiv | 🔴 Bärisch | 50 SMA weit unter 200 SMA |
| Momentum | MACD | +0,73 | 🟢 Positiv | Aber stagnierend seit Mitte April |
| Momentum-Stärke | MACD Histogramm | +0,09 | 🟡 Abschwächend | Spitze bei 0,79 (22. Apr.), jetzt nur noch 0,09 |
| RSI | RSI (14) | 56,48 | 🟡 Neutral | Bärische Divergenz: Preis-Hoch höher, RSI-Hoch niedriger |
| Volatilität (oben) | Bollinger UB | 20,81 | — | Fast berührt am 11. Mai |
| Volatilität (unten) | Bollinger LB | 15,66 | — | 15 % Puffer nach unten |
| Übergeordnete Einschätzung | — | — | ⚠️ VORSICHT | Momentum-Verlust + bärische Divergenz warnen vor Einstieg auf aktuellen Niveaus |

---

## Empfehlung (Draft-Charakter — nicht finales Investment-Komitee)

**Die technische Gesamtlage ist gemischt mit bärischen Untertönen:**

- Die Erholung von den März-Tiefs ist beeindruckend (+54 %), aber die Momentum-Indikatoren (MACD-Histogramm, RSI-Divergenz) signalisieren eine **Ermüdung der Rally**.
- Die langfristige Death-Cross-Struktur bleibt intakt und stellt ein übergeordnetes Risiko dar.
- Die Bollinger-Bänder und die 50 SMA bieten klare technische Referenzpunkte für Risikomanagement.

**Kurzfristig** spricht die technische Evidenz für **Abwarten** oder **reduzierte Positionen**. Ein nachhaltiger Wiedereinstieg wäre erst bei einem bestätigten Bruch über 20,81 (Bollinger UB) mit steigendem MACD-Histogramm technisch sauber. Auf der Unterseite bietet ein Test der 50 SMA (16,63) eine potenzielle Akkumulationszone, sofern sie hält.

---

### Quellenvermerk (Room 16 QA):
- Kursdaten: vendor:yfinance, asof=2026-05-14, period_type=daily, source_id=get_stock_data:rgti:2026-05-14:yfinance (Vendor-Tier)
- Indikatoren: vendor:yfinance, asof=2026-05-14, period_type=calculated, source_id=get_indicators:rgti:2026-05-14:yfinance (Vendor-Tier)
- **Keine SEC/IR-Quellen** für fundamentale Daten in dieser rein technischen Analyse verwendet
- Der Schlusskurs vom 14. Mai 2026 lag zum Zeitpunkt der Analyse nicht vor; Indikatoren basieren auf dem letzten verfügbaren Close (13. Mai: 18,42)
- Alle Berechnungen (Abstände, Prozentsätze) sind deterministisch aus den Rohdaten abgeleitet
- Konfidenz der technischen Signale: Mittel — RGTI ist ein niedrigkapitalisierter, spekulativer Titel mit hoher Noise-Anfälligkeit

### sentiment_report

# 📊 Rigetti Computing (RGTI) – Social-Media-, Nachrichten- und Sentiment-Analyse

**Analysezeitraum:** 7. Mai – 14. Mai 2026  
**Analyst:** Room 16 – Social-Media- & Nachrichten-Desk  
**Ticker:** RGTI (NASDAQ)  
**Stand:** 14. Mai 2026 | Quelle: vendor:yfinance (News-Aggregator)  
**Prioritätsstufe:** SEC/IR > Transkript > Reputable Medien > Vendor > Social

---

## 1. ZUSAMMENFASSUNG (EXECUTIVE SUMMARY)

Rigetti Computing durchläuft eine hochvolatile Phase. Die Q1-2026-Zahlen übertrafen die Analystenerwartungen – der Umsatz stieg um **198,9 % YoY auf 4,4 Mio. USD**, der Verlust verengte sich. Dennoch **fiel die Aktie nach den Earnings**. Der Grund: Eine **eklatante Diskrepanz zwischen Marktkapitalisierung (~6,34 Mrd. USD) und fundamentaler Realität** (FY2025-Umsatz: 7,09 Mio. USD, das ist ein Rückgang von 34,31 %). Die Aktie notiert **66 % unter ihrem Allzeithoch von Ende 2025**. Social-Media-Plattformen (insb. Reddit) behandeln RGTI als **spekulativen „Cult Stock"** – getrieben von Narrativen, nicht von Fundamentaldaten.

---

## 2. DETAILANALYSE DER NACHRICHTENLAGE

### 2.1 Q1-2026 Earnings – Umsatz-Beat, aber Aktie fällt

| Kennzahl | Q1 2026 | Anmerkung |
|---|---|---|
| Umsatz | **4,4 Mio. USD** | +198,9 % YoY (Quelle: Proactive Investors, 14.05.) |
| Gewinn/Verlust | Verlust verengt | Genaue EPS-Zahl in Vendor-Quellen nicht beziffert |
| Ausblick | „Stetige Hand am technischen Fahrplan" | Fokus auf Qualität statt „reißerische Meilensteine" (Barron's) |

**Quellen-Tier:** Vendor (Proactive Investors, Barron's). **Keine SEC/IR-Primärquelle** in den vorliegenden Daten. Für harte EPS- und Guidance-Zahlen ist ein Fallback auf das offizielle IR-Deck zwingend erforderlich.

Trotz des Beats **tankte die Aktie** (GuruFocus: „Why Rigetti Computing Stock Is Tanking"). Dies deutet darauf hin, dass der Markt den Umsatz zwar zur Kenntnis nahm, aber fundamental nicht als ausreichend für die aktuelle Bewertung ansieht.

### 2.2 Bewertungsdiskrepanz – Das Kernproblem

24/7 Wall St. (13.05.) beziffert das Missverhältnis glasklar:

> **Marktkapitalisierung: 6,34 Mrd. USD vs. FY2025-Umsatz: 7,09 Mio. USD**

Das entspricht einem **Price-to-Sales-Verhältnis von ca. 894x** (basierend auf FY2025-Umsatz). Selbst mit Q1-2026 annualisiert (~17,6 Mio. USD) läge das KGV-Umsatz-Verhältnis bei rund **360x**. 

| Metrik | Wert | Quelle | Vertrauen |
|---|---|---|---|
| Market Cap | ~6,34 Mrd. USD | 24/7 Wall St. (13.05.) | Vendor – Mittel |
| FY2025 Revenue | 7,09 Mio. USD | 24/7 Wall St. (13.05.) | Vendor – Mittel |
| FY2025 Rev. Δ% | −34,31 % | 24/7 Wall St. (13.05.) | Vendor – Mittel |
| Q1 2026 Revenue | 4,4 Mio. USD | Proactive Investors | Vendor – Mittel |
| Q1 2026 Rev. Δ% | +198,9 % YoY | Proactive Investors | Vendor – Mittel |
| Aktienkurs (14.05.) | ~18,42 USD | 24/7 Wall St. | Vendor – Mittel |

**Warnung:** Alle Zahlen sind Vendor-tier. SEC-Filing-Fallback für verifizierte GAAP-Zahlen erforderlich.

### 2.3 Technische Meilensteine & Strategie-Shift

- **Cepheus-1-108Q:** 108-Qubit-System als technisches Aushängeschild (Zacks, 14.05.)
- **Chiplet-basierte Architektur:** Weiterentwicklung läuft (Proactive Investors)
- **Strategiewechsel:** Barron's (14.05.) berichtet von einer Abkehr von „reißerischen Meilensteinen" hin zu „Leistungsqualität" – Rigetti hatte bereits im Januar die Timeline verschoben, um technische Verfeinerungen zu ermöglichen.
- **Cloud-Reichweite** wird ausgebaut (Zacks)

**Bewertung:** Die technische Roadmap ist ambitioniert, aber die kommerzielle Adoption bleibt laut Zacks „begrenzt". Ohne breite Kommerzialisierung bleibt RGTI ein **Science-Project-Investment**.

---

## 3. SOCIAL-MEDIA-SENTIMENT & ÖFFENTLICHE WAHRNEHMUNG

### 3.1 „Cult Stock"-Status

24/7 Wall St. (14.05.) kategorisiert RGTI explizit als einen der **drei meistbeobachteten spekulativen Namen auf Reddit** (neben Archer Aviation und SoundHound AI). Allen drei gemein:

- **Pre-Profit** (keine Gewinne)
- **High Beta** (hohe Volatilität)
- **Narrative-Driven** (Story-gesteuert, nicht fundamental)

Dieser „Cult Stock"-Status bedeutet: Die Aktie wird nicht nach traditionellen Bewertungskennzahlen gehandelt, sondern nach **Hoffnung auf den Quanten-Durchbruch** und Momentum.

### 3.2 Sentiment-Trajektorie (qualitativ rekonstruiert)

Da kein dediziertes Sentiment-Tool zur Verfügung steht, rekonstruiere ich die Stimmung aus den Schlagzeilen:

| Tag (ca.) | Stimmung | Indikator |
|---|---|---|
| Vor Earnings | Neutral/Bullish | „Cult Stock" Rally vom April-Tief (24/7 Wall St.) |
| Earnings-Release | Kurzfristig positiv | Umsatz-Beat, Verlust verengt |
| Post-Earnings | **Negativ** | „Tanking", „cratering", 66 % unter ATH |
| 13.–14. Mai | Gespalten | Zacks: „Hold"; 24/7 Wall St.: „Bullish Screen" aber fundamentale Kritik; Motley Fool: „Buy the Dip?" vs. „Revenue Soars but Stock Tumbles" |

**Fazit Sentiment:** Die Social-Media-Community ist **gespalten**. Reddit-Retail hält die Aktie („buy the dip"-Narrativ), während Finanzmedien zunehmend fundamental skeptisch werden.

---

## 4. PEER-VERGLEICH: RGTI vs. IONQ vs. QBTS

| Aspekt | IONQ | RGTI | QBTS |
|---|---|---|---|
| Q1-Leistung | **Führt das Feld an** (Zacks) | Umsatz-Beat, aber Bewertungsproblem | Umsatz −81 %, Bookings-Surge als Ausrede |
| Analysten-Ranking | #1 (Zacks: „Best Quantum Stock") | #2–#3 | #2–#3 |
| Strategie | Enterprise-Adoption, wachsender Backlog | Technische Roadmap, Qualität über Hype | „Lumpy Revenue" vor Kommerzialisierung |
| Bewertung | ~21 Mrd. USD Market Cap | ~6,34 Mrd. USD | (nicht in Daten) |

Quelle: Zacks (14.05.), Barron's (14.05.), Trefis (13.05.)

---

## 5. KATALYSATOREN & RISIKEN

### Katalysatoren (potenziell bullish)

1. **Xanadu-IPO-Read-Through (14. Mai):** Barchart berichtet, dass Xanadus Q-Bericht das „Narrativ um Quanten-Aktien neu setzen" könnte – positiver Spillover möglich.
2. **Technische Durchbrüche:** Cepheus-1-108Q könnte Türen für kommerzielle Partnerschaften öffnen.
3. **Cash-Rich Balance Sheet:** 24/7 Wall St. erwähnt eine „cash-stuffed balance sheet" – RGTI hat Liquidität, um den Betrieb zu finanzieren.

### Risiken (potenziell bearish)

1. **Bewertungsblase:** 894x Sales ist für jedes Unternehmen schwer zu rechtfertigen, selbst mit 200 % Wachstum.
2. **Fehlende kommerzielle Adoption:** Zacks explizit: „limited commercial adoption keeps RGTI in hold territory."
3. **Timeline-Verschiebungen:** Bereits im Januar verzögert; weitere Verzögerungen würden das Vertrauen untergraben.
4. **Quantum-Sektor-Hype-Zyklus:** Der Sektor ist stark hype-getrieben. Wenn IONQ oder Xanadu enttäuschen, könnte der gesamte Sektor korrigieren.

---

## 6. IMPLIKATIONEN FÜR TRADER UND INVESTOREN

### Für kurzfristige Trader:
- RGTI zeigt **hohe Beta und narrative-driven Bewegungen**. Post-Earnings-Tanking trotz Umsatz-Beat ist ein **Warnsignal**: Der Markt kauft keine „guten Nachrichten" mehr – ein klassisches Zeichen überdehnter Bewertungen.
- Xanadu-Bericht am 14. Mai könnte Sektor-Volatilität auslösen.
- Reddit-Momentum kann kurzfristige Squeezes verursachen, aber die fundamentale Unterlage ist dünn.

### Für mittelfristige Investoren:
- Die Diskrepanz zwischen **6,34 Mrd. USD Market Cap** und **7 Mio. USD Jahresumsatz** ist extrem. Selbst bei Verdreifachung des Umsatzes 2026 bleibt das Multiple dreistellig.
- Rigettis Strategiewechsel zu „Qualität über Hype" ist zwar vernünftig, bedeutet aber auch: **keine kurzfristigen Kurskatalysatoren durch Meilenstein-Schlagzeilen**.

### Für langfristige Investoren:
- Quantencomputing ist ein reales, großes Zukunftsfeld. RGTI hat technische Kompetenz und eine solide Bilanz.
- Das Risiko ist jedoch: **Verwässerung, Verzögerungen und ein möglicherweise jahrzehntelanger Weg zur Profitabilität**.

---

## 7. FAZIT

RGTI befindet sich in einer **paradoxen Situation**: Operativ Fortschritte (Q1-Umsatz +199 % YoY), technisch relevante Meilensteine (108-Qubit-System), aber eine **Bewertung, die selbst bei optimistischsten Annahmen schwer zu rechtfertigen ist**. Der „Cult Stock"-Status auf Reddit und das Retail-Interesse halten den Preis künstlich über fundamental gerechtfertigten Niveaus. Die Post-Earnings-Reaktion (Aktie fällt trotz Beat) ist ein klares Signal, dass **der Markt beginnt, fundamental zu hinterfragen**.

**Ohne SEC/IR-bestätigte Zahlen** (GAAP-EPS, Cash-Position, Guidance) bleibt die Analyse unvollständig. Ich empfehle dringend den Fallback auf das Q1-2026-Earnings-Release und die 10-Q-Einreichung.

---

## 📋 KENNZAHLEN-TABELLE

| Kategorie | Metrik | Wert | Quelle | Quellen-Tier | Zeitraum |
|---|---|---|---|---|---|
| **Bewertung** | Market Cap | ~6,34 Mrd. USD | 24/7 Wall St. | Vendor | 13.05.2026 |
| **Bewertung** | Aktienkurs | ~18,42 USD | 24/7 Wall St. | Vendor | 14.05.2026 |
| **Bewertung** | Allzeithoch-Abstand | −66 % | Motley Fool | Vendor | 14.05.2026 |
| **Fundamental** | FY2025 Revenue | 7,09 Mio. USD | 24/7 Wall St. | Vendor | FY2025 |
| **Fundamental** | FY2025 Revenue Δ | −34,31 % | 24/7 Wall St. | Vendor | FY2025 vs. FY2024 |
| **Fundamental** | Q1 2026 Revenue | 4,4 Mio. USD | Proactive Investors | Vendor | Q1 2026 |
| **Fundamental** | Q1 2026 Revenue Δ | +198,9 % YoY | Proactive Investors | Vendor | Q1 2026 vs. Q1 2025 |
| **Fundamental** | P/S Ratio (FY2025) | ~894x | Berechnet* | Vendor-Basis | FY2025 |
| **Fundamental** | GAAP EPS Q1 | **Fehlt** | — | — | Q1 2026 |
| **Fundamental** | Cash-Position | „Cash-stuffed" | 24/7 Wall St. | Vendor (qualitativ) | Nicht datiert |
| **Technisch** | Qubits | 108 (Cepheus-1-108Q) | Zacks | Vendor | Mai 2026 |
| **Sentiment** | Analysten-Rating | Hold | Zacks | Vendor | 14.05.2026 |
| **Sentiment** | Reddit-Status | „Cult Stock" / Bullish Screen | 24/7 Wall St. | Vendor | 14.05.2026 |
| **Sentiment** | Institutionelle Stimmung | Skeptisch (Bewertung) | Barron's, Motley Fool | Reputable Medien | 13.–14.05.2026 |
| **Katalysator** | Xanadu Q-Bericht | 14. Mai 2026 | Barchart | Vendor | 14.05.2026 |

> *P/S Ratio aus Vendor-Zahlen abgeleitet – nicht als verifizierte GAAP-Kennzahl zu behandeln. Vertrauen: Niedrig. Fallback auf SEC-Filing erforderlich.

---

## ⚠️ DATENQUALITÄTS-VERMERK

Sämtliche Zahlen in diesem Report basieren auf **Vendor-tier Quellen** (Yahoo Finance Aggregator via yfinance). Es liegen **keine direkten SEC/IR-Primärquellen** vor. Für eine institutionelle Investmententscheidung ist der **Fallback auf das offizielle Q1-2026-Earnings-Release (8-K/10-Q) und das IR-Deck von Rigetti Computing zwingend erforderlich**. GAAP vs. Non-GAAP-Abgrenzung, SBC-Behandlung, Cash-Burn-Rate und Forward-Guidance können aus den vorliegenden Daten nicht verifiziert werden.

---

**Kein FINAL TRANSACTION PROPOSAL** – Dieser Report ist eine Informationsgrundlage für den Investment-Komitee-Prozess. Die Entscheidung BUY/HOLD/SELL erfordert zusätzliche SEC/IR-Validierung und Abgleich mit dem Gesamtportfolio-Kontext.

### news_report

# RGTI (Rigetti Computing) – Markt- und Nachrichtenanalyse
## Berichtszeitraum: 7. Mai – 14. Mai 2026

---

### 1. Zusammenfassung der Lage

Rigetti Computing (NASDAQ: RGTI) befindet sich in einer akuten Korrekturphase. Die Aktie notiert nach einem massiven Rückgang von **66 % gegenüber den Allzeithochs Ende 2025** bei rund **$18,42** (Quelle: 24/7 Wall St., 14.05.2026). Trotz eines Q1-Umsatzwachstums von +198,9 % im Jahresvergleich und einer übertroffenen Gewinnschätzung gerät der Titel weiter unter Druck. Die fundamentale Diskrepanz zwischen Bewertung und Realgeschäft – **$6,34 Mrd. Marktkapitalisierung vs. $7,09 Mio. Jahresumsatz 2025** – steht im Zentrum der Anlegerdebatte.

---

### 2. Unternehmensspezifische Entwicklungen (RGTI)

#### 2.1 Q1 2026 – Quartalszahlen

| Kennzahl | Wert | Quelle |
|---|---|---|
| Q1 2026 Umsatz | $4,4 Mio. (+198,9 % YoY) | Proactive Investors |
| Gewinn/Loss | Verlust verengt, über Erwartungen | Proactive Investors, Barron's |
| Vergleich FY2025 Umsatz | $7,09 Mio. (−34,31 % YoY) | 24/7 Wall St. |

**Einordnung:** Der Q1-Umsatz von $4,4 Mio. ist im Vergleich zum Gesamtjahr 2025 ($7,09 Mio.) beachtlich, was auf eine mögliche Beschleunigung hindeutet. Allerdings ist die absolute Basis winzig im Verhältnis zur Marktkapitalisierung. Die annualisierte Q1-Run-Rate läge bei etwa $17,6 Mio. – was einem **Kurs-Umsatz-Verhältnis von ca. 360×** entspräche. (Eigene Berechnung auf Basis der angegebenen Daten; kein offizieller Konsens.)

**Quellen-Tier:** Proactive Investors und Barron's sind reputable Finanzmedien (Tier 2). Eine direkte SEC/IR-Bestätigung liegt in den abgerufenen Daten nicht vor; eine SEC-8-K-/10-Q-Prüfung wird empfohlen.

#### 2.2 Technische Meilensteine

- **Cepheus-1-108Q**: Rigetti hat sein 108-Qubit-System auf den Markt gebracht (Zacks, 24/7 Wall St.).
- **Chiplet-basierte Architektur**: Weiterentwicklung des modularen Ansatzes (Proactive Investors).
- **Strategiewechsel**: Barron's (12.05.2026) berichtet, dass Rigetti sich von „auffälligen Schlagzeilen-Meilensteinen" abwendet und auf **Systemqualität und Performance** fokussiert. Eine ursprünglich für Januar vorgesehene Roadmap wurde bereits verschoben.

**Einordnung:** Die Neuausrichtung auf Qualität statt Quantität der Meilensteine ist ein potenziell positiver Reifeschritt, signalisiert aber auch, dass frühere Zeitpläne zu ambitioniert waren. Die begrenzte kommerzielle Adoption bleibt das Kernproblem.

#### 2.3 Analysten- und Medienstimmen

| Medium | Tenor | Kernaussage |
|---|---|---|
| Zacks | **HOLD** | Technische Fortschritte da, aber limitierte kommerzielle Adoption |
| 24/7 Wall St. (1) | **BULLISH** (Screen) | $18,42 screen bullishly |
| 24/7 Wall St. (2) | **BEARISH** | $6 Mrd. Market Cap vs. $7 Mio. Umsatz = nicht haltbar |
| Motley Fool (1) | **NEUTRAL-FRAGEND** | „Time to Consider?" nach Umsatzsprung |
| Motley Fool (2) | **NEUTRAL-FRAGEND** | „Down 66% – Buy the Dip?" |
| GuruFocus | **BEARISH** | „Why RGTI Is Tanking" |
| Barron's | **NEUTRAL** | Positiv zum Roadmap-Fokus, aber kein klares Buy-Signal |

**Quellen-Tier:** Sämtlich Tier-3/Vendor. Keine direkten Broker-Upgrades/-Downgrades mit Preiszielen in den abgerufenen Daten enthalten. Direkte Analyst-Reports (z. B. Goldman, Morgan Stanley, BofA) wurden nicht erfasst und wären für ein vollständiges Bild erforderlich.

---

### 3. Quanten-Computing-Sektor – Peer-Vergleich

| Unternehmen | Ticker | Aktuelle Lage |
|---|---|---|
| **IonQ** | IONQ | Führend nach Q1 – $21 Mrd. Market Cap, starkes Umsatzwachstum, AQ-64-Fokus (Trefis, Zacks) |
| **D-Wave** | QBTS | Umsatz −81 %, aber Bookings-Surge; CEO warnt vor „lumpy revenue" (Barron's) |
| **Quantum Computing Inc.** | QUBT | +16 % nach Q1-Earnings, nach −38 % in 2025 (Barron's) |
| **Xanadu** | (IPO) | Q1-Report am 14. Mai – könnte das Narrativ für den Sektor neu setzen (Barchart) |

**Einordnung:** Der Sektor bleibt narrativ-getrieben und hochspekulativ. IONQ wird von mehreren Quellen als Klassenbester identifiziert. RGTI hat den zweifelhaften „Vorteil", technisch Fortschritte zu machen, aber kommerziell kaum zu monetarisieren.

---

### 4. Makroökonomisches Umfeld

| Faktor | Entwicklung | Implikation für RGTI |
|---|---|---|
| **Zinsen/Renditen** | Steigend – Anleiherenditen im Aufwind | Negativ für unprofitable Wachstumswerte |
| **Ölpreis** | Rally | Inflationsdruck steigt |
| **Inflation** | Ängste nehmen zu (Motley Fool, 15.05.) | Belastet Risk-On-Assets |
| **Dow Jones** | −500 Punkte an einem Tag (IBD) | Breiter Risk-Off-Modus |
| **Nvidia** | Fallend | Tech-Schwäche |
| **Cerebras IPO** | Blockbuster-IPO, dann Rutsch | Signal für Tech-IPO-Müdigkeit |

**Makro-Fazit:** Das Umfeld ist für spekulative, vorprofitable Technologiewerte wie RGTI ausgesprochen ungünstig. Steigende Renditen und Inflationssorgen treiben Kapital aus langlaufenden, unsicheren Assets in sicherere Häfen. RGTI als hochvolatiler „Cult Stock" (Beta implizit hoch, kein numerischer Beta-Wert in den Quellen) leidet überproportional.

---

### 5. Risikofaktoren und Warnsignale

1. **Bewertungsdiskonnektivität**: $6,34 Mrd. Market Cap vs. $7,09 Mio. Jahresumsatz – ein Multiplikator jenseits aller fundamentalen Rechtfertigung. (24/7 Wall St., 13.05.2026)
2. **Roadmap-Verzögerung**: Bereits im Januar wurde der Zeitplan verschoben (Barron's).
3. **Kein klares Profitabilitätsdatum**: Das Unternehmen ist „pre-profit" (24/7 Wall St.). Kein Datum für Break-Even kommuniziert.
4. **Makro-Gegenwind**: Zinsanstieg trifft spekulative Namen besonders hart.
5. **Reddit/Cult-Status**: Hohe Retail-Exposure kann in Risk-Off-Phasen zu beschleunigten Abverkäufen führen.

---

### 6. Katalysatoren (Bull Case)

1. **Q1-Umsatzsprung +198,9 %**: Wenn sich diese Wachstumsrate fortsetzt, könnte die Run-Rate schnell steigen.
2. **Cepheus-1-108Q**: Als technischer Meilenstein könnte das System neue Kunden/Partnerschaften erschließen.
3. **Cash-Reserve**: 24/7 Wall St. spricht von einer „cash-stuffed balance sheet" – genaue Cash-Position aus SEC-Filings zu verifizieren (hier nicht direkt abrufbar).
4. **Sektor-Narrativ**: Quantencomputing bleibt ein langfristiger Megatrend; RGTI ist einer der wenigen Pure-Play-Titel.

**Kausalitätseinordnung:** Keiner dieser Katalysatoren hat im Berichtszeitraum eine nachhaltige Kursstützung bewirkt. Der Kursrückgang trotz positivem Earnings-Report deutet auf eine tieferliegende Vertrauenskrise hin. Mögliche Erklärungen: Enttäuschung über Ausblick/Guidance (nicht in Quellen spezifiziert), Sektor-Rotation oder Gewinnmitnahmen nach vorheriger Rally.

---

### 7. Schlussfolgerung und Handlungsempfehlung

RGTI präsentiert sich als klassischer Fall eines **narrativ-getriebenen, fundamental überbewerteten** Spekulationswerts in einem zunehmend risk-aversen Makroumfeld. Die Q1-Zahlen zeigen operativen Fortschritt, aber die Schere zwischen Bewertung und realer Wirtschaftsleistung bleibt extrem. Der Sektor-Peer-Vergleich zeigt zudem, dass IONQ der konsistentere Performer ist.

**Ohne direkte SEC/IR-Quellen und ohne vollständige Guidance-Analyse bleibt die Evidenzlage unvollständig.** Die folgende Einschätzung basiert auf dem verfügbaren Vendor- und Medienmaterial (Tier 2/3).

---

### 📊 Übersichtstabelle: Zentrale Datenpunkte

| Kategorie | Detail | Quelle | Datum | Quellen-Tier | Konfidenz |
|---|---|---|---|---|---|
| Kurs | ~$18,42 | 24/7 Wall St. | 14.05.2026 | Vendor (T3) | Mittel |
| Korrektur vom ATH | −66 % | Motley Fool | 14.05.2026 | Media (T3) | Mittel |
| Market Cap | ~$6,34 Mrd. | 24/7 Wall St. | 13.05.2026 | Vendor (T3) | Mittel |
| FY2025 Umsatz | $7,09 Mio. (−34,31 %) | 24/7 Wall St. | 13.05.2026 | Vendor (T3) | Hoch (berichtete Zahl) |
| Q1 2026 Umsatz | $4,4 Mio. (+198,9 %) | Proactive Investors | Mai 2026 | Media (T2) | Hoch (berichtete Zahl) |
| Cepheus-1-108Q Launch | Technischer Meilenstein | Zacks / 24/7 Wall St. | Mai 2026 | Vendor (T3) | Hoch |
| Roadmap-Verzögerung | Januar 2026 | Barron's | 12.05.2026 | Media (T2) | Mittel |
| Zacks-Rating | Hold | Zacks | 14.05.2026 | Vendor (T3) | Hoch (direkt zitiert) |
| Makro: Dow | −500 Pkte | IBD | Berichtszeitraum | Media (T2) | Hoch |
| Makro: Renditen | Steigend | IBD / Motley Fool | Berichtszeitraum | Media (T2) | Hoch |
| Peer: IONQ führend | $21 Mrd. MCap | Trefis / Zacks | 13.05.2026 | Vendor (T3) | Mittel |
| Cash-Position | „Cash-stuffed" (keine Zahl) | 24/7 Wall St. | 13.05.2026 | Vendor (T3) | Niedrig (ungenau) |
| SBC / Verwässerung | Nicht in Quellen | — | — | — | Fehlt |
| Guidance Q2/FY2026 | Nicht in Quellen | — | — | — | Fehlt |
| GAAP vs. Non-GAAP | Nicht differenziert in Quellen | — | — | — | Fehlt |

---

### ⚠️ Datenlücken und nächste Schritte (Fallback-Protokoll)

Vor einer finalen Investitionsentscheidung sind zwingend zu prüfen:

1. **SEC 10-Q (Q1 2026)** → Cash-Bestand, Verwässerung/SBC, Deferred Revenue, Guidance.
2. **Earnings Call Transcript** → Management-Kommentar zu kommerzieller Pipeline, Zeitplan bis Profitabilität.
3. **Analyst-Reports Tier 1** → Preisziele, Up-/Downgrades von Banken (nicht Vendor-Plattformen).
4. **Insider-Trading** → Wurden nach dem Earnings-Beat Aktien verkauft?

**Ohne diese Daten kann keine robuste BUY/HOLD/SELL-Empfehlung nach institutionellen Standards ausgesprochen werden.** Auf Basis des verfügbaren Materials tendiert die vorläufige Einschätzung zu **HOLD** – mit erheblichem Abwärtsrisiko bei weiterer Makro-Verschlechterung und ohne klaren Katalysator für eine Neubewertung.

### fundamentals_report

# Fundamentalanalyse: Rigetti Computing, Inc. (RGTI)
## Erstellungsdatum: 14. Mai 2026

---

## 1. Unternehmensprofil und Geschäftsmodell

**Rigetti Computing, Inc. (Ticker: RGTI)** ist ein US-amerikanisches Technologieunternehmen mit Sitz in Berkeley, Kalifornien. Das Unternehmen ist im Sektor **Technologie / Computer Hardware** angesiedelt und entwickelt Quantencomputer sowie die dazugehörige Software-Infrastruktur. Rigetti gehört zu den wenigen börsennotierten Pure-Play-Quantencomputing-Unternehmen.

Wesentliche Marktdaten (Quelle: Vendor `yfinance`, Stand 14.05.2026):

| Kennzahl | Wert |
|---|---|
| Marktkapitalisierung | $5,93 Mrd. |
| Beta | 1,801 |
| 52-Wochen-Hoch | $58,15 |
| 52-Wochen-Tief | $10,30 |
| 50-Tage-Durchschnitt | $16,63 |
| 200-Tage-Durchschnitt | $22,99 |

Die Aktie notiert deutlich unter ihrem 200-Tage-Durchschnitt von $22,99, was auf einen negativen mittelfristigen Trend hindeutet. Das Beta von 1,80 signalisiert eine hohe Volatilität relativ zum Gesamtmarkt – typisch für ein spekulatives Technologieunternehmen.

---

## 2. Umsatz- und Ertragslage (GuV-Analyse)

### 2.1 Quartalszahlen im Zeitverlauf

| (USD) | Q4 2025 | Q3 2025 | Q2 2025 | Q1 2025 | Q4 2024 |
|---|---|---|---|---|---|
| **Gesamtumsatz** | 1.868.000 | 1.947.000 | 1.801.000 | 1.472.000 | 2.274.000 |
| Umsatzkosten | 1.216.000 | 1.543.000 | 1.235.000 | 1.030.000 | 1.271.000 |
| **Bruttogewinn** | 652.000 | 404.000 | 566.000 | 442.000 | 1.003.000 |
| F&E-Ausgaben | 17.348.000 | 15.020.000 | 13.522.000 | 15.455.000 | 13.657.000 |
| SG&A | 5.901.000 | 5.933.000 | 6.926.000 | 6.619.000 | 5.840.000 |
| **Operatives Ergebnis** | −22.597.000 | −20.549.000 | −19.882.000 | −21.632.000 | −18.494.000 |
| Sonstige Erträge/Aufw. | −1.379.000 | −186.017.000 | −22.814.000 | 62.099.000 | −135.567.000 |
| Zinserträge (netto) | 5.769.000 | 5.598.000 | 3.042.000 | 2.152.000 | 1.100.000 |
| **Nettoergebnis** | −18.207.000 | −200.968.000 | −39.654.000 | 42.619.000 | −152.961.000 |
| **EPS (verwässert)** | −$0,06 | −$0,62 | −$0,13 | $0,13 | −$0,68 |

*Quelle: Vendor `yfinance`, Quartals-GuV, period_type: quarterly. Die Zahlen sind GAAP-basiert.*

**Kernbefund:** Rigetti erzielt minimale Umsätze von ca. $1,5–2,3 Mio. pro Quartal. Die Bruttomarge ist zwar positiv (ca. 21–44 % je nach Quartal), aber die operativen Kosten (F&E + SG&A) übersteigen den Umsatz um das **Zehnfache**. Das operative Ergebnis ist durchgängig stark negativ (ca. −$20 Mio. pro Quartal).

### 2.2 TTM-Betrachtung (Q1–Q4 2025)

| TTM-Kennzahl | Wert |
|---|---|
| TTM Umsatz | ~$7,09 Mio. (aus Quartalsdaten) |
| TTM Nettoergebnis | −$216,21 Mio. |
| TTM EBITDA | −$59,54 Mio. (ohne Sondereffekte) |
| Operative Marge | −589,8 % (laut Fundamentals) |

**Wichtiger Hinweis:** Das in den Fundamentals gemeldete TTM-Umsatzvolumen von $10,016 Mio. weicht von den summierten Quartalsdaten ($7,09 Mio.) ab. Dies kann auf unterschiedliche Periodenabgrenzungen oder Datenanbieter-Berechnungsmethoden zurückzuführen sein. Der Fundamental-Datenpunkt wird hier als vendor-seitig gemeldet, aber mangels SEC/IR-Abgleich als **nicht verifiziert** eingestuft.

### 2.3 Sondereffekte – große Volatilität

Die Position „Sonstige Erträge/Aufwendungen" ist extrem volatil:

- **Q1 2025:** +$62,1 Mio. (Gewinne aus Sicherheitsverkäufen: +$53,3 Mio.)
- **Q3 2025:** −$186,0 Mio. (Verluste aus Sicherheitsverkäufen: −$182,0 Mio.)
- **Q4 2024:** −$135,6 Mio. (davon −$90,9 Mio. Wertpapierverluste, −$44,3 Mio. Restrukturierung)

Dahinter stehen maßgeblich **Derivatverbindlichkeiten (Derivative Product Liabilities)** in der Bilanz, die Marktwertschwankungen unterliegen. Dies sind nicht-cash-wirksame Bewertungseffekte, die das Nettoergebnis stark verzerren.

---

## 3. Bilanzanalyse (Stichtag: 31. Dezember 2025)

### 3.1 Vermögensstruktur

| Bilanzposten | 31.12.2025 | 30.09.2025 | 31.12.2024 |
|---|---|---|---|
| **Bilanzsumme** | 666.574.000 | 630.274.000 | 284.787.000 |
| Umlaufvermögen | 454.760.000 | 456.294.000 | 206.758.000 |
| — davon Cash & Äquivalente | 44.851.000 | 26.133.000 | 67.674.000 |
| — davon kurzfristige Investments | 398.660.000 | 420.850.000 | 124.420.000 |
| Anlagevermögen | 211.814.000 | 173.980.000 | 78.029.000 |
| — davon Sachanlagen (netto) | 63.462.000 | 60.883.000 | 52.636.000 |
| — davon Investments (langfristig) | 146.321.000 | 111.955.000 | 25.068.000 |

*Quelle: Vendor `yfinance`, Quartalsbilanz, period_type: balance_sheet_spot.*

**Kernbefund:** Die Bilanzsumme hat sich gegenüber dem Vorjahr mehr als verdoppelt (+134 %). Dies ist auf Kapitalerhöhungen zurückzuführen (Q2 2025: $381,7 Mio. Nettoemissionserlös). Die liquiden Mittel (Cash + kurzfristige Investments) belaufen sich auf **$443,5 Mio.** – dies stellt das finanzielle Rückgrat des Unternehmens dar.

### 3.2 Kapitalstruktur

| Bilanzposten | 31.12.2025 | 31.12.2024 |
|---|---|---|
| **Eigenkapital** | 546.199.000 | 126.589.000 |
| — Gezeichnetes Kapital | 33.000 | 29.000 |
| — Kapitalrücklage | 1.316.126.000 | 681.202.000 |
| — Bilanzverlust | −770.957.000 | −554.747.000 |
| Fremdkapital (gesamt) | 120.375.000 | 158.198.000 |
| — Davon langfristig | 108.223.000 | 146.331.000 |
| — Davon kurzfristig | 12.152.000 | 11.867.000 |
| **Schulden (Total Debt)** | 7.167.000 | 8.800.000 |
| — ausschließlich Leasingverbindlichkeiten | 7.167.000 | 8.800.000 |

**Wichtige Kennzahlen:**

- **Eigenkapitalquote:** 546,2 Mio. / 666,6 Mio. = **81,9 %** – extrem solide
- **Debt to Equity:** 1,162 (laut Fundamentals) – dies erscheint auf Basis von Total Debt ($7,17 Mio.) / Equity ($546,2 Mio.) = 0,013 unplausibel. Der Fundamentals-Wert von 1,162 könnte Derivatverbindlichkeiten als „Schulden" einbeziehen. **Ohne IR/SEC-Verifizierung als unsicher einzustufen.**
- **Kurs-Buchwert-Verhältnis (P/B):** 10,82 – hohe Bewertungsprämie
- **Nettoliquidität (Cash + Investments − Debt):** $443,51 Mio. − $7,17 Mio. = **$436,34 Mio.**
- **Working Capital:** $442,61 Mio. (extrem komfortabel)
- **Current Ratio (Umlaufvermögen / kurzfristige Verbindlichkeiten):** $454,76 Mio. / $12,15 Mio. = **37,4x** (Hinweis: Der Fundamentals-Wert von 6,985 weicht ab – möglicherweise andere Berechnungsbasis.)

### 3.3 Derivative Produktverbindlichkeiten

Auffällig ist der Bilanzposten **„Derivative Product Liabilities"** in Höhe von **$102,59 Mio.** (31.12.2025), nach $240,74 Mio. im Vorquartal. Diese Verbindlichkeiten sind nicht-cash-wirksam und unterliegen starken Marktwertschwankungen, die das Nettoergebnis erheblich verzerren. Zum Vergleich: Am 31.12.2024 betrugen sie $93,1 Mio.

---

## 4. Cashflow-Analyse

### 4.1 Operativer Cashflow und Free Cashflow

| (USD) | Q4 2025 | Q3 2025 | Q2 2025 | Q1 2025 | Q4 2024 |
|---|---|---|---|---|---|
| **Operativer CF** | −14.901.000 | −13.822.000 | −16.169.000 | −13.651.000 | −8.544.000 |
| CapEx | −4.573.000 | −5.889.000 | −5.667.000 | −2.547.000 | −1.282.000 |
| **Free Cash Flow** | −19.474.000 | −19.711.000 | −21.836.000 | −16.198.000 | −9.826.000 |

*Quelle: Vendor `yfinance`, Quartals-Cashflow, period_type: quarterly.*
*FCF-Definition: Operating Cash Flow minus CapEx (Standard).*

**TTM FCF (Q1–Q4 2025):** −$77,22 Mio.

**Kernbefund:** Der Cash-Burn liegt bei **ca. $15–20 Mio. pro Quartal** und beschleunigt sich tendenziell (Q2 2025: −$21,8 Mio.). Die CapEx-Quote ist mit $4,6–5,9 Mio./Quartal signifikant und spiegelt Investitionen in Quantencomputer-Infrastruktur wider.

### 4.2 Cash-Reichweite (Runway)

Bei einer konservativen monatlichen Cash-Burn-Rate von ~$6 Mio. (basierend auf ~$18 Mio. operativem Cash-Abfluss pro Quartal) und liquiden Mitteln von $443,5 Mio. ergibt sich eine **theoretische Reichweite von ca. 6 Jahren**. Dies gibt Rigetti erheblichen finanziellen Spielraum, bevor eine erneute Kapitalaufnahme nötig wird.

### 4.3 Finanzierungsaktivitäten

- **Q2 2025:** Nettoerlös aus Aktienemission: **$381,7 Mio.**
- **Q4 2025:** Erlöse aus Aktienoptionsausübungen: $47,2 Mio. (deutlich erhöht)
- **Schuldentilgung:** Keine in den letzten vier Quartalen (letzte Rückzahlung Q4 2024: −$13,8 Mio.)

---

## 5. Aktienbasierte Vergütung (SBC)

| (USD) | Q4 2025 | Q3 2025 | Q2 2025 | Q1 2025 | Q4 2024 |
|---|---|---|---|---|---|
| **SBC** | 5.578.000 | 4.299.000 | 3.554.000 | 4.174.000 | 3.364.000 |

*Quelle: Vendor `yfinance`, Quartals-Cashflow.*

- **TTM SBC:** $17,61 Mio.
- **SBC / Umsatz (TTM):** 17,61 Mio. / 7,09 Mio. = **248,4 %**
- **SBC / FCF (TTM):** 17,61 Mio. / −77,22 Mio. = −22,8 % (SBC verschärft den wirtschaftlichen Verlust)
- **SBC / Operatives Ergebnis (TTM, negativ):** 17,61 Mio. / 84,66 Mio. = 20,8 %

**Kernbefund:** Die SBC ist mit dem 2,5-Fachen des Gesamtumsatzes extrem hoch. Dies ist für ein Unternehmen in der Frühphase nicht ungewöhnlich, stellt aber eine signifikante Verwässerung für Aktionäre dar. Die ausstehenden Aktien stiegen von 283,5 Mio. (Q4 2024) auf 331,3 Mio. (Q4 2025) – eine **Verwässerung von 16,8 % in einem Jahr**.

---

## 6. Bewertungskennzahlen

| Kennzahl | Wert | Anmerkung |
|---|---|---|
| **Forward P/E** | −87,79 | Negativ, da Forward EPS −$0,20 (GAAP, Konsens) |
| **EPS (TTM)** | −$0,89 | GAAP, verzerrt durch Sondereffekte |
| **Forward EPS** | −$0,20 | Konsens, Quelle: Vendor `yfinance` |
| **P/B** | 10,82 | Hohe Prämie auf Buchwert |
| **ROE** | −57,09 % | Negativ |
| **ROA** | −12,09 % | Negativ |

**Hinweis zu Forward P/E:** Das Forward EPS von −$0,20 (Quelle: Vendor-Konsensschätzung) steht im Kontrast zum TTM-EPS von −$0,89. Die Diskrepanz erklärt sich durch massive Sondereffekte im TTM-Zeitraum, die im Forward-Konsens offenbar nicht in gleichem Maße erwartet werden. Ohne Management-Guidance oder offizielle IR-Quellen bleibt diese Konsensschätzung jedoch unverifiziert. Es liegt **keine Management-Guidance** in den abgerufenen Daten vor – eine IR/SEC-Recherche wäre erforderlich, um diesen Punkt zu klären.

---

## 7. Gesamtbeurteilung

### Stärken
1. **Sehr solide Bilanz:** $443,5 Mio. liquide Mittel bei nur $7,2 Mio. Schulden (ausschließlich Leasing)
2. **Lange Cash-Reichweite:** ~6 Jahre bei aktuellem Burn-Rate-Niveau
3. **Strategische Positionierung:** Einer der wenigen börsennotierten Pure-Play-Quantencomputing-Anbieter

### Risiken
1. **Minimale Umsätze:** ~$7–10 Mio. TTM bei $5,93 Mrd. Marktkapitalisierung – Price/Sales-Verhältnis von ca. 600–850x
2. **Hoher Cash-Burn:** ~$77 Mio. TTM FCF negativ, strukturell defizitär
3. **Extreme SBC:** 248 % des Umsatzes – erhebliche Verwässerung
4. **Unklarer Pfad zur Profitabilität:** Kein Quartal mit operativem Gewinn
5. **Volatilität durch Derivate:** $102,6 Mio. derivative Verbindlichkeiten sorgen für unvorhersehbare Ergebnisschwankungen
6. **Aktie unter 200-Tage-Linie:** Technisches Schwächesignal

### Fazit

Rigetti Computing ist ein **hochspekulatives Investment** in einem zukunftsträchtigen, aber noch unreifen Markt. Das Unternehmen verfügt über ausreichend Kapital, um die nächsten Jahre zu überleben, aber es gibt keinen sichtbaren Pfad zu positiven Cashflows. Die fundamentale Bewertung erscheint von Umsatz- und Ertragskraft entkoppelt und wird primär von Technologiehoffnungen getragen.

---

## 8. Zusammenfassende Übersichtstabelle

| Kategorie | Kennzahl | Wert | Quelle / Periode | Sicherheit |
|---|---|---|---|---|
| **Profil** | Branche | Computer Hardware | Vendor | Hoch |
| **Profil** | Marktkapitalisierung | $5,93 Mrd. | Vendor, 14.05.2026 | Hoch |
| **Bewertung** | Forward P/E | −87,79 | Vendor, Forward-Konsens | Mittel (Konsens, nicht IR) |
| **Bewertung** | Kurs-Buchwert | 10,82 | Vendor | Mittel |
| **Rentabilität** | EPS (TTM) | −$0,89 | Vendor, GAAP | Mittel |
| **Rentabilität** | ROE | −57,09 % | Vendor | Mittel |
| **Rentabilität** | ROA | −12,09 % | Vendor | Mittel |
| **Rentabilität** | Operative Marge | −589,8 % | Vendor | Mittel |
| **Umsatz** | Umsatz (TTM) | $7,09–10,02 Mio. | Quartalssumme / Vendor | Mittel (Diskrepanz) |
| **Cashflow** | Operativer CF (Q4) | −$14,90 Mio. | Vendor, Q4 2025 | Hoch |
| **Cashflow** | FCF (TTM) | −$77,22 Mio. | Vendor, Quartalssumme | Hoch |
| **Cashflow** | CapEx (Q4) | −$4,57 Mio. | Vendor, Q4 2025 | Hoch |
| **Bilanz** | Cash + Investments | $443,51 Mio. | Vendor, 31.12.2025 | Hoch |
| **Bilanz** | Total Debt | $7,17 Mio. | Vendor, 31.12.2025 | Hoch |
| **Bilanz** | Nettoliquidität | $436,34 Mio. | Eigene Berechnung | Hoch |
| **Bilanz** | Derivative Liabilities | $102,59 Mio. | Vendor, 31.12.2025 | Mittel |
| **Bilanz** | Eigenkapital | $546,20 Mio. | Vendor, 31.12.2025 | Hoch |
| **Bilanz** | Current Ratio | 37,4x | Eigene Berechnung | Hoch |
| **SBC** | SBC (TTM) | $17,61 Mio. | Vendor, Quartalssumme | Hoch |
| **SBC** | SBC / Umsatz (TTM) | 248,4 % | Eigene Berechnung | Hoch |
| **Verwässerung** | Aktienanzahl (YoY) | +16,8 % | Vendor | Hoch |
| **Volatilität** | Beta | 1,80 | Vendor | Hoch |
| **Technisch** | 50-Tage-Durchschnitt | $16,63 | Vendor | Hoch |
| **Technisch** | 200-Tage-Durchschnitt | $22,99 | Vendor | Hoch |
| **Technisch** | 52-Wochen-Spanne | $10,30 – $58,15 | Vendor | Hoch |

---

**DISCLAIMER:** Diese Analyse basiert auf Vendor-Daten (`yfinance`). Für endgültige Anlageentscheidungen sind SEC-Filings (10-K, 10-Q), offizielle IR-Materialien sowie Management-Kommentare (Earnings Calls) als Primärquellen zu konsultieren. Mehrere Kennzahlen weichen zwischen verschiedenen Datenpunkten ab und bedürfen einer Verifizierung anhand von Primärquellen. Es wurde keine IR/SEC-Primärquellenrecherche durchgeführt; die Analyse beschränkt sich auf die über die Tools verfügbaren Daten.

**FINAL TRANSACTION PROPOSAL: HOLD** — Aufgrund der soliden Bilanz mit langer Cash-Reichweite besteht kein unmittelbarer Insolvenzdruck, aber fundamentale Bewertung und operatives Momentum rechtfertigen keinen Kauf. Bestehende Positionen können aufgrund des spekulativen Charakters und ausreichender Liquidität gehalten werden, ein Neuaufbau erscheint fundamental nicht gestützt.

### trader_investment_decision

**Action**: Hold

**Reasoning**: The investment plan lays out a compelling bearish case: an active Death Cross, RSI divergence, 16.8% YoY dilution from SBC running at 2.5x revenue TTM, and a post-earnings sell-off despite a beat — all pointing to further downside risk. However, the plan itself recommends Underweight, not a full Sell, and the Trader's role is to execute the committee's strategic guidance. Existing holders should trim into strength per the plan; new entries should wait for a 200-day SMA reclaim and a second $4M+ revenue quarter. Without confirming that current price has bounced into the 10-EMA selling window, the immediate tactical posture is to hold residual positions but refrain from adding.

**Stop Loss**: 12.6

FINAL TRANSACTION PROPOSAL: **HOLD**

### investment_plan

**Recommendation**: Underweight

**Rationale**: The bull makes a spirited case anchored to Q1 2026's $4.4M print and the $443M cash cushion, arguing Rigetti is at an inflection point after a deliberate reset year. The forward math — annualizing Q1 to ~$17.6M and compressing the P/S toward ~340x — has surface appeal, and the cash runway does eliminate near-term dilution risk.

But the bear won this debate on the weight of evidence. Three arguments proved decisive:

First, **the post-earnings price action is the smoking gun**. Rigetti beat Q1 estimates and the stock still tanked — GuruFocus ran the headline "Why Rigetti Computing Stock Is Tanking" after what should have been a victory lap. When good news is met with aggressive selling, it signals the market is repricing the entire thesis, not just reacting to a data point. The bull's "coiled spring" narrative cannot reconcile this.

Second, **the dilution story is brutal and underappreciated**. SBC of $17.6M TTM — 2.5x total revenue — has driven a 16.8% YoY increase in shares outstanding. This is a stealth tax on shareholders that persists regardless of whether the top line improves. The bull never addressed it.

Third, **the technical picture is objectively bearish, not consolidating**. A Death Cross is active with price ~20% below the 200-day SMA. The MACD histogram has collapsed from 0.79 to 0.09. Most importantly, the bearish RSI divergence — higher price high on May 11 paired with a lower RSI high — is one of the most reliable topping signals in technical analysis. The bull's "textbook consolidation" read ignores this divergence entirely.

The bear's case isn't flawless — the Q1 jump is real, the cash runway is a genuine asset, and the 66% drawdown does create room for upside if execution delivers. But those are conditions, not evidence. The synchronized message from fundamentals (no path to profitability, extreme multiples even on forward numbers, relentless dilution) and technicals (Death Cross, RSI divergence, post-earnings sell-off) points to further downside risk. For existing holders, trimming into strength is prudent. For those without a position, there is no rush — let the company prove a second consecutive growth quarter first.

**Strategic Actions**: 1. **Existing positions**: Trim to 50-75% of current allocation. Use any bounces toward the 10-EMA (~$17-18 zone) or the 50-day SMA as selling windows rather than accumulation points. The post-earnings price rejection suggests rallies will be sold.

2. **New positions**: Do not initiate. The entry signal to watch is a reclaim of the 200-day SMA (~$22.99) on above-average volume, ideally paired with a second consecutive quarter of $4M+ revenue and declining SBC as a percentage of revenue. Until those conditions align, the risk/reward favors patience.

3. **Stop management for residual holdings**: A close below the March low (~$12.60 zone) would invalidate the bounce thesis entirely and signal a leg toward single digits — that level should serve as a hard stop for any retained position.

4. **Monitoring triggers**: 
   - Bullish reversal trigger: Q2 2026 revenue above $5M with narrowing operating losses and SBC below $4M for the quarter.
   - Bearish acceleration trigger: Another "beat and drop" quarter, or a dilutive capital raise despite the cash balance — either would warrant moving to an outright Sell.

5. **Sector context**: IONQ remains the higher-quality name in quantum. If maintaining quantum exposure, consider rotating a portion of RGTI proceeds into IONQ on pullbacks, as the bear correctly noted its broader commercial pipeline justifies the premium. The Xanadu IPO is a sector catalyst but benefits the established leader more than the catch-up trade in a risk-off tape.

### final_trade_decision

**Rating**: Underweight

**Executive Summary**: Bestehende RGTI-Positionen auf 50–75 % der aktuellen Allokation zurückführen. Abverkäufe bevorzugt in Stärkephasen Richtung 10-EMA ($17–18) oder 50-SMA platzieren. Keine Neuaufnahmen. Harter Stop-Loss bei $12,60, ergänzt um einen Frühwarn-Trigger: Wochenschluss unter der 50-SMA ($16,63) erzwingt eine sofortige Überprüfung und voraussichtliche weitere Reduktion. Kapital aus Teilverkäufen in hochwertigere Quantum-Namen (IONQ) oder defensive Anlagen umschichten.

**Investment Thesis**: Die Debatte der Risikoanalysten liefert ein klares Übergewicht der bärischen Argumente, rechtfertigt aber keinen Totalausstieg. Drei Evidenzlinien stützen die Untergewichtung:

**Erstens – Die technische Verfassung ist objektiv bärisch, nicht konsolidierend.** Der Death Cross ist aktiv, der Kurs notiert rund 20 % unter der 200-Tage-Linie ($22,99). Das MACD-Histogramm ist von 0,79 auf 0,09 kollabiert. Die bärische RSI-Divergenz – höheres Kurshoch am 11. Mai bei niedrigerem RSI-Hoch – zählt zu den verlässlichsten Topping-Signalen der technischen Analyse. Der Neutrale Analyst weist zurecht darauf hin, dass gesunde Konsolidierungen oberhalb kurzfristiger gleitender Durchschnitte stattfinden; RGTI ist jedoch unter die 10-EMA zurückgefallen. Die 30-%-Wahrscheinlichkeit eines bullishen Szenarios rechtfertigt keine aggressive Haltung.

**Zweitens – Die Verwässerung ist eine unterschätzte, persistente Belastung.** SBC von $17,6 Mio. TTM (2,5× Gesamtumsatz) hat das Aktienvolumen um 16,8 % YoY ausgeweitet. Selbst bei operativen Fortschritten wird dieser schleichende Wertverlust für Aktionäre fortbestehen. Der Konservative Analyst hat Recht: Die Nettoliquidität von $436 Mio. schützt nicht vor einem weiteren Kursverfall, wenn jährlich $77 Mio. FCF verbrannt werden und die Aktienzahl weiter steigt.

**Drittens – Die Post-Earnings-Preisaktion ist das entscheidende Signal.** RGTI übertraf die Q1-Schätzungen und die Aktie wurde dennoch abverkauft. Wenn gute Nachrichten auf aggressiven Verkaufsdruck treffen, signalisiert dies eine Neubewertung der gesamten Investmentthese, nicht nur eine Datenpunkt-Reaktion. Die gespaltene Sentiment-Lage (Reddit hält, Institutionen bleiben untergewichtet, klassische Medien skeptisch) ist eine Übergangsphase, in der große Richtungswetten meist bestraft werden.

Die bullishen Gegenargumente sind nicht substanzlos: Der Q1-Sprung auf $4,4 Mio. (199 % YoY) ist real, die Cash-Reichweite beseitigt das kurzfristige Verwässerungsrisiko durch Kapitalerhöhungen, und der 66-%-Drawdown vom Allzeithoch schafft Raum für Erholung. Aber dies sind Bedingungen, keine Evidenz. Der Neutrale Analyst liefert mit seinem Zwei-Stufen-Ansatz die ausgewogenste Synthese: Harter Stop bei $12,60 unterhalb des März-Tiefs als Katastrophenschutz, kombiniert mit einem Frühwarn-Trigger bei Verletzung der 50-SMA – genau dann, wenn der einzige verbliebene bullishe Zwischensignal zusammenbricht. Dies respektiert das asymmetrische Chancenprofil, ohne die erheblichen Abwärtsrisiken zu verharmlosen. Der Wechsel von IONQ als höherwertiger Quantum-Name bleibt taktisch sinnvoll.

**Time Horizon**: 3–6 Monate mit Überprüfung nach Q2 2026

### manifest.decision

Underweight
