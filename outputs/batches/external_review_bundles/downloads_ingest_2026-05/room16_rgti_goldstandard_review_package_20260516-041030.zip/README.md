# Room 16 RGTI Goldstandard Review Package

Dieses Paket enthält die prüfbaren Artefakte der RGTI-Goldstandard-Internal-Report-Arbeit.

## Wichtigste Dateien

- `room16-run/generated/internal_best_report.md` — Goldstandard interne RGTI-Lesefassung
- `room16-run/generated/RGTI_manual_review_reading_version.pdf` — PDF-Export der internen Lesefassung
- `room16-run/generated/internal_best_report_sources.md` — Quellen- und Encoding-QA
- `room16-run/generated/RGTI_GOLDSTANDARD_INTERNAL_REPORT_ACCEPTANCE.md` — Abnahmebericht
- `templates/SPECULATIVE_DEEP_TECH_INTERNAL_REPORT_TEMPLATE.md` — generisches Deep-Tech-Template
- `room16-run/complete/` — eigentlicher Aktienreport / Complete-Dossier-Artefakte
- `room16-run/dashboard_status.json` — App-/Dashboard-Status mit Artefaktlinks
- `tests/test_institutional_quality.py` — angepasste Regression für Goldstandard-Caveat + Missing-Caveat-Fall

## Erwarteter Status

- review_status = manual_review
- publishable = false
- internal_rating = Preliminary Underweight
- external_display_rating = Manual Review / Preliminary Underweight
- public_rating = null
- company_archetype = SPECULATIVE_DEEP_TECH_EARLY_COMMERCIAL

## Letzte Verifikation

- Room16 pytest: 125 passed, 41 subtests passed
- Research-Core Deep-Tech pytest: 7 passed
- compileall: grün
- Room16 verify: pass
- Room16 report-machine verify: pass
- Markdown/PDF Encoding-QA: ä ö ü Ä Ö Ü ß € – — „“ grün
