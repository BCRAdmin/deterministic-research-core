# RGTI – Aktienreport

> Interne Room-16-Lesefassung. Nicht öffentlich freigegeben. Keine Anlageberatung. Dieser Report ersetzt die alte, ungefilterte Complete-Dossier-Lesefassung im RGTI-Run. Der unveränderte Rohbericht bleibt als Regression- und Quellenartefakt erhalten.

## Status

| Feld | Wert |
| --- | --- |
| Unternehmen | Rigetti Computing |
| Ticker | RGTI |
| Report-Datum | 2026-05-15 |
| TradingAgents-Datum | 2026-05-14 |
| Review-Status | manual_review |
| Publishable | false |
| Internes Rating | Preliminary Underweight |
| Externe Anzeige | Manual Review / Preliminary Underweight |
| Public Rating | null |
| Company Archetype | SPECULATIVE_DEEP_TECH_EARLY_COMMERCIAL |

## Executive Summary

RGTI ist keine normale Investmentstory. Die Aktie ist im aktuellen Stand eine spekulative Deep-Tech-Option auf künftige kommerzielle Erfolge im Quantencomputing, aber kein bewiesener Compounder und keine Kernposition.

Die fundamentale Evidenz stützt keine Neuaufnahme. Eine kleine bestehende Restposition kann höchstens als Optionswette verstanden werden, wenn die Positionsgröße den binären Technologie-, Finanzierungs- und Verwässerungsrisiken entspricht. Reduktion in Stärke ist rational, weil die Aktie bereits sehr viel zukünftigen Erfolg einpreist, während Umsatzbasis, Operating Loss und Free Cash Flow noch keine tragfähige Langfristthese beweisen.

Es gibt kein Public Rating. Der Report bleibt `manual_review`, `publishable = false` und intern bei **Preliminary Underweight**.

## Key Metrics Snapshot

| Kennzahl | Wert | Einordnung | Source Tier / Evidence Status |
| --- | ---: | --- | --- |
| Market Cap | ca. 6,34 Mrd. USD | Milliardenbewertung trotz sehr kleiner Umsatzbasis | Vendor / unverified |
| FY2025 Revenue | ca. 7,09 Mio. USD | Mini-Umsatzbasis; im Dossier zugleich als Rückgang ggü. Vorjahr markiert | Vendor / unverified |
| Q1 2026 Revenue | ca. 4,4 Mio. USD | Starker Sprung von kleiner Basis, aber kein Skalierungsbeweis | Media/Vendor / unverified |
| Market Cap / FY Revenue | ca. 894x | Bewertung setzt massive künftige Erfolge voraus | Berechnung auf Vendor-Basis |
| Annualisierte Q1 Revenue Run-Rate | ca. 17,6 Mio. USD | Mechanische Annualisierung; keine Wiederholbarkeitsgarantie | Berechnung auf Media/Vendor-Basis |
| Market Cap / annualisierte Q1 Run-Rate | ca. 360x | Auch auf Run-Rate-Basis extrem hoch | Berechnung auf Media/Vendor-Basis |
| Operating Loss Q1 2026 | nicht primär bestätigt | Im lokalen Regression-Material liegt für Q1 2026 kein SEC/IR-bestätigter Operating-Loss-Wert vor | Datenlücke |
| Operating Loss TTM | ca. -84,66 Mio. USD | Operatives Geschäft bleibt deutlich negativ | Vendor/Quartalssumme / unverified |
| Free Cash Flow / Cashburn | ca. -77,22 Mio. USD TTM | Signifikanter Mittelabfluss | Vendor/Quartalssumme / unverified |
| Cash + Investments | ca. 443,5 Mio. USD; ca. 436,3 Mio. USD Nettoliquidität | Verlängert die Runway, rechtfertigt aber nicht die Bewertung | Vendor/Media-Level / unverified |
| SBC / Revenue | ca. 248,4 % TTM | Zentrale Verwässerungsbelastung relativ zur Umsatzbasis | Eigene Berechnung auf Vendor-Basis |
| Source Tier / Evidence Status | Vendor/manual fallback | Keine vollständige SEC/IR-Bestätigung im Regression-Stand | Nicht public-freigabefähig |

## Investment Classification

RGTI ist aktuell eher eine börsennotierte Technologieoption als ein normales operatives Investment. Der Unterschied ist entscheidend:

- Ein normales operatives Investment stützt sich auf wiederholbaren Revenue, belastbare Margen, planbare Kundennachfrage und nachvollziehbare Cashflow-Entwicklung.
- Eine Technologieoption stützt sich auf technische Roadmap, Kapitalpuffer, optionale Marktchancen und die Möglichkeit, dass aus Forschung und frühen Kundenprojekten später ein skalierbares Geschäft entsteht.

RGTI gehört derzeit klar in die zweite Kategorie. Das macht den Titel nicht uninteressant, aber es verschiebt die interne Beweislast deutlich nach oben.

## Technischer Realitätscheck

Rigettis technologische Story ist relevant. Ein 108-Qubit-System, Cepheus und die Roadmap können zeigen, dass das Unternehmen in einem potenziell wichtigen Zukunftsmarkt weiterentwickelt und technische Meilensteine erreicht.

Technische Meilensteine sind aber kein Umsatzbeweis. Für die Aktie zählt nicht nur, ob die Technologie interessant ist, sondern ob daraus wiederholbarer, margenfähiger Revenue entsteht. Technischer Fortschritt kann den Optionswert stützen, ersetzt aber keine belastbare kommerzielle Adoption.

Die entscheidende Frage lautet deshalb: Werden Roadmap und technische Leistungsfähigkeit in zahlende, wiederkehrende Kundenbeziehungen übersetzt? Im aktuellen Evidence-Stand ist diese Schwelle noch nicht erreicht.

## Kommerzielle Adoption

Die bisherige Evidenz spricht für frühe, noch nicht skalierte Adoption. Der Q1-2026-Umsatzsprung ist positiv, aber er kommt von einer sehr kleinen Basis. Bei frühen Deep-Tech-Unternehmen können einzelne Lieferungen, Projektumsätze oder Meilensteine große prozentuale Wachstumsraten erzeugen, ohne dass bereits ein wiederholbares Geschäftsmodell sichtbar ist.

Für eine bessere interne Sicht müsste Rigetti mehrere Quartale mit wiederholbarem Revenue zeigen, größere Aufträge in planbare Umsätze übersetzen und nachweisen, dass diese Umsätze nicht nur technisch spannend, sondern wirtschaftlich tragfähig sind.

## Contract / Order Materiality

Die relevanten Auftragswerte werden im aktuellen Arbeitsstand nicht als SEC/IR-primärbestätigt behandelt. Sie sind daher Vendor-/Media-Level-Arbeitswerte und dürfen nicht als finale Public-Evidence genutzt werden.

| Auftrag / Gegenpartei | Genannter Wert | Materialität zum FY2025 Revenue | Materialität zur Market Cap | Interne Bewertung |
| --- | ---: | ---: | ---: | --- |
| C-DAC Indien | ca. 8,4 Mio. USD | ca. 118 % des FY2025 Revenue | ca. 0,13 % der Market Cap | Operativ relevant gegenüber dem kleinen Umsatz, aber kein Skalierungsbeweis |
| AFRL / U.S. Air Force | ca. 5,8 Mio. USD | ca. 82 % des FY2025 Revenue | ca. 0,09 % der Market Cap | Relevanter Proof-of-Concept, aber keine Bewertungsbrücke |
| Beide zusammen | ca. 14,2 Mio. USD | ca. 200 % des FY2025 Revenue | ca. 0,22 % der Market Cap | Groß relativ zur Umsatzbasis, klein relativ zur Aktienbewertung |

Diese Aufträge wären für ein Unternehmen mit rund 7 Mio. USD Jahresumsatz operativ wichtig. Genau daraus entsteht aber die Bewertungsfrage: Wenn einzelne Aufträge prozentual sehr groß wirken, weil die Umsatzbasis winzig ist, tragen sie noch keine 5–6 Mrd. USD Bewertung.

Die Aufträge sind eher Proof-of-Concept als Bewertungsanker. Es fehlt die Brücke zu skalierbarem, wiederholbarem Revenue: Lieferzeitpunkt, Umsatzrealisierung, Wiederholbarkeit, Kundentyp, Marge, Folgeaufträge und die Frage, ob es sich um kommerzielle Nutzung oder forschungsnahe/prototypische Nachfrage handelt.

## Finanzielle Realität

Die finanzielle Realität ist der Kern des Underweight-Befunds. RGTI hat eine sehr kleine Umsatzbasis relativ zur Bewertung. FY2025 Revenue von rund 7,09 Mio. USD und eine Market Cap von rund 6,34 Mrd. USD ergeben ein Verhältnis, das enorme künftige Skalierung bereits vorwegnimmt.

Der Q1-2026-Umsatzsprung auf rund 4,4 Mio. USD ist ein Fortschritt, aber kein operativer Turnaround. Operating Loss bleibt hoch. Free Cash Flow bleibt negativ. Die Investmentfrage lautet nicht, ob der Umsatz von einer kleinen Basis wachsen kann, sondern ob daraus ein wiederholbares, profitables Geschäft mit sinkendem Cashburn entsteht.

Positive GAAP-Effekte aus Warrant- oder Fair-Value-Veränderungen sind kein operativer Gewinn. Wenn GAAP Net Income besser aussieht, obwohl das operative Ergebnis negativ bleibt und Derivat- oder Warrant-Bewertungseffekte wesentlich sind, darf das nicht als operative Verbesserung interpretiert werden. Der notwendige Caveat lautet:

> GAAP net income was helped by non-operating fair-value effects and does not indicate an operating turnaround.

Cash Runway schützt vor kurzfristigem Finanzierungsdruck, rechtfertigt aber nicht die Bewertung. Ein Cash-Puffer gibt Rigetti Zeit, beweist aber weder Commercial Adoption noch Unit Economics. SBC und Verwässerung bleiben zentral, weil Aktionäre trotz technologischer Fortschritte wirtschaftlich verlieren können, wenn die Aktienzahl steigt oder SBC im Verhältnis zum Revenue extrem bleibt.

## Cash Runway und Verwässerung

Der Cash-Puffer von rund 443,5 Mio. USD ist der wichtigste Schutzfaktor auf der Bilanzseite. Er reduziert unmittelbaren Finanzierungsdruck und gibt Rigetti Zeit, Technologie, Vertrieb und Kundenbeziehungen weiterzuentwickeln.

Dieser Schutzfaktor ist aber kein Kaufargument. Bei einem Free Cash Flow von rund -77,22 Mio. USD TTM ist Runway vor allem Überlebenszeit. Die Bewertung muss irgendwann durch wiederholbares Umsatzwachstum, bessere Margen, niedrigeren Cashburn und kontrollierte Verwässerung getragen werden.

SBC von rund 248,4 % des Revenue ist in diesem Stadium ein zentrales Risiko. Selbst wenn die Technologie Fortschritte macht, kann die wirtschaftliche Beteiligung bestehender Aktionäre verwässert werden.

## Bilanzqualität

Die Bilanzqualität ist kein Nebenthema. Derivative Product Liabilities, Warrant-Effekte und Fair-Value-Veränderungen können das Nettoergebnis stark verzerren. Eine Verbesserung im GAAP Net Income ist deshalb nicht automatisch eine operative Wende.

Intern gilt: Umsatzbeschleunigung ist ein Fortschritt, aber keine Profitabilität. Ein echter Turnaround wäre erst sichtbar, wenn Revenue wiederholbar steigt, operative Verluste sinken, Free Cash Flow weniger negativ wird und Ergebnisverbesserungen nicht aus Warrant-/Fair-Value-Effekten stammen.

## Valuation Disconnect

Die Bewertungsdiskrepanz ist extrem: Milliardenbewertung gegen Mini-Umsatz. Selbst die annualisierte Q1 Revenue Run-Rate von rund 17,6 Mio. USD bleibt winzig relativ zu einer Market Cap von rund 6,34 Mrd. USD. Daraus ergibt sich noch immer ein Umsatzmultiple von rund 360x auf einer nicht verifizierten, mechanisch annualisierten Quartalsbasis.

Die Aktie preist massive Zukunftserfolge ein: technische Ausführung, wiederholbare Nachfrage, größere Aufträge, sinkenden Cashburn, kontrollierte Verwässerung und irgendwann operative Hebelwirkung. Diese Kombination kann theoretisch eintreten, ist aber im aktuellen Evidence-Stand nicht bewiesen.

Die Bewertung wäre nur tragbar, wenn Rigetti über mehrere Jahre wiederholtes Umsatzwachstum zeigt, größere Aufträge in skalierbaren Revenue verwandelt, den Cashburn reduziert und die Verwässerung kontrolliert. Bis dahin ist die Aktie eine hochvolatile Deep-Tech-Option, keine Kernposition.

## Chartbild und Risikomanagement

Technische Analyse ist hier nur Timing- und Risikomanagement. Sie darf die Langfristthese nicht dominieren. Chartstärke kann bei spekulativen Deep-Tech-Titeln eher Risikoappetit als fundamentale Bestätigung zeigen. Für bestehende Positionen ist Stärke deshalb eher ein Fenster zur Reduktion als ein Beweis für eine bessere Investmentthese.

## Was die Sicht ändern würde

Eine bessere interne Bewertung braucht primäre Evidenz und Wiederholbarkeit:

1. SEC/IR-bestätigte aktuelle Zahlen zu Revenue, Cash, Debt, Free Cash Flow, SBC und Aktienzahl.
2. Auftragsdetails mit Wert, Lieferzeitpunkt, Umsatzrealisierung, Wiederholbarkeit, Kundentyp und Margenlogik.
3. Sinkender Operating Loss ohne Warrant-, Derivat- oder Fair-Value-Verzerrung.
4. Mehrere Quartale mit wiederholbarem Umsatzwachstum statt einzelner Meilensteinumsätze.
5. Sinkender Cashburn und nachvollziehbare Cash-Runway-Brücke.
6. Bessere per-share economics durch kontrollierte SBC und geringere Verwässerung.

## Finale interne Sicht

**Manual Review / Preliminary Underweight. Kein Neukauf. Bestehende Kleinstpositionen nur als spekulative Optionswette. Reduktion in Stärke ist rational. RGTI ist aktuell keine Kernposition und kein bewiesener Compounder.**

RGTI bleibt intern beobachtbar, aber nicht public-freigabefähig. Die Technologie kann relevant sein, doch die Aktie verlangt bereits eine Zukunft, die der aktuelle Evidence-Stand noch nicht belegt.

## Appendix

### Triggered Rules

- `market_cap_revenue_gt_100`
- `revenue_ttm_lt_50m`
- `operating_income_ttm_negative`
- `free_cash_flow_ttm_negative`
- `sbc_to_revenue_gt_050`
- `vendor_only_hard_financial_metrics`
- `derivative_warrant_fair_value_effects_detected`
- `no_sec_ir_current_period_evidence`
- `lumpy_revenue_non_scaled_adoption_language`
- `high_volatility_or_beta_gt_15`

### Quality Caps

```json
{
  "SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE": 75,
  "ACCOUNTING_GAIN_NOT_OPERATING_TURNAROUND": 70,
  "ORDER_MATERIALITY_MISSING": 80,
  "VENDOR_ONLY_HARD_METRICS": 75
}
```

### Source Limitations

- Harte Finanzkennzahlen im Regression-Stand sind nicht vollständig durch SEC/IR-Primärquellen bestätigt.
- Market Cap, FY2025 Revenue, Q1 2026 Revenue, Cash, Free Cash Flow, SBC und Verwässerung stammen im vorliegenden Arbeitsstand aus Vendor-, Media- oder berechneten Datenpunkten.
- C-DAC Indien und AFRL / U.S. Air Force werden als Vendor-/Media-Level-Auftragswerte behandelt, nicht als primärbelegte Public-Evidence.
- Daraus folgt: `publishable = false`, `public_rating = null`, keine Public-Freigabe.

### Required Follow-up

1. Aktuelles 10-Q, 8-K, Earnings Release und IR-Deck ziehen und gegen das Dossier abgleichen.
2. Revenue, Operating Loss, Free Cash Flow, Cash, Debt, SBC und Aktienzahl aus Primärquellen neu aufbauen.
3. C-DAC Indien und AFRL / U.S. Air Force mit Originalquelle, Vertragswert, Umsatzzeitpunkt, Wiederholbarkeit und Kundentyp verifizieren.
4. Warrant-, Derivat- und Fair-Value-Effekte vom operativen Ergebnis trennen.
5. Cash Runway mit realistischem Burn und Verwässerungsszenario aktualisieren.
6. Report erst nach bestandenen Gates als Public-Fassung freigeben.

### Encoding-QA

UTF-8-Testzeichen für Markdown und PDF: ä ö ü Ä Ö Ü ß € – — „“

### Regression-Fixture-Hinweis

Der alte RGTI-Report bleibt Regression-Fixture und ist nicht die gefixte Public-Fassung.

Raw Room-16-Output: `/Users/BjornRosinger/Documents/New project/company-dossier-lab/reports/room16/runs/20260515-223522-rgti-e63b8cca/RGTI/generated/raw_room16_report.md`
