# Rigetti Computing (RGTI)

Room 16 Leseregal für RGTI.

Latest internal reading version: `2026-05-15 Room 16 RGTI Internal Manual Review Reading Version.pdf`

Wichtig: RGTI ist `manual_review`, `publishable=false` und hat kein Public Rating. Die interne Lesefassung ist nicht als Public-Report freigegeben.

## Interne Lesefassung

- `2026-05-15 Room 16 RGTI Internal Manual Review Reading Version.pdf`
- `2026-05-15 Room 16 RGTI Internal Manual Review Reading Version.md`

## Legacy / Regression-Fixture

- `2026-05-15 Room 16 RGTI DeepSeek V4 Complete Dossier.pdf`
