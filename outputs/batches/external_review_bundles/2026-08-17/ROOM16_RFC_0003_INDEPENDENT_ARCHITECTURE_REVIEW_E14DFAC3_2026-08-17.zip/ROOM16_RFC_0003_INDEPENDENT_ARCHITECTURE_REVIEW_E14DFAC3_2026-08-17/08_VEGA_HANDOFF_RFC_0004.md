# HANDOFF TYPE: EXECUTE

# RFC-0004 — Semantic Contract Integrity Closure

## Operator decision

```text
RFC-0003 direction = accepted
PassKernel execution = accepted and frozen
Product full regression = accepted
Compatibility Shadow = retained
Semantic Compiler Wave = not yet complete
BA10 = not authorized
```

Arbeite RFC-0004 als **einen einzigen engen Abschlussblock** ab. Kein Report-Rebuild, kein Unternehmenspatch, kein Foundation-Rewrite, kein BA10 und kein Zwischen-Copy-Paste, solange keine Stoppbedingung eintritt.

## A. Registry-aware Cache and Replay Lock

Der Foundation PassKernel bleibt unverändert. Ergänze additiv einen gebundenen Semantic Registry Lock im initialen `SemanticCompileStateIR`:

```text
semantic_registry_authority_sha256
metric_signature_authority_sha256
formula/evidence/claim/decision policy hashes
pass_manifest_sha256
compiler implementation commit/version
```

Diese Werte müssen den Input-Payload-Hash und damit jeden Cache-Key beeinflussen.

Pflichtfixture:

```text
same source input + changed semantic registry/signature authority
=> no cache_hit
=> recompute or fail-closed
```

## B. Formula Operand Semantics and Provenance

`FormulaOperandIR` darf keine Metadaten und Evidence des Result-Facts kopieren.

Jede Rolle wird aufgelöst als:

```text
Role -> existing TypedFactIR
oder
Role -> registered PolicyParameterIR
oder
quarantined_unresolved_operand
```

Pflichtfelder je Operand:

```text
role
expected_role_contract
operand_fact_or_parameter_id
value
dimension
unit
currency
period
source/evidence lineage
origin mode
hash
```

L10 prüft gegen Formula Registry:

```text
role exists
role cardinality
role dimension/unit
period compatibility
source/evidence binding
result dimension
```

Nicht auflösbare Legacy-Operands blockieren fail-closed; sie dürfen nicht durch Result-Metadaten ersetzt werden.

## C. Canonical Table/Cell Artifact and Lineage Closure

Alle vollständigen `SemanticTableIR`/Cells bleiben content-addressed abrufbar. Um große States zu vermeiden, ist ein Sidecar Artifact Store zulässig, aber jeder `SemanticTableRefIR` benötigt:

```text
artifact_path_or_uri
artifact_sha256
cell_count
locator contract
```

Legacy Table-/Cell-IDs werden deterministisch auf Canonical IDs gemappt oder ausdrücklich quarantänisiert.

Ein ausführbarer Fact mit deklarierter, aber unauflösbarer Table-/Cell-Lineage darf nicht als PASS gelten.

Neue L10-Invariants:

```text
CANONICAL_TABLE_ARTIFACTS_RESOLVABLE
DECLARED_TABLE_CELL_LINEAGE_COMPLETE
EXECUTABLE_FACT_TABLE_LINEAGE_COMPLETE
```

Die aktuell 44 unaufgelösten Facts müssen entweder korrekt gebunden oder ehrlich quarantänisiert sein.

## D. Decision Claim/Fact/Evidence Lineage

Den lossless JSON graph und den registry-typisierten Graph behalten.

Ergänze echte Kanten/SubjectRefs:

```text
decision input -> claim
risk -> risk claim/fact/evidence
score contribution -> contributing facts/claims
rule -> registered rule + evaluated inputs
rationale -> supporting and opposing claims
permission -> policy/rule lineage
```

`not_present` Nodes dürfen Schema-Coverage darstellen, aber nicht Instance-Lineage-Completeness erfüllen.

Neue L10-Invariants:

```text
DECISION_CLAIM_LINEAGE_COMPLETE
DECISION_FACT_LINEAGE_COMPLETE
DECISION_SCORE_INPUTS_BOUND
DECISION_RISK_COUNTEREVIDENCE_BOUND
```

## E. Verification and Final Verdict

Die bestehenden grünen Gates werden nicht entfernt, sondern verschärft:

- `FORMULA_OPERAND_LINEAGE_COMPLETE` prüft Semantik und Provenienz, nicht nur IDs/Hashes.
- `TABLE_FACT_LINEAGE_TRUTHFUL` blockiert unaufgelöste deklarierte Lineage bei executable facts.
- `DECISION_REGISTRY_BINDINGS_COMPLETE` wird von Instance-Lineage-Gates ergänzt.
- `semantic_compiler_wave_complete` wird ausschließlich aus diesen realen Diagnostics abgeleitet.

## F. Execution Attestation Boundary

Ohne BA10 vorwegzunehmen, definiere additiv:

```text
ExecutionAttestationIR@1
```

Es bindet nach Kernel-Ende PassExecutionRecords und den sealed Verification Report. Es ist kein semantischer Pass und verändert keine Compiler-Wahrheit.

Entferne provisorisch wahre `PASS_KERNEL_EXECUTION_COMPLETE`-/`FIXTURE_DIAGNOSTIC_CODES_STABLE`-Behauptungen aus dem inneren L10 oder markiere sie als pending. Fixture-Stabilität gehört zur Build-/Release-Attestation, nicht zum issuerbezogenen CompileVerdict.

## Unveränderliche Grenzen

```text
Foundation 1.0.0 immutable
Registry Foundation 1.1.0 retained
Authority Bundle v3 unchanged
WM/COST/ABT archives unchanged
Product semantic authority absent
compiler_mode=compatibility_shadow
source_native_fact_generation=false
release_ready=false
publication_allowed=false
renderer_cutover=false
BA10=false
```

## Stoppbedingungen

Nur stoppen, wenn Foundation 1.0.0, Authority Bundle v3 oder Canary-Archive verändert werden müssten, Product fachliche Authority erhalten müsste oder ticker-spezifischer Code notwendig wäre. Dann neues RFC; keine Umgehung.

## Pflichtoutput

```text
00_EXECUTIVE_SUMMARY.md
01_RFC_0004_IMPLEMENTATION_RECORD.md
02_SEMANTIC_REGISTRY_CACHE_LOCK.json
03_FORMULA_OPERAND_BINDING_AUDIT.json
04_CANONICAL_TABLE_ARTIFACT_AUDIT.json
05_TABLE_CELL_LINEAGE_CLOSURE.json
06_DECISION_CLAIM_FACT_LINEAGE.json
07_L10_DIAGNOSTICS_AND_VERDICT/
08_EXECUTION_ATTESTATION_IR.json
09_WM_COST_ABT_REPLAY_RESULTS.md
10_PRODUCT_FULL_REGRESSION.md
11_FOUNDATION_REGISTRY_ABI_IMMUTABILITY.md
12_SEMANTIC_WAVE_FINAL_VERDICT.json
RESULT_MANIFEST.json
```

Danach genau eine enge Prüfung der Findings `RFC3-AR-001` bis `RFC3-AR-005`. Kein neuer allgemeiner Unternehmens- oder Architektur-Audit. BA10 erst nach ausdrücklichem PASS.
