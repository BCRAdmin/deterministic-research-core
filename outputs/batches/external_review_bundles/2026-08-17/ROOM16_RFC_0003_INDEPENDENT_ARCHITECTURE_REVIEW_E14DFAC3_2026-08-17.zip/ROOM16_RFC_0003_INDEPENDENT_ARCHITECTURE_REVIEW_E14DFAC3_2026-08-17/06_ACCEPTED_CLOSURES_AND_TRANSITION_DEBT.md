# Accepted Closures and Transition Debt

## Closed and retained

- Foundation PassKernel is the execution authority for the ten semantic passes.
- Executed, replayed and cache-hit modes converge to one final payload hash per Canary.
- Formula Operand and Evaluation IRs are content-addressed.
- Required Evidence Graph node classes exist.
- The generic Decision JSON graph is lossless.
- Parsed IRs are bound in VerificationPlan v3.
- Stable fixture diagnostics pass 16/16 exact-code checks.
- Product full verification, Foundation freeze and Registry freeze pass.
- Authority Bundle v3 and WM/COST/ABT archives remain unchanged.

## Accepted transition debt

- `compiler_mode=compatibility_shadow`
- `source_native_fact_generation=false`
- no renderer cutover
- release/publication remain false
- the post-kernel execution seal will become a formal sidecar/attestation in the Artifact ABI phase
