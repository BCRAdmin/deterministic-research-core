# BA4 Table Discovery Audit

## Aktueller Parser

- JSON: rekursive Records; Tabelle nur für nichtleere Listen aus Dictionaries.
- CSV: flache `DictReader`-Zeilen.
- Text/sonstige UTF-8-Artefakte: ein Textrecord, keine Tabelle.
- Legacy-Bridge: bereits akzeptierte `table_id`-/`cell_id`-Facts werden in CanonicalTableIR umgewandelt.

## Fehlende Verträge

- HTML-/SEC-Tabellenstruktur
- Multi-Header und verschachtelte Header
- Row-/Column-Achsen und Periodenachsen
- Transponierte Tabellen
- Sparse Tables
- Footnote-/Unit-/Scale-Header
- Merged Cells
- Detected/Registered/Excluded Coverage
- vollständige Source-Locator-Rekonstruktion
- Tests für reale Canary-Tabellenformen

## Akzeptanzkriterium

```text
detected_source_tables
=
registered_source_tables
+
explicitly_excluded_source_tables
```

Für jede registrierte Tabelle:

```text
source bytes
→ table locator
→ row/column axes
→ cell locator
→ normalized record
→ typed fact
```

Die Legacy-Bridge kann während der Migration bestehen bleiben, darf aber nicht als Beweis dienen, dass die neue Table Grammar die Primärquelle verstanden hat.
