# Scope Alignment Matrix

| Genehmigter Abschnitt | Genehmigte Bedeutung | Implementierter Stand | Urteil |
|---|---|---|---|
| BA4 / L3 | ParsedDocumentIR + CanonicalTableIR; Multi-Header, transposed, sparse, Locator | JSON list-of-dicts, CSV, Text; Legacy-Table-Bridge | partial |
| BA5 / L4-L5 | Normalize from parsed records/tables, then strict Typed Facts before Claims | Re-typing directly from Legacy Fact Ledger | partial |
| BA6 / L6 | Registry-bound Metrics and Formula Evaluation | Legacy formulas re-evaluated; structurally useful | accepted_shadow_with_limits |
| BA7 / L7-L8 | Evidence and Claim Graphs | Separate BA7 Evidence and BA8 Claim; presence checks, limited semantic lineage | partial |
| BA8 / L9 | Decision Graph | Implemented as BA9; graph plus embedded legacy payload | partial |
| BA9 / L10 | VerificationPlan, DiagnosticIR, VerificationReport, CompileVerdictIR | absent | not_implemented |
| BA10 | Artifact ABI / Renderer | correctly not started | compliant |
