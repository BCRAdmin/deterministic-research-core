# Registry Semantic Audit

## Quantitative Struktur

```text
Legacy Metric IDs: 282
Canonical Metric Definitions: 9
Formula IDs: 32
Formula Definitions: 23
Claim Kinds: 7
Decision Node Definitions: 10
```

Verteilung der Metric IDs:

```text
metric.operating_kpi      174
metric.filing_numeric      34
metric.guidance            18
metric.core_financial      17
metric.scenario            16
metric.capital_allocation  12
metric.valuation            5
metric.technical            4
metric.risk                 2
```

## Positive Bewertung

- Definition und Instanz sind getrennt.
- Unbekannte und positionale Prefixes werden quarantänisiert.
- Formula Definitions besitzen deutlich bessere Operandrollen.
- Product ist kein Registry-Owner.
- Ticker-spezifische Definitionen werden blockiert.

## Architekturdefizit

Die neun Metric Definitions sind fachlich zu breit. Praktisch jede Definition akzeptiert fast das gesamte gemeinsame Vokabular aus Dimensionen, Fact Types, Periodenarten, Units, Scales und Währungen.

Damit kann die Registry derzeit vor allem beantworten:

```text
Zu welchem Namespace gehört diese ID?
```

Sie kann noch nicht zuverlässig beantworten:

```text
Darf genau diese Metrik genau diese wirtschaftliche Semantik besitzen?
```

## Erforderliche Zielstruktur

Eine Lösung muss nicht 282 einzeln hardcodierte Definitionen erzeugen. Geeignet wäre:

```text
Metric Family Definition
+ Semantic Signature Template
+ Parameterized Metric Instance
+ Expected Contract Hash
```

Beispiel:

```text
membership_count
  dimension=count
  fact_kind=instant_stock
  period_kind=instant
  allowed_units=count
  aggregation=none

renewal_rate
  dimension=percent
  fact_kind=point_rate
  period_kind=instant
  allowed_units=percent
  aggregation=none
```

Zusätzlich sind Tests für **valide, aber fachlich falsche Kombinationen** erforderlich.
