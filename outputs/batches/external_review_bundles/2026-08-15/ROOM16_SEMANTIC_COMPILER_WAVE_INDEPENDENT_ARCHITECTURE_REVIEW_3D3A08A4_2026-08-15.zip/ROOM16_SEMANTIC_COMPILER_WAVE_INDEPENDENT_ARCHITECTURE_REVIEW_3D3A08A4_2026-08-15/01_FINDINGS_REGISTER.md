# Findings Register

## SCW-001 — Der vorgesehene BA9-/L10-Verification-Pass fehlt

- **Severity:** `high`
- **Status:** `open`
- **Root cause:** Die Bauabschnittsnummern wurden gegenüber der genehmigten Architektur verschoben. Der aktuelle Passvertrag endet mit BA9 Decision Graph und enthält keinen L10-Verification-Pass.
- **Impact:** Der Abschlussstatus semantic_compiler_wave_complete ist nicht belastbar. Der zentrale Schutz gegen False Pass, doppelte Verdicts und Selbstbestätigung wurde nicht als Compiler-Pass umgesetzt.
- **Required fix:** BA-Nummerierung und Layerzuordnung wieder an die genehmigte Architektur anbinden und einen echten L10-Verification-Pass ergänzen, dessen Verdict ausschließlich aus gebundenen Diagnostics abgeleitet wird.

**Evidence**

- Genehmigte Architektur: BA8 Decision Graph; BA9 Verification; L10 erzeugt DiagnosticIR und CompileVerdictIR.
- Implementierter Passvertrag: BA7 Evidence Graph, BA8 Claim Graph, BA9 Decision Graph; kein VerificationPlan, DiagnosticIR, VerificationReport oder CompileVerdictIR.

## SCW-002 — Die neue IR-Kette bildet noch keine durchgehende Compiler-Spine

- **Severity:** `high`
- **Status:** `open`
- **Root cause:** ParsedDocumentIR und CanonicalTableIR werden erzeugt, aber die Typed Facts werden direkt aus dem bereits akzeptierten Legacy-Fact-Ledger neu verpackt. Evidence-, Claim- und Decision-Graphen werden ebenfalls aus Legacy-Endartefakten aufgebaut.
- **Impact:** Die Implementierung validiert und rehydriert die bestehende Pipeline, ersetzt aber noch nicht die fehlende Source→Parse→Normalize→Facts→Claims→Decision-Passkette. Bereits vorhandene Legacy-Semantikfehler werden übernommen, nicht aus Primärartefakten verhindert.
- **Required fix:** Eine explizite, hashgebundene IR-Spine herstellen. Legacy-Bridges dürfen als benannte Compatibility-Inputs existieren, müssen aber diagnostiziert werden und dürfen die eigentliche Parser-/Normalizer-Lineage nicht still umgehen.

**Evidence**

- replay_semantic_wave_archive parst Snapshots und entdeckt Tabellen.
- Danach wird build_typed_facts(facts) direkt mit fact_ledger.json aufgerufen; parsed_documents und discovered_tables sind kein Input der Normalisierung oder Fact-Erzeugung.
- ClaimGraph konsumiert legacy analyst_claims.json; DecisionGraph konsumiert legacy decision_packet.json.

## SCW-003 — BA4 erfüllt den genehmigten Table-Discovery-Vertrag nicht

- **Severity:** `high`
- **Status:** `open`
- **Root cause:** Der Parser erkennt Tabellen nur als flache CSVs oder nichtleere JSON-Listen aus Objekten. Text-/HTML-Artefakte erzeugen keine Tabellen; komplexe Header-, Achsen- und Transpositionssemantik wird nicht modelliert. Zusätzlich wird akzeptierte Legacy-Tabellenlineage gebridged.
- **Impact:** Die in der Architektur geforderte Garantie 'jede Canary-Zelle mit stabiler ID und Locator' ist nicht bewiesen. Reale SEC-/IR-Tabellen können den Vertrag weiterhin umgehen.
- **Required fix:** Source-Table-Discovery vor Validation implementieren: echte Tabellenformate, Multi-Header, transponierte und sparse Tabellen, explizite Exclusions, Row-/Column-Achsen und detected=registered+excluded.

**Evidence**

- JSON-Discovery: list[dict] wird als Tabelle behandelt; Spalten sind alphabetisch sortierte Schlüssel.
- CSV: flache DictReader-Zeilen.
- Text: genau ein Textrecord, Tabellenliste leer.
- Die BA4-Tests decken eine einfache JSON-Tabelle sowie malformed/tamper ab, nicht multi-header, transposed, sparse oder vollständige Source-Locator-Grammatik.

## SCW-004 — Die Metric Registry ist überwiegend eine Namespace-Klassifikation, kein geschlossenes semantisches Typsystem

- **Severity:** `high`
- **Status:** `open`
- **Root cause:** 282 Legacy-IDs werden nur neun sehr breiten Definitionen zugeordnet. Die Definitionen erlauben nahezu dieselben Dimensionen, Fact Types, Periodenarten, Units, Scales und Währungen.
- **Impact:** Ein fachlich falscher, formal erlaubter Fact kann weiterhin bestehen: etwa Mitgliederbestand als Währungsfluss, absolute Renewal Rate als YoY-Change oder Quartalsrate als Periodensumme. 100 % Identifier Coverage ist daher nicht gleich 100 % semantische Contract Coverage.
- **Required fix:** Definitionen oder Definition-Templates mit enger semantischer Signatur einführen. Jede Instanz benötigt einen erwarteten Contract-Hash für Dimension, Fact Type, Periodenrolle, Unit, Scale, Currency und Aggregationsverhalten.

**Evidence**

- 174 der 282 IDs binden an metric.operating_kpi; weitere große Gruppen an metric.filing_numeric und metric.guidance.
- Die Definitionen akzeptieren unter anderem Currency, Count, Percent, Text, Instant, Duration, Rate, Guidance und fast alle Fact Types.
- Negative Tests verwenden ungültige Fantasiewerte wie duration_weeks oder future_guess, prüfen aber nicht valide, fachlich falsche Kombinationen.

## SCW-005 — Der Cross-Company-Coverage-PASS enthält fest codierte Erfolgswerte

- **Severity:** `high`
- **Status:** `open`
- **Root cause:** audit_cross_company setzt zentrale Gates wie registry_identifier_coverage=100, unknown_executable_ids=0, semantic_collisions=0 und lossy_decision_roundtrips=0 als Literale, statt sie aus den Einzelergebnissen zu berechnen.
- **Impact:** Das zentrale Aggregatevidence kann grün bleiben, obwohl ein Real-Canary- oder Coverage-Fehler vorhanden ist. Dies reproduziert genau die frühere False-Pass-Klasse.
- **Required fix:** Alle Aggregate-Gates aus den per-company Artefakten und Diagnostics berechnen. Keine Erfolgszahl darf im Evidence-Compiler als konstante Zielzahl eingesetzt werden.

**Evidence**

- Die Cross-Company-gates werden als konstantes Dictionary aufgebaut.
- Der Status prüft anschließend lediglich, ob diese Konstanten zu {0,100,false} gehören.

## SCW-006 — Claim- und Evidence-Vollständigkeit prüft Existenz, nicht semantische Unterstützung

- **Severity:** `high`
- **Status:** `open`
- **Root cause:** Der Claim Graph akzeptiert einen Claim, wenn irgendeine bekannte Evidence-ID vorhanden ist und seine Fact-IDs existieren. Er prüft nicht, ob die Claim-Evidence genau die gebundenen Facts unterstützt. Fehlende Source-Registry-Einträge werden im Evidence Graph zudem als source_reference-Platzhalter erzeugt.
- **Impact:** Ein Claim kann mit Evidence A und einem Fact aus Evidence B als vollständig gelten. Eine unvollständige Source Registry kann durch synthetische Referenznodes verdeckt werden.
- **Required fix:** End-to-end Lineage-Invariante implementieren: jeder materielle Claim-Span und Numeric Binding muss über denselben registrierten Evidence-/Source-Pfad belegt sein; unbekannte Source-IDs blockieren.

**Evidence**

- Claim evidence complete bedeutet: nicht leer und keine unbekannte Evidence-ID.
- Bound Facts werden separat an den Claim gebunden; ein Schnittmengen-/Lineage-Check Fact→Evidence→Claim fehlt.
- Bei fehlendem Source Node wird ein Source-Reference-Node erzeugt statt eines blockierenden Diagnostic.

## SCW-007 — Der Decision-Roundtrip beweist nur die Erhaltung einer eingebetteten Legacy-Kopie

- **Severity:** `high`
- **Status:** `open`
- **Root cause:** DecisionGraphIR speichert das vollständige Legacy Decision Packet. roundtrip_legacy_decision gibt diese Kopie zurück und vergleicht ihren Hash; es rekonstruiert das Packet nicht aus Nodes und Edges.
- **Impact:** 3/3 lossless Roundtrips belegen nicht, dass DecisionGraphIR Inputs, Regeln, Risiken, Counterevidence, Scores und Permission Corridors verlustfrei ausdrückt.
- **Required fix:** Legacy-kompatibles Decision Packet deterministisch aus dem Graph rekonstruieren und erst dieses Ergebnis gegen den Legacy-Hash prüfen. Die eingebettete Legacy-Kopie darf höchstens Vergleichs-Sidecar sein.

**Evidence**

- DecisionGraphIR enthält legacy_payload, legacy_payload_sha256 und roundtrip_payload_sha256.
- roundtrip_legacy_decision kopiert graph.legacy_payload und verifiziert nur dessen Hash.
- Die Graph-Nodes könnten unvollständig sein, während der Roundtrip weiterhin exakt besteht.

## SCW-008 — Das Evidence-Bundle ist für die behauptete Wave-Abnahme nicht selbsttragend

- **Severity:** `medium`
- **Status:** `open`
- **Root cause:** Das Bundle enthält Summaries und Coverage-Matrizen, aber nicht die tatsächlichen IR-Artefakte, Pass Contracts, Registry-Authority-Datei, Diagnostic-/Verdict-Artefakte, Graph-Exporte oder vollständigen benannten Testnachweise.
- **Impact:** Ein Offline-Reviewer kann zentrale Behauptungen nicht allein aus dem Release-Evidence-Bundle reproduzieren.
- **Required fix:** Contracts und tatsächliche IR-/Diagnostic-Artefakte direkt einbetten oder in ein vollständig hashgebundenes Artifact-Archive aufnehmen.

**Evidence**

- 19 manifestgebundene Ergebnisdateien; keine per-company ParsedDocumentIR-, CanonicalTableIR-, TypedFactIR-, Graph- oder Diagnostic-Artefakte.
- Die unabhängige Architekturprüfung musste zusätzlich GitHub-Quellcode lesen.

## SCW-009 — Die Negative-Fixture-Evidence weist die verlangte Rot/Grün/Reintroduction-Kette nicht einzeln nach

- **Severity:** `medium`
- **Status:** `open`
- **Root cause:** Für alle 16 Fixtures wird eine True-Tabelle ausgegeben, während beide Machine-Proof-Läufe denselben pytest-Befehl und nur eine Punktfolge enthalten.
- **Impact:** Die Unit Tests sind nützlich, die geforderte finding-/fixture-spezifische Closure-Evidence ist aber nicht vollständig reproduzierbar.
- **Required fix:** Pro Fixture drei oder vier benannte Artefakte mit Input-Hash, erwartetem Diagnostic Code, tatsächlichem Diagnostic und Gate-Ergebnis binden.

**Evidence**

- Keine fixture-spezifischen Artefakt-Hashes oder getrennten defective/corrected/reintroduced Payloads im Bundle.
- Die Tests prüfen Exceptions, aber das Release-Bundle bindet nicht jeden Zustand einzeln.

## SCW-010 — Die Product-Gesamtverifikation ist nur bedingt bestanden

- **Severity:** `medium`
- **Status:** `open`
- **Root cause:** Der vollständige Product-Verify wurde mit ROOM16_VERIFY_SKIP_HARDENING_STATE=1 ausgeführt; der Hardening Verdict wurde nicht neu erzeugt.
- **Impact:** Das ist kein Fehler der Semantic Registry, darf aber nicht als uneingeschränkter Product Full Regression PASS gelten.
- **Required fix:** Entweder Hardening State reproduzierbar erneuern und ungekürzt prüfen oder den Status explizit als conditional_product_regression_pass führen.

**Evidence**

- Das Bundle bezeichnet den Lauf als Product verification PASS, dokumentiert aber den übersprungenen volatile hardening-age Check.