# Source References

## Reviewed bundle

- `ROOM16_SEMANTIC_COMPILER_WAVE_3d3a08a41611_2026-08-15.zip`
- SHA-256: `2117cf07de23db002f59cb6f2531f46065e9dc65bf5edde784f92e67d7c2675c`

## Git commits reviewed

- Research evidence commit: `3d3a08a41611432050eb8a550493db969498afec`
- Registry Foundation commit: `607cdc98e17caf35e47850e73c6b90487bba4193`
- Semantic implementation commit: `7d5c1f920adb9aa41c27cd73da137f6379f1b08c`
- Product mirror commit: `82c5525f3291ace4e3d8c0fdeee6bd67348f5a38`

## Key implementation surfaces reviewed

- `semantic_wave_pass_contracts.json`
- `pass_protocol.py`
- `parser.py`
- `typed_facts.py`
- `metrics.py`
- `graphs.py`
- `legacy_replay.py`
- `release_gates.py`
- `registry_foundation_v1_1.json`
- `authority.py`
- `coverage.py`
- `test_registry_foundation_v1_1.py`
- `test_semantic_compiler_wave.py`
