# VEGA HANDOFF — RFC-0002

## Operatorentscheidung

```text
Semantic Compiler Wave 3d3a08a4:
CHANGES_REQUIRED

Registry Foundation 1.1.0:
RETAIN

Foundation 1.0.0:
RETAIN / IMMUTABLE

Current Shadow Scaffolding:
RETAIN

semantic_compiler_wave_complete:
FALSE

BA10:
NOT AUTHORIZED
```

Der aktuelle Stand ist wertvolle Migrationstechnik, erfüllt aber die genehmigte BA4–BA9-Semantik noch nicht vollständig.

## Neuer begrenzter Arbeitsblock

Erzeuge und bearbeite:

```text
RFC-0002
Semantic IR Spine and Verification Completion
```

Kein Rewrite, keine Unternehmenssonderregel, kein BA10, kein Renderer-Cutover.

### A. Pass- und Bauabschnittsordnung korrigieren

Verbindliche Zuordnung:

```text
BA4 = L3 Parse and Discover
BA5 = L4 Normalize and Reconcile + L5 Typed Facts
BA6 = L6 Metrics and Formula Evaluation
BA7 = L7 Evidence Graph + L8 Claim Graph
BA8 = L9 Decision Graph
BA9 = L10 Verification
```

Der Passvertrag muss zusätzlich einen echten L10-Verification-Pass enthalten.

### B. Durchgehende IR-Spine herstellen

Der neue Compilerpfad muss tatsächlich lauten:

```text
SourceSnapshotIR
→ ParsedDocumentIR / CanonicalTableIR
→ NormalizedRecordIR
→ TypedFactIR
→ MetricIR / FormulaEvaluationIR
→ EvidenceGraphIR
→ ClaimGraphIR
→ DecisionGraphIR
→ DiagnosticIR / CompileVerdictIR
```

Nicht zulässig:

```text
Parser läuft separat
+
Typed Facts werden direkt aus dem Legacy Fact Ledger übernommen
```

Ein Legacy-Fact-Bridge-Pass ist während der Migration zulässig, wenn er:

- ausdrücklich als Compatibility Adapter benannt ist;
- jedes übernommene Feld mit Provenienz bindet;
- einen Diagnostic über den Bypass erzeugt;
- nicht als Beweis für Source-derived Compilation gilt;
- nachweisbar entfernbar ist.

### C. BA4 Table Grammar vervollständigen

Implementiere mindestens:

- HTML-/strukturierte Source Tables;
- Multi-Header;
- transposed;
- sparse;
- merged/header axes;
- Unit/Scale/Period Header;
- dash/zero/missing/not-applicable;
- stabile Cell Locator;
- explicit exclusion.

Gate:

```text
detected_source_tables
=
registered_source_tables
+
explicitly_excluded_source_tables
```

### D. Metric Registry semantisch schließen

Die 282 IDs dürfen nicht nur an neun breite Namespace-Buckets gebunden werden.

Implementiere generische, parameterisierte Semantic Signatures:

```text
dimension
fact_kind
fact_subtype
period_role
unit
scale
currency
aggregation_behavior
direction_contract
comparison_contract
```

Jede aktive Metric Instance benötigt genau einen erwarteten Contract-Hash.

Pflichttests für valide, aber fachlich falsche Kombinationen:

- stock metric als period flow;
- absolute rate als YoY change;
- quarterly rate als period total;
- count als currency;
- guidance als historical actual;
- per-share rate als total cash flow;
- percentage-of-total als comparison change.

### E. Cross-Company-Gates berechnen

Entferne fest codierte Erfolgswerte aus `audit_cross_company`.

Jeder Aggregatewert muss aus gebundenen per-company Results oder Diagnostics berechnet werden.

Nicht zulässig:

```text
registry_identifier_coverage = 100
unknown_executable_ids = 0
semantic_collisions = 0
```

als Literale im Evidence-Compiler.

### F. Claim-/Evidence-Lineage schließen

Jeder Numeric Binding und jede materielle Assertion braucht:

```text
Claim
→ Fact
→ Evidence
→ registrierte Source
→ Locator
```

Ein beliebiges bekanntes Evidence-Objekt reicht nicht.

Unbekannte Source IDs dürfen nicht still als `source_reference` synthetisiert werden.

### G. Decision Graph wirklich roundtripfähig machen

Rekonstruiere das Legacy-kompatible Decision Packet aus den Graph Nodes und Edges.

Der Roundtrip-PASS darf nicht auf `return deepcopy(graph.legacy_payload)` beruhen.

Das Legacy Payload darf nur Vergleichs-Sidecar sein.

### H. BA9 / L10 Verification implementieren

Mindestens:

```text
VerificationPlan
DiagnosticIR
VerificationReport
CompileVerdictIR
```

`DiagnosticIR` benötigt stabile Codes, Layer, Pass, Subjects, Source Refs, expected/actual, Root Cause, Fixture und Release Effect.

Der Verdict wird ausschließlich aus Diagnostics berechnet.

### I. Evidence Bundle selbsttragend machen

Das nächste Bundle bindet mindestens:

- Registry Authority und Product Mirror;
- Pass Contracts;
- alle IR Schemas;
- per-company IR Artifact Archive;
- Table Discovery Coverage;
- Metric Semantic Signatures;
- Formula Evaluations;
- Evidence/Claim/Decision Graph Artifacts;
- Verification Reports;
- Compile Verdicts;
- fixture-spezifische defective/corrected/reintroduced Artefakte;
- vollständige Testlogs;
- Git Status und Commits.

### J. Product Verification

Entweder:

```text
npm run verify
```

ohne Skip vollständig bestehen lassen,

oder den Status korrekt als:

```text
conditional_product_regression_pass
```

ausweisen. Kein unqualifiziertes Full-PASS bei übersprungenem Hardening-State.

## Acceptance Criteria

```text
pass_chain_contains_l10_verification = true
diagnostic_ir_emitted_for_all_canaries = true
compile_verdict_derived_only_from_diagnostics = true
source_to_fact_ir_spine_connected = true
legacy_fact_bypass_unlabelled = 0
detected_table_coverage = 100%
metric_semantic_signature_coverage = 100%
valid_but_wrong_metric_fixtures_blocked = true
cross_company_gates_hardcoded = 0
claim_fact_evidence_source_lineage_complete = true
synthetic_missing_source_references = 0
decision_roundtrip_reconstructed_from_graph = true
foundation_v1_unchanged = true
registry_foundation_1_1_unchanged_or_versioned_via_rfc = true
authority_bundle_v3_unchanged = true
wm_cost_abt_archives_unchanged = true
ba10_authorized = false
```

## Pflichtoutput

```text
00_EXECUTIVE_SUMMARY.md
01_RFC_0002_IMPLEMENTATION_RECORD.md
02_PASS_AND_LAYER_ALIGNMENT.md
03_CONNECTED_IR_SPINE_PROOF.md
04_TABLE_DISCOVERY_COVERAGE.md
04_TABLE_DISCOVERY_COVERAGE.json
05_METRIC_SEMANTIC_SIGNATURES.md
05_METRIC_SEMANTIC_SIGNATURES.json
06_GRAPH_LINEAGE_RESULTS.md
06_GRAPH_LINEAGE_RESULTS.json
07_DECISION_RECONSTRUCTION_ROUNDTRIP.md
07_DECISION_RECONSTRUCTION_ROUNDTRIP.json
08_VERIFICATION_PLAN.md
08_DIAGNOSTIC_IR_ARCHIVE.zip
09_COMPILE_VERDICT_RESULTS.md
09_COMPILE_VERDICT_RESULTS.json
10_NEGATIVE_FIXTURE_ARTIFACTS.zip
11_WM_COST_ABT_RESULTS.md
12_PRODUCT_REGRESSION_STATUS.md
13_SEMANTIC_WAVE_COMPLETION_VERDICT.json
RESULT_MANIFEST.json
```

Danach erneut unabhängige Architekturabnahme. BA10 erst nach explizitem PASS.
