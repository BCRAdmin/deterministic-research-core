# BA9 / L10 Verification Gap

## Genehmigte Zielsetzung

BA9 sollte einen gemeinsamen Verification Plan mit stabilen Diagnostics liefern. Der Verdict darf nur aus gebundenen Diagnostics ableitbar sein.

## Tatsächlicher Stand

Die aktuelle Passkette enthält neun Passes und endet mit:

```text
ba9.l9.build_decision_graph
```

Es fehlen:

```text
ba9.l10.verify_semantics
DiagnosticIR
CompileVerdictIR
VerificationPlan
VerificationReport
```

Der Coverage-Audit setzt zudem mehrere Erfolgswerte als Konstanten.

## Erforderliche Lösung

Ein zusätzlicher L10-Pass muss:

1. alle Outputs L3–L9 als Inputs binden;
2. Diagnostics mit stabilen Codes erzeugen;
3. Severity und Release Effect trennen;
4. keine Success-Gates hardcoden;
5. CompileVerdictIR ausschließlich aus Diagnostics berechnen;
6. Tamper, fehlende Passes und widersprüchliche States fail-closed blockieren;
7. pro Canary ein vollständiges VerificationReport-Artefakt ausgeben.
