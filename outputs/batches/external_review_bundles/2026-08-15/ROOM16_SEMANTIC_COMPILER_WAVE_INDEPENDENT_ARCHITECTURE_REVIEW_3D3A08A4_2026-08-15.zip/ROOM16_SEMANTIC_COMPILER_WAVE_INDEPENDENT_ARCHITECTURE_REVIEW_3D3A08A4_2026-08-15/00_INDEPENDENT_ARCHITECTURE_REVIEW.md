# Room16 Semantic Compiler Wave — Unabhängige Architekturprüfung

## Entscheidung

```text
overall_verdict = changes_required
semantic_compiler_wave_complete = false
ba10_authorized = false
release_ready = false
publication_allowed = false
```

Die Wave ist **keine Fehlleistung**. Sie liefert wertvolles Shadow-/Strangler-Gerüst:

- Foundation 1.0.0 blieb unverändert.
- Registry Foundation 1.1.0 ist Research-owned.
- Product besitzt nur einen hashverifizierten Mirror.
- WM, COST und ABT blieben byteidentisch.
- Formeln, Aliase, Hashes und Replays wurden deutlich formalisiert.
- BA10 wurde korrekt nicht begonnen.

Die Implementierung erfüllt aber noch nicht die genehmigte Bedeutung von BA4–BA9. Sie ist derzeit vor allem eine **deterministische Rehydrierungs- und Kompatibilitätsstrecke über bereits akzeptierte Legacy-Artefakte**, noch keine geschlossene Source-to-Verdict-Compiler-Spine.

## Hauptgründe

### 1. L10 Verification fehlt

Die genehmigte Architektur sieht nach BA8 Decision Graph einen eigenen BA9-Verification-Abschnitt vor. Die implementierte Passkette endet dagegen mit BA9 Decision Graph. `DiagnosticIR`, `CompileVerdictIR`, `VerificationPlan` und `VerificationReport` fehlen.

### 2. Parser und Tabellen speisen die Facts nicht

Source Snapshots werden geparst und Tabellen entdeckt. Die Typed Facts werden anschließend aber direkt aus `fact_ledger.json` erzeugt. Damit läuft die neue Parser-/Table-Strecke parallel zur Legacy-Wahrheit, statt deren semantische Quelle zu werden.

### 3. Registry Coverage ist nicht Contract Coverage

282 IDs sind vollständig klassifiziert, aber nur neun sehr breite Metric Definitions tragen nahezu alle erlaubten Typen, Einheiten und Perioden. Dadurch werden unbekannte IDs blockiert, fachlich falsche Kombinationen innerhalb des breiten Vokabulars aber nicht zuverlässig erkannt.

### 4. Aggregate PASS ist teilweise vorgegeben

Zentrale Cross-Company-Gates werden im Coverage-Code als feste Erfolgswerte gesetzt. Das widerspricht dem Ziel, Verdicts ausschließlich aus gebundenen Diagnostics abzuleiten.

### 5. Graph- und Table-Nachweise bleiben zu oberflächlich

Claim-Evidence prüft Existenz statt passgenauer Unterstützung. Der Decision-Roundtrip gibt eine eingebettete Legacy-Kopie zurück. Die Table Discovery deckt reale komplexe Tabellenformen nicht ab.

## Akzeptierbarer Zwischenstatus

```text
rfc_0001_registry_foundation_1_1 = accepted
foundation_immutability = accepted
product_mirror_conformance = accepted
formula_replay_scaffolding = accepted
shadow_replay_determinism = accepted

ba4_parser_table_contract = partial
ba5_typed_fact_compiler = partial
ba6_metric_formula_compiler = partial_to_accepted_shadow
ba7_evidence_claim_semantics = partial
ba8_decision_graph = partial
ba9_verification = not_implemented
semantic_compiler_wave_complete = false
```

## Nächste Entscheidung

Kein Rückbau und kein Neustart. Die vorhandenen Ergebnisse bleiben als Migration Scaffolding bestehen.

Erforderlich ist genau ein begrenztes, versioniertes RFC:

```text
RFC-0002
Semantic IR Spine and Verification Completion
```

Erst danach ist ein erneuter unabhängiger Architektur-Gate vor BA10 sinnvoll.
