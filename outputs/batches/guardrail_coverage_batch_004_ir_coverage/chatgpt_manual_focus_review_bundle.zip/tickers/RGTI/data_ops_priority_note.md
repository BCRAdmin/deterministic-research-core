# Data-Ops Priority Note

- Ticker: `RGTI`
- Status in Batch 004: `manual_review`
- Priority: `P0`
- Blocks publish: `True`
- Affects manual review: `True`
- Why it matters: High: speculative deep-tech guardrail anchor; direct current-period source improves manual-review quality.
- Note: Direct IR/Earnings replacement preferred; do not infer guidance.
