# Data-Ops Priority Note

- Ticker: `QBTS`
- Status in Batch 004: `manual_review`
- Priority: `P0`
- Blocks publish: `True`
- Affects manual review: `True`
- Why it matters: High: speculative deep-tech comparator and valuation/anomaly sanity case.
- Note: Direct IR/Earnings replacement preferred; do not infer guidance.
