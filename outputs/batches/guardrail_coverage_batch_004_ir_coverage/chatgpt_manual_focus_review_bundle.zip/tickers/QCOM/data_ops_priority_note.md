# Data-Ops Priority Note

- Ticker: `QCOM`
- Status in Batch 004: `passed`
- Priority: `P0`
- Blocks publish: `True`
- Affects manual review: `False`
- Why it matters: High: display rule and FCF support regression anchor.
- Note: QCOM is passed in Batch 004 and included here only as a P0 Data-Ops priority; do not relabel it as manual_review.
