# Data-Ops Priority Note

- Ticker: `NVDA`
- Status in Batch 004: `manual_review`
- Priority: `P0`
- Blocks publish: `True`
- Affects manual review: `True`
- Why it matters: High: AI-infrastructure benchmark; direct guidance/capex details affect semi-cycle interpretation.
- Note: Direct IR/Earnings replacement preferred; do not infer guidance.
