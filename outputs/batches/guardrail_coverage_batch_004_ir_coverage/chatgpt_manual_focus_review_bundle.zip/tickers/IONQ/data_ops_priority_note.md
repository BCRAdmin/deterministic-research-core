# Data-Ops Priority Note

- Ticker: `IONQ`
- Status in Batch 004: `manual_review`
- Priority: `P0`
- Blocks publish: `True`
- Affects manual review: `True`
- Why it matters: High: quantum comparator; direct IR helps avoid misreading SEC-derived scale/context.
- Note: Direct IR/Earnings replacement preferred; do not infer guidance.
