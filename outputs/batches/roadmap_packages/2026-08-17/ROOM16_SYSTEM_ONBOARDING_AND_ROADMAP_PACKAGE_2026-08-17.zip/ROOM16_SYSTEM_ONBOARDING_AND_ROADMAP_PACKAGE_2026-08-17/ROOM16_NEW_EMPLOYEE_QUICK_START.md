# Room16 - Quick Start fuer neue Mitarbeiter

## 1. Was ist Room16?

Room16 ist ein deterministischer Financial Research Compiler. Das System uebersetzt eingefrorene Quellen in typisierte Fakten, Metriken, belegte Claims, einen Decision Graph, Diagnostics und ein gebundenes Compiler-Artefakt.

Ein Bericht ist nur ein Backend. Er ist nicht die fachliche Wahrheit.

## 2. Die wichtigste Regel

Behebe nie nur den sichtbaren Bericht.

Frage zuerst:

1. Welcher Compiler-Layer ist verantwortlich?
2. Welcher Contract haette den Fehler verhindern muessen?
3. Welche Negative Fixture reproduziert die Fehlerklasse?
4. Welche Canary koennte regressieren?

## 3. Wahrheit und Ownership

Research Core besitzt:

- Sources und Snapshots
- IRs und Registries
- Facts, Metrics und Formula Evaluations
- Evidence-, Claim- und Decision-Graphen
- Diagnostics und Compile Verdict
- L11 Emit

Product Shell besitzt:

- Queue und Runtime
- Operatoroberflaeche
- Renderer und Delivery
- Human-, Release- und Publish-Gates

Product darf keine fachliche Parallelwahrheit erzeugen.

## 4. Aktueller Migrationsmodus

`compatibility_shadow`

Die neue Compiler-Spine laeuft ueber die akzeptierte Authority-v3-Baseline. Die Source-/Table-Strecke ist vorhanden, aber Facts entstehen noch nicht source-native. Ein Cutover benoetigt spaeter ein eigenes RFC.

## 5. Aktueller Stand

- BA0 Architektur-Freeze: frozen
- BA1 Compiler Kernel: frozen
- BA2 Registry Authority: frozen
- BA3 Source Front-End: shadow
- BA4-BA9 Semantic Wave: partial, RFC-0004 aktiv
- BA10 Artifact ABI und Renderer: locked
- BA11 Canary Governance: planned
- BA12 Archetype Qualification: planned

## 6. Was als Naechstes passiert

1. RFC-0004 vollstaendig umsetzen.
2. Nur die fuenf definierten Findings eng unabhaengig pruefen.
3. Bei PASS die Semantic Wave einfrieren.
4. BA10 separat freigeben.
5. BA11 Canary Governance aufbauen.
6. BA12 mit Software/SaaS beginnen: Salesforce als Development, ServiceNow als Holdout.

## 7. Begriffe

- IR: versioniertes Zwischenartefakt
- Pass: deterministische Transformation
- Registry: ausfuehrbare Definition und Policy
- Canary: eingefrorener Regressionstest
- ABI: aeusserer Vertrag zwischen Compiler und Consumer
- Shadow: neue Pipeline laeuft kontrolliert neben akzeptierter Legacy-Wahrheit
- DiagnosticIR: stabiler Fehler-/Warncode mit Layer- und Source-Bezug
- CompileVerdictIR: ausschliesslich aus Diagnostics abgeleitetes Compilerurteil
