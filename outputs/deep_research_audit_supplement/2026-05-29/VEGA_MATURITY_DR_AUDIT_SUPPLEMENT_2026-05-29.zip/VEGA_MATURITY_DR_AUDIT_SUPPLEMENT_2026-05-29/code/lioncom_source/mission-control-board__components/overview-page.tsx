'use client';

import { useState } from 'react';

import { ActivityFeed } from '@/components/activity-feed';
import { AgentStatusCard } from '@/components/agent-status-card';
import { GlobalSituationCard } from '@/components/global-situation-card';
import { MissionFlowBoard } from '@/components/mission-flow-board';
import { OperatorGuidanceCard } from '@/components/operator-guidance-card';
import { StatusChip } from '@/components/status-chip';
import { SystemAuditCard } from '@/components/system-audit-card';
import { Card } from '@/components/ui/card';
import { useControlPlaneData } from '@/components/use-control-plane-data';
import { ViviLoopStatusCard } from '@/components/vivi-loop-status-card';
import type { GlobalStatus, GoldenBaselineStatus } from '@/lib/types';
import { useControlPlaneStore } from '@/store/control-plane-store';

function TelemetryCompact({ status }: { status: GlobalStatus }) {
  const items = [
    ['Loop-Zustand', status.loopHealth, isHealthyLabel(status.loopHealth) ? 'success' : 'warning'],
    ['Queue-Tiefe', String(status.queueDepth), status.queueDepth > 40 ? 'warning' : 'info'],
    ['Brückenlink', status.bridgeStatus, status.bridgeStatus === 'ONLINE' ? 'success' : 'warning'],
    ['Sync-Status', status.syncStatus, isFreshLabel(status.syncStatus) ? 'info' : 'warning'],
    ['Aktive Claims', String(status.activeClaims), 'info'],
    ['Watcher-Lage', status.watcherPosture, isHealthyLabel(status.watcherPosture) ? 'success' : 'warning'],
  ] as const;

  return (
    <Card className="rounded-2xl p-4">
      <div className="hud-title text-sm text-vega">Telemetrie & Kontrolle kompakt</div>
      <div className="mt-4 grid gap-2 md:grid-cols-2">
        {items.map(([label, value, tone]) => (
          <div key={label} className="flex items-center justify-between gap-3 rounded-xl border border-border bg-cpbg/30 p-3">
            <span className="text-sm text-muted">{label}</span>
            <StatusChip label={localizeValue(value)} tone={tone} />
          </div>
        ))}
      </div>
    </Card>
  );
}

function isFreshLabel(value: string) {
  const normalized = value.toLowerCase();
  return normalized === 'fresh' || normalized === 'frisch';
}

function isHealthyLabel(value: string) {
  const normalized = value.toLowerCase();
  return ['healthy', 'stabil', 'steady', 'frisch'].some((item) => normalized.includes(item));
}

function localizeValue(value: string) {
  const normalized = value.toLowerCase();
  if (normalized === 'fresh') return 'Frisch';
  if (normalized === 'healthy') return 'Stabil';
  if (normalized === 'steady') return 'Stabil';
  if (normalized === 'attention') return 'Achtung';
  if (normalized === 'blocked') return 'Blockiert';
  return value;
}

function LiveSourceCard({ generatedAt, source, status }: { generatedAt: string; source: 'live' | 'fallback'; status: GlobalStatus }) {
  const liveState = useControlPlaneStore((state) => state.liveState);
  const liveError = useControlPlaneStore((state) => state.liveError);
  const timestamp = new Intl.DateTimeFormat('de-DE', { hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(new Date(generatedAt));
  const isLiveTruth = source === 'live' && liveState !== 'error';
  const remoteBridge = status.bridgeStatus === 'ONLINE' ? 'Verbunden' : 'Remote wartet';
  const localLoop = `${localizeValue(status.loopHealth)} · ${status.activeClaims} Claims`;

  return (
    <Card className="rounded-2xl p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="hud-title text-sm text-vega">Live-Datenverbindung</div>
          <div className="mt-1 text-xs leading-5 text-muted">Trennt Direkte Vivi-Runtime, Lokaler Duo-Loop und Remote-Bridge. Keine Karte wirkt frischer als ihre Quelle.</div>
        </div>
        <StatusChip label={isLiveTruth ? 'Lokale Wahrheit' : 'Lokaler Fallback'} tone={isLiveTruth ? 'success' : 'warning'} />
      </div>
      <div className="mt-4 grid gap-2">
        <div className="flex items-center justify-between rounded-xl border border-border bg-cpbg/30 p-3 text-sm">
          <span className="text-muted">Direkte Vivi-Runtime</span>
          <span className="font-mono text-text">{localizeLiveState(liveState)}</span>
        </div>
        <div className="flex items-center justify-between rounded-xl border border-border bg-cpbg/30 p-3 text-sm">
          <span className="text-muted">Lokaler Duo-Loop</span>
          <span className="font-mono text-text">{localLoop}</span>
        </div>
        <div className="flex items-center justify-between rounded-xl border border-border bg-cpbg/30 p-3 text-sm">
          <span className="text-muted">Remote-Bridge</span>
          <span className="font-mono text-text">{remoteBridge}</span>
        </div>
        <div className="flex items-center justify-between rounded-xl border border-border bg-cpbg/30 p-3 text-sm">
          <span className="text-muted">Letzter Snapshot</span>
          <span className="font-mono text-text">{timestamp}</span>
        </div>
        {status.bridgeStatus !== 'ONLINE' ? <div className="rounded-xl border border-warning/30 bg-warning/10 p-3 text-xs leading-5 text-warning">Remote-Bridge ist vorbereitet, aber nicht scharf. Aktivierung braucht Operator-Go.</div> : null}
        {liveError ? <div className="rounded-xl border border-warning/30 bg-warning/10 p-3 text-xs leading-5 text-warning">{liveError}</div> : null}
      </div>
    </Card>
  );
}

function OperationsControlDeck({ baseline, generatedAt, source, status }: { baseline: GoldenBaselineStatus; generatedAt: string; source: 'live' | 'fallback'; status: GlobalStatus }) {
  const [deck, setDeck] = useState<'signal' | 'baseline' | 'loop' | 'audit'>('signal');
  const tabs = [
    { id: 'signal', label: 'Signal' },
    { id: 'baseline', label: 'Basislinie' },
    { id: 'loop', label: 'Vivi-Loop' },
    { id: 'audit', label: 'Audit' },
  ] as const;

  return (
    <div className="grid gap-3">
      <div className="rounded-2xl border border-border bg-cpbg/30 p-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <div className="hud-title text-sm text-vega">Operations-Deck</div>
            <p className="mt-1 text-xs leading-5 text-muted">Signal, Baseline, Vivi Loop & Gate und Audit liegen in einer kompakten Steuerfläche.</p>
          </div>
          <StatusChip label="Ein-Screen-Lage" tone="info" />
        </div>
        <div className="mt-4 grid grid-cols-4 gap-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              type="button"
              className={`rounded-lg border px-2 py-2 text-xs font-semibold uppercase tracking-[0.08em] transition ${
                deck === tab.id ? 'border-vega/55 bg-vega/15 text-vega' : 'border-border bg-cpbg/30 text-muted hover:text-text'
              }`}
              onClick={() => setDeck(tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>
      <div className="grid gap-3">
        {deck === 'signal' ? (
          <>
            <LiveSourceCard generatedAt={generatedAt} source={source} status={status} />
            <TelemetryCompact status={status} />
          </>
        ) : null}
        {deck === 'baseline' ? <GoldenBaselineCard baseline={baseline} /> : null}
        {deck === 'loop' ? <ViviLoopStatusCard /> : null}
        {deck === 'audit' ? <SystemAuditCard /> : null}
      </div>
    </div>
  );
}

function GoldenBaselineCard({ baseline }: { baseline: GoldenBaselineStatus }) {
  const failedCount = baseline.failedSteps.length;
  const [runState, setRunState] = useState<'idle' | 'starting' | 'started' | 'error'>('idle');
  const tone = baseline.verdict === 'fail' || baseline.freshness === 'critical' || baseline.freshness === 'failed'
    ? 'critical'
    : baseline.verdict === 'pass' && baseline.freshness === 'fresh'
      ? 'success'
      : 'warning';

  async function startBaseline() {
    setRunState('starting');
    try {
      const response = await fetch('/api/control-plane-v2/golden-baseline/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode: 'due', force: true }),
      });
      if (!response.ok) {
        throw new Error(await response.text());
      }
      setRunState('started');
      window.setTimeout(() => setRunState('idle'), 10_000);
    } catch {
      setRunState('error');
    }
  }

  return (
    <Card className="rounded-2xl p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="hud-title text-sm text-vega">Goldene Baseline</div>
          <div className="mt-1 text-xs leading-5 text-muted">Automatisches Gate für LIONCOM, Room16, Quellwert und Materialbedarf.</div>
        </div>
        <div className="flex flex-col items-end gap-2">
          <StatusChip label={baselineVerdictLabel(baseline.verdict)} tone={tone} />
          <StatusChip label={baselineFreshnessLabel(baseline.freshness)} tone={tone} />
        </div>
      </div>
      <div className="mt-4 grid gap-2">
        <BaselineRow label="Letzter Lauf" value={formatBaselineTime(baseline.generatedAt)} />
        <BaselineRow label="Nächste Fälligkeitsprüfung" value={formatBaselineTime(baseline.nextDueAt || baseline.automation?.nextDueAt)} />
        <BaselineRow label="Modus" value={formatBaselineMode(baseline.mode)} />
        <BaselineRow
          label="Schritte"
          value={`${baseline.passedSteps ?? 0}/${baseline.stepCount ?? 0}`}
          tone={failedCount === 0 && baseline.stepCount ? 'success' : 'warning'}
        />
        <BaselineRow label="Fehler" value={failedCount === 0 ? 'keine' : String(failedCount)} tone={failedCount === 0 ? 'success' : 'critical'} />
      </div>
      <div className="mt-3 rounded-xl border border-border bg-cpbg/30 p-3 text-xs leading-5 text-muted">
        <div className="font-semibold text-text">{baseline.nextAction || 'Goldene Baseline prüfen.'}</div>
        <div className="mt-1">Automatisierung: {formatAutomationStatus(baseline.automation)}</div>
      </div>
      {failedCount > 0 ? (
        <div className="mt-3 rounded-xl border border-danger/30 bg-danger/10 p-3 text-xs leading-5 text-danger">
          {baseline.failedSteps.slice(0, 3).join(' · ')}
        </div>
      ) : null}
      <button
        className="mt-3 w-full rounded-xl border border-vega/40 bg-vega/10 px-3 py-2 text-sm font-semibold text-vega transition hover:bg-vega/15 disabled:cursor-not-allowed disabled:opacity-60"
        type="button"
        disabled={runState === 'starting'}
        onClick={startBaseline}
      >
        {runState === 'starting' ? 'Baseline startet ...' : runState === 'started' ? 'Baseline gestartet' : runState === 'error' ? 'Start fehlgeschlagen' : 'Jetzt prüfen'}
      </button>
    </Card>
  );
}

function BaselineRow({ label, value, tone = 'info' }: { label: string; value: string; tone?: 'info' | 'success' | 'warning' | 'critical' }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl border border-border bg-cpbg/30 p-3 text-sm">
      <span className="text-muted">{label}</span>
      <StatusChip label={value} tone={tone} />
    </div>
  );
}

function formatBaselineTime(value?: string | null): string {
  if (!value) return 'nicht gelaufen';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }).format(date);
}

function baselineFreshnessLabel(value?: GoldenBaselineStatus['freshness']): string {
  if (value === 'fresh') return 'frisch';
  if (value === 'stale') return 'faellig';
  if (value === 'critical') return 'kritisch alt';
  if (value === 'failed') return 'fehlgeschlagen';
  return 'unbekannt';
}

function baselineVerdictLabel(value: GoldenBaselineStatus['verdict']): string {
  if (value === 'pass') return 'bestanden';
  if (value === 'fail') return 'fehlgeschlagen';
  return 'unbekannt';
}

function formatBaselineMode(value?: string | null): string {
  if (!value) return 'unbekannt';
  const labels: Record<string, string> = {
    due: 'fällig',
    manual: 'manuell',
    scheduled: 'geplant',
    'dry-run': 'Testlauf',
  };
  return labels[value] ?? value;
}

function formatAutomationStatus(status?: GoldenBaselineStatus['automation']): string {
  if (!status?.checkedAt) return 'noch kein Due-Check';
  const checkedAt = formatBaselineTime(status.checkedAt);
  const action = localizeAutomationAction(status.action || 'unknown');
  const reason = status.reason ? ` (${status.reason})` : '';
  return `${action}${reason} · ${checkedAt}`;
}

function localizeAutomationAction(value: string): string {
  const labels: Record<string, string> = {
    skipped: 'übersprungen',
    'dry-run': 'Testlauf',
    locked: 'läuft bereits',
    started: 'gestartet',
    unknown: 'unbekannt',
  };
  return labels[value] ?? value;
}

function localizeLiveState(value: string): string {
  const labels: Record<string, string> = {
    error: 'Fehler',
    idle: 'Bereit',
    loading: 'Lädt',
    ready: 'Bereit',
    stale: 'Veraltet',
  };

  return labels[value] ?? value;
}

export function OverviewPage() {
  const setSelectedView = useControlPlaneStore((state) => state.setSelectedView);
  const { activitySignals, agentSummaries, agents, generatedAt, globalStatus, goldenBaseline, missions, source } = useControlPlaneData();
  const vivi = agents.find((agent) => agent.id === 'vivi')!;
  const vega = agents.find((agent) => agent.id === 'vega')!;
  const viviSummary = agentSummaries.find((summary) => summary.agentId === 'vivi')!;
  const vegaSummary = agentSummaries.find((summary) => summary.agentId === 'vega')!;

  return (
    <div className="grid min-h-full grid-cols-12 gap-3">
      <GlobalSituationCard status={globalStatus} />
      <div className="col-span-12 grid self-start gap-3 xl:col-span-8 xl:grid-cols-2">
        <AgentStatusCard agent={vivi} summary={viviSummary} onOpen={() => setSelectedView('vivi')} />
        <AgentStatusCard agent={vega} summary={vegaSummary} onOpen={() => setSelectedView('vega')} />
      </div>
      <div className="col-span-12 grid content-start gap-3 xl:col-span-4">
        <OperationsControlDeck baseline={goldenBaseline} generatedAt={generatedAt} source={source} status={globalStatus} />
      </div>
      <div className="col-span-12 self-start xl:col-span-8">
        <MissionFlowBoard missions={missions} />
      </div>
      <div className="col-span-12 self-start xl:col-span-4">
        <OperatorGuidanceCard onDispatch={() => setSelectedView('dispatch')} />
      </div>
      <ActivityFeed signals={activitySignals} accent="vega" />
    </div>
  );
}
