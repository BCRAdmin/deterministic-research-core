import { Activity, RadioTower, Radar, ShieldCheck } from 'lucide-react';

import { StatusChip } from '@/components/status-chip';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/cn';
import type { GlobalStatus } from '@/lib/types';

export function GlobalSituationCard({ status }: { status: GlobalStatus }) {
  const postureTone = status.posture === 'STABIL' ? 'success' : status.posture === 'WARNING' ? 'warning' : 'info';

  return (
    <Card className="col-span-12 overflow-hidden rounded-2xl p-5">
      <div className="absolute inset-0 hud-map opacity-40" aria-hidden="true" />
      <div className="relative z-[1] grid gap-5 xl:grid-cols-[minmax(0,1fr)_360px] 2xl:grid-cols-[minmax(0,1fr)_460px]">
        <div>
          <div className="flex items-center gap-3">
            <div className="grid size-14 place-items-center rounded-2xl border border-strong bg-vega-soft text-vega shadow-hud">
              <Radar className="size-7" />
            </div>
            <div>
              <h1 className="hud-title text-3xl leading-none text-text">LAGEBILD // GLOBALE LAGE</h1>
              <p className="mt-2 text-sm text-muted">Gesamtzustand von LIONCOM, Vivi, Vega, Bridge und Automationen.</p>
            </div>
          </div>
          <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-6">
            {[
              ['Systemhaltung', status.posture, postureTone],
              ['Aktive Missionen', String(status.activeMissions), 'info'],
              ['Offene Queue', String(status.openQueue), 'warning'],
              ['Automationszustand', status.automationHealth, 'success'],
              ['Brückenstatus', status.bridgeStatus, 'success'],
              ['Aktive Claims', String(status.activeClaims), 'info'],
            ].map(([label, value, tone]) => (
              <div key={label} className="rounded-xl border border-border bg-cpbg/45 p-3">
                <div className="hud-label text-muted">{label}</div>
                <div className={cn('mt-2 text-xl font-semibold', tone === 'success' ? 'text-vivi' : tone === 'warning' ? 'text-warning' : 'text-vega')}>
                  {localizeValue(String(value))}
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="rounded-2xl border border-border bg-cpbg/35 p-4">
          <div className="flex items-center justify-between">
            <div className="hud-title text-sm text-vega">Operationslage</div>
            <StatusChip label={status.posture} tone={postureTone} />
          </div>
          <div className="mt-5 grid grid-cols-2 gap-3">
            {[
              [ShieldCheck, 'Loop-Zustand', status.loopHealth],
              [RadioTower, 'Sync-Status', status.syncStatus],
              [Activity, 'Watcher-Lage', status.watcherPosture],
              [Radar, 'Letztes Signal', status.lastSignal],
            ].map(([Icon, label, value]) => (
              <div key={label as string} className="rounded-xl border border-border bg-elevated/40 p-3">
                <Icon className="size-5 text-vega" />
                <div className="hud-label mt-3 text-muted">{label as string}</div>
                <div className="mt-2 text-sm text-text">{localizeValue(value as string)}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
}

function localizeValue(value: string): string {
  const labels: Record<string, string> = {
    ATTENTION: 'ACHTUNG',
    Attention: 'Achtung',
    Fresh: 'Frisch',
    Healthy: 'Stabil',
    STABIL: 'STABIL',
    Steady: 'Stabil',
    WARNING: 'WARNUNG',
  };

  return labels[value] ?? value;
}
