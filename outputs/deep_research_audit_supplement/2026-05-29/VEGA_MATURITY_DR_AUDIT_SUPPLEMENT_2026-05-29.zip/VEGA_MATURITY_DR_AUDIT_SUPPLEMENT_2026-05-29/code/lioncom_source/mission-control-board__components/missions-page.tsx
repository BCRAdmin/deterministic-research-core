'use client';

import { CheckCircle2, Clock3, Gauge, ShieldAlert, Workflow } from 'lucide-react';

import { MissionFlowBoard } from '@/components/mission-flow-board';
import { MissionTable } from '@/components/mission-table';
import { StatusChip } from '@/components/status-chip';
import { Card } from '@/components/ui/card';
import { useControlPlaneData } from '@/components/use-control-plane-data';
import { cn } from '@/lib/cn';
import type { Mission } from '@/lib/types';

function MissionKpis({ missions }: { missions: Mission[] }) {
  const active = missions.filter((mission) => mission.status === 'active' || mission.status === 'planning').length;
  const critical = missions.filter((mission) => mission.priority === 'critical').length;
  const review = missions.filter((mission) => mission.status === 'review').length;
  const done = missions.filter((mission) => mission.status === 'done').length;
  const kpis = [
    [Workflow, 'Aktive Missionen', String(active), 'info'],
    [ShieldAlert, 'Kritische Missionen', String(critical), 'warning'],
    [Gauge, 'In Prüfung', String(review), 'info'],
    [CheckCircle2, 'Abgeschlossen 24h', String(done), 'success'],
    [Clock3, 'Ø Zykluszeit', '06:18', 'info'],
  ] as const;

  return (
    <div className="grid gap-3 md:grid-cols-5">
      {kpis.map(([Icon, label, value, tone]) => (
        <Card key={label} className="rounded-2xl p-4">
          <Icon className={cn('size-5', tone === 'success' ? 'text-vivi' : tone === 'warning' ? 'text-warning' : 'text-vega')} />
          <div className="hud-label mt-4 text-muted">{label}</div>
          <div className="mt-2 flex items-center justify-between gap-3">
            <span className="text-2xl font-semibold text-text">{value}</span>
            <StatusChip label={tone} tone={tone} />
          </div>
        </Card>
      ))}
    </div>
  );
}

export function MissionsPage() {
  const { missions } = useControlPlaneData();

  return (
    <div className="grid min-h-full grid-cols-12 gap-3">
      <Card className="col-span-12 rounded-2xl p-5">
        <h1 className="hud-title text-3xl text-vega">MISSION CONTROL // ABLÄUFE & PROJEKTE</h1>
        <p className="mt-2 max-w-3xl text-sm leading-6 text-muted">Agentenübergreifende Missionen und Projekte mit klaren Agent-Badges, Status, Übergabe-Historie und nächster Aktion. Keine Chat-Details.</p>
      </Card>
      <div className="col-span-12"><MissionKpis missions={missions} /></div>
      <div className="col-span-12"><MissionTable missions={missions} /></div>
      <div className="col-span-12"><MissionFlowBoard missions={missions} title="Missionsfluss // Eingang → Planung → Ausführung → Verifikation → Erledigt" /></div>
    </div>
  );
}
