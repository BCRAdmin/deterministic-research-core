'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { Archive, Bot, Loader2, MessageSquare, Plus, Power, RefreshCw, Save, Send, Trash2, UserRound } from 'lucide-react';

import { StatusChip } from '@/components/status-chip';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/cn';
import {
  VIVI_PROVIDER_OPTIONS,
  defaultViviModel,
  modelSourceLabel,
  modelsForProvider,
  normalizeViviProviderMode,
  normalizeViviRequestedModel,
  providerKey,
  providerModeForPreset,
  type ViviModelCatalog,
  type ViviProviderMode,
  type ViviProviderPreset,
} from '@/lib/vivi-model-catalog';

type ViviChatRole = 'operator' | 'vivi' | 'system';
type ViviChatStatus = 'idle' | 'waiting' | 'reported' | 'attention';

interface ViviChatSession {
  id: string;
  title: string;
  topic: string;
  createdAt: string;
  updatedAt: string;
  providerMode: ViviProviderMode;
  providerPreset: ViviProviderPreset;
  requestedModel: string;
  lastMessagePreview: string;
  lastReference: string;
  status: ViviChatStatus;
  latestActivity: string;
}

interface ViviChatMessage {
  id: string;
  sessionId: string;
  addedAt: string;
  role: ViviChatRole;
  status: string;
  summary: string;
  message: string;
  source?: string;
  reference?: string;
  providerMode: ViviProviderMode;
  providerPreset: ViviProviderPreset;
  requestedModel?: string;
  derivedFrom: 'chat-thread' | 'vivi-report';
}

interface ViviChatSnapshot {
  sessions: ViviChatSession[];
  messages: ViviChatMessage[];
  activeSessionId?: string;
}

interface ViviStartResult {
  ok: boolean;
  mode: 'launchagent' | 'direct-script' | 'unavailable';
  detail: string;
}

interface ViviApiResponse {
  ok?: boolean;
  snapshot?: ViviChatSnapshot;
  start?: ViviStartResult;
  error?: string;
}

const STORAGE_KEY = 'lioncom-v2-vivi-active-session';

const statusTone: Record<ViviChatStatus, 'neutral' | 'info' | 'success' | 'warning'> = {
  idle: 'neutral',
  waiting: 'info',
  reported: 'success',
  attention: 'warning',
};

const providerLabels: Record<ViviProviderPreset, string> = {
  chatgpt: 'ChatGPT Cloud',
  lmstudio: 'LM Studio lokal',
  ollama: 'Ollama',
  openrouter: 'OpenRouter',
};

export function ViviChatConsole() {
  const [snapshot, setSnapshot] = useState<ViviChatSnapshot>({ sessions: [], messages: [] });
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [titleDraft, setTitleDraft] = useState('');
  const [topicDraft, setTopicDraft] = useState('');
  const [providerPreset, setProviderPreset] = useState<ViviProviderPreset>('lmstudio');
  const [providerMode, setProviderMode] = useState<ViviProviderMode>('local');
  const [requestedModel, setRequestedModel] = useState('');
  const [modelCatalog, setModelCatalog] = useState<ViviModelCatalog | null>(null);
  const [messageDraft, setMessageDraft] = useState('');
  const [notice, setNotice] = useState('Vivi-Konsole bereit. Sessions werden lokal aus dem Workspace gelesen.');
  const [error, setError] = useState<string | null>(null);
  const [busyAction, setBusyAction] = useState<string | null>(null);
  const [deleteCandidateId, setDeleteCandidateId] = useState<string | null>(null);

  const activeSession = useMemo(
    () => snapshot.sessions.find((session) => session.id === activeSessionId) ?? snapshot.sessions[0],
    [activeSessionId, snapshot.sessions],
  );
  const activeMessages = useMemo(
    () => snapshot.messages.filter((message) => message.sessionId === activeSession?.id),
    [activeSession?.id, snapshot.messages],
  );
  const providerOptions = useMemo(
    () => VIVI_PROVIDER_OPTIONS.filter((option) => option.mode === providerMode),
    [providerMode],
  );
  const modelOptions = useMemo(
    () => modelsForProvider(modelCatalog ?? { models: [] }, providerPreset, providerMode),
    [modelCatalog, providerMode, providerPreset],
  );
  const isDirty = Boolean(activeSession)
    && (titleDraft !== activeSession.title
      || topicDraft !== activeSession.topic
      || providerPreset !== activeSession.providerPreset
      || requestedModel !== activeSession.requestedModel);

  const selectedProviderLabel = providerOptions.find((option) => option.value === providerPreset)?.label
    ?? providerLabels[providerPreset];
  const selectedProviderStatus = modelCatalog?.providerStatus?.find(
    (status) => status.key === providerKey(providerPreset, providerMode),
  );

  const applySnapshot = useCallback((nextSnapshot: ViviChatSnapshot, preferredSessionId?: string | null) => {
    setSnapshot(nextSnapshot);
    const storedSessionId = typeof window !== 'undefined' ? window.localStorage.getItem(STORAGE_KEY) : null;
    const nextActiveId = preferredSessionId
      ?? (storedSessionId && nextSnapshot.sessions.some((session) => session.id === storedSessionId) ? storedSessionId : null)
      ?? nextSnapshot.activeSessionId
      ?? nextSnapshot.sessions[0]?.id
      ?? null;
    setActiveSessionId(nextActiveId);
    if (nextActiveId && typeof window !== 'undefined') {
      window.localStorage.setItem(STORAGE_KEY, nextActiveId);
    }
  }, []);

  const fetchSnapshot = useCallback(async (quiet = false) => {
    if (!quiet) setBusyAction('refresh');
    setError(null);
    try {
      const response = await fetch('/api/vivi-chat', { cache: 'no-store' });
      if (!response.ok) throw new Error('Vivi-Chat konnte nicht geladen werden.');
      const nextSnapshot = await response.json() as ViviChatSnapshot;
      applySnapshot(nextSnapshot);
      if (!quiet) setNotice('Vivi-Sessions wurden aktualisiert.');
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Vivi-Chat konnte nicht geladen werden.');
    } finally {
      if (!quiet) setBusyAction(null);
    }
  }, [applySnapshot]);

  const postAction = useCallback(async (body: Record<string, unknown>, actionLabel: string, preferredSessionId?: string | null) => {
    setBusyAction(actionLabel);
    setError(null);
    try {
      const response = await fetch('/api/vivi-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const result = await response.json() as ViviApiResponse;
      if (!response.ok || result.error) throw new Error(result.error || 'Vivi-Aktion fehlgeschlagen.');
      if (result.snapshot) applySnapshot(result.snapshot, preferredSessionId);
      return result;
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Vivi-Aktion fehlgeschlagen.');
      return null;
    } finally {
      setBusyAction(null);
    }
  }, [applySnapshot]);

  useEffect(() => {
    void fetchSnapshot(true);
    const timer = window.setInterval(() => void fetchSnapshot(true), 15000);
    return () => window.clearInterval(timer);
  }, [fetchSnapshot]);

  useEffect(() => {
    let cancelled = false;

    async function loadCatalog() {
      try {
        const response = await fetch('/api/vivi-model-catalog', { cache: 'no-store' });
        if (!response.ok) throw new Error('Modellkatalog konnte nicht geladen werden.');
        const catalog = await response.json() as ViviModelCatalog;
        if (!cancelled) setModelCatalog(catalog);
      } catch {
        if (!cancelled) setNotice('Modellkatalog nutzt Fallbacks. Lokale Provider werden beim nächsten Refresh erneut geprüft.');
      }
    }

    void loadCatalog();

    return () => {
      cancelled = true;
    };
  }, []);

  async function refreshModelCatalog() {
    setBusyAction('catalog');
    setError(null);
    try {
      const response = await fetch('/api/vivi-model-catalog', { cache: 'no-store' });
      if (!response.ok) throw new Error('Modellkatalog konnte nicht geladen werden.');
      const catalog = await response.json() as ViviModelCatalog;
      setModelCatalog(catalog);
      setNotice('Modellkatalog aktualisiert. Lokale und Cloud-Modelle sind nach Provider getrennt.');
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Modellkatalog konnte nicht geladen werden.');
    } finally {
      setBusyAction(null);
    }
  }

  useEffect(() => {
    if (!activeSession) {
      setTitleDraft('');
      setTopicDraft('');
      setProviderPreset('lmstudio');
      setRequestedModel('');
      return;
    }

    setTitleDraft(activeSession.title);
    setTopicDraft(activeSession.topic);
    setProviderPreset(activeSession.providerPreset);
    setProviderMode(normalizeViviProviderMode(activeSession.providerMode, activeSession.providerPreset));
    setRequestedModel(activeSession.requestedModel || defaultViviModel(activeSession.providerPreset, activeSession.providerMode));
    setDeleteCandidateId(null);
  }, [activeSession?.id]);

  useEffect(() => {
    if (!activeSession || !modelCatalog) return;
    const normalized = normalizeViviRequestedModel(providerPreset, requestedModel, providerMode, modelCatalog);
    if (normalized !== requestedModel) setRequestedModel(normalized);
  }, [activeSession, modelCatalog, providerMode, providerPreset, requestedModel]);

  function selectSession(sessionId: string) {
    setActiveSessionId(sessionId);
    window.localStorage.setItem(STORAGE_KEY, sessionId);
    setDeleteCandidateId(null);
  }

  function handleModeChange(nextMode: ViviProviderMode) {
    const nextPreset = nextMode === 'cloud'
      ? 'chatgpt'
      : providerPreset === 'ollama'
        ? 'ollama'
        : 'lmstudio';
    setProviderMode(nextMode);
    setProviderPreset(nextPreset);
    setRequestedModel(normalizeViviRequestedModel(nextPreset, requestedModel, nextMode, modelCatalog ?? undefined));
  }

  function handleProviderChange(nextPreset: ViviProviderPreset) {
    const nextMode = providerModeForPreset(nextPreset, providerMode);
    setProviderPreset(nextPreset);
    setProviderMode(nextMode);
    setRequestedModel(normalizeViviRequestedModel(nextPreset, requestedModel, nextMode, modelCatalog ?? undefined));
  }

  async function createSession() {
    const result = await postAction({
      action: 'create-session',
      title: 'Neue lokale Vivi-Session',
      topic: 'Operator-Dialog mit automatischem Backbone-Startkontext',
      providerMode,
      providerPreset,
      requestedModel,
    }, 'create');

    const newSessionId = result?.snapshot?.sessions[0]?.id;
    if (newSessionId) {
      applySnapshot(result.snapshot!, newSessionId);
      setNotice('Neue Vivi-Session angelegt. Vivi bekommt den Startkontext automatisch mit.');
    }
  }

  async function saveSession(applyToRuntime = true) {
    if (!activeSession) return false;
    const result = await postAction({
      action: 'update-session',
      sessionId: activeSession.id,
      title: titleDraft,
      topic: topicDraft,
      providerMode,
      providerPreset,
      requestedModel,
      applyToRuntime,
    }, 'save', activeSession.id);
    if (result?.snapshot) {
      setNotice(applyToRuntime ? 'Session gespeichert und Vivi-Runtime-Wunsch aktualisiert.' : 'Session gespeichert.');
      return true;
    }
    return false;
  }

  async function sendMessage() {
    if (!activeSession || !messageDraft.trim()) return;
    if (isDirty) {
      const saved = await saveSession(true);
      if (!saved) return;
    }

    const message = messageDraft.trim();
    setMessageDraft('');
    const result = await postAction({
      action: 'send-message',
      sessionId: activeSession.id,
      title: titleDraft,
      topic: topicDraft,
      providerMode,
      providerPreset,
      requestedModel,
      message,
      source: 'LIONCOM Control Plane V2',
      autoStart: true,
    }, 'send', activeSession.id);
    if (result?.snapshot) {
      setNotice(result.start?.detail || 'Nachricht an Vivi gesendet. Vivi antwortet im Chat; wenn daraus Arbeit entsteht, hält sie die lokalen Rails im Hintergrund aktuell.');
    } else {
      setMessageDraft(message);
    }
  }

  async function startLocalVivi() {
    if (!activeSession) {
      setError('Lege zuerst eine Vivi-Session an.');
      return;
    }
    if (isDirty) {
      const saved = await saveSession(true);
      if (!saved) return;
    }

    const result = await postAction({
      action: 'start-local-vivi',
      sessionId: activeSession.id,
    }, 'start', activeSession.id);
    if (result?.start) {
      setNotice(result.start.detail);
      if (!result.start.ok) setError(result.start.detail);
    }
  }

  async function archiveSession(sessionId: string) {
    const result = await postAction({
      action: 'archive-session',
      sessionId,
      reason: 'Operator archiviert die Session über die Vivi-Konsole.',
    }, 'archive');
    if (result?.snapshot) {
      setDeleteCandidateId(null);
      setNotice('Session archiviert. Der Verlauf bleibt im Workspace und im Archiv nachvollziehbar.');
    }
  }

  async function removeEmptySession(sessionId: string) {
    const result = await postAction({
      action: 'remove-session',
      sessionId,
      confirmEmpty: true,
      reason: 'Operator entfernt eine leere Session aus der Vivi-Konsole.',
    }, 'remove');
    if (result?.snapshot) {
      setDeleteCandidateId(null);
      setNotice('Leere Session entfernt. Sessions mit Inhalt werden aus Sicherheitsgründen nur archiviert.');
    }
  }

  return (
    <Card className="col-span-12 rounded-2xl min-[1500px]:col-span-6">
      <CardHeader className="items-start gap-4">
        <div>
          <CardTitle className="text-sm text-vivi">Vivi-Arbeitsraum</CardTitle>
          <CardDescription>Lokale Sessions, Chats und automatischer Startkontext</CardDescription>
        </div>
        <div className="flex flex-wrap items-center justify-end gap-2">
          <Button size="sm" variant="outline" onClick={() => void fetchSnapshot()} disabled={Boolean(busyAction)}>
            {busyAction === 'refresh' ? <Loader2 className="size-3.5 animate-spin" /> : <RefreshCw className="size-3.5" />}
            Aktualisieren
          </Button>
          <Button size="sm" variant="vivi" onClick={() => void createSession()} disabled={Boolean(busyAction)}>
            <Plus className="size-3.5" />
            Neue Session
          </Button>
        </div>
      </CardHeader>
      <CardContent className="grid gap-4 min-[1500px]:grid-cols-[260px_minmax(0,1fr)]">
        <aside className="min-w-0 space-y-3">
          <div className="rounded-xl border border-border bg-cpbg/35 p-2">
            <div className="mb-2 flex items-center justify-between px-1">
              <span className="hud-label text-muted">Sessions</span>
              <span className="font-mono text-xs text-vivi">{snapshot.sessions.length}</span>
            </div>
            <div className="max-h-[430px] space-y-2 overflow-y-auto pr-1">
              {snapshot.sessions.map((session) => (
                <button
                  key={session.id}
                  type="button"
                  onClick={() => selectSession(session.id)}
                  className={cn(
                    'w-full rounded-xl border p-3 text-left transition',
                    activeSession?.id === session.id
                      ? 'border-vivi/55 bg-vivi-soft shadow-[0_0_22px_rgba(103,245,192,0.12)]'
                      : 'border-border bg-cpbg/35 hover:border-vivi/35 hover:bg-vivi-soft/50',
                  )}
                >
                  <div className="flex min-w-0 items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="truncate text-sm font-semibold text-text">{session.title}</div>
                      <div className="mt-1 line-clamp-2 text-xs leading-5 text-muted">{session.topic}</div>
                    </div>
                    <StatusChip label={session.status} tone={statusTone[session.status]} className="h-6 shrink-0 px-2" />
                  </div>
                  <div className="mt-3 flex items-center justify-between gap-2 text-[0.7rem] text-muted">
                    <span className="truncate">{providerLabels[session.providerPreset]} · {session.providerMode === 'cloud' ? 'Cloud' : 'Lokal'}</span>
                    <span className="font-mono">{formatTime(session.updatedAt)}</span>
                  </div>
                  <div className={cn('mt-2 line-clamp-2 text-xs leading-5', session.status === 'attention' ? 'text-warning' : 'text-muted')}>
                    {session.latestActivity}
                  </div>
                </button>
              ))}
              {snapshot.sessions.length === 0 ? (
                <div className="rounded-xl border border-dashed border-border p-4 text-sm text-muted">
                  Noch keine lokale Vivi-Session. Starte mit "Neue Session".
                </div>
              ) : null}
            </div>
          </div>

          <div className="rounded-xl border border-border bg-cpbg/35 p-3">
            <div className="flex items-center justify-between gap-2">
              <div className="hud-label text-muted">Runtime</div>
              <Button size="sm" variant="ghost" onClick={() => void refreshModelCatalog()} disabled={Boolean(busyAction)}>
                {busyAction === 'catalog' ? <Loader2 className="size-3.5 animate-spin" /> : <RefreshCw className="size-3.5" />}
                Katalog
              </Button>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <Button
                size="sm"
                variant={providerMode === 'local' ? 'vivi' : 'outline'}
                onClick={() => handleModeChange('local')}
                disabled={!activeSession}
              >
                Lokal
              </Button>
              <Button
                size="sm"
                variant={providerMode === 'cloud' ? 'vivi' : 'outline'}
                onClick={() => handleModeChange('cloud')}
                disabled={!activeSession}
              >
                Cloud
              </Button>
            </div>
            <select
              value={providerPreset}
              onChange={(event) => handleProviderChange(event.target.value as ViviProviderPreset)}
              disabled={!activeSession}
              className="mt-2 flex h-10 w-full rounded-xl border border-border bg-[#07131f] px-3 text-sm text-text outline-none focus:border-strong"
            >
              {providerOptions.map((option) => (
                <option key={`${option.mode}-${option.value}`} value={option.value}>
                  {formatProviderOptionLabel(option.label, modelCatalog?.providerStatus?.find((status) => status.key === providerKey(option.value, option.mode)))}
                </option>
              ))}
            </select>
            <select
              value={requestedModel}
              onChange={(event) => setRequestedModel(event.target.value)}
              disabled={!activeSession}
              className="mt-2 flex h-10 w-full rounded-xl border border-border bg-[#07131f] px-3 text-sm text-text outline-none focus:border-strong"
            >
              {modelOptions.length > 0 ? modelOptions.map((model) => (
                <option key={`${model.mode}-${model.provider}-${model.id}`} value={model.id}>
                  {model.label} · {modelSourceLabel(model.source)}
                </option>
              )) : (
                <option value={defaultViviModel(providerPreset, providerMode)}>
                  {defaultViviModel(providerPreset, providerMode)}
                </option>
              )}
            </select>
            <div className="mt-2 rounded-lg border border-border bg-cpbg/45 px-3 py-2 text-xs leading-5 text-muted">
              <div className="font-medium text-text">{selectedProviderLabel}: {selectedProviderStatus?.detail || 'Katalog wird geladen.'}</div>
              <div>
                {modelOptions.length > 0 ? `${modelOptions.length} passende Modelle für ${providerMode === 'cloud' ? 'Cloud' : 'Lokal'}.` : 'Fallback-Modell aktiv.'}
                {selectedProviderStatus?.warning ? ` ${selectedProviderStatus.warning}` : ''}
              </div>
            </div>
          </div>
        </aside>

        <section className="min-w-0 rounded-xl border border-border bg-cpbg/25">
          <div className="border-b border-border p-3">
            <div className="grid gap-2 md:grid-cols-[minmax(0,1fr)_180px]">
              <Input
                value={titleDraft}
                onChange={(event) => setTitleDraft(event.target.value)}
                placeholder="Session-Titel"
                disabled={!activeSession}
              />
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" onClick={() => void saveSession(true)} disabled={!activeSession || !isDirty || Boolean(busyAction)}>
                  {busyAction === 'save' ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
                  Speichern
                </Button>
                <Button variant="vivi" onClick={() => void startLocalVivi()} disabled={!activeSession || Boolean(busyAction)}>
                  {busyAction === 'start' ? <Loader2 className="size-4 animate-spin" /> : <Power className="size-4" />}
                  Vivi starten
                </Button>
              </div>
            </div>
            <Input
              value={topicDraft}
              onChange={(event) => setTopicDraft(event.target.value)}
              placeholder="Thema / Kontext"
              className="mt-2"
              disabled={!activeSession}
            />
            {activeSession?.status === 'attention' ? (
              <div className="mt-3 rounded-xl border border-warning/35 bg-warning/10 px-3 py-2 text-sm leading-6 text-warning">
                {activeSession.latestActivity} Starte Vivi erneut oder archiviere die Session, wenn der Auftrag erledigt ist.
              </div>
            ) : activeSession ? (
              <div className="mt-3 rounded-xl border border-border bg-cpbg/35 px-3 py-2 text-sm leading-6 text-muted">
                {activeSession.latestActivity}
              </div>
            ) : null}
            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-muted">
              <span className="min-w-0 truncate">{notice}</span>
              {activeSession ? (
                <div className="flex flex-wrap items-center justify-end gap-2">
                  <Button size="sm" variant="ghost" onClick={() => void archiveSession(activeSession.id)} disabled={Boolean(busyAction)}>
                    {busyAction === 'archive' ? <Loader2 className="size-3.5 animate-spin" /> : <Archive className="size-3.5" />}
                    Archivieren
                  </Button>
                  {deleteCandidateId === activeSession.id ? (
                    <span className="flex items-center gap-2">
                      <span>Nur leere Session entfernen?</span>
                      <Button size="sm" variant="ghost" onClick={() => setDeleteCandidateId(null)}>Abbrechen</Button>
                      <Button size="sm" variant="outline" onClick={() => void removeEmptySession(activeSession.id)} disabled={Boolean(busyAction)}>
                        {busyAction === 'remove' ? <Loader2 className="size-3.5 animate-spin" /> : null}
                        Entfernen
                      </Button>
                    </span>
                  ) : (
                    <Button size="sm" variant="ghost" onClick={() => setDeleteCandidateId(activeSession.id)}>
                      <Trash2 className="size-3.5" />
                      Leere entfernen
                    </Button>
                  )}
                </div>
              ) : null}
            </div>
            {error ? <div className="mt-2 rounded-lg border border-danger/35 bg-danger/10 px-3 py-2 text-sm text-danger">{error}</div> : null}
          </div>

          <div className="max-h-[420px] space-y-3 overflow-y-auto p-3">
            {activeMessages.length > 0 ? activeMessages.map((message) => (
              <ChatBubble key={message.id} message={message} />
            )) : (
              <div className="grid min-h-[230px] place-items-center rounded-xl border border-dashed border-border bg-cpbg/25 p-6 text-center">
                <div>
                  <MessageSquare className="mx-auto size-9 text-vivi" />
                  <div className="mt-3 text-base font-semibold text-text">Bereit für eine neue Vivi-Unterhaltung</div>
                  <div className="mt-2 max-w-md text-sm leading-6 text-muted">
                    Neue Sessions bekommen automatisch den Backbone-Startkontext. Sende einfach deine Anfrage, Vivi liest die lokale Arbeitslage selbst.
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="border-t border-border p-3">
            <div className="grid gap-2 md:grid-cols-[minmax(0,1fr)_120px]">
              <textarea
                value={messageDraft}
                onChange={(event) => setMessageDraft(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key !== 'Enter' || event.shiftKey) return;
                  event.preventDefault();
                  if (activeSession && messageDraft.trim() && !busyAction) void sendMessage();
                }}
                placeholder={activeSession ? 'Nachricht an Vivi...' : 'Lege zuerst eine Session an...'}
                disabled={!activeSession || Boolean(busyAction)}
                rows={3}
                className="min-h-[86px] w-full resize-none rounded-xl border border-border bg-cpbg/50 px-3 py-2 text-sm leading-6 text-text outline-none transition placeholder:text-muted/70 focus:border-strong focus:ring-2 focus:ring-[rgba(98,196,255,0.30)] disabled:opacity-50"
              />
              <Button variant="vivi" className="h-full min-h-[86px]" onClick={() => void sendMessage()} disabled={!activeSession || !messageDraft.trim() || Boolean(busyAction)}>
                {busyAction === 'send' ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
                Senden
              </Button>
            </div>
          </div>
        </section>
      </CardContent>
    </Card>
  );
}

function ChatBubble({ message }: { message: ViviChatMessage }) {
  const isOperator = message.role === 'operator';
  const isSystem = message.role === 'system';
  const Icon = isOperator ? UserRound : Bot;

  return (
    <div className={cn('flex gap-3', isOperator ? 'justify-end' : 'justify-start')}>
      {!isOperator ? (
        <div className={cn('mt-1 grid size-8 shrink-0 place-items-center rounded-full border', isSystem ? 'border-border bg-elevated text-muted' : 'border-vivi/40 bg-vivi-soft text-vivi')}>
          <Icon className="size-4" />
        </div>
      ) : null}
      <div
        className={cn(
          'max-w-[82%] rounded-2xl border px-4 py-3 text-sm leading-6',
          isOperator
            ? 'border-vega/25 bg-vega-soft/75 text-text'
            : isSystem
              ? 'border-border bg-elevated/40 text-muted'
              : 'border-vivi/30 bg-vivi-soft/70 text-text',
        )}
      >
        <div className="mb-2 flex flex-wrap items-center gap-2 font-mono text-[0.68rem] uppercase tracking-[0.13em]">
          <span className={isOperator ? 'text-vega' : isSystem ? 'text-muted' : 'text-vivi'}>
            {isOperator ? 'Operator' : isSystem ? 'System' : 'Vivi'}
          </span>
          <span className="text-muted">{formatTime(message.addedAt)}</span>
          {message.reference ? <span className="truncate text-muted">Ref {message.reference}</span> : null}
        </div>
        <p className="whitespace-pre-wrap break-words">{message.message}</p>
      </div>
      {isOperator ? (
        <div className="mt-1 grid size-8 shrink-0 place-items-center rounded-full border border-vega/35 bg-vega-soft text-vega">
          <Icon className="size-4" />
        </div>
      ) : null}
    </div>
  );
}

function formatTime(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
}

function formatProviderOptionLabel(label: string, status?: { source: string; modelCount: number }): string {
  if (!status) return label;
  const source = status.source === 'live' ? 'Live' : status.source === 'fallback' ? 'Fallback' : 'kein Katalog';
  return `${label} (${source}, ${status.modelCount})`;
}
