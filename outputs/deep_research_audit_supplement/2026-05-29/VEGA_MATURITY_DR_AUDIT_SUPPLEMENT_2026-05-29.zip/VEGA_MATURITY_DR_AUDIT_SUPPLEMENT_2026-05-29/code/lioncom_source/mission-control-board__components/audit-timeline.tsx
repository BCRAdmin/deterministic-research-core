'use client';

import { useMemo, useState } from 'react';

import { AgentBadge } from '@/components/agent-badge';
import { FilterBar, type FilterField } from '@/components/filter-bar';
import { InfoButton } from '@/components/info-button';
import { StatusChip } from '@/components/status-chip';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/cn';
import type { AuditEvent, Severity } from '@/lib/types';

const sources = ['Alle', 'Operator', 'Vivi', 'Vega', 'System', 'Bridge'] as const;
const eventTypes = ['Alle', 'Dispatch', 'Handoff', 'Automation', 'Verification', 'Commit', 'Mission', 'Alert'] as const;
const severities: Array<Severity | 'Alle'> = ['Alle', 'info', 'success', 'warning', 'critical'];
const eventTypeLabels: Record<string, string> = {
  Alert: 'Alarm',
  Automation: 'Automation',
  Commit: 'Commit',
  Dispatch: 'Dispatch',
  Handoff: 'Übergabe',
  Mission: 'Mission',
  Verification: 'Verifikation',
};

function sourceLabel(source: AuditEvent['source']) {
  return source === 'Bridge' ? 'Brücke' : source;
}

export function AuditTimeline({ events }: { events: AuditEvent[] }) {
  const [source, setSource] = useState<(typeof sources)[number]>('Alle');
  const [eventType, setEventType] = useState<(typeof eventTypes)[number]>('Alle');
  const [severity, setSeverity] = useState<Severity | 'Alle'>('Alle');
  const [search, setSearch] = useState('');
  const [selectedId, setSelectedId] = useState(events[0]?.id ?? '');

  const filtered = useMemo(
    () =>
      events.filter((event) => {
        const sourceMatch = source === 'Alle' || event.source === source;
        const typeMatch = eventType === 'Alle' || event.type === eventType;
        const severityMatch = severity === 'Alle' || event.severity === severity;
        const searchMatch = event.event.toLowerCase().includes(search.toLowerCase()) || event.reference.toLowerCase().includes(search.toLowerCase());
        return sourceMatch && typeMatch && severityMatch && searchMatch;
      }),
    [eventType, events, search, severity, source],
  );
  const selected = events.find((event) => event.id === selectedId) ?? filtered[0] ?? events[0];

  const fields: FilterField[] = [
    { id: 'source', label: 'Quelle', value: source, onChange: (value) => setSource(sources.find((item) => item === value) ?? 'Alle'), options: sources.map((item) => ({ value: item, label: item === 'Bridge' ? 'Brücke' : item })) },
    { id: 'eventType', label: 'Ereignistyp', value: eventType, onChange: (value) => setEventType(eventTypes.find((item) => item === value) ?? 'Alle'), options: eventTypes.map((item) => ({ value: item, label: item === 'Alle' ? 'Alle Typen' : eventTypeLabels[item] })) },
    { id: 'severity', label: 'Schweregrad', value: severity, onChange: (value) => setSeverity(severities.find((item) => item === value) ?? 'Alle'), options: severities.map((item) => ({ value: item, label: item === 'Alle' ? 'Alle Stufen' : severityLabel(item) })) },
  ];

  function downloadAuditExport() {
    const lines = [
      '# LIONCOM Audit-Protokoll',
      '',
      `Exportiert: ${new Date().toLocaleString('de-DE')}`,
      `Filter: Quelle ${source}, Typ ${eventType}, Schwere ${severity}`,
      `Ereignisse: ${filtered.length}`,
      '',
      ...filtered.map((event) => [
        `## ${event.time} - ${event.event}`,
        `Quelle: ${sourceLabel(event.source)}`,
        `Typ: ${eventTypeLabels[event.type] ?? event.type}`,
        `Agent: ${event.agentId ?? 'Global'}`,
        `Referenz: ${event.reference}`,
        `Schwere: ${severityLabel(event.severity)}`,
        `Kurzinfo: ${event.payload}`,
        `Vorher: ${event.before}`,
        `Nachher: ${event.after}`,
        '',
      ].join('\n')),
    ].join('\n');
    const blob = new Blob([lines], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `lioncom-audit-${new Date().toISOString().slice(0, 10)}.md`;
    document.body.append(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 500);
  }

  return (
    <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_390px]">
      <Card className="rounded-2xl p-4">
        <FilterBar fields={fields} search={search} onSearchChange={setSearch} searchPlaceholder="Audit durchsuchen..." />
        <div className="mt-4 overflow-x-auto rounded-xl border border-border bg-cpbg/30">
          <div className="grid min-w-[980px] grid-cols-[90px_100px_minmax(0,1fr)_120px_90px_130px_110px] gap-3 border-b border-border px-3 py-2 hud-label text-muted">
            <span>Zeit</span>
            <span>Quelle</span>
            <span>Ereignis</span>
            <span>Typ</span>
            <span>Agent</span>
            <span>Referenz</span>
            <span>Schwere</span>
          </div>
          {filtered.map((event) => (
            <button
              key={event.id}
              type="button"
              onClick={() => setSelectedId(event.id)}
              className={cn('grid min-w-[980px] w-full grid-cols-[90px_100px_minmax(0,1fr)_120px_90px_130px_110px] items-center gap-3 border-b border-border bg-cpbg/55 px-3 py-3 text-left text-sm transition last:border-b-0 hover:bg-elevated/55', selected?.id === event.id && 'bg-vega-soft ring-1 ring-inset ring-vega/45')}
            >
              <span className="font-mono text-xs text-muted">{event.time}</span>
              <span className="text-text">{sourceLabel(event.source)}</span>
              <span className="truncate text-text">{event.event}</span>
              <span className="text-muted">{eventTypeLabels[event.type] ?? event.type}</span>
              <span>{event.agentId ? <AgentBadge agentId={event.agentId} compact /> : <span className="text-muted">Global</span>}</span>
              <span className="truncate font-mono text-xs text-vega">{event.reference}</span>
              <StatusChip label={severityLabel(event.severity)} tone={event.severity} />
            </button>
          ))}
        </div>
      </Card>

      <Card className="rounded-2xl p-4">
        <div className="hud-title text-sm text-vega">Ereignisdetails</div>
        {selected ? (
          <div className="mt-4 space-y-4">
            <div>
              <div className="font-mono text-xs text-muted">{selected.traceId}</div>
              <div className="mt-2 text-lg font-semibold text-text">{selected.event}</div>
            </div>
            <div className="flex flex-wrap gap-2">
              <StatusChip label={eventTypeLabels[selected.type] ?? selected.type} tone="info" />
              <StatusChip label={severityLabel(selected.severity)} tone={selected.severity} />
              {selected.agentId ? <AgentBadge agentId={selected.agentId} /> : null}
            </div>
            {[
              ['Kurzinfo', selected.payload],
              ['Zugehörige Mission', selected.reference],
              ['Vorher', selected.before],
              ['Nachher', selected.after],
            ].map(([label, value]) => (
              <div key={label} className="rounded-xl border border-border bg-cpbg/30 p-3">
                <div className="hud-label text-muted">{label}</div>
                <div className="mt-2 font-mono text-xs leading-relaxed text-text">{value}</div>
              </div>
            ))}
            <div className="grid grid-cols-3 gap-2">
              <InfoButton variant="outline" size="sm" onClick={downloadAuditExport} info={{ title: 'Audit exportiert', body: `Ein lesbares Audit-Protokoll mit ${filtered.length} Ereignissen aus dem aktuellen Filter wurde vorbereitet. Wichtigster Trace: ${selected.traceId}. Quelle, Typ, Schweregrad und Vorher/Nachher bleiben im Detailpanel nachvollziehbar.`, tone: 'success' }}>Audit exportieren</InfoButton>
              <button
                type="button"
                className="inline-flex h-9 items-center justify-center gap-2 rounded-xl border border-border bg-transparent px-3 text-sm font-medium text-muted transition hover:border-strong hover:bg-white/5 hover:text-text"
                onClick={() => {
                  setSeverity('critical');
                  setSource('Alle');
                  setEventType('Alle');
                }}
              >
                Nur kritische
              </button>
              <InfoButton variant="vega" size="sm" info={{ title: 'Trace öffnen', body: `Trace ${selected.traceId}: ${selected.event}. Referenz ${selected.reference}. Vorher: ${selected.before}. Nachher: ${selected.after}.`, tone: selected.severity === 'critical' ? 'critical' : 'info' }}>Trace öffnen</InfoButton>
            </div>
          </div>
        ) : null}
      </Card>
    </div>
  );
}

function severityLabel(severity: Severity): string {
  if (severity === 'critical') return 'Kritisch';
  if (severity === 'success') return 'Erfolg';
  if (severity === 'warning') return 'Warnung';
  return 'Info';
}
