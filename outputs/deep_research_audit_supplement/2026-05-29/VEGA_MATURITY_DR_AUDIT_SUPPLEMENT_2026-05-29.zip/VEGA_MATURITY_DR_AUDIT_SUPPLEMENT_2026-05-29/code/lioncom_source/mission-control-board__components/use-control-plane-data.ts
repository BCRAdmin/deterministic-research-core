'use client';

import { createContext, useContext } from 'react';

import * as mock from '@/lib/mock-data';
import type { ControlPlaneLiveData } from '@/lib/types';
import { useControlPlaneStore } from '@/store/control-plane-store';

export const InitialControlPlaneDataContext = createContext<ControlPlaneLiveData | null>(null);
const FALLBACK_GENERATED_AT = '2026-05-06T02:34:12.000Z';

export function useControlPlaneData() {
  const initialLiveData = useContext(InitialControlPlaneDataContext);
  const storeLiveData = useControlPlaneStore((state) => state.liveData);
  const liveData = storeLiveData ?? initialLiveData;

  return {
    generatedAt: liveData?.generatedAt ?? FALLBACK_GENERATED_AT,
    source: liveData?.source ?? 'fallback',
    operatorLoopStatus: liveData?.operatorLoopStatus ?? mock.operatorLoopStatus,
    globalStatus: liveData?.globalStatus ?? mock.globalStatus,
    agents: liveData?.agents ?? mock.agents,
    agentSummaries: liveData?.agentSummaries ?? mock.agentSummaries,
    missions: liveData?.missions ?? mock.missions,
    dispatchEvents: liveData?.dispatchEvents ?? mock.dispatchEvents,
    handoffQueue: liveData?.handoffQueue ?? mock.handoffQueue,
    telemetrySignals: liveData?.telemetrySignals ?? mock.telemetrySignals,
    alerts: liveData?.alerts ?? mock.alerts,
    backlogItems: liveData?.backlogItems ?? mock.backlogItems,
    auditEvents: liveData?.auditEvents ?? mock.auditEvents,
    activitySignals: liveData?.activitySignals ?? mock.activitySignals,
    automationTasks: liveData?.automationTasks ?? mock.automationTasks,
    queueItems: liveData?.queueItems ?? mock.queueItems,
    chatMessages: liveData?.chatMessages ?? mock.chatMessages,
    workspaces: liveData?.workspaces ?? mock.workspaces,
    runtimeProfiles: liveData?.runtimeProfiles ?? mock.runtimeProfiles,
    intakeRows: liveData?.intakeRows ?? mock.intakeRows,
    repoSnapshots: liveData?.repoSnapshots ?? mock.repoSnapshots,
    portfolioRepositories: liveData?.portfolioRepositories ?? mock.portfolioRepositories,
    portfolioExecutionContract: liveData?.portfolioExecutionContract ?? mock.portfolioExecutionContract,
    portfolioMetrics: liveData?.portfolioMetrics ?? mock.portfolioMetrics,
    portfolioReviewCalendar: liveData?.portfolioReviewCalendar ?? mock.portfolioReviewCalendar,
    planningQuality: liveData?.planningQuality ?? mock.planningQuality,
    goldenBaseline: liveData?.goldenBaseline ?? mock.goldenBaseline,
    verificationItems: mock.verificationItems,
    handoffs: mock.handoffs,
  };
}
