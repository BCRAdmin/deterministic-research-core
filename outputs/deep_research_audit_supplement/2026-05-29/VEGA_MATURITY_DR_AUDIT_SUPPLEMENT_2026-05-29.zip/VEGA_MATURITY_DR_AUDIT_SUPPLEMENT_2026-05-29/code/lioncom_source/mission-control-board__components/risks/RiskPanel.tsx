// RiskPanel - Kompakte Risiko/Blocker-Anzeige

interface RiskPanelProps {
  blockedCount: number;
  openIssues: string[];
}

export function RiskPanel({ blockedCount, openIssues }: RiskPanelProps) {
  return (
    <div className="bg-white rounded-lg shadow border border-slate-200 p-4 mx-4">
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm font-medium">Risiken & Blocker</span>
        {blockedCount > 0 && (
          <span className="px-2 py-1 bg-red-100 text-red-700 text-xs rounded-full">
            {blockedCount} blockiert
          </span>
        )}
      </div>
      
      {openIssues.length > 0 ? (
        <ul className="space-y-1 text-sm text-slate-600">
          {openIssues.slice(0, 3).map((issue, idx) => (
            <li key={idx} className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
              <span>{issue}</span>
            </li>
          ))}
        </ul>
      ) : (
        <span className="text-sm text-slate-400">Keine offenen Blocker</span>
      )}
    </div>
  );
}
