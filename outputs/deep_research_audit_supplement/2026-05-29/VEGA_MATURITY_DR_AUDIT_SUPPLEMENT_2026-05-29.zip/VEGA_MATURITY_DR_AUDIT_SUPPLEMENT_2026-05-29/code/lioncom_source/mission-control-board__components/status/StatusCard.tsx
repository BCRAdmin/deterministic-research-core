// StatusCard - Einzelne Status-Anzeige

import type { StatusValue } from '@/lib/mappers/statusMapper';

interface StatusCardProps {
  name: string;
  status: StatusValue;
  icon?: string;
}

const statusColors = {
  healthy: 'bg-emerald-500',
  warning: 'bg-amber-500',
  error: 'bg-red-500',
  unknown: 'bg-slate-500'
};

const statusLabels = {
  healthy: 'OK',
  warning: 'Warnung',
  error: 'Fehler',
  unknown: 'Unbekannt'
};

export function StatusCard({ name, status, icon }: StatusCardProps) {
  return (
    <div className="bg-white rounded-lg shadow border border-slate-200 p-4">
      <div className="flex items-center gap-2">
        {icon && <span className="text-lg">{icon}</span>}
        <span className="font-medium text-sm">{name}</span>
      </div>
      <div className="mt-2 flex items-center gap-2">
        <span className={`w-2 h-2 rounded-full ${statusColors[status]}`}></span>
        <span className="text-sm text-slate-600">{statusLabels[status]}</span>
      </div>
    </div>
  );
}
