import { ArrowRight, GitBranch } from 'lucide-react';

import { InfoButton } from '@/components/info-button';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/cn';
import type { Handoff } from '@/lib/types';

export function HandoffCard({
  handoff,
  accent = 'vivi',
  className,
}: {
  handoff: Handoff;
  accent?: 'vivi' | 'vega';
  className?: string;
}) {
  return (
    <Card className={cn('rounded-2xl p-4', accent === 'vivi' ? 'hud-glow-vivi' : 'hud-glow-vega', className)}>
      <div className="flex min-w-0 items-start gap-3">
        <div className={cn('grid size-10 place-items-center rounded-xl border', accent === 'vivi' ? 'border-vivi/40 bg-vivi-soft text-vivi' : 'border-vega/40 bg-vega-soft text-vega')}>
          <GitBranch className="size-5" />
        </div>
        <div className="min-w-0">
          <div className={cn('hud-title text-sm', accent === 'vivi' ? 'text-vivi' : 'text-vega')}>{handoff.title}</div>
          <div className="mt-1 line-clamp-2 text-xs leading-5 text-muted">{handoff.detail}</div>
        </div>
      </div>
      <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
        <div className={cn('hud-label min-w-0 truncate', accent === 'vivi' ? 'text-vivi' : 'text-vega')}>{handoff.status}</div>
        <InfoButton className="shrink-0" variant={accent} size="sm" info={{ title: handoff.actionLabel, body: `${handoff.title}: ${handoff.detail}. Die Übergabe bleibt als Operator-Entscheidung sichtbar; technische Detailarbeit bleibt sauber bei Vega.`, tone: 'info' }}>
          {handoff.actionLabel}
          <ArrowRight className="size-4" />
        </InfoButton>
      </div>
    </Card>
  );
}
