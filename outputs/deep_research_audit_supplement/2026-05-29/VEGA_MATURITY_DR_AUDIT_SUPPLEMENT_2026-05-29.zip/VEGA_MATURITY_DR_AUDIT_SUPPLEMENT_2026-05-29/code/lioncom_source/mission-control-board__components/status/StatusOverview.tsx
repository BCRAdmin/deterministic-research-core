// StatusOverview - Container fuer alle Status-Karten

import { StatusCard } from './StatusCard';
import { StatusGrid } from '../layout/StatusGrid';
import type { MappedStatus } from '@/lib/mappers/statusMapper';

interface StatusOverviewProps {
  status: MappedStatus;
}

export function StatusOverview({ status }: StatusOverviewProps) {
  return (
    <StatusGrid>
      <StatusCard name="OpenClaw" status={status.openclaw} icon="🤖" />
      <StatusCard name="Telegram" status={status.telegram} icon="💬" />
      <StatusCard name="Cron" status={status.cron} icon="⏰" />
      <StatusCard name="GitHub" status={status.github} icon="🐙" />
      <StatusCard name="Morning Briefing" status={status.morningBriefing} icon="📋" />
      <StatusCard name="Nightly Research" status={status.nightlyResearch} icon="🔍" />
    </StatusGrid>
  );
}
