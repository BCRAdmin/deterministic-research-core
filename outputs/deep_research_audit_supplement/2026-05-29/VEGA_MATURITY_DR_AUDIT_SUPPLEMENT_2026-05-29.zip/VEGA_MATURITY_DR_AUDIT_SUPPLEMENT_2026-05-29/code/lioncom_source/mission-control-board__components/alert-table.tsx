import { StatusChip } from '@/components/status-chip';
import { Card } from '@/components/ui/card';
import type { AlertItem } from '@/lib/types';

export function AlertTable({ alerts }: { alerts: AlertItem[] }) {
  const summary = summarizeAlerts(alerts);

  return (
    <Card className="rounded-2xl p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="hud-title text-sm text-warning">Alarmwege</div>
          <p className="mt-1 max-w-2xl text-sm text-muted">
            Jede Warnung zeigt Analysepfad, Reparaturpfad, Nacht-Fix oder Operator-Gate mit nächstem sicheren Schritt.
          </p>
        </div>
        <div className="grid min-w-[260px] grid-cols-3 gap-2 text-center">
          <SummaryPill label="Gruppen" value={String(summary.groups)} />
          <SummaryPill label="Kritisch" value={String(summary.critical)} tone={summary.critical > 0 ? 'critical' : 'info'} />
          <SummaryPill label="Gates" value={String(summary.operatorGates)} tone={summary.operatorGates > 0 ? 'warning' : 'info'} />
        </div>
      </div>
      <div className="mt-4 overflow-x-auto rounded-xl border border-border bg-cpbg/30">
        <div className="grid min-w-[980px] grid-cols-[130px_150px_minmax(0,1.35fr)_minmax(260px,1fr)_92px] gap-3 border-b border-border px-3 py-2 hud-label text-muted">
          <span>Pfad</span>
          <span>Quelle</span>
          <span>Meldung</span>
          <span>Nächster sicherer Schritt</span>
          <span>Status</span>
        </div>
        {alerts.map((alert) => (
          <div key={alert.id} className="grid min-w-[980px] grid-cols-[130px_150px_minmax(0,1.35fr)_minmax(260px,1fr)_92px] items-start gap-3 border-b border-border px-3 py-3 text-sm last:border-b-0">
            <div className="space-y-2">
              <StatusChip label={alert.actionLabel || actionPathLabel(alert.actionPath)} tone={toneForPath(alert.actionPath, alert.severity)} />
              <div className="font-mono text-[11px] uppercase tracking-[0.08em] text-muted">{severityLabel(alert.severity)}</div>
            </div>
            <div>
              <div className="text-text">{alert.source === 'Bridge' ? 'Brücke' : alert.source}</div>
              <div className="mt-1 text-xs text-muted">{alert.group || 'Beobachtung'}</div>
              <div className="mt-1 font-mono text-[11px] text-muted">{alert.time}</div>
            </div>
            <div>
              <div className="font-medium text-text">{alert.message}</div>
              <div className="mt-1 line-clamp-2 text-xs leading-5 text-muted">{alert.recommendation || 'Alert lokal prüfen und erst nach Verifikation weiter eskalieren.'}</div>
            </div>
            <div className="text-sm leading-5 text-text">
              {alert.nextStep || 'Weiter beobachten und erst aktiv werden, wenn ein Verifier kippt oder ein Operator-Gate sichtbar wird.'}
            </div>
            <span className="text-text">{statusLabel(alert.status)}</span>
          </div>
        ))}
      </div>
    </Card>
  );
}

function SummaryPill({ label, value, tone = 'info' }: { label: string; value: string; tone?: AlertItem['severity'] }) {
  return (
    <div className={`rounded-lg border px-2 py-2 ${tone === 'critical' ? 'border-danger/60 bg-danger/10' : tone === 'warning' ? 'border-warning/60 bg-warning/10' : 'border-border bg-cpbg/30'}`}>
      <div className="font-mono text-sm text-text">{value}</div>
      <div className="hud-label mt-1 text-[10px] text-muted">{label}</div>
    </div>
  );
}

function summarizeAlerts(alerts: AlertItem[]) {
  return {
    groups: new Set(alerts.map((alert) => alert.group || 'Beobachtung')).size,
    critical: alerts.filter((alert) => alert.severity === 'critical').length,
    operatorGates: alerts.filter((alert) => alert.actionPath === 'operator_gate').length,
  };
}

function statusLabel(status: string): string {
  const value = status.toLowerCase();
  if (value.includes('closed')) return 'geschlossen';
  if (value.includes('open')) return 'offen';
  if (value.includes('watch')) return 'beobachtet';
  return status;
}

function actionPathLabel(path: AlertItem['actionPath']): string {
  if (path === 'analyse') return 'Analysepfad';
  if (path === 'reparatur') return 'Reparaturpfad';
  if (path === 'nachtfix') return 'Nacht-Fix';
  if (path === 'operator_gate') return 'Operator-Gate';
  return 'Beobachten';
}

function toneForPath(path: AlertItem['actionPath'], severity: AlertItem['severity']): AlertItem['severity'] {
  if (path === 'operator_gate' || severity === 'critical') return 'critical';
  if (path === 'reparatur' || path === 'nachtfix') return 'warning';
  return severity;
}

function severityLabel(severity: AlertItem['severity']): string {
  if (severity === 'critical') return 'Kritisch';
  if (severity === 'success') return 'Erfolg';
  if (severity === 'warning') return 'Warnung';
  return 'Info';
}
