'use client';

import { useEffect, useRef } from 'react';
import { useSearchParams } from 'next/navigation';

import { SidebarNav } from '@/components/sidebar-nav';
import { TopStatusBar } from '@/components/top-status-bar';
import { AuditLogPage } from '@/components/audit-log-page';
import { BacklogPage } from '@/components/backlog-page';
import { DispatchBridgePage } from '@/components/dispatch-bridge-page';
import { MissionsPage } from '@/components/missions-page';
import { OperatorInfoDialog } from '@/components/operator-info-dialog';
import { OverviewPage } from '@/components/overview-page';
import { PortfolioControlTowerPage } from '@/components/portfolio-control-tower-page';
import { TelemetryPage } from '@/components/telemetry-page';
import { VegaTechCellPage } from '@/components/vega-tech-cell-page';
import { ViviCommandPage } from '@/components/vivi-command-page';
import { InitialControlPlaneDataContext } from '@/components/use-control-plane-data';
import type { ControlPlaneLiveData, ControlPlaneView } from '@/lib/types';
import { useControlPlaneStore } from '@/store/control-plane-store';

function renderView(selectedView: ControlPlaneView) {
  switch (selectedView) {
    case 'overview':
      return <OverviewPage />;
    case 'vivi':
      return <ViviCommandPage />;
    case 'vega':
      return <VegaTechCellPage />;
    case 'portfolio':
      return <PortfolioControlTowerPage />;
    case 'dispatch':
      return <DispatchBridgePage />;
    case 'missions':
      return <MissionsPage />;
    case 'telemetry':
      return <TelemetryPage />;
    case 'backlog':
      return <BacklogPage />;
    case 'audit':
      return <AuditLogPage />;
    default:
      return <OverviewPage />;
  }
}

const controlPlaneViews = new Set<ControlPlaneView>([
  'overview',
  'vivi',
  'vega',
  'portfolio',
  'dispatch',
  'missions',
  'telemetry',
  'backlog',
  'audit',
]);

function isControlPlaneView(view: string | null): view is ControlPlaneView {
  return Boolean(view && controlPlaneViews.has(view as ControlPlaneView));
}

function savedNotice(saved: string | null, legacyTab: string | null, source: string | null) {
  if (source === 'operator-go') {
    return {
      title: 'Operator-Go Vorschau geöffnet',
      body: 'Dieser Link kam aus der alten Freigabe-Schicht und landet jetzt bewusst in Control Plane V2. Prüfe den aktuellen Status über Übersicht, Audit-Protokoll oder Backlog; die alte V111-Tab-Oberfläche wird dafür nicht mehr verwendet.',
      tone: 'info' as const,
    };
  }

  const savedLabels: Record<string, string> = {
    'brain-dump': 'Idee wurde im Brain-Dump gesichert.',
    'work-intake': 'Arbeitsauftrag wurde in den Eingang geschrieben.',
    'telegram-packet': 'Telegram-Paket wurde übernommen.',
    'telegram-poll': 'Telegram-Brücke wurde abgefragt.',
    'telegram-poll-failed': 'Telegram-Abfrage konnte nicht abgeschlossen werden.',
    'codex-chat': 'Vega-Nachricht wurde gespeichert.',
    'codex-command': 'Vega-Auftrag wurde gespeichert.',
    'vivi-command': 'Vivi-Auftrag wurde gespeichert.',
    'repair-request': 'Reparaturauftrag wurde gespeichert.',
  };
  const savedText = saved ? savedLabels[saved] ?? `Eingang wurde verarbeitet: ${saved}.` : null;

  if (!savedText && !legacyTab) return null;

  return {
    title: saved === 'telegram-poll-failed' ? 'Eingang prüfen' : 'Eingang gesichert',
    body: `${savedText ?? 'Der alte Rücksprung wurde übernommen.'} Du bist jetzt auf Control Plane V2. Die Daten werden als Lagebild, Rückstau, Dispatch oder Agentenbereich angezeigt; Rohdaten bleiben aus der Operator-Oberfläche heraus.`,
    tone: saved === 'telegram-poll-failed' ? 'warning' as const : 'success' as const,
    actionLabel: 'Weiterarbeiten',
  };
}

export function AppShell({ initialLiveData }: { initialLiveData?: ControlPlaneLiveData | null }) {
  const selectedView = useControlPlaneStore((state) => state.selectedView);
  const setSelectedView = useControlPlaneStore((state) => state.setSelectedView);
  const setLiveData = useControlPlaneStore((state) => state.setLiveData);
  const setLiveState = useControlPlaneStore((state) => state.setLiveState);
  const openOperatorInfo = useControlPlaneStore((state) => state.openOperatorInfo);
  const searchParams = useSearchParams();
  const initialized = useRef(false);
  const shownNoticeKey = useRef<string | null>(null);

  useEffect(() => {
    if (!initialized.current && initialLiveData) {
      setLiveData(initialLiveData);
      initialized.current = true;
    }
  }, [initialLiveData, setLiveData]);

  useEffect(() => {
    let cancelled = false;

    async function refreshLiveData(markLoading: boolean) {
      if (markLoading) {
        setLiveState('loading');
      }

      try {
        const response = await fetch('/api/control-plane-v2', { cache: 'no-store' });
        if (!response.ok) {
          throw new Error(`Live snapshot unavailable (${response.status})`);
        }
        const data = (await response.json()) as ControlPlaneLiveData;
        if (!cancelled) {
          setLiveData(data);
        }
      } catch (error) {
        if (!cancelled) {
          setLiveState('error', error instanceof Error ? error.message : 'Live snapshot unavailable');
        }
      }
    }

    refreshLiveData(!initialLiveData);
    const interval = window.setInterval(() => refreshLiveData(false), 30_000);

    return () => {
      cancelled = true;
      window.clearInterval(interval);
    };
  }, [initialLiveData, setLiveData, setLiveState]);

  useEffect(() => {
    const requestedView = searchParams.get('view');
    if (isControlPlaneView(requestedView)) {
      setSelectedView(requestedView);
    }
  }, [searchParams, setSelectedView]);

  useEffect(() => {
    const noticeKey = searchParams.toString();
    if (!noticeKey || shownNoticeKey.current === noticeKey) return;

    const notice = savedNotice(
      searchParams.get('saved'),
      searchParams.get('legacyTab'),
      searchParams.get('source'),
    );
    if (!notice) return;

    shownNoticeKey.current = noticeKey;
    openOperatorInfo(notice);
  }, [openOperatorInfo, searchParams]);

  return (
    <InitialControlPlaneDataContext.Provider value={initialLiveData ?? null}>
      <div className="control-plane-v2 relative min-h-screen overflow-hidden bg-cpbg text-text">
        <SidebarNav />
        <TopStatusBar />
        <main className="control-plane-v2-main fixed inset-y-0 left-sidebar right-0 top-topbar z-[1] overflow-y-auto px-3 pb-3 pt-3 2xl:px-4">
          {renderView(selectedView)}
        </main>
        <OperatorInfoDialog />
      </div>
    </InitialControlPlaneDataContext.Provider>
  );
}
