// BackupStatus - GitHub Backup Anzeige

interface BackupStatusProps {
  isRepo: boolean;
  hasRemote: boolean;
  lastCommit?: string;
  branch: string;
}

export function BackupStatus({ isRepo, hasRemote, lastCommit, branch }: BackupStatusProps) {
  const status = isRepo && hasRemote ? 'healthy' : isRepo ? 'warning' : 'error';
  const statusColor = status === 'healthy' ? 'bg-emerald-500' : status === 'warning' ? 'bg-amber-500' : 'bg-red-500';
  
  return (
    <div className="bg-white rounded-lg shadow border border-slate-200 p-4 mx-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className={`w-2 h-2 rounded-full ${statusColor}`}></span>
          <span className="text-sm font-medium">GitHub Backup</span>
        </div>
        <span className="text-xs text-slate-400">{branch}</span>
      </div>
      
      {lastCommit && (
        <div className="mt-2 text-xs text-slate-500">
          Letzter Commit: {lastCommit.slice(0, 7)}
        </div>
      )}
    </div>
  );
}
