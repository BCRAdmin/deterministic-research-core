import type { Metric } from '@/lib/types';
import { cn } from '@/lib/cn';

function points(values: number[]) {
  if (values.length === 0) return '';
  const min = Math.min(...values);
  const max = Math.max(...values);
  const spread = Math.max(1, max - min);
  return values
    .map((value, index) => {
      const x = (index / Math.max(1, values.length - 1)) * 100;
      const y = 34 - ((value - min) / spread) * 25;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');
}

export function MetricCard({ metric, accent }: { metric: Metric; accent: 'vivi' | 'vega' }) {
  const accentClass = accent === 'vivi' ? 'text-vivi' : 'text-vega';
  const lineColor = accent === 'vivi' ? 'var(--cp-vivi)' : 'var(--cp-vega)';

  return (
    <div className="min-w-0 border-l border-border px-4 first:border-l-0">
      <div className="hud-label line-clamp-2 text-muted">{metric.label}</div>
      <div className={cn('mt-3 text-2xl font-semibold tracking-wide', accentClass)}>{metric.value}</div>
      <div className="mt-1 line-clamp-3 text-xs leading-5 text-muted">{metric.detail}</div>
      {metric.sparkline ? (
        <svg viewBox="0 0 100 38" className="mt-3 h-10 w-full overflow-visible" aria-hidden="true">
          <defs>
            <linearGradient id={`metric-fill-${metric.id}`} x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor={lineColor} stopOpacity="0.28" />
              <stop offset="100%" stopColor={lineColor} stopOpacity="0" />
            </linearGradient>
          </defs>
          <polyline
            points={`0,38 ${points(metric.sparkline)} 100,38`}
            fill={`url(#metric-fill-${metric.id})`}
            stroke="none"
          />
          <polyline points={points(metric.sparkline)} fill="none" stroke={lineColor} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      ) : null}
    </div>
  );
}
