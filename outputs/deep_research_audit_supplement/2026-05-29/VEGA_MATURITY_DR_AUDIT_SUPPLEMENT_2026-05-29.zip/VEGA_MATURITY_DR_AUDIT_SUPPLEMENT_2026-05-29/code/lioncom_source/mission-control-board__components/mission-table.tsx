'use client';

import { useMemo, useState } from 'react';

import { AgentBadge } from '@/components/agent-badge';
import { FilterBar, type FilterField } from '@/components/filter-bar';
import { PriorityBadge } from '@/components/priority-badge';
import { StatusChip } from '@/components/status-chip';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/cn';
import type { AgentId, Mission, Priority } from '@/lib/types';

const statusOptions = ['all', 'intake', 'planning', 'active', 'review', 'done', 'blocked'];
const priorityOptions: Array<Priority | 'all'> = ['all', 'low', 'normal', 'high', 'critical'];
const statusLabels: Record<string, string> = {
  active: 'Aktiv',
  all: 'Alle Status',
  blocked: 'Blockiert',
  done: 'Erledigt',
  intake: 'Eingang',
  planning: 'Planung',
  review: 'Prüfung',
};

export function MissionTable({ missions }: { missions: Mission[] }) {
  const [agent, setAgent] = useState<AgentId | 'all'>('all');
  const [status, setStatus] = useState<Mission['status'] | 'all'>('all');
  const [priority, setPriority] = useState<Priority | 'all'>('all');
  const [search, setSearch] = useState('');
  const [selectedMissionId, setSelectedMissionId] = useState(missions[0]?.id ?? '');

  const filtered = useMemo(
    () =>
      missions.filter((mission) => {
        const matchesAgent = agent === 'all' || mission.ownerAgentId === agent;
        const matchesStatus = status === 'all' || mission.status === status;
        const matchesPriority = priority === 'all' || mission.priority === priority;
        const matchesSearch = mission.title.toLowerCase().includes(search.toLowerCase()) || mission.id.toLowerCase().includes(search.toLowerCase());
        return matchesAgent && matchesStatus && matchesPriority && matchesSearch;
      }),
    [agent, missions, priority, search, status],
  );

  const selectedMission = missions.find((mission) => mission.id === selectedMissionId) ?? filtered[0] ?? missions[0];

  const fields: FilterField[] = [
    {
      id: 'agent',
      label: 'Agent',
      value: agent,
      onChange: (value) => setAgent(value === 'vivi' || value === 'vega' ? value : 'all'),
      options: [
        { value: 'all', label: 'Alle Agenten' },
        { value: 'vivi', label: 'Vivi' },
        { value: 'vega', label: 'Vega' },
      ],
    },
    {
      id: 'status',
      label: 'Status',
      value: status,
      onChange: (value) => setStatus(statusOptions.includes(value) ? (value as Mission['status'] | 'all') : 'all'),
      options: statusOptions.map((option) => ({ value: option, label: statusLabels[option] ?? option })),
    },
    {
      id: 'priority',
      label: 'Priorität',
      value: priority,
      onChange: (value) => setPriority(priorityOptions.includes(value as Priority | 'all') ? (value as Priority | 'all') : 'all'),
      options: priorityOptions.map((option) => ({ value: option, label: option === 'all' ? 'Alle Prioritäten' : priorityLabel(option) })),
    },
  ];

  return (
    <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_360px]">
      <Card className="rounded-2xl p-4">
        <div className="flex items-center justify-between gap-3">
          <div>
            <div className="hud-title text-sm text-vega">Missionstabelle</div>
            <div className="mt-1 text-xs text-muted">Agentenübergreifend, filterbar, ohne Chat-Details.</div>
          </div>
          <div className="font-mono text-xs text-muted">{filtered.length} / {missions.length}</div>
        </div>
        <div className="mt-4">
          <FilterBar fields={fields} search={search} onSearchChange={setSearch} searchPlaceholder="Mission suchen..." />
        </div>
        <div className="mt-4 overflow-x-auto rounded-xl border border-border bg-cpbg/30">
          <div className="grid min-w-[1120px] grid-cols-[120px_minmax(0,1.5fr)_112px_100px_104px_110px_minmax(0,1fr)] gap-3 border-b border-border px-3 py-2 hud-label text-muted">
            <span>ID</span>
            <span>Titel</span>
            <span>Agent</span>
            <span>Status</span>
            <span>Priorität</span>
            <span>Fortschritt</span>
            <span>Nächster Schritt</span>
          </div>
          {filtered.map((mission) => (
            <button
              key={mission.id}
              type="button"
              onClick={() => setSelectedMissionId(mission.id)}
              className={cn(
                'grid min-w-[1120px] w-full grid-cols-[120px_minmax(0,1.5fr)_112px_100px_104px_110px_minmax(0,1fr)] items-center gap-3 border-b border-border bg-cpbg/55 px-3 py-3 text-left text-sm transition last:border-b-0 hover:bg-elevated/55',
                selectedMission?.id === mission.id && 'bg-vega-soft ring-1 ring-inset ring-vega/45',
              )}
            >
              <span className="truncate font-mono text-xs text-muted">{mission.id}</span>
              <span className="truncate text-text">{mission.title}</span>
              <AgentBadge agentId={mission.ownerAgentId} compact />
              <StatusChip label={statusLabels[mission.status] ?? mission.status} tone={mission.status === 'blocked' ? 'critical' : mission.status === 'done' ? 'success' : 'info'} />
              <PriorityBadge priority={mission.priority} />
              <span className="flex items-center gap-2">
                <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-elevated">
                  <span className={cn('block h-full rounded-full', mission.ownerAgentId === 'vivi' ? 'bg-vivi' : 'bg-vega')} style={{ width: `${mission.progress}%` }} />
                </span>
                <span className="font-mono text-xs text-muted">{mission.progress}%</span>
              </span>
              <span className="truncate text-muted">{mission.nextStep}</span>
            </button>
          ))}
        </div>
      </Card>

      <Card className="rounded-2xl p-4">
        <div className="hud-title text-sm text-vega">Missionsdetail</div>
        {selectedMission ? (
          <div className="mt-4 space-y-4">
            <div>
              <div className="font-mono text-xs text-muted">{selectedMission.id}</div>
              <div className="mt-2 text-lg font-semibold text-text">{selectedMission.title}</div>
            </div>
            <div className="flex flex-wrap gap-2">
              <AgentBadge agentId={selectedMission.ownerAgentId} />
              <PriorityBadge priority={selectedMission.priority} />
              <StatusChip label={statusLabels[selectedMission.status] ?? selectedMission.status} tone={selectedMission.status === 'blocked' ? 'critical' : 'info'} />
            </div>
            <div className="rounded-xl border border-border bg-cpbg/30 p-3">
              <div className="hud-label text-muted">Nächste Aktion</div>
              <div className="mt-2 text-sm text-text">{selectedMission.nextStep}</div>
            </div>
            <div className="rounded-xl border border-border bg-cpbg/30 p-3">
              <div className="hud-label text-muted">Übergabe-Historie</div>
              <div className="mt-3 space-y-2">
                {selectedMission.handoffHistory.map((entry) => (
                  <div key={entry} className="rounded-lg border border-border bg-elevated/40 px-3 py-2 text-sm text-text">{entry}</div>
                ))}
              </div>
            </div>
          </div>
        ) : null}
      </Card>
    </div>
  );
}

function priorityLabel(priority: Priority): string {
  if (priority === 'critical') return 'Kritisch';
  if (priority === 'high') return 'Hoch';
  if (priority === 'low') return 'Niedrig';
  return 'Normal';
}
