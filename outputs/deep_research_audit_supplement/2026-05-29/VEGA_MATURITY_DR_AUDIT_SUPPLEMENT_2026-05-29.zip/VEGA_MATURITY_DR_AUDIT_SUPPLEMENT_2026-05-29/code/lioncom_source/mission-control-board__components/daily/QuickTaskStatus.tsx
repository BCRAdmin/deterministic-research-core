// QuickTaskStatus - Minimaler Task-Ueberblick

import type { ParsedTaskQueue } from '@/lib/parsers/taskQueueParser';

interface QuickTaskStatusProps {
  tasks: ParsedTaskQueue;
}

export function QuickTaskStatus({ tasks }: QuickTaskStatusProps) {
  return (
    <div className="bg-white rounded-lg shadow border border-slate-200 p-4 mx-4">
      <div className="flex items-center justify-between">
        <div>
          <span className="text-sm font-medium">Aktiver Task:</span>
          <span className="ml-2 text-sm text-slate-700">
            {tasks.activeTask || 'Kein aktiver Task'}
          </span>
        </div>
        <div className="flex gap-4 text-sm text-slate-600">
          <span>Backlog: {tasks.backlogCount}</span>
          <span>Erledigt: {tasks.doneCount}</span>
          {tasks.blockedCount > 0 && <span className="text-red-500">Blockiert: {tasks.blockedCount}</span>}
        </div>
      </div>
    </div>
  );
}
