'use client';

import {
  AlertTriangle,
  Bell,
  Bot,
  CalendarCheck,
  ClipboardList,
  Gauge,
  GitBranch,
  Hexagon,
  LayoutDashboard,
  RadioTower,
  Shield,
  TerminalSquare,
} from 'lucide-react';

import { InfoButton } from '@/components/info-button';
import { cn } from '@/lib/cn';
import type { AgentId, ControlPlaneView } from '@/lib/types';
import { useControlPlaneStore } from '@/store/control-plane-store';

type NavItem = {
  id: ControlPlaneView;
  label: string;
  sublabel: string;
  icon: React.ComponentType<{ className?: string }>;
  agent?: AgentId;
};

const navItems: NavItem[] = [
  { id: 'overview', label: 'Übersicht', sublabel: 'Lagebild', icon: LayoutDashboard },
  { id: 'vivi', label: 'Vivi Command', sublabel: 'Primäre Steuerung', icon: Bot, agent: 'vivi' },
  { id: 'vega', label: 'Vega Tech Cell', sublabel: 'Prüfung & Code', icon: TerminalSquare, agent: 'vega' },
  { id: 'portfolio', label: 'Portfolio', sublabel: 'Repos & Gates', icon: Shield, agent: 'vega' },
  { id: 'dispatch', label: 'Dispatch-Brücke', sublabel: 'Routing & Übergaben', icon: GitBranch },
  { id: 'missions', label: 'Missionen', sublabel: 'Abläufe & Projekte', icon: CalendarCheck },
  { id: 'telemetry', label: 'Telemetrie', sublabel: 'System & Signale', icon: RadioTower },
  { id: 'backlog', label: 'Rückstau', sublabel: 'Warteschlangen & Eingang', icon: ClipboardList },
  { id: 'audit', label: 'Audit-Protokoll', sublabel: 'Aktivitäten & Ereignisse', icon: AlertTriangle },
];

export function SidebarNav() {
  const selectedView = useControlPlaneStore((state) => state.selectedView);
  const selectedAgent = useControlPlaneStore((state) => state.selectedAgent);
  const setSelectedView = useControlPlaneStore((state) => state.setSelectedView);

  return (
    <aside className="control-plane-v2-window-drag fixed inset-y-0 left-0 z-[3] w-sidebar border-r border-border bg-[rgba(4,12,20,0.92)] p-2 shadow-hud backdrop-blur-2xl">
      <div className="flex h-full flex-col gap-3 rounded-2xl border border-border bg-cpbg/20 p-2">
        <div className="flex items-center gap-3 px-3 py-2">
          <div className="grid size-12 place-items-center rounded-2xl border border-strong bg-vega-soft text-vega shadow-hud">
            <Hexagon className="size-7" />
          </div>
          <div className="min-w-0">
            <div className="hud-title text-lg leading-none text-text">LIONCOM</div>
            <div className="mt-1 text-xs text-muted">Kontrollebene</div>
          </div>
        </div>

        <nav className="mt-1 flex flex-1 flex-col gap-1">
          {navItems.map((item) => {
            const active = item.id === selectedView;
            const Icon = item.icon;
            const accent = item.agent === 'vivi' ? 'vivi' : item.agent === 'vega' ? 'vega' : selectedAgent;

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setSelectedView(item.id)}
                className={cn(
                  'group relative flex w-full items-center gap-3 rounded-xl border px-3 py-3 text-left transition',
                  active
                    ? accent === 'vivi'
                      ? 'border-[rgba(103,245,192,0.56)] bg-vivi-soft text-vivi hud-glow-vivi'
                      : 'border-[rgba(85,183,255,0.58)] bg-vega-soft text-vega hud-glow-vega'
                    : 'border-transparent bg-white/[0.015] text-muted hover:border-border hover:bg-white/[0.035] hover:text-text',
                )}
              >
                {active ? (
                  <span
                    className={cn(
                      'absolute left-0 top-2 h-[calc(100%-1rem)] w-1 rounded-r-full',
                      accent === 'vivi' ? 'bg-vivi' : 'bg-vega',
                    )}
                  />
                ) : null}
                <span
                  className={cn(
                    'grid size-9 shrink-0 place-items-center rounded-xl border transition',
                    active
                      ? accent === 'vivi'
                        ? 'border-vivi/45 bg-vivi-soft'
                        : 'border-vega/45 bg-vega-soft'
                      : 'border-border bg-cpbg/45 group-hover:border-strong',
                  )}
                >
                  <Icon className="size-4" />
                </span>
                <span className="min-w-0">
                  <span className="hud-title block truncate text-sm">{item.label}</span>
                  <span className="mt-0.5 block truncate text-xs text-muted">{item.sublabel}</span>
                </span>
              </button>
            );
          })}
        </nav>

        <div className="rounded-xl border border-border bg-elevated/50 p-3">
          <div className="flex items-center gap-2 text-muted">
            <Shield className="size-4 text-vivi" />
            <span className="hud-label">Kontrollzentrale</span>
          </div>
          <div className="mt-1 text-xs text-muted">Desktop-Kontrollebene</div>
          <div className="mt-3 flex gap-2">
            <InfoButton
              variant={selectedAgent}
              size="sm"
              className="flex-1"
              info={{
                title: 'Live-Lage',
                body: 'Die Kontrollzentrale ist online. Neue Operator-Aktionen laufen über die jeweilige Hauptseite, damit Vivi- und Vega-Daten getrennt bleiben.',
                tone: 'success',
              }}
            >
              <Gauge className="size-4" />
              Aktiv
            </InfoButton>
            <InfoButton
              variant="outline"
              size="icon"
              className="size-8"
              info={{
                title: 'Kontrollhinweise',
                body: 'Kontrollhinweise bündeln Dispatch, Missionen und Audit als kurze Operator-Lage. Kritische Punkte bleiben zusätzlich in der Topbar sichtbar.',
                tone: 'info',
              }}
            >
              <Bell className="size-4" />
            </InfoButton>
          </div>
        </div>
      </div>
    </aside>
  );
}
