'use client';

import { useEffect, useMemo, useState } from 'react';

import type {
  RoadmapCard,
  RoadmapCardSnapshot,
  RoadmapCardStatus,
} from '@/lib/types/roadmap-cards';

interface RoadmapCardMutationResponse {
  ok?: boolean;
  card?: RoadmapCard;
  snapshot?: RoadmapCardSnapshot;
  error?: string;
}

const STATUS_LABELS: Record<RoadmapCardStatus, string> = {
  parked: 'Geparkt',
  review_due: 'Fällig',
  queued: 'In Pipeline',
  done: 'Erledigt',
  blocked: 'Blockiert',
};

const PRIORITY_LABELS: Record<string, string> = {
  critical: 'Kritisch',
  high: 'Hoch',
  normal: 'Normal',
  low: 'Niedrig',
};

export function RoadmapCardRegistry({ onDueCountChange }: { onDueCountChange?: (count: number) => void }) {
  const [snapshot, setSnapshot] = useState<RoadmapCardSnapshot | null>(null);
  const [loading, setLoading] = useState(true);
  const [mutating, setMutating] = useState<string | null>(null);
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;

    fetch('/api/roadmap-cards', { cache: 'no-store' })
      .then(async (response) => {
        if (!response.ok) throw new Error('roadmap-cards-load-failed');
        return response.json() as Promise<RoadmapCardSnapshot>;
      })
      .then((nextSnapshot) => {
        if (!active) return;
        hydrateSnapshot(nextSnapshot);
      })
      .catch(() => {
        if (!active) return;
        setError('Roadmap-Karten sind gerade nicht lesbar.');
        onDueCountChange?.(0);
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [onDueCountChange]);

  const dueIds = useMemo(() => new Set((snapshot?.dueCards ?? []).map((card) => card.id)), [snapshot]);
  const cards = snapshot?.cards ?? [];

  function hydrateSnapshot(nextSnapshot: RoadmapCardSnapshot) {
    setSnapshot(nextSnapshot);
    setError(null);
    onDueCountChange?.(nextSnapshot.counts.due);
    setNotes((current) => {
      const next = { ...current };
      for (const card of nextSnapshot.cards) {
        next[card.id] = current[card.id] ?? card.note ?? '';
      }
      return next;
    });
  }

  async function updateCard(card: RoadmapCard, payload: { status?: RoadmapCardStatus; note?: string }) {
    setMutating(card.id);
    setError(null);

    try {
      const response = await fetch(`/api/roadmap-cards/${encodeURIComponent(card.id)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const result = await response.json() as RoadmapCardMutationResponse;
      if (!response.ok || !result.snapshot) throw new Error(result.error || 'roadmap-card-update-failed');
      hydrateSnapshot(result.snapshot);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Roadmap-Karte konnte nicht aktualisiert werden.');
    } finally {
      setMutating(null);
    }
  }

  async function enqueueCard(card: RoadmapCard) {
    setMutating(card.id);
    setError(null);

    try {
      const response = await fetch(`/api/roadmap-cards/${encodeURIComponent(card.id)}/enqueue`, {
        method: 'POST',
      });
      const result = await response.json() as RoadmapCardMutationResponse;
      if (!response.ok || !result.snapshot) throw new Error(result.error || 'roadmap-card-enqueue-failed');
      hydrateSnapshot(result.snapshot);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Roadmap-Karte konnte nicht in die Pipeline gelegt werden.');
    } finally {
      setMutating(null);
    }
  }

  return (
    <section className="panel tab-section roadmap-card-registry">
      <div className="hero-headline">
        <div>
          <span className="eyebrow">Roadmap Registry</span>
          <h3>Audit- und Research-Karten</h3>
        </div>
        <div className="operator-go-meta">
          <span className="status-pill tone-info">{snapshot?.counts.total ?? 0} Karten</span>
          <span className={`status-pill ${(snapshot?.counts.due ?? 0) > 0 ? 'tone-warning' : 'tone-ok'}`}>
            {snapshot?.counts.due ?? 0} fällig
          </span>
        </div>
      </div>

      <div className="roadmap-registry-meta">
        <span>Quelle: {snapshot?.storagePath ?? '.runtime/roadmap-cards/cards.json'}</span>
        <span>Operator-Go-Publisher: getrennt</span>
      </div>

      {error ? <div className="empty-state">{error}</div> : null}
      {loading ? <div className="empty-state">Roadmap-Karten werden geladen…</div> : null}
      {!loading && cards.length === 0 ? <div className="empty-state">Keine Roadmap-Karten gespeichert.</div> : null}

      <div className="roadmap-card-grid">
        {cards.map((card) => {
          const isMutating = mutating === card.id;
          const isDue = dueIds.has(card.id);

          return (
            <article key={card.id} className={`roadmap-card ${isDue ? 'is-due' : ''}`}>
              <div className="roadmap-card-topline">
                <span className={`review-chip review-${card.status}`}>{STATUS_LABELS[card.status]}</span>
                <span className={`priority-chip priority-${priorityClass(card.priority)}`}>
                  {PRIORITY_LABELS[card.priority] ?? card.priority}
                </span>
              </div>

              <div className="roadmap-card-title-row">
                <strong>{card.title}</strong>
                {card.dispatchRef ? <span className="mini-flag">{card.dispatchRef}</span> : null}
              </div>

              <p>{card.summary}</p>

              <div className="roadmap-card-facts">
                <div>
                  <span>Fälligkeit</span>
                  <strong>{formatDateTime(card.reviewAt)}</strong>
                </div>
                <div>
                  <span>Quelle</span>
                  <code>{card.sourcePath}</code>
                </div>
                <div>
                  <span>Gate / Risiko</span>
                  <strong>{card.gate}</strong>
                  <p>{card.risk}</p>
                </div>
                <div>
                  <span>Nächster Schritt</span>
                  <p>{card.nextStep}</p>
                </div>
              </div>

              <textarea
                className="roadmap-card-note"
                value={notes[card.id] ?? ''}
                placeholder="Notiz"
                onChange={(event) => setNotes((current) => ({ ...current, [card.id]: event.target.value }))}
              />

              <div className="operator-go-detail-actions">
                <button
                  type="button"
                  className="button-primary"
                  disabled={isMutating || card.status === 'queued' || card.status === 'done'}
                  onClick={() => enqueueCard(card)}
                >
                  In Pipeline legen
                </button>
                <button
                  type="button"
                  className="button-secondary"
                  disabled={isMutating || card.status === 'parked'}
                  onClick={() => updateCard(card, { status: 'parked' })}
                >
                  Parken
                </button>
                <button
                  type="button"
                  className="button-secondary"
                  disabled={isMutating || card.status === 'done'}
                  onClick={() => updateCard(card, { status: 'done' })}
                >
                  Erledigt
                </button>
                <button
                  type="button"
                  className="button-secondary"
                  disabled={isMutating}
                  onClick={() => updateCard(card, { note: notes[card.id] ?? '' })}
                >
                  Notiz speichern
                </button>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}

function priorityClass(priority: string): string {
  if (priority === 'critical') return 'kritisch';
  if (priority === 'high') return 'hoch';
  if (priority === 'low') return 'später';
  return 'normal';
}

function formatDateTime(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat('de-DE', {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(date);
}
