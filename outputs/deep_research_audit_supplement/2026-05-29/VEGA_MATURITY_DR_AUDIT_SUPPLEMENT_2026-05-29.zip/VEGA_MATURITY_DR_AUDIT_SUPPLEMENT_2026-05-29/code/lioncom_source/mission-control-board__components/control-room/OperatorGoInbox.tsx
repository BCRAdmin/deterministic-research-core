'use client';

import { useEffect, useMemo, useState } from 'react';

import type { OperatorGoPriority } from '@/lib/control-room/operator-go-inbox-data';
import type { OperatorGoResolvedItem, OperatorGoSnapshot } from '@/lib/services/operatorGoStateService';

type ReviewState = 'pending' | 'approved' | 'needs_changes';

const PRIORITY_ORDER: Record<OperatorGoPriority, number> = {
  kritisch: 0,
  hoch: 1,
  normal: 2,
  später: 3,
};

const PRIORITY_LABEL: Record<OperatorGoPriority, string> = {
  kritisch: 'Kritisch',
  hoch: 'Hoch',
  normal: 'Normal',
  später: 'Später',
};

export function OperatorGoInbox() {
  const [snapshot, setSnapshot] = useState<OperatorGoSnapshot | null>(null);
  const [loading, setLoading] = useState(true);
  const [mutatingId, setMutatingId] = useState<string | null>(null);
  const [selectedProjectId, setSelectedProjectId] = useState('');
  const [selectedItemId, setSelectedItemId] = useState('');
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [previewMode, setPreviewMode] = useState<'preview' | 'live' | 'local'>('preview');

  useEffect(() => {
    let active = true;

    fetch('/api/operator-go', { cache: 'no-store' })
      .then(async (response) => {
        if (!response.ok) throw new Error('operator-go-load-failed');
        return response.json() as Promise<OperatorGoSnapshot>;
      })
      .then((nextSnapshot) => {
        if (!active) return;
        hydrateSnapshot(nextSnapshot);
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, []);

  const projectItems = useMemo(
    () =>
      (snapshot?.pendingItems ?? [])
        .filter((item) => item.projectId === selectedProjectId)
        .sort((left, right) => {
          const priorityDiff = PRIORITY_ORDER[left.priority] - PRIORITY_ORDER[right.priority];
          if (priorityDiff !== 0) return priorityDiff;
          return left.title.localeCompare(right.title);
        }),
    [snapshot, selectedProjectId],
  );
  const projectApprovedItems = useMemo(
    () => (snapshot?.approvedItems ?? []).filter((item) => item.projectId === selectedProjectId),
    [snapshot, selectedProjectId],
  );
  const projectPublishedItems = useMemo(
    () => (snapshot?.publishedItems ?? []).filter((item) => item.projectId === selectedProjectId),
    [snapshot, selectedProjectId],
  );

  const projectAllItems = [...projectItems, ...projectApprovedItems, ...projectPublishedItems];
  const selectedItem = projectAllItems.find((item) => item.id === selectedItemId) ?? projectItems[0] ?? projectApprovedItems[0] ?? projectPublishedItems[0] ?? null;
  const selectedProject = snapshot?.projects.find((project) => project.id === selectedProjectId) ?? null;
  const approvedItems = snapshot?.approvedItems ?? [];
  const publishedItems = snapshot?.publishedItems ?? [];
  const previewUrl = selectedItem
    ? (previewMode === 'local'
      ? selectedItem.resolvedLocalPreviewUrl
      : previewMode === 'live'
        ? selectedItem.resolvedLiveUrl
        : selectedItem.resolvedPreviewUrl)
    : undefined;

  function hydrateSnapshot(nextSnapshot: OperatorGoSnapshot) {
    setSnapshot(nextSnapshot);
    setNotes((current) => {
      const next = { ...current };
      for (const item of [...nextSnapshot.pendingItems, ...nextSnapshot.approvedItems]) {
        next[item.id] = item.note ?? current[item.id] ?? '';
      }
      return next;
    });

    setSelectedProjectId((currentProjectId) => {
      const nextProjectId = nextSnapshot.projects.find((project) => project.id === currentProjectId)?.id
        ?? nextSnapshot.projects.find((project) => project.pendingCount > 0)?.id
        ?? nextSnapshot.projects.find((project) => project.approvedCount > 0)?.id
        ?? nextSnapshot.projects[0]?.id
        ?? '';

      const nextItems = [
        ...nextSnapshot.pendingItems.filter((item) => item.projectId === nextProjectId),
        ...nextSnapshot.approvedItems.filter((item) => item.projectId === nextProjectId),
        ...nextSnapshot.publishedItems.filter((item) => item.projectId === nextProjectId),
      ]
        .sort((left, right) => {
          const priorityDiff = PRIORITY_ORDER[left.priority] - PRIORITY_ORDER[right.priority];
          if (priorityDiff !== 0) return priorityDiff;
          return left.title.localeCompare(right.title);
        });

      setSelectedItemId((currentItemId) => nextItems.find((item) => item.id === currentItemId)?.id ?? nextItems[0]?.id ?? '');
      return nextProjectId;
    });
  }

  async function updateItem(action: 'approve' | 'request_changes' | 'save_note' | 'reset', itemId: string, note?: string) {
    setMutatingId(itemId);
    try {
      const response = await fetch('/api/operator-go', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, itemId, note }),
      });

      if (!response.ok) throw new Error('operator-go-update-failed');

      const payload = await response.json() as { snapshot: OperatorGoSnapshot };
      hydrateSnapshot(payload.snapshot);
    } finally {
      setMutatingId(null);
    }
  }

  return (
    <section className="panel tab-section operator-go-page">
      <div className="hero-headline">
        <div>
          <span className="eyebrow">Operator only</span>
          <h3>Operator Go Inbox</h3>
        </div>
      </div>

      <div className="operator-go-intro">
        <p className="detail">
          Nur fertig gebaute Dinge, die wirklich deine operative Zustimmung oder einen klaren Operator-Schritt brauchen.
          Kein Vivi-Claim-Rauschen, keine Rails, keine Hintergrundsysteme.
        </p>
        <div className="operator-go-meta">
          <span className="status-pill tone-info">Täglicher Batch: {snapshot?.batchTime ?? '12:00 Europe/Berlin'}</span>
          <span className="status-pill tone-warning">Nur 100 % freigabereife Punkte</span>
          <span className="status-pill tone-ok">{approvedItems.length} für Batch freigegeben</span>
          <span className="status-pill tone-info">{publishedItems.length} bereits veröffentlicht</span>
        </div>
        {snapshot?.health ? (
          <div className="operator-go-meta" style={{ marginTop: 10 }}>
            <span className={`status-pill ${snapshot.health.ok ? 'tone-ok' : 'tone-warning'}`}>
              {snapshot.health.ok ? 'Pipeline-Preflight ok' : 'Pipeline-Preflight blockiert'}
            </span>
            <span className="detail">{snapshot.health.summary}</span>
          </div>
        ) : null}
      </div>

      <div className="operator-go-toolbar">
        <div className="field project-select-field">
          <label htmlFor="operator-go-project">Projekt</label>
          <select
            id="operator-go-project"
            value={selectedProjectId}
            onChange={(event) => {
              const nextProjectId = event.target.value;
              setSelectedProjectId(nextProjectId);
              const nextItems = [
                ...((snapshot?.pendingItems ?? []).filter((item) => item.projectId === nextProjectId)),
                ...((snapshot?.approvedItems ?? []).filter((item) => item.projectId === nextProjectId)),
                ...((snapshot?.publishedItems ?? []).filter((item) => item.projectId === nextProjectId)),
              ]
                .sort((left, right) => {
                  const priorityDiff = PRIORITY_ORDER[left.priority] - PRIORITY_ORDER[right.priority];
                  if (priorityDiff !== 0) return priorityDiff;
                  return left.title.localeCompare(right.title);
                });
              setSelectedItemId(nextItems[0]?.id ?? '');
            }}
          >
            {(snapshot?.projects ?? []).map((project) => (
              <option key={project.id} value={project.id}>
                {project.label} ({project.pendingCount} offen / {project.approvedCount} geplant)
              </option>
            ))}
          </select>
        </div>
        {selectedProject ? <div className="operator-go-project-subtitle">{selectedProject.subtitle}</div> : null}
      </div>

      <div className="operator-go-layout">
        <aside className="operator-go-list panel">
          <div className="operator-go-list-header">
            <strong>Freigabepunkte</strong>
            <span>{projectItems.length}</span>
          </div>

          {loading ? (
            <div className="empty-state">Operator-Go-Inbox wird geladen…</div>
          ) : projectItems.length === 0 ? (
            <div className="empty-state">Für dieses Projekt liegt aktuell kein fertiger Go-Punkt vor.</div>
          ) : (
            <div className="operator-go-list-stack">
                {projectItems.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  className={`operator-go-card ${selectedItem?.id === item.id ? 'is-active' : ''}`}
                  onClick={() => setSelectedItemId(item.id)}
                >
                  <div className="operator-go-card-topline">
                    <span className={`priority-chip priority-${item.priority}`}>{PRIORITY_LABEL[item.priority]}</span>
                    <span className={`review-chip review-${item.reviewState}`}>{reviewStateLabel(item.reviewState)}</span>
                  </div>
                  <strong>{item.title}</strong>
                  <p>{item.operatorNeed}</p>
                  {item.scheduledFor ? <div className="detail">Geplant: {formatSchedule(item.scheduledFor)}</div> : null}
                  <div className="operator-go-flag-row">
                    {item.flags.map((flag) => (
                      <span key={flag} className="mini-flag">
                        {flag}
                      </span>
                    ))}
                  </div>
                </button>
              ))}
            </div>
          )}

          {approvedItems.length > 0 ? (
            <div className="operator-go-approved-queue">
              <div className="operator-go-list-header">
                <strong>Freigegeben für 12:00</strong>
                <span>{approvedItems.length}</span>
              </div>
              <div className="operator-go-approved-stack">
                {approvedItems.slice(0, 6).map((item) => (
                  <button
                    type="button"
                    key={item.id}
                    className={`approved-row approved-row-button ${selectedItem?.id === item.id ? 'is-active' : ''}`}
                    onClick={() => {
                      setSelectedProjectId(item.projectId);
                      setSelectedItemId(item.id);
                    }}
                  >
                    <div>
                      <span>{item.title}</span>
                      {item.lastPipelineError ? <div className="detail" style={{ color: '#b91c1c' }}>Fehler: {item.lastPipelineError}</div> : null}
                    </div>
                    <span className="detail">
                      {item.lastPipelineRunAt
                        ? `Letzter Lauf ${formatPublished(item.lastPipelineRunAt)}`
                        : item.scheduledFor
                          ? formatSchedule(item.scheduledFor)
                          : item.approvedAt
                            ? formatTimestamp(item.approvedAt)
                            : 'freigegeben'}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          ) : null}

          {publishedItems.length > 0 ? (
            <div className="operator-go-approved-queue">
              <div className="operator-go-list-header">
                <strong>Bereits veröffentlicht</strong>
                <span>{publishedItems.length}</span>
              </div>
              <div className="operator-go-approved-stack">
                {publishedItems.slice(0, 6).map((item) => (
                  <button
                    type="button"
                    key={item.id}
                    className={`approved-row approved-row-button ${selectedItem?.id === item.id ? 'is-active' : ''}`}
                    onClick={() => {
                      setSelectedProjectId(item.projectId);
                      setSelectedItemId(item.id);
                    }}
                  >
                    <span>{item.title}</span>
                    <span className="detail">{item.publishedAt ? formatPublished(item.publishedAt) : 'veröffentlicht'}</span>
                  </button>
                ))}
              </div>
            </div>
          ) : null}
        </aside>

        <section className="operator-go-detail panel">
          {selectedItem ? (
            <>
              <div className="operator-go-detail-header">
                <div>
                  <span className="eyebrow">{selectedItem.kind}</span>
                  <h4>{selectedItem.title}</h4>
                </div>
                <div className="operator-go-detail-actions">
                  {selectedItem.reviewState !== 'approved' ? (
                    <button
                      type="button"
                      className="button-primary"
                      disabled={mutatingId === selectedItem.id}
                      onClick={() => updateItem('approve', selectedItem.id)}
                    >
                      Ja – freigeben
                    </button>
                  ) : null}
                  <button
                    type="button"
                    className="button-secondary"
                    disabled={mutatingId === selectedItem.id}
                    onClick={() => updateItem('request_changes', selectedItem.id, notes[selectedItem.id] ?? '')}
                  >
                    Nein – Änderungen
                  </button>
                  {selectedItem.reviewState !== 'pending' ? (
                    <button
                      type="button"
                      className="button-secondary"
                      disabled={mutatingId === selectedItem.id}
                      onClick={() => updateItem('reset', selectedItem.id)}
                    >
                      Wieder offen
                    </button>
                  ) : null}
                </div>
              </div>

              <div className="operator-go-info-grid">
                <InfoBlock title="Warum wurde das gemacht?">{selectedItem.why}</InfoBlock>
                <InfoBlock title="Gewählte Endvariante">{selectedItem.chosenVariant}</InfoBlock>
                <InfoBlock title="Warum genau diese Variante?">{selectedItem.rationale}</InfoBlock>
                <InfoBlock title="Operator-Aktion">{selectedItem.operatorNeed}</InfoBlock>
                <InfoBlock title="Geplanter Slot">{selectedItem.scheduledFor ? formatSchedule(selectedItem.scheduledFor) : 'Noch nicht terminiert'}</InfoBlock>
                <InfoBlock title="Pipeline-Status">
                  {selectedItem.lastPipelineError
                    ? `Fehler beim letzten Lauf: ${selectedItem.lastPipelineError}`
                    : selectedItem.lastPipelineRunAt
                      ? `Letzter Pipeline-Lauf: ${formatPublished(selectedItem.lastPipelineRunAt)}`
                      : 'Noch kein Pipeline-Lauf erfolgt'}
                </InfoBlock>
                <InfoList title="Vorteile" items={selectedItem.benefits} />
                <InfoList title="Risiken" items={selectedItem.risks} />
                <InfoList title="Live-Auswirkung" items={selectedItem.liveImpact} />
                <InfoList title="Verifikation" items={selectedItem.verification} />
              </div>

              <div className="operator-go-supporting panel">
                <div className="operator-go-supporting-header">
                  <strong>Entscheidungsrelevante Belege</strong>
                  <span className="detail">{selectedItem.deployMode}</span>
                </div>
                {selectedItem.expectedLivePath ? (
                  <div className="supporting-path">
                    Geplanter Live-Pfad: <code>{selectedItem.expectedLivePath}</code>
                  </div>
                ) : null}
                <ul className="data-list compact">
                  {selectedItem.supportingPaths.map((path) => (
                    <li key={path}>
                      <div className="list-title">
                        <span>{path.split('/').slice(-2).join('/')}</span>
                      </div>
                      <div className="detail">{path}</div>
                    </li>
                  ))}
                </ul>
              </div>
            </>
          ) : (
            <div className="empty-state">Wähle links ein fertiges Go-Item aus.</div>
          )}
        </section>

        <aside className="operator-go-preview panel">
          {selectedItem ? (
            <>
              <div className="operator-go-preview-header">
                <div>
                  <span className="eyebrow">Preview</span>
                  <strong>Formatierte Endansicht</strong>
                </div>
                <span className="detail">Was später live gehen würde</span>
              </div>

              {selectedItem.reviewState === 'needs_changes' ? (
                <div className="operator-go-chat">
                  <div className="operator-go-chat-head">
                    <strong>Änderungs-Chat nur für dieses Item</strong>
                    <span className="detail">Anmerkungen bleiben an diesem Freigabepunkt hängen</span>
                  </div>
                  <div className="operator-go-chat-thread">
                    <div className="chat-bubble chat-system">
                      Dieser Unter-Chat gehört nur zu <strong>{selectedItem.title}</strong>. Hier kommen nur Korrekturen, Fragen oder Änderungswünsche zu diesem Punkt hinein.
                    </div>
                    {notes[selectedItem.id] ? <div className="chat-bubble chat-operator">{notes[selectedItem.id]}</div> : null}
                  </div>
                  <label className="field">
                    <span>Änderungen oder Fragen</span>
                    <textarea
                      rows={8}
                      value={notes[selectedItem.id] ?? ''}
                      onChange={(event) => setNotes((current) => ({ ...current, [selectedItem.id]: event.target.value }))}
                      placeholder="z. B. Titel schärfen, Variante B zeigen, noch ein Risiko erklären, vor Live-Go warten ..."
                    />
                  </label>
                  <div className="operator-go-detail-actions">
                    <button
                      type="button"
                      className="button-primary"
                      disabled={mutatingId === selectedItem.id}
                      onClick={() => updateItem('save_note', selectedItem.id, notes[selectedItem.id] ?? '')}
                    >
                      Notiz speichern
                    </button>
                    <button
                      type="button"
                      className="button-secondary"
                      disabled={mutatingId === selectedItem.id}
                      onClick={() => updateItem('request_changes', selectedItem.id, notes[selectedItem.id] ?? '')}
                    >
                      Änderung aktiv halten
                    </button>
                  </div>
                </div>
              ) : (
                <div className="operator-go-render-surface">
                  <div className="operator-go-detail-actions" style={{ marginBottom: 12 }}>
                    <button
                      type="button"
                      className={`button-secondary ${previewMode === 'preview' ? 'is-active' : ''}`}
                      onClick={() => setPreviewMode('preview')}
                    >
                      Vorschau
                    </button>
                    {selectedItem.resolvedLiveUrl ? (
                      <button
                        type="button"
                        className={`button-secondary ${previewMode === 'live' ? 'is-active' : ''}`}
                        onClick={() => setPreviewMode('live')}
                      >
                        Live
                      </button>
                    ) : null}
                    {selectedItem.resolvedLocalPreviewUrl ? (
                      <button
                        type="button"
                        className={`button-secondary ${previewMode === 'local' ? 'is-active' : ''}`}
                        onClick={() => setPreviewMode('local')}
                      >
                        Lokal
                      </button>
                    ) : null}
                  </div>
                  <div className="mock-browser-bar">
                    <span className="dot red" />
                    <span className="dot yellow" />
                    <span className="dot green" />
                    <div className="mock-browser-url">
                      {previewUrl ?? (selectedItem.expectedLivePath ? `materialbedarf-rechner.de${selectedItem.expectedLivePath}` : 'preview')}
                    </div>
                  </div>
                  {previewUrl ? (
                    <iframe
                      key={`${selectedItem.id}-${previewMode}-${previewUrl}`}
                      src={previewUrl}
                      title={`Webvorschau für ${selectedItem.title}`}
                      className="operator-go-preview-frame"
                    />
                  ) : null}
                  <div className="mock-preview-page">
                    <span className="eyebrow">{selectedItem.kind}</span>
                    <h5>{selectedItem.previewTitle}</h5>
                    <p className="mock-preview-lead">{selectedItem.previewLead}</p>
                    <div className="mock-preview-sections">
                      {selectedItem.previewSections.map((section) => (
                        <div key={section} className="mock-preview-block">
                          {section}
                        </div>
                      ))}
                    </div>
                    <div className="mock-preview-ctas">
                      {selectedItem.previewCtas.map((cta, index) => (
                        <span key={cta} className={`mock-cta ${index === 0 ? 'is-primary' : ''}`}>
                          {cta}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="empty-state">Keine Preview verfügbar.</div>
          )}
        </aside>
      </div>
    </section>
  );
}

function reviewStateLabel(state: ReviewState): string {
  if (state === 'approved') return 'Ja gesetzt';
  if (state === 'needs_changes') return 'Änderung offen';
  return 'Offen';
}

function formatTimestamp(value: string): string {
  try {
    return new Intl.DateTimeFormat('de-DE', {
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(value));
  } catch {
    return value;
  }
}

function formatSchedule(value: string): string {
  try {
    return new Intl.DateTimeFormat('de-DE', {
      weekday: 'short',
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(value));
  } catch {
    return value;
  }
}

function formatPublished(value: string): string {
  try {
    return new Intl.DateTimeFormat('de-DE', {
      weekday: 'short',
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(value));
  } catch {
    return value;
  }
}

function InfoBlock({ title, children }: { title: string; children: string }) {
  return (
    <div className="operator-go-info-card">
      <strong>{title}</strong>
      <p>{children}</p>
    </div>
  );
}

function InfoList({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="operator-go-info-card">
      <strong>{title}</strong>
      <ul>
        {items.map((item) => (
          <li key={item}>{item}</li>
        ))}
      </ul>
    </div>
  );
}
