'use client';

import { useMemo, useState } from 'react';
import { Loader2, Send } from 'lucide-react';

import { PriorityBadge } from '@/components/priority-badge';
import { StatusChip } from '@/components/status-chip';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { DispatchEvent, Priority } from '@/lib/types';
import { useControlPlaneStore } from '@/store/control-plane-store';

const taskTypes = ['Mission', 'Research', 'Code', 'Repair', 'Verification', 'Follow-up'] as const;
const targetModes = ['Vivi zuerst', 'Direkt an Vega', 'Vivi → Vega Handoff', 'Nur Review'] as const;
const priorities: Priority[] = ['low', 'normal', 'high', 'critical'];
const runtimes = ['Local', 'Cloud', 'Auto'] as const;

type TaskType = (typeof taskTypes)[number];
type TargetMode = (typeof targetModes)[number];
type RuntimeContext = (typeof runtimes)[number];

interface DispatchResponse {
  ok?: boolean;
  event?: DispatchEvent;
  reference?: string;
  routes?: Array<{
    rail: string;
    target: 'vivi' | 'vega' | 'bridge';
    status: string;
    reference: string;
  }>;
  operatorSummary?: string;
  error?: string;
}

const taskTypeLabels: Record<TaskType, string> = {
  Code: 'Code',
  'Follow-up': 'Nachfassen',
  Mission: 'Mission',
  Repair: 'Reparatur',
  Research: 'Recherche',
  Verification: 'Verifikation',
};
const targetModeLabels: Record<TargetMode, string> = {
  'Direkt an Vega': 'Direkt an Vega',
  'Nur Review': 'Nur Prüfung',
  'Vivi zuerst': 'Vivi zuerst',
  'Vivi → Vega Handoff': 'Vivi → Vega Übergabe',
};
const runtimeLabels: Record<RuntimeContext, string> = {
  Auto: 'Automatisch',
  Cloud: 'Cloud',
  Local: 'Lokal',
};

function recommendedTarget(type: TaskType): TargetMode {
  if (type === 'Code' || type === 'Repair' || type === 'Verification') return 'Direkt an Vega';
  if (type === 'Mission') return 'Vivi → Vega Handoff';
  return 'Vivi zuerst';
}

export function DispatchComposer({ initialEvents }: { initialEvents: DispatchEvent[] }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [taskType, setTaskType] = useState<TaskType>('Mission');
  const [targetMode, setTargetMode] = useState<TargetMode>('Vivi zuerst');
  const [priority, setPriority] = useState<Priority>('normal');
  const [runtime, setRuntime] = useState<RuntimeContext>('Local');
  const [attachments, setAttachments] = useState('');
  const [events, setEvents] = useState<DispatchEvent[]>(initialEvents);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [inlineError, setInlineError] = useState<string | null>(null);
  const [lastRouteSummary, setLastRouteSummary] = useState<string | null>(null);
  const openOperatorInfo = useControlPlaneStore((state) => state.openOperatorInfo);
  const recommendation = useMemo(() => recommendedTarget(taskType), [taskType]);

  async function submitDispatch() {
    const trimmedTitle = title.trim();
    const trimmedDescription = description.trim();

    if (!trimmedTitle && !trimmedDescription) {
      setInlineError('Bitte mindestens einen Auftragstitel oder Kontext eintragen.');
      return;
    }

    setIsSubmitting(true);
    setInlineError(null);
    setLastRouteSummary(null);

    try {
      const response = await fetch('/api/control-plane-v2/dispatch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: trimmedTitle,
          description: trimmedDescription,
          taskType,
          targetMode,
          priority,
          runtime,
          attachments,
        }),
      });
      const result = await response.json() as DispatchResponse;

      if (!response.ok || !result.ok || !result.event) {
        throw new Error(result.error || 'Dispatch konnte nicht geschrieben werden.');
      }

      setEvents((current) => [result.event!, ...current.filter((event) => event.id !== result.event!.id)]);
      setLastRouteSummary(result.operatorSummary ?? 'Dispatch wurde in die lokalen Rails geschrieben.');
      openOperatorInfo({
        title: 'Dispatch geschrieben',
        body: [
          `${result.event.title} wurde in die lokalen LIONCOM-Rails geschrieben.`,
          `Routing: ${targetModeLabels[targetMode]}. Priorität: ${priorityLabel(priority)}. Runtime: ${runtimeLabels[runtime]}.`,
          result.routes?.length ? `Zielrails: ${result.routes.map((route) => `${route.rail} (${route.status})`).join(', ')}.` : null,
          targetMode === 'Vivi → Vega Handoff' ? 'Vivi bekommt den Primärauftrag; Vega sieht einen wartenden Übergabe-Marker und soll erst nach Vivi-Kontext übernehmen.' : null,
        ].filter(Boolean).join(' '),
        tone: priority === 'critical' ? 'warning' : 'success',
        actionLabel: 'Verstanden',
      });
      setTitle('');
      setDescription('');
      setAttachments('');
    } catch (caught) {
      const message = caught instanceof Error ? caught.message : 'Dispatch konnte nicht geschrieben werden.';
      setInlineError(message);
      openOperatorInfo({
        title: 'Dispatch nicht geschrieben',
        body: `${message} Es wurde kein lokaler Rail-Eintrag erzeugt; bitte Auftrag prüfen und erneut senden.`,
        tone: 'warning',
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Card className="rounded-2xl p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="hud-title text-sm text-vega">Dispatch-Ersteller</div>
          <div className="mt-1 text-xs text-muted">Schreibt direkt in die lokalen LIONCOM-Rails. Keine externen Sends, kein Production-Deploy.</div>
        </div>
        <StatusChip label={`Empfehlung: ${targetModeLabels[recommendation]}`} tone={recommendation.includes('Vega') ? 'info' : 'success'} />
      </div>

      <div className="mt-4 grid gap-3">
        <Input placeholder="Auftragstitel" value={title} onChange={(event) => setTitle(event.target.value)} />
        <textarea
          className="min-h-32 w-full resize-none rounded-xl border border-border bg-cpbg/50 px-3 py-3 text-sm text-text outline-none transition placeholder:text-muted/70 focus:border-strong focus:ring-2 focus:ring-[rgba(98,196,255,0.30)]"
          placeholder="Beschreibung / Kontext"
          value={description}
          onChange={(event) => setDescription(event.target.value)}
        />
        <div className="grid gap-3 md:grid-cols-2">
          <Select
            value={taskType}
            onValueChange={(value) => {
              const next = taskTypes.find((item) => item === value) ?? 'Mission';
              setTaskType(next);
              setTargetMode(recommendedTarget(next));
            }}
          >
            <SelectTrigger><SelectValue placeholder="Auftragstyp" /></SelectTrigger>
            <SelectContent>{taskTypes.map((item) => <SelectItem key={item} value={item}>{taskTypeLabels[item]}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={targetMode} onValueChange={(value) => setTargetMode(targetModes.find((item) => item === value) ?? 'Vivi zuerst')}>
            <SelectTrigger><SelectValue placeholder="Zielmodus" /></SelectTrigger>
            <SelectContent>{targetModes.map((item) => <SelectItem key={item} value={item}>{targetModeLabels[item]}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={priority} onValueChange={(value) => setPriority(priorities.find((item) => item === value) ?? 'normal')}>
            <SelectTrigger><SelectValue placeholder="Priorität" /></SelectTrigger>
            <SelectContent>{priorities.map((item) => <SelectItem key={item} value={item}>{priorityLabel(item)}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={runtime} onValueChange={(value) => setRuntime(runtimes.find((item) => item === value) ?? 'Local')}>
            <SelectTrigger><SelectValue placeholder="Runtime-Kontext" /></SelectTrigger>
            <SelectContent>{runtimes.map((item) => <SelectItem key={item} value={item}>{runtimeLabels[item]}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <Input
          placeholder="Anhänge / Links vormerken"
          value={attachments}
          onChange={(event) => setAttachments(event.target.value)}
        />
        {inlineError ? <div className="rounded-xl border border-warning/35 bg-warning/10 px-3 py-2 text-sm text-warning">{inlineError}</div> : null}
        {lastRouteSummary ? <div className="rounded-xl border border-vivi/25 bg-vivi-soft px-3 py-2 text-sm text-vivi">{lastRouteSummary}</div> : null}
        <Button variant="vega" className="w-full" onClick={() => void submitDispatch()} disabled={isSubmitting}>
          {isSubmitting ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
          Dispatch senden
        </Button>
      </div>

      <div className="mt-5">
        <div className="hud-label text-muted">Letzte Dispatch-Ereignisse</div>
        <div className="mt-3 space-y-2">
          {events.slice(0, 4).map((event) => (
            <div key={event.id} className="grid grid-cols-[60px_minmax(0,1fr)_112px_90px] items-center gap-3 rounded-xl border border-border bg-cpbg/30 p-3 text-sm">
              <span className="font-mono text-xs text-muted">{event.time}</span>
              <span className="truncate text-text">{event.title}</span>
              <PriorityBadge priority={event.priority} />
              <span className="text-right text-muted">{statusLabel(event.status)}</span>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
}

function priorityLabel(priority: Priority): string {
  if (priority === 'critical') return 'Kritisch';
  if (priority === 'high') return 'Hoch';
  if (priority === 'low') return 'Niedrig';
  return 'Normal';
}

function statusLabel(status: string): string {
  const normalized = status.toLowerCase();
  if (normalized.includes('accepted')) return 'angenommen';
  if (normalized.includes('auto')) return 'automatisch';
  if (normalized.includes('block')) return 'blockiert';
  if (normalized.includes('done')) return 'erledigt';
  if (normalized.includes('handoff')) return 'Übergabe';
  if (normalized.includes('queue')) return 'wartend';
  return status;
}
