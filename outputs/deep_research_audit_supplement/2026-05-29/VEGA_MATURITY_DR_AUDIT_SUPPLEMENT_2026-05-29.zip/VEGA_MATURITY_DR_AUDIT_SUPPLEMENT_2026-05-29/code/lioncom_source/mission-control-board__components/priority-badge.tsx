import { cn } from '@/lib/cn';
import type { Priority } from '@/lib/types';

const priorityLabel: Record<Priority, string> = {
  low: 'Niedrig',
  normal: 'Normal',
  high: 'Hoch',
  critical: 'Kritisch',
};

const priorityClass: Record<Priority, string> = {
  low: 'border-border bg-elevated/40 text-muted',
  normal: 'border-vivi/30 bg-vivi-soft text-vivi',
  high: 'border-warning/40 bg-warning/10 text-warning',
  critical: 'border-danger/45 bg-danger/10 text-danger',
};

export function PriorityBadge({ priority, className }: { priority: Priority; className?: string }) {
  return (
    <span className={cn('inline-flex h-7 items-center rounded-lg border px-2.5 font-mono text-[0.68rem] font-semibold uppercase tracking-[0.13em]', priorityClass[priority], className)}>
      {priorityLabel[priority]}
    </span>
  );
}
