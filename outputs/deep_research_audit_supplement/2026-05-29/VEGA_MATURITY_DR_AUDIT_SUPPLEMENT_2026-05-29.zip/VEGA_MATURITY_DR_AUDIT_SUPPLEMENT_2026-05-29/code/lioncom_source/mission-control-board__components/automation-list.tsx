'use client';

import { useEffect, useMemo, useState } from 'react';
import { CalendarCheck, CheckCircle2, CirclePause, Play, Plus, RotateCw, Settings2, Square, Star, Trash2, Workflow } from 'lucide-react';

import { InfoButton } from '@/components/info-button';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/cn';
import type { AgentAccent, AutomationTask } from '@/lib/types';
import { useControlPlaneStore } from '@/store/control-plane-store';

const icons = [Workflow, CalendarCheck, RotateCw, Star, CheckCircle2, CirclePause];

type ManagedAutomationStatus = 'running' | 'stopped' | 'disabled' | 'archived';
type AutomationTemplateId = 'flight-pack' | 'vivi-health' | 'golden-baseline';

interface ManagedAutomation {
  id: string;
  label: string;
  name: string;
  status: ManagedAutomationStatus;
  schedule: string;
  detail: string;
  protected: boolean;
  canStart: boolean;
  canStop: boolean;
  canArchive: boolean;
}

interface AutomationTemplate {
  id: AutomationTemplateId;
  name: string;
  detail: string;
}

interface AutomationResponse {
  ok: boolean;
  message?: string;
  automations?: ManagedAutomation[];
  templates?: AutomationTemplate[];
}

export function AutomationList({ tasks, accent }: { tasks: AutomationTask[]; accent: AgentAccent }) {
  const openOperatorInfo = useControlPlaneStore((state) => state.openOperatorInfo);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [managed, setManaged] = useState<ManagedAutomation[]>([]);
  const [templates, setTemplates] = useState<AutomationTemplate[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const activeCount = useMemo(() => managed.filter((item) => item.status === 'running').length, [managed]);
  const selectedTemplate = templates[0]?.id ?? 'flight-pack';

  useEffect(() => {
    if (!settingsOpen) return;
    void loadAutomations();
  }, [settingsOpen]);

  async function loadAutomations() {
    setBusy('refresh');
    setError(null);
    try {
      const response = await fetch('/api/control-plane-v2/automations', { cache: 'no-store' });
      const payload = (await response.json()) as AutomationResponse;
      if (!response.ok || !payload.ok) throw new Error(payload.message ?? `HTTP ${response.status}`);
      setManaged(payload.automations ?? []);
      setTemplates(payload.templates ?? []);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Automationen konnten nicht geladen werden.';
      setError(message);
      openOperatorInfo({
        title: 'Automation-Konsole nicht geladen',
        body: message,
        tone: 'warning',
      });
    } finally {
      setBusy(null);
    }
  }

  async function runAutomationAction(action: 'start' | 'stop' | 'archive' | 'create', label?: string, template: AutomationTemplateId = selectedTemplate) {
    const key = `${action}:${label ?? template}`;
    setBusy(key);
    setError(null);
    try {
      const response = await fetch('/api/control-plane-v2/automations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, label, template }),
      });
      const payload = (await response.json()) as AutomationResponse;
      if (!response.ok || !payload.ok) throw new Error(payload.message ?? `HTTP ${response.status}`);
      setManaged(payload.automations ?? []);
      openOperatorInfo({
        title: 'Automation aktualisiert',
        body: payload.message ?? 'Die lokale Automation-Konsole wurde aktualisiert.',
        tone: 'success',
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Automation-Aktion fehlgeschlagen.';
      setError(message);
      openOperatorInfo({
        title: 'Automation nicht geändert',
        body: message,
        tone: 'warning',
      });
    } finally {
      setBusy(null);
    }
  }

  return (
    <Card className="col-span-12 rounded-2xl xl:col-span-3">
      <CardHeader>
        <div>
          <CardTitle className={cn('text-sm', accent === 'vivi' ? 'text-vivi' : 'text-vega')}>
            {accent === 'vivi' ? 'Automatische Aufgaben' : 'Reparatur-Automationen'}
          </CardTitle>
          <CardDescription>{accent === 'vivi' ? 'Hintergrundprozesse' : 'Technische Hintergrundprozesse'}</CardDescription>
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        {tasks.map((task, index) => {
          const Icon = icons[index % icons.length];
          const warning = task.status === 'warning';
          return (
            <div key={task.id} className="flex items-center gap-3 rounded-xl border border-border bg-cpbg/30 p-3">
              <div className={cn('grid size-9 shrink-0 place-items-center rounded-lg border', accent === 'vivi' ? 'border-vivi/35 bg-vivi-soft text-vivi' : 'border-vega/35 bg-vega-soft text-vega')}>
                <Icon className="size-4" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm text-text">{task.title}</div>
                <div className="truncate text-xs text-muted">{task.description}</div>
              </div>
              <div className={cn('hud-label', warning ? 'text-warning' : accent === 'vivi' ? 'text-vivi' : 'text-vega')}>
                {warning ? 'Check' : 'Aktiv'}
              </div>
            </div>
          );
        })}
        <Button variant={accent} className="mt-3 w-full" onClick={() => setSettingsOpen((value) => !value)}>
          <Settings2 className="size-4" />
          {settingsOpen ? 'Automation-Konsole schließen' : 'Automation-Einstellungen'}
        </Button>

        {settingsOpen ? (
          <div className="mt-3 space-y-3 rounded-2xl border border-strong bg-cpbg/45 p-3">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className={cn('hud-title text-sm', accent === 'vivi' ? 'text-vivi' : 'text-vega')}>Automation-Konsole</div>
                <div className="mt-1 text-xs leading-5 text-muted">
                  {activeCount} aktiv · {managed.length} lokale LaunchAgents · Entfernen archiviert nicht-destruktiv.
                </div>
              </div>
              <Button variant="outline" size="sm" onClick={() => void loadAutomations()} disabled={Boolean(busy)}>
                <RotateCw className="size-3.5" />
                Aktualisieren
              </Button>
            </div>

            <div className="grid gap-2">
              {managed.map((item) => (
                <div key={item.id} className="rounded-xl border border-border bg-elevated/35 p-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="truncate text-sm font-semibold text-text">{item.name}</div>
                      <div className="mt-1 truncate font-mono text-[0.68rem] text-muted">{item.label}</div>
                      <div className="mt-2 text-xs leading-5 text-muted">{item.schedule} · {item.detail}</div>
                    </div>
                    <span className={cn(
                      'hud-label rounded-lg border px-2 py-1',
                      item.status === 'running' ? 'border-vivi/35 bg-vivi-soft text-vivi' : item.status === 'archived' ? 'border-border bg-cpbg/55 text-muted' : 'border-warning/35 bg-warning/10 text-warning',
                    )}>
                      {statusLabel(item.status)}
                    </span>
                  </div>
                  <div className="mt-3 grid grid-cols-3 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={!item.canStart || Boolean(busy)}
                      onClick={() => void runAutomationAction('start', item.label)}
                    >
                      <Play className="size-3.5" />
                      Start
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={!item.canStop || Boolean(busy)}
                      onClick={() => void runAutomationAction('stop', item.label)}
                    >
                      <Square className="size-3.5" />
                      Stop
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={!item.canArchive || Boolean(busy)}
                      onClick={() => void runAutomationAction('archive', item.label)}
                    >
                      <Trash2 className="size-3.5" />
                      Entfernen
                    </Button>
                  </div>
                  {item.protected ? <div className="mt-2 text-[0.68rem] text-warning">Kernprozess: Stop/Entfernen ist gesperrt, damit V2 erreichbar bleibt.</div> : null}
                </div>
              ))}
            </div>

            <div className="rounded-xl border border-border bg-cpbg/35 p-3">
              <div className="hud-label text-muted">Neu anlegen</div>
              <div className="mt-2 grid gap-2">
                {templates.map((template) => (
                  <Button
                    key={template.id}
                    variant="outline"
                    className="h-auto justify-start px-3 py-2 text-left"
                    disabled={Boolean(busy)}
                    onClick={() => void runAutomationAction('create', undefined, template.id)}
                  >
                    <Plus className="size-3.5 shrink-0" />
                    <span className="min-w-0">
                      <span className="block truncate">{template.name}</span>
                      <span className="mt-0.5 block truncate text-xs text-muted">{template.detail}</span>
                    </span>
                  </Button>
                ))}
              </div>
            </div>

            {error ? <div className="rounded-xl border border-warning/35 bg-warning/10 p-3 text-xs leading-5 text-warning">{error}</div> : null}
          </div>
        ) : null}
      </CardContent>
    </Card>
  );
}

function statusLabel(status: ManagedAutomationStatus): string {
  if (status === 'running') return 'läuft';
  if (status === 'disabled') return 'pausiert';
  if (status === 'archived') return 'archiviert';
  return 'gestoppt';
}
