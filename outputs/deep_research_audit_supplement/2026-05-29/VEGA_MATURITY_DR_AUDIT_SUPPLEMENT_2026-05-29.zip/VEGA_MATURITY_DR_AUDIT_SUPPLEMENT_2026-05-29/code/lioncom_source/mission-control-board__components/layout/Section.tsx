// Section - Abschnitts-Container

import { ReactNode } from 'react';

interface SectionProps {
  title: string;
  children: ReactNode;
}

export function Section({ title, children }: SectionProps) {
  return (
    <section className="mb-6">
      <h2 className="text-lg font-semibold text-slate-800 mb-3 px-4">{title}</h2>
      {children}
    </section>
  );
}
