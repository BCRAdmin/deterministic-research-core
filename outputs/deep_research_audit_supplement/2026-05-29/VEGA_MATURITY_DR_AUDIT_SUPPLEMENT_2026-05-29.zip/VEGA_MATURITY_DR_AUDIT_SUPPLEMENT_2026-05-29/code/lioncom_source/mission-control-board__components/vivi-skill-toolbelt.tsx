'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { Activity, Boxes, FileText, ImageIcon, Loader2, PackageCheck, Play, Power, PowerOff, RefreshCw, Route, Search, ShieldCheck, Sparkles } from 'lucide-react';

import { StatusChip } from '@/components/status-chip';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/cn';
import type { Severity } from '@/lib/types';
import type { ViviSkill, ViviSkillRun, ViviSkillSnapshot } from '@/lib/vivi-skills/types';

interface SkillApiResponse {
  ok?: boolean;
  snapshot?: ViviSkillSnapshot;
  run?: ViviSkillRun;
  error?: string;
}

const quickSkillIds = [
  'lioncom.status.read',
  'vivi.model.route',
  'image.generate.local',
  'vivi.skill.propose',
  'vivi.skill-hub.local',
] as const;

const skillIcons: Record<string, typeof Activity> = {
  'lioncom.status.read': Activity,
  'vivi.model.route': Route,
  'image.generate.provider-check': ImageIcon,
  'image.generate.local': ImageIcon,
  'repo.inspect.readonly': PackageCheck,
  'browser.qa.inspect': ShieldCheck,
  'vega.handoff.create': Sparkles,
  'vivi.skill.propose': FileText,
  'vivi.skill-hub.local': Boxes,
  'vivi.skill-hub.remote-dry-run': ShieldCheck,
};

export function ViviSkillToolbelt({ className }: { className?: string }) {
  const [snapshot, setSnapshot] = useState<ViviSkillSnapshot | null>(null);
  const [selectedSkillId, setSelectedSkillId] = useState<string>('lioncom.status.read');
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [lastRun, setLastRun] = useState<ViviSkillRun | null>(null);
  const [query, setQuery] = useState('');

  const selectedSkill = useMemo(
    () => snapshot?.skills.find((skill) => skill.id === selectedSkillId) ?? snapshot?.skills[0] ?? null,
    [selectedSkillId, snapshot?.skills],
  );
  const quickSkills = useMemo(
    () => (query.trim()
      ? snapshot?.skills.filter((skill) => searchableSkill(skill).includes(query.trim().toLowerCase())).slice(0, 6) ?? []
      : quickSkillIds.map((skillId) => snapshot?.skills.find((skill) => skill.id === skillId)))
      .filter((skill): skill is ViviSkill => Boolean(skill)),
    [query, snapshot?.skills],
  );

  const loadSkills = useCallback(async (quiet = false) => {
    if (!quiet) setBusy('refresh');
    setError(null);
    try {
      const response = await fetch('/api/vivi-skills', { cache: 'no-store' });
      const nextSnapshot = await response.json() as ViviSkillSnapshot | { error?: string };
      if (!response.ok || !isSkillSnapshot(nextSnapshot)) {
        throw new Error(!isSkillSnapshot(nextSnapshot) && nextSnapshot.error ? nextSnapshot.error : 'Vivi-Skills konnten nicht geladen werden.');
      }
      setSnapshot(nextSnapshot);
      setLastRun((current) => current ?? nextSnapshot.latestRuns[0] ?? null);
      if (!selectedSkillId && nextSnapshot.skills[0]) setSelectedSkillId(nextSnapshot.skills[0].id);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Vivi-Skills konnten nicht geladen werden.');
    } finally {
      if (!quiet) setBusy(null);
    }
  }, [selectedSkillId]);

  useEffect(() => {
    void loadSkills(true);
    const timer = window.setInterval(() => void loadSkills(true), 20000);
    return () => window.clearInterval(timer);
  }, [loadSkills]);

  async function runSkill(skillId: string) {
    setBusy(`run:${skillId}`);
    setError(null);
    try {
      const response = await fetch('/api/vivi-skills/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          skillId,
          source: 'Vivi Skill Toolbelt',
          requestedBy: 'operator',
          operatorMessage: `Operator startete ${skillId} aus dem Vivi Skill Toolbelt.`,
        }),
      });
      const result = await response.json() as SkillApiResponse;
      if (!response.ok || result.error || !result.run) throw new Error(result.error || 'Skill-Lauf fehlgeschlagen.');
      setLastRun(result.run);
      await loadSkills(true);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Skill-Lauf fehlgeschlagen.');
    } finally {
      setBusy(null);
    }
  }

  async function toggleSkill(skill: ViviSkill) {
    setBusy(`toggle:${skill.id}`);
    setError(null);
    try {
      const response = await fetch(`/api/vivi-skills/${skill.enabled ? 'disable' : 'enable'}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ skillId: skill.id }),
      });
      const result = await response.json() as SkillApiResponse;
      if (!response.ok || result.error || !result.snapshot) throw new Error(result.error || 'Skill-Status konnte nicht geändert werden.');
      setSnapshot(result.snapshot);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Skill-Status konnte nicht geändert werden.');
    } finally {
      setBusy(null);
    }
  }

  return (
    <Card className={cn('col-span-12 rounded-2xl min-[1500px]:col-span-3', className)}>
      <CardHeader>
        <div>
          <CardTitle className="text-sm text-vivi">Vivi Skill-Toolbelt</CardTitle>
          <CardDescription>Lokale Fähigkeiten, Vorschläge & sichere Checks</CardDescription>
        </div>
        <Button size="sm" variant="outline" onClick={() => void loadSkills()} disabled={Boolean(busy)}>
          {busy === 'refresh' ? <Loader2 className="size-3.5 animate-spin" /> : <RefreshCw className="size-3.5" />}
          Prüfen
        </Button>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-3 gap-2">
          <Metric label="Skills" value={String(snapshot?.counts.total ?? '–')} tone="info" />
          <Metric label="Aktiv" value={String(snapshot?.counts.enabled ?? '–')} tone="success" />
          <Metric label="Vorschläge" value={String(snapshot?.counts.proposals ?? '0')} tone={snapshot?.counts.proposals ? 'warning' : 'success'} />
        </div>

        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-3.5 -translate-y-1/2 text-muted" />
          <Input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Skill suchen..."
            className="h-9 pl-9"
          />
        </div>

        <div className="grid gap-2">
          {quickSkills.map((skill) => {
            const Icon = skillIcons[skill.id] ?? Activity;
            return (
              <button
                key={skill.id}
                type="button"
                onClick={() => setSelectedSkillId(skill.id)}
                className={cn(
                  'grid grid-cols-[34px_minmax(0,1fr)_auto] items-center gap-3 rounded-xl border p-3 text-left transition',
                  selectedSkillId === skill.id ? 'border-vivi/45 bg-vivi-soft/80' : 'border-border bg-cpbg/30 hover:border-vivi/35',
                )}
              >
                <span className="grid size-8 place-items-center rounded-lg border border-vivi/30 bg-vivi-soft text-vivi">
                  <Icon className="size-4" />
                </span>
                <span className="min-w-0">
                  <span className="block truncate text-sm font-semibold text-text">{skill.shortName}</span>
                  <span className="mt-0.5 block truncate text-xs text-muted">{skill.operatorSummary}</span>
                </span>
                <StatusChip label={skill.health.label} tone={skill.health.tone} className="h-6 px-2" />
              </button>
            );
          })}
        </div>

        {selectedSkill ? (
          <div className="rounded-xl border border-border bg-cpbg/35 p-3">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="truncate text-sm font-semibold text-text">{selectedSkill.name}</div>
                <div className="mt-1 text-xs leading-5 text-muted">{selectedSkill.description}</div>
              </div>
              <StatusChip label={selectedSkill.enabled ? 'aktiv' : 'aus'} tone={selectedSkill.enabled ? 'success' : 'warning'} className="shrink-0" />
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <Button
                variant="vivi"
                size="sm"
                onClick={() => void runSkill(selectedSkill.id)}
                disabled={Boolean(busy) || !selectedSkill.enabled}
              >
                {busy === `run:${selectedSkill.id}` ? <Loader2 className="size-3.5 animate-spin" /> : <Play className="size-3.5" />}
                Lauf starten
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => void toggleSkill(selectedSkill)}
                disabled={Boolean(busy)}
              >
                {busy === `toggle:${selectedSkill.id}` ? <Loader2 className="size-3.5 animate-spin" /> : selectedSkill.enabled ? <PowerOff className="size-3.5" /> : <Power className="size-3.5" />}
                {selectedSkill.enabled ? 'Deaktivieren' : 'Aktivieren'}
              </Button>
            </div>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => void runSkill('vivi.skill-hub.local')}
                disabled={Boolean(busy)}
              >
                {busy === 'run:vivi.skill-hub.local' ? <Loader2 className="size-3.5 animate-spin" /> : <Boxes className="size-3.5" />}
                Hub prüfen
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => void runSkill('vivi.skill-hub.remote-dry-run')}
                disabled={Boolean(busy)}
              >
                {busy === 'run:vivi.skill-hub.remote-dry-run' ? <Loader2 className="size-3.5 animate-spin" /> : <ShieldCheck className="size-3.5" />}
                Dry-Run
              </Button>
            </div>
            <div className="mt-3 rounded-lg border border-border bg-cpbg/45 px-3 py-2 text-xs leading-5 text-muted">
              {selectedSkill.safeUse}
            </div>
          </div>
        ) : (
          <div className="rounded-xl border border-dashed border-border p-4 text-sm text-muted">
            Skill-Katalog wird geladen.
          </div>
        )}

        {lastRun ? (
          <div className="rounded-xl border border-border bg-cpbg/35 p-3">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="hud-label text-muted">Letzter Skill-Lauf</div>
                <div className="mt-2 text-sm font-semibold text-text">{lastRun.summary}</div>
              </div>
              <StatusChip label={runLabel(lastRun.status)} tone={lastRun.tone} className="shrink-0" />
            </div>
            <div className="mt-2 line-clamp-4 text-xs leading-5 text-muted">{lastRun.detail}</div>
            <div className="mt-2 rounded-lg border border-border bg-cpbg/45 px-3 py-2 text-xs leading-5 text-muted">
              Nächster Schritt: {lastRun.nextAction}
            </div>
            {lastRun.artifacts.length ? (
              <div className="mt-2 space-y-1 rounded-lg border border-border bg-cpbg/45 px-3 py-2 text-xs leading-5 text-muted">
                {lastRun.artifacts.slice(0, 3).map((artifact) => (
                  <div key={`${artifact.label}-${artifact.value}`} className="min-w-0">
                    <span className="text-text/85">{operatorArtifactLabel(artifact.label)}:</span>{' '}
                    <span className="break-words">{operatorArtifactValue(artifact.value)}</span>
                  </div>
                ))}
              </div>
            ) : null}
          </div>
        ) : (
          <div className="rounded-xl border border-border bg-cpbg/30 p-3 text-xs leading-5 text-muted">
            Noch kein Skill-Lauf in dieser Runtime. Starte einen sicheren Check oben.
          </div>
        )}

        {snapshot?.latestProposals?.length ? (
          <div className="rounded-xl border border-border bg-cpbg/35 p-3">
            <div className="hud-label text-muted">Aktuelle Skill-Vorschläge</div>
            <div className="mt-2 space-y-2">
              {snapshot.latestProposals.slice(0, 2).map((proposal) => (
                <div key={proposal.id} className="rounded-lg border border-border bg-cpbg/45 px-3 py-2">
                  <div className="truncate text-xs font-semibold text-text">{proposal.title}</div>
                  <div className="mt-1 text-[11px] uppercase tracking-[0.18em] text-vega">{proposal.requestedCapability}</div>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        {error ? <div className="rounded-xl border border-danger/35 bg-danger/10 px-3 py-2 text-sm text-danger">{error}</div> : null}
      </CardContent>
    </Card>
  );
}

function Metric({ label, value, tone }: { label: string; value: string; tone: Severity }) {
  return (
    <div className="rounded-xl border border-border bg-cpbg/35 p-3">
      <div className="hud-label text-muted">{label}</div>
      <div className={cn('mt-2 text-2xl font-semibold', tone === 'success' ? 'text-vivi' : tone === 'warning' ? 'text-warning' : 'text-vega')}>
        {value}
      </div>
    </div>
  );
}

function runLabel(status: ViviSkillRun['status']): string {
  const labels: Record<ViviSkillRun['status'], string> = {
    blocked: 'blockiert',
    completed: 'ok',
    failed: 'fehler',
    'missing-provider': 'provider fehlt',
    proposal: 'vorschlag',
  };
  return labels[status];
}

function operatorArtifactLabel(label: string): string {
  const normalized = label.toLowerCase();
  if (normalized.includes('proposal')) return 'Skill-Vorschlag';
  if (normalized.includes('catalog') || normalized.includes('katalog')) return 'Skill-Katalog';
  if (normalized.includes('json')) return 'Lokales Datenpaket';
  return label;
}

function operatorArtifactValue(value: string): string {
  if (value.startsWith('/Users/') || value.startsWith('/private/')) {
    const fileName = value.split('/').filter(Boolean).at(-1) ?? 'lokale Datei';
    return `lokal aktualisiert (${fileName})`;
  }
  return value.replace(/\.jsonl?\b/gi, ' Datenpaket');
}

function searchableSkill(skill: ViviSkill): string {
  return [
    skill.id,
    skill.name,
    skill.shortName,
    skill.operatorSummary,
    skill.description,
    ...skill.tags,
  ].join(' ').toLowerCase();
}

function isSkillSnapshot(value: ViviSkillSnapshot | { error?: string }): value is ViviSkillSnapshot {
  return Boolean(value && 'skills' in value && Array.isArray(value.skills) && 'counts' in value && 'latestRuns' in value);
}
