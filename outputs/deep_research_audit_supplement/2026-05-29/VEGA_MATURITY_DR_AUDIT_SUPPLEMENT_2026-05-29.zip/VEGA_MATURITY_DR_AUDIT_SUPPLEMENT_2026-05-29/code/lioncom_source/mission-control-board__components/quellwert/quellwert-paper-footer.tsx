type Props = {
  className?: string;
};

export function QuellwertPaperFooter({ className }: Props) {
  return (
    <footer className={['qwp-footer', className].filter(Boolean).join(' ')} aria-label="Quellwert Footer">
      <div className="qwp-footer-brand" aria-label="Quellwert">
        <span className="qwp-footer-mark" aria-hidden="true">
          <svg viewBox="0 0 32 32" role="presentation">
            <path d="M6 2.5h8v27H6zM18 2.5h8v27h-8z" />
            <path d="M10 5.5v21M22 5.5v21M6 8h8M18 24h8M14 15h4" />
          </svg>
        </span>
        <span className="qwp-footer-word">Quellwert</span>
      </div>
      <p>Öffentliche Research-Notizen zu Unternehmen.</p>
      <nav aria-label="Quellwert Footer Navigation">
        <a href="/membership">Start</a>
        <a href="/membership/analysen">Analysen</a>
        <a href="/membership/methodik">Methodik</a>
        <a href="/membership/archiv">Archiv</a>
        <a href="/membership/verifier">Verifier</a>
        <a href="/membership/impressum">Impressum</a>
        <a href="/membership/datenschutz">Datenschutz</a>
        <a href="/membership/kontakt">Kontakt</a>
      </nav>
    </footer>
  );
}
