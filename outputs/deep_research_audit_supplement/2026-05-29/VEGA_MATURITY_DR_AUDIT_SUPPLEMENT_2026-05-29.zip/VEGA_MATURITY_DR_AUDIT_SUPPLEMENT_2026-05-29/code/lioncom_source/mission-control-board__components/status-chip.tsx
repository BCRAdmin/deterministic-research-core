import { cn } from '@/lib/cn';
import type { Severity } from '@/lib/types';

const toneClass: Record<Severity | 'neutral', string> = {
  success: 'border-vivi/35 bg-vivi-soft text-vivi',
  info: 'border-vega/35 bg-vega-soft text-vega',
  warning: 'border-warning/40 bg-warning/10 text-warning',
  critical: 'border-danger/45 bg-danger/10 text-danger',
  neutral: 'border-border bg-elevated/45 text-muted',
};

export function StatusChip({ label, tone = 'neutral', className }: { label: string; tone?: Severity | 'neutral'; className?: string }) {
  return (
    <span className={cn('inline-flex h-7 items-center rounded-lg border px-2.5 font-mono text-[0.68rem] font-semibold uppercase tracking-[0.13em]', toneClass[tone], className)}>
      {localizeChipLabel(label)}
    </span>
  );
}

function localizeChipLabel(label: string): string {
  const labels: Record<string, string> = {
    active: 'aktiv',
    attention: 'achtung',
    blocked: 'blockiert',
    busy: 'beschäftigt',
    critical: 'kritisch',
    done: 'erledigt',
    error: 'fehler',
    fallback: 'fallback',
    fresh: 'frisch',
    healthy: 'stabil',
    high: 'hoch',
    info: 'info',
    low: 'niedrig',
    normal: 'normal',
    online: 'online',
    open: 'offen',
    planning: 'planung',
    queued: 'wartend',
    ready: 'bereit',
    return: 'rückgabe',
    stale: 'veraltet',
    success: 'ok',
    watching: 'beobachtet',
    warning: 'warnung',
  };

  return labels[label.toLowerCase()] ?? label;
}
