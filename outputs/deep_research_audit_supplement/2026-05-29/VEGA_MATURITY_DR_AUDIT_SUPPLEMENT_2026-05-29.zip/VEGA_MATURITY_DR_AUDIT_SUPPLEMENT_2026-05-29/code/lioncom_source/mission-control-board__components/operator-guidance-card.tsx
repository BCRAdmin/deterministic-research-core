import { ArrowRight, CheckCircle2 } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

const guidance = [
  'Neue Missionen über die Einsatz-Brücke senden',
  'Vivi für Planung, Routing und Aufnahme verwenden',
  'Vega für Code, Debugging und Verifikation verwenden',
  'Kritische Claims vor Eskalation prüfen',
];

export function OperatorGuidanceCard({ onDispatch }: { onDispatch?: () => void }) {
  return (
    <Card className="flex h-full flex-col rounded-2xl p-4">
      <div className="hud-title text-sm text-vega">Operator-Hinweise</div>
      <div className="mt-4 space-y-3">
        {guidance.map((item) => (
          <div key={item} className="flex items-start gap-3 rounded-xl border border-border bg-cpbg/30 p-3 text-sm text-text">
            <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-vivi" />
            <span>{item}</span>
          </div>
        ))}
      </div>
      <div className="mt-auto pt-4">
        <Button variant="vega" className="w-full" onClick={onDispatch}>
          Neuen Einsatz erstellen
          <ArrowRight className="size-4" />
        </Button>
      </div>
    </Card>
  );
}
