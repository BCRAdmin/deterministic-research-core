'use client';

import { useState } from 'react';
import { Activity, Cloud, DatabaseZap, GitBranch, RadioTower, RotateCw } from 'lucide-react';

import { AlertTable } from '@/components/alert-table';
import { InfoButton } from '@/components/info-button';
import { StatusChip } from '@/components/status-chip';
import { TelemetryChartCard } from '@/components/telemetry-chart-card';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useControlPlaneData } from '@/components/use-control-plane-data';
import { cn } from '@/lib/cn';
import type { Agent, ControlPlaneLiveData, ControlPlaneView, GlobalStatus, Severity, TelemetrySignal } from '@/lib/types';
import { useControlPlaneStore } from '@/store/control-plane-store';

function HealthSummary({ agents, status, signals }: { agents: Agent[]; status: GlobalStatus; signals: TelemetrySignal[] }) {
  const vega = agents.find((agent) => agent.id === 'vega');
  const items = [
    [Activity, 'Systemzustand %', status.automationHealth, status.posture === 'ATTENTION' ? 'warning' : 'success'],
    [RotateCw, 'Vivi-Loop', localizeValue(status.loopHealth), isHealthyLabel(status.loopHealth) ? 'success' : 'warning'],
    [RotateCw, 'Vega-Loop', vega ? localizeValue(vega.status) : 'BEREIT', vega?.status === 'warning' ? 'warning' : 'info'],
    [RadioTower, 'Brückenlink', status.bridgeStatus, status.bridgeStatus === 'ONLINE' ? 'success' : 'warning'],
    [GitBranch, 'GitHub-Sync', localizeValue(status.syncStatus), 'info'],
    [Cloud, 'Automationsplaner', status.automationHealth, status.posture === 'ATTENTION' ? 'warning' : 'success'],
  ] as const;

  return (
    <div className="grid gap-3 md:grid-cols-3 min-[1500px]:grid-cols-6">
      {items.map(([Icon, label, value, tone]) => (
        <Card key={label} className="rounded-2xl p-4">
          <Icon className={cn('size-5', tone === 'success' ? 'text-vivi' : 'text-vega')} />
          <div className="hud-label mt-4 text-muted">{label}</div>
          <div className="mt-2 text-xl font-semibold text-text">{value}</div>
        </Card>
      ))}
    </div>
  );
}

function SignalCards({ status, signals }: { status: GlobalStatus; signals: TelemetrySignal[] }) {
  const cards = [
    ['Datenquelle', 'Alle Werte stammen aus dem lokalen LIONCOM-Live-Snapshot. Es ist dieselbe Datenbasis wie Übersicht, Missionen und Audit-Protokoll.'],
    ['Vivi-Signal', signals.find((signal) => signal.id === 'tel-loop')?.sourceLabel ?? 'Vivi-Runtime-Telemetrie'],
    ['Vega-Signal', 'Vega-spezifische Code- und Repo-Werte stehen in der Vega-Technikzelle; diese Telemetrie-Seite zeigt globale Systemsignale.'],
    ['Sync / Brücke', `Sync ${status.syncStatus}, Brückenlink ${status.bridgeStatus}.`],
    ['Watcher-Lage', `Watcher ${status.watcherPosture}, aktive Claims ${status.activeClaims}.`],
  ];
  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 min-[1500px]:grid-cols-5">
      {cards.map(([title, detail]) => (
        <Card key={title} className="rounded-2xl p-4">
          <DatabaseZap className="size-5 text-vega" />
          <div className="hud-title mt-4 text-sm text-vega">{title}</div>
          <div className="mt-2 text-xs leading-5 text-muted">{detail}</div>
        </Card>
      ))}
    </div>
  );
}

function MetricPathPanel({ agents, status, signals }: { agents: Agent[]; status: GlobalStatus; signals: TelemetrySignal[] }) {
  const vega = agents.find((agent) => agent.id === 'vega');
  const metricPaths: MetricPath[] = [
    {
      label: 'Live-Telemetrie',
      value: signals.find((signal) => signal.id === 'tel-loop')?.value ?? localizeValue(status.loopHealth),
      detail: 'Zeigt, ob Vivi-/Vega-Signale aus dem aktuellen lokalen Snapshot kommen oder nur aus Ersatzdaten stammen.',
      source: signals.find((signal) => signal.id === 'tel-loop')?.sourceLabel ?? 'Quelle: LIONCOM Live-Snapshot',
      gate: 'Remote-/Bridge-Aktivierung bleibt Operator-Gate.',
      nextStep: 'Bei Warnung zuerst Live-Sicht und Alertwege prüfen, danach erst Layout oder Kosmetik.',
      tone: isHealthyLabel(status.loopHealth) ? 'success' : 'warning',
    },
    {
      label: 'Gesundheitsmesh',
      value: status.automationHealth,
      detail: 'Bündelt Systemhaltung, Zeitplaner, Watcher und globale Warnlage.',
      source: 'Quelle: Control-Plane-Audit und lokale Runtime-Signale',
      gate: 'Externe Reparatur, Auth oder Public-Änderung bleibt Operator-Gate.',
      nextStep: 'Health-Check öffnen und nur lokale Verifier-Reparaturen automatisch ausführen.',
      tone: status.posture === 'ATTENTION' ? 'warning' : 'success',
    },
    {
      label: 'Automationsschiene',
      value: status.automationHealth,
      detail: 'Zeigt, ob Automationen sichtbar, gesund und nicht heimlich riskant sind.',
      source: 'Quelle: Automation-Risk-Registry und LIONCOM Runtime',
      gate: 'Automation erstellen, ändern, löschen oder scharf schalten braucht Operator-Go.',
      nextStep: 'Risiko sichtbar halten; nur lokale Verifier und Reports aktualisieren.',
      tone: status.posture === 'ATTENTION' ? 'warning' : 'info',
    },
    {
      label: 'Risikowert',
      value: status.posture,
      detail: 'Verdichtet kritische Alerts, Warteschlangendruck und blockierte Vertrauensspuren.',
      source: 'Quelle: Alerts, Wartung und Mission-/Warteschlangen-Snapshot',
      gate: 'Rote Risiken nicht wegformulieren; erst Evidence und Gate prüfen.',
      nextStep: 'Bei Achtung zuerst Alertwege lesen und den kleinsten lokalen Fix ableiten.',
      tone: status.posture === 'ATTENTION' ? 'critical' : status.posture === 'WARNING' ? 'warning' : 'success',
    },
    {
      label: 'Missionsstatus',
      value: String(status.activeMissions),
      detail: 'Zählt aktive Missionen und macht sichtbar, ob Arbeit wirklich in Bewegung ist.',
      source: 'Quelle: Work-Blocks, Claims und Mission-Rails',
      gate: 'Public/Production/Room16-Publish bleibt geschlossen, auch wenn Missionen grün wirken.',
      nextStep: 'Bei Stillstand Übergabe-Inbox oder Rückstau öffnen, nicht frei neue Scope-Arbeit beginnen.',
      tone: status.activeMissions > 0 ? 'success' : 'warning',
    },
    {
      label: 'Builder-Last',
      value: vega?.metrics.find((metric) => metric.id === 'code-tasks')?.value ?? String(status.openQueue),
      detail: 'Zeigt Arbeitsdruck in Code-, Reparatur-, Warteschlangen- und Prüferspuren.',
      source: 'Quelle: Vega-Technikzelle, Warteschlange und Arbeits-Engine',
      gate: 'Commit, Cleanup, Push und Löschung brauchen vorher Ownership-/Handoff-Prüfung.',
      nextStep: 'Bei hoher Last erst Verifier- und Dirt-Handoff-Karten priorisieren.',
      tone: status.openQueue > 20 ? 'warning' : 'info',
    },
  ];

  return (
    <Card className="rounded-2xl p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="hud-title text-sm text-vega">Kennzahlen-Wege</div>
          <p className="mt-1 max-w-3xl text-sm leading-6 text-muted">
            Jede Kernkennzahl hat eine Unteransicht mit Bedeutung, Quelle, Gate und nächstem Schritt.
          </p>
        </div>
        <StatusChip label={`${metricPaths.length} Unteransichten`} tone="info" />
      </div>
      <div className="mt-4 grid gap-3 md:grid-cols-2 min-[1500px]:grid-cols-3">
        {metricPaths.map((metric) => (
          <div key={metric.label} className="rounded-xl border border-border bg-cpbg/30 p-3">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="hud-label text-muted">{metric.label}</div>
                <div className="mt-2 text-xl font-semibold text-text">{metric.value}</div>
              </div>
              <StatusChip label={metric.tone === 'critical' ? 'Gate prüfen' : metric.tone === 'warning' ? 'prüfen' : 'klar'} tone={metric.tone} />
            </div>
            <p className="mt-2 line-clamp-2 text-xs leading-5 text-muted">{metric.detail}</p>
            <InfoButton
              className="mt-3 w-full justify-start"
              variant="outline"
              info={{
                title: `${metric.label} Unteransicht`,
                body: `${metric.detail} ${metric.source}. Gate: ${metric.gate} Nächster Schritt: ${metric.nextStep}`,
                tone: metric.tone,
              }}
            >
              Unteransicht öffnen
            </InfoButton>
          </div>
        ))}
      </div>
    </Card>
  );
}

function BuilderWorkshopPanel({ alerts, agents, status, onJump }: { alerts: { severity: Severity }[]; agents: Agent[]; status: GlobalStatus; onJump: (view: ControlPlaneView) => void }) {
  const vega = agents.find((agent) => agent.id === 'vega');
  const codeTasks = vega?.metrics.find((metric) => metric.id === 'code-tasks')?.value ?? String(status.openQueue);
  const failedOrCritical = alerts.filter((alert) => alert.severity === 'critical').length;
  const warningAlerts = alerts.filter((alert) => alert.severity === 'warning').length;
  const zones: WorkshopZone[] = [
    {
      label: 'Eingang',
      value: String(status.openQueue),
      detail: 'Neue Arbeit und unsortierte Eingänge',
      target: 'backlog',
      tone: status.openQueue > 20 ? 'warning' : 'info',
    },
    {
      label: 'Bauen',
      value: codeTasks,
      detail: 'Vega-Code-, Fix- und Strukturarbeit',
      target: 'vega',
      tone: 'info',
    },
    {
      label: 'Warteschlange',
      value: String(status.queueDepth),
      detail: 'Wartende Schritte und Claims',
      target: 'backlog',
      tone: status.queueDepth > 40 ? 'warning' : 'info',
    },
    {
      label: 'Reparatur',
      value: String(failedOrCritical + warningAlerts),
      detail: 'Alerts, Gates und Reparaturdruck',
      target: 'telemetry',
      tone: failedOrCritical > 0 ? 'critical' : warningAlerts > 0 ? 'warning' : 'success',
    },
    {
      label: 'Prüfung',
      value: status.syncStatus,
      detail: 'Build-, Visual- und Audit-Prüfung',
      target: 'audit',
      tone: isFreshLabel(status.syncStatus) ? 'success' : 'warning',
    },
    {
      label: 'Mission',
      value: String(status.activeMissions),
      detail: 'Aktive operative Arbeit',
      target: 'missions',
      tone: status.activeMissions > 0 ? 'success' : 'warning',
    },
  ];

  return (
    <Card className="rounded-2xl p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="hud-title text-sm text-vega">Builder-Werkstatt</div>
          <p className="mt-1 max-w-3xl text-sm leading-6 text-muted">
            Builder-Last wird als Arbeitsfläche gelesen: Eingang, Bauen, Warteschlange, Reparatur, Prüfung und Mission springen in die passende Sicht.
          </p>
        </div>
        <StatusChip label="Werkstatt" tone="info" />
      </div>
      <div className="mt-4 grid min-h-[280px] gap-3 md:grid-cols-3">
        {zones.map((zone) => (
          <button
            key={zone.label}
            type="button"
            onClick={() => onJump(zone.target)}
            className={cn(
              'group flex min-h-[120px] flex-col justify-between rounded-xl border bg-cpbg/30 p-4 text-left transition hover:-translate-y-0.5 hover:bg-elevated/60 focus:outline-none focus:ring-2 focus:ring-vega/40',
              zone.tone === 'critical'
                ? 'border-danger/45'
                : zone.tone === 'warning'
                  ? 'border-warning/45'
                  : zone.tone === 'success'
                    ? 'border-vivi/35'
                    : 'border-border',
            )}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="hud-label text-muted">{zone.label}</div>
              <StatusChip label={zone.tone === 'critical' ? 'Stop' : zone.tone === 'warning' ? 'prüfen' : 'öffnen'} tone={zone.tone} />
            </div>
            <div>
              <div className="mt-4 text-2xl font-semibold text-text">{zone.value}</div>
              <div className="mt-2 text-xs leading-5 text-muted">{zone.detail}</div>
              <div className="mt-3 text-xs font-semibold text-vega opacity-80 transition group-hover:opacity-100">Sicht öffnen</div>
            </div>
          </button>
        ))}
      </div>
    </Card>
  );
}

export function TelemetryPage() {
  const { alerts, agents, generatedAt, globalStatus, source, telemetrySignals } = useControlPlaneData();
  const openOperatorInfo = useControlPlaneStore((state) => state.openOperatorInfo);
  const setSelectedView = useControlPlaneStore((state) => state.setSelectedView);
  const setLiveData = useControlPlaneStore((state) => state.setLiveData);
  const setLiveState = useControlPlaneStore((state) => state.setLiveState);
  const [busyAction, setBusyAction] = useState<string | null>(null);
  const snapshotTime = new Intl.DateTimeFormat('de-DE', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  }).format(new Date(generatedAt));
  async function refreshMesh() {
    setBusyAction('refresh');
    setLiveState('loading');
    openOperatorInfo({
      title: 'Mesh wird aktualisiert',
      body: 'Ich ziehe den aktuellen lokalen LIONCOM-Control-Plane-Snapshot neu ein und aktualisiere danach Warteschlange, Claims, Telemetrie und Systemhaltung in der Oberfläche.',
      tone: 'info',
    });
    try {
      const response = await fetch('/api/control-plane-v2', { cache: 'no-store' });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = (await response.json()) as ControlPlaneLiveData;
      setLiveData(data);
      openOperatorInfo({
        title: 'Mesh aktualisiert',
        body: `Live-Snapshot wurde neu eingezogen. Quelle: ${data.source === 'live' ? 'LIONCOM Live-Daten' : 'Ersatzdaten'}, Warteschlangentiefe ${data.globalStatus.queueDepth}, aktive Claims ${data.globalStatus.activeClaims}, letztes Signal ${data.globalStatus.lastSignal}.`,
        tone: data.source === 'live' ? 'success' : 'warning',
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'unbekannter Fehler';
      setLiveState('error', message);
      openOperatorInfo({
        title: 'Mesh-Aktualisierung fehlgeschlagen',
        body: `Der Live-Snapshot konnte nicht neu geladen werden (${message}). Die Oberfläche behält den letzten bekannten Stand und markiert die Verbindung als prüfbedürftig.`,
        tone: 'warning',
      });
    } finally {
      setBusyAction(null);
    }
  }

  async function createSystemExport() {
    setBusyAction('export');
    openOperatorInfo({
      title: 'Systemexport läuft',
      body: 'LIONCOM erstellt gerade ein neues Control-Plane-Flight-Pack mit Snapshot, Audit, Loop-Status, Modellroute und Offline-Bericht. Der laufende Vivi-Loop wird dabei nicht gestoppt.',
      tone: 'info',
    });
    try {
      const response = await fetch('/api/control-plane-v2/flight-pack', { method: 'POST', cache: 'no-store' });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const payload = (await response.json()) as FlightPackResponse;
      openOperatorInfo({
        title: 'Systemexport erstellt',
        body: flightPackSummary(payload),
        tone: payload.ok ? 'success' : 'warning',
      });
    } catch (error) {
      openOperatorInfo({
        title: 'Systemexport nicht erstellt',
        body: `Das Flight-Pack konnte gerade nicht erzeugt werden (${error instanceof Error ? error.message : 'unbekannter Fehler'}). Bestehende Live-Daten bleiben unverändert sichtbar.`,
        tone: 'warning',
      });
    } finally {
      setBusyAction(null);
    }
  }

  async function runHealthCheck() {
    setBusyAction('health');
    openOperatorInfo({
      title: 'Health-Check läuft',
      body: 'Ich lese den aktuellen Systemaudit-Snapshot und fasse danach Score, prüfbedürftige Checks und die nächste sinnvolle Operator-Aktion zusammen.',
      tone: 'info',
    });
    try {
      const response = await fetch('/api/control-plane-v2/audit', { cache: 'no-store' });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const audit = (await response.json()) as AuditResponse;
      openOperatorInfo({
        title: 'Health-Check abgeschlossen',
        body: `Audit-Score ${audit.score}/100, Gesamtzustand ${localizeValue(audit.overall)}. ${audit.checks.filter((check) => check.severity !== 'ok').length} prüfbedürftige Checks. Nächster Hinweis: ${audit.nextActions[0] ?? 'Keine zusätzliche Operator-Aktion nötig.'}`,
        tone: audit.overall === 'ready' ? 'success' : audit.overall === 'warning' ? 'warning' : 'critical',
      });
    } catch (error) {
      openOperatorInfo({
        title: 'Health-Check fehlgeschlagen',
        body: `Der Audit-Snapshot konnte nicht gelesen werden (${error instanceof Error ? error.message : 'unbekannter Fehler'}). Bitte Live-Verbindung und lokalen Control-Plane-Prozess prüfen.`,
        tone: 'warning',
      });
    } finally {
      setBusyAction(null);
    }
  }

  const controlActions: TelemetryControlAction[] = [
    {
      label: 'Mesh aktualisieren',
      body: `Aktueller Snapshot: ${snapshotTime}, Quelle ${source === 'live' ? 'LIONCOM Live-Daten' : 'Ersatzdaten'}. Brückenlink ${globalStatus.bridgeStatus}, Sync ${globalStatus.syncStatus}. Empfehlung: bei Warnlage zuerst Warteschlangentiefe und Alarmtabelle prüfen, dann neu laden.`,
      tone: globalStatus.bridgeStatus === 'ONLINE' ? 'success' : 'warning',
      action: refreshMesh,
      busyKey: 'refresh',
    },
    {
      label: 'Live-Drilldown öffnen',
      body: `Sichtbare Signale: ${telemetrySignals.length}. Wichtigste Quellen: ${telemetrySignals.map((signal) => signal.sourceLabel.replace('Quelle: ', '')).join('; ')}. Vega-Code-Details bleiben separat in der Vega-Technikzelle.`,
      tone: 'info',
    },
    {
      label: 'Systemexport',
      body: `Export-Basis ist der aktuelle LIONCOM-Live-Snapshot mit Systemhaltung ${globalStatus.posture}, Warteschlangentiefe ${globalStatus.queueDepth}, aktiven Claims ${globalStatus.activeClaims} und ${alerts.length} Alarmen. Ergebnis ist ein lesbarer Offline- und Flugmodusbericht für den Operator.`,
      tone: 'info',
      action: createSystemExport,
      busyKey: 'export',
    },
    {
      label: 'Health-Check starten',
      body: `Aktuelle Health-Prüfung: Automationszustand ${globalStatus.automationHealth}, Watcher-Lage ${globalStatus.watcherPosture}, letztes Signal ${globalStatus.lastSignal}. ${alerts.length > 0 ? `${alerts.length} Alarme sollten zuerst geprüft werden.` : 'Keine sichtbaren Alarme im Snapshot.'}`,
      tone: alerts.length > 0 || globalStatus.posture !== 'STABIL' ? 'warning' : 'success',
      action: runHealthCheck,
      busyKey: 'health',
    },
  ];

  return (
    <div className="grid min-h-full grid-cols-12 gap-3">
      <Card className="col-span-12 rounded-2xl p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="hud-title text-3xl text-vega">TELEMETRIE // SYSTEMSIGNALE</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-muted">Globale LIONCOM-Systemsignale aus demselben Live-Snapshot wie V2. Vega-Code-Details bleiben in der Vega-Technikzelle getrennt.</p>
          </div>
          <StatusChip label={`Letztes Signal ${globalStatus.lastSignal}`} tone="info" />
        </div>
      </Card>
      <div className="col-span-12"><HealthSummary agents={agents} status={globalStatus} signals={telemetrySignals} /></div>
      <div className="col-span-12"><MetricPathPanel agents={agents} status={globalStatus} signals={telemetrySignals} /></div>
      <div className="col-span-12"><BuilderWorkshopPanel alerts={alerts} agents={agents} status={globalStatus} onJump={setSelectedView} /></div>
      <div className="col-span-12 grid gap-3 md:grid-cols-2 xl:grid-cols-3 min-[1500px]:grid-cols-5">
        {telemetrySignals.map((signal) => <TelemetryChartCard key={signal.id} signal={signal} />)}
      </div>
      <div className="col-span-12"><SignalCards status={globalStatus} signals={telemetrySignals} /></div>
      <div className="col-span-12 xl:col-span-9"><AlertTable alerts={alerts} /></div>
      <Card className="col-span-12 rounded-2xl p-4 xl:col-span-3">
        <div className="hud-title text-sm text-vega">Kontrollen</div>
        <div className="mt-4 grid gap-2">
          {controlActions.map(({ action, body, busyKey, label, tone }) => {
            const busy = busyAction === busyKey;
            if (action) {
              return (
                <Button key={label} variant="outline" className="justify-start" disabled={Boolean(busyAction)} onClick={() => void action()}>
                  {busy ? 'läuft ...' : label}
                </Button>
              );
            }

            return (
              <InfoButton
                key={label}
                variant="outline"
                className="justify-start"
                info={{
                  title: label,
                  body,
                  tone,
                }}
              >
                {label}
              </InfoButton>
            );
          })}
        </div>
      </Card>
    </div>
  );
}

interface FlightPackResponse {
  ok: boolean;
  pack?: {
    generatedAt?: string;
    markdownPath?: string;
    jsonPath?: string;
    summary?: string;
  } | null;
}

interface MetricPath {
  label: string;
  value: string;
  detail: string;
  source: string;
  gate: string;
  nextStep: string;
  tone: Severity;
}

interface WorkshopZone {
  label: string;
  value: string;
  detail: string;
  target: ControlPlaneView;
  tone: Severity;
}

interface TelemetryControlAction {
  label: string;
  body: string;
  tone: Severity;
  action?: () => Promise<void>;
  busyKey?: string;
}

interface AuditResponse {
  overall: 'ready' | 'warning' | 'blocked' | string;
  score: number;
  checks: Array<{
    severity: 'ok' | Severity | string;
  }>;
  nextActions: string[];
}

function flightPackSummary(payload: FlightPackResponse): string {
  const pack = payload.pack;
  if (!payload.ok || !pack) return 'Der Export konnte keinen neuen Operatorbericht erzeugen. Bitte Live-Verbindung und lokale Schreibrechte prüfen.';
  const generated = pack.generatedAt ? formatTelemetryTime(pack.generatedAt) : 'gerade eben';
  return `Flight-Pack wurde ${generated} erstellt. Offline-Bericht und technisches Datenpaket wurden im lokalen LIONCOM-Arbeitsbereich aktualisiert. Nutze es als Flugmodus-Snapshot, nicht als Ersatz für den laufenden Vivi-Loop.`;
}

function formatTelemetryTime(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat('de-DE', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }).format(date);
}

function localizeValue(value: string): string {
  if (value.toLowerCase() === 'ready') return 'BEREIT';
  if (value.toLowerCase() === 'blocked') return 'BLOCKIERT';
  if (value.toLowerCase() === 'warning') return 'WARNUNG';
  if (value.toLowerCase() === 'frisch') return 'FRISCH';
  if (value.toLowerCase() === 'fresh') return 'FRISCH';
  if (value.toLowerCase() === 'stabil') return 'STABIL';
  if (value.toLowerCase() === 'healthy') return 'STABIL';
  if (value.toLowerCase() === 'active') return 'AKTIV';
  if (value.toLowerCase() === 'busy') return 'BESCHÄFTIGT';
  if (value.toLowerCase() === 'ready') return 'BEREIT';
  if (value.toLowerCase() === 'warning') return 'WARNUNG';
  if (value.toLowerCase() === 'attention') return 'ACHTUNG';
  if (value.toLowerCase() === 'achtung') return 'ACHTUNG';
  return value.toUpperCase();
}

function isHealthyLabel(value: string): boolean {
  const normalized = value.toLowerCase();
  return normalized.includes('healthy') || normalized.includes('stabil') || normalized.includes('steady');
}

function isFreshLabel(value: string): boolean {
  const normalized = value.toLowerCase();
  return normalized === 'fresh' || normalized === 'frisch';
}
