import { ArrowRight } from 'lucide-react';

import { InfoButton } from '@/components/info-button';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/cn';
import type { ActivitySignal, AgentAccent } from '@/lib/types';

export function ActivityFeed({ signals, accent }: { signals: ActivitySignal[]; accent: AgentAccent }) {
  return (
    <Card className="col-span-12 rounded-2xl p-4">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-baseline gap-3">
          <div className={cn('hud-title text-sm', accent === 'vivi' ? 'text-vivi' : 'text-vega')}>Aktuelle Signale</div>
          <div className="text-xs text-muted">Aktivitätsstrom</div>
        </div>
        <div className="h-1 flex-1 rounded-full bg-elevated" />
      </div>
      <div className="mt-4 grid gap-2 xl:grid-cols-6">
        {signals.map((signal) => (
          <div key={signal.id} className="min-w-0 border-l border-border px-4 first:border-l-0">
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs text-muted">{signal.time}</span>
              <span className={cn('hud-label', accent === 'vivi' ? 'text-vivi' : 'text-vega')}>{signal.actor}</span>
            </div>
            <div className={cn('mt-2 line-clamp-2 min-h-8 text-xs font-semibold uppercase leading-4', accent === 'vivi' ? 'text-vivi' : 'text-vega')}>{signal.label}</div>
            <div className="mt-1 truncate text-xs text-muted">{signal.detail}</div>
          </div>
        ))}
        <div className="flex items-center justify-end border-l border-border px-4">
          <InfoButton variant="ghost" size="sm" info={{ title: 'Aktuelle Signale', body: 'Der Aktivitätsstrom öffnet eine chronologische Operator-Ansicht der wichtigsten Live-Signale. Die aktuelle Zeile bleibt als kompakter Überblick sichtbar.', tone: 'info' }}>
            Strom anzeigen
            <ArrowRight className="size-4" />
          </InfoButton>
        </div>
      </div>
    </Card>
  );
}
