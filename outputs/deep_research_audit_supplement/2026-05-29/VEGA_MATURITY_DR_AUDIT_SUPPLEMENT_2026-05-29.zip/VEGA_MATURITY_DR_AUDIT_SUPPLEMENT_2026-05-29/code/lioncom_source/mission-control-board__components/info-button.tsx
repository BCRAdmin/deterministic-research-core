'use client';

import { Button, type ButtonProps } from '@/components/ui/button';
import type { OperatorInfo } from '@/lib/types';
import { useControlPlaneStore } from '@/store/control-plane-store';

interface InfoButtonProps extends ButtonProps {
  info: OperatorInfo;
}

export function InfoButton({ info, onClick, children, ...props }: InfoButtonProps) {
  const openOperatorInfo = useControlPlaneStore((state) => state.openOperatorInfo);

  return (
    <Button
      {...props}
      onClick={(event) => {
        onClick?.(event);
        if (!event.defaultPrevented) openOperatorInfo(info);
      }}
    >
      {children}
    </Button>
  );
}
