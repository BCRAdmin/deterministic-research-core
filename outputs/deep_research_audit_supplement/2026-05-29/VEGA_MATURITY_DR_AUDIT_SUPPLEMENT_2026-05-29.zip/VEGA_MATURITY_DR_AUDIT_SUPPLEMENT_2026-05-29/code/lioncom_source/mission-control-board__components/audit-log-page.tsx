'use client';

import { AuditTimeline } from '@/components/audit-timeline';
import { StatusChip } from '@/components/status-chip';
import { Card } from '@/components/ui/card';
import { useControlPlaneData } from '@/components/use-control-plane-data';

export function AuditLogPage() {
  const { auditEvents } = useControlPlaneData();

  return (
    <div className="grid min-h-full grid-cols-12 gap-3">
      <Card className="col-span-12 rounded-2xl p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="hud-title text-3xl text-vega">AUDIT-PROTOKOLL // ENTSCHEIDUNGEN & AKTIVITÄTEN</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-muted">Nur lesbare Ereignisse, Entscheidungen, Dispatches, Übergaben, Automationsläufe und Systemaktionen.</p>
          </div>
          <StatusChip label="nur lesen" tone="info" />
        </div>
      </Card>
      <div className="col-span-12">
        <AuditTimeline events={auditEvents} />
      </div>
    </div>
  );
}
