'use client';

import { Loader2, Play, ShieldAlert, ShieldCheck } from 'lucide-react';
import { useState } from 'react';

import { StatusChip } from '@/components/status-chip';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useControlPlaneData } from '@/components/use-control-plane-data';
import { cn } from '@/lib/cn';
import type { ControlPlaneLiveData, Severity } from '@/lib/types';
import { useControlPlaneStore } from '@/store/control-plane-store';

interface StartResponse {
  ok: boolean;
  mode: 'launchagent' | 'direct-script' | 'unavailable';
  detail: string;
  snapshot?: ControlPlaneLiveData;
}

export function ViviLoopStatusCard({ className }: { className?: string }) {
  const { operatorLoopStatus } = useControlPlaneData();
  const openOperatorInfo = useControlPlaneStore((state) => state.openOperatorInfo);
  const setLiveData = useControlPlaneStore((state) => state.setLiveData);
  const [starting, setStarting] = useState(false);

  async function startLoop() {
    setStarting(true);
    try {
      const response = await fetch('/api/control-plane-v2/vivi-loop/start', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
      });
      const result = (await response.json()) as StartResponse;
      if (result.snapshot) {
        setLiveData(result.snapshot);
      }
      openOperatorInfo({
        title: result.ok ? 'Vivi wurde angestoßen' : 'Vivi konnte nicht gestartet werden',
        body: result.ok
          ? `${result.detail} Die Oberfläche aktualisiert den Live-Status automatisch. Wenn ein Quality-Gate blockiert, bleibt der aktuelle Claim offen und Vivi korrigiert denselben Bericht statt die Spur zu wechseln.`
          : `${result.detail} Bitte den lokalen LaunchAgent oder das Startskript prüfen, bevor neue unbeaufsichtigte Arbeit erwartet wird.`,
        tone: result.ok ? 'success' : 'warning',
        actionLabel: 'Verstanden',
      });
    } catch {
      openOperatorInfo({
        title: 'Vivi-Start nicht erreichbar',
        body: 'Die V2 konnte den lokalen Start-Endpunkt nicht erreichen. Die bestehenden Live-Daten bleiben sichtbar; bitte lokalen Server und LaunchAgent prüfen.',
        tone: 'warning',
        actionLabel: 'OK',
      });
    } finally {
      setStarting(false);
    }
  }

  function showDetails() {
    openOperatorInfo({
      title: operatorLoopStatus.title,
      body: [
        operatorLoopStatus.summary,
        operatorLoopStatus.detail,
        `Nächster sinnvoller Schritt: ${operatorLoopStatus.nextAction}`,
        operatorLoopStatus.taskTitle ? `Aktueller Auftrag: ${operatorLoopStatus.taskTitle}` : '',
        operatorLoopStatus.claimId ? `Claim: ${operatorLoopStatus.claimId}` : '',
        operatorLoopStatus.lastHeartbeat ? `Letztes Lebenszeichen: ${operatorLoopStatus.lastHeartbeat}` : '',
        operatorLoopStatus.modelProvider && operatorLoopStatus.modelName ? `Runtime: ${operatorLoopStatus.modelProvider} / ${operatorLoopStatus.modelName}` : '',
      ].filter(Boolean).join(' '),
      tone: operatorLoopStatus.tone,
      actionLabel: 'Verstanden',
    });
  }

  const blocked = operatorLoopStatus.state === 'blocked';
  const Icon = blocked ? ShieldAlert : ShieldCheck;

  return (
    <Card className={cn('rounded-2xl p-4', className)}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className={cn('hud-title text-sm', blocked ? 'text-warning' : 'text-vivi')}>Vivi Loop & Gate</div>
          <div className="mt-1 text-xs leading-5 text-muted">Operatorfreundlicher Status aus lokalem Runner und Quality-Gate.</div>
        </div>
        <StatusChip label={statusLabel(operatorLoopStatus.state)} tone={chipTone(operatorLoopStatus.tone)} />
      </div>

      <div className="mt-4 grid gap-3 md:grid-cols-[74px_minmax(0,1fr)]">
        <div className={cn('grid min-h-24 place-items-center rounded-xl border bg-cpbg/30', blocked ? 'border-warning/30 text-warning' : 'border-vivi/30 text-vivi')}>
          <Icon className="size-8" />
        </div>
        <div className="rounded-xl border border-border bg-cpbg/30 p-3">
          <div className="text-sm font-semibold text-text">{operatorLoopStatus.title}</div>
          <div className="mt-2 line-clamp-3 text-xs leading-5 text-muted">{operatorLoopStatus.summary}</div>
          <div className="mt-3 flex flex-wrap gap-2">
            <StatusChip label={operatorLoopStatus.qualityGate.label} tone={operatorLoopStatus.qualityGate.ok ? 'success' : 'warning'} />
            {operatorLoopStatus.modelProvider ? <StatusChip label={operatorLoopStatus.modelProvider} tone="info" /> : null}
          </div>
        </div>
      </div>

      <div className="mt-3 grid gap-2 text-xs md:grid-cols-2">
        <StatusLine label="Auftrag" value={operatorLoopStatus.taskTitle ?? 'kein aktiver Titel'} />
        <StatusLine label="Heartbeat" value={operatorLoopStatus.lastHeartbeat ?? 'nicht sichtbar'} />
      </div>

      <div className="mt-3 rounded-xl border border-border bg-cpbg/25 p-3 text-xs leading-5 text-muted">
        {operatorLoopStatus.nextAction}
      </div>

      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        <Button variant={blocked ? 'vega' : 'outline'} size="sm" onClick={() => void startLoop()} disabled={starting}>
          {starting ? <Loader2 className="size-3.5 animate-spin" /> : <Play className="size-3.5" />}
          {operatorLoopStatus.primaryActionLabel}
        </Button>
        <Button variant="outline" size="sm" onClick={showDetails}>
          Details anzeigen
        </Button>
      </div>
    </Card>
  );
}

function StatusLine({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-border bg-cpbg/25 p-3">
      <div className="hud-label text-muted">{label}</div>
      <div className="mt-1 truncate text-text">{value}</div>
    </div>
  );
}

function statusLabel(value: string): string {
  const labels: Record<string, string> = {
    blocked: 'Gate blockiert',
    busy: 'Beschäftigt',
    offline: 'Offline',
    ready: 'Bereit',
    running: 'Läuft',
    warning: 'Prüfen',
  };
  return labels[value] ?? value;
}

function chipTone(tone: Severity): 'info' | 'success' | 'warning' | 'critical' {
  return tone;
}
