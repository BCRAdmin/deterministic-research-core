'use client';

import { useEffect, useMemo, useState } from 'react';
import { Loader2, RefreshCw, ShieldCheck } from 'lucide-react';

import { StatusChip } from '@/components/status-chip';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

type AuditSeverity = 'ok' | 'warning' | 'critical';

interface AuditCheck {
  id: string;
  label: string;
  severity: AuditSeverity;
  summary: string;
  detail: string;
}

interface AuditSnapshot {
  generatedAt: string;
  overall: 'ready' | 'attention' | 'blocked';
  score: number;
  checks: AuditCheck[];
  nextActions: string[];
}

const severityTone: Record<AuditSeverity, 'success' | 'warning' | 'critical'> = {
  ok: 'success',
  warning: 'warning',
  critical: 'critical',
};

export function SystemAuditCard() {
  const [snapshot, setSnapshot] = useState<AuditSnapshot | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const visibleChecks = useMemo(() => snapshot?.checks.filter((check) => check.severity !== 'ok').slice(0, 4) ?? [], [snapshot]);
  const okCount = snapshot?.checks.filter((check) => check.severity === 'ok').length ?? 0;

  async function refreshAudit() {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/control-plane-v2/audit', { cache: 'no-store' });
      if (!response.ok) throw new Error(`Audit nicht erreichbar (${response.status})`);
      setSnapshot(await response.json() as AuditSnapshot);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Audit nicht erreichbar.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void refreshAudit();
    const timer = window.setInterval(() => void refreshAudit(), 60_000);
    return () => window.clearInterval(timer);
  }, []);

  return (
    <Card className="rounded-2xl p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="hud-title text-sm text-vivi">System-Audit</div>
          <div className="mt-1 text-xs leading-5 text-muted">V2, Vivi-Rails, Runtime und lokaler Startpfad.</div>
        </div>
        <StatusChip label={snapshot ? auditLabel(snapshot.overall) : 'Prüfung'} tone={snapshot ? auditTone(snapshot.overall) : 'neutral'} />
      </div>

      <div className="mt-4 grid grid-cols-[90px_minmax(0,1fr)] gap-3">
        <div className="grid place-items-center rounded-xl border border-border bg-cpbg/30 p-3">
          <ShieldCheck className="size-6 text-vivi" />
          <div className="mt-2 text-2xl font-semibold text-text">{snapshot?.score ?? '--'}</div>
          <div className="hud-label text-muted">Score</div>
        </div>
        <div className="rounded-xl border border-border bg-cpbg/30 p-3">
          <div className="text-sm text-text">{snapshot ? `${okCount}/${snapshot.checks.length} Checks grün` : 'Audit wird geladen'}</div>
          <div className="mt-2 text-xs leading-5 text-muted">
            {snapshot?.nextActions[0] ?? 'Prüfe Live-Snapshot, lokale Rails und Vivi-Startpfad.'}
          </div>
          {error ? <div className="mt-2 text-xs text-warning">{error}</div> : null}
        </div>
      </div>

      <div className="mt-3 space-y-2">
        {(visibleChecks.length > 0 ? visibleChecks : snapshot?.checks.slice(0, 3) ?? []).map((check) => (
          <div key={check.id} className="flex items-center justify-between gap-3 rounded-xl border border-border bg-cpbg/25 px-3 py-2">
            <div className="min-w-0">
              <div className="truncate text-sm text-text">{check.label}</div>
              <div className="truncate text-xs text-muted">{check.summary}</div>
            </div>
            <StatusChip label={check.severity === 'ok' ? 'ok' : check.severity} tone={severityTone[check.severity]} className="shrink-0" />
          </div>
        ))}
      </div>

      <Button variant="outline" size="sm" className="mt-3 w-full" onClick={() => void refreshAudit()} disabled={loading}>
        {loading ? <Loader2 className="size-3.5 animate-spin" /> : <RefreshCw className="size-3.5" />}
        Audit aktualisieren
      </Button>
    </Card>
  );
}

function auditLabel(value: AuditSnapshot['overall']): string {
  if (value === 'ready') return 'Bereit';
  if (value === 'attention') return 'Achtung';
  return 'Blockiert';
}

function auditTone(value: AuditSnapshot['overall']): 'success' | 'warning' | 'critical' {
  if (value === 'ready') return 'success';
  if (value === 'attention') return 'warning';
  return 'critical';
}
