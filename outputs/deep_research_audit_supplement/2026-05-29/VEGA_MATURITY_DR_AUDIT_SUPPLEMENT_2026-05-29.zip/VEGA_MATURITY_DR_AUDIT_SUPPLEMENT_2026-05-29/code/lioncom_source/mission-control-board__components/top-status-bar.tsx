'use client';

import { Bell, Grid2X2, Hexagon, Radio, ShieldCheck } from 'lucide-react';

import { useControlPlaneData } from '@/components/use-control-plane-data';
import { cn } from '@/lib/cn';
import { useControlPlaneStore } from '@/store/control-plane-store';

export function TopStatusBar() {
  const openOperatorInfo = useControlPlaneStore((state) => state.openOperatorInfo);
  const { activitySignals, generatedAt, globalStatus, missions, operatorLoopStatus, source } = useControlPlaneData();
  const statusChips = [
    ['Systemstatus', source === 'live' ? 'LIVE' : 'FALLBACK', source === 'live' ? 'vivi' : 'vega'],
    ['Betriebslage', postureLabel(globalStatus.watcherPosture), globalStatus.posture === 'STABIL' ? 'vivi' : 'vega'],
    ['Synchronisation', syncLabel(globalStatus.syncStatus), globalStatus.syncStatus.toLowerCase() === 'frisch' || globalStatus.syncStatus.toLowerCase() === 'fresh' ? 'vivi' : 'vega'],
    ['Brückenlink', globalStatus.bridgeStatus, globalStatus.bridgeStatus === 'ONLINE' ? 'vivi' : 'vega'],
    ['Risikostufe', globalStatus.posture === 'ATTENTION' ? 'HOCH' : globalStatus.posture === 'WARNING' ? 'MITTEL' : 'NIEDRIG', 'vega'],
  ] as const;
  const generatedLabel = new Intl.DateTimeFormat('de-DE', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  }).format(new Date(generatedAt));

  return (
    <header className="control-plane-v2-window-drag fixed left-sidebar right-0 top-0 z-[2] h-topbar border-b border-border bg-[rgba(3,10,17,0.9)] px-4 backdrop-blur-2xl">
      <div className="flex h-full items-center gap-4">
        <div className="flex min-w-[320px] items-center gap-3">
          <div className="grid size-11 place-items-center rounded-2xl border border-strong bg-vega-soft text-vega shadow-hud">
            <Hexagon className="size-6" />
          </div>
          <div>
            <div className="hud-title text-xl leading-none text-text">LIONCOM CONTROL PLANE</div>
            <div className="mt-1 text-xs text-muted">Gemeinsame Operations-Fläche für Vivi + Vega</div>
          </div>
        </div>

        <div className="control-plane-v2-drag-handle" aria-hidden="true">
          <span />
          <span />
          <span />
        </div>

        <div className="hidden min-w-0 flex-1 items-center gap-2 min-[1500px]:flex">
          {statusChips.map(([label, value, accent]) => (
            <div key={label} className="min-w-28 rounded-xl border border-border bg-elevated/55 px-4 py-2">
              <div className="hud-label text-muted">{label}</div>
              <div className={cn('mt-1 text-sm font-semibold', accent === 'vivi' ? 'text-vivi' : 'text-vega')}>{value}</div>
            </div>
          ))}
        </div>

        <div className="ml-auto flex items-center gap-3">
          <div className="hidden rounded-2xl border border-border bg-elevated/55 px-4 py-2 text-right md:block">
            <div className="font-mono text-xs text-text">{generatedLabel}</div>
            <div className="hud-label mt-1 text-muted">Operator: LIONCOM</div>
          </div>
          <button
            type="button"
            onClick={() => openOperatorInfo({
              title: 'Benachrichtigungen',
              body: `Live-Snapshot ${generatedLabel}: Systemhaltung ${globalStatus.posture}, offene Queue ${globalStatus.openQueue}, aktive Missionen ${globalStatus.activeMissions}. Vivi-Loop: ${operatorLoopStatus.title}. Nächster Schritt: ${operatorLoopStatus.nextAction} Letztes Signal: ${globalStatus.lastSignal}.`,
              tone: operatorLoopStatus.state === 'blocked' ? 'warning' : globalStatus.posture === 'STABIL' ? 'success' : 'warning',
              actionLabel: 'Lage verstanden',
            })}
            className="grid size-10 place-items-center rounded-2xl border border-border bg-elevated/55 text-muted transition hover:border-strong hover:text-text"
          >
            <Bell className="size-4" />
          </button>
          <button
            type="button"
            onClick={() => openOperatorInfo({
              title: 'Kontrollraster',
              body: `Die V2 nutzt gerade ${source === 'live' ? 'Live-Daten aus dem lokalen LIONCOM-Lagebild' : 'Fallback-Daten'}. Sichtbar sind ${missions.length} Missionen, ${activitySignals.length} aktuelle Signale und eine Queue-Tiefe von ${globalStatus.queueDepth}. Für echte Arbeit: Die Dispatch-Brücke erstellt neue Aufträge, Missionen zeigt den Verlauf, Telemetrie erklärt die Systemsignale.`,
              tone: 'info',
              actionLabel: 'OK',
            })}
            className="grid size-10 place-items-center rounded-2xl border border-border bg-elevated/55 text-muted transition hover:border-strong hover:text-text"
          >
            <Grid2X2 className="size-4" />
          </button>
          <button
            type="button"
            onClick={() => openOperatorInfo({
              title: 'System-Mesh',
              body: `Quelle: ${source === 'live' ? 'LIONCOM Live-Snapshot' : 'Fallback-Daten'}. Brückenlink ${globalStatus.bridgeStatus}, Sync ${syncLabel(globalStatus.syncStatus)}, Watcher-Lage ${postureLabel(globalStatus.watcherPosture)}, aktive Claims ${globalStatus.activeClaims}. Vivi Runtime: ${operatorLoopStatus.modelProvider ?? 'lokal'}${operatorLoopStatus.modelName ? ` / ${operatorLoopStatus.modelName}` : ''}. Modell- und Providerwahl bleibt bewusst im Vivi-Arbeitsraum.`,
              tone: globalStatus.bridgeStatus === 'ONLINE' ? 'success' : 'warning',
              actionLabel: 'Status schließen',
            })}
            className="hidden items-center gap-2 rounded-2xl border border-border bg-elevated/55 px-3 py-2 text-xs text-muted transition hover:border-strong hover:text-text 2xl:flex"
          >
            <ShieldCheck className="size-4 text-vivi" />
            <Radio className="size-4 text-vega" />
          </button>
        </div>
      </div>
    </header>
  );
}

function postureLabel(value: string): string {
  const normalized = value.toLowerCase();
  if (normalized.includes('attention')) return 'ACHTUNG';
  if (normalized.includes('achtung')) return 'ACHTUNG';
  if (normalized.includes('blocked')) return 'BLOCKIERT';
  if (normalized.includes('blockiert')) return 'BLOCKIERT';
  if (normalized.includes('stabil')) return 'STABIL';
  if (normalized.includes('steady')) return 'STABIL';
  return value.toUpperCase();
}

function syncLabel(value: string): string {
  if (value.toLowerCase() === 'fresh') return 'FRISCH';
  if (value.toLowerCase() === 'frisch') return 'FRISCH';
  if (value.toLowerCase() === 'stale') return 'VERALTET';
  if (value.toLowerCase() === 'veraltet') return 'VERALTET';
  return value.toUpperCase();
}
