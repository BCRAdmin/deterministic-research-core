'use client';

import { AlertTriangle, Clock3, Wrench, XCircle } from 'lucide-react';

import { BacklogList } from '@/components/backlog-list';
import { StatusChip } from '@/components/status-chip';
import { Card } from '@/components/ui/card';
import { useControlPlaneData } from '@/components/use-control-plane-data';
import { cn } from '@/lib/cn';
import type { BacklogItem } from '@/lib/types';

function BacklogSummary({ backlogItems }: { backlogItems: BacklogItem[] }) {
  const stale = backlogItems.filter((item) => item.status === 'stale').length;
  const repair = backlogItems.filter((item) => item.status === 'repair').length;
  const blocked = backlogItems.filter((item) => item.status === 'blocked').length;
  const summary = [
    [AlertTriangle, 'Offener Backlog', String(backlogItems.length), 'info'],
    [Clock3, 'Alte Claims', String(stale), 'warning'],
    [Wrench, 'Reparatursignale', String(repair), 'info'],
    [XCircle, 'Blockierte Items', String(blocked), 'warning'],
    [Clock3, 'Ältester Eintrag', '3h 40m', 'info'],
  ] as const;

  return (
    <div className="grid gap-3 md:grid-cols-5">
      {summary.map(([Icon, label, value, tone]) => (
        <Card key={label} className="rounded-2xl p-4">
          <Icon className={cn('size-5', tone === 'warning' ? 'text-warning' : 'text-vega')} />
          <div className="hud-label mt-4 text-muted">{label}</div>
          <div className="mt-2 flex items-center justify-between gap-3">
            <span className="text-2xl font-semibold text-text">{value}</span>
            <StatusChip label={tone} tone={tone} />
          </div>
        </Card>
      ))}
    </div>
  );
}

export function BacklogPage() {
  const { backlogItems } = useControlPlaneData();

  return (
    <div className="grid min-h-full grid-cols-12 gap-3">
      <Card className="col-span-12 rounded-2xl p-5">
        <h1 className="hud-title text-3xl text-vega">RÜCKSTAU // WARTESCHLANGEN & RESTARBEITEN</h1>
        <p className="mt-2 max-w-3xl text-sm leading-6 text-muted">Triage für offene Arbeit, Restarbeiten, Reparatursignale, alte Claims und ungeklärte Items. Jedes Item routet klar nach Vivi oder Vega.</p>
      </Card>
      <div className="col-span-12"><BacklogSummary backlogItems={backlogItems} /></div>
      <div className="col-span-12"><BacklogList items={backlogItems} /></div>
    </div>
  );
}
