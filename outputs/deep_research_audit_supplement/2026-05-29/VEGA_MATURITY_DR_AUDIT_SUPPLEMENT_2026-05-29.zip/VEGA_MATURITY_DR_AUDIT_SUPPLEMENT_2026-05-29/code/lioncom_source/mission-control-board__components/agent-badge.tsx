import { Bot, TerminalSquare } from 'lucide-react';

import { cn } from '@/lib/cn';
import type { AgentId } from '@/lib/types';

export function AgentBadge({ agentId, compact = false }: { agentId: AgentId; compact?: boolean }) {
  const Icon = agentId === 'vivi' ? Bot : TerminalSquare;
  return (
    <span
      className={cn(
        'inline-flex items-center gap-2 rounded-lg border font-mono text-[0.68rem] font-semibold uppercase tracking-[0.13em]',
        compact ? 'h-7 px-2' : 'h-8 px-3',
        agentId === 'vivi' ? 'border-vivi/35 bg-vivi-soft text-vivi' : 'border-vega/35 bg-vega-soft text-vega',
      )}
    >
      <Icon className="size-3.5" />
      {agentId === 'vivi' ? 'Vivi' : 'Vega'}
    </span>
  );
}
