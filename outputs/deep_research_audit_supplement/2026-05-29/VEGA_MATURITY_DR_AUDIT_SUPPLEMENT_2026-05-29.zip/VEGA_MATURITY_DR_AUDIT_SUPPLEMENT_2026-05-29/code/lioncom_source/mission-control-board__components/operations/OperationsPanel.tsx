// OperationsPanel - Anzeige fuer Daily/Nightly/Backup

import type { MappedOperations } from '@/lib/mappers/operationsMapper';

interface OperationsPanelProps {
  operations: MappedOperations;
}

const statusLabels = {
  scheduled: 'Geplant',
  completed: 'Abgeschlossen',
  running: 'Läuft',
  failed: 'Fehler',
  unknown: 'Unbekannt'
};

export function OperationsPanel({ operations }: OperationsPanelProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 px-4">
      <OperationCard
        name="Morning Briefing"
        status={operations.morningBriefing.status}
        lastRun={operations.morningBriefing.lastRun}
        scheduled={operations.morningBriefing.scheduled}
      />
      <OperationCard
        name="Nightly Research"
        status={operations.nightlyResearch.status}
        lastRun={operations.nightlyResearch.lastRun}
        scheduled={operations.nightlyResearch.scheduled}
      />
      <OperationCard
        name="Backup"
        status={operations.backup.status}
        lastCommit={operations.backup.lastCommit}
      />
    </div>
  );
}

interface OperationCardProps {
  name: string;
  status: MappedOperations['morningBriefing']['status'];
  lastRun?: string;
  lastCommit?: string;
  scheduled?: boolean;
}

function OperationCard({ name, status, lastRun, lastCommit, scheduled }: OperationCardProps) {
  const statusColor = status === 'completed' ? 'bg-emerald-500' :
                      status === 'running' ? 'bg-blue-500' :
                      status === 'failed' ? 'bg-red-500' :
                      status === 'scheduled' ? 'bg-amber-500' :
                      'bg-slate-500';

  return (
    <div className="bg-white rounded-lg shadow border border-slate-200 p-4">
      <div className="flex items-center justify-between mb-2">
        <span className="font-medium text-sm">{name}</span>
        <span className={`w-2 h-2 rounded-full ${statusColor}`}></span>
      </div>
      <div className="text-sm text-slate-600">
        {statusLabels[status]}
      </div>
      {lastRun && <div className="text-xs text-slate-400 mt-1">{lastRun}</div>}
      {lastCommit && <div className="text-xs text-slate-400 mt-1">Commit: {lastCommit.slice(0, 7)}</div>}
    </div>
  );
}
