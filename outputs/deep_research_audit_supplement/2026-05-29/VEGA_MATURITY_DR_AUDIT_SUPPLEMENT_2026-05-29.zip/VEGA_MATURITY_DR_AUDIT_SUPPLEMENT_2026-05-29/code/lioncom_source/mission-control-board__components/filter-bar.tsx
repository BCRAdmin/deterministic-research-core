'use client';

import { Search } from 'lucide-react';

import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export type FilterOption = {
  value: string;
  label: string;
};

export type FilterField = {
  id: string;
  label: string;
  value: string;
  options: FilterOption[];
  onChange: (value: string) => void;
};

export function FilterBar({
  fields,
  search,
  onSearchChange,
  searchPlaceholder = 'Suchen...',
}: {
  fields: FilterField[];
  search?: string;
  onSearchChange?: (value: string) => void;
  searchPlaceholder?: string;
}) {
  return (
    <div className="flex flex-wrap items-center gap-2 rounded-2xl border border-border bg-elevated/35 p-2">
      {fields.map((field) => (
        <div key={field.id} className="min-w-[150px]">
          <Select value={field.value} onValueChange={field.onChange}>
            <SelectTrigger className="h-9 rounded-xl">
              <SelectValue placeholder={field.label} />
            </SelectTrigger>
            <SelectContent>
              {field.options.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      ))}
      {onSearchChange ? (
        <div className="relative min-w-[260px] flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted" />
          <Input className="h-9 pl-9" placeholder={searchPlaceholder} value={search ?? ''} onChange={(event) => onSearchChange(event.target.value)} />
        </div>
      ) : null}
    </div>
  );
}
