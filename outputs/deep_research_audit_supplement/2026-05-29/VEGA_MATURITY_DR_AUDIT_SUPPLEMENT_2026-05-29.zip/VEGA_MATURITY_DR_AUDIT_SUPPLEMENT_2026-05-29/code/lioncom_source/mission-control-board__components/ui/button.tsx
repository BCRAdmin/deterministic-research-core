import * as React from 'react';
import { Slot } from '@radix-ui/react-slot';
import { cva, type VariantProps } from 'class-variance-authority';

import { cn } from '@/lib/cn';

const buttonVariants = cva(
  'inline-flex appearance-none items-center justify-center gap-2 rounded-xl border text-sm font-medium transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[rgba(98,196,255,0.30)] disabled:pointer-events-none disabled:opacity-50',
  {
    variants: {
      variant: {
        default: 'border-strong bg-elevated text-text shadow-hud hover:border-strong hover:bg-white/5',
        ghost: 'border-transparent bg-transparent text-muted hover:bg-white/5 hover:text-text',
        outline: 'border-border bg-transparent text-text hover:border-strong hover:bg-white/5',
        vivi: 'border-[rgba(103,245,192,0.32)] bg-vivi-soft text-vivi hover:bg-[rgba(103,245,192,0.18)]',
        vega: 'border-[rgba(85,183,255,0.34)] bg-vega-soft text-vega hover:bg-[rgba(85,183,255,0.18)]',
      },
      size: {
        default: 'h-10 px-4 py-2',
        sm: 'h-8 px-3 text-xs',
        icon: 'size-10',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'default',
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : 'button';
    return <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />;
  },
);
Button.displayName = 'Button';

export { Button, buttonVariants };
