'use client';

import { Cloud, Cpu, Settings, TerminalSquare } from 'lucide-react';

import { InfoButton } from '@/components/info-button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/cn';
import type { AgentAccent, RuntimeProfile } from '@/lib/types';
import { useControlPlaneStore } from '@/store/control-plane-store';

export function RuntimeCard({
  runtime,
  accent,
  compact = false,
}: {
  runtime: RuntimeProfile;
  accent: AgentAccent;
  compact?: boolean;
}) {
  const agentId = accent === 'vivi' ? 'vivi' : 'vega';
  const providerMode = useControlPlaneStore((state) => state.providerModes[agentId]);
  const setProviderMode = useControlPlaneStore((state) => state.setProviderMode);
  const openOperatorInfo = useControlPlaneStore((state) => state.openOperatorInfo);
  const localActive = providerMode === 'local';
  const agentLabel = accent === 'vivi' ? 'Vivi' : 'Vega';
  const cloudProvider = accent === 'vivi' ? 'Vivi Cloud Relay' : 'Vega Cloud Relay';
  const requestedModel = runtime.requestedModel || runtime.model;
  const effectiveModel = runtime.effectiveModel || runtime.model;
  const modelMismatch = Boolean(runtime.requestedModel && runtime.effectiveModel && runtime.requestedModel !== runtime.effectiveModel);
  const runtimeTone = runtime.status.toLowerCase().includes('fallback') || modelMismatch || runtime.modelLastError ? 'warning' : 'info';
  function chooseProviderMode(mode: 'local' | 'cloud') {
    setProviderMode(agentId, mode);
    openOperatorInfo({
      title: `${agentLabel} Runtime-Modus`,
      body: mode === 'local'
        ? `${agentLabel} bleibt auf lokalem Ausführungskontext: Provider ${runtime.provider}, Modell ${runtime.model}, letzter Sync ${runtime.lastSync}. Der andere Agent wird dadurch nicht umgestellt.`
        : `${agentLabel} zeigt jetzt den Cloud-Fallback-Kontext: Provider ${cloudProvider}, Modell ${runtime.fallbackModel}. Der Wechsel betrifft nur diese Agent-Karte und startet keinen externen Lauf.`,
      tone: mode === 'local' ? 'success' : 'info',
    });
  }

  return (
    <Card className={cn('col-span-12 rounded-2xl', compact ? 'min-[1500px]:col-span-4' : 'min-[1500px]:col-span-3')}>
      <CardHeader>
        <div>
          <CardTitle className={cn('text-sm', accent === 'vivi' ? 'text-vivi' : 'text-vega')}>Modell / Runtime</CardTitle>
          <CardDescription>{accent === 'vivi' ? 'Ausführungskontext' : 'Umgebung, Tools & Ausführungskontext'}</CardDescription>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 rounded-xl border border-border bg-cpbg/40 p-1">
          <button
            type="button"
            aria-label={`${agentLabel} lokales LLM anzeigen`}
            aria-pressed={localActive}
            onClick={() => chooseProviderMode('local')}
            className={cn(
              'flex h-9 appearance-none items-center justify-center gap-2 rounded-lg border-0 text-sm transition',
              localActive ? (accent === 'vivi' ? 'bg-vivi-soft text-vivi' : 'bg-vega-soft text-vega') : 'bg-transparent text-muted hover:text-text',
            )}
          >
            <Cpu className="size-4" />
            Lokales LLM
          </button>
          <button
            type="button"
            aria-label={`${agentLabel} Cloud-Fallback anzeigen`}
            aria-pressed={!localActive}
            onClick={() => chooseProviderMode('cloud')}
            className={cn(
              'flex h-9 appearance-none items-center justify-center gap-2 rounded-lg border-0 text-sm transition',
              !localActive ? (accent === 'vivi' ? 'bg-vivi-soft text-vivi' : 'bg-vega-soft text-vega') : 'bg-transparent text-muted hover:text-text',
            )}
          >
            <Cloud className="size-4" />
            Cloud
          </button>
        </div>

        {accent === 'vivi' ? (
          <div className={cn(
            'rounded-xl border p-3',
            runtimeTone === 'warning'
              ? 'border-warning/35 bg-warning/10'
              : 'border-vivi/25 bg-vivi-soft/70',
          )}>
            <div className={cn('hud-label', runtimeTone === 'warning' ? 'text-warning' : 'text-vivi')}>Laufwahrheit</div>
            <div className="mt-3 grid gap-2 text-xs">
              <div className="flex justify-between gap-3">
                <span className="text-muted">Angefordert</span>
                <span className="min-w-0 truncate text-right text-text">{runtime.requestedProvider || runtime.provider} / {requestedModel}</span>
              </div>
              <div className="flex justify-between gap-3">
                <span className="text-muted">Effektiv</span>
                <span className={cn('min-w-0 truncate text-right font-semibold', runtimeTone === 'warning' ? 'text-warning' : 'text-vivi')}>
                  {runtime.effectiveProvider || runtime.provider} / {effectiveModel}
                </span>
              </div>
              {runtime.modelDetail ? <div className="leading-5 text-muted">{runtime.modelDetail}</div> : null}
              {runtime.modelLastError ? <div className="rounded-lg border border-warning/25 bg-cpbg/40 px-2 py-1 leading-5 text-warning">{runtime.modelLastError}</div> : null}
            </div>
          </div>
        ) : null}

        <div className="rounded-xl border border-border bg-cpbg/30 p-3">
          {[
            ['Provider', localActive ? runtime.provider : cloudProvider],
            ['Modell', localActive ? runtime.model : runtime.fallbackModel],
            ['Kontextfenster', runtime.contextWindow],
          ].map(([label, value]) => (
            <div key={label} className="grid grid-cols-[minmax(0,1fr)_minmax(0,1.2fr)] gap-3 border-b border-border py-3 text-sm last:border-b-0">
              <div className="text-muted">{label}</div>
              <div className="truncate text-right text-text">{value}</div>
            </div>
          ))}
          <div className="grid grid-cols-[minmax(0,1fr)_minmax(0,1.2fr)] gap-3 py-3 text-sm">
            <div className="text-muted">Fallback Modell</div>
            <Select defaultValue={runtime.fallbackModel}>
              <SelectTrigger className="h-9 min-w-0 justify-between rounded-lg text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={runtime.fallbackModel}>{runtime.fallbackModel}</SelectItem>
                <SelectItem value={`${runtime.fallbackModel}-safe`}>{runtime.fallbackModel}-safe</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-3 rounded-xl border border-border bg-cpbg/30 p-3">
          {[
            ['Status', localActive ? runtime.status : 'BEREITSCHAFT'],
            ['Latenz', localActive ? runtime.latency : '118 ms'],
            ['Letzter Sync', runtime.lastSync],
          ].map(([label, value]) => (
            <div key={label} className="border-l border-border px-2 first:border-l-0">
              <div className="hud-label text-muted">{label}</div>
              <div className={cn('mt-1 text-xs font-semibold', label === 'Status' ? (accent === 'vivi' ? 'text-vivi' : 'text-vega') : 'text-text')}>{value}</div>
            </div>
          ))}
        </div>

        {compact ? (
          <div className="grid gap-3 lg:grid-cols-2">
            <div className="rounded-xl border border-border bg-cpbg/30 p-3">
              <div className="hud-label text-muted">Werkzeuge</div>
              <div className="mt-3 space-y-2">
                {runtime.tools.map((tool) => (
                  <div key={tool} className="flex items-center justify-between text-sm">
                    <span className="truncate text-text">› {tool}</span>
                    <span className={cn('text-xs', accent === 'vivi' ? 'text-vivi' : 'text-vega')}>Aktiv</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="rounded-xl border border-border bg-cpbg/30 p-3">
              <div className="hud-label text-muted">Aktiver Workspace</div>
              <div className="mt-3 space-y-2 text-sm">
                <div className="flex justify-between gap-3"><span className="text-muted">Repo</span><span className="truncate text-text">{runtime.workspace.repo}</span></div>
                <div className="flex justify-between gap-3"><span className="text-muted">Pfad</span><span className="truncate text-text">{runtime.workspace.path}</span></div>
                <div className="flex justify-between gap-3"><span className="text-muted">Branch</span><span className="truncate text-text">{runtime.workspace.branch}</span></div>
                <div className="flex justify-between gap-3"><span className="text-muted">Sync</span><span className="truncate text-text">{runtime.workspace.lastSync}</span></div>
              </div>
            </div>
          </div>
        ) : null}

        <InfoButton
          variant={accent}
          className="w-full"
          info={{
            title: compact ? 'Werkzeugübersicht' : 'Modell-Einstellungen',
            body: compact
              ? `Aktiver Vega-Workspace: Repo ${runtime.workspace.repo}, Branch ${runtime.workspace.branch}, Sync ${runtime.workspace.lastSync}. Werkzeuge: ${runtime.tools.join(', ')}.`
              : `Aktuelle ${accent === 'vivi' ? 'Vivi' : 'Vega'} Runtime: Provider ${runtime.provider}, Modell ${runtime.model}, Kontext ${runtime.contextWindow}, Sync ${runtime.lastSync}.${accent === 'vivi' ? ` Angefordert: ${runtime.requestedProvider || runtime.provider} / ${requestedModel}. Effektiv: ${runtime.effectiveProvider || runtime.provider} / ${effectiveModel}.` : ''} Modell- und Providerwahl bleibt bewusst im jeweiligen Agentenbereich, damit Vivi und Vega nicht versehentlich gemeinsam umgeschaltet werden.`,
            tone: runtime.status.toLowerCase().includes('warning') || runtime.status.toLowerCase().includes('attention') || runtimeTone === 'warning' ? 'warning' : 'info',
          }}
        >
          {compact ? <TerminalSquare className="size-4" /> : <Settings className="size-4" />}
          {compact ? 'Werkzeugübersicht öffnen' : 'Modell-Einstellungen'}
        </InfoButton>
      </CardContent>
    </Card>
  );
}
