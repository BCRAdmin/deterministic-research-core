'use client';

import { FileStack, Plus } from 'lucide-react';

import { InfoButton } from '@/components/info-button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/cn';
import type { AgentAccent, Workspace } from '@/lib/types';
import { useControlPlaneStore } from '@/store/control-plane-store';

export function WorkspaceList({ workspaces, accent }: { workspaces: Workspace[]; accent: AgentAccent }) {
  const activeWorkspaceId = useControlPlaneStore((state) => state.activeWorkspaceId);
  const setActiveWorkspaceId = useControlPlaneStore((state) => state.setActiveWorkspaceId);
  const setSelectedView = useControlPlaneStore((state) => state.setSelectedView);

  return (
    <Card className="col-span-12 rounded-2xl xl:col-span-2">
      <CardHeader className="pb-1">
        <div>
          <CardTitle className={cn('text-sm', accent === 'vivi' ? 'text-vivi' : 'text-vega')}>Chats & Arbeitsbereiche</CardTitle>
          <CardDescription>{accent === 'vivi' ? 'Vivi Arbeitsbereiche' : 'Vega Arbeitsbereiche'}</CardDescription>
        </div>
        <InfoButton variant="outline" size="sm" onClick={() => setSelectedView('dispatch')} info={{ title: 'Neuer Workspace', body: `Aktueller Agent: ${accent === 'vivi' ? 'Vivi Command' : 'Vega Tech Cell'}. Ich habe die Dispatch-Brücke geöffnet, damit neue Arbeit mit Routing, Priorität und Agent-Zuordnung sauber startet.`, tone: 'info' }}>
          <Plus className="size-4" />
          Neu
        </InfoButton>
      </CardHeader>
      <CardContent className="flex flex-col gap-2">
        {workspaces.map((workspace, index) => {
          const active = activeWorkspaceId ? activeWorkspaceId === workspace.id : index === 0;
          return (
            <button
              key={workspace.id}
              type="button"
              onClick={() => setActiveWorkspaceId(workspace.id)}
              className={cn(
                'flex w-full items-center gap-3 rounded-xl border p-3 text-left transition',
                active
                  ? accent === 'vivi'
                    ? 'border-[rgba(103,245,192,0.58)] bg-vivi-soft hud-glow-vivi'
                    : 'border-[rgba(85,183,255,0.58)] bg-vega-soft hud-glow-vega'
                  : 'border-border bg-cpbg/30 hover:border-strong hover:bg-elevated/50',
              )}
            >
              <span
                className={cn(
                  'grid size-9 shrink-0 place-items-center rounded-lg border',
                  accent === 'vivi' ? 'border-vivi/40 bg-vivi-soft text-vivi' : 'border-vega/40 bg-vega-soft text-vega',
                )}
              >
                <FileStack className="size-4" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm text-text">{workspaceTitle(workspace.title)}</span>
                <span className="block truncate text-xs text-muted">{workspaceStatus(workspace.status)}</span>
              </span>
              <span className="text-right">
                <span className="block font-mono text-xs text-muted">{workspace.updatedAt}</span>
                {workspace.unreadCount ? (
                  <span className="mt-1 inline-grid min-w-7 place-items-center rounded-lg border border-border bg-elevated px-2 py-1 text-xs text-text">
                    {workspace.unreadCount}
                  </span>
                ) : null}
              </span>
            </button>
          );
        })}
        <InfoButton variant="outline" size="sm" className="mt-1 w-full" info={{ title: 'Alle Workspaces', body: `Sichtbar sind ${workspaces.length} ${accent === 'vivi' ? 'Vivi' : 'Vega'}-Workspaces. Diese Liste ist nach Agent getrennt; Chats und Arbeitsdaten werden hier nicht vermischt.`, tone: 'info' }}>
          Alle Arbeitsbereiche anzeigen
      </InfoButton>
      </CardContent>
    </Card>
  );
}

function workspaceTitle(title: string): string {
  return title
    .replace('Mission Planning', 'Missionsplanung')
    .replace('Operator Requests', 'Operator-Anfragen')
    .replace('Routing Review', 'Routing-Prüfung')
    .replace('Research Intake', 'Research-Eingang')
    .replace('System Updates', 'System-Updates')
    .replace('Knowledge Sync', 'Wissens-Sync')
    .replace('Code Tasks', 'Code-Aufgaben')
    .replace('Verification Queue', 'Prüf-Queue')
    .replace('Troubleshooting', 'Fehleranalyse');
}

function workspaceStatus(status: string): string {
  const labels: Record<string, string> = {
    active: 'Aktiv',
    ready: 'Bereit',
    review: 'Prüfung',
  };

  return labels[status.toLowerCase()] ?? status;
}
