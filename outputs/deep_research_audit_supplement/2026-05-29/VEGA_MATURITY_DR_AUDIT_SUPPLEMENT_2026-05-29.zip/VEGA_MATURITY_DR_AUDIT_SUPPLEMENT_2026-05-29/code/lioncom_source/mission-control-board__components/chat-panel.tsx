'use client';

import { useState } from 'react';
import { Check, Filter, Loader2, Maximize2, Send, SlidersHorizontal } from 'lucide-react';

import { InfoButton } from '@/components/info-button';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/cn';
import type { AgentAccent, AgentId, ChatMessage } from '@/lib/types';
import { useControlPlaneStore } from '@/store/control-plane-store';

const senderLabel: Record<ChatMessage['sender'], string> = {
  operator: 'Operator',
  vivi: 'Vivi',
  vega: 'Vega',
  system: 'System',
};

export function ChatPanel({
  agentId,
  accent,
  messages,
}: {
  agentId: AgentId;
  accent: AgentAccent;
  messages: ChatMessage[];
}) {
  const title = agentId === 'vivi' ? 'Operator → Vivi' : 'Operator → Vega';
  const placeholder = agentId === 'vivi' ? 'Nachricht an Vivi...' : 'Nachricht an Vega...';
  const openOperatorInfo = useControlPlaneStore((state) => state.openOperatorInfo);
  const [draft, setDraft] = useState('');
  const [localMessages, setLocalMessages] = useState<ChatMessage[]>([]);
  const [isSending, setIsSending] = useState(false);
  const renderedMessages = [...messages, ...localMessages];

  async function sendMessage() {
    const body = draft.trim();
    if (!body) {
      openOperatorInfo({
        title: 'Nachricht fehlt',
        body: agentId === 'vega'
          ? 'Schreibe kurz, was Vega prüfen, reparieren oder verifizieren soll. Leere Chat-Pakete werden nicht in die Rails geschrieben.'
          : 'Schreibe kurz, was Vivi planen, strukturieren oder als nächste Mission aufnehmen soll.',
        tone: 'warning',
      });
      return;
    }

    setIsSending(true);
    try {
      const response = await fetch(agentId === 'vega' ? '/api/codex' : '/api/control-plane-v2/dispatch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(agentId === 'vega'
          ? {
              role: 'operator',
              message: body,
              summary: body.slice(0, 180),
              status: 'chat',
              source: 'LIONCOM Control Plane V2 Live Chat',
            }
          : {
              title: `Vivi Chat: ${body.slice(0, 80)}`,
              description: body,
              taskType: 'Mission',
              targetMode: 'Vivi zuerst',
              priority: 'normal',
              runtime: 'Local',
              attachments: '',
            }),
      });
      const result = await response.json() as { ok?: boolean; reference?: string; operatorSummary?: string; error?: string };
      if (!response.ok || !result.ok) {
        throw new Error(result.error || 'Nachricht konnte lokal nicht gespeichert werden.');
      }

      const now = new Intl.DateTimeFormat('de-DE', { hour: '2-digit', minute: '2-digit' }).format(new Date());
      setLocalMessages((current) => [
        ...current,
        {
          id: `local-${agentId}-${Date.now()}`,
          agentId,
          sender: 'operator',
          time: now,
          body,
          status: 'queued',
        },
      ]);
      setDraft('');
      openOperatorInfo({
        title: agentId === 'vega' ? 'Vega-Livechat gespeichert' : 'Vivi-Paket geschrieben',
        body: agentId === 'vega'
          ? 'Deine Nachricht wurde im Vega/Codex-Livechat gespeichert und bleibt in dieser Chat-Ansicht sichtbar. Sie erzeugt keinen neuen Auftrag und keinen Dispatch-Eintrag.'
          : `${result.reference ?? 'Neuer Auftrag'} wurde lokal gespeichert. ${result.operatorSummary ?? 'Die Verarbeitung läuft über die vorhandenen LIONCOM-Rails.'}`,
        tone: 'success',
        actionLabel: 'Weiterarbeiten',
      });
    } catch (caught) {
      openOperatorInfo({
        title: 'Nachricht nicht geschrieben',
        body: caught instanceof Error ? caught.message : 'Die lokale Rail konnte nicht aktualisiert werden.',
        tone: 'warning',
      });
    } finally {
      setIsSending(false);
    }
  }

  return (
    <Card className="col-span-12 flex min-h-[410px] flex-col rounded-2xl xl:col-span-5">
      <CardHeader className="pb-1">
        <div>
          <CardTitle className={cn('text-base', accent === 'vivi' ? 'text-vivi' : 'text-vega')}>{title}</CardTitle>
          <CardDescription>Direkter Chat</CardDescription>
        </div>
        <div className="flex gap-2">
          <InfoButton variant="outline" size="icon" className="size-8" info={{ title: 'Chat-Filter', body: 'Filter blenden Operator-, Agent- und Systemnachrichten getrennt ein. Diese Ansicht bleibt auf den aktuell gewählten Agenten begrenzt.', tone: 'info' }}>
            <Filter className="size-4" />
          </InfoButton>
          <InfoButton variant="outline" size="icon" className="size-8" info={{ title: 'Chat-Einstellungen', body: 'Priorität, Kontext und Übergabehinweise bleiben agentenspezifisch. Vivi- und Vega-Daten werden hier nicht vermischt.', tone: 'info' }}>
            <SlidersHorizontal className="size-4" />
          </InfoButton>
          <InfoButton variant="outline" size="icon" className="size-8" info={{ title: 'Chat-Fokus', body: 'Der Fokus zeigt den aktuellen Agent-Chat größer, ohne dich in eine interne Debug-Ansicht zu schicken.', tone: 'info' }}>
            <Maximize2 className="size-4" />
          </InfoButton>
        </div>
      </CardHeader>
      <CardContent className="flex flex-1 flex-col gap-3 pt-2">
        <div className="relative flex-1 overflow-hidden rounded-xl border border-border bg-cpbg/35 p-3">
          <div className="absolute inset-0 hud-map opacity-20" aria-hidden="true" />
          <div className="relative flex h-full flex-col gap-2 overflow-y-auto pr-1">
            {renderedMessages.map((message) => {
              const fromAgent = message.sender === agentId;
              return (
                <div
                  key={message.id}
                  className={cn(
                    'max-w-[82%] rounded-xl border px-3 py-2 text-sm leading-relaxed',
                    fromAgent
                      ? accent === 'vivi'
                        ? 'border-[rgba(103,245,192,0.22)] bg-vivi-soft text-text'
                        : 'border-[rgba(85,183,255,0.24)] bg-vega-soft text-text'
                      : 'ml-auto border-border bg-elevated/55 text-text',
                  )}
                >
                  <div className="mb-1 flex items-center gap-2">
                    <span className={cn('hud-label', fromAgent ? (accent === 'vivi' ? 'text-vivi' : 'text-vega') : 'text-vega')}>
                      {senderLabel[message.sender]}
                    </span>
                    <span className="font-mono text-[0.68rem] text-muted">{message.time}</span>
                  </div>
                  <div>{message.body}</div>
                  {fromAgent && message.status ? (
                    <div className="mt-2 flex justify-end">
                      <Check className={cn('size-4', accent === 'vivi' ? 'text-vivi' : 'text-vega')} />
                    </div>
                  ) : null}
                </div>
              );
            })}
          </div>
        </div>
        <div className="flex gap-2">
          <Input
            placeholder={placeholder}
            className="h-10 flex-1"
            value={draft}
            onChange={(event) => setDraft(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                void sendMessage();
              }
            }}
            disabled={isSending}
          />
          <Button variant={accent} size="icon" className="size-10" onClick={() => void sendMessage()} disabled={isSending} aria-label={agentId === 'vivi' ? 'Nachricht an Vivi senden' : 'Nachricht an Vega senden'}>
            {isSending ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
