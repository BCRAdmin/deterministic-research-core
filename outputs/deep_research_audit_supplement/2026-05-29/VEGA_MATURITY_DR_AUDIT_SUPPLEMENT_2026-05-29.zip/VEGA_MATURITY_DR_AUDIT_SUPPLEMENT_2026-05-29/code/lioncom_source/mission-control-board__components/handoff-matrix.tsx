import { ArrowRight, Bot, TerminalSquare } from 'lucide-react';

import { AgentBadge } from '@/components/agent-badge';
import { Card } from '@/components/ui/card';

const rules = [
  ['Planung & Intake', 'vivi'],
  ['Operator-Chat', 'vivi'],
  ['Missionsrückgabe', 'vivi'],
  ['Code / Debug / Verifikation', 'vega'],
  ['Fehleranalyse', 'vega'],
  ['Implementierung', 'vega'],
  ['Finale QA', 'vega'],
] as const;

export function HandoffMatrix() {
  return (
    <Card className="rounded-2xl p-4">
      <div className="hud-title text-sm text-vega">Routing-Regeln / Übergabe-Matrix</div>
      <div className="mt-4 space-y-2">
        {rules.map(([label, target]) => {
          const Icon = target === 'vivi' ? Bot : TerminalSquare;
          return (
            <div key={label} className="grid grid-cols-[minmax(0,1fr)_auto_auto] items-center gap-3 rounded-xl border border-border bg-cpbg/30 p-3">
              <div className="flex items-center gap-3 text-sm text-text">
                <Icon className={target === 'vivi' ? 'size-4 text-vivi' : 'size-4 text-vega'} />
                <span>{label}</span>
              </div>
              <ArrowRight className="size-4 text-muted" />
              <AgentBadge agentId={target} compact />
            </div>
          );
        })}
      </div>
    </Card>
  );
}
