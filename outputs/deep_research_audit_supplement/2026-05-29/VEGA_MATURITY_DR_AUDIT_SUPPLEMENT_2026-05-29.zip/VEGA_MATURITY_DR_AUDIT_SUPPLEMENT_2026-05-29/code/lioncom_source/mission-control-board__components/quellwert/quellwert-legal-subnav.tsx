type QuellwertLegalNavKey = 'impressum' | 'datenschutz' | 'kontakt';

type Props = {
  current: QuellwertLegalNavKey;
};

export function QuellwertLegalSubnav({ current }: Props) {
  return (
    <nav className="qwp-legal-nav" aria-label="Rechtliches">
      <a
        href="/membership/impressum"
        aria-current={current === 'impressum' ? 'page' : undefined}
      >
        Impressum
      </a>
      <a
        href="/membership/datenschutz"
        aria-current={current === 'datenschutz' ? 'page' : undefined}
      >
        Datenschutz
      </a>
      <a href="/membership/kontakt" aria-current={current === 'kontakt' ? 'page' : undefined}>
        Kontakt
      </a>
    </nav>
  );
}
