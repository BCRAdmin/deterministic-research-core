type QuellwertPaperNavKey = 'analysen' | 'methodik' | 'archiv' | 'verifier';

type Props = {
  current?: QuellwertPaperNavKey;
};

export function QuellwertPaperHeader({ current }: Props) {
  return (
    <header className="qwp-header">
      <a className="qwp-skip-link" href="#qwp-content">
        Zum Inhalt springen
      </a>
      <a className="qwp-brand" href="/membership">
        Quellwert
      </a>
      <nav aria-label="Quellwert Navigation">
        <a href="/membership">Start</a>
        <a aria-current={current === 'analysen' ? 'page' : undefined} href="/membership/analysen">
          Analysen
        </a>
        <a aria-current={current === 'methodik' ? 'page' : undefined} href="/membership/methodik">
          Methodik
        </a>
        <a aria-current={current === 'archiv' ? 'page' : undefined} href="/membership/archiv">
          Archiv
        </a>
        <a aria-current={current === 'verifier' ? 'page' : undefined} href="/membership/verifier">
          Verifier
        </a>
      </nav>
    </header>
  );
}
