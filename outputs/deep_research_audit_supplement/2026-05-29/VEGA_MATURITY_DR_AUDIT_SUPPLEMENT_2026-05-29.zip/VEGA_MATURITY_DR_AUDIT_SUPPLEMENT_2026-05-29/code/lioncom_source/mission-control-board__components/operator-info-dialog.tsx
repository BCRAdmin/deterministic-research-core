'use client';

import { AlertTriangle, CheckCircle2, Info, ShieldAlert, X } from 'lucide-react';

import { StatusChip } from '@/components/status-chip';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/cn';
import { useControlPlaneStore } from '@/store/control-plane-store';

const toneIcon = {
  info: Info,
  success: CheckCircle2,
  warning: AlertTriangle,
  critical: ShieldAlert,
} as const;

export function OperatorInfoDialog() {
  const info = useControlPlaneStore((state) => state.operatorInfo);
  const close = useControlPlaneStore((state) => state.closeOperatorInfo);

  if (!info) return null;

  const tone = info.tone ?? 'info';
  const Icon = toneIcon[tone];

  return (
    <div className="fixed inset-0 z-[90] grid place-items-center bg-[rgba(1,7,12,0.74)] px-4 backdrop-blur-md" role="dialog" aria-modal="true">
      <div className="hud-panel w-full max-w-xl rounded-2xl border-strong bg-[rgb(var(--cp-surface-elevated-rgb))] p-5 shadow-hud-strong">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-3">
            <div
              className={cn(
                'grid size-11 shrink-0 place-items-center rounded-2xl border',
                tone === 'success'
                  ? 'border-vivi/45 bg-vivi-soft text-vivi'
                  : tone === 'warning'
                    ? 'border-warning/45 bg-warning/10 text-warning'
                    : tone === 'critical'
                      ? 'border-danger/45 bg-danger/10 text-danger'
                      : 'border-vega/45 bg-vega-soft text-vega',
              )}
            >
              <Icon className="size-5" />
            </div>
            <div>
              <div className="hud-label text-muted">Operator Info</div>
              <h2 className="mt-2 text-lg font-semibold text-text">{info.title}</h2>
            </div>
          </div>
          <button
            type="button"
            onClick={close}
            className="grid size-9 place-items-center rounded-xl border border-border bg-cpbg/45 text-muted transition hover:border-strong hover:text-text"
            aria-label="Info schließen"
          >
            <X className="size-4" />
          </button>
        </div>

        <div className="operator-info-body mt-5 rounded-xl border border-strong p-4 text-sm leading-6 text-text">
          <div className="hud-label mb-2 text-vega">Hinweis</div>
          <p>{info.body}</p>
        </div>

        <div className="mt-5 flex items-center justify-between gap-3">
          <StatusChip label={tone === 'success' ? 'bereit' : tone === 'warning' ? 'prüfen' : tone === 'critical' ? 'kritisch' : 'info'} tone={tone} />
          <Button variant="vega" onClick={close}>
            {info.actionLabel ?? 'Verstanden'}
          </Button>
        </div>
      </div>
    </div>
  );
}
