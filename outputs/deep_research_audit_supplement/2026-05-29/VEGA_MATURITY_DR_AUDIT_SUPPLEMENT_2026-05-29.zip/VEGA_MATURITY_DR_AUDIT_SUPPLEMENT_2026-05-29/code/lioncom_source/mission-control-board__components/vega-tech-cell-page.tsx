'use client';

import { AlertTriangle, DatabaseZap, GitCommitHorizontal, Wrench } from 'lucide-react';

import { ActivityFeed } from '@/components/activity-feed';
import { AgentShell } from '@/components/agent-shell';
import { HandoffCard } from '@/components/handoff-card';
import { InfoButton } from '@/components/info-button';
import { QueueOverview } from '@/components/queue-overview';
import { RuntimeCard } from '@/components/runtime-card';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useControlPlaneData } from '@/components/use-control-plane-data';
import { VegaChatConsole } from '@/components/vega-chat-console';
import { cn } from '@/lib/cn';
import type { AutomationTask, Handoff, RepoSnapshot, RuntimeProfile, VerificationItem } from '@/lib/types';

function VerificationQueuePanel({ verificationItems }: { verificationItems: VerificationItem[] }) {
  const counts = {
    total: verificationItems.length,
    waiting: verificationItems.filter((item) => item.status === 'waiting').length,
    passed: verificationItems.filter((item) => item.status === 'passed').length,
    failed: verificationItems.filter((item) => item.status === 'failed').length,
  };
  const statusCopy = (item: VerificationItem) => {
    if (item.status === 'passed') return 'Bestanden';
    if (item.status === 'failed') return 'Fehlgeschlagen';
    if (item.priority === 'critical') return 'Kritisch';
    if (item.priority === 'high') return 'Hoch';
    return 'Normal';
  };

  return (
    <Card className="col-span-12 rounded-2xl xl:col-span-3">
      <CardHeader>
        <div>
          <CardTitle className="text-sm text-vega">Prüf-Queue</CardTitle>
          <CardDescription>Prüfungen, Validierung & Testergebnisse</CardDescription>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-4 gap-2">
          {[
            ['Gesamt', counts.total, 'text-vega'],
            ['Wartend', counts.waiting, 'text-muted'],
            ['Bestanden', counts.passed, 'text-vivi'],
            ['Fehlgeschlagen', counts.failed, 'text-danger'],
          ].map(([label, value, color]) => (
            <div key={label} className="rounded-xl border border-border bg-cpbg/30 p-2 text-center">
              <div className={cn('text-xl font-semibold', color)}>{value}</div>
              <div className="hud-label mt-1 text-muted">{label}</div>
            </div>
          ))}
        </div>
        <div className="mt-3 space-y-2">
          {verificationItems.map((item) => (
            <div key={item.id} data-vega-verification-row="readable-card" className="rounded-xl border border-border bg-cpbg/35 px-3 py-2.5 text-sm">
              <div className="flex items-start justify-between gap-3">
                <span className="min-w-0 break-all font-mono text-[0.68rem] leading-snug text-vega">{item.id}</span>
                <span className="shrink-0 font-mono text-[0.68rem] text-muted">{item.duration}</span>
              </div>
              <div className="mt-1.5 line-clamp-2 leading-snug text-text">{item.title}</div>
              <div className="mt-2 flex items-center justify-between gap-2">
                <span
                  className={cn(
                    'rounded-lg border px-2 py-1 text-[0.68rem] font-semibold uppercase tracking-[0.12em]',
                    item.status === 'passed'
                      ? 'border-vivi/40 bg-vivi-soft text-vivi'
                      : item.status === 'failed'
                        ? 'border-danger/40 bg-danger/10 text-danger'
                        : item.priority === 'high' || item.priority === 'critical'
                          ? 'border-warning/40 bg-warning/10 text-warning'
                          : 'border-border-strong bg-surface-elevated text-muted',
                  )}
                >
                  {statusCopy(item)}
                </span>
                <span className="truncate text-right text-xs text-muted">
                  {item.status === 'waiting' ? 'wartet auf Lauf' : item.status === 'passed' ? 'Prüfung abgeschlossen' : 'Operator prüfen'}
                </span>
              </div>
            </div>
          ))}
        </div>
        <InfoButton variant="outline" size="sm" className="mt-3 w-full" info={{ title: 'Prüf-Queue Details', body: `Aktuell ${counts.total} Prüfungen: ${counts.waiting} wartend, ${counts.passed} bestanden, ${counts.failed} fehlgeschlagen. Operator-Fokus: fehlgeschlagene Checks zuerst prüfen, danach wartende Verifikationen freigeben.`, tone: counts.failed > 0 ? 'warning' : 'info' }}>
          Queue-Details anzeigen
        </InfoButton>
      </CardContent>
    </Card>
  );
}

function RepositoryPanel({ repoSnapshots }: { repoSnapshots: RepoSnapshot[] }) {
  const repo = repoSnapshots[0];

  return (
    <Card className="col-span-12 rounded-2xl xl:col-span-2">
      <CardHeader>
        <div>
          <CardTitle className="text-sm text-vega">Repository / Diffs / Commits</CardTitle>
          <CardDescription>Codebasis, Änderungen & Prüfung</CardDescription>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="rounded-xl border border-border bg-cpbg/30 p-3">
          <div className="hud-label text-muted">Branch</div>
          <div className="mt-2 flex items-center justify-between gap-3">
            <span className="truncate font-mono text-sm text-vega">{repo.branch}</span>
            <InfoButton variant="outline" size="sm" info={{ title: 'Branch ändern', body: `Aktiver Branch: ${repo.branch}. Prüfziel: ${repo.reviewTarget}. Vor einem Wechsel sollte Vega offene Diffs und laufende Tests abschließen.`, tone: 'info' }}>Ändern</InfoButton>
          </div>
        </div>
        <div className="rounded-xl border border-border bg-cpbg/30 p-3">
          <div className="hud-label text-muted">Letzter Commit</div>
          <div className="mt-2 flex items-center gap-2 text-text">
            <GitCommitHorizontal className="size-4 text-vega" />
            <span className="font-mono text-sm">{repo.lastCommit}</span>
          </div>
          <div className="mt-2 text-sm text-text">{repo.commitMessage}</div>
          <div className="mt-1 text-xs text-muted">{repo.author}</div>
        </div>
        <div className="rounded-xl border border-border bg-cpbg/30 p-3">
          <div className="hud-label text-muted">Geänderte Dateien ({repo.changedFiles.length})</div>
          <div className="mt-3 space-y-2">
            {repo.changedFiles.map((file) => (
              <div key={file.path} className="grid grid-cols-[minmax(0,1fr)_42px_34px] gap-2 text-xs">
                <span className="truncate text-text">{file.path}</span>
                <span className="text-right text-vivi">+{file.additions}</span>
                <span className="text-right text-danger">-{file.deletions}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="rounded-xl border border-border bg-cpbg/30 p-3">
          <div className="min-w-0">
            <div className="hud-label text-muted">Prüfziel</div>
            <div className="mt-1 break-words text-sm text-text">{repo.reviewTarget}</div>
          </div>
          <InfoButton className="mt-3 w-full" variant="vega" size="sm" info={{ title: 'Diff anzeigen', body: `${repo.changedFiles.length} geänderte Dateien auf ${repo.branch}. Letzter Commit ${repo.lastCommit}: ${repo.commitMessage}. Operator-Fokus: Review-Ziel ${repo.reviewTarget} prüfen.`, tone: 'info' }}>
            Diff anzeigen
          </InfoButton>
        </div>
      </CardContent>
    </Card>
  );
}

function TroubleshootingPanel({ automationTasks }: { automationTasks: AutomationTask[] }) {
  const repairs = automationTasks.filter((task) => task.agentId === 'vega');

  return (
    <Card className="col-span-12 rounded-2xl xl:col-span-3">
      <CardHeader>
        <div>
          <CardTitle className="text-sm text-vega">Fehleranalyse / Reparaturen</CardTitle>
          <CardDescription>Aktive Untersuchungen & Fehlerbehebung</CardDescription>
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        {repairs.map((task, index) => (
          <div key={task.id} className="grid grid-cols-[auto_minmax(0,1fr)_92px] items-center gap-3 rounded-xl border border-border bg-cpbg/30 p-3">
            <div className="grid size-9 place-items-center rounded-lg border border-vega/35 bg-vega-soft text-vega">
              {task.status === 'warning' ? <AlertTriangle className="size-4 text-warning" /> : <Wrench className="size-4" />}
            </div>
            <div className="min-w-0">
              <div className="truncate text-sm text-text">{task.title}</div>
              <div className="truncate text-xs text-muted">{task.description}</div>
            </div>
            <div className={cn('rounded-lg border px-2 py-1 text-center text-[0.68rem] font-semibold uppercase tracking-[0.12em]', task.status === 'warning' ? 'border-warning/40 bg-warning/10 text-warning' : 'border-vega/40 bg-vega-soft text-vega')}>
              {index === 0 ? 'Live' : task.status === 'warning' ? 'Logs' : 'Analyse'}
            </div>
          </div>
        ))}
        <InfoButton variant="outline" size="sm" className="mt-3 w-full" info={{ title: 'Alle Untersuchungen', body: `Aktuell ${repairs.length} Vega-Untersuchungen sichtbar. ${repairs[0] ? `Nächster Fokus: ${repairs[0].title} (${repairs[0].description}).` : 'Keine aktive Reparatur im Snapshot.'}`, tone: repairs.some((task) => task.status === 'warning') ? 'warning' : 'info' }}>
          Alle Untersuchungen anzeigen
        </InfoButton>
      </CardContent>
    </Card>
  );
}

function CodeMetricsPanel({
  queueCount,
  repoSnapshots,
  runtime,
  verificationItems,
}: {
  queueCount: number;
  repoSnapshots: RepoSnapshot[];
  runtime: RuntimeProfile;
  verificationItems: VerificationItem[];
}) {
  const repo = repoSnapshots[0];
  const passed = verificationItems.filter((item) => item.status === 'passed').length;
  const failed = verificationItems.filter((item) => item.status === 'failed').length;
  const waiting = verificationItems.filter((item) => item.status === 'waiting').length;
  const total = verificationItems.length;
  const passRate = total > 0 ? Math.round((passed / total) * 100) : 0;
  const metrics = [
    ['Code-Queue', String(queueCount), 'aus V2 Live-Snapshot', 'text-vega'],
    ['Prüfungen', `${passed}/${total}`, failed > 0 ? `${failed} fehlgeschlagen` : `${waiting} wartend`, failed > 0 ? 'text-danger' : 'text-vivi'],
    ['Repository', repo.branch, repo.lastCommit, 'text-vega'],
    ['Diff-Dateien', String(repo.changedFiles.length), repo.reviewTarget, 'text-text'],
    ['Runtime Sync', runtime.lastSync, runtime.status, isStableRuntimeStatus(runtime.status) ? 'text-vivi' : 'text-warning'],
  ];

  return (
    <Card className="col-span-12 rounded-2xl xl:col-span-4">
      <CardHeader>
        <div>
          <CardTitle className="text-sm text-vega">Vega Live-Status</CardTitle>
          <CardDescription>Quelle: LIONCOM V2 Snapshot + Vega Workspace</CardDescription>
        </div>
      </CardHeader>
      <CardContent className="grid gap-4 lg:grid-cols-[150px_minmax(0,1fr)]">
        <div className="grid place-items-center">
          <div className="relative grid size-36 place-items-center rounded-full border border-vega/45 bg-vega-soft hud-glow-vega">
            <div className="absolute inset-3 rounded-full border border-dashed border-vega/40" />
            <div className="text-center">
              <div className="text-3xl font-semibold text-text">{passRate}%</div>
              <div className="hud-label mt-1 text-vega">Bestanden</div>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-border bg-cpbg/30 p-3">
          {metrics.map(([label, value, status, color]) => (
            <div key={label} className="grid grid-cols-[minmax(0,1fr)_54px_80px] gap-3 border-b border-border py-2 text-sm last:border-b-0">
              <span className="truncate text-muted">{label}</span>
              <span className="truncate text-right text-text">{value}</span>
              <span className={cn('truncate text-right', color)}>{status}</span>
            </div>
          ))}
        </div>
        <InfoButton variant="outline" size="sm" className="lg:col-span-2" info={{ title: 'Vega Live-Status', body: `Diese Karte nutzt den aktuellen LIONCOM-Live-Snapshot: ${queueCount} Vega-Queue-Einträge, Branch ${repo.branch}, Commit ${repo.lastCommit}, Runtime-Sync ${runtime.lastSync}. Es ist dieselbe Datenbasis wie Übersicht und Audit-Protokoll.`, tone: failed > 0 ? 'warning' : 'info' }}>
          Datenquelle anzeigen
        </InfoButton>
      </CardContent>
    </Card>
  );
}

function isStableRuntimeStatus(status: string): boolean {
  const normalized = status.toLowerCase();
  return normalized.includes('stabil') || normalized.includes('healthy') || normalized.includes('bereit') || normalized.includes('ready');
}

function VegaSourceCard({ queueCount, repoSnapshots, runtime }: { queueCount: number; repoSnapshots: RepoSnapshot[]; runtime: RuntimeProfile }) {
  const repo = repoSnapshots[0];
  const rows = [
    ['Live-Snapshot', 'LIONCOM-Live-Daten'],
    ['Runtime', `${runtime.provider} · ${runtime.model}`],
    ['Workspace', `${repo.branch} · ${runtime.workspace.lastSync}`],
    ['Operator-Fokus', queueCount > 0 ? `${queueCount} technische Einträge prüfen` : 'Keine Vega-Queue sichtbar'],
  ];

  return (
    <Card className="col-span-12 rounded-2xl p-4 xl:col-span-2">
      <div className="flex items-center gap-3">
        <div className="grid size-10 place-items-center rounded-xl border border-vega/40 bg-vega-soft text-vega">
          <DatabaseZap className="size-5" />
        </div>
        <div>
          <div className="hud-title text-sm text-vega">Vega-Datenquelle</div>
          <div className="text-xs text-muted">Gleiche Datenbasis wie Übersicht</div>
        </div>
      </div>
      <div className="mt-4 space-y-2">
        {rows.map(([label, value]) => (
          <div key={label} className="rounded-xl border border-border bg-cpbg/30 p-3 text-sm">
            <div className="hud-label text-muted">{label}</div>
            <div className="mt-1 truncate text-text">{value}</div>
          </div>
        ))}
      </div>
    </Card>
  );
}

export function VegaTechCellPage() {
  const {
    activitySignals,
    agents,
    automationTasks,
    handoffs,
    queueItems,
    repoSnapshots,
    runtimeProfiles,
    verificationItems,
  } = useControlPlaneData();
  const agent = agents.find((item) => item.id === 'vega')!;
  const runtime = runtimeProfiles.find((item) => item.agentId === 'vega')!;
  const vegaQueues = queueItems.filter((item) => item.agentId === 'vega');
  const vegaSignals = activitySignals.filter((signal) => signal.agentId === 'vega');
  const handoff = handoffs.find((item) => item.id === 'handoff-vega-from-vivi') as Handoff;

  return (
    <AgentShell agent={agent}>
      <VegaChatConsole />
      <QueueOverview
        title="Code-Aufgaben"
        description="Technische Aufgaben & Implementierungen"
        items={vegaQueues}
        accent="vega"
        className="xl:col-span-3"
        showTabs
        actionLabel="Alle Code-Aufgaben anzeigen"
      />
      <VerificationQueuePanel verificationItems={verificationItems} />
      <RepositoryPanel repoSnapshots={repoSnapshots} />
      <HandoffCard handoff={handoff} accent="vega" className="col-span-12 xl:col-span-3" />
      <TroubleshootingPanel automationTasks={automationTasks} />
      <RuntimeCard runtime={runtime} accent="vega" compact />
      <CodeMetricsPanel queueCount={vegaQueues.length} repoSnapshots={repoSnapshots} runtime={runtime} verificationItems={verificationItems} />
      <VegaSourceCard queueCount={vegaQueues.length} repoSnapshots={repoSnapshots} runtime={runtime} />
      <ActivityFeed signals={vegaSignals} accent="vega" />
    </AgentShell>
  );
}
