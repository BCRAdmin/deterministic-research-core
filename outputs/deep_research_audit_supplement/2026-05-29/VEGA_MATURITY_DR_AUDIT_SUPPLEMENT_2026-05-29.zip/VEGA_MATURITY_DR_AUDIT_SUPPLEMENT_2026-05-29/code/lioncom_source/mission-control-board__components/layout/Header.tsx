// Header - Mission Control Board v1

interface HeaderProps {
  title: string;
  phase: string;
  lastUpdated: string;
}

export function Header({ title, phase, lastUpdated }: HeaderProps) {
  const timeString = new Date(lastUpdated).toLocaleTimeString('de-DE', {
    hour: '2-digit',
    minute: '2-digit'
  });

  return (
    <header className="bg-slate-900 text-white p-4 border-b border-slate-700">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-xl font-bold">{title}</h1>
          <span className="text-sm text-slate-400">Phase: {phase}</span>
        </div>
        <div className="text-right">
          <span className="text-sm text-slate-400">Aktualisiert: {timeString}</span>
        </div>
      </div>
    </header>
  );
}
