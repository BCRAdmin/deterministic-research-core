'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { Archive, Bot, Loader2, MessageSquare, Plus, Power, RefreshCw, Save, Send, Trash2, UserRound } from 'lucide-react';

import { StatusChip } from '@/components/status-chip';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/cn';
import { useControlPlaneStore } from '@/store/control-plane-store';

type VegaSessionStatus = 'idle' | 'active' | 'waiting' | 'archived';
type VegaChatRole = 'operator' | 'vega' | 'system';

interface VegaChatSession {
  id: string;
  title: string;
  topic: string;
  createdAt: string;
  updatedAt: string;
  status: VegaSessionStatus;
  lastMessagePreview: string;
  lastReference: string;
  latestActivity: string;
}

interface VegaChatMessage {
  id: string;
  sessionId: string;
  addedAt: string;
  role: VegaChatRole;
  status: string;
  summary: string;
  message: string;
  source?: string;
  reference?: string;
}

interface VegaChatSnapshot {
  sessions: VegaChatSession[];
  messages: VegaChatMessage[];
  activeSessionId?: string;
}

interface VegaApiResponse {
  ok?: boolean;
  snapshot?: VegaChatSnapshot;
  error?: string;
}

const STORAGE_KEY = 'lioncom-v2-vega-active-session';

const statusTone: Record<VegaSessionStatus, 'neutral' | 'info' | 'success' | 'warning'> = {
  active: 'success',
  archived: 'neutral',
  idle: 'neutral',
  waiting: 'info',
};

export function VegaChatConsole() {
  const openOperatorInfo = useControlPlaneStore((state) => state.openOperatorInfo);
  const [snapshot, setSnapshot] = useState<VegaChatSnapshot>({ sessions: [], messages: [] });
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [titleDraft, setTitleDraft] = useState('');
  const [topicDraft, setTopicDraft] = useState('');
  const [messageDraft, setMessageDraft] = useState('');
  const [notice, setNotice] = useState('Vega-Konsole bereit. Chats bleiben als Livechat getrennt von Dispatch-Aufträgen.');
  const [error, setError] = useState<string | null>(null);
  const [busyAction, setBusyAction] = useState<string | null>(null);
  const [deleteCandidateId, setDeleteCandidateId] = useState<string | null>(null);

  const activeSession = useMemo(
    () => snapshot.sessions.find((session) => session.id === activeSessionId) ?? snapshot.sessions[0],
    [activeSessionId, snapshot.sessions],
  );
  const activeMessages = useMemo(
    () => snapshot.messages.filter((message) => message.sessionId === activeSession?.id),
    [activeSession?.id, snapshot.messages],
  );
  const isDirty = Boolean(activeSession)
    && (titleDraft !== activeSession.title || topicDraft !== activeSession.topic);

  const applySnapshot = useCallback((nextSnapshot: VegaChatSnapshot, preferredSessionId?: string | null) => {
    setSnapshot(nextSnapshot);
    const storedSessionId = typeof window !== 'undefined' ? window.localStorage.getItem(STORAGE_KEY) : null;
    const nextActiveId = preferredSessionId
      ?? (storedSessionId && nextSnapshot.sessions.some((session) => session.id === storedSessionId) ? storedSessionId : null)
      ?? nextSnapshot.activeSessionId
      ?? nextSnapshot.sessions[0]?.id
      ?? null;
    setActiveSessionId(nextActiveId);
    if (nextActiveId && typeof window !== 'undefined') window.localStorage.setItem(STORAGE_KEY, nextActiveId);
  }, []);

  const fetchSnapshot = useCallback(async (quiet = false) => {
    if (!quiet) setBusyAction('refresh');
    setError(null);
    try {
      const response = await fetch('/api/vega-chat', { cache: 'no-store' });
      if (!response.ok) throw new Error('Vega-Chat konnte nicht geladen werden.');
      const nextSnapshot = await response.json() as VegaChatSnapshot;
      applySnapshot(nextSnapshot);
      if (!quiet) setNotice('Vega-Sessions wurden aktualisiert.');
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Vega-Chat konnte nicht geladen werden.');
    } finally {
      if (!quiet) setBusyAction(null);
    }
  }, [applySnapshot]);

  const postAction = useCallback(async (body: Record<string, unknown>, actionLabel: string, preferredSessionId?: string | null) => {
    setBusyAction(actionLabel);
    setError(null);
    try {
      const response = await fetch('/api/vega-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const result = await response.json() as VegaApiResponse;
      if (!response.ok || result.error) throw new Error(result.error || 'Vega-Aktion fehlgeschlagen.');
      if (result.snapshot) applySnapshot(result.snapshot, preferredSessionId);
      return result;
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Vega-Aktion fehlgeschlagen.');
      return null;
    } finally {
      setBusyAction(null);
    }
  }, [applySnapshot]);

  useEffect(() => {
    void fetchSnapshot(true);
    const timer = window.setInterval(() => void fetchSnapshot(true), 15000);
    return () => window.clearInterval(timer);
  }, [fetchSnapshot]);

  useEffect(() => {
    if (!activeSession) {
      setTitleDraft('');
      setTopicDraft('');
      return;
    }
    setTitleDraft(activeSession.title);
    setTopicDraft(activeSession.topic);
    setDeleteCandidateId(null);
  }, [activeSession?.id]);

  function selectSession(sessionId: string) {
    setActiveSessionId(sessionId);
    window.localStorage.setItem(STORAGE_KEY, sessionId);
    setDeleteCandidateId(null);
  }

  async function createSession() {
    const result = await postAction({
      action: 'create-session',
      title: 'Neue lokale Vega-Session',
      topic: 'Code, Debugging, Verifikation oder QA im getrennten Vega-Livechat',
    }, 'create');
    const newSessionId = result?.snapshot?.sessions[0]?.id;
    if (newSessionId) {
      applySnapshot(result.snapshot!, newSessionId);
      setNotice('Neue Vega-Session angelegt. Sie bleibt getrennt von Vivi-Sessions und Dispatch-Aufträgen.');
      openOperatorInfo({
        title: 'Vega-Session angelegt',
        body: 'Die neue Vega-Session hat einen eigenen Livechat-Kontext. Nachrichten hier werden nicht als Dispatch-Auftrag behandelt.',
        tone: 'success',
      });
    }
  }

  async function saveSession() {
    if (!activeSession) return false;
    const result = await postAction({
      action: 'update-session',
      sessionId: activeSession.id,
      title: titleDraft,
      topic: topicDraft,
    }, 'save', activeSession.id);
    if (result?.snapshot) {
      setNotice('Vega-Session gespeichert.');
      return true;
    }
    return false;
  }

  async function activateSession() {
    if (!activeSession) {
      setError('Lege zuerst eine Vega-Session an.');
      return;
    }
    if (isDirty) {
      const saved = await saveSession();
      if (!saved) return;
    }
    const result = await postAction({ action: 'activate-session', sessionId: activeSession.id }, 'start', activeSession.id);
    if (result?.snapshot) {
      setNotice('Vega-Session aktiv. Livechat bleibt in diesem Thread.');
      openOperatorInfo({
        title: 'Vega-Session aktiv',
        body: 'Vega ist für diesen Chat-Kontext bereit. Nutze Dispatch nur, wenn daraus ein echter Auftrag mit Routing, Priorität und Audit werden soll.',
        tone: 'info',
      });
    }
  }

  async function sendMessage() {
    if (!activeSession || !messageDraft.trim()) return;
    if (isDirty) {
      const saved = await saveSession();
      if (!saved) return;
    }
    const message = messageDraft.trim();
    setMessageDraft('');
    const result = await postAction({
      action: 'send-message',
      sessionId: activeSession.id,
      title: titleDraft,
      topic: topicDraft,
      message,
    }, 'send', activeSession.id);
    if (result?.snapshot) {
      setNotice('Nachricht im Vega-Livechat gespeichert. Kein Dispatch-Auftrag erzeugt.');
    } else {
      setMessageDraft(message);
    }
  }

  async function archiveSession(sessionId: string) {
    const result = await postAction({
      action: 'archive-session',
      sessionId,
      reason: 'Operator archiviert die Vega-Session über die V2-Konsole.',
    }, 'archive');
    if (result?.snapshot) {
      setDeleteCandidateId(null);
      setNotice('Vega-Session archiviert. Verlauf bleibt im Workspace nachvollziehbar.');
    }
  }

  async function removeEmptySession(sessionId: string) {
    const result = await postAction({
      action: 'remove-session',
      sessionId,
      confirmEmpty: true,
      reason: 'Operator entfernt eine leere Vega-Session.',
    }, 'remove');
    if (result?.snapshot) {
      setDeleteCandidateId(null);
      setNotice('Leere Vega-Session entfernt. Sessions mit Inhalt werden nur archiviert.');
    }
  }

  return (
    <Card className="col-span-12 rounded-2xl xl:col-span-5">
      <CardHeader className="items-start gap-4">
        <div>
          <CardTitle className="text-sm text-vega">Operator → Vega</CardTitle>
          <CardDescription>Livechat-Sessions, getrennt von Dispatch-Aufträgen</CardDescription>
        </div>
        <div className="flex flex-wrap items-center justify-end gap-2">
          <Button size="sm" variant="outline" onClick={() => void fetchSnapshot()} disabled={Boolean(busyAction)}>
            {busyAction === 'refresh' ? <Loader2 className="size-3.5 animate-spin" /> : <RefreshCw className="size-3.5" />}
            Aktualisieren
          </Button>
          <Button size="sm" variant="vega" onClick={() => void createSession()} disabled={Boolean(busyAction)}>
            <Plus className="size-3.5" />
            Neue Vega-Session
          </Button>
        </div>
      </CardHeader>
      <CardContent className="grid gap-4 xl:grid-cols-[220px_minmax(0,1fr)]">
        <aside className="min-w-0 rounded-xl border border-border bg-cpbg/35 p-2">
          <div className="mb-2 flex items-center justify-between px-1">
            <span className="hud-label text-muted">Vega-Sessions</span>
            <span className="font-mono text-xs text-vega">{snapshot.sessions.length}</span>
          </div>
          <div className="max-h-[485px] space-y-2 overflow-y-auto pr-1">
            {snapshot.sessions.map((session) => (
              <button
                key={session.id}
                type="button"
                onClick={() => selectSession(session.id)}
                className={cn(
                  'w-full rounded-xl border p-3 text-left transition',
                  activeSession?.id === session.id
                    ? 'border-vega/55 bg-vega-soft shadow-[0_0_22px_rgba(85,183,255,0.12)]'
                    : 'border-border bg-cpbg/35 hover:border-vega/35 hover:bg-vega-soft/50',
                )}
              >
                <div className="flex min-w-0 items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="truncate text-sm font-semibold text-text">{session.title}</div>
                    <div className="mt-1 line-clamp-2 text-xs leading-5 text-muted">{session.topic}</div>
                  </div>
                  <StatusChip label={localizeStatus(session.status)} tone={statusTone[session.status]} className="h-6 shrink-0 px-2" />
                </div>
                <div className="mt-2 line-clamp-2 text-xs leading-5 text-muted">{session.latestActivity}</div>
              </button>
            ))}
            {snapshot.sessions.length === 0 ? (
              <div className="rounded-xl border border-dashed border-border p-4 text-sm text-muted">
                Noch keine Vega-Session. Starte mit "Neue Vega-Session".
              </div>
            ) : null}
          </div>
        </aside>

        <section className="min-w-0 rounded-xl border border-border bg-cpbg/25">
          <div className="border-b border-border p-3">
            <div className="grid gap-2 md:grid-cols-[minmax(0,1fr)_190px]">
              <Input value={titleDraft} onChange={(event) => setTitleDraft(event.target.value)} placeholder="Vega-Session-Titel" disabled={!activeSession} />
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" onClick={() => void saveSession()} disabled={!activeSession || !isDirty || Boolean(busyAction)}>
                  {busyAction === 'save' ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
                  Speichern
                </Button>
                <Button variant="vega" onClick={() => void activateSession()} disabled={!activeSession || Boolean(busyAction)}>
                  {busyAction === 'start' ? <Loader2 className="size-4 animate-spin" /> : <Power className="size-4" />}
                  Aktivieren
                </Button>
              </div>
            </div>
            <Input value={topicDraft} onChange={(event) => setTopicDraft(event.target.value)} placeholder="Technischer Kontext / Prüfziel" className="mt-2" disabled={!activeSession} />
            <div className="mt-3 rounded-xl border border-border bg-cpbg/35 px-3 py-2 text-sm leading-6 text-muted">
              {activeSession ? activeSession.latestActivity : 'Lege eine Vega-Session an, um einen getrennten Tech-Chat zu starten.'}
            </div>
            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-muted">
              <span className="min-w-0 truncate">{notice}</span>
              {activeSession ? (
                <div className="flex flex-wrap items-center justify-end gap-2">
                  <Button size="sm" variant="ghost" onClick={() => void archiveSession(activeSession.id)} disabled={Boolean(busyAction)}>
                    {busyAction === 'archive' ? <Loader2 className="size-3.5 animate-spin" /> : <Archive className="size-3.5" />}
                    Archivieren
                  </Button>
                  {deleteCandidateId === activeSession.id ? (
                    <span className="flex items-center gap-2">
                      <span>Nur leere Session entfernen?</span>
                      <Button size="sm" variant="ghost" onClick={() => setDeleteCandidateId(null)}>Abbrechen</Button>
                      <Button size="sm" variant="outline" onClick={() => void removeEmptySession(activeSession.id)} disabled={Boolean(busyAction)}>
                        {busyAction === 'remove' ? <Loader2 className="size-3.5 animate-spin" /> : null}
                        Entfernen
                      </Button>
                    </span>
                  ) : (
                    <Button size="sm" variant="ghost" onClick={() => setDeleteCandidateId(activeSession.id)}>
                      <Trash2 className="size-3.5" />
                      Leere entfernen
                    </Button>
                  )}
                </div>
              ) : null}
            </div>
            {error ? <div className="mt-2 rounded-lg border border-danger/35 bg-danger/10 px-3 py-2 text-sm text-danger">{error}</div> : null}
          </div>

          <div className="max-h-[330px] space-y-3 overflow-y-auto p-3">
            {activeMessages.length > 0 ? activeMessages.map((message) => <VegaBubble key={message.id} message={message} />) : (
              <div className="grid min-h-[200px] place-items-center rounded-xl border border-dashed border-border bg-cpbg/25 p-6 text-center">
                <div>
                  <MessageSquare className="mx-auto size-9 text-vega" />
                  <div className="mt-3 text-base font-semibold text-text">Bereit für einen Vega-Livechat</div>
                  <div className="mt-2 max-w-md text-sm leading-6 text-muted">
                    Diese Session ist nur für Vega. Vivi-Chats, Mission Intake und Dispatches bleiben getrennt.
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="border-t border-border p-3">
            <div className="grid gap-2 md:grid-cols-[minmax(0,1fr)_112px]">
              <textarea
                value={messageDraft}
                onChange={(event) => setMessageDraft(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key !== 'Enter' || event.shiftKey) return;
                  event.preventDefault();
                  if (activeSession && messageDraft.trim() && !busyAction) void sendMessage();
                }}
                placeholder={activeSession ? 'Nachricht an Vega...' : 'Lege zuerst eine Vega-Session an...'}
                disabled={!activeSession || Boolean(busyAction)}
                rows={3}
                className="min-h-[86px] w-full resize-none rounded-xl border border-border bg-cpbg/50 px-3 py-2 text-sm leading-6 text-text outline-none transition placeholder:text-muted/70 focus:border-strong focus:ring-2 focus:ring-[rgba(98,196,255,0.30)] disabled:opacity-50"
              />
              <Button variant="vega" className="h-full min-h-[86px]" onClick={() => void sendMessage()} disabled={!activeSession || !messageDraft.trim() || Boolean(busyAction)} aria-label="Vega-Livechat senden">
                {busyAction === 'send' ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
                Senden
              </Button>
            </div>
          </div>
        </section>
      </CardContent>
    </Card>
  );
}

function VegaBubble({ message }: { message: VegaChatMessage }) {
  const isOperator = message.role === 'operator';
  const isSystem = message.role === 'system';
  const Icon = isOperator ? UserRound : Bot;

  return (
    <div className={cn('flex gap-3', isOperator ? 'justify-end' : 'justify-start')}>
      {!isOperator ? (
        <div className={cn('mt-1 grid size-8 shrink-0 place-items-center rounded-full border', isSystem ? 'border-border bg-elevated text-muted' : 'border-vega/40 bg-vega-soft text-vega')}>
          <Icon className="size-4" />
        </div>
      ) : null}
      <div className={cn('max-w-[82%] rounded-2xl border px-4 py-3 text-sm leading-6', isOperator ? 'border-vega/25 bg-vega-soft/75 text-text' : isSystem ? 'border-border bg-elevated/40 text-muted' : 'border-vega/30 bg-vega-soft/70 text-text')}>
        <div className="mb-2 flex flex-wrap items-center gap-2 font-mono text-[0.68rem] uppercase tracking-[0.13em]">
          <span className={isOperator ? 'text-vega' : isSystem ? 'text-muted' : 'text-vega'}>{isOperator ? 'Operator' : isSystem ? 'System' : 'Vega'}</span>
          <span className="text-muted">{formatTime(message.addedAt)}</span>
        </div>
        <p className="whitespace-pre-wrap break-words">{message.message}</p>
      </div>
      {isOperator ? (
        <div className="mt-1 grid size-8 shrink-0 place-items-center rounded-full border border-vega/35 bg-vega-soft text-vega">
          <Icon className="size-4" />
        </div>
      ) : null}
    </div>
  );
}

function localizeStatus(status: VegaSessionStatus): string {
  if (status === 'active') return 'aktiv';
  if (status === 'archived') return 'archiviert';
  if (status === 'waiting') return 'wartet';
  return 'bereit';
}

function formatTime(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
}
