import { CheckCircle2 } from 'lucide-react';

import { InfoButton } from '@/components/info-button';
import { MetricCard } from '@/components/metric-card';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/cn';
import type { Agent } from '@/lib/types';

function ViviSigil() {
  return (
    <svg viewBox="0 0 96 96" className="size-20" aria-hidden="true">
      <path d="M48 13 72 27v30L48 83 24 57V27Z" fill="rgba(103,245,192,0.08)" stroke="currentColor" strokeWidth="2" />
      <path d="M48 24v39" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
      <path d="M48 36 35 28M48 37l13-9M48 50 31 42M48 50l17-8M48 63 34 57M48 63l14-6" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M34 29c-7 9-7 24 3 34M62 29c7 9 7 24-3 34" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" opacity="0.72" />
      <circle cx="48" cy="22" r="3" fill="currentColor" />
      <circle cx="35" cy="28" r="2" fill="currentColor" />
      <circle cx="61" cy="28" r="2" fill="currentColor" />
    </svg>
  );
}

function VegaSigil() {
  return (
    <svg viewBox="0 0 96 96" className="size-20" aria-hidden="true">
      <path d="M48 12 76 28v32L48 84 20 60V28Z" fill="rgba(85,183,255,0.08)" stroke="currentColor" strokeWidth="2" />
      <path d="M35 33h26v26H35z" fill="none" stroke="currentColor" strokeWidth="4" strokeLinejoin="round" />
      <path d="M28 34h7M28 48h7M28 62h7M61 34h7M61 48h7M61 62h7M34 28v7M48 28v7M62 28v7M34 61v7M48 61v7M62 61v7" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
      <path d="M43 43h10v10H43z" fill="currentColor" opacity="0.85" />
      <path d="M24 28 48 42 72 28M24 60l24-14 24 14" fill="none" stroke="currentColor" strokeWidth="1.7" opacity="0.55" />
    </svg>
  );
}

function AgentMark({ accent }: { accent: Agent['accent'] }) {
  return (
    <div
      className={cn(
        'relative grid size-32 shrink-0 place-items-center rounded-full border bg-cpbg/50',
        accent === 'vivi' ? 'border-[rgba(103,245,192,0.42)] hud-glow-vivi' : 'border-[rgba(85,183,255,0.46)] hud-glow-vega',
      )}
    >
      <div className={cn('absolute inset-3 rounded-full border border-dashed opacity-50', accent === 'vivi' ? 'border-vivi' : 'border-vega')} />
      <div className={cn('absolute inset-7 rounded-full border opacity-45', accent === 'vivi' ? 'border-vivi' : 'border-vega')} />
      <div className={cn(accent === 'vivi' ? 'text-vivi' : 'text-vega')}>
        {accent === 'vivi' ? <ViviSigil /> : <VegaSigil />}
      </div>
    </div>
  );
}

export function AgentHero({ agent }: { agent: Agent }) {
  const accentClass = agent.accent === 'vivi' ? 'text-vivi' : 'text-vega';
  const role = agent.accent === 'vivi' ? 'Primärer Operations-Agent' : 'Verifikation, Fehleranalyse & Codebetrieb';

  return (
    <Card className="col-span-12 overflow-hidden rounded-2xl p-5 min-[1500px]:col-span-9">
      <div className="absolute inset-y-0 right-0 w-1/2 hud-map" aria-hidden="true" />
      <div className="relative z-[1] grid gap-5 lg:grid-cols-[auto_minmax(0,1fr)] min-[1500px]:grid-cols-[auto_minmax(0,1fr)_minmax(460px,0.94fr)]">
        <AgentMark accent={agent.accent} />
        <div className="min-w-0">
          <h1 className={cn('hud-title text-3xl leading-none', accentClass)}>{agent.name}</h1>
          <div className="mt-2 text-sm font-semibold uppercase tracking-[0.16em] text-text/80">{role}</div>
          <p className="mt-5 max-w-2xl text-[0.95rem] leading-7 text-muted">{agent.description}</p>
          <div className="mt-6 grid grid-cols-2 rounded-xl border border-border bg-cpbg/35 md:grid-cols-4">
            {[
              ['Status', agent.identity.status],
              ['Laufzeit', agent.identity.uptime],
              ['Letzter Sync', agent.identity.lastSync],
              ['Verbindung', agent.identity.linkLabel],
            ].map(([label, value]) => (
              <div key={label} className="border-l border-border px-4 py-3 first:border-l-0">
                <div className="hud-label text-muted">{label}</div>
                <div className={cn('mt-1 text-sm font-semibold', label === 'Status' ? accentClass : 'text-text')}>{localizeStatus(value)}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="grid grid-cols-2 overflow-hidden rounded-xl border border-border bg-cpbg/35 py-4 lg:col-span-2 md:grid-cols-4 min-[1500px]:col-span-1">
          {agent.metrics.map((metric) => (
            <MetricCard key={metric.id} metric={metric} accent={agent.accent} />
          ))}
        </div>
      </div>
    </Card>
  );
}

function localizeStatus(value: string): string {
  const labels: Record<string, string> = {
    READY: 'BEREIT',
    ACTIVE: 'AKTIV',
    BUSY: 'BESCHÄFTIGT',
    ATTENTION: 'ACHTUNG',
    WARNING: 'WARNUNG',
    HEALTHY: 'STABIL',
    ONLINE: 'ONLINE',
  };

  return labels[value.toUpperCase()] ?? value;
}

export function AgentFocusCard({ agent }: { agent: Agent }) {
  return (
    <Card className="col-span-12 rounded-2xl p-4 min-[1500px]:col-span-3">
      <div className={cn('hud-title text-sm', agent.accent === 'vivi' ? 'text-vivi' : 'text-vega')}>
        {agent.accent === 'vivi' ? 'Agent Fokus' : 'Vega Schwerpunkte'}
      </div>
      <div className="mt-4 flex flex-col gap-3">
        {agent.focus.map((item) => (
          <div key={item} className="flex items-center gap-3 text-sm text-muted">
            <CheckCircle2 className={cn('size-4 shrink-0', agent.accent === 'vivi' ? 'text-vivi' : 'text-vega')} />
            <span>{item}</span>
          </div>
        ))}
      </div>
      <InfoButton
        variant={agent.accent}
        className="mt-5 w-full"
        info={{
          title: `${agent.label} Einstellungen`,
          body: agent.accent === 'vivi'
            ? `Live-Kontext: Status ${localizeStatus(agent.identity.status)}, letzter Sync ${agent.identity.lastSync}, Verbindung ${agent.identity.linkLabel}. Fokus bleibt Intake, Planung, Routing und Operator-Kommunikation; Modell- und Providerwahl liegt in der Vivi Runtime Card.`
            : `Live-Kontext: Status ${localizeStatus(agent.identity.status)}, letzter Sync ${agent.identity.lastSync}, Branch/Link ${agent.identity.linkLabel}. Vega zeigt Code-Workspace, Verifikation, Debugging und Repo-Prüfung getrennt von Vivi-Chats.`,
          tone: 'info',
        }}
      >
        Agent-Einstellungen
      </InfoButton>
    </Card>
  );
}
