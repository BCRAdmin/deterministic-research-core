import { ArrowRight } from 'lucide-react';

import { AgentBadge } from '@/components/agent-badge';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/cn';
import type { Agent, AgentSummary } from '@/lib/types';

export function AgentStatusCard({ agent, summary, onOpen }: { agent: Agent; summary: AgentSummary; onOpen?: () => void }) {
  return (
    <Card className={cn('flex h-full flex-col rounded-2xl p-4', agent.id === 'vivi' ? 'hud-glow-vivi' : 'hud-glow-vega')}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <AgentBadge agentId={agent.id} />
          <div className={cn('hud-title mt-4 text-lg', agent.id === 'vivi' ? 'text-vivi' : 'text-vega')}>{agent.label}</div>
          <div className="mt-1 text-sm text-muted">{agent.id === 'vivi' ? 'Primärer Operations-Agent' : 'Prüfung, Fehleranalyse & Codebetrieb'}</div>
        </div>
        <div className={cn('rounded-xl border px-3 py-2 text-sm font-semibold uppercase', agent.id === 'vivi' ? 'border-vivi/35 bg-vivi-soft text-vivi' : 'border-vega/35 bg-vega-soft text-vega')}>
          {localizeStatus(summary.status)}
        </div>
      </div>
      <div className="mt-4 grid grid-cols-3 gap-2">
        {[
          ['Intake', summary.intakeCount],
          ['Planung', summary.planningQueue],
          ['Aktiv', summary.activeMissions],
        ].map(([label, value]) => (
          <div key={label} className="rounded-xl border border-border bg-cpbg/35 p-3">
            <div className="hud-label text-muted">{label}</div>
            <div className={cn('mt-2 text-2xl font-semibold', agent.id === 'vivi' ? 'text-vivi' : 'text-vega')}>{value}</div>
          </div>
        ))}
      </div>
      <div className="mt-4 rounded-xl border border-border bg-cpbg/35 p-3">
        <div className="hud-label text-muted">Letzte Aktion</div>
        <div className="mt-2 h-[3.75rem] overflow-hidden text-sm leading-5 text-text">{summary.lastAction}</div>
      </div>
      <div className="mt-auto pt-4">
        <Button variant={agent.id} className="w-full" onClick={onOpen}>
          Zu {agent.label}
          <ArrowRight className="size-4" />
        </Button>
      </div>
    </Card>
  );
}

function localizeStatus(status: string): string {
  const labels: Record<string, string> = {
    active: 'aktiv',
    attention: 'achtung',
    blocked: 'blockiert',
    busy: 'beschäftigt',
    ready: 'bereit',
    warning: 'warnung',
  };

  return labels[status.toLowerCase()] ?? status;
}
