import { Card } from '@/components/ui/card';
import { cn } from '@/lib/cn';
import type { TelemetrySignal } from '@/lib/types';

function points(values: number[]) {
  if (values.length === 0) return '';
  const min = Math.min(...values);
  const max = Math.max(...values);
  const spread = Math.max(1, max - min);
  return values
    .map((value, index) => {
      const x = (index / Math.max(1, values.length - 1)) * 100;
      const y = 44 - ((value - min) / spread) * 34;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');
}

function trendSummary(values: number[]) {
  if (values.length === 0) return 'Kein Verlauf im Snapshot.';

  const first = values[0] ?? 0;
  const last = values[values.length - 1] ?? first;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const direction = last > first ? 'steigend' : last < first ? 'fallend' : 'stabil';

  return `Verlauf ${direction}; Bereich ${min}-${max}; letzter Punkt ${last}.`;
}

export function TelemetryChartCard({ signal }: { signal: TelemetrySignal }) {
  const isWarning = signal.status === 'warning' || signal.status === 'critical';
  const lineColor = signal.status === 'critical' ? 'var(--cp-danger)' : isWarning ? 'var(--cp-warning)' : 'var(--cp-vega)';

  return (
    <Card className="rounded-2xl p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className={cn('hud-title text-sm', isWarning ? 'text-warning' : 'text-vega')}>{signal.title}</div>
          <div className="mt-1 text-xs text-muted">{signal.detail}</div>
          <div className="mt-2 rounded-lg border border-border bg-cpbg/35 px-2 py-1 font-mono text-[0.65rem] uppercase tracking-[0.12em] text-muted">
            {signal.sourceLabel}
          </div>
        </div>
        <div className={cn('text-2xl font-semibold', isWarning ? 'text-warning' : 'text-vega')}>{signal.value}</div>
      </div>
      <svg viewBox="0 0 100 52" className="mt-4 h-24 w-full overflow-visible" aria-hidden="true">
        <defs>
          <linearGradient id={`telemetry-fill-${signal.id}`} x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor={lineColor} stopOpacity="0.28" />
            <stop offset="100%" stopColor={lineColor} stopOpacity="0" />
          </linearGradient>
        </defs>
        <polyline points={`0,52 ${points(signal.series)} 100,52`} fill={`url(#telemetry-fill-${signal.id})`} stroke="none" />
        <polyline points={points(signal.series)} fill="none" stroke={lineColor} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      <div className="mt-3 rounded-xl border border-border bg-cpbg/30 px-3 py-2 text-xs leading-5 text-muted">
        {trendSummary(signal.series)}
      </div>
    </Card>
  );
}
