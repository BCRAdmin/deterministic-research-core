import { AgentFocusCard, AgentHero } from '@/components/agent-hero';
import type { Agent } from '@/lib/types';

export function AgentShell({ agent, children }: { agent: Agent; children: React.ReactNode }) {
  return (
    <div className="mx-auto grid min-h-full max-w-none grid-cols-12 gap-3">
      <AgentHero agent={agent} />
      <AgentFocusCard agent={agent} />
      {children}
    </div>
  );
}
