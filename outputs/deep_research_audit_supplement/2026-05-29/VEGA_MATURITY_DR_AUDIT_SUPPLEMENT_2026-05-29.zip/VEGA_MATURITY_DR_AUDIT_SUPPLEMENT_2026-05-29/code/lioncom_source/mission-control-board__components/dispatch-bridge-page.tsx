'use client';

import { Activity, Clock3, GitBranch, RotateCcw } from 'lucide-react';

import { DispatchComposer } from '@/components/dispatch-composer';
import { HandoffMatrix } from '@/components/handoff-matrix';
import { PriorityBadge } from '@/components/priority-badge';
import { StatusChip } from '@/components/status-chip';
import { Card } from '@/components/ui/card';
import { useControlPlaneData } from '@/components/use-control-plane-data';
import { cn } from '@/lib/cn';
import type { DispatchEvent, HandoffQueueItem } from '@/lib/types';

const columns: Array<{ id: HandoffQueueItem['column']; label: string }> = [
  { id: 'eingehend', label: 'Eingehend' },
  { id: 'vivi', label: 'An Vivi' },
  { id: 'vega', label: 'An Vega' },
  { id: 'rueckgabe', label: 'Rückgabe' },
  { id: 'blockiert', label: 'Blockiert' },
];

function DispatchMetrics({ events, queue }: { events: DispatchEvent[]; queue: HandoffQueueItem[] }) {
  const blocked = queue.filter((item) => item.column === 'blockiert').length;
  const overrides = events.filter((event) => event.targetMode === 'Nur Review').length;
  const metrics = [
    [GitBranch, 'Routing-Zustand', blocked > 2 ? 'WARNUNG' : 'ONLINE', blocked > 2 ? 'warning' : 'success'],
    [Clock3, 'Ø Übergabezeit', '06:42', 'info'],
    [Activity, 'Fehlgeschlagene Übergaben', String(blocked), blocked > 0 ? 'warning' : 'success'],
    [RotateCcw, 'Manuelle Eingriffe', String(overrides), 'info'],
  ] as const;

  return (
    <div className="grid gap-3 md:grid-cols-4">
      {metrics.map(([Icon, label, value, tone]) => (
        <Card key={label} className="rounded-2xl p-4">
          <Icon className={cn('size-5', tone === 'success' ? 'text-vivi' : tone === 'warning' ? 'text-warning' : 'text-vega')} />
          <div className="hud-label mt-4 text-muted">{label}</div>
          <div className="mt-2 flex items-center justify-between gap-3">
            <div className="text-2xl font-semibold text-text">{value}</div>
            <StatusChip label={tone} tone={tone} />
          </div>
        </Card>
      ))}
    </div>
  );
}

function HandoffQueueBoard({ queue }: { queue: HandoffQueueItem[] }) {
  return (
    <Card className="rounded-2xl p-4">
      <div className="hud-title text-sm text-vega">Übergabe-Queue</div>
      <div className="mt-4 grid items-start gap-3 xl:grid-cols-5">
        {columns.map((column) => {
          const items = queue.filter((item) => item.column === column.id);
          return (
            <div key={column.id} className="rounded-2xl border border-border bg-cpbg/30 p-3">
              <div className="flex items-center justify-between">
                <div className="hud-label text-muted">{column.label}</div>
                <span className="font-mono text-xs text-muted">{items.length}</span>
              </div>
              <div className="mt-3 space-y-2">
                {items.map((item) => (
                  <div key={item.id} className="rounded-xl border border-border bg-elevated/35 p-3">
                    <div className="text-sm font-semibold text-text">{item.title}</div>
                    <div className="mt-3 flex items-center justify-between gap-2">
                      <PriorityBadge priority={item.priority} />
                      <span className="font-mono text-xs text-muted">{statusLabel(item.status)}</span>
                    </div>
                  </div>
                ))}
                {items.length === 0 ? (
                  <div className="rounded-xl border border-dashed border-border bg-cpbg/25 p-3 text-xs leading-5 text-muted">
                    Keine offene Übergabe in dieser Spalte.
                  </div>
                ) : null}
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

function statusLabel(status: string): string {
  const value = status.toLowerCase();
  if (value.includes('accepted')) return 'angenommen';
  if (value.includes('active')) return 'aktiv';
  if (value.includes('block')) return 'blockiert';
  if (value.includes('done')) return 'erledigt';
  if (value.includes('handoff')) return 'Übergabe';
  if (value.includes('new')) return 'neu';
  if (value.includes('planning')) return 'planung';
  if (value.includes('return')) return 'rückgabe';
  if (value.includes('queue') || value.includes('wait')) return 'wartend';
  return status;
}

export function DispatchBridgePage() {
  const { dispatchEvents, handoffQueue } = useControlPlaneData();

  return (
    <div className="grid min-h-full grid-cols-12 gap-3">
      <Card className="col-span-12 overflow-hidden rounded-2xl p-5">
        <div className="absolute inset-0 hud-map opacity-30" aria-hidden="true" />
        <div className="relative z-[1]">
          <h1 className="hud-title text-3xl text-vega">DISPATCH-BRÜCKE // ROUTING & ÜBERGABEN</h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-muted">
            Zentrale Auftragserstellung und Routing. Vivi übernimmt Planung, Intake und Operator-Kommunikation; Vega übernimmt Code, Debugging, Verifikation und QA.
          </p>
        </div>
      </Card>
      <div className="col-span-12 xl:col-span-7">
        <DispatchComposer initialEvents={dispatchEvents} />
      </div>
      <div className="col-span-12 xl:col-span-5">
        <HandoffMatrix />
      </div>
      <div className="col-span-12">
        <DispatchMetrics events={dispatchEvents} queue={handoffQueue} />
      </div>
      <div className="col-span-12">
        <HandoffQueueBoard queue={handoffQueue} />
      </div>
    </div>
  );
}
