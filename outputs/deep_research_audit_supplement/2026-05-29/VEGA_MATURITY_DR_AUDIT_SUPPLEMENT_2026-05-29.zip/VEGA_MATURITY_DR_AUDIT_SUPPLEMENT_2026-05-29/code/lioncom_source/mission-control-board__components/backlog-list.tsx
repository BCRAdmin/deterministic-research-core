'use client';

import { useMemo, useState } from 'react';
import { Archive, Ban, CheckCircle2, GitBranch } from 'lucide-react';

import { AgentBadge } from '@/components/agent-badge';
import { InfoButton } from '@/components/info-button';
import { PriorityBadge } from '@/components/priority-badge';
import { StatusChip } from '@/components/status-chip';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/cn';
import type { BacklogItem } from '@/lib/types';
import { useControlPlaneStore } from '@/store/control-plane-store';

const tabs = ['Alle', 'Vivi-Eingang', 'Vega-Code', 'Reparatursignale', 'Alte Claims', 'Blockiert'] as const;
type BacklogTab = (typeof tabs)[number];

function matchesTab(item: BacklogItem, tab: BacklogTab) {
  if (tab === 'Alle') return true;
  if (tab === 'Vivi-Eingang') return item.recommendedAgentId === 'vivi';
  if (tab === 'Vega-Code') return item.recommendedAgentId === 'vega';
  if (tab === 'Reparatursignale') return item.status === 'repair';
  if (tab === 'Alte Claims') return item.status === 'stale';
  return item.status === 'blocked';
}

function statusLabel(status: BacklogItem['status']) {
  if (status === 'blocked') return 'Blockiert';
  if (status === 'open') return 'Offen';
  if (status === 'repair') return 'Reparatur';
  if (status === 'stale') return 'Alt';
  return 'Triage';
}

export function BacklogList({ items }: { items: BacklogItem[] }) {
  const setSelectedView = useControlPlaneStore((state) => state.setSelectedView);
  const [tab, setTab] = useState<BacklogTab>('Alle');
  const [selectedId, setSelectedId] = useState(items[0]?.id ?? '');
  const filtered = useMemo(() => items.filter((item) => matchesTab(item, tab)), [items, tab]);
  const selected = items.find((item) => item.id === selectedId) ?? filtered[0] ?? items[0];

  return (
    <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_380px]">
      <Card className="rounded-2xl p-4">
        <div className="flex flex-wrap gap-2">
          {tabs.map((item) => (
            <button
              key={item}
              type="button"
              onClick={() => setTab(item)}
              className={cn(
                'rounded-xl border px-3 py-2 font-mono text-xs font-semibold uppercase tracking-[0.13em] transition',
                tab === item ? 'border-vega/45 bg-vega-soft text-vega' : 'border-border bg-cpbg/30 text-muted hover:border-strong hover:text-text',
              )}
            >
              {item}
            </button>
          ))}
        </div>
        <div className="mt-4 space-y-2 overflow-x-auto pb-1">
          {filtered.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setSelectedId(item.id)}
              className={cn('grid min-w-[720px] w-full grid-cols-[minmax(0,1fr)_120px_90px_110px_80px] items-center gap-3 rounded-xl border p-3 text-left text-sm transition', selected?.id === item.id ? 'border-strong bg-elevated/55' : 'border-border bg-cpbg/30 hover:border-strong')}
            >
              <span className="min-w-0">
                <span className="block truncate text-text">{item.title}</span>
                <span className="mt-1 block truncate text-xs text-muted">{item.source}</span>
              </span>
              <AgentBadge agentId={item.recommendedAgentId} compact />
              <span className="font-mono text-xs text-muted">{item.age}</span>
              <PriorityBadge priority={item.priority} />
              <span className="text-right text-muted">{statusLabel(item.status)}</span>
            </button>
          ))}
        </div>
      </Card>

      <Card className="rounded-2xl p-4">
        <div className="hud-title text-sm text-vega">Backlog-Detail</div>
        {selected ? (
          <div className="mt-4 space-y-4">
            <div>
              <div className="font-mono text-xs text-muted">{selected.id}</div>
              <div className="mt-2 text-lg font-semibold text-text">{selected.title}</div>
            </div>
            <div className="flex flex-wrap gap-2">
              <AgentBadge agentId={selected.recommendedAgentId} />
              <PriorityBadge priority={selected.priority} />
              <StatusChip label={statusLabel(selected.status)} tone={selected.status === 'blocked' || selected.status === 'stale' ? 'warning' : 'info'} />
            </div>
            <div className="rounded-xl border border-border bg-cpbg/30 p-3">
              <div className="hud-label text-muted">Beschreibung</div>
              <div className="mt-2 text-sm text-text">{selected.description}</div>
            </div>
            <div className="rounded-xl border border-border bg-cpbg/30 p-3">
              <div className="hud-label text-muted">Warum offen?</div>
              <div className="mt-2 text-sm text-text">{selected.reasonOpen}</div>
            </div>
            <div className="rounded-xl border border-border bg-cpbg/30 p-3">
              <div className="hud-label text-muted">Empfohlener nächster Schritt</div>
              <div className="mt-2 text-sm text-text">{selected.nextStep}</div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <InfoButton variant="vivi" size="sm" onClick={() => setSelectedView('dispatch')} info={{ title: 'Route-Vorschlag für Vivi', body: `Empfehlung: "${selected.title}" gehört zu Vivi, wenn Planung, Intake oder Operator-Kommunikation gebraucht wird. Ich habe die Dispatch-Brücke geöffnet; dort kannst du daraus einen verbindlichen Auftrag machen.`, tone: 'success' }}><GitBranch className="size-4" />An Vivi routen</InfoButton>
              <InfoButton variant="vega" size="sm" onClick={() => setSelectedView('dispatch')} info={{ title: 'Route-Vorschlag für Vega', body: `Empfehlung: "${selected.title}" gehört zu Vega, wenn Code, Debugging oder Verifikation gebraucht wird. Ich habe die Dispatch-Brücke geöffnet; dort kannst du daraus einen verbindlichen Tech-Auftrag machen.`, tone: 'info' }}><GitBranch className="size-4" />An Vega routen</InfoButton>
              <InfoButton variant="outline" size="sm" info={{ title: 'Abschluss prüfen', body: `"${selected.title}" ist ein Abschlusskandidat. Schließe ihn erst, wenn kein aktiver Vivi- oder Vega-Auftrag mehr darauf zeigt und der letzte Status im Audit nachvollziehbar ist.`, tone: 'success' }}><CheckCircle2 className="size-4" />Erledigt</InfoButton>
              <InfoButton variant="outline" size="sm" info={{ title: 'Blocker prüfen', body: `"${selected.title}" braucht einen Owner und eine klare Entblockungsaktion. Empfohlen: an ${selected.recommendedAgentId === 'vivi' ? 'Vivi' : 'Vega'} routen und den Grund im Audit nachvollziehen.`, tone: 'warning' }}><Ban className="size-4" />Blocker</InfoButton>
            </div>
            <InfoButton variant="outline" className="w-full" info={{ title: 'Auto-Aufräumvorschläge', body: `Aktuelle Triage: ${filtered.length} sichtbare Einträge in "${tab}". Klare Kandidaten sind alte Claims, doppelte Reparatursignale und erledigte Items ohne aktive Folgeaufgabe. Keine Aktion läuft automatisch ohne Operator-Freigabe.`, tone: 'info' }}><Archive className="size-4" />Auto-Aufräumvorschläge</InfoButton>
          </div>
        ) : null}
      </Card>
    </div>
  );
}
