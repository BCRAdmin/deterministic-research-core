'use client';

import { GitBranch, ListChecks, MessageSquareWarning } from 'lucide-react';

import { ActivityFeed } from '@/components/activity-feed';
import { AgentShell } from '@/components/agent-shell';
import { AutomationList } from '@/components/automation-list';
import { HandoffCard } from '@/components/handoff-card';
import { InfoButton } from '@/components/info-button';
import { QueueOverview } from '@/components/queue-overview';
import { RuntimeCard } from '@/components/runtime-card';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useControlPlaneData } from '@/components/use-control-plane-data';
import { ViviLoopStatusCard } from '@/components/vivi-loop-status-card';
import { ViviChatConsole } from '@/components/vivi-chat-console';
import { ViviSkillToolbelt } from '@/components/vivi-skill-toolbelt';
import { cn } from '@/lib/cn';
import type { Handoff, IntakeRow, QueueItem } from '@/lib/types';

function MissionIntakeTable({ intakeRows }: { intakeRows: IntakeRow[] }) {
  const rows = intakeRows.filter((row) => row.agentId === 'vivi');

  return (
    <Card className="col-span-12 rounded-2xl xl:col-span-5">
      <CardHeader className="pb-2">
        <div>
          <CardTitle className="text-sm text-vivi">Missionseingang</CardTitle>
          <CardDescription>Anfragen & Planung</CardDescription>
        </div>
        <div className="grid grid-cols-4 rounded-xl border border-border bg-cpbg/35 p-1 text-center text-[0.68rem] uppercase tracking-[0.14em] text-muted">
          <span className="rounded-lg bg-vivi-soft px-3 py-2 text-vivi">Neu</span>
          <span className="px-3 py-2">In Planung</span>
          <span className="px-3 py-2">Geplant</span>
          <span className="px-3 py-2">Abgeschlossen</span>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-hidden rounded-xl border border-border bg-cpbg/30">
          {rows.map((row) => (
            <div key={row.id} className="grid grid-cols-[86px_minmax(0,1fr)_120px_70px] items-center gap-3 border-b border-border px-3 py-2 text-sm last:border-b-0">
              <span className="font-mono text-xs text-muted">{row.id}</span>
              <span className="truncate text-text">{row.title}</span>
              <span className={cn('text-xs font-semibold', row.priority === 'high' ? 'text-warning' : 'text-vivi')}>
                {row.priority === 'high' ? 'Hoch' : 'Normal'}
              </span>
              <span className="text-right font-mono text-xs text-muted">{row.updatedAt}</span>
            </div>
          ))}
        </div>
        <InfoButton variant="outline" size="sm" className="mt-3 w-full" info={{ title: 'Missionseingang', body: 'Die vollständige Eingangsliste bleibt Vivi-only und zeigt keine Vega-Code-Aufgaben. Diese Ansicht fasst die wichtigsten Planungsanfragen zusammen; Detailarbeit startest du über die Vivi-Session oder die Dispatch-Brücke.', tone: 'info' }}>
          Alle Anfragen anzeigen
        </InfoButton>
      </CardContent>
    </Card>
  );
}

function ViviSummaryCard({ handoff }: { handoff: Handoff }) {
  return (
    <Card className="col-span-12 rounded-2xl xl:col-span-4">
      <CardHeader>
        <div>
          <CardTitle className="text-sm text-vivi">Zusammenfassung</CardTitle>
          <CardDescription>Vivi Aktivität (24h)</CardDescription>
        </div>
      </CardHeader>
      <CardContent className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_140px]">
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-2">
            {[
              ['Verarbeitete Anfragen', '134', '+18%'],
              ['Erstellte Pläne', '22', '+12%'],
              ['Abgeschlossene Tasks', '96', '+9%'],
            ].map(([label, value, delta]) => (
              <div key={label} className="rounded-xl border border-border bg-cpbg/30 p-3">
                <div className="text-xs text-muted">{label}</div>
                <div className="mt-2 text-2xl font-semibold text-vivi">{value}</div>
                <div className="mt-1 font-mono text-xs text-vivi">{delta}</div>
              </div>
            ))}
          </div>
          <div className="rounded-xl border border-border bg-cpbg/30 p-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted">Eskalationen</span>
              <span className="text-vivi">6</span>
              <span className="font-mono text-xs text-warning">-14%</span>
            </div>
          </div>
          <HandoffCard handoff={handoff} accent="vivi" />
        </div>
        <div className="grid place-items-center">
          <div className="relative grid size-36 place-items-center rounded-full border border-vivi/40 bg-vivi-soft hud-glow-vivi">
            <div className="absolute inset-3 rounded-full border border-dashed border-vivi/40" />
            <div className="text-center">
              <div className="text-3xl font-semibold text-text">92%</div>
              <div className="hud-label mt-1 text-muted">Erfolgsrate</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function ViviDecisionPanel({
  handoff,
  intakeRows,
  queueItems,
}: {
  handoff: Handoff;
  intakeRows: IntakeRow[];
  queueItems: QueueItem[];
}) {
  const openIntake = intakeRows.filter((row) => row.agentId === 'vivi' && row.status.toLowerCase() !== 'abgeschlossen').length;
  const runningQueue = queueItems.filter((item) => item.agentId === 'vivi' && !item.status.toLowerCase().includes('erledigt') && !item.status.toLowerCase().includes('done')).length;
  const nextIntake = intakeRows.find((row) => row.agentId === 'vivi');
  const nextQueue = queueItems.find((item) => item.agentId === 'vivi');
  const gates = [
    {
      title: 'Eingang prüfen',
      value: `${openIntake} offen`,
      detail: nextIntake ? `Nächster Eingang: ${nextIntake.title} (${nextIntake.updatedAt}).` : 'Kein offener Vivi-Eingang sichtbar.',
      icon: MessageSquareWarning,
      tone: openIntake > 0 ? 'warning' : 'success',
    },
    {
      title: 'Queue priorisieren',
      value: `${runningQueue} aktiv`,
      detail: nextQueue ? `Aktueller Queue-Fokus: ${nextQueue.title}. Status ${nextQueue.status}, Fortschritt ${nextQueue.progress ?? 0}%.` : 'Keine aktive Vivi-Queue sichtbar.',
      icon: ListChecks,
      tone: runningQueue > 0 ? 'info' : 'success',
    },
    {
      title: 'Übergabe klären',
      value: handoff.status,
      detail: `${handoff.title}: ${handoff.detail}. Nur technische Folgearbeit geht an Vega; Planung und Operator-Kommunikation bleiben bei Vivi.`,
      icon: GitBranch,
      tone: 'info',
    },
  ] as const;

  return (
    <Card className="col-span-12 rounded-2xl p-4 xl:col-span-3">
      <div className="hud-title text-sm text-vivi">Vivi-Entscheidungspunkte</div>
      <div className="mt-1 text-xs text-muted">Live aus Eingang, Vivi-Queue und Übergabe-Status.</div>
      <div className="mt-4 space-y-2">
        {gates.map(({ detail, icon: Icon, title, tone, value }) => (
          <InfoButton
            key={title}
            variant="outline"
            className="h-auto w-full justify-between px-3 py-3 text-left"
            info={{
              title,
              body: detail,
              tone,
              actionLabel: 'Verstanden',
            }}
          >
            <span className="flex min-w-0 items-center gap-3">
              <Icon className={cn('size-4 shrink-0', tone === 'warning' ? 'text-warning' : 'text-vivi')} />
              <span className="min-w-0">
                <span className="block truncate text-sm text-text">{title}</span>
                <span className="mt-0.5 block truncate text-xs text-muted">{value}</span>
              </span>
            </span>
          </InfoButton>
        ))}
      </div>
    </Card>
  );
}

export function ViviCommandPage() {
  const { activitySignals, agents, automationTasks, handoffs, intakeRows, queueItems, runtimeProfiles } = useControlPlaneData();
  const agent = agents.find((item) => item.id === 'vivi')!;
  const runtime = runtimeProfiles.find((item) => item.agentId === 'vivi')!;
  const viviAutomations = automationTasks.filter((task) => task.agentId === 'vivi');
  const viviQueues = queueItems.filter((item) => item.agentId === 'vivi');
  const viviSignals = activitySignals.filter((signal) => signal.agentId === 'vivi');
  const handoff = handoffs.find((item) => item.id === 'handoff-vivi-to-vega')!;

  return (
    <AgentShell agent={agent}>
      <ViviChatConsole />
      <RuntimeCard runtime={runtime} accent="vivi" />
      <ViviSkillToolbelt />
      <AutomationList tasks={viviAutomations} accent="vivi" />
      <MissionIntakeTable intakeRows={intakeRows} />
      <QueueOverview
        title="Queue-Übersicht"
        description="Warteschlangen & Fortschritt"
        items={viviQueues}
        accent="vivi"
        className="xl:col-span-3"
      />
      <ViviSummaryCard handoff={handoff} />
      <ViviDecisionPanel handoff={handoff} intakeRows={intakeRows} queueItems={queueItems} />
      <ViviLoopStatusCard className="col-span-12 xl:col-span-2" />
      <ActivityFeed signals={viviSignals} accent="vivi" />
    </AgentShell>
  );
}
