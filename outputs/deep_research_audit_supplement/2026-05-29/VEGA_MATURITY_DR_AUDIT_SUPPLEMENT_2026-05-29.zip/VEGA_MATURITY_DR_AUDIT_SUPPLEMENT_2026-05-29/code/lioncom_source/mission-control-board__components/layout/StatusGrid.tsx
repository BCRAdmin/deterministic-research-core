// StatusGrid - Grid-Layout fuer Statuskarten

import { ReactNode } from 'react';

interface StatusGridProps {
  children: ReactNode;
}

export function StatusGrid({ children }: StatusGridProps) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 p-4">
      {children}
    </div>
  );
}
