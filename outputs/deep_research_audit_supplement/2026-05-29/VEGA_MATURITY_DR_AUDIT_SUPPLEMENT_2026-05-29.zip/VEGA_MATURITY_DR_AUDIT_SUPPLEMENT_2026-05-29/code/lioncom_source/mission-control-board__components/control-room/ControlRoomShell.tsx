'use client';

import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { useRouter } from 'next/navigation';
import { OperatorGoInbox } from './OperatorGoInbox';
import { RoadmapCardRegistry } from './RoadmapCardRegistry';

import type {
  AgentSignal,
  AutomationSignal,
  BacklogLane,
  BrainDumpEntry,
  BridgePacket,
  CodexChatEntry,
  ControlRoomData,
  DesktopDiagnostics,
  DecisionItem,
  FreezeStatus,
  GitHubSyncStatus,
  QualificationSnapshot,
  SummaryMetric,
  SubtaskItem,
  SystemAlert,
  TabId,
  TaskItem,
  ThemeVariant,
  TimelineEntry,
  ViviReportEntry,
  WorkBlockItem,
  WorkIntakeEntry,
} from '@/lib/control-room/types';
import {
  VIVI_PROVIDER_OPTIONS,
  defaultViviModel,
  modelsForProvider,
  normalizeViviProviderMode,
  normalizeViviRequestedModel,
  providerModeForPreset,
  type ViviModelCatalog,
  type ViviProviderMode,
  type ViviProviderPreset,
} from '@/lib/vivi-model-catalog';

interface OperatorDecisionSignal {
  id: string;
  title: string;
  detail: string;
  recommendation: string;
  tone: 'critical' | 'warning' | 'info';
  targetTab: TabId;
  targetAnchor?: string;
}

const TABS: Array<{ id: TabId; label: string }> = [
  { id: 'command', label: 'Lagebild' },
  { id: 'approvals', label: 'Operator Go' },
  { id: 'builder', label: 'Pipeline' },
  { id: 'research', label: 'Analyse' },
  { id: 'projects', label: 'Projekte' },
  { id: 'agents', label: 'Agenten' },
  { id: 'automations', label: 'Automationen' },
  { id: 'comms', label: 'Ideenraum' },
  { id: 'codex', label: 'Vivi + Vega' },
  { id: 'system', label: 'System' },
];

const BRAIN_DUMP_CATEGORY_OPTIONS = [
  { value: 'raw-idea', label: 'Rohe Idee' },
  { value: 'new-project', label: 'Neues Projekt' },
  { value: 'workflow', label: 'Workflow / System' },
  { value: 'problem-signal', label: 'Problem / Schmerzpunkt' },
  { value: 'research-spark', label: 'Research-Anstoß' },
];

const WORK_ORDER_CATEGORY_OPTIONS = [
  { value: 'work-order', label: 'Allgemeiner Auftrag' },
  { value: 'feature-direction', label: 'Feature-Richtung' },
  { value: 'project-build', label: 'Projektaufbau' },
  { value: 'research-brief', label: 'Research-Briefing' },
  { value: 'workflow-upgrade', label: 'Workflow-Upgrade' },
  { value: 'repair-track', label: 'Reparatur / Stabilisierung' },
];

const CODEX_CHAT_CATEGORY_OPTIONS = [
  { value: 'live-sync', label: 'Laufende Abstimmung' },
  { value: 'review-sync', label: 'Review / Qualitätscheck' },
  { value: 'decision-sync', label: 'Entscheidung / Richtung' },
  { value: 'blocker-sync', label: 'Blocker / Eskalation' },
];

const CODEX_COMMAND_CATEGORY_OPTIONS = [
  { value: 'implementation', label: 'Feature-Umsetzung' },
  { value: 'bugfix', label: 'Bugfix / Reparatur' },
  { value: 'ui-pass', label: 'UI / Bedienung' },
  { value: 'integration', label: 'Integration / Sync' },
  { value: 'review', label: 'Review / Verifikation' },
];

const VIVI_COMMAND_CATEGORY_OPTIONS = [
  { value: 'execution', label: 'Direkte Umsetzung' },
  { value: 'decompose', label: 'In Arbeit zerlegen' },
  { value: 'research-run', label: 'Research-Lauf' },
  { value: 'ops-support', label: 'Ops / Pflege' },
  { value: 'repair-run', label: 'Fehler beheben' },
];

type ViviChatRole = 'operator' | 'vivi' | 'system';

interface ViviChatSession {
  id: string;
  title: string;
  topic: string;
  createdAt: string;
  updatedAt: string;
  providerMode: ViviProviderMode;
  providerPreset: ViviProviderPreset;
  requestedModel: string;
  lastMessagePreview: string;
  lastReference: string;
  status: 'idle' | 'waiting' | 'reported' | 'attention';
  latestActivity: string;
}

interface ViviChatMessage {
  id: string;
  sessionId: string;
  addedAt: string;
  role: ViviChatRole;
  status: string;
  summary: string;
  message: string;
  source?: string;
  reference?: string;
  providerMode: ViviProviderMode;
  providerPreset: ViviProviderPreset;
  requestedModel?: string;
  derivedFrom: 'chat-thread' | 'vivi-report';
}

interface ViviChatSnapshot {
  sessions: ViviChatSession[];
  messages: ViviChatMessage[];
  activeSessionId?: string;
}

const VIVI_CHAT_ACTIVE_SESSION_KEY = 'lioncom-vivi-chat-active-session';

function CategoryField({
  id,
  name,
  label,
  options,
  defaultValue,
}: {
  id: string;
  name: string;
  label: string;
  options: Array<{ value: string; label: string }>;
  defaultValue: string;
}) {
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      <select id={id} name={name} defaultValue={defaultValue}>
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );
}

export function ControlRoomShell({
  data,
  initialTab,
  notice,
}: {
  data: ControlRoomData;
  initialTab: TabId;
  notice?: string;
}) {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<TabId>(initialTab);
  const [theme, setTheme] = useState<ThemeVariant>('knight');
  const [copiedCommand, setCopiedCommand] = useState<string | null>(null);
  const [jumpTarget, setJumpTarget] = useState<string | null>(null);
  const [selectedMetric, setSelectedMetric] = useState<string | null>(null);
  const [operatorGoPendingCount, setOperatorGoPendingCount] = useState<number>(0);
  const [roadmapDueCount, setRoadmapDueCount] = useState<number>(0);

  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    const stored = window.localStorage.getItem('lioncom-control-theme');
    if (stored === 'knight' || stored === 'signals') {
      setTheme(stored);
    }
  }, []);

  useEffect(() => {
    window.localStorage.setItem('lioncom-control-theme', theme);
  }, [theme]);

  useEffect(() => {
    const timer = window.setInterval(() => {
      router.refresh();
    }, 30000);

    return () => window.clearInterval(timer);
  }, [router]);

  useEffect(() => {
    let cancelled = false;

    fetch('/api/operator-go', { cache: 'no-store' })
      .then((response) => {
        if (!response.ok) throw new Error('operator-go-summary-failed');
        return response.json();
      })
      .then((payload) => {
        if (cancelled) return;
        const count = Array.isArray(payload?.pendingItems) ? payload.pendingItems.length : 0;
        setOperatorGoPendingCount(count);
      })
      .catch(() => {
        if (!cancelled) setOperatorGoPendingCount(0);
      });

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    let cancelled = false;

    fetch('/api/roadmap-cards', { cache: 'no-store' })
      .then((response) => {
        if (!response.ok) throw new Error('roadmap-card-summary-failed');
        return response.json();
      })
      .then((payload) => {
        if (cancelled) return;
        const count = typeof payload?.counts?.due === 'number' ? payload.counts.due : 0;
        setRoadmapDueCount(count);
      })
      .catch(() => {
        if (!cancelled) setRoadmapDueCount(0);
      });

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!copiedCommand) return;
    const timer = window.setTimeout(() => setCopiedCommand(null), 2500);
    return () => window.clearTimeout(timer);
  }, [copiedCommand]);

  useEffect(() => {
    if (!jumpTarget) return;

    let cancelled = false;
    let attempts = 0;

    const tryScroll = () => {
      if (cancelled) return;
      const target = document.querySelector<HTMLElement>(`[data-anchor="${jumpTarget}"]`);
      if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        setJumpTarget(null);
        return;
      }

      if (attempts < 12) {
        attempts += 1;
        window.setTimeout(tryScroll, 60);
      } else {
        setJumpTarget(null);
      }
    };

    tryScroll();

    return () => {
      cancelled = true;
    };
  }, [activeTab, jumpTarget]);

  const quickCommands = useMemo(() => buildQuickCommands(data), [data]);

  async function handleCopy(command: string, label: string) {
    try {
      await navigator.clipboard.writeText(command);
      setCopiedCommand(label);
    } catch {
      setCopiedCommand('Zwischenablage nicht verfügbar');
    }
  }

  function openDeck(tab: TabId, anchor?: string) {
    setActiveTab(tab);
    setJumpTarget(anchor ?? null);
  }

  const operatorDecisionCount = operatorGoPendingCount + roadmapDueCount;

  return (
    <div className="control-room-app" data-theme={theme}>
      <div className="window-top-drag-zone" aria-hidden="true" />
      <div className="control-room-shell">
        <div className="desktop-drag-strip panel" aria-hidden="true">
          <div className="drag-strip-left">
            <span className="eyebrow">Native Schaltzentrale</span>
            <strong>LIONCOM Desktop Control Plane</strong>
          </div>
        </div>

        <header className="topbar panel">
          <div className="topbar-main">
            <div className="brand-block">
              <div className="brand-row">
                <LioncomMark />
                <div>
                  <span className="eyebrow">LIONCOM // Vivi + Vega // Taktische Control Plane</span>
                  <h1 className="brand-title">LIONCOM</h1>
                </div>
              </div>
              <p className="brand-subtitle">
                Ideen, Missionen und Reparaturpakete laufen hier in einer gemeinsamen Control Plane zusammen, damit du
                den Betrieb lesen und steuern kannst, ohne dich in Einzelwerkzeug zu verlieren.
              </p>
            </div>

            <div className="control-actions">
              <div className="theme-switch">
                <button
                  type="button"
                  className="theme-button"
                  onClick={() => openDeck('codex', 'vivi-mission-form')}
                >
                  Vivi
                </button>
                <button
                  type="button"
                  className="theme-button is-active"
                  onClick={() => openDeck('codex', 'codex-chat-form')}
                >
                  Vega
                </button>
              </div>

              {copiedCommand ? <div className="copy-feedback">Telegram-Kommando bereit: {copiedCommand}</div> : null}
            </div>
          </div>

          <DisclosureCard
            title="Systemkurzlage"
            summary={`${data.mission.phase} · ${data.telemetry.state.toUpperCase()} · ${data.alerts.length} Hinweise · ${data.autonomy.activeClaims.length} aktive Claims`}
            nested
          >
            <div className="top-summary top-summary-inline">
              <SummaryChip
                label="Phase"
                value={data.mission.phase}
                detail={`${data.mission.progress}% Missionsfortschritt`}
                onSelect={() => setSelectedMetric('Systemkurzlage: Phase')}
                actionLabel="Phasendetails lesen"
                isActive={selectedMetric === 'Systemkurzlage: Phase'}
              />
              <SummaryChip
                label="Vertrauenslage"
                value={data.telemetry.state.toUpperCase()}
                detail={data.telemetry.runtimeResponsive ? 'Direkte Runtime bestätigt das Lagebild' : 'Lokaler Loop hält das Lagebild frisch'}
                onSelect={() => setSelectedMetric('Live-Telemetrie')}
                actionLabel="Vertrauensdetails lesen"
                isActive={selectedMetric === 'Live-Telemetrie'}
              />
              <SummaryChip
                label="Kritische Hinweise"
                value={String(data.alerts.length)}
                detail="Nur essentielle oder vertrauensbrechende Punkte"
                onSelect={() => setSelectedMetric('Systemkurzlage: Kritische Hinweise')}
                actionLabel="Hinweise lesen"
                isActive={selectedMetric === 'Systemkurzlage: Kritische Hinweise'}
              />
              <SummaryChip
                label="Loops"
                value={`${data.autonomy.activeClaims.length} aktiv`}
                detail={`Vivi ${data.autonomy.viviLoop.state} / Vega ${data.autonomy.codexLoop.state}`}
                onSelect={() => setSelectedMetric('Systemkurzlage: Loops')}
                actionLabel="Loopdetails lesen"
                isActive={selectedMetric === 'Systemkurzlage: Loops'}
              />
            </div>

            <div className="system-quick-details">
              <div className="list-card compact-card-shell">
                <strong>Was steckt gerade dahinter?</strong>
                <ul className="data-list compact">
                  <li>Direkte Runtime: {data.telemetry.detail}</li>
                  <li>Vivi-Loop: {data.autonomy.viviLoop.summary}</li>
                  <li>Vega-Loop: {data.autonomy.codexLoop.summary}</li>
                </ul>
              </div>

              <div className="list-card compact-card-shell">
                <strong>Kritische Hinweise live</strong>
                {data.alerts.length > 0 ? (
                  <ul className="data-list compact">
                    {data.alerts.slice(0, 2).map((alert) => (
                      <li key={alert.id}>
                        <div className="list-title">
                          <span>{alert.title}</span>
                          <StatusPill value={alert.severity} tone={toneForAlertSeverity(alert.severity)} />
                        </div>
                        <div className="detail" style={{ marginTop: 8 }}>{alert.recommendation}</div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="empty-state">Aktuell ist kein kritischer Hinweis offen.</div>
                )}
              </div>
            </div>
          </DisclosureCard>
        </header>

        {notice ? (
          <div className="notice-banner panel">
            <strong>Lokal gespeichert</strong>
            <div>{notice}</div>
          </div>
        ) : null}

        <section className="main-command-grid">
          <div className="hero-panel panel">
            <div className="hero-headline">
              <div>
                <span className="eyebrow">Primäres Lagebild</span>
                <h2>Strategischer Überblick</h2>
              </div>
              <StatusPill value={data.mission.systemState} tone={toneForMissionState(data.mission.systemState)} />
            </div>

            <div className="command-hero-layout">
              <div className="hero-copy-stack">
                <p className="mission-copy">{data.mission.executiveSummary}</p>

                <div className="telemetry-banner">
                  <div>
                    <strong>Telemetrie-Schiene</strong>
                    <span>{data.telemetry.state.toUpperCase()}</span>
                  </div>
                  <p>{data.telemetry.detail}</p>
                  <div className="inline-meta">
                    <span>quelle</span>
                    <span>{data.telemetry.source}</span>
                    <span>letztes Signal</span>
                    <span>{data.telemetry.lastUpdate ? formatMoment(data.telemetry.lastUpdate) : 'none'}</span>
                  </div>
                </div>

                <div className="progress-wrap">
                  <div className="progress-meta">
                    <span>{data.mission.phase}</span>
                    <span>{data.mission.progress}%</span>
                  </div>
                  <div className="progress-track">
                    <div className="progress-fill" style={{ width: `${Math.max(6, data.mission.progress)}%` }} />
                  </div>
                </div>

                <div className="mission-focus-grid">
                  <div className="list-card mission-focus-card">
                    <strong>Aktuelle Aktion</strong>
                    <div className="value">{data.mission.lastAction}</div>
                    <p className="detail">Zeit in Phase: {data.mission.timeInPhase ? `${data.mission.timeInPhase} min` : 'noch nicht gemessen'}</p>
                  </div>

                  <div className="list-card mission-focus-card">
                    <strong>Nächster Schritt</strong>
                    <div className="value">{data.mission.nextStep}</div>
                    <p className="detail">Das ist der operative Handoff-Anker für dich, Vivi und Vega.</p>
                    <button
                      type="button"
                      className="inline-link-button"
                      onClick={() => openDeck('approvals')}
                    >
                      Offene Entscheidungen bündeln{operatorDecisionCount > 0 ? ` (${operatorDecisionCount})` : ''}
                    </button>
                  </div>
                </div>

                {operatorDecisionCount > 0 ? (
                  <div className="operator-go-callout">
                    <div>
                      <strong>Operator-Entscheidungen warten</strong>
                      <p>
                        {operatorDecisionCount} Punkte liegen im Operator-Go- oder Roadmap-Deck.
                      </p>
                    </div>
                    <button
                      type="button"
                      className="rail-action-button rail-action-button-primary"
                      onClick={() => openDeck('approvals')}
                    >
                      Zur Go Inbox
                    </button>
                  </div>
                ) : null}

                <MissionMetricDeck
                  metrics={data.metrics}
                  selectedMetric={selectedMetric}
                  onSelectMetric={setSelectedMetric}
                />
              </div>
            </div>
          </div>

          <div className="side-column">
            <FoundationTracksCard blocks={data.workBlocks} roadmap={data.roadmap} />

            <div className="panel tab-section compact-panel">
              <div className="hero-headline">
                <div>
                  <span className="eyebrow">Nur essenzielle Probleme</span>
                  <h3>Kritischer Hinweisdeck</h3>
                </div>
              </div>
              <div className="alert-stack">
                {data.alerts.length > 0 ? data.alerts.map((alert) => (
                  <AlertCard key={alert.id} alert={alert} onOpenDeck={openDeck} />
                )) : <div className="empty-state">Aktuell ist kein vertrauensbrechender Hinweis sichtbar.</div>}
              </div>
            </div>
          </div>
        </section>

        <div className="workspace-frame">
          <nav className="tab-strip panel" aria-label="Control room sections">
            <div className="rail-group">
              <span className="rail-group-label">Navigation</span>
            </div>
            {TABS.map((tab) => (
              <button
                key={tab.id}
                type="button"
                className={`tab-button ${activeTab === tab.id ? 'is-active' : ''}`}
                onClick={() => {
                  setJumpTarget(null);
                  setActiveTab(tab.id);
                }}
              >
                <span>{tab.label}</span>
                {tab.id === 'approvals' && operatorDecisionCount > 0 ? (
                  <span className="tab-badge">{operatorDecisionCount}</span>
                ) : null}
              </button>
            ))}

            <div className="rail-group rail-group-actions">
              <span className="rail-group-label">Schnellzugriff</span>
              <button type="button" className="rail-action-button" onClick={() => router.refresh()}>
                Mesh aktualisieren
              </button>
              <button type="button" className="rail-action-button" onClick={() => openDeck('comms', 'ideendump-form')}>
                Brain Dump senden
              </button>
              <button type="button" className="rail-action-button" onClick={() => openDeck('comms', 'workorder-form')}>
                Auftrag anlegen
              </button>
              <button type="button" className="rail-action-button" onClick={() => openDeck('codex', 'vivi-mission-form')}>
                Vivi-Mission
              </button>
              <button type="button" className="rail-action-button rail-action-button-primary" onClick={() => openDeck('codex', 'codex-command-form')}>
                Vega-Paket
              </button>
            </div>
          </nav>

          <div className="tab-layout">
            {activeTab === 'command' ? <CommandTab data={data} onOpenDeck={openDeck} /> : null}
            {activeTab === 'approvals' ? (
              <>
                <RoadmapCardRegistry onDueCountChange={setRoadmapDueCount} />
                <OperatorGoInbox />
              </>
            ) : null}
            {activeTab === 'builder' ? <BuilderTab data={data} /> : null}
            {activeTab === 'research' ? <ResearchTab data={data} /> : null}
            {activeTab === 'projects' ? <ProjectsTab projects={data.projects} notes={data.notes} /> : null}
            {activeTab === 'agents' ? <AgentsTab agents={data.agents} /> : null}
            {activeTab === 'automations' ? <AutomationsTab automations={data.automations} timeline={data.timeline} telegramOutbox={data.telegramOutbox} /> : null}
            {activeTab === 'comms' ? <CommsTab data={data} quickCommands={quickCommands} onCopy={handleCopy} /> : null}
            {activeTab === 'codex' ? <CodexTab data={data} /> : null}
            {activeTab === 'system' ? <SystemTab data={data} /> : null}
          </div>
        </div>

        {selectedMetric ? (
          <MetricInspectorSheet
            metricLabel={selectedMetric}
            data={data}
            onClose={() => setSelectedMetric(null)}
            onOpenDeck={(tab, anchor) => {
              setSelectedMetric(null);
              openDeck(tab, anchor);
            }}
          />
        ) : null}
      </div>
    </div>
  );
}

function MissionMetricDeck({
  metrics,
  selectedMetric,
  onSelectMetric,
}: {
  metrics: SummaryMetric[];
  selectedMetric: string | null;
  onSelectMetric: (label: string) => void;
}) {
  if (metrics.length === 0) {
    return null;
  }

  const featuredMetric = metrics.find((metric) => metric.label.toLowerCase().includes('telemetrie'))
    || [...metrics].sort((left, right) => (right.detail?.length || 0) - (left.detail?.length || 0))[0];

  const compactMetrics = metrics.filter((metric) => metric !== featuredMetric);
  const primaryMetrics = compactMetrics.slice(0, 4);
  const overflowMetrics = compactMetrics.slice(4);

  return (
    <div className="mission-metric-stack">
      <div className="mission-metric-deck">
        <div className="mission-metric-grid">
          {primaryMetrics.map((metric) => (
            <MetricCard
              key={metric.label}
              metric={metric}
              variant="compact"
              isActive={selectedMetric === metric.label}
              onSelect={() => onSelectMetric(metric.label)}
            />
          ))}
        </div>

        {featuredMetric ? (
          <MetricCard
            metric={featuredMetric}
            variant="featured"
            isActive={selectedMetric === featuredMetric.label}
            onSelect={() => onSelectMetric(featuredMetric.label)}
          />
        ) : null}
      </div>

      {overflowMetrics.length > 0 ? (
        <div className="mission-metric-overflow">
          {overflowMetrics.map((metric) => (
            <MetricCard
              key={metric.label}
              metric={metric}
              variant="compact"
              isActive={selectedMetric === metric.label}
              onSelect={() => onSelectMetric(metric.label)}
            />
          ))}
        </div>
      ) : null}
    </div>
  );
}

function CommandTab({
  data,
  onOpenDeck,
}: {
  data: ControlRoomData;
  onOpenDeck: (tab: TabId, anchor?: string) => void;
}) {
  const movementSummary = `${data.timeline.length} Timeline · ${data.viviSteps.length} Vivi-Schritte · ${data.maintenance.length} Wartung`;
  const operatorDecisions = collectOperatorDecisions(data);

  return (
    <section className="panel tab-section">
      <div className="hero-headline">
        <div>
          <span className="eyebrow">Hauptdeck</span>
          <h3>Lagebild</h3>
        </div>
      </div>

      <div className="command-board-grid command-board-grid-quiet">
        <div className="command-column command-column-primary">
          <div className="list-card">
            <strong>Live-Vertrauen</strong>
            <div className={`value tone-${data.telemetry.state === 'live' ? 'ok' : data.telemetry.state === 'stale' ? 'warning' : 'critical'}`}>
              {data.telemetry.state.toUpperCase()}
            </div>
            <p className="detail">{data.telemetry.detail}</p>
            <MiniList
              items={[
                `Vivi-Loop: ${data.autonomy.viviLoop.state} - ${data.autonomy.viviLoop.summary}`,
                `Vega-Loop: ${data.autonomy.codexLoop.state} - ${data.autonomy.codexLoop.summary}`,
                `Remote-Bridge: ${data.remoteBridge.state} - ${data.remoteBridge.detail}`,
              ]}
              emptyMessage="Keine Vertrauenssignale sichtbar."
            />
          </div>

          <div className="list-card">
            <strong>Handlungsanker</strong>
            <p className="detail section-intro">Nur die nächsten Schritte, die dich operativ wirklich weiterbringen.</p>
            <MiniList
              items={data.recommendations}
              emptyMessage="Aktuell wurde keine konkrete Empfehlung extrahiert."
            />
          </div>
        </div>

        <div className="command-column">
          <div className="list-card" data-anchor="operator-decision-hub">
            <strong>Operator-Entscheidungen</strong>
            <p className="detail section-intro">Alles, was morgen wirklich durch dich entschieden oder freigegeben werden muss, ist hier gebündelt.</p>
            {operatorDecisions.length > 0 ? (
              <ul className="data-list">
                {operatorDecisions.map((decision) => (
                  <li key={decision.id}>
                    <div className="list-title">
                      <span>{decision.title}</span>
                      <StatusPill value={decision.tone} tone={decision.tone} />
                    </div>
                    <div className="detail" style={{ marginTop: 8 }}>{decision.detail}</div>
                    <div className="detail" style={{ marginTop: 8 }}>Empfohlen: {decision.recommendation}</div>
                    <button
                      type="button"
                      className="inline-link-button"
                      onClick={() => onOpenDeck(decision.targetTab, decision.targetAnchor)}
                    >
                      Zum passenden Bereich
                    </button>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="empty-state">Aktuell ist keine explizite Operator-Entscheidung extrahiert.</div>
            )}
          </div>

          <DisclosureCard title="Spuren und Nebenwissen" summary={movementSummary}>
            <div className="disclosure-stack">
              <div className="list-card compact-card-shell">
                <strong>Live-Timeline</strong>
                <div className="timeline-stack dense scroll-region">
                  {data.timeline.map((entry) => (
                    <TimelineCard key={`${entry.time}-${entry.label}`} entry={entry} />
                  ))}
                </div>
              </div>

              <div className="list-card compact-card-shell">
                <strong>Vivi-Schrittfeed</strong>
                <div className="timeline-stack dense scroll-region">
                  {data.viviSteps.map((entry) => (
                    <TimelineCard key={`vivi-${entry.time}-${entry.label}`} entry={entry} />
                  ))}
                </div>
              </div>

              <div className="list-card compact-card-shell">
                <strong>Wartungsdruck</strong>
                {data.maintenance.length > 0 ? (
                  <ul className="data-list compact">
                    {data.maintenance.map((alert) => (
                      <li key={alert.id}>
                        <div className="list-title">
                          <span>{alert.title}</span>
                          <StatusPill value={alert.severity} tone={toneForAlertSeverity(alert.severity)} />
                        </div>
                        <div className="detail" style={{ marginTop: 8 }}>{alert.detail}</div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="empty-state">Aktuell drückt kein nicht-kritisches Wartungsthema.</div>
                )}
              </div>
            </div>
          </DisclosureCard>
        </div>
      </div>
    </section>
  );
}

function MetricInspectorSheet({
  metricLabel,
  data,
  onClose,
  onOpenDeck,
}: {
  metricLabel: string;
  data: ControlRoomData;
  onClose: () => void;
  onOpenDeck: (tab: TabId, anchor?: string) => void;
}) {
  const model = buildMetricInspector(metricLabel, data);
  const compactInspector = model.stats.length <= 2 && !model.floor;

  return (
    <div className="metric-inspector-backdrop" role="presentation" onClick={onClose}>
      <aside className={`metric-inspector-sheet panel${compactInspector ? ' is-compact' : ''}`} role="dialog" aria-modal="true" aria-label={model.title} onClick={(event) => event.stopPropagation()}>
        <div className="metric-inspector-header">
          <div>
            <span className="eyebrow">{model.kicker}</span>
            <h3>{model.title}</h3>
          </div>
          <button type="button" className="button" onClick={onClose}>Schließen</button>
        </div>

        <p className="metric-inspector-summary">{model.summary}</p>

        <div className={`metric-inspector-stat-grid${model.stats.length <= 1 ? ' is-single' : ''}`}>
          {model.stats.map((stat) => (
            <div key={stat.label} className="metric-inspector-stat">
              <span className="label">{stat.label}</span>
              <strong className={`value tone-${stat.tone}`}>{stat.value}</strong>
              <span className="detail">{stat.detail}</span>
            </div>
          ))}
        </div>

        {model.floor ? (
          <div className="metric-inspector-floor">
            <div className="metric-inspector-subhead">
              <strong>Ops-Floor</strong>
              <span>Halo-inspirierte Mini-Lage, aber funktional statt dekorativ</span>
            </div>
            <div className="ops-floor-grid">
              {model.floor.map((room) => (
                <div key={room.label} className={`ops-room tone-${room.tone}`}>
                  <div className="ops-room-head">
                    <span>{room.label}</span>
                    <strong>{room.count}</strong>
                  </div>
                  <div className="ops-room-pixels" aria-hidden="true">
                    {Array.from({ length: Math.max(4, Math.min(room.count || 0, 12)) }).map((_, index) => (
                      <span key={`${room.label}-${index}`} />
                    ))}
                  </div>
                  <div className="ops-room-detail">{room.detail}</div>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        <div className={`metric-inspector-sections${model.sections.length <= 1 || compactInspector ? ' is-single' : ''}`}>
          {model.sections.map((section) => (
            <DisclosureCard
              key={section.title}
              title={section.title}
              summary={section.summary || `${section.items.length} Signale`}
              defaultOpen={section.defaultOpen ?? compactInspector}
              nested
            >
              <MiniList items={section.items} emptyMessage="Keine Details sichtbar." />
            </DisclosureCard>
          ))}
        </div>

        <div className="metric-inspector-actions">
          {model.actions.map((action) => (
            <button key={`${action.tab}-${action.label}`} type="button" className={`button ${action.primary ? 'button-primary' : ''}`} onClick={() => onOpenDeck(action.tab, action.anchor)}>
              {action.label}
            </button>
          ))}
        </div>
      </aside>
    </div>
  );
}

function DisclosureCard({
  title,
  summary,
  children,
  defaultOpen = false,
  nested = false,
}: {
  title: string;
  summary?: string;
  children: ReactNode;
  defaultOpen?: boolean;
  nested?: boolean;
}) {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className={`detail-disclosure${nested ? ' is-nested' : ''}${isOpen ? ' is-open' : ''}`}>
      <button type="button" className="detail-disclosure-trigger" onClick={() => setIsOpen((value) => !value)}>
        <div className="detail-disclosure-head">
          <strong>{title}</strong>
          {summary ? <span className="detail-disclosure-summary">{summary}</span> : null}
        </div>
        <span className="detail-disclosure-toggle">{isOpen ? 'Details ausblenden' : 'Details'}</span>
      </button>
      {isOpen ? <div className="detail-disclosure-body">{children}</div> : null}
    </div>
  );
}

function BuilderTab({ data }: { data: ControlRoomData }) {
  return (
    <section className="panel tab-section">
      <div className="hero-headline">
        <div>
          <span className="eyebrow">Ausführungslanes</span>
          <h3>Pipeline</h3>
        </div>
      </div>

      <div className="builder-grid builder-grid-3">
        <TaskListCard title="Aktive Bautasks" items={data.activeTasks} emptyMessage="Aktuell ist kein aktiver Task markiert." />
        <TaskListCard title="Wartend / blockiert" items={data.waitingTasks} emptyMessage="Aktuell ist kein wartender Task gelistet." />
        <TaskListCard title="Abgeschlossene Historie" items={data.completedTasks} emptyMessage="Keine jüngere Abschluss-Historie gefunden." />
        <ExecutionRoadmapCard roadmap={data.roadmap} />
        <WorkBlockCard blocks={data.workBlocks} />
        <SubtaskCard subtasks={data.subtasks} />
        <BacklogCard backlog={data.backlog} />
        <IntakeCard title="Eingereihte Arbeitsaufträge" entries={data.workIntake} emptyMessage="Noch kein eingehender Arbeitsauftrag in der Queue." />
        <BridgeCard title="Reparatur-Queue" entries={data.repairQueue} emptyMessage="Aktuell ist kein Reparaturpaket eingereiht." />
      </div>
    </section>
  );
}

function ResearchTab({ data }: { data: ControlRoomData }) {
  return (
    <section className="panel tab-section">
      <div className="hero-headline">
        <div>
          <span className="eyebrow">Analyse und Planung</span>
          <h3>Analyse</h3>
        </div>
      </div>

      <div className="split-layout research-layout">
        <div className="list-grid">
          <div className="list-card">
            <strong>Offene Entscheidungen</strong>
            <DecisionListCard decisions={data.decisionQueue} fallbackItems={data.decisions} />
          </div>
          <div className="list-card">
            <strong>Empfohlene nächste Schritte</strong>
            <MiniList items={data.recommendations} emptyMessage="Aktuell liegt keine Empfehlung vor." />
          </div>
          <RoadmapSummaryCard roadmap={data.roadmap} />
          <div className="list-card">
            <strong>Blocker und Reibung</strong>
            {data.blockers.length > 0 ? (
              <ul className="data-list">
                {data.blockers.map((blocker) => (
                  <li key={blocker.description}>
                    <div className="list-title"><span>{blocker.description}</span></div>
                    {blocker.impact ? <div className="detail" style={{ marginTop: 8 }}>Impact: {blocker.impact}</div> : null}
                    {blocker.workaround ? <div className="detail" style={{ marginTop: 8 }}>Workaround: {blocker.workaround}</div> : null}
                  </li>
                ))}
              </ul>
            ) : (
              <div className="empty-state">Aktuell ist kein Blockersignal sichtbar.</div>
            )}
          </div>
          <div className="list-card">
            <strong>Wartungskandidaten</strong>
            {data.maintenance.length > 0 ? (
              <ul className="data-list">
                {data.maintenance.map((item) => (
                  <li key={item.id}>
                    <div className="list-title">
                      <span>{item.title}</span>
                      <StatusPill value={item.severity} tone={toneForAlertSeverity(item.severity)} />
                    </div>
                    <div className="detail" style={{ marginTop: 8 }}>{item.recommendation}</div>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="empty-state">Aktuell drängt kein Thema in einen Nachtsweep.</div>
            )}
          </div>
        </div>

        <div className="list-card">
          <strong>Research-gekoppelte Arbeit</strong>
          {data.researchQueue.length > 0 ? (
            <ul className="data-list">
              {data.researchQueue.map((item) => (
                <li key={item.id}>
                  <div className="list-title">
                    <span>{item.title}</span>
                    <StatusPill value={item.status} tone={item.status === 'active' ? 'ok' : item.status === 'watching' ? 'warning' : 'info'} />
                  </div>
                  <div className="detail" style={{ marginTop: 8 }}>{item.reason}</div>
                </li>
              ))}
            </ul>
          ) : (
          <ul className="data-list">
            {collectResearchWork(data).map((item) => (
              <li key={item.id || item.title}>
                <div className="list-title">
                  <span>{item.title}</span>
                  <StatusPill value={item.status} tone={toneForTaskStatus(item.status)} />
                </div>
                {item.detail ? <div className="detail" style={{ marginTop: 8 }}>{item.detail}</div> : null}
              </li>
            ))}
          </ul>
          )}
        </div>
      </div>
    </section>
  );
}

function ProjectsTab({ projects, notes }: { projects: ControlRoomData['projects']; notes: string[] }) {
  return (
    <section className="panel tab-section">
      <div className="hero-headline">
        <div>
          <span className="eyebrow">Projektgedächtnis</span>
          <h3>Projekte und Artefakte</h3>
        </div>
      </div>

      <div className="split-layout projects-layout">
        <div className="project-grid">
          {projects.map((project) => (
            <div className="source-card" key={project.path}>
              <strong>{project.category}</strong>
              <div className="list-title">
                <span>{project.name}</span>
                <StatusPill value={project.category} tone={project.category === 'dashboard' ? 'info' : 'ok'} />
              </div>
              <div className="detail" style={{ marginTop: 8 }}>{project.path}</div>
              {project.modified ? <div className="inline-meta" style={{ marginTop: 12 }}><span>aktualisiert</span><span>{formatMoment(project.modified)}</span></div> : null}
            </div>
          ))}
        </div>
        <div className="list-card">
          <strong>Operator-Notizen</strong>
          <MiniList items={notes} emptyMessage="Aktuell liegt noch kein Notizsignal vor." />
        </div>
      </div>
    </section>
  );
}

function AgentsTab({ agents }: { agents: AgentSignal[] }) {
  return (
    <section className="panel tab-section">
      <div className="hero-headline">
        <div>
          <span className="eyebrow">Live-Akteursmesh</span>
          <h3>Agenten und Dienste</h3>
        </div>
      </div>
      <div className="agent-grid">
        {agents.map((agent) => (
          <div className="agent-card" key={agent.id}>
            <strong>{agent.kind}</strong>
            <div className="list-title">
              <span>{agent.name}</span>
              <StatusPill value={agent.status} tone={toneForAgentStatus(agent.status)} />
            </div>
            <div className="detail" style={{ marginTop: 10 }}>{agent.signal}</div>
            <div className="detail" style={{ marginTop: 8 }}>{agent.detail}</div>
            <div className="inline-meta" style={{ marginTop: 14 }}>
              <span>quelle</span>
              <span>{agent.source}</span>
              {agent.lastSeen ? <><span>zuletzt gesehen</span><span>{formatMoment(agent.lastSeen)}</span></> : null}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function AutomationsTab({
  automations,
  timeline,
  telegramOutbox,
}: {
  automations: AutomationSignal[];
  timeline: TimelineEntry[];
  telegramOutbox: BridgePacket[];
}) {
  return (
    <section className="panel tab-section">
      <div className="hero-headline">
        <div>
          <span className="eyebrow">Automationsschiene</span>
          <h3>Automationen und Zeitpläne</h3>
        </div>
      </div>

      <div className="split-layout">
        <div className="agent-grid automation-grid">
          {automations.map((automation) => (
            <div className="agent-card" key={automation.id}>
              <strong>automation</strong>
              <div className="list-title">
                <span>{automation.name}</span>
                <StatusPill value={automation.status} tone={toneForAutomationStatus(automation.status)} />
              </div>
              <div className="detail" style={{ marginTop: 8 }}>{automation.detail}</div>
              <div className="inline-meta" style={{ marginTop: 12 }}>
                <span>zeitplan</span>
                <span>{automation.schedule}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="list-grid">
          <div className="list-card">
            <strong>Letzte Pipeline-Bewegung</strong>
            <div className="timeline-stack dense">
              {timeline.map((entry) => (
                <TimelineCard key={`${entry.time}-${entry.label}`} entry={entry} />
              ))}
            </div>
          </div>
          <BridgeCard title="Letzte Telegram-Pakete" entries={telegramOutbox} emptyMessage="Noch kein ausgehendes Telegram-Paket gespeichert." />
        </div>
      </div>
    </section>
  );
}

function CommsTab({
  data,
  quickCommands,
  onCopy,
}: {
  data: ControlRoomData;
  quickCommands: Array<{ label: string; detail: string; command: string }>;
  onCopy: (command: string, label: string) => void;
}) {
  return (
    <section className="panel tab-section">
      <div className="hero-headline">
        <div>
          <span className="eyebrow">Unscharfer Operator-Input</span>
          <h3>Ideenraum</h3>
        </div>
      </div>

      <div className="comms-primary-grid">
        <div className="form-card" data-anchor="ideendump-form">
          <strong>Brain Dump für Vivi</strong>
          <div className="form-help">
            Für rohe Gedanken, wirre Fragmente oder neue Richtungen. Hier gilt: erst verstehen, dann strukturieren. Beispiele sind standardmäßig Inspiration, nicht sofort exakte Spezifikation.
          </div>
          <form action="/api/intake" method="post" encType="multipart/form-data" className="form-stack">
            <input type="hidden" name="kind" value="brain-dump" />
            <input type="hidden" name="redirectTab" value="comms" />
            <CategoryField
              id="brain-category"
              name="category"
              label="Kategorie"
              options={BRAIN_DUMP_CATEGORY_OPTIONS}
              defaultValue="raw-idea"
            />
            <div className="field">
              <label htmlFor="brain-context">Kontext</label>
              <input id="brain-context" name="context" placeholder="Optionaler Projekt-, Missions- oder Systemkontext" />
            </div>
            <div className="field">
              <label htmlFor="brain-input">Rohsignal</label>
              <textarea id="brain-input" name="rawInput" required placeholder="Schreib genau so, wie der Gedanke in deinem Kopf ankommt. Vivi soll ihn entwirren, bei Bedarf Research starten und daraus echte Arbeit ableiten." />
            </div>
            <div className="field">
              <label htmlFor="brain-files">Anhänge</label>
              <input id="brain-files" name="attachments" type="file" multiple />
              <div className="form-note">Optional: PDFs, Screenshots, Markdown-Dateien, Audio oder andere Referenzen für Vivi.</div>
            </div>
            <div className="form-actions">
              <button type="submit" className="button button-primary">Brain Dump speichern</button>
            </div>
          </form>
        </div>

        <div className="form-card" data-anchor="workorder-form">
          <strong>Arbeitsauftrag für Vivi</strong>
          <div className="form-help">
            Für Wünsche, die Vivi in Phasen, Work-Blocks, Subtasks und eine saubere Umsetzung übersetzen soll. Nutze das, wenn das Ziel da ist, aber der genaue Scope noch gebaut werden muss.
          </div>
          <form action="/api/intake" method="post" encType="multipart/form-data" className="form-stack">
            <input type="hidden" name="kind" value="work-intake" />
            <input type="hidden" name="redirectTab" value="comms" />
            <CategoryField
              id="work-category"
              name="category"
              label="Kategorie"
              options={WORK_ORDER_CATEGORY_OPTIONS}
              defaultValue="work-order"
            />
            <div className="field">
              <label htmlFor="work-title">Titel</label>
              <input id="work-title" name="title" required placeholder="Kurzer Arbeitstitel" />
            </div>
            <div className="field">
              <label htmlFor="work-outcome">Gewünschtes Ergebnis</label>
              <input id="work-outcome" name="desiredOutcome" placeholder="Was soll am Ende wahr oder nutzbar sein?" />
            </div>
            <div className="field">
              <label htmlFor="work-urgency">Dringlichkeit</label>
              <select id="work-urgency" name="urgency" defaultValue="normal">
                <option value="critical">kritisch</option>
                <option value="high">hoch</option>
                <option value="normal">normal</option>
                <option value="explore">erkunden</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="work-request">Auftrag</label>
              <textarea id="work-request" name="rawRequest" required placeholder="Beschreibe das Projekt oder Ziel natürlich. Vivi soll daraus Scope, Zielgruppe, Funktionen, Research-Fragen und die nächsten Schritte ableiten." />
            </div>
            <div className="field">
              <label htmlFor="work-files">Anhänge</label>
              <input id="work-files" name="attachments" type="file" multiple />
              <div className="form-note">Optional: Briefings, Bilder, Dokumente oder technische Referenzen, die direkt zum Auftrag gehören.</div>
            </div>
            <div className="form-actions">
              <button type="submit" className="button button-primary">Für Vivi einreihen</button>
            </div>
          </form>
        </div>

        <div className="form-card">
          <strong>Telegram-Bridge</strong>
          <div className="form-help">
            Sende dir selbst ein mobiles Paket für unterwegs, Entscheidungen, Alerts oder Handoff-Notizen. Fehlen die Credentials, bleibt das Paket trotzdem lokal erhalten.
          </div>
          <form action="/api/intake" method="post" encType="multipart/form-data" className="form-stack">
            <input type="hidden" name="kind" value="telegram-packet" />
            <input type="hidden" name="redirectTab" value="comms" />
            <div className="field">
              <label htmlFor="tg-title">Paket-Titel</label>
              <input id="tg-title" name="title" required placeholder="Kurze mobile Überschrift" />
            </div>
            <div className="field">
              <label htmlFor="tg-priority">Priorität</label>
              <select id="tg-priority" name="priority" defaultValue="normal">
                <option value="critical">kritisch</option>
                <option value="high">hoch</option>
                <option value="normal">normal</option>
                <option value="briefing">briefing</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="tg-message">Nachricht</label>
              <textarea id="tg-message" name="message" required placeholder="Was soll dein mobiles Ich bekommen?" />
            </div>
            <div className="field">
              <label htmlFor="tg-files">Anhänge</label>
              <input id="tg-files" name="attachments" type="file" multiple />
              <div className="form-note">Optional: Dateien, die du dir zusammen mit der mobilen Nachricht direkt an Telegram schicken willst.</div>
            </div>
            <div className="form-actions">
              <button type="submit" className="button button-primary">An Telegram senden</button>
            </div>
          </form>
        </div>
      </div>

      <div className="comms-support-stack">
        <DisclosureCard title="Wohin gehört was?" summary="Nur öffnen, wenn du die Eingangslanes nachschlagen willst.">
          <ul className="data-list compact">
            <li><strong>Brain Dump</strong>: rohe Gedanken, halbe Ideen, Referenzen, Richtungen. Vivi soll zuerst verstehen, sortieren und Research anstoßen.</li>
            <li><strong>Arbeitsauftrag</strong>: ein klarer Wunsch oder ein Projektziel ist schon erkennbar, aber Umfang und Struktur müssen noch gebaut werden.</li>
            <li><strong>Baumodus</strong>: du weißt schon konkret, was gebaut, geprüft oder repariert werden soll.</li>
          </ul>
        </DisclosureCard>

        <DisclosureCard
          title="Mobile Spuren und Telegram"
          summary={`Relay ${data.telegramRelay.inboundReady ? 'bereit' : 'lokal'} · Eingang ${data.telegramInbox.length} · Ausgang ${data.telegramOutbox.length}`}
        >
          <div className="disclosure-stack">
            <div className="form-card compact-card-shell">
              <strong>Telegram-Eingang synchronisieren</strong>
              <div className="form-help">
                Hole neue Telegram-Bot-Nachrichten bei Bedarf in LIONCOM. Mobil bleibt ein Fallback-Kanal: nach außen eskaliert nur, was wirklich kritisch oder vertrauensbrechend ist.
              </div>
              <div className="detail" style={{ marginBottom: 14 }}>{data.telegramRelay.detail}</div>
              <div className="list-meta" style={{ marginBottom: 14 }}>
                <span>eingang {data.telegramRelay.inboundReady ? 'aktiv' : 'offline'}</span>
                <span>ausgang {data.telegramRelay.outboundReady ? 'aktiv' : 'nur lokal gequeued'}</span>
                <span>{data.telegramRelay.criticalOnly ? 'nur kritische Mobile-Policy' : 'offenes Mobile-Relay'}</span>
              </div>
              <form action="/api/telegram" method="post" className="form-stack">
                <input type="hidden" name="mode" value="poll" />
                <input type="hidden" name="redirectTab" value="comms" />
                <div className="form-actions">
                  <button type="submit" className="button button-primary">Telegram jetzt abrufen</button>
                </div>
              </form>
            </div>

            <div className="list-grid">
              <BridgeCard title="Telegram-Eingang" entries={data.telegramInbox} emptyMessage="Noch kein eingehendes Telegram-Paket gespeichert." />
              <BridgeCard title="Telegram-Ausgang" entries={data.telegramOutbox} emptyMessage="Noch kein ausgehendes Telegram-Paket gespeichert." />
            </div>

            <div className="list-card compact-card-shell">
              <strong>Telegram-Kurzbefehle</strong>
              <div className="form-help" style={{ marginBottom: 14 }}>
                Mobil bleibt kurz: Dumps, Arbeit, Research, Vivi, Vega, Repair und Status. Alles andere gehört ins Board.
              </div>
              <div className="quick-command-grid">
                {quickCommands.map((command) => (
                  <button key={command.label} type="button" className="quick-command" onClick={() => onCopy(command.command, command.label)}>
                    <strong>{command.label}</strong>
                    <span>{command.detail}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </DisclosureCard>

        <DisclosureCard
          title="Zuletzt eingereihte Signale"
          summary={`Brain Dumps ${data.brainDump.length} · Arbeitsaufträge ${data.workIntake.length}`}
        >
          <div className="list-grid">
            <div className="list-card compact-card-shell">
              <strong>Letzte Brain Dumps</strong>
              {data.brainDump.length > 0 ? (
                <ul className="data-list">
                  {data.brainDump.map((entry) => (
                    <li key={entry.id}>
                      <div className="list-title">
                        <span>{entry.summary}</span>
                        <StatusPill value={entry.status} tone="info" />
                      </div>
                      {entry.category ? <div className="detail" style={{ marginTop: 8 }}>Kategorie: {entry.category}</div> : null}
                      {entry.attachmentCount ? <div className="detail" style={{ marginTop: 8 }}>Anhänge: {entry.attachments?.join(', ')}</div> : null}
                      <div className="list-meta" style={{ marginTop: 8 }}>
                        <span>{entry.id}</span>
                        <span>{formatMoment(entry.addedAt)}</span>
                      </div>
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="empty-state">Noch kein Brain Dump gespeichert.</div>
              )}
            </div>

            <div className="list-card compact-card-shell">
              <strong>Eingereihte Arbeitsaufträge</strong>
              {data.workIntake.length > 0 ? (
                <ul className="data-list">
                  {data.workIntake.map((entry) => (
                    <li key={entry.id}>
                      <div className="list-title">
                        <span>{entry.title}</span>
                        <StatusPill value={entry.urgency} tone={toneForUrgency(entry.urgency)} />
                      </div>
                      {entry.category ? <div className="detail" style={{ marginTop: 8 }}>Kategorie: {entry.category}</div> : null}
                      {entry.attachmentCount ? <div className="detail" style={{ marginTop: 8 }}>Anhänge: {entry.attachments?.join(', ')}</div> : null}
                      <div className="detail" style={{ marginTop: 8 }}>{entry.summary}</div>
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="empty-state">Noch kein Arbeitsauftrag eingereiht.</div>
              )}
            </div>
          </div>
        </DisclosureCard>
      </div>
    </section>
  );
}

function CodexTab({ data }: { data: ControlRoomData }) {
  return (
    <section className="panel tab-section">
      <div className="hero-headline">
        <div>
          <span className="eyebrow">Vivi und Vega // konkrete Arbeit</span>
          <h3>Vivi + Vega</h3>
        </div>
      </div>

      <div className="bridge-deck-grid">
        <div className="bridge-form-grid">
          <div className="vivi-path-grid bridge-span">
            <button type="button" className="vivi-path-card" onClick={() => document.querySelector<HTMLElement>('[data-anchor="vivi-mission-form"]')?.scrollIntoView({ behavior: 'smooth', block: 'start' })}>
              <span className="eyebrow">Mission</span>
              <strong>Vivi-Mission</strong>
              <span>Klare operative Aufgabe direkt in Vivi-Queue und Work Intake.</span>
            </button>
            <button type="button" className="vivi-path-card" onClick={() => document.querySelector<HTMLElement>('[data-anchor="vivi-chat-workspace"]')?.scrollIntoView({ behavior: 'smooth', block: 'start' })}>
              <span className="eyebrow">Chat</span>
              <strong>Vivi-Chat</strong>
              <span>Themen-Tabs, Wunschpfad und sichtbare Provider-Wahrheit.</span>
            </button>
            <button type="button" className="vivi-path-card" onClick={() => document.querySelector<HTMLElement>('[data-anchor="codex-chat-form"]')?.scrollIntoView({ behavior: 'smooth', block: 'start' })}>
              <span className="eyebrow">Live</span>
              <strong>Vega-Chat</strong>
              <span>Kurz mit Vega schärfen, prüfen oder technische Richtung setzen.</span>
            </button>
            <button type="button" className="vivi-path-card" onClick={() => document.querySelector<HTMLElement>('[data-anchor="codex-command-form"]')?.scrollIntoView({ behavior: 'smooth', block: 'start' })}>
              <span className="eyebrow">Paket</span>
              <strong>Vega-Paket</strong>
              <span>Technische Arbeit als sauberes Umsetzungs- oder Review-Paket.</span>
            </button>
          </div>

          <ViviChatWorkspace desktop={data.desktop} />

          <div className="list-card bridge-span">
            <strong>Arbeitsweg wählen</strong>
            <ul className="data-list compact">
              <li><strong>Vivi-Chat</strong>: wenn Vivi in einem eigenen Themen-Tab mit Provider-Wunsch und Verlauf arbeiten soll.</li>
              <li><strong>Vivi-Mission</strong>: wenn Vivi eine konkrete Mission übernehmen und sichtbar zurückmelden soll.</li>
              <li><strong>Vega-Chat</strong>: wenn du live mit mir etwas ausarbeiten, schärfen oder kurz prüfen willst.</li>
              <li><strong>Vega-Paket</strong>: wenn die technische Arbeit klar ist und direkt gebaut, gefixt oder geprüft werden soll.</li>
            </ul>
          </div>

          <div className="form-card" data-anchor="codex-chat-form">
            <strong>Mit Vega im Board sprechen</strong>
            <div className="form-help">
              Erst die Nachricht schreiben. Kategorie, Referenz und Kontext bleiben optional.
            </div>
            <form action="/api/intake" method="post" className="form-stack">
              <input type="hidden" name="kind" value="codex-chat" />
              <input type="hidden" name="redirectTab" value="codex" />
              <div className="field">
                <label htmlFor="codex-chat-message">Nachricht</label>
                <textarea id="codex-chat-message" name="message" required placeholder="Schreib natürlich. Vega soll von hier aus arbeiten können, ohne dass du perfekte Prompts bauen musst." />
              </div>
              <details className="field-group-details">
                <summary>Optionalen Kontext ergänzen</summary>
                <div className="field-group-stack">
                  <CategoryField
                    id="codex-chat-category"
                    name="category"
                    label="Kategorie"
                    options={CODEX_CHAT_CATEGORY_OPTIONS}
                    defaultValue="live-sync"
                  />
                  <div className="field">
                    <label htmlFor="codex-chat-reference">Referenz</label>
                    <input id="codex-chat-reference" name="reference" placeholder="Task-, Missions-, Datei- oder Report-Referenz" />
                  </div>
                  <div className="field">
                    <label htmlFor="codex-chat-context">Kontext</label>
                    <input id="codex-chat-context" name="context" placeholder="Lane, Projekt oder Anlass" />
                  </div>
                </div>
              </details>
              <div className="form-actions">
                <button type="submit" className="button button-primary">An Vega senden</button>
              </div>
            </form>
          </div>

          <div className="form-card" data-anchor="codex-command-form">
            <strong>Vega-Paket anlegen</strong>
            <div className="form-help">
              Nur Titel und Auftrag gehören in den ersten Griff. Alles andere bleibt optional.
            </div>
            <form action="/api/intake" method="post" className="form-stack">
              <input type="hidden" name="kind" value="codex-command" />
              <input type="hidden" name="redirectTab" value="codex" />
              <div className="field">
                <label htmlFor="codex-title">Auftragstitel</label>
                <input id="codex-title" name="title" required placeholder="Was soll Vega übernehmen?" />
              </div>
              <div className="field">
                <label htmlFor="codex-request">Auftrag</label>
                <textarea id="codex-request" name="rawRequest" required placeholder="Beschreibe genau, was Vega analysieren, bauen, debuggen oder verbessern soll." />
              </div>
              <details className="field-group-details">
                <summary>Optionalen Kontext ergänzen</summary>
                <div className="field-group-stack">
                  <CategoryField
                    id="codex-category"
                    name="category"
                    label="Kategorie"
                    options={CODEX_COMMAND_CATEGORY_OPTIONS}
                    defaultValue="implementation"
                  />
                  <div className="field">
                    <label htmlFor="codex-context">Kontext</label>
                    <input id="codex-context" name="context" placeholder="Dashboard, Bugfix, UI-Pass, Integration, Review..." />
                  </div>
                  <div className="field">
                    <label htmlFor="codex-reference">Referenz</label>
                    <input id="codex-reference" name="reference" placeholder="Task-, Datei- oder Report-Referenz" />
                  </div>
                  <div className="field">
                    <label htmlFor="codex-comment">Operator-Hinweis</label>
                    <input id="codex-comment" name="operatorComment" placeholder="Optionale Notiz, Nuance oder rote Linie" />
                  </div>
                  <div className="field">
                    <label htmlFor="codex-priority">Priorität</label>
                    <select id="codex-priority" name="priority" defaultValue="normal">
                      <option value="critical">kritisch</option>
                      <option value="high">hoch</option>
                      <option value="normal">normal</option>
                      <option value="explore">erkunden</option>
                    </select>
                  </div>
                </div>
              </details>
              <div className="form-actions">
                <button type="submit" className="button button-primary">Für Vega einreihen</button>
              </div>
            </form>
          </div>

          <div className="form-card" data-anchor="vivi-mission-form">
            <strong>Direkte Vivi-Mission</strong>
            <div className="form-help">
              Erst Missionstitel und Mission. Ergebnis, Priorität und Vorsichtshinweise nur bei Bedarf.
            </div>
            <form action="/api/intake" method="post" className="form-stack">
              <input type="hidden" name="kind" value="vivi-command" />
              <input type="hidden" name="redirectTab" value="codex" />
              <div className="field">
                <label htmlFor="vivi-title">Missionstitel</label>
                <input id="vivi-title" name="title" required placeholder="Was soll Vivi übernehmen?" />
              </div>
              <div className="field">
                <label htmlFor="vivi-request">Mission</label>
                <textarea id="vivi-request" name="rawRequest" required placeholder="Beschreibe die konkrete Mission. Referenzen sollen die Richtung geben, außer du willst ausdrücklich eine sehr enge Nähe zur Vorlage." />
              </div>
              <details className="field-group-details">
                <summary>Optionalen Kontext ergänzen</summary>
                <div className="field-group-stack">
                  <CategoryField
                    id="vivi-category"
                    name="category"
                    label="Kategorie"
                    options={VIVI_COMMAND_CATEGORY_OPTIONS}
                    defaultValue="execution"
                  />
                  <div className="field">
                    <label htmlFor="vivi-context">Kontext</label>
                    <input id="vivi-context" name="context" placeholder="Projekt-Lane, Bauphase, betroffene Fläche..." />
                  </div>
                  <div className="field">
                    <label htmlFor="vivi-reference">Referenz</label>
                    <input id="vivi-reference" name="reference" placeholder="Mission-, Datei- oder Report-Referenz" />
                  </div>
                  <div className="field">
                    <label htmlFor="vivi-outcome">Gewünschtes Ergebnis</label>
                    <input id="vivi-outcome" name="desiredOutcome" placeholder="Was soll wahr oder nutzbar sein, wenn Vivi fertig ist?" />
                  </div>
                  <div className="field">
                    <label htmlFor="vivi-comment">Operator-Hinweis</label>
                    <input id="vivi-comment" name="operatorComment" placeholder="Optionale Notiz, Vorsicht oder Nuance für Vivi" />
                  </div>
                  <div className="field">
                    <label htmlFor="vivi-priority">Priorität</label>
                    <select id="vivi-priority" name="priority" defaultValue="normal">
                      <option value="critical">kritisch</option>
                      <option value="high">hoch</option>
                      <option value="normal">normal</option>
                      <option value="explore">erkunden</option>
                    </select>
                  </div>
                </div>
              </details>
              <div className="form-actions">
                <button type="submit" className="button button-primary">An Vivi übergeben</button>
              </div>
            </form>
          </div>

          <div className="list-card">
            <strong>Vivi/Vega-Leitplanken</strong>
            <ul className="data-list compact">
              <li>Dieser Bereich hat drei belastbare Lanes: Board-Chat mit Vega, strukturierte Vega-Pakete und direkte Vivi-Missionen.</li>
              <li>Vega-Chat wird in die technische Arbeitslane gespiegelt, damit Board-Nachrichten nicht zwischen Sessions verschwinden.</li>
              <li>Vivi-Pakete werden ins Work Intake gespiegelt, damit der bestehende Builder-Flow intakt bleibt.</li>
              <li>Vivi-Schritte lassen sich mit kurzem Kommentar direkt zurück an Vega reichen.</li>
              <li>Vega ist für harten Code, Architektur, Debugging und Verifikation. Vivi ist für Umsetzung, Zerlegung und Rückmeldung.</li>
            </ul>
          </div>
        </div>

        <div className="list-grid bridge-feed-grid">
          <AutonomyOverviewCard autonomy={data.autonomy} />
          <CodexRuntimeCard runtime={data.codexRuntime} />
          <ClaimLedgerCard claims={data.autonomy.activeClaims} staleClaims={data.autonomy.staleClaims} />
          <CodexChatThreadCard entries={data.codexChat} />
          <ViviStepRelayCard entries={data.viviSteps} />
          <ViviReportRelayCard entries={data.viviReports} />
          <BridgeCard title="Letzte Vivi-Pakete" entries={data.viviCommandQueue} emptyMessage="Noch kein Vivi-Paket eingereiht." />
          <BridgeCard title="Letzte Vega-Pakete" entries={data.codexInbox} emptyMessage="Noch kein Vega-Paket eingereiht." />
        </div>
      </div>
    </section>
  );
}

function ViviChatWorkspace({ desktop }: { desktop: DesktopDiagnostics }) {
  const router = useRouter();
  const [snapshot, setSnapshot] = useState<ViviChatSnapshot | null>(null);
  const [activeSessionId, setActiveSessionId] = useState('');
  const [titleDraft, setTitleDraft] = useState('');
  const [topicDraft, setTopicDraft] = useState('');
  const [providerMode, setProviderMode] = useState<ViviProviderMode>('cloud');
  const [providerPreset, setProviderPreset] = useState<ViviProviderPreset>('chatgpt');
  const [requestedModel, setRequestedModel] = useState('gpt-5.4');
  const [modelCatalog, setModelCatalog] = useState<ViviModelCatalog | null>(null);
  const [messageDraft, setMessageDraft] = useState('');
  const [isBusy, setIsBusy] = useState(false);
  const [chatError, setChatError] = useState<string | null>(null);
  const [chatNotice, setChatNotice] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function loadSnapshot() {
      setChatError(null);
      try {
        const response = await fetch('/api/vivi-chat', { cache: 'no-store' });
        if (!response.ok) throw new Error('Vivi-Chat konnte nicht geladen werden.');
        const next = await response.json() as ViviChatSnapshot;
        if (!cancelled) setSnapshot(next);
      } catch (error) {
        if (!cancelled) setChatError(error instanceof Error ? error.message : 'Vivi-Chat ist gerade nicht verfügbar.');
      }
    }

    void loadSnapshot();

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!snapshot) return;
    const ids = new Set(snapshot.sessions.map((session) => session.id));
    const stored = window.localStorage.getItem(VIVI_CHAT_ACTIVE_SESSION_KEY);
    const next = activeSessionId && ids.has(activeSessionId)
      ? activeSessionId
      : stored && ids.has(stored)
        ? stored
        : snapshot.activeSessionId || snapshot.sessions[0]?.id || '';

    if (next && next !== activeSessionId) {
      setActiveSessionId(next);
    }
  }, [snapshot, activeSessionId]);

  useEffect(() => {
    if (!activeSessionId) return;
    window.localStorage.setItem(VIVI_CHAT_ACTIVE_SESSION_KEY, activeSessionId);
  }, [activeSessionId]);

  const activeSession = useMemo(
    () => snapshot?.sessions.find((session) => session.id === activeSessionId) || snapshot?.sessions[0],
    [snapshot, activeSessionId],
  );
  const activeMessages = useMemo(
    () => snapshot?.messages.filter((message) => message.sessionId === activeSession?.id) || [],
    [snapshot, activeSession],
  );
  const providerOptions = VIVI_PROVIDER_OPTIONS.filter((option) => option.mode === providerMode);
  const modelOptions = modelsForProvider(modelCatalog ?? { models: [] }, providerPreset, providerMode);

  useEffect(() => {
    if (!activeSession) return;
    setTitleDraft(activeSession.title);
    setTopicDraft(activeSession.topic);
    setProviderMode(normalizeViviProviderMode(activeSession.providerMode, activeSession.providerPreset));
    setProviderPreset(activeSession.providerPreset);
    setRequestedModel(activeSession.requestedModel || defaultViviModel(activeSession.providerPreset, activeSession.providerMode));
    setMessageDraft('');
  }, [activeSession?.id]);

  useEffect(() => {
    let cancelled = false;

    async function loadCatalog() {
      try {
        const response = await fetch('/api/vivi-model-catalog', { cache: 'no-store' });
        if (!response.ok) throw new Error('Modellkatalog nicht erreichbar.');
        const catalog = await response.json() as ViviModelCatalog;
        if (!cancelled) setModelCatalog(catalog);
      } catch {
        if (!cancelled) setModelCatalog(null);
      }
    }

    void loadCatalog();

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!activeSession || !modelCatalog) return;
    const normalized = normalizeViviRequestedModel(providerPreset, requestedModel, providerMode, modelCatalog);
    if (normalized !== requestedModel) setRequestedModel(normalized);
  }, [activeSession, modelCatalog, providerMode, providerPreset, requestedModel]);

  async function postViviChat(payload: Record<string, unknown>, successMessage: string) {
    setIsBusy(true);
    setChatError(null);
    setChatNotice(null);
    try {
      const response = await fetch('/api/vivi-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result?.error || 'Vivi-Chat konnte nicht aktualisiert werden.');
      setSnapshot(result.snapshot as ViviChatSnapshot);
      setChatNotice(successMessage);
      router.refresh();
      return result.snapshot as ViviChatSnapshot;
    } catch (error) {
      setChatError(error instanceof Error ? error.message : 'Vivi-Chat konnte nicht aktualisiert werden.');
      return null;
    } finally {
      setIsBusy(false);
    }
  }

  async function createSession() {
    const next = await postViviChat({
      action: 'create-session',
      title: 'Neuer Vivi-Chat',
      topic: 'Neues Thema',
      providerMode,
      providerPreset,
      requestedModel,
    }, 'Neuer Vivi-Chat angelegt.');

    if (next?.activeSessionId) {
      setActiveSessionId(next.activeSessionId);
    }
  }

  async function saveSession(applyToRuntime: boolean) {
    if (!activeSession) return;
    await postViviChat({
      action: 'update-session',
      sessionId: activeSession.id,
      title: titleDraft,
      topic: topicDraft,
      providerMode,
      providerPreset,
      requestedModel,
      applyToRuntime,
    }, applyToRuntime ? 'Wunschpfad in Runtime gespeichert.' : 'Chat-Tab gespeichert.');
  }

  async function sendMessage() {
    if (!activeSession || !messageDraft.trim()) return;
    const sentMessage = messageDraft;
    const next = await postViviChat({
      action: 'send-message',
      sessionId: activeSession.id,
      title: titleDraft,
      topic: topicDraft,
      providerMode,
      providerPreset,
      requestedModel,
      message: sentMessage,
    }, 'Nachricht an Vivi gesendet und in Queue/Work Intake gespiegelt.');

    if (next) setMessageDraft('');
  }

  function selectMode(nextMode: ViviProviderMode) {
    const nextPreset = nextMode === 'cloud'
      ? 'chatgpt'
      : providerPreset === 'ollama'
        ? 'ollama'
        : 'lmstudio';
    setProviderMode(nextMode);
    setProviderPreset(nextPreset);
    setRequestedModel(normalizeViviRequestedModel(nextPreset, requestedModel, nextMode, modelCatalog ?? undefined));
  }

  function selectPreset(nextPreset: ViviProviderPreset) {
    const nextMode = providerModeForPreset(nextPreset, providerMode);
    setProviderPreset(nextPreset);
    setProviderMode(nextMode);
    setRequestedModel(normalizeViviRequestedModel(nextPreset, requestedModel, nextMode, modelCatalog ?? undefined));
  }

  return (
    <div className="form-card bridge-span vivi-chat-workspace" data-anchor="vivi-chat-workspace">
      <div className="vivi-chat-header">
        <div>
          <span className="eyebrow">Vivi-Chat // Themen-Tabs</span>
          <strong>Vivi-Arbeitsraum</strong>
          <div className="form-help">
            Jeder Tab speichert Thema, Wunschpfad und Modellwunsch. Beim Senden wird daraus gleichzeitig eine Vivi-Queue und ein Work-Intake-Eintrag.
          </div>
        </div>
        <button type="button" className="button button-primary" onClick={createSession} disabled={isBusy}>
          Neuer Vivi-Chat
        </button>
      </div>

      <div className="vivi-chat-tabbar">
        <div className="vivi-chat-tabs" role="tablist" aria-label="Vivi chat sessions">
          {snapshot?.sessions.length ? snapshot.sessions.map((session) => (
            <button
              type="button"
              key={session.id}
              className={`vivi-chat-tab ${activeSession?.id === session.id ? 'is-active' : ''}`}
              onClick={() => setActiveSessionId(session.id)}
              role="tab"
              aria-selected={activeSession?.id === session.id}
            >
              <span className="vivi-chat-tab-title">{session.title}</span>
              <span>{session.latestActivity || session.status}</span>
            </button>
          )) : (
            <div className="empty-state">Noch kein Vivi-Chat geladen.</div>
          )}
        </div>
      </div>

      <div className="vivi-chat-toolbar">
        <div className="field-group-inline">
          <div className="field">
            <label htmlFor="vivi-chat-title">Titel</label>
            <input id="vivi-chat-title" value={titleDraft} onChange={(event) => setTitleDraft(event.target.value)} placeholder="Chat-Titel" />
          </div>
          <div className="field">
            <label htmlFor="vivi-chat-topic">Thema</label>
            <input id="vivi-chat-topic" value={topicDraft} onChange={(event) => setTopicDraft(event.target.value)} placeholder="Worum arbeitet Vivi hier?" />
          </div>
        </div>

        <div className="mode-toggle-row" aria-label="Wunschpfad">
          <button type="button" className={`mode-toggle-button ${providerMode === 'cloud' ? 'is-active' : ''}`} onClick={() => selectMode('cloud')}>
            Cloud
          </button>
          <button type="button" className={`mode-toggle-button ${providerMode === 'local' ? 'is-active' : ''}`} onClick={() => selectMode('local')}>
            Local
          </button>
        </div>

        <div className="field-group-inline">
          <div className="field">
            <label htmlFor="vivi-chat-provider">Tab-Wunsch</label>
            <select id="vivi-chat-provider" value={providerPreset} onChange={(event) => selectPreset(event.target.value as ViviProviderPreset)}>
              {providerOptions.map((option) => (
                <option key={`${option.mode}-${option.value}`} value={option.value}>{option.label}</option>
              ))}
            </select>
          </div>
          <div className="field">
            <label htmlFor="vivi-chat-model">Wunschmodell</label>
            <select id="vivi-chat-model" value={requestedModel} onChange={(event) => setRequestedModel(event.target.value)}>
              {modelOptions.length > 0 ? modelOptions.map((model) => (
                <option key={`${model.mode}-${model.provider}-${model.id}`} value={model.id}>
                  {model.label}
                </option>
              )) : (
                <option value={defaultViviModel(providerPreset, providerMode)}>
                  {defaultViviModel(providerPreset, providerMode)}
                </option>
              )}
            </select>
            <div className="form-help">
              Modelle kommen aus dem Provider-Katalog; kein freier Modelltext nötig.
            </div>
          </div>
        </div>

        <div className="form-actions">
          <button type="button" className="button" onClick={() => saveSession(false)} disabled={!activeSession || isBusy}>
            Tab speichern
          </button>
          <button type="button" className="button button-primary" onClick={() => saveSession(true)} disabled={!activeSession || isBusy}>
            Wunschpfad speichern
          </button>
        </div>
      </div>

      <div className="vivi-chat-runtime-glance">
        <div className="list-title">
          <span>Provider-Wahrheit</span>
          <StatusPill value={desktop.viviModelState || 'unknown'} tone={toneForModelState(desktop.viviModelState)} />
        </div>
        <div className="vivi-runtime-grid">
          <div>
            <span>Tab-Wunsch</span>
            <strong>{formatViviProviderTruth(providerMode, providerPreset, requestedModel)}</strong>
          </div>
          <div>
            <span>Persistierter Runtime-Wunsch</span>
            <strong>{formatProviderAndModel(desktop.viviRequestedProvider, desktop.viviRequestedModel)}</strong>
          </div>
          <div>
            <span>Effektive Runtime jetzt</span>
            <strong>{formatProviderAndModel(desktop.viviEffectiveProvider, desktop.viviEffectiveModel)}</strong>
          </div>
          <div>
            <span>Fallback / letzter Fehler</span>
            <strong>{desktop.viviModelLastError || desktop.viviFallbackModel || desktop.viviModelDetail || 'kein Fehler sichtbar'}</strong>
          </div>
        </div>
      </div>

      <div className="vivi-chat-thread" aria-live="polite">
        {activeMessages.length > 0 ? activeMessages.map((message) => (
          <article key={message.id} className={`vivi-chat-bubble role-${message.role}`}>
            <div className="list-title">
              <span>{message.role === 'operator' ? 'Du' : message.role === 'vivi' ? 'Vivi' : 'System'}</span>
              <StatusPill value={message.status} tone={toneForViviChatStatus(message.status)} />
            </div>
            <div className="vivi-chat-bubble-summary">{message.summary}</div>
            <div className="vivi-chat-bubble-message">
              {message.message.split('\n').map((line, index) => (
                <span key={`${message.id}-${index}`}>{line || ' '}</span>
              ))}
            </div>
            <div className="inline-meta">
              <span>{formatMoment(message.addedAt)}</span>
              <span>{formatViviProviderTruth(message.providerMode, message.providerPreset, message.requestedModel)}</span>
              {message.reference ? <span>{message.reference}</span> : null}
            </div>
          </article>
        )) : (
          <div className="empty-state">Dieser Vivi-Chat hat noch keinen Verlauf. Eine Nachricht erzeugt sofort Queue, Intake und Chat-Thread.</div>
        )}
      </div>

      <div className="vivi-chat-composer">
        <div className="field">
          <label htmlFor="vivi-chat-message">Nachricht an Vivi</label>
          <textarea
            id="vivi-chat-message"
            value={messageDraft}
            onChange={(event) => setMessageDraft(event.target.value)}
            placeholder="Schreib an Vivi. Der aktuelle Wunschpfad wird beim Senden persistiert."
          />
        </div>
        <div className="form-actions">
          <button type="button" className="button button-primary" onClick={sendMessage} disabled={!activeSession || !messageDraft.trim() || isBusy}>
            An Vivi senden
          </button>
          {chatNotice ? <span className="form-help">{chatNotice}</span> : null}
          {chatError ? <span className="form-error">{chatError}</span> : null}
        </div>
      </div>
    </div>
  );
}

function SystemTab({ data }: { data: ControlRoomData }) {
  return (
    <section className="panel tab-section">
      <div className="hero-headline">
        <div>
          <span className="eyebrow">Infrastruktur und Speicherlage</span>
          <h3>Systemübersicht</h3>
        </div>
      </div>

      <div className="split-layout system-layout">
        <div className="source-section">
          <div className="source-grid">
            {data.sources.map((source) => (
              <div className="source-card" key={source.path}>
                <strong>{source.name}</strong>
                <div className="list-title">
                  <span>{source.path}</span>
                  <StatusPill value={source.status} tone={toneForSourceStatus(source.status)} />
                </div>
                <div className="detail" style={{ marginTop: 8 }}>{source.detail}</div>
                {source.lastModified ? <div className="inline-meta" style={{ marginTop: 12 }}><span>aktualisiert</span><span>{formatMoment(source.lastModified)}</span></div> : null}
              </div>
            ))}
          </div>
        </div>

        <div className="list-grid">
          <div className="list-card">
            <strong>Git-Schiene</strong>
            <ul className="data-list">
              <li><div className="list-title"><span>Repository</span><span>{data.git.isRepo ? 'vorhanden' : 'fehlt'}</span></div></li>
              <li><div className="list-title"><span>Remote</span><span>{data.git.hasRemote ? 'konfiguriert' : 'nicht konfiguriert'}</span></div></li>
              <li><div className="list-title"><span>Branch</span><span>{data.git.branch}</span></div></li>
              <li><div className="list-title"><span>Letzter Commit</span><span>{data.git.lastCommit || 'keiner'}</span></div></li>
            </ul>
          </div>

          <div className="list-card">
            <strong>Telemetrielage</strong>
            <ul className="data-list compact">
              <li>Status: {data.telemetry.state.toUpperCase()}</li>
              <li>Quelle: {data.telemetry.source}</li>
              <li>Letztes Signal: {data.telemetry.lastUpdate ? formatMoment(data.telemetry.lastUpdate) : 'keins'}</li>
              <li>Antwortfähig: {data.telemetry.runtimeResponsive ? 'ja' : 'nein'}</li>
            </ul>
          </div>

          <DesktopDiagnosticsCard desktop={data.desktop} />

          <RemoteBridgeCard bridge={data.remoteBridge} freeze={data.freeze} githubSync={data.githubSync} />

          <AutonomySystemCard autonomy={data.autonomy} />

          <QualificationStatusCard qualification={data.qualification} />

          <QualificationEvidenceCard qualification={data.qualification} />

          <DesktopLogCard desktop={data.desktop} />

          <div className="list-card">
            <strong>Systemprinzipien</strong>
            <ul className="data-list compact">
              <li>Keine sichtbare OpenClaw- oder Gateway-Sprache in der App-Hülle.</li>
              <li>Die Hauptansicht zeigt Missionslage statt einer rohen Logwand.</li>
              <li>Operator-Input wird zuerst lokal gesichert und dann in Vivi- und Vega-fähige Pakete übersetzt.</li>
              <li>Kritische Hinweise bleiben bedienbar statt nur als passiver roter Text zu enden.</li>
              <li>Diese Oberfläche wird in Richtung eines echten lokalen Mac-Command-OS gehärtet.</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}

function DesktopDiagnosticsCard({ desktop }: { desktop: DesktopDiagnostics }) {
  return (
    <div className="list-card">
      <strong>Desktop-Lage</strong>
      <ul className="data-list compact">
        <li><div className="list-title"><span>Modus</span><span>{desktop.mode}</span></div></li>
        <li><div className="list-title"><span>Startstatus</span><span>{desktop.startupState}</span></div></li>
        <li><div className="list-title"><span>Workspace</span><span>{desktop.workspaceValid ? 'gültig' : 'ungültig'}</span></div></li>
        <li><div className="list-title"><span>Server-Port</span><span>{desktop.serverPort || 'nicht exponiert'}</span></div></li>
        <li><div className="list-title"><span>Version</span><span>{desktop.appVersion || 'unknown'}</span></div></li>
        <li><div className="list-title"><span>Signatur</span><span>{desktop.signingMode}</span></div></li>
        <li><div className="list-title"><span>Notarisiert</span><span>{desktop.notarized ? 'ja' : 'nein'}</span></div></li>
        <li><div className="list-title"><span>asar</span><span>{desktop.asarEnabled ? 'aktiv' : 'deaktiviert'}</span></div></li>
      </ul>
      <div className="detail" style={{ marginTop: 10 }}>{desktop.startupDetail}</div>
      <div className="inline-meta" style={{ marginTop: 12 }}>
        <span>workspace</span>
        <span>{desktop.workspaceRoot}</span>
      </div>
      <div className="badge-row" style={{ marginTop: 12 }}>
        {desktop.requiredMarkers.map((marker) => (
          <span className="mini-badge" key={marker.name}>
            <span className={`mini-dot ${marker.present ? 'tone-ok' : 'tone-critical'}`} />
            {marker.name}
          </span>
        ))}
      </div>
      {desktop.issues.length > 0 ? (
        <div className="relay-stack" style={{ marginTop: 14 }}>
          {desktop.issues.map((issue, index) => (
            <div className="relay-item" key={`${issue.severity}-${index}`}>
              <div className="list-title">
                <span>{issue.message}</span>
                <StatusPill value={issue.severity} tone={issue.severity === 'critical' ? 'critical' : 'warning'} />
              </div>
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
}

function DesktopLogCard({ desktop }: { desktop: DesktopDiagnostics }) {
  return (
    <div className="list-card">
      <strong>Desktop-Diagnostik</strong>
      <div className="inline-meta" style={{ marginBottom: 12 }}>
        <span>settings</span>
        <span>{desktop.settingsPath}</span>
      </div>
      <div className="inline-meta" style={{ marginBottom: 12 }}>
        <span>status</span>
        <span>{desktop.statusPath}</span>
      </div>
      <div className="inline-meta" style={{ marginBottom: 12 }}>
        <span>log</span>
        <span>{desktop.logPath}</span>
      </div>
      {desktop.logTail.length > 0 ? (
        <div className="relay-stack">
          {desktop.logTail.map((line, index) => (
            <div className="relay-item" key={`${index}-${line}`}>
              <div className="detail" style={{ whiteSpace: 'pre-wrap' }}>{line}</div>
            </div>
          ))}
        </div>
      ) : (
        <div className="empty-state">No desktop log lines are visible yet.</div>
      )}
    </div>
  );
}

function QualificationStatusCard({ qualification }: { qualification: QualificationSnapshot }) {
  return (
    <div className="list-card">
      <strong>Qualification posture</strong>
      <ul className="data-list compact">
        <li><div className="list-title"><span>Overall state</span><StatusPill value={qualification.overallState} tone={toneForQualificationState(qualification.overallState)} /></div></li>
        <li><div className="list-title"><span>Release decision</span><StatusPill value={qualification.releaseDecision} tone={toneForQualificationState(qualification.releaseDecision === 'approved' ? 'ready' : qualification.releaseDecision === 'conditional' ? 'warning' : 'blocked')} /></div></li>
        <li><div className="list-title"><span>Completed sections</span><span>{qualification.completedSections} / {qualification.totalSections}</span></div></li>
        <li><div className="list-title"><span>Updated</span><span>{qualification.updatedAt ? formatMoment(qualification.updatedAt) : 'not run yet'}</span></div></li>
      </ul>
      <div className="detail" style={{ marginTop: 10 }}>{qualification.summary}</div>
      <div className="relay-stack" style={{ marginTop: 14 }}>
        {qualification.sections.map((section) => (
          <div className="relay-item" key={section.id}>
            <div className="list-title">
              <span>{section.id} · {section.title}</span>
              <StatusPill value={section.state} tone={toneForQualificationSection(section.state)} />
            </div>
            <div className="detail" style={{ marginTop: 8 }}>{section.detail}</div>
            <div className="inline-meta" style={{ marginTop: 10 }}>
              <span>evidence</span>
              <span>{section.evidencePath}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function QualificationEvidenceCard({ qualification }: { qualification: QualificationSnapshot }) {
  return (
    <div className="list-card">
      <strong>Release blockers and scope</strong>
      <div className="detail" style={{ marginBottom: 12 }}>This deck separates what is already safe to use from what still must not be treated as closed.</div>
      <div className="relay-stack">
        <div className="relay-item">
          <div className="list-title">
            <span>Blockers</span>
            <StatusPill value={qualification.blockers.length ? String(qualification.blockers.length) : 'clear'} tone={qualification.blockers.length ? 'critical' : 'ok'} />
          </div>
          <MiniList items={qualification.blockers} emptyMessage="No blocker is recorded." />
        </div>
        <div className="relay-item">
          <div className="list-title">
            <span>Residual risks</span>
            <StatusPill value={qualification.residualRisks.length ? String(qualification.residualRisks.length) : 'clear'} tone={qualification.residualRisks.length ? 'warning' : 'ok'} />
          </div>
          <MiniList items={qualification.residualRisks} emptyMessage="No residual risk is recorded." />
        </div>
        <div className="relay-item">
          <div className="list-title">
            <span>Approved now</span>
            <StatusPill value={qualification.approvedFor.length ? String(qualification.approvedFor.length) : 'none'} tone="ok" />
          </div>
          <MiniList items={qualification.approvedFor} emptyMessage="No approved operating scope is recorded." />
        </div>
        <div className="relay-item">
          <div className="list-title">
            <span>Not approved yet</span>
            <StatusPill value={qualification.notApprovedFor.length ? String(qualification.notApprovedFor.length) : 'clear'} tone={qualification.notApprovedFor.length ? 'warning' : 'ok'} />
          </div>
          <MiniList items={qualification.notApprovedFor} emptyMessage="No restricted scope is recorded." />
        </div>
      </div>
    </div>
  );
}

function AlertCard({ alert, onOpenDeck }: { alert: SystemAlert; onOpenDeck: (tab: TabId, anchor?: string) => void }) {
  return (
    <div className={`alert-card severity-${alert.severity}`}>
      <div className="list-title">
        <span>{alert.title}</span>
        <StatusPill value={alert.severity} tone={toneForAlertSeverity(alert.severity)} />
      </div>
      <div className="detail" style={{ marginTop: 10 }}>{alert.detail}</div>
      <div className="detail" style={{ marginTop: 10 }}>{alert.recommendation}</div>
      <div className="inline-meta" style={{ marginTop: 12 }}>
        <span>quelle</span>
        <span>{alert.source}</span>
      </div>
      {alert.followThrough && alert.followThrough.length > 0 ? (
        <div className="detail" style={{ marginTop: 12 }}>
          <strong>Nächster Klarpfad</strong>
          <ul className="data-list compact" style={{ marginTop: 10 }}>
            {alert.followThrough.map((step) => (
              <li key={step}>{step}</li>
            ))}
          </ul>
        </div>
      ) : null}
      <div className="form-actions" style={{ marginTop: 14 }}>
        {alert.action === 'rescue' || alert.action === 'queue-night' ? (
          <form action="/api/intake" method="post" className="inline-form">
            <input type="hidden" name="kind" value="repair-request" />
            <input type="hidden" name="redirectTab" value="command" />
            <input type="hidden" name="title" value={alert.title} />
            <input type="hidden" name="problem" value={alert.detail} />
            <input type="hidden" name="source" value={alert.source} />
            <input type="hidden" name="recommendation" value={alert.recommendation} />
            <input type="hidden" name="severity" value={alert.severity === 'critical' ? 'critical' : 'high'} />
            <input type="hidden" name="mode" value={alert.action === 'rescue' ? 'rescue' : 'night-sweep'} />
            <button type="submit" className="button button-primary">
              {alert.action === 'rescue' ? 'Rettungspaket senden' : 'Nacht-Fix einreihen'}
            </button>
          </form>
        ) : null}
        {alert.action === 'review' ? (
          <button
            type="button"
            className="button"
            onClick={() => onOpenDeck(alert.actionTargetTab || 'research', alert.actionTargetAnchor)}
          >
            {alert.actionLabel || 'In Analyse prüfen'}
          </button>
        ) : null}
      </div>
    </div>
  );
}

function LioncomMark() {
  return (
    <svg className="lioncom-mark" viewBox="0 0 96 96" aria-hidden="true">
      <defs>
        <linearGradient id="lionStroke" x1="0%" x2="100%" y1="0%" y2="100%">
          <stop offset="0%" stopColor="#d4f6c5" />
          <stop offset="42%" stopColor="#91d289" />
          <stop offset="100%" stopColor="#7ed6c6" />
        </linearGradient>
      </defs>
      <path d="M48 6 L80 22 L80 52 C80 68 68 81 48 90 C28 81 16 68 16 52 L16 22 Z" fill="rgba(255,255,255,0.04)" stroke="url(#lionStroke)" strokeWidth="2.6" />
      <path d="M31 29 C36 22 42 18 48 18 C54 18 60 22 65 29" fill="none" stroke="url(#lionStroke)" strokeWidth="2.4" strokeLinecap="round" />
      <path d="M29 35 L39 29 L48 39 L57 29 L67 35" fill="none" stroke="url(#lionStroke)" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M36 49 C38 43 42 39 48 39 C54 39 58 43 60 49" fill="none" stroke="url(#lionStroke)" strokeWidth="2.6" strokeLinecap="round" />
      <path d="M37 58 L48 48 L59 58" fill="none" stroke="url(#lionStroke)" strokeWidth="3.6" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="48" cy="48" r="24" fill="none" stroke="rgba(210,246,197,0.14)" strokeWidth="1.2" strokeDasharray="4 6" />
      <path d="M48 16 L48 28" stroke="rgba(212,246,197,0.48)" strokeWidth="1.4" strokeLinecap="round" />
      <path d="M48 68 L48 80" stroke="rgba(212,246,197,0.48)" strokeWidth="1.4" strokeLinecap="round" />
      <path d="M16 48 L28 48" stroke="rgba(212,246,197,0.48)" strokeWidth="1.4" strokeLinecap="round" />
      <path d="M68 48 L80 48" stroke="rgba(212,246,197,0.48)" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );
}

function MiniList({ items, emptyMessage }: { items: string[]; emptyMessage: string }) {
  return items.length > 0 ? (
    <ul className="data-list compact">
      {items.map((item) => <li key={item}>{item}</li>)}
    </ul>
  ) : (
    <div className="empty-state">{emptyMessage}</div>
  );
}

function IntakeCard({ title, entries, emptyMessage }: { title: string; entries: WorkIntakeEntry[]; emptyMessage: string }) {
  return (
    <div className="list-card">
      <strong>{title}</strong>
      {entries.length > 0 ? (
        <ul className="data-list">
          {entries.map((entry) => (
            <li key={entry.id}>
              <div className="list-title">
                <span>{entry.title}</span>
                <StatusPill value={entry.urgency} tone={toneForUrgency(entry.urgency)} />
              </div>
              {entry.category ? <div className="detail" style={{ marginTop: 8 }}>Kategorie: {entry.category}</div> : null}
              {entry.attachmentCount ? <div className="detail" style={{ marginTop: 8 }}>Anhänge: {entry.attachments?.join(', ')}</div> : null}
              <div className="detail" style={{ marginTop: 8 }}>{entry.summary}</div>
              <div className="list-meta" style={{ marginTop: 8 }}>
                <span>{entry.id}</span>
                <span>{entry.status}</span>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <div className="empty-state">{emptyMessage}</div>
      )}
    </div>
  );
}

function FoundationTracksCard({
  blocks,
  roadmap,
}: {
  blocks: WorkBlockItem[];
  roadmap: ControlRoomData['roadmap'];
}) {
  const foundationBlocks = blocks
    .filter((block) => block.title.startsWith('Build Block'))
    .sort((left, right) => (right.overallScore || 0) - (left.overallScore || 0))
    .slice(0, 4);

  const focusBand = foundationBlocks.length > 0
    ? foundationBlocks
    : [...roadmap.now, ...roadmap.next]
      .filter((item) => item.title.startsWith('Build Block'))
      .slice(0, 4)
      .map((item) => ({
        id: item.id,
        title: item.title,
        lane: item.lane,
        stage: item.stage,
        owner: item.owner,
        priority: item.priority,
        summary: item.rationale,
        desiredOutcome: undefined,
        sourceRail: 'roadmap',
        overallScore: item.overallScore,
        active: item.actionWindow === 'now',
        requiresCodex: item.owner !== 'vivi',
        requiresOperator: false,
      }));

  return (
    <div className="panel tab-section compact-panel foundation-panel">
      <div className="hero-headline">
        <div>
          <span className="eyebrow">Nächste Systembasis</span>
          <h3>Basisblöcke</h3>
        </div>
      </div>
      <div className="detail foundation-summary">
        Diese Schiene hält die UI an die kommenden Hauptarbeiten gekoppelt: Remote-Bridge, Vivi-Work-Engine,
        Board-only Vega Rail und GitHub-/Freeze-Zuverlässigkeit.
      </div>
      {focusBand.length > 0 ? (
        <div className="foundation-grid">
          {focusBand.map((block) => (
            <article key={block.id} className="foundation-track-card">
              <div className="list-title">
                <span>{block.title}</span>
                <StatusPill
                  value={block.stage}
                  tone={block.stage === 'FREEZE' ? 'critical' : block.active ? 'ok' : 'warning'}
                />
              </div>
              <div className="badge-row">
                <span className="mini-badge"><span className="mini-dot tone-warning" />{block.priority}</span>
                <span className="mini-badge"><span className="mini-dot tone-info" />{block.owner}</span>
                <span className="mini-badge"><span className="mini-dot tone-ok" />{block.lane}</span>
                {typeof block.overallScore === 'number' ? (
                  <span className="mini-badge"><span className="mini-dot tone-info" />Score {block.overallScore.toFixed(1)}</span>
                ) : null}
              </div>
              <div className="detail foundation-track-summary">{block.summary}</div>
            </article>
          ))}
        </div>
      ) : (
        <div className="empty-state">Noch kein Basisblock sichtbar. Sobald Vivi oder Vega die Pipeline neu sortieren, erscheint die nächste Systembasis hier.</div>
      )}
    </div>
  );
}

function BridgeCard({ title, entries, emptyMessage }: { title: string; entries: BridgePacket[]; emptyMessage: string }) {
  return (
    <div className="list-card">
      <strong>{title}</strong>
      {entries.length > 0 ? (
        <ul className="data-list">
          {entries.map((entry) => (
            <li key={entry.id}>
              <div className="list-title">
                <span>{entry.title}</span>
                <StatusPill value={entry.status} tone={toneForPacketStatus(entry.status)} />
              </div>
              {entry.category ? <div className="detail" style={{ marginTop: 8 }}>Kategorie: {entry.category}</div> : null}
              {entry.attachmentCount ? <div className="detail" style={{ marginTop: 8 }}>Anhänge: {entry.attachments?.join(', ')}</div> : null}
              <div className="detail" style={{ marginTop: 8 }}>{entry.summary}</div>
              <div className="list-meta" style={{ marginTop: 8 }}>
                <span>{entry.id}</span>
                <span>{entry.delivery || entry.channel}</span>
                <span>{formatMoment(entry.addedAt)}</span>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <div className="empty-state">{emptyMessage}</div>
      )}
    </div>
  );
}

function WorkBlockCard({ blocks }: { blocks: WorkBlockItem[] }) {
  return (
    <div className="list-card">
      <strong>Generated work blocks</strong>
      {blocks.length > 0 ? (
        <ul className="data-list">
          {blocks.slice(0, 8).map((block) => (
            <li key={block.id}>
              <div className="list-title">
                <span>{block.title}</span>
                <StatusPill value={block.stage} tone={block.stage === 'FREEZE' ? 'critical' : block.active ? 'ok' : 'info'} />
              </div>
              <div className="badge-row">
                <span className="mini-badge"><span className="mini-dot tone-info" />{block.sourceRail}</span>
                <span className="mini-badge"><span className="mini-dot tone-warning" />{block.priority}</span>
                <span className="mini-badge"><span className="mini-dot tone-ok" />{block.lane}</span>
                <span className="mini-badge"><span className="mini-dot tone-info" />{block.owner}</span>
                {typeof block.overallScore === 'number' ? <span className="mini-badge"><span className="mini-dot tone-warning" />score {block.overallScore.toFixed(1)}</span> : null}
                {block.duplicateCount && block.duplicateCount > 1 ? <span className="mini-badge"><span className="mini-dot tone-info" />merged {block.duplicateCount}</span> : null}
              </div>
              <div className="detail" style={{ marginTop: 10 }}>{block.summary}</div>
              {block.desiredOutcome ? <div className="detail" style={{ marginTop: 8 }}>Outcome: {block.desiredOutcome}</div> : null}
            </li>
          ))}
        </ul>
      ) : (
        <div className="empty-state">No generated work block exists yet.</div>
      )}
    </div>
  );
}

function ExecutionRoadmapCard({ roadmap }: { roadmap: ControlRoomData['roadmap'] }) {
  const bands = [
    { label: 'Now', items: roadmap.now, tone: 'critical' as const },
    { label: 'Next', items: roadmap.next, tone: 'warning' as const },
    { label: 'Later', items: roadmap.later, tone: 'info' as const },
  ];

  return (
    <div className="list-card">
      <strong>Execution roadmap</strong>
      <div className="detail" style={{ marginBottom: 12 }}>{roadmap.focus}</div>
      <div className="relay-stack">
        {bands.map((band) => (
          <div className="relay-item" key={band.label}>
            <div className="list-title">
              <span>{band.label}</span>
              <StatusPill value={band.items.length ? `${band.items.length} items` : 'clear'} tone={band.tone} />
            </div>
            {band.items.length > 0 ? (
              <ul className="data-list compact" style={{ marginTop: 10 }}>
                {band.items.map((item) => (
                  <li key={item.id}>
                    <div className="list-title">
                      <span>{item.title}</span>
                      <span>{item.overallScore.toFixed(1)}</span>
                    </div>
                    <div className="badge-row">
                      <span className="mini-badge"><span className="mini-dot tone-warning" />{item.priority}</span>
                      <span className="mini-badge"><span className="mini-dot tone-info" />{item.lane}</span>
                      <span className="mini-badge"><span className="mini-dot tone-ok" />{item.owner}</span>
                    </div>
                    <div className="detail" style={{ marginTop: 8 }}>{item.rationale}</div>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="empty-state" style={{ marginTop: 10 }}>No item is currently ranked in this band.</div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function SubtaskCard({ subtasks }: { subtasks: SubtaskItem[] }) {
  return (
    <div className="list-card">
      <strong>Subtask queue</strong>
      {subtasks.length > 0 ? (
        <ul className="data-list">
          {subtasks.slice(0, 10).map((subtask) => (
            <li key={subtask.id}>
              <div className="list-title">
                <span>{subtask.title}</span>
                <StatusPill value={subtask.status} tone={subtask.status === 'done' ? 'ok' : subtask.status === 'active' ? 'warning' : 'info'} />
              </div>
              <div className="badge-row">
                <span className="mini-badge"><span className="mini-dot tone-info" />{subtask.blockId}</span>
                <span className="mini-badge"><span className="mini-dot tone-warning" />{subtask.lane}</span>
                <span className="mini-badge"><span className="mini-dot tone-ok" />{subtask.owner}</span>
              </div>
              <div className="detail" style={{ marginTop: 10 }}>{subtask.detail}</div>
            </li>
          ))}
        </ul>
      ) : (
        <div className="empty-state">No generated subtask is visible yet.</div>
      )}
    </div>
  );
}

function RoadmapSummaryCard({ roadmap }: { roadmap: ControlRoomData['roadmap'] }) {
  return (
    <div className="list-card">
      <strong>Priority logic</strong>
      <div className="detail" style={{ marginBottom: 12 }}>{roadmap.focus}</div>
      <MiniList items={roadmap.summary} emptyMessage="No roadmap summary is available yet." />
    </div>
  );
}

function DecisionListCard({ decisions, fallbackItems }: { decisions: DecisionItem[]; fallbackItems: string[] }) {
  if (decisions.length === 0) {
    return <MiniList items={fallbackItems} emptyMessage="No open decision currently extracted." />;
  }

  return (
    <ul className="data-list compact">
      {decisions.map((decision) => (
        <li key={decision.id}>
          <div className="list-title">
            <span>{decision.title}</span>
            <StatusPill value={decision.status} tone={decision.status === 'open' ? 'warning' : 'info'} />
          </div>
          <div className="detail" style={{ marginTop: 8 }}>{decision.reason}</div>
          <div className="detail" style={{ marginTop: 8 }}>Recommendation: {decision.recommendation}</div>
        </li>
      ))}
    </ul>
  );
}

function collectOperatorDecisions(data: ControlRoomData): OperatorDecisionSignal[] {
  const items: OperatorDecisionSignal[] = [];

  for (const decision of data.decisionQueue) {
    items.push({
      id: `decision-${decision.id}`,
      title: decision.title,
      detail: decision.reason,
      recommendation: decision.recommendation,
      tone: decision.status === 'open' ? 'warning' : 'info',
      targetTab: 'research',
    });
  }

  if (data.githubSync.state === 'blocked') {
    items.push({
      id: 'github-sync-blocked',
      title: 'GitHub-Schreibzugang ist blockiert',
      detail: data.githubSync.detail,
      recommendation: 'Entscheide, ob wir die Auth-Reparatur priorisieren oder bis zur lokalen Stabilisierung bewusst ohne Remote-Write weiterfahren.',
      tone: 'critical',
      targetTab: 'system',
    });
  }

  if (data.remoteBridge.state !== 'live-remote') {
    items.push({
      id: 'remote-bridge-pending',
      title: 'Remote-Bridge ist noch nicht live',
      detail: data.remoteBridge.detail,
      recommendation: 'Entscheide, wann die echte VPS-/Remote-Aktivierung scharf geschaltet werden soll, damit Vivi nicht lokal-only bleibt.',
      tone: data.remoteBridge.state === 'offline' ? 'critical' : 'warning',
      targetTab: 'system',
    });
  }

  if (data.qualification.releaseDecision !== 'approved') {
    items.push({
      id: 'release-posture',
      title: 'Produktfreigabe bleibt vorläufig konditional',
      detail: data.qualification.summary,
      recommendation: 'Entscheide morgen bewusst, welche Restgates vor echter Produktionsfreigabe zwingend geschlossen werden müssen.',
      tone: data.qualification.releaseDecision === 'blocked' ? 'critical' : 'warning',
      targetTab: 'system',
    });
  }

  for (const report of data.viviReports) {
    const operatorAction = report.operatorAction?.trim();
    const nextStep = report.nextStep?.trim();
    const commandRef = report.commandRef || report.id;
    const actionableText = operatorAction || nextStep;
    if (!actionableText) continue;

    const normalized = actionableText.toLowerCase();
    if (
      normalized.includes('no operator action requested')
      || normalized.includes('no next step supplied')
      || normalized.includes('sobald localhost wieder antwortet')
      || normalized.includes('board-laufumgebung')
    ) {
      continue;
    }

    const isBusinessTrack = commandRef.startsWith('FIN-PLATFORM-');
    items.push({
      id: `report-decision-${report.id}`,
      title: isBusinessTrack ? `Business-Entscheidung: ${report.title}` : `Entscheidung aus Vivi-Report: ${report.title}`,
      detail: report.summary,
      recommendation: actionableText,
      tone: isBusinessTrack ? 'warning' : 'info',
      targetTab: isBusinessTrack ? 'command' : 'research',
      targetAnchor: isBusinessTrack ? 'operator-decision-hub' : undefined,
    });
  }

  const seen = new Set<string>();
  return items.filter((item) => {
    const key = `${item.title}::${item.recommendation}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, 8);
}

function CodexRuntimeCard({ runtime }: { runtime: ControlRoomData['codexRuntime'] }) {
  return (
    <div className="list-card">
      <strong>Vega runtime</strong>
      <ul className="data-list compact">
        <li><div className="list-title"><span>State</span><span>{runtime.state}</span></div></li>
        <li><div className="list-title"><span>Pending operator messages</span><span>{runtime.pendingOperatorMessages}</span></div></li>
        <li><div className="list-title"><span>Queued packets</span><span>{runtime.queuedPackets}</span></div></li>
        <li><div className="list-title"><span>Latest reference</span><span>{runtime.latestReference || 'none'}</span></div></li>
        <li><div className="list-title"><span>Oldest pending</span><span>{runtime.oldestPendingMinutes !== undefined ? `${runtime.oldestPendingMinutes}m` : 'none'}</span></div></li>
        <li><div className="list-title"><span>Oldest queued</span><span>{runtime.oldestQueuedMinutes !== undefined ? `${runtime.oldestQueuedMinutes}m` : 'none'}</span></div></li>
        <li><div className="list-title"><span>Watcher posture</span><StatusPill value={runtime.stalePendingMessages ? 'attention' : 'clear'} tone={runtime.stalePendingMessages ? 'warning' : 'ok'} /></div></li>
      </ul>
      <div className="detail" style={{ marginTop: 10 }}>{runtime.detail}</div>
      <div className="detail" style={{ marginTop: 8 }}>Watcher: {runtime.watcherRecommendation}</div>
    </div>
  );
}

function AutonomyOverviewCard({ autonomy }: { autonomy: ControlRoomData['autonomy'] }) {
  return (
    <div className="list-card">
      <strong>Autonomy posture</strong>
      <ul className="data-list compact">
        <li><div className="list-title"><span>Readiness</span><StatusPill value={autonomy.readiness} tone={autonomy.readiness === 'ready' ? 'ok' : autonomy.readiness === 'warning' ? 'warning' : 'critical'} /></div></li>
        <li><div className="list-title"><span>Vivi loop</span><span>{autonomy.viviLoop.state}</span></div></li>
        <li><div className="list-title"><span>Vega loop</span><span>{autonomy.codexLoop.state}</span></div></li>
        <li><div className="list-title"><span>Active claims</span><span>{autonomy.activeClaims.length}</span></div></li>
        <li><div className="list-title"><span>Stale claims</span><span>{autonomy.staleClaims.length}</span></div></li>
      </ul>
      <div className="detail" style={{ marginTop: 10 }}>{autonomy.summary}</div>
      <div className="detail" style={{ marginTop: 8 }}>{autonomy.operatorFreedom}</div>
      <div className="relay-stack" style={{ marginTop: 14 }}>
        <div className="relay-item">
          <div className="list-title">
            <span>Vivi next dispatch</span>
            <StatusPill value={autonomy.viviLoop.state} tone={autonomy.viviLoop.state === 'ready' ? 'ok' : autonomy.viviLoop.state === 'busy' ? 'warning' : autonomy.viviLoop.state === 'attention' ? 'warning' : 'critical'} />
          </div>
          <div className="detail" style={{ marginTop: 8 }}>{autonomy.viviLoop.summary}</div>
          {autonomy.viviLoop.selectedTask ? (
            <div className="detail" style={{ marginTop: 8 }}>
              Next: {autonomy.viviLoop.selectedTask.title} ({autonomy.viviLoop.selectedTask.sourceRail})
            </div>
          ) : null}
        </div>
        <div className="relay-item">
          <div className="list-title">
            <span>Vega next dispatch</span>
            <StatusPill value={autonomy.codexLoop.state} tone={autonomy.codexLoop.state === 'ready' ? 'ok' : autonomy.codexLoop.state === 'busy' ? 'warning' : autonomy.codexLoop.state === 'attention' ? 'warning' : 'critical'} />
          </div>
          <div className="detail" style={{ marginTop: 8 }}>{autonomy.codexLoop.summary}</div>
          {autonomy.codexLoop.selectedTask ? (
            <div className="detail" style={{ marginTop: 8 }}>
              Next: {autonomy.codexLoop.selectedTask.title} ({autonomy.codexLoop.selectedTask.sourceRail})
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}

function ClaimLedgerCard({
  claims,
  staleClaims,
}: {
  claims: ControlRoomData['autonomy']['activeClaims'];
  staleClaims: ControlRoomData['autonomy']['staleClaims'];
}) {
  const visible = [...claims, ...staleClaims].slice(0, 8);

  return (
    <div className="list-card">
      <strong>Claim ledger</strong>
      {visible.length > 0 ? (
        <ul className="data-list">
          {visible.map((claim) => (
            <li key={claim.id}>
              <div className="list-title">
                <span>{claim.title}</span>
                <StatusPill value={claim.claimState} tone={claim.claimState === 'completed' ? 'ok' : claim.claimState === 'stale' ? 'critical' : claim.claimState === 'working' ? 'warning' : 'info'} />
              </div>
              <div className="badge-row">
                <span className="mini-badge"><span className={`mini-dot ${claim.agent === 'vivi' ? 'tone-ok' : 'tone-warning'}`} />{claim.agent}</span>
                <span className="mini-badge"><span className="mini-dot tone-info" />{claim.sourceRail}</span>
                <span className="mini-badge"><span className="mini-dot tone-warning" />{claim.priority}</span>
              </div>
              <div className="detail" style={{ marginTop: 10 }}>{claim.reason}</div>
              <div className="inline-meta" style={{ marginTop: 10 }}>
                <span>lease</span>
                <span>{formatMoment(claim.leaseUntil)}</span>
              </div>
              {claim.outcome ? <div className="detail" style={{ marginTop: 8 }}>Outcome: {claim.outcome}</div> : null}
            </li>
          ))}
        </ul>
      ) : (
        <div className="empty-state">No claim is active yet. Once the loops start, ownership and stale leases will show up here.</div>
      )}
    </div>
  );
}

function RemoteBridgeCard({
  bridge,
  freeze,
  githubSync,
}: {
  bridge: ControlRoomData['remoteBridge'];
  freeze: FreezeStatus;
  githubSync: GitHubSyncStatus;
}) {
  return (
    <div className="list-card">
      <strong>Control reliability</strong>
      <ul className="data-list compact">
        <li><div className="list-title"><span>Remote bridge</span><span>{bridge.state}</span></div></li>
        <li><div className="list-title"><span>Expected mode</span><span>{bridge.expectedMode}</span></div></li>
        <li><div className="list-title"><span>Remote host</span><span>{bridge.remoteHost || 'not declared'}</span></div></li>
        <li><div className="list-title"><span>Public ingest</span><span>{bridge.publicIngestReady ? 'armed' : 'pending'}</span></div></li>
        <li><div className="list-title"><span>Bridge auth</span><span>{bridge.authReady ? 'armed' : 'pending'}</span></div></li>
        <li><div className="list-title"><span>GitHub sync</span><span>{githubSync.state} / {githubSync.pushReady}</span></div></li>
        <li><div className="list-title"><span>GitHub auth</span><span>{githubSync.authMode || 'unknown'}</span></div></li>
        <li><div className="list-title"><span>Freeze posture</span><span>{freeze.state}</span></div></li>
      </ul>
      <div className="detail" style={{ marginTop: 10 }}>{bridge.detail}</div>
      <div className="detail" style={{ marginTop: 8 }}>Action: {bridge.suggestedAction}</div>
      <div className="detail" style={{ marginTop: 8 }}>Ingest: {bridge.ingestUrl}</div>
      <div className="detail" style={{ marginTop: 8 }}>Local control: {bridge.controlPlaneUrl}</div>
      <div className="detail" style={{ marginTop: 8 }}>Secrets: {bridge.secretSource || 'not armed locally'}</div>
      <div className="detail" style={{ marginTop: 8 }}>Freeze: {freeze.reason}</div>
      <div className="detail" style={{ marginTop: 8 }}>GitHub: {githubSync.detail}</div>
      {githubSync.suggestedFix ? <div className="detail" style={{ marginTop: 8 }}>Fix: {githubSync.suggestedFix}</div> : null}
      {githubSync.lastError ? <div className="detail" style={{ marginTop: 8 }}>Last error: {githubSync.lastError}</div> : null}
    </div>
  );
}

function AutonomySystemCard({ autonomy }: { autonomy: ControlRoomData['autonomy'] }) {
  return (
    <div className="list-card">
      <strong>Autonomy system</strong>
      <div className="detail" style={{ marginBottom: 12 }}>{autonomy.summary}</div>
      <div className="relay-stack">
        <div className="relay-item">
          <div className="list-title">
            <span>Operator freedom</span>
            <StatusPill value={autonomy.readiness} tone={autonomy.readiness === 'ready' ? 'ok' : autonomy.readiness === 'warning' ? 'warning' : 'critical'} />
          </div>
          <div className="detail" style={{ marginTop: 8 }}>{autonomy.operatorFreedom}</div>
        </div>
        <div className="relay-item">
          <div className="list-title">
            <span>Vivi instructions</span>
            <span>{autonomy.viviLoop.backlogCount} queued</span>
          </div>
          <MiniList items={autonomy.viviLoop.instructions} emptyMessage="No Vivi loop instruction is visible yet." />
        </div>
        <div className="relay-item">
          <div className="list-title">
            <span>Vega instructions</span>
            <span>{autonomy.codexLoop.backlogCount} queued</span>
          </div>
          <MiniList items={autonomy.codexLoop.instructions} emptyMessage="No Vega loop instruction is visible yet." />
        </div>
        <div className="relay-item">
          <div className="list-title">
            <span>Operating notes</span>
            <span>{autonomy.notes.length}</span>
          </div>
          <MiniList items={autonomy.notes} emptyMessage="No autonomy note is visible yet." />
        </div>
      </div>
    </div>
  );
}

function CodexChatThreadCard({ entries }: { entries: CodexChatEntry[] }) {
  return (
    <div className="list-card bridge-span">
      <strong>Vega board chat</strong>
      {entries.length > 0 ? (
        <div className="relay-stack">
          {entries.map((entry) => (
            <div className="relay-item" key={entry.id}>
              <div className="list-title">
                <span>{entry.summary}</span>
                <StatusPill value={entry.role} tone={entry.role === 'codex' ? 'ok' : entry.role === 'system' ? 'info' : 'warning'} />
              </div>
              <div className="list-meta" style={{ marginTop: 8 }}>
                <span>{entry.id}</span>
                <span>{formatMoment(entry.addedAt)}</span>
                <span>{entry.status}</span>
              </div>
              <div className="detail" style={{ marginTop: 8, whiteSpace: 'pre-wrap' }}>{entry.message}</div>
              <div className="inline-meta" style={{ marginTop: 12 }}>
                <span>source</span>
                <span>{entry.source || 'unknown'}</span>
                <span>reference</span>
                <span>{entry.reference || 'none'}</span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="empty-state">No Vega board chat exists yet.</div>
      )}
    </div>
  );
}

function ViviStepRelayCard({ entries }: { entries: TimelineEntry[] }) {
  return (
    <div className="list-card bridge-span">
      <strong>Vivi step feed</strong>
      {entries.length > 0 ? (
        <div className="relay-stack">
          {entries.map((entry, index) => (
            <div className="relay-item" key={`${entry.time}-${entry.label}-${index}`}>
              <div className="list-title">
                <span>{entry.label}</span>
                <StatusPill value={entry.tone} tone={entry.tone} />
              </div>
              <div className="list-meta" style={{ marginTop: 8 }}>
                <span>{entry.time}</span>
                <span>vivi step</span>
              </div>
              {entry.detail ? <div className="detail" style={{ marginTop: 8 }}>{entry.detail}</div> : null}
              <form action="/api/intake" method="post" className="relay-inline-form">
                <input type="hidden" name="kind" value="codex-command" />
                <input type="hidden" name="redirectTab" value="codex" />
                <input type="hidden" name="title" value={`Review Vivi step: ${entry.label}`} />
                <input type="hidden" name="context" value="Vivi step relay from LIONCOM" />
                <input
                  type="hidden"
                  name="rawRequest"
                  value={`${entry.label}\n\n${entry.detail || 'No further detail captured in the local step feed.'}\n\nPlease analyze this Vivi step, decide what matters, and either fix it directly or prepare the next safe action.`}
                />
                <input type="hidden" name="reference" value={`${entry.time} :: ${entry.label}`} />
                <input
                  type="text"
                  name="operatorComment"
                  placeholder="Optional comment for Vega"
                  aria-label={`Comment for ${entry.label}`}
                />
                <button type="submit" className="button">Hand to Vega</button>
              </form>
            </div>
          ))}
        </div>
      ) : (
        <div className="empty-state">No Vivi step rail is visible yet.</div>
      )}
    </div>
  );
}

function ViviReportRelayCard({ entries }: { entries: ViviReportEntry[] }) {
  return (
    <div className="list-card bridge-span">
      <strong>Vivi reports and handoffs</strong>
      {entries.length > 0 ? (
        <div className="relay-stack">
          {entries.map((entry) => (
            <div className="relay-item" key={entry.id}>
              <div className="list-title">
                <span>{entry.title}</span>
                <StatusPill value={entry.kind} tone={entry.kind === 'recovery' ? 'warning' : entry.kind === 'verify' ? 'ok' : 'info'} />
              </div>
              <div className="list-meta" style={{ marginTop: 8 }}>
                <span>{entry.id}</span>
                <span>{formatMoment(entry.addedAt)}</span>
                <span>{entry.state} / {entry.phase}</span>
              </div>
              <div className="detail" style={{ marginTop: 8 }}>{entry.summary}</div>
              {entry.outcome ? <div className="detail" style={{ marginTop: 8 }}>Outcome: {entry.outcome}</div> : null}
              {entry.nextStep ? <div className="detail" style={{ marginTop: 8 }}>Next: {entry.nextStep}</div> : null}
              <form action="/api/intake" method="post" className="relay-inline-form">
                <input type="hidden" name="kind" value="codex-command" />
                <input type="hidden" name="redirectTab" value="codex" />
                <input type="hidden" name="title" value={`Review Vivi report: ${entry.title}`} />
                <input type="hidden" name="context" value="Vivi report relay from LIONCOM" />
                <input
                  type="hidden"
                  name="rawRequest"
                  value={`Report kind: ${entry.kind}\nState: ${entry.state}\nPhase: ${entry.phase}\nSummary: ${entry.summary}\nOutcome: ${entry.outcome || 'n/a'}\nNext Step: ${entry.nextStep || 'n/a'}\nOperator Action: ${entry.operatorAction || 'n/a'}\nCommand Ref: ${entry.commandRef || 'n/a'}\n\nPlease review this Vivi report and decide whether Vega should act, verify, or leave it with Vivi.`}
                />
                <input type="hidden" name="reference" value={entry.id} />
                <input type="text" name="operatorComment" placeholder="Optional comment for Vega" aria-label={`Comment for ${entry.title}`} />
                <button type="submit" className="button">Review with Vega</button>
              </form>
            </div>
          ))}
        </div>
      ) : (
        <div className="empty-state">No Vivi report or handoff has been captured yet.</div>
      )}
    </div>
  );
}

function TaskListCard({ title, items, emptyMessage }: { title: string; items: TaskItem[]; emptyMessage: string }) {
  return (
    <div className="list-card">
      <strong>{title}</strong>
      {items.length > 0 ? (
        <ul className="data-list">
          {items.map((item) => (
            <li key={`${item.id}-${item.title}`}>
              <div className="list-title">
                <span>{item.title}</span>
                <StatusPill value={item.status} tone={toneForTaskStatus(item.status)} />
              </div>
              <div className="badge-row">
                {item.id ? <span className="mini-badge"><span className="mini-dot tone-info" />{item.id}</span> : null}
                {item.priority ? <span className="mini-badge"><span className="mini-dot tone-warning" />{item.priority}</span> : null}
                {item.owner ? <span className="mini-badge"><span className="mini-dot tone-info" />{item.owner}</span> : null}
                {item.deadline ? <span className="mini-badge"><span className="mini-dot tone-ok" />{item.deadline}</span> : null}
              </div>
              {item.detail ? <div className="detail" style={{ marginTop: 10 }}>{item.detail}</div> : null}
            </li>
          ))}
        </ul>
      ) : (
        <div className="empty-state">{emptyMessage}</div>
      )}
    </div>
  );
}

function BacklogCard({ backlog }: { backlog: BacklogLane[] }) {
  const hasAnyItem = backlog.some((lane) => lane.items.length > 0);

  return (
    <div className="list-card">
      <strong>Backlog-Schienen</strong>
      {hasAnyItem ? (
        <ul className="data-list">
          {backlog.map((lane) => (
            <li key={lane.lane}>
              <div className="list-title">
                <span>{lane.lane}</span>
                <span>{lane.items.length}</span>
              </div>
              {lane.items.length > 0 ? (
                <div className="badge-row">
                  {lane.items.slice(0, 3).map((item) => (
                    <span key={item.id} className="mini-badge"><span className="mini-dot tone-info" />{item.id} {item.title}</span>
                  ))}
                </div>
              ) : (
                <div className="detail" style={{ marginTop: 8 }}>Aktuell liegt hier kein Paket.</div>
              )}
            </li>
          ))}
        </ul>
      ) : (
        <div className="empty-state">Aktuell trägt keine Backlog-Schiene ein Paket.</div>
      )}
    </div>
  );
}

function SummaryChip({
  label,
  value,
  detail,
  onSelect,
  actionLabel,
  isActive = false,
}: {
  label: string;
  value: string;
  detail?: string;
  onSelect?: () => void;
  actionLabel?: string;
  isActive?: boolean;
}) {
  const className = `summary-chip${onSelect ? ' is-interactive' : ''}${isActive ? ' is-active' : ''}`;

  if (onSelect) {
    return (
      <button type="button" className={className} onClick={onSelect} aria-pressed={isActive}>
        <strong>{label}</strong>
        <span className="value">{value}</span>
        {detail ? <span className="detail">{detail}</span> : null}
        <span className="summary-chip-action">{actionLabel || 'Details lesen'}</span>
      </button>
    );
  }

  return (
    <div className={className}>
      <strong>{label}</strong>
      <span className="value">{value}</span>
      {detail ? <span className="detail">{detail}</span> : null}
    </div>
  );
}

function MetricCard({
  metric,
  variant = 'default',
  onSelect,
  isActive = false,
}: {
  metric: SummaryMetric;
  variant?: 'default' | 'compact' | 'featured';
  onSelect?: () => void;
  isActive?: boolean;
}) {
  const className = `metric-card ${variant === 'compact' ? 'compact-card' : ''} ${variant === 'featured' ? 'featured-card' : ''} ${onSelect ? 'metric-card-button' : ''} ${isActive ? 'is-active' : ''}`;

  if (onSelect) {
    return (
      <button type="button" className={className} onClick={onSelect} aria-pressed={isActive}>
        <strong>{metric.label}</strong>
        <span className={`value tone-${metric.tone}`}>{metric.value}</span>
        {metric.detail ? <span className="detail">{metric.detail}</span> : null}
        <span className="metric-card-meta">Live-Drilldown öffnen</span>
      </button>
    );
  }

  return (
    <div className={className}>
      <strong>{metric.label}</strong>
      <span className={`value tone-${metric.tone}`}>{metric.value}</span>
      {metric.detail ? <span className="detail">{metric.detail}</span> : null}
    </div>
  );
}

function buildMetricInspector(metricLabel: string, data: ControlRoomData): {
  kicker: string;
  title: string;
  summary: string;
  stats: Array<{ label: string; value: string; detail: string; tone: 'ok' | 'warning' | 'critical' | 'info' }>;
  sections: Array<{ title: string; items: string[]; summary?: string; defaultOpen?: boolean }>;
  floor?: Array<{ label: string; count: number; detail: string; tone: 'ok' | 'warning' | 'critical' | 'info' }>;
  actions: Array<{ label: string; tab: TabId; anchor?: string; primary?: boolean }>;
} {
  const queuedSubtasks = data.subtasks.filter((item) => item.status === 'queued').length;
  const activeSubtasks = data.subtasks.filter((item) => item.status === 'active').length;
  const queuedSubtaskItems = data.subtasks
    .filter((item) => item.status === 'queued')
    .slice(0, 4)
    .map((item) => `${item.title}${item.owner ? ` - ${item.owner}` : ''}`);
  const activeWorkItems = data.workBlocks
    .filter((item) => item.active)
    .slice(0, 4)
    .map((item) => `${item.title} (${item.stage})`);
  const visibleBlocks = data.workBlocks.length;
  const activeBlocks = data.workBlocks.filter((item) => item.active).length;
  const repairBlocks = data.workBlocks.filter((item) => item.lane === 'repair').length;
  const bridgeBlocks = data.workBlocks.filter((item) => item.lane === 'bridge').length;
  const researchBlocks = data.workBlocks.filter((item) => item.lane === 'research').length;
  const verifyBlocks = data.workBlocks.filter((item) => item.stage === 'VERIFY').length;
  const intakeBlocks = data.workBlocks.filter((item) => ['INTAKE', 'ANALYZE', 'PLAN'].includes(item.stage)).length;

  switch (metricLabel) {
    case 'Systemkurzlage: Phase':
      return {
        kicker: 'Systemkurzlage',
        title: 'Phasenlage',
        summary: 'Hier siehst du lesbar, in welcher Missionsphase LION gerade steht, was zuletzt passiert ist und welcher Schritt als Nächstes erwartet wird.',
        stats: [
          { label: 'Phase', value: data.mission.phase, detail: `${data.mission.progress}% Missionsfortschritt`, tone: toneForMissionState(data.mission.systemState) },
          { label: 'Systemzustand', value: data.mission.systemState, detail: data.mission.executiveSummary, tone: toneForMissionState(data.mission.systemState) },
          { label: 'Zeit in Phase', value: data.mission.timeInPhase ? `${data.mission.timeInPhase} min` : 'neu', detail: 'Wie lange die aktuelle Phase schon sichtbar läuft', tone: 'info' },
          { label: 'Risiko', value: `${data.mission.riskScore}/100`, detail: 'Operativer Risikowert für diese Mission', tone: data.mission.riskScore >= 70 ? 'critical' : data.mission.riskScore >= 40 ? 'warning' : 'ok' },
        ],
        sections: [
          {
            title: 'Aktuelle Missionsspur',
            summary: 'Letzte Aktion und nächster Schritt',
            defaultOpen: true,
            items: [
              `Letzte Aktion: ${data.mission.lastAction}`,
              `Nächster Schritt: ${data.mission.nextStep}`,
              `Zusammenfassung: ${data.mission.executiveSummary}`,
            ],
          },
          {
            title: 'Operator-Anker',
            summary: 'Was du daraus lesen sollst',
            items: [
              'Diese Phase ist die führende Lage für den aktuellen Arbeitszustand.',
              'Wenn Phase und Telemetrie auseinanderlaufen, gewinnt zuerst die frischere Runtime-Spur.',
              'Wenn der nächste Schritt unklar wirkt, ist das ein Vega-/Vivi-Schnittstellenproblem und kein Operator-Fehler.',
            ],
          },
        ],
        actions: [
          { label: 'Lagebild öffnen', tab: 'command', primary: true },
          { label: 'Pipeline öffnen', tab: 'builder' },
        ],
      };
    case 'Systemkurzlage: Kritische Hinweise':
      return {
        kicker: 'Systemkurzlage',
        title: 'Kritische Hinweise',
        summary: 'Hier wird lesbar aufgeschlüsselt, welche Warnungen gerade wirklich offen sind, was sie bedeuten und ob eher du oder wir handeln müssen.',
        stats: [
          { label: 'Kritische Hinweise', value: String(data.alerts.length), detail: 'Essenzielle oder vertrauensbrechende Karten', tone: data.alerts.length > 0 ? 'critical' : 'ok' },
          { label: 'Wartungsthemen', value: String(data.maintenance.length), detail: 'Nicht-kritische Punkte mit beobachtbarem Druck', tone: data.maintenance.length > 0 ? 'warning' : 'ok' },
          { label: 'Blocker', value: String(data.blockers.length), detail: 'Systemisch erkannte Reibungen im aktuellen Lauf', tone: data.blockers.length > 0 ? 'warning' : 'ok' },
        ],
        sections: [
          {
            title: 'Offene Hinweisdecks',
            summary: data.alerts.length > 0 ? `${data.alerts.length} offene Karten` : 'Keine offenen Karten',
            defaultOpen: true,
            items: data.alerts.length > 0
              ? data.alerts.map((alert) => `${alert.title}: ${alert.detail} Empfohlen: ${alert.recommendation}`)
              : ['Aktuell ist kein kritischer Hinweis offen.'],
          },
          {
            title: 'Wartung und Nebenwissen',
            summary: data.maintenance.length > 0 ? `${data.maintenance.length} Wartungsthemen` : 'Keine Wartung offen',
            items: data.maintenance.length > 0
              ? data.maintenance.map((item) => `${item.title}: ${item.detail}`)
              : ['Aktuell drängt kein zusätzliches Wartungsthema.'],
          },
          {
            title: 'Wer muss handeln?',
            summary: 'Mensch oder System',
            items: data.alerts.length > 0
              ? data.alerts.map((alert) => `${alert.title}: ${alert.action === 'review' ? 'Zuerst lesen und Fixspur prüfen' : alert.action === 'rescue' ? 'Rettungspaket kann direkt angestoßen werden' : 'Systemisch beobachten oder nachts sammeln'}`)
              : ['Ohne offene Hinweise ist gerade keine explizite Menschenaktion nötig.'],
          },
        ],
        actions: [
          { label: 'Lagebild öffnen', tab: 'command', primary: true },
          { label: 'System öffnen', tab: 'system' },
        ],
      };
    case 'Systemkurzlage: Loops':
      return {
        kicker: 'Systemkurzlage',
        title: 'Loop-Status',
        summary: 'Diese Ansicht zeigt, ob Vivi und Vega wirklich arbeiten, wer gerade eine Claim hält und ob etwas still festhängt.',
        stats: [
          { label: 'Vivi', value: data.autonomy.viviLoop.state, detail: data.autonomy.viviLoop.summary, tone: data.autonomy.viviLoop.state === 'busy' ? 'ok' : data.autonomy.viviLoop.state === 'ready' ? 'info' : 'warning' },
          { label: 'Vega', value: data.autonomy.codexLoop.state, detail: data.autonomy.codexLoop.summary, tone: data.autonomy.codexLoop.state === 'busy' ? 'ok' : data.autonomy.codexLoop.state === 'ready' ? 'info' : 'warning' },
          { label: 'Aktive Claims', value: String(data.autonomy.activeClaims.length), detail: 'Gerade wirklich geclaimte Missionen', tone: data.autonomy.activeClaims.length > 0 ? 'ok' : 'warning' },
          { label: 'Stale Claims', value: String(data.autonomy.staleClaims.length), detail: 'Vertrauensschuld, die bereinigt werden muss', tone: data.autonomy.staleClaims.length > 0 ? 'critical' : 'ok' },
        ],
        sections: [
          {
            title: 'Aktive Claims',
            summary: data.autonomy.activeClaims.length > 0 ? `${data.autonomy.activeClaims.length} live` : 'Keine aktive Claim',
            defaultOpen: true,
            items: data.autonomy.activeClaims.length > 0
              ? data.autonomy.activeClaims.map((claim) => `${claim.title}: ${claim.agent} · ${claim.claimState} · Lease bis ${formatMoment(claim.leaseUntil)}`)
              : ['Aktuell hält kein Agent eine aktive Claim.'],
          },
          {
            title: 'Loop-Wahrheit',
            summary: 'Was das Board gerade über die Agenten weiß',
            items: [
              `Vivi: ${data.autonomy.viviLoop.summary}`,
              `Vega: ${data.autonomy.codexLoop.summary}`,
              `Vega-Runtime: ${data.codexRuntime.detail}`,
            ],
          },
        ],
        actions: [
          { label: 'Baumodus öffnen', tab: 'codex', primary: true },
          { label: 'Agenten öffnen', tab: 'agents' },
        ],
      };
    case 'Builder-Last':
      return {
        kicker: 'Live-Metrikinspektor',
        title: 'Builder-Last',
        summary: 'Diese Metrik zeigt nicht „wie viel fertig ist“, sondern wie voll die operative Werkstatt gerade ist: sichtbare Blöcke, wartende Subtasks, laufende Arbeit und abgeschlossene Historie.',
        stats: [
          { label: 'Sichtbare Blöcke', value: String(visibleBlocks), detail: 'Arbeitsblöcke, die das Board derzeit wirklich verfolgt', tone: 'info' },
          { label: 'Aktive Blöcke', value: String(activeBlocks), detail: 'Blöcke mit aktivem Ausführungsmarker', tone: activeBlocks > 0 ? 'ok' : 'warning' },
          { label: 'Wartende Subtasks', value: String(queuedSubtasks), detail: 'Operative Unterpunkte, die noch nicht gezogen wurden', tone: queuedSubtasks > 0 ? 'warning' : 'ok' },
          { label: 'Aktive Subtasks', value: String(activeSubtasks), detail: 'Was gerade tatsächlich bearbeitet wird', tone: activeSubtasks > 0 ? 'ok' : 'info' },
          { label: 'Abgeschlossen', value: String(data.completedTasks.length), detail: 'Letzte sauber markierte Abschluss-Historie', tone: data.completedTasks.length > 0 ? 'ok' : 'info' },
          { label: 'Repair-Druck', value: String(repairBlocks), detail: 'Sichtbare Reparaturblöcke im Lagebild', tone: repairBlocks > 0 ? 'critical' : 'ok' },
        ],
        floor: [
          { label: 'Intake', count: intakeBlocks, detail: 'Neu, Analyse oder Plan', tone: intakeBlocks > 0 ? 'info' : 'ok' },
          { label: 'Build', count: activeSubtasks, detail: 'Aktiv in Arbeit', tone: activeSubtasks > 0 ? 'ok' : 'info' },
          { label: 'Queue', count: queuedSubtasks, detail: 'Wartende operative Schritte', tone: queuedSubtasks > 0 ? 'warning' : 'ok' },
          { label: 'Repair', count: repairBlocks, detail: 'Stabilisierung und Rettung', tone: repairBlocks > 0 ? 'critical' : 'ok' },
          { label: 'Bridge', count: bridgeBlocks, detail: 'Konkrete Missionen und Übergaben', tone: bridgeBlocks > 0 ? 'info' : 'ok' },
          { label: 'Verify', count: verifyBlocks, detail: 'Nahe an Review oder Abschluss', tone: verifyBlocks > 0 ? 'warning' : 'ok' },
        ],
        sections: [
          {
            title: 'Werkstatt live',
            summary: 'Aktive Blöcke und wartende Schritte',
            defaultOpen: true,
            items: [
              ...(activeWorkItems.length > 0 ? activeWorkItems : ['Aktuell ist kein sichtbarer Work-Block aktiv markiert.']),
              ...(queuedSubtaskItems.length > 0 ? queuedSubtaskItems : ['Keine wartenden Subtasks sichtbar.']),
            ],
          },
          {
            title: 'Was die Zahl wirklich meint',
            summary: 'Kennzahl statt Bauchgefühl',
            items: [
              `${activeBlocks}/${visibleBlocks} bedeutet: wie viele sichtbare Blöcke aktiv markiert sind, nicht wie viele Subtasks insgesamt offen sind.`,
              `${queuedSubtasks} wartende Subtasks zeigen, wie viel operative Arbeit noch nicht gezogen wurde.`,
              `${data.completedTasks.length} abgeschlossen kommt aus der Task-Historie und ist absichtlich getrennt von der Work-Engine.`,
            ],
          },
          {
            title: 'Operative Beobachtung',
            summary: 'Loop- und Repair-Wahrheit',
            items: [
              `${data.autonomy.viviLoop.summary}`,
              `${data.autonomy.codexLoop.summary}`,
              `Repair-Queue aktuell: ${data.repairQueue.length} Karten sichtbar, operativ aber mehr auf den Rails.`,
            ],
          },
          {
            title: 'Nächste sinnvolle Wege',
            summary: 'Direkte Handlungsoptionen',
            items: [
              'In Pipeline prüfen, welche Blöcke wirklich aktiv oder nur sichtbar sind.',
              'In Analyse prüfen, ob Research oder Repair gerade zu viel Druck erzeugen.',
              'Bei dauerhaft hoher Queue: Vivi eine Triage- oder Entstau-Mission geben.',
            ],
          },
        ],
        actions: [
          { label: 'Pipeline öffnen', tab: 'builder', primary: true },
          { label: 'Analyse öffnen', tab: 'research' },
          { label: 'Vivi-Mission anlegen', tab: 'codex', anchor: 'vivi-mission-form' },
        ],
      };
    case 'Live-Telemetrie':
      const trustTracks = [
        `Direkte Vivi-Runtime: ${data.telemetry.source} · ${data.telemetry.detail}`,
        `Autonomy-Lage: ${data.autonomy.viviLoop.summary}`,
        `Remote-Bridge: ${data.remoteBridge.expectedMode} / ${data.remoteBridge.state} · ${data.remoteBridge.suggestedAction}`,
        data.githubSync.suggestedFix
          ? `GitHub-Write-Sync: ${data.githubSync.suggestedFix}`
          : 'GitHub-Write-Sync ist aktuell nicht der begrenzende Vertrauensfaktor.',
      ];
      return {
        kicker: 'Live-Metrikinspektor',
        title: 'Live-Telemetrie',
        summary: 'Hier trennen wir direkte Vivi-Runtime, lokale Fallback-Sicht und äußere Vertrauensgates. So wird sichtbar, ob das Board wirklich live ist oder nur lokal plausibel.',
        stats: [
          { label: 'Status', value: data.telemetry.state.toUpperCase(), detail: data.telemetry.detail, tone: data.metrics.find((metric) => metric.label === metricLabel)?.tone || 'info' },
          { label: 'Quelle', value: data.telemetry.source, detail: 'Aktuelle führende Telemetriespur', tone: 'info' },
          { label: 'Autonomy', value: data.autonomy.readiness.toUpperCase(), detail: data.autonomy.viviLoop.summary, tone: data.autonomy.readiness === 'ready' ? 'ok' : 'warning' },
          { label: 'Remote Bridge', value: data.remoteBridge.state, detail: data.remoteBridge.detail, tone: data.remoteBridge.state === 'live-remote' ? 'ok' : 'warning' },
        ],
        sections: [
          {
            title: 'Signaltrennung',
            summary: 'Welche Spur gerade was beweist',
            defaultOpen: true,
            items: trustTracks,
          },
          {
            title: 'Fix- und Reviewpfade',
            summary: 'Keine tote Warnung',
            items: [
              data.telemetry.state === 'live'
                ? 'Live-Telemetrie ist frisch. Prüfe jetzt eher Gate- und Schreibvertrauen als reine Sichtbarkeit.'
                : 'Wenn Live-Telemetrie kippt, zuerst Sichtbarkeit wiederherstellen und erst danach an Layout oder Kosmetik arbeiten.',
              'Nutze den kritischen Hinweisdeck für direkte Reparatur- oder Fixspuren statt nur zu lesen.',
              'Wenn Remote-Bridge und GitHub-Sync beide blockieren, bleibt lokal die führende Wahrheit.',
            ],
          },
        ],
        actions: [
          { label: 'System öffnen', tab: 'system', primary: true },
          { label: 'Analyse öffnen', tab: 'research' },
        ],
      };
    default:
      return {
        kicker: 'Live-Metrikinspektor',
        title: metricLabel,
        summary: 'Diese Kennzahl lässt sich jetzt aufklappen, damit du nicht nur eine nackte Zahl, sondern ihren operativen Kontext siehst.',
        stats: data.metrics
          .filter((metric) => metric.label === metricLabel)
          .map((metric) => ({
            label: metric.label,
            value: metric.value,
            detail: metric.detail || 'Keine Zusatzbeschreibung verfügbar.',
            tone: metric.tone,
          })),
        sections: [
          {
            title: 'Operativer Kontext',
            summary: 'Kurz erklärt statt Logwand',
            defaultOpen: true,
            items: [
              data.mission.executiveSummary,
              `Aktueller nächster Schritt: ${data.mission.nextStep}`,
              `Risikowert: ${data.mission.riskScore}/100`,
            ],
          },
        ],
        actions: [
          { label: 'Lagebild öffnen', tab: 'command', primary: true },
          { label: 'System öffnen', tab: 'system' },
        ],
      };
  }
}

function TimelineCard({ entry }: { entry: TimelineEntry }) {
  return (
    <div className="timeline-item">
      <strong>{entry.time}</strong>
      <div className={`value tone-${entry.tone}`}>{entry.label}</div>
      {entry.detail ? <div className="detail" style={{ marginTop: 8 }}>{entry.detail}</div> : null}
    </div>
  );
}

function StatusPill({ value, tone }: { value: string; tone: 'ok' | 'warning' | 'critical' | 'info' }) {
  return <span className={`status-pill tone-${tone}`}>{value}</span>;
}

function toneForMissionState(value: string): 'ok' | 'warning' | 'critical' | 'info' {
  const normalized = value.toLowerCase();
  if (normalized.includes('critical') || normalized.includes('error')) return 'critical';
  if (normalized.includes('blocked') || normalized.includes('warning') || normalized.includes('stale')) return 'warning';
  if (normalized.includes('idle') || normalized.includes('telemetry')) return 'info';
  return 'ok';
}

function toneForAlertSeverity(value: SystemAlert['severity']): 'ok' | 'warning' | 'critical' | 'info' {
  if (value === 'critical') return 'critical';
  if (value === 'warning' || value === 'maintenance') return 'warning';
  return 'info';
}

function toneForAgentStatus(value: AgentSignal['status']): 'ok' | 'warning' | 'critical' | 'info' {
  if (value === 'active') return 'ok';
  if (value === 'warning') return 'warning';
  if (value === 'offline') return 'critical';
  return 'info';
}

function toneForAutomationStatus(value: AutomationSignal['status']): 'ok' | 'warning' | 'critical' | 'info' {
  if (value === 'active') return 'ok';
  if (value === 'scheduled') return 'info';
  if (value === 'warning') return 'warning';
  return 'critical';
}

function toneForTaskStatus(value: string): 'ok' | 'warning' | 'critical' | 'info' {
  const normalized = value.toLowerCase();
  if (normalized.includes('done')) return 'ok';
  if (normalized.includes('waiting') || normalized.includes('review')) return 'warning';
  if (normalized.includes('progress') || normalized.includes('queued')) return 'info';
  return 'info';
}

function toneForPacketStatus(value: string): 'ok' | 'warning' | 'critical' | 'info' {
  const normalized = value.toLowerCase();
  if (normalized.includes('sent')) return 'ok';
  if (normalized.includes('failed')) return 'critical';
  if (normalized.includes('queued')) return 'warning';
  return 'info';
}

function toneForViviChatStatus(value: string): 'ok' | 'warning' | 'critical' | 'info' {
  const normalized = value.toLowerCase();
  if (normalized.includes('reported')) return 'ok';
  if (normalized.includes('action') || normalized.includes('attention')) return 'warning';
  if (normalized.includes('failed') || normalized.includes('error')) return 'critical';
  if (normalized.includes('queued') || normalized.includes('waiting')) return 'info';
  return 'info';
}

function toneForModelState(value?: string): 'ok' | 'warning' | 'critical' | 'info' {
  const normalized = value?.toLowerCase() || '';
  if (normalized.includes('error') || normalized.includes('failed')) return 'critical';
  if (normalized.includes('fallback') || normalized.includes('unsupported')) return 'warning';
  if (normalized.includes('ready') || normalized.includes('requested')) return 'ok';
  return 'info';
}

function toneForUrgency(value: string): 'ok' | 'warning' | 'critical' | 'info' {
  const normalized = value.toLowerCase();
  if (normalized === 'critical') return 'critical';
  if (normalized === 'high') return 'warning';
  if (normalized === 'explore') return 'info';
  return 'ok';
}

function toneForSourceStatus(value: string): 'ok' | 'warning' | 'critical' | 'info' {
  if (value === 'online') return 'ok';
  if (value === 'warning') return 'warning';
  return 'critical';
}

function toneForQualificationState(value: QualificationSnapshot['overallState'] | 'ready' | 'blocked' | 'warning'): 'ok' | 'warning' | 'critical' | 'info' {
  if (value === 'ready') return 'ok';
  if (value === 'warning') return 'warning';
  if (value === 'blocked') return 'critical';
  return 'info';
}

function toneForQualificationSection(value: QualificationSnapshot['sections'][number]['state']): 'ok' | 'warning' | 'critical' | 'info' {
  if (value === 'passed') return 'ok';
  if (value === 'warning') return 'warning';
  if (value === 'failed') return 'critical';
  return 'info';
}

function suggestModel(providerPreset: ViviProviderPreset, current?: string): string {
  const trimmed = current?.trim() || '';
  const isLocalProviderModel = /:cloud$/i.test(trimmed) || /^qwen/i.test(trimmed) || /^deepseek/i.test(trimmed) || /^llama/i.test(trimmed) || /^mistral/i.test(trimmed);

  if (providerPreset === 'chatgpt') {
    return trimmed && !isLocalProviderModel && trimmed !== 'qwen2.5-coder:7b' && trimmed !== 'qwen2.5-coder:3b'
      ? trimmed
      : 'gpt-5.4';
  }

  if (providerPreset === 'ollama') {
    return trimmed || 'qwen2.5-coder:7b';
  }

  return isLocalProviderModel ? trimmed : '';
}

function formatViviProviderTruth(mode?: string, provider?: string, model?: string): string {
  const modeLabel = mode === 'local' ? 'Local' : mode === 'cloud' ? 'Cloud' : 'Pfad offen';
  return `${modeLabel} · ${formatProvider(provider)} · ${model?.trim() || 'kein Modell gesetzt'}`;
}

function formatProviderAndModel(provider?: string, model?: string): string {
  return `${formatProvider(provider)} · ${model?.trim() || 'kein Modell gesetzt'}`;
}

function formatProvider(provider?: string): string {
  if (provider === 'chatgpt') return 'ChatGPT';
  if (provider === 'ollama') return 'Ollama';
  if (provider === 'lmstudio') return 'LM Studio';
  return provider?.trim() || 'unbekannt';
}

function buildQuickCommands(data: ControlRoomData) {
  const phase = data.mission.phase;
  const blockers = data.blockers.length;

      return [
    {
      label: 'Brain Dump',
      detail: 'Für Telegram oder Board, wenn der Gedanke roh ist und Vivi ihn erst entwirren soll.',
      command: `/dump This is a raw operator dump. Treat it as chaotic intent, extract what I probably mean, and convert it into possible work blocks without pretending unclear details are resolved.`,
    },
    {
      label: 'Arbeitsauftrag',
      detail: 'Schicke ein sauberes Arbeitspaket, das Vivi in Phasen und Subtasks zerlegen soll.',
      command: `/work Build this into tracked execution. Current mission phase is ${phase}. Break it into phases, work blocks, subtasks, blockers and next actions before you claim it is ready.`,
    },
    {
      label: 'Research Burst',
      detail: 'Wandle eine rohe Idee zuerst in Analyse und Research um statt sofort zu bauen.',
      command: `/research Treat this as a research seed. Visible blockers: ${blockers}. Produce assumptions, open questions, validation checks, and a small research sequence before execution.`,
    },
    {
      label: 'Direkt an Vivi',
      detail: 'Für eine konkrete Vivi-Mission, wenn Lane und Ziel schon klar sind.',
      command: `/vivi Execute this safely, stay inside the correct state machine, and report back through LIONCOM when done.`,
    },
    {
      label: 'Direkt an Vega',
      detail: 'Für technische Umsetzung, harte Reviews oder Debugging direkt an Vega.',
      command: `/codex Own this as a Vega task. Give me a concrete technical result and feed it back into the board with a clean reference.`,
    },
    {
      label: 'Reparaturpaket',
      detail: 'Für Stabilitäts- oder Vertrauensprobleme, die erst sauber repariert werden müssen.',
      command: `/repair This is a stability or trust issue. Analyze the failure, contain it, and only return the system to normal use when the repair is verified.`,
    },
    {
      label: 'Status prüfen',
      detail: 'Hole dir eine mobil lesbare Kurzlage direkt aus LIONCOM zurück.',
      command: '/status',
    },
  ];
}

function collectResearchWork(data: ControlRoomData): TaskItem[] {
  const pool = [...data.activeTasks, ...data.waitingTasks, ...data.backlog.flatMap((lane) => lane.items)];
  const filtered = pool.filter((item) => {
    const haystack = `${item.title} ${item.detail || ''}`.toLowerCase();
    return haystack.includes('research') || haystack.includes('analyse') || haystack.includes('trend') || haystack.includes('idea') || haystack.includes('plan');
  });

  return filtered.length > 0 ? filtered.slice(0, 8) : pool.slice(0, 6);
}

function formatMoment(value?: string): string {
  if (!value) return 'n/a';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;

  return date.toLocaleString('de-DE', {
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
}
