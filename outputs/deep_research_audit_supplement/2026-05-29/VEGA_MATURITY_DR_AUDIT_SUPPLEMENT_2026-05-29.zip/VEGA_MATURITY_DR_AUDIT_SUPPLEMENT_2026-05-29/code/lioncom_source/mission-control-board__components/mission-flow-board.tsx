import { AgentBadge } from '@/components/agent-badge';
import { PriorityBadge } from '@/components/priority-badge';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/cn';
import type { Mission } from '@/lib/types';

const columns: Array<{ id: Mission['status']; label: string }> = [
  { id: 'intake', label: 'Eingang' },
  { id: 'active', label: 'Aktiv' },
  { id: 'review', label: 'Prüfung' },
  { id: 'done', label: 'Erledigt' },
];

export function MissionFlowBoard({ missions, title = 'Missionsfluss / Queue-Übersicht' }: { missions: Mission[]; title?: string }) {
  return (
    <Card className="rounded-2xl p-4">
      <div className="hud-title text-sm text-vega">{title}</div>
      <div className="mt-4 grid items-start gap-3 lg:grid-cols-4">
        {columns.map((column) => {
          const columnItems = missions.filter((mission) => mission.status === column.id || (column.id === 'active' && mission.status === 'planning'));
          const visibleItems = columnItems.slice(0, 2);
          const hiddenCount = Math.max(0, columnItems.length - visibleItems.length);
          return (
            <div key={column.id} className="min-h-[170px] rounded-2xl border border-border bg-cpbg/30 p-3">
              <div className="flex items-center justify-between">
                <div className="hud-label text-muted">{column.label}</div>
                <div className="font-mono text-xs text-muted">{columnItems.length}</div>
              </div>
              <div className="mt-3 space-y-2">
                {visibleItems.map((mission) => (
                  <div key={mission.id} className="rounded-xl border border-border bg-elevated/35 p-3">
                    <div className="flex items-center justify-between gap-2">
                      <AgentBadge agentId={mission.ownerAgentId} compact />
                      <PriorityBadge priority={mission.priority} />
                    </div>
                    <div className="mt-3 line-clamp-2 text-sm font-semibold text-text">{mission.title}</div>
                    <div className="mt-2 flex items-center gap-2">
                      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-cpbg">
                        <div
                          className={cn('h-full rounded-full', mission.ownerAgentId === 'vivi' ? 'bg-vivi' : 'bg-vega')}
                          style={{ width: `${mission.progress}%` }}
                        />
                      </div>
                      <span className="font-mono text-xs text-muted">{mission.progress}%</span>
                    </div>
                  </div>
                ))}
                {hiddenCount > 0 ? (
                  <div className="rounded-xl border border-border bg-cpbg/35 px-3 py-2 text-center font-mono text-xs uppercase tracking-[0.12em] text-muted">
                    +{hiddenCount} weitere
                  </div>
                ) : null}
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}
