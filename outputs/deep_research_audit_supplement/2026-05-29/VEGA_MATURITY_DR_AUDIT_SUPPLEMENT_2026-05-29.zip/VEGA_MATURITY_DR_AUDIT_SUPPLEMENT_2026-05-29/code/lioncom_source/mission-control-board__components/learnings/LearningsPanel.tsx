// LearningsPanel - Kompakte Learnings-Anzeige

import type { MappedLearnings } from '@/lib/mappers/learningMapper';

interface LearningsPanelProps {
  learnings: MappedLearnings;
}

const severityIcons = {
  error: '🔴',
  warning: '🟡',
  info: '🟢'
};

export function LearningsPanel({ learnings }: LearningsPanelProps) {
  if (learnings.items.length === 0) {
    return (
      <div className="bg-slate-50 rounded-lg border border-slate-200 p-4 mx-4 text-sm text-slate-500">
        Keine aktuellen Learnings
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow border border-slate-200 p-4 mx-4">
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm font-medium">Aktuelle Learnings</span>
        <span className="text-xs text-slate-400">{learnings.items.length} Einträge</span>
      </div>
      
      <ul className="space-y-2">
        {learnings.items.map((item) => (
          <li key={item.id} className="flex items-start gap-2 text-sm">
            <span>{severityIcons[item.severity]}</span>
            <span className="text-slate-700">{item.title}</span>
          </li>
        ))}
      </ul>
      
      {(learnings.errorCount > 0 || learnings.warningCount > 0) && (
        <div className="mt-3 pt-3 border-t border-slate-100 text-xs">
          {learnings.errorCount > 0 && <span className="text-red-500 mr-3">{learnings.errorCount} Fehler</span>}
          {learnings.warningCount > 0 && <span className="text-amber-500">{learnings.warningCount} Warnungen</span>}
        </div>
      )}
    </div>
  );
}
