import { Plus } from 'lucide-react';

import { InfoButton } from '@/components/info-button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/cn';
import type { AgentAccent, QueueItem } from '@/lib/types';

function priorityClass(priority: QueueItem['priority']) {
  if (priority === 'critical') return 'text-danger';
  if (priority === 'high') return 'text-warning';
  return 'text-vivi';
}

function statusLabel(status: string) {
  const value = status.toLowerCase();
  if (value.includes('active') || value.includes('working')) return 'Aktiv';
  if (value.includes('block')) return 'Blockiert';
  if (value.includes('done')) return 'Erledigt';
  if (value.includes('queue') || value.includes('wait') || value.includes('pending')) return 'Wartend';
  if (value.includes('review')) return 'Prüfung';
  if (value.includes('repair')) return 'Reparatur';
  return status;
}

export function QueueOverview({
  title,
  description,
  items,
  accent,
  className,
  showTabs = false,
  actionLabel = 'Details anzeigen',
}: {
  title: string;
  description: string;
  items: QueueItem[];
  accent: AgentAccent;
  className?: string;
  showTabs?: boolean;
  actionLabel?: string;
}) {
  const firstItem = items[0];
  return (
    <Card className={cn('col-span-12 rounded-2xl', className)}>
      <CardHeader className="pb-2">
        <div>
          <CardTitle className={cn('text-sm', accent === 'vivi' ? 'text-vivi' : 'text-vega')}>{title}</CardTitle>
          <CardDescription>{description}</CardDescription>
        </div>
        {showTabs ? (
          <InfoButton variant={accent} size="sm" info={{ title: 'Neue Aufgabe', body: `Aktuelle Queue: ${items.length} Einträge. Neue Aufgaben sollten über Dispatch Bridge laufen, damit Zielmodus, Priorität und Agent sauber im Audit landen.`, tone: 'info' }}>
            <Plus className="size-4" />
            Neue Aufgabe
          </InfoButton>
        ) : null}
      </CardHeader>
      <CardContent>
        {showTabs ? (
          <div className="mb-3 grid grid-cols-4 rounded-xl border border-border bg-cpbg/35 p-1">
            {['Aktiv', 'Probleme', 'Reparaturen', 'Umsetzung'].map((tab, index) => (
              <div
                key={tab}
                className={cn(
                  'rounded-lg px-2 py-2 text-center text-[0.68rem] font-semibold uppercase tracking-[0.14em]',
                  index === 0 ? (accent === 'vivi' ? 'bg-vivi-soft text-vivi' : 'bg-vega-soft text-vega') : 'text-muted',
                )}
              >
                {tab}
              </div>
            ))}
          </div>
        ) : null}
        <div className="space-y-2">
          {items.length > 0 ? items.map((item) => (
            <div key={item.id} className="rounded-xl border border-border bg-cpbg/30 p-3">
              <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="truncate text-sm text-text">{item.title}</div>
                  <div className="mt-1 font-mono text-xs text-muted">{item.type}</div>
                </div>
                <div className="shrink-0 text-right">
                  <div className={cn('text-xs font-semibold', priorityClass(item.priority))}>{statusLabel(item.status)}</div>
                  <div className="mt-1 font-mono text-xs text-muted">{item.updatedAt}</div>
                </div>
              </div>
              <div className="mt-3 flex items-center gap-3">
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-elevated">
                  <div
                    className={cn('h-full rounded-full', accent === 'vivi' ? 'bg-vivi' : 'bg-vega')}
                    style={{ width: `${Math.max(0, Math.min(100, item.progress ?? 0))}%` }}
                  />
                </div>
                <div className="w-10 text-right font-mono text-xs text-muted">{item.progress ?? 0}%</div>
              </div>
            </div>
          )) : (
            <div className="rounded-xl border border-border bg-cpbg/30 p-4 text-sm leading-6 text-muted">
              Keine aktiven Einträge in dieser Queue. Neue Live-Pakete erscheinen hier automatisch.
            </div>
          )}
        </div>
        <InfoButton variant="outline" size="sm" className="mt-3 w-full" info={{ title: actionLabel, body: firstItem ? `Aktuelle ${accent === 'vivi' ? 'Vivi' : 'Vega'} Queue: ${items.length} Einträge. Nächster sichtbarer Eintrag: ${firstItem.title}, Status ${statusLabel(firstItem.status)}, Fortschritt ${firstItem.progress ?? 0}%, aktualisiert ${firstItem.updatedAt}.` : `Aktuell sind keine ${accent === 'vivi' ? 'Vivi' : 'Vega'} Queue-Einträge sichtbar.`, tone: items.some((item) => item.priority === 'critical') ? 'warning' : 'info' }}>
          {actionLabel}
        </InfoButton>
      </CardContent>
    </Card>
  );
}
