# Vivi Model Route Snapshot Closure - 2026-05-21

Status: `implemented_claim_start_snapshot`

This closes the historical low-noise review item around Vivi model route drift. The active model route truth is no longer reconstructed only from later runner state, route probes, and report text. New Vivi autonomy claims now carry `modelRouteSnapshotAtClaimStart` directly on the claim object.

## Implemented Contract

- `AutonomyClaim.modelRouteSnapshotAtClaimStart` records the requested and effective provider/model at claim creation.
- The snapshot also records local loop model state, route-probe freshness metadata, and the exact runtime paths used for the evidence.
- `TASK_CLAIMS.md` renders the snapshot for operator inspection.
- `scripts/run_local_duo_loop.sh` propagates the snapshot into the local heartbeat and runner prompt, so Vivi sees the claim-start route as first-class evidence.
- `scripts/verify_vivi_model_route_snapshot.mjs` verifies the static contract.

## Boundary

Existing pre-change claims are not retroactively rewritten as if they had a claim-start snapshot. The closure applies from the next newly issued Vivi autonomy claim onward.

## Verification

Run from `mission-control-board`:

```bash
node scripts/verify_vivi_model_route_snapshot.mjs
npm run vivi:model-route
npm run verify:control-plane-v2:static
npx tsc --noEmit --pretty false
```
