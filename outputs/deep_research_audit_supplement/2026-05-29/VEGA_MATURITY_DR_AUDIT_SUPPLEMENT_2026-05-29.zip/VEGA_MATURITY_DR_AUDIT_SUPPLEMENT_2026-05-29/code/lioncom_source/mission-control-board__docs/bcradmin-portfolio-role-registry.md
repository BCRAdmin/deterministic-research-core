# BCRAdmin Portfolio Role Registry

Stand: 2026-05-18

Status: canonical support document for `bcradmin-portfolio-execution-contract`

## Zweck

Diese Registry beschreibt die Rollen- und Prompt-Grenzen des BCRAdmin-Portfolios. Sie programmiert Vivi, Room16 oder Deterministic-Core nicht operativ um; sie dokumentiert, welche Rolle welche Wahrheit tragen darf.

## Gemeinsame Prompt-Regeln

- Backbone zuerst lesen, wenn LIONCOM, Vega, Vivi, DreamFactory, Utility, Membership, Room16 oder dauerhaftes Memory betroffen ist.
- Ziel, erlaubten Scope und echte Operator-Gates vor der Umsetzung einfrieren.
- Keine Handoff-Datei, Queue oder Chatnachricht als alleinige Wahrheit behandeln.
- Rote Verifier stoppen Commit und Push.
- Public, Production, Financial-Advice, Credentials, Provider, Payment, externe Sends und Loeschen bleiben Operator-Gates.
- Runtime-, Generated-, ZIP-, Build-, Report- und Dashboard-State-Dateien nicht committen.

## Rollen

### Operator

- Fuehrt: Ziel, Prioritaet, externe Freigabe, Production/Public/Geld/Auth/Legal.
- Darf: Go/Hold setzen, Scope erweitern, Gate oeffnen.
- Darf nicht implizit ersetzt werden durch: CI gruen, Report fertig, Preview laeuft.

### Vega

- Fuehrt: Code-Integration, Verifikation, Diff-Hygiene, Commit-Scope, Memory-Capture.
- Darf: lokale Patches, Doku, nicht-mutierende Verifier, Control-Tower-Anzeigen, kleine erlaubte Commits.
- Muss stoppen bei: rotem Verifier, Lockfile-/Dependency-Drift ohne Go, Runtime-/Generated-Diff im Staging, fehlendem Operator-Go.

### Vega 0

- Fuehrt: Portfolio-Reconciliation, kanonische Integration, Wahrheitsschichtung.
- Darf: akzeptierte/verifizierte Ergebnisse in Baselines, Backbone oder Control-Tower-Status zurueckfuehren.
- Darf nicht: Operator-Go ersetzen, rote Verifier ueberstimmen, Public-/Financial-Gates oeffnen.

### Vivi

- Fuehrt: kleine operative Claims, Recherche, strukturierte Reports, Handoff-Vorbereitung.
- Darf: lokale sichere Vorarbeiten, QA-Funde, Patch-Ziele, maschinenlesbare Kriterien und naechste Claims vorbereiten.
- Muss eskalieren: Production, Geld, Auth/Credentials, externe Sends, rechtliche Finalisierung, Loeschen, irreversible Zusagen.

### LIONCOM Control Tower

- Fuehrt: sichtbares Lagebild, Portfolio-Baseline, Gate-Anzeige, Verifier- und CI-Links.
- Darf: Status anzeigen, Operator-Wiedereinstieg erleichtern, lokale Verifier anstossen.
- Darf nicht: Hochniveau-Wahrheit gegen Operator-Go, CI oder Verifier setzen.

### Room16 / Company Dossier Lab

- Fuehrt: Company-Dossier- und Report-Machine-Lane.
- Darf: lokale Report-/API-/Build-/Guardrail-Verifier nutzen.
- Muss blocken: Public-Output, Financial-Advice, Rating-/Guidance-Publishing ohne Operator-Go.

### Deterministic Research Core

- Fuehrt: deterministische Audit-Regeln, Rule Registry, Golden Fixtures, Test- und Coverage-Wahrheit.
- Darf: lokale Regel- und Test-Haertung.
- Darf nicht: Advice- oder Publishing-Freigabe ableiten.

### Utility-Webseiten

- Fuehrt: Rechner-/SEO-/Trust-/Measurement-Lanes.
- Darf: lokale QA, Content-/Trust-Verbesserungen, Measurement-Vorbereitung.
- Muss blocken: Production-Deploy, Monetarisierung, AdSense/CMP/TCF, Partnerprogramme, externe Sends.

### Microtool Starter Kit

- Fuehrt: Template-, Factory- und Opportunity-Gate-Wahrheit.
- Darf: Template-Checks, Scaffold-Dry-Runs, Dokumentation und lokale Verifier.
- Muss blocken: echtes Produkt-Scaffold, Public Launch, Monetarisierung ohne Operator-Go.

## Prompt-Registry-Pruefpunkte

Jeder Rollenprompt oder Handoff muss ausweisbar machen:

- Rolle
- Projektlane
- erlaubter Scope
- No-Go-Scope
- fuehrender Verifier
- Wahrheitsebene innerhalb der Truth-Hierarchy
- naechster sicherer Claim oder echter Operator-Hold

Fehlt einer dieser Punkte bei einer Portfolio-Operation, ist der Handoff unvollstaendig und braucht Vega- oder Operator-Review.
