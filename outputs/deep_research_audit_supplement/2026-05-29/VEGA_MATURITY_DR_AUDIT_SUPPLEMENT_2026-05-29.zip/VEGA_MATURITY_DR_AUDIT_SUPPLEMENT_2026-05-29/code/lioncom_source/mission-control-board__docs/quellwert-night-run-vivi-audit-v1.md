# Quellwert Nachtlauf Vivi Audit v1

- Rolle: Vivi-Support fuer Vega
- Scope: Softlaunch-/Website-Qualitaet der lokalen Quellwert-Preview unter `/membership`
- Current as of: 2026-05-13T00:11:01Z / 2026-05-13 02:11 Berlin
- Geprüft: Obsidian `Project - Quellwert`, `Feature - Research Publishing Surface`, `lib/quellwert/analysisCatalog.ts`, `app/membership/*`, `scripts/verify_quellwert_membership_preview.cjs`, `docs/quellwert-googl-public-ready-v1.md`, `data/quellwert/googl-public-ready-gate.v1.json`
- Verifikation: `curl http://127.0.0.1:4107/membership` -> `200 text/html`; `LIONCOM_BASE_URL=http://127.0.0.1:4107 npm run verify:quellwert-membership-preview` -> `pass`
- Nicht getan: keine Codeänderung, kein externer Send, kein Production-Go, kein neuer Aktienbericht, keine Dossier-Verarbeitung

## 1. Was jetzt stark genug für Softlaunch-Preview ist

Die Surface ist für eine lokale Softlaunch-Preview stark genug, weil sie inzwischen eine klare Research-first-Wahrheit trägt: Startseite, Analysenindex, Detailseiten, Methodik und Archiv sind als ruhige Quellwert-Fläche lesbar und nicht mehr als Membership- oder Sales-Funnel gerahmt.

Stark sind vor allem diese Punkte:

- Der öffentliche Katalog ist eng gefiltert: sichtbar sind nur `publicationStatus="pilot_ready"` und `visibility="public"`. Aktuell sind das GOOGL, SNOW und MSFT aus `phase12_current_batch_003`; NVDA und MU bleiben hidden und liefern laut Verifier `404`.
- GOOGL ist sauber als `Public-Ready-Kandidat` markiert, aber nicht als externer Publish. Das Gate trennt `publicPreviewReady=true`, `externalPublicationReady=false`, `operatorGoRequired=true` und hält das Source-Registry-Delta sichtbar auf `Review offen`.
- Die Detailseiten haben eine brauchbare Trust-Struktur: These, Kernzahlen, Prüfpunkte, Risiken, Evidence, Gate-Panel und Non-Advice-Hinweis.
- Methodik und Archiv erklären die Publikationsgrenze verständlich: Quellen, Evidence, Reconciliation, Public-Preview-Gate und interne Review-Fälle sind sichtbar.
- Der bestehende Verifier deckt die wichtigsten Softlaunch-Risiken schon ab: Route-Status, Required Tokens, verbotene Sales-/Membership-/Checkout-/Waitlist-/Trading-Tokens, versteckte Review-Ticker, GOOGL-Gate-JSON und Quellwert-Assets.

Wichtig: Die offiziellen GOOGL-Quellenclaims wurden in diesem Audit nicht extern neu nachgerechnet. Ich behandle die Quelle-Prüfung aus Gate/Handoff als geprüfte Projektwahrheit, aber nicht als frische unabhängige Zahlenvalidierung durch diesen Lauf.

## 2. Fünf lokale Verbesserungen mit größtem Hebel

1. GOOGL-Detailseite redaktionell tiefer machen, ohne Trading-Sprache.
   Der aktuelle Detailtext ist solide, aber noch knapp. Größter Hebel wäre ein lokaler Artikelkörper aus dem vorhandenen Handoff: operative Lage, Cloud-/AI-Capex-Frage, Bewertungsrahmen, technischer Kontext als Risikokontext, Szenarien und Review-Hinweis. Sichtbare Copy sollte echte Umlaute nutzen, z. B. `Veröffentlichung`, `nüchtern`, `Überblick`, `größer`, nicht ASCII-Umschreibungen.

2. Evidence-Panel stärker nach Quellenstatus staffeln.
   Aktuell stehen Evidence-Karten nebeneinander. Besser wäre eine klare sichtbare Trennung: `geprüfte Primärquelle`, `SEC-Datenpaket`, `lokales Evidence-Paket`, `Review offen`. Das würde das offene Registry-Delta als Qualitätsmerkmal statt als vagen Warnsatz zeigen.

3. Archiv und Analysenindex um Filter-/Statuslogik erweitern.
   Ohne neue Reports kann die Oberfläche mehr Vertrauen geben, wenn der Index zwischen `Public-Ready-Kandidat`, `Pilot-Entwurf` und `zurückgestellt intern` klarer trennt. Zurückgestellte Namen müssen nicht öffentlich genannt werden; aber die Regel und die Anzahl dürfen sichtbar bleiben.

4. Methodikseite mit einer kompakten Gate-Matrix ergänzen.
   Die Methodik ist gut, aber noch abstrakt. Eine kleine Matrix `Datenpaket -> Evidence -> Reconciliation -> Redaktion -> Operator-Go` würde Softlaunch-Besuchern schneller zeigen, warum Quellwert keine Blackbox ist.

5. Non-Advice- und Review-Hinweise konsistent an Index, Detail und Footer führen.
   Detailseiten haben den Hinweis. Für Softlaunch-Qualität wäre besser, wenn Analysenindex und Footer ebenfalls knapp sichtbar machen: `Research-Notizen, keine Anlageberatung, externe Veröffentlichung nur nach Review`. Das bleibt neutral und vermeidet Sales-, Membership- und Trading-Sprache.

## 3. Fehlende maschinenlesbare Gates und Verifier

- Katalog-Contract-Gate: prüfen, dass jeder `visibility="public"` Eintrag auch `publicationStatus="pilot_ready"`, `nonAdvice`-Status, `sourceBatch`, `reportId`, `qualityScore`, `sourceCount>0`, Evidence-Einträge und mindestens einen lokalen Artefaktnachweis hat.
- Gate-Consistency-Gate: prüfen, dass `displayStatus="Public-Ready-Kandidat"` nur gesetzt werden darf, wenn ein Gate-Objekt oder Gate-JSON existiert und `externalPublicationReady=false` plus `operatorGoRequired=true` erhalten bleibt.
- Source-Registry-Delta-Gate: GOOGL aktuell zeigt `Review offen`; ein Verifier sollte maschinenlesbar verlangen, dass dieser Zustand sichtbar bleibt, solange `source_registry_delta_review` nicht `pass` ist.
- Public-Copy-Quality-Gate: prüfen, dass öffentliche Copy echte deutsche Umlaute enthält und keine alten ASCII-Public-Copy-Fragmente wie `Veroeffentlichung`, `fuer`, `waere`, `grosse` auf sichtbaren Seiten landen.
- Article-Depth-Gate: pro öffentlicher Detailseite Mindeststruktur prüfen: These, Kernzahlen, Prüfpunkte, Risiken, Evidence, Non-Advice, Quellenstatus und mindestens ein substantieller erklärender Absatz jenseits von Kurzsummary/KPI-Liste.
- Hidden-Route-Regression-Gate: bestehend sind NVDA/MU-404s; es fehlt ein datengetriebener Test, der alle `visibility="hidden"` Slugs automatisch aus dem Katalog nimmt, statt hidden Routes statisch zu listen.
- No-External-Publish-Gate: maschinenlesbar prüfen, dass keine öffentliche Seite Copy wie `freigegeben`, `live`, `publish`, `kaufen`, `verkaufen`, `Portfolio`, `Position` oder CTA-Sprache zeigt, außer explizit als Operator-Gate/Negation.
- Artifact-Link-Gate: prüfen, dass `localArtifacts` nicht nur Namen sind, sondern auf vorhandene lokale Batch-Artefakte oder bewusst `not_publicly_linked`/`internal_only` gemappt werden.

## 4. Ein nächster sicherer Code-Slice für Vega

Vega sollte zuerst einen kataloggetriebenen `verify:quellwert-public-catalog-contract` bauen und in den bestehenden Preview-Verifier einhängen.

Warum dieser Slice zuerst: Er schützt die höchste Produktrisiko-Kante, ohne neue Reports, ohne Dossier-Verarbeitung und ohne sichtbare Sales-/Trading-Sprache. Der Test kann `lib/quellwert/analysisCatalog.ts` als Datenquelle laden oder über eine kleine exportierbare Contract-Schicht prüfen und dann sicherstellen:

- öffentliche Einträge erfüllen den vollständigen Public-Preview-Contract;
- hidden Einträge werden automatisch als 404-Routen geprüft;
- `Public-Ready-Kandidat` braucht Gate-Daten und darf externen Publish nicht freigeben;
- offene Source-Registry-Deltas müssen sichtbar bleiben;
- sichtbare Public-Copy nutzt echte Umlaute und enthält keine verbotenen Tokens.

Dieser Slice ist klein, lokal, verifier-first und kollidiert nicht mit Vega-Parallelcode, solange Vivi keine App-/Lib-/Script-Dateien schreibt.

## 5. Harte Operator-Gates

- Externer Publish oder Production-Go für Quellwert bleibt gesperrt.
- GOOGL darf lokal als Public-Ready-Kandidat sichtbar sein, aber externe Veröffentlichung braucht Operator-Go.
- Source-Registry-Delta für GOOGL bleibt `Review offen`, bis menschlicher Quellencheck und Registry-Abgleich abgeschlossen sind.
- Keine neuen Aktienberichte, keine neue Dossier-Verarbeitung und keine automatische Promotion weiterer Ticker.
- Keine Sales-, Membership-, Checkout-, Waitlist-, Payment- oder Founder-Sprache auf Public Pages.
- Keine Trading-, Rating- oder Handlungssprache als öffentliche Empfehlung.
- Keine externen E-Mails, Social Posts, Newsletter, Partnerkontakte oder öffentlichen Claims.
- Keine Änderungen an Auth, Credentials, Geldflüssen, Legal-Finalisierung, Production-Routing oder Domains.

## Geänderte Datei(en)

- `docs/quellwert-night-run-vivi-audit-v1.md`
