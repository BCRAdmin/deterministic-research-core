# LIONCOM Maintenance Final + Portfolio Control Tower V1

Stand: 2026-05-18

## Ziel

Diese Notiz friert den technischen Maintenance-Abschluss und die erste Portfolio-Control-Tower-Baseline fuer LIONCOM ein.

LIONCOM dient damit als zentrale lokale Uebersicht fuer das BCRAdmin-Portfolio: aktive Repos, Legacy-Schutz, CI-/E2E-Lage, GitHub-Gates, Production-/Public-/Financial-Advice-Grenzen und die naechste sinnvolle Aktion je Projekt.

## Maintenance-Baseline

- Branch: `reconcile/lioncom-origin-main-2026-05-02`
- Electron-39-Maintenance-Commit: `41ef821`
- Security-Fix-Commit: `298846e`
- Next: `15.5.18`
- React: `19.2.6`
- Electron: `39.8.10`
- electron-builder: `26.8.1`
- brace-expansion: `5.0.6` ueber parent-spezifischen `minimatch@10.2.5`-Override
- GitHub-Actions Node: `24`
- Build-ID fuer Source, Runtime-Workspace, `/Applications/LIONCOM.app` und `dist-desktop`: `OuFrDueeo4aN4umXaAhjV`
- Remote CI Run `26044327237`: gruen

Ab diesem Stand gilt: keine Dependency-Aenderungen ohne eigenes Operator-Go. Der Portfolio-Control-Tower-Schnitt darf die Maintenance-Wahrheit dokumentieren und pruefen, aber keine neuen Upgrades oeffnen.

## Portfolio-Baseline

Die fuehrende versionierte Datenquelle ist:

`mission-control-board/data/portfolio-control-tower-baseline.json`

Sie enthaelt sieben Repos:

- `BCRAdmin/materialbedarf-rechner.de`
- `BCRAdmin/Kindergeld`
- `BCRAdmin/LIONCOM`
- `BCRAdmin/microtool-starter-kit`
- `BCRAdmin/company-dossier-lab`
- `BCRAdmin/deterministic-research-core`
- `BCRAdmin/Vivi-os-v1`

`BCRAdmin/Vivi-os-v1` bleibt archived/read-only/legacy. Es ist Teil der Portfolio-Uebersicht, aber kein Bearbeitungsziel.

## Harte Gates

- keine Production- oder Public-Freigabe aus gruenen Checks ableiten
- keine Financial-Advice-Freigabe ableiten
- keine Credentials, Provider, Payment, Secrets oder externen Aktionen oeffnen
- keine Runtime-, Temp-, ZIP-, Build-, Log-, Report- oder Release-Artefakte committen
- keine Arbeit an `BCRAdmin/Vivi-os-v1`

## Bekannte lokale Diffs

- LIONCOM: `dashboard/data/golden_baseline_status.json` ist generated baseline state und nicht commitbar.
- LIONCOM: `VIVI_CHAT_SESSIONS.json` und `VIVI_CHAT_THREAD.md` sind lokale Vivi-Chat-Rails und nicht commitbar.
- Materialbedarf: `ops/EXECUTION_LOG.md` war ein vorgefundener Monitoring-Log-Diff ausserhalb dieses LIONCOM-Schnitts und bleibt out of scope.

## Verifier

`npm run verify:portfolio-status` prueft jetzt zusaetzlich:

- Portfolio V1-Metadaten
- alle sieben Repos und Required-Check-Kategorien
- aktualisierte Snapshot-SHAs
- LIONCOM-Maintenance-Versionen aus `package.json` und `package-lock.json`
- Electron-39- und electron-builder-26-Baseline
- Security-Overrides fuer `@xmldom/xmldom`, `ip-address` und `brace-expansion`
- Operator-Gates fuer Public/Production, Financial Advice, Dependencies und generated state
- `Vivi-os-v1` No-Touch-Policy

Damit ist Portfolio Control Tower V1 ein lokaler Kontrollanker, kein Launch- oder Monetarisierungs-Go.
