# Vega Prompt Registry 2026-05-18

Status: canonical support document for Portfolio Control Tower V2

Quelle: `/Users/BjornRosinger/Downloads/BCRADMIN_EXPANSION_VEGA_PROMPTS_2026-05-18.md`

## Zweck

Diese Registry macht sichtbar, welche Vega-Prompts das BCRAdmin-Portfolio am 2026-05-18 tragen, welche Repos betroffen sind, welche Verifier führen und welche Gates nicht automatisch geöffnet werden.

Sie ist kein Production-, Public-, Financial-Advice-, Provider-, Payment- oder Credential-Go.

## Prompt-Lanes

| Prompt | Stream | Repo | Branch | Führender Verifier | Gate |
| --- | --- | --- | --- | --- | --- |
| Vega 0 - Portfolio-Koordinator | portfolio.integration | BCRAdmin/LIONCOM | reconcile/lioncom-origin-main-2026-05-02 | `npm run verify:portfolio-status` | kein Override für rote Worker-Verifier oder fehlenden Operator-Go |
| Vega 1 - Materialbedarf Measurement/Funnel | materialbedarf.measurement | BCRAdmin/materialbedarf-rechner.de | main | `npm run check:measurement` | kein Affiliate-, AdSense-, CMP-, Productfeed- oder Production-Go |
| Vega 2 - Elterngeld Trust/Quellenmatrix | elterngeld.trust | BCRAdmin/Kindergeld | master | `npm run check:trust` | keine Rechtsversprechen, keine unbelegten Regelupdates, kein Public-Go |
| Vega 3 - Room16 Manual Review Workbench | room16.review | BCRAdmin/company-dossier-lab | bcr-report-lab-original-trading-flow | `npm run verify:manual-review-workbench` | keine Public-Freigabe, keine Publishing-Automation, keine Financial Advice |
| Vega 4 - Deterministic Outcome Tracking | deterministic.outcomes | BCRAdmin/deterministic-research-core | main | `python -m research_agent.outcomes.verify_outcome_schema` | kein Live-Fetch, keine Trading-Automation, keine Public-Reports |
| Vega 5 - Microtool Opportunity Gate | microtool.opportunities | BCRAdmin/microtool-starter-kit | main | `npm run check:opportunity-gate` | kein neues Repo, kein Domainkauf, kein Monetarisierungssetup ohne Operator-Go |
| Vega 6 - LIONCOM Control Tower V2 | portfolio.metrics | BCRAdmin/LIONCOM | reconcile/lioncom-origin-main-2026-05-02 | `npm run verify:portfolio-status` | keine Dependencies, keine Runtime-State-Commits, kein Deploy |
| LIONCOM Membership Readiness | membership.launchReadiness | BCRAdmin/LIONCOM | reconcile/lioncom-origin-main-2026-05-02 | `node scripts/verify_operator_readiness_pass.cjs` | Credential-Free Launch Readiness; kein Provider-, Mail-, Stripe-, Checkout-, Public- oder Production-Go |

## Portfolio Streams

- `materialbedarf.measurement`: Funnel- und Revenue-Vorbereitung, aber keine Monetarisierungsfreigabe.
- `elterngeld.trust`: Trust-/Quellenmatrix, Sonderfallführung und fachliche Review-Luecken.
- `membership.launchReadiness`: Credential-Free Launch Readiness für Quellwert/Membership; lokale QA und Runbook sichtbar, Credentials und Launch-Gates bleiben geschlossen.
- `room16.review`: interne Dossier-Review-Queue mit Gate-Reasons.
- `deterministic.outcomes`: 5D/10D/20D/60D-Outcome-Schnittstelle; fixture-only V1 ist intern grün, Public-/Advice-Gates bleiben geschlossen.
- `microtool.opportunities`: Scorecard und Backlog als Gate vor jedem Scaffold.
- `github.planBlocked`: Branch Protection und Secret Scanning bleiben ehrlich als Plan/API-blockiert markiert.
- `generatedStatePolicy`: Runtime-, Generated-, ZIP-, Build-, Report- und Dashboard-State-Dateien sind nicht commitbar.

## Globale Gates

- `BCRAdmin/Vivi-os-v1` bleibt archived, read-only, legacy und no-touch.
- Kein Stream setzt automatisch `productionGo`.
- Research-Streams setzen nicht automatisch `publicReady`.
- Branch Protection / Required Checks und Secret Scanning werden nur als aktiv behauptet, wenn GitHub-Plan/API und Repo-Wahrheit es belegen.
- Generated State, lokale Runtime-Dateien und Dashboard-State bleiben ausserhalb von Commits.

## Abschlusslesart

Portfolio Control Tower V2 ist eine Integrations- und Sichtbarkeitsschicht. Die einzelnen Worker-Verifier und GitHub Actions bleiben führend für ihre Repo-Lane; Operator-Go bleibt führend für Production, Public, Geld, Provider, Credentials und irreversible Aktionen.
