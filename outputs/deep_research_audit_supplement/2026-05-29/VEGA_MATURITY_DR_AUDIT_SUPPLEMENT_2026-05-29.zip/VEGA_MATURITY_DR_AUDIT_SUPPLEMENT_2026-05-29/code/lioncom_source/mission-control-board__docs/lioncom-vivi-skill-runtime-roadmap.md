# LIONCOM Vivi Skill Runtime Roadmap

Stand: 2026-05-17
Status: Planungsanker fuer den naechsten Umsetzungsschnitt

## Operator-Ziel

Vivi soll im LIONCOM Control Plane Chat nicht nur Nachrichten ablegen oder Arbeit an die Queue schieben. Vivi soll als primaere Operator-Assistentin aktiv antworten, Aufgaben verstehen, passende Faehigkeiten finden, lokale und cloudbasierte Werkzeuge bewusst auswaehlen und einfache Aufgaben direkt ausfuehren.

Die Zielrichtung ist OpenClaw-aehnlich:

- Vivi erkennt aus einer Chatnachricht, ob es sich um normalen Dialog, eine Aufgabe, eine Skill-Anfrage, einen Tool-Aufruf, eine Recherche, ein Artefakt oder einen Vega-Handoff handelt.
- Vivi kennt vorhandene lokale Skills, Modelle, Provider, Rails und sichere Tools.
- Vivi kann Skills aktivieren und ausfuehren, wenn sie lokal vorhanden und sicher freigegeben sind.
- Vivi kann fehlende Skills als Spezifikation vorschlagen, statt stumm zu scheitern oder beliebigen Code zu installieren.
- Vega/Codex bleibt die Tech Cell fuer Code, Debugging, Verifikation, Tests, Diffs, Installer und riskante Aenderungen.
- Gefaehrliche Aktionen bleiben Operator-Gates: externe Sends, Credentials/Auth, Geld, Loeschen, Production Deploys und unbekannter Remote-Code.

Beispiel-Ziel:
Wenn der Operator schreibt `erstelle mir ein Bild von ...`, soll Vivi nicht einfach eine Queue-Notiz erzeugen. Vivi soll erkennen: `image.generate` wird gebraucht, pruefen welche Bild-Skills oder Provider lokal verfuegbar sind, einen passenden Runtime-Weg nutzen oder ehrlich eine fehlende Provider-/Skill-Karte mit naechster Handlung anzeigen.

## Aktueller Stand

Vorhanden:

- Control Plane V2 mit getrennten Vivi- und Vega-Ansichten.
- `/api/vivi-chat` mit direkter Vivi-Antwort fuer normale Dialoge.
- Taskartige Nachrichten koennen weiter in `VIVI_COMMAND_QUEUE.md` und `WORK_INTAKE.md` gehen.
- Lokale Modell-/Provider-Auswahl fuer Vivi inklusive LM Studio, Ollama und OpenRouter-Katalog.
- Autonomy Rails, Night-Run, Quality Gate, Golden Baseline, Visual-QA und Release-Gates.
- Vega als Code-/Verifier-Zelle.

Fehlt:

- Keine echte App-Level-Skill-Registry.
- Kein Skill-Hub / ClawHub-aehnlicher Katalog.
- Kein Capability-Router zwischen Chat, Skill, Queue und Vega-Handoff.
- Kein Skill-Ausfuehrungsprotokoll mit Artefakten.
- Kein Installer-/Enable-Flow fuer lokale oder remote Skills.
- Keine Skill-Builder-Rail, bei der Vivi fehlende Skills entwirft und Vega sie baut/verifiziert.
- Kein operatorfreundliches Skill-Toolbelt in der Vivi-UI.

## Zielarchitektur

### 0. External Skill Review Reference

External skills, ClawHub-style packages, repos, hooks, providers, and Deep Research skill recommendations remain pattern sources by default.

Read-only reference docs:

- `docs/skills/EXTERNAL_SKILL_INTAKE_SOP.md`
- `docs/skills/SKILL_AUTHORING_POLICY.md`
- `docs/memory/OBSIDIAN_MEMORY_PROMOTION_MAP.md`
- `docs/skills/VIVI_EXTERNAL_SKILL_REVIEW_CONTRACT.md`
- `docs/skills/SKILL_RESEARCH_HANDOFF_PROTOCOL.md`
- `docs/skills/NO_RUNTIME_INSTALL_WITHOUT_GATE.md`
- `docs/skills/VIVI_SKILL_REVIEW_EXAMPLES.md`
- `docs/skills/CLAW_SKILL_PATTERN_DECISION_MATRIX.md`

Rules:

- External skills are not runtime candidates unless they pass External Skill Intake SOP plus Operator Gate.
- Obsidian is the Backbone; no second memory layer.
- `source_not_verified` is pre-triage only, not trust.
- No API Gateway, Desktop Control, Proactive-full, phone-home scanner, silent auto-update, or background agent is enabled by reference docs.

### 1. Capability Model

Neues internes Faehigkeitsmodell:

- `chat.direct`
- `task.queue`
- `dispatch.route`
- `memory.capture`
- `obsidian.read`
- `obsidian.write_safe`
- `repo.inspect`
- `code.patch`
- `code.test`
- `browser.inspect`
- `web.research`
- `image.generate`
- `image.edit`
- `document.create`
- `presentation.create`
- `spreadsheet.analyze`
- `automation.schedule`
- `telegram.bridge`
- `vega.handoff`

Neue TypeScript-Typen:

- `SkillManifest`
- `SkillCapability`
- `SkillRiskLevel`
- `SkillPermission`
- `SkillRuntime`
- `SkillInvocation`
- `SkillResult`
- `SkillArtifact`
- `SkillInstallSource`
- `SkillHealth`
- `CapabilityRouteDecision`

### 2. Skill Registry

Ziel:
Vivi kann alle verfuegbaren Skills und deren Zustand sehen.

Geplante Dateien:

- `lib/vivi-skills/types.ts`
- `lib/vivi-skills/registry.ts`
- `lib/vivi-skills/builtin-skills.ts`
- `data/vivi-skills/catalog.json`
- `.runtime/vivi-skills/enabled-skills.json`
- `.runtime/vivi-skills/runs.jsonl`

Geplante APIs:

- `GET /api/vivi-skills`
- `GET /api/vivi-skills/[skillId]`
- `POST /api/vivi-skills/run`
- `POST /api/vivi-skills/enable`
- `POST /api/vivi-skills/disable`

MVP-Skills:

- `lioncom.status.read`
- `vivi.memory.capture`
- `vivi.dispatch.create`
- `vivi.model.route`
- `vega.handoff.create`
- `repo.inspect.readonly`
- `browser.qa.inspect`
- `image.generate.provider-check`

### 3. Safety- und Permission-Rails

Jeder Skill bekommt eine deklarierte Risikoklasse:

- `safe_local_read`
- `safe_local_write`
- `external_read`
- `external_send`
- `credentials_auth`
- `money_payment`
- `destructive_delete`
- `production_deploy`
- `remote_code_install`

Regel:
Vivi darf sichere lokale Reads und klar begrenzte lokale Writes ausfuehren. Alles mit externem Send, Auth, Geld, Loeschung, Deploy oder Remote-Code braucht ein Operator-Gate und bei Code/Installer zusaetzlich Vega-Verifikation.

### 4. Capability Router

Ziel:
`/api/vivi-chat` entscheidet nicht mehr nur `Dialog oder Queue`, sondern:

- direkter Vivi-Dialog
- Skill ausfuehren
- Aufgabe an Vivi-Queue
- Handoff an Vega
- Operator-Gate anfordern
- fehlenden Skill als Vorschlag anlegen

Geplante Datei:

- `lib/vivi-skills/capability-router.ts`

Routing-Beispiele:

- `hallo`, `was ist der stand` -> `chat.direct`
- `erstelle mir ein bild...` -> `image.generate`
- `lies den letzten report und fasse zusammen` -> `obsidian.read` oder `memory/read`
- `fixe den bug im repo` -> `vega.handoff.create`
- `loesche alte daten` -> Operator-Gate
- `deploye produktiv` -> Operator-Gate

### 5. Skill Runtime

Ziel:
Skill-Ausfuehrungen werden nachvollziehbar und operatorfreundlich.

Jeder Skill-Run speichert:

- Run-ID
- Session-ID
- Operator-Message-ID
- Skill-ID
- Capability
- Inputs
- Permission-Entscheidung
- Ergebnisstatus
- Artefakte
- naechste Handlung
- Audit-Referenz

Keine rohen internen Dumps in der UI. Die UI zeigt kurze, nutzbare Operator-Infos:

- was Vivi versucht hat
- welches Tool/Modell genutzt wurde
- was herauskam
- ob ein Gate oder Provider fehlt
- wo das Artefakt liegt

### 6. Local Skill Hub

Phase 1 bleibt lokal und sicher.

Ziel:
Ein kuratierter lokaler Skill-Katalog, der ohne Netzwerk und ohne fremden Code funktioniert.

Funktionen:

- Skills anzeigen
- Skills aktivieren/deaktivieren
- Skill Health anzeigen
- Skills nach Capability suchen
- Skill-Details operatorfreundlich erklaeren
- fehlende Provider sichtbar machen

Noch kein automatisches Remote-Install in Phase 1.

### 7. Remote Skill Hub / ClawHub-aehnlicher Ausbau

Phase 2 fuegt kontrollierte Remote-Quellen hinzu.

Regeln:

- nur erlaubte Quellen
- Manifest zuerst lesen
- Checksumme/Signatur oder zumindest Hash erfassen
- Dry-Run-Install
- Vega-Verifikation vor Aktivierung
- Operator-Go fuer unbekannten Remote-Code
- kein stilles Installieren von Credentials oder Send-Tools

Moegliche Quellen:

- lokaler Skill-Ordner
- kuratierte GitHub-Repos
- spaeter ClawHub/OpenClaw-kompatible Manifeste, falls technisch passend

### 8. Skill Builder

Ziel:
Vivi darf fehlende Skills nicht wild selbst installieren, aber sie darf sie als saubere Spezifikation entwerfen.

Flow:

1. Operator fragt etwas an, fuer das kein Skill existiert.
2. Capability Router erkennt `missing_skill`.
3. Vivi erstellt eine `SkillSpec`.
4. Vega bekommt einen Tech-Cell-Handoff.
5. Vega baut, testet und registriert den Skill.
6. Vivi kann ihn danach nutzen.

Geplante API:

- `POST /api/vivi-skills/propose`

Geplante Artefakte:

- `.runtime/vivi-skills/proposals/*.md`
- `.runtime/vivi-skills/proposals/*.json`

### 9. Vivi UI Toolbelt

Ziel:
Die Vivi Command Ansicht bekommt sichtbare, aber kompakte Skill-Kontrolle.

UI-Bloecke:

- Aktive Skills
- Skill-Suche
- Skill Health
- letzter Skill-Run
- fehlende Provider
- sichere Aktionen
- gesperrte Aktionen mit Gate-Begruendung
- Artefakt-Vorschau

Wichtig:
Kein grosses neues UI-Konzept. Die bestehende dunkle V2-Command-Center-Sprache bleibt.

### 10. Image Generation als erster End-to-End-Schnitt

Warum:
Das Beispiel ist fuer den Operator sofort greifbar und testet die ganze Kette: Intent, Skill, Provider, Artefakt, UI, Gate.

MVP:

- Erkennung von Bildanfragen im Vivi-Chat.
- Skill `image.generate.provider-check`.
- Pruefung lokaler Provider:
  - ComfyUI
  - Stable Diffusion WebUI
  - lokaler Ordner/CLI, falls vorhanden
  - spaeter OpenAI/Replicate/andere APIs nur mit Credential-Gate
- Wenn Provider fehlt: klare Karte `Bild-Skill vorhanden, Provider fehlt`.
- Wenn Provider vorhanden: Bild erzeugen, Artefakt speichern, im Chat anzeigen.

Nicht erlaubt:

- fake Bild-Erfolg ohne Datei
- stiller externer Send
- API-Key-Annahme ohne Gate

### 11. Verifier und Release Gates

Neue Pruefungen:

- `scripts/verify_vivi_skill_registry.mjs`
- `scripts/verify_vivi_capability_router.mjs`
- `scripts/verify_vivi_skill_runtime.mjs`
- Erweiterung von `scripts/verify_vivi_session_lifecycle.mjs`
- Erweiterung von `scripts/verify_control_plane_v2_local.mjs`
- optional Visual-QA fuer Skill Toolbelt

Pflichtfaelle:

- normaler Chat bleibt Chat
- Bildanfrage geht an `image.generate`
- Codefix geht an Vega
- geloesch-/deploy-/credential-nahe Anfrage erzeugt Gate
- fehlender Skill erzeugt Proposal
- jeder Skill-Run wird auditiert
- UI zeigt keine Roh-JSON-Dumps

## Umsetzungsroadmap

### Block 0 - Spezifikation und Memory-Anker

Status: erledigt mit diesem Dokument.
ETA: 0.5h

Ergebnis:

- Operator-Ziel dauerhaft abgelegt.
- Scope gegen aktuellen Stand abgegrenzt.
- Roadmap fuer naechste Umsetzung festgelegt.

### Block 1 - Skill-Typen, Registry und lokale API

ETA: 1.5-2.5h

Tasks:

- TypeScript-Typen fuer Skills und Capabilities anlegen.
- Builtin-Skill-Katalog anlegen.
- Runtime-State fuer enabled Skills und Runs anlegen.
- `GET /api/vivi-skills` bauen.
- `GET /api/vivi-skills/[skillId]` bauen.
- Registry-Verifier bauen.

Akzeptanz:

- API listet Skills aus zentralem Katalog.
- Kein `any`.
- Fehlende Runtime-Dateien werden defensiv erzeugt.
- Verifier blockt kaputte Manifeste.

### Block 2 - Capability Router in Vivi Chat integrieren

ETA: 2-3h

Tasks:

- Router fuer Dialog, Skill, Queue, Vega-Handoff und Gate bauen.
- Bestehende `/api/vivi-chat`-Logik nicht brechen.
- Dialog bleibt direkt.
- Taskartige Nachrichten bleiben Queue-faehig.
- Skillartige Nachrichten werden als Skill-Intent erkannt.
- Vega-Codeaufgaben werden klar als Handoff markiert.

Akzeptanz:

- `hallo` erzeugt nur Chat.
- `erstelle ein bild...` erzeugt Skill-Intent.
- `fix den Code...` geht nicht an Vivi-Chat-Dauerloop, sondern an Vega-Handoff.
- `loesche/deploye/sende extern` erzeugt Gate.

### Block 3 - Skill Runtime und Audit Trail

ETA: 2-3h

Tasks:

- `POST /api/vivi-skills/run` bauen.
- Skill-Run-Records schreiben.
- Artefakt-Referenzen modellieren.
- Audit-Events fuer Skill-Starts und Ergebnisse erzeugen.
- Operatorfreundliche Ergebnistexte standardisieren.

Akzeptanz:

- Jeder Skill-Run hat Run-ID und Session-Bezug.
- Fehler sind lesbar, nicht intern.
- Audit Log kann Skill-Run nachvollziehen.

### Block 4 - Vivi Skill Toolbelt UI

ETA: 2-3h

Tasks:

- Kompakte Skill-Karte in Vivi Command.
- Skill-Liste / aktive Skills.
- Letzter Skill-Run.
- Provider-/Gate-Hinweise.
- Button-Funktionen mit echten Daten statt generischem Popup.

Akzeptanz:

- Keine ueberlappenden Panels.
- Deutschsprachige Texte.
- Keine Roh-JSON-/Debug-Flaechen.
- Bestehendes V2-Design bleibt erhalten.

### Block 5 - Erste Builtin-Skills

ETA: 3-4h

Skills:

- `lioncom.status.read`
- `vivi.memory.capture`
- `vivi.dispatch.create`
- `vivi.model.route`
- `vega.handoff.create`
- `repo.inspect.readonly`
- `browser.qa.inspect`

Akzeptanz:

- Vivi kann in einem Chat sichtbar sagen, welchen Skill sie verwendet.
- Skills laufen lokal.
- Gefaehrliche Aktionen bleiben gesperrt.

### Block 6 - Image Generation Vertical Slice

ETA: 2-4h, abhaengig von lokal verfuegbarem Bildprovider

Tasks:

- `image.generate.provider-check` bauen.
- Lokale Provider erkennen.
- Falls Provider fehlt: konkrete Setup-/Provider-Karte anzeigen.
- Falls Provider vorhanden: Bildlauf mit Artefaktpfad.
- Chat-Bubble mit Artefakt-Vorschau.

Akzeptanz:

- Bildanfrage verschwindet nicht in der Queue.
- Kein Fake-Erfolg.
- Externe APIs nur mit Gate.

### Block 7 - Skill Proposal und Vega Builder Loop

ETA: 3-5h

Tasks:

- Missing-Skill-Proposal erzeugen.
- Proposal-Dateien in Runtime schreiben.
- Vega-Handoff fuer Skill-Bau erzeugen.
- Verifier fuer neue Skill-Manifeste.
- UI-Hinweis `Skill vorgeschlagen / wartet auf Vega`.

Akzeptanz:

- Vivi kann fehlende Faehigkeiten sauber formulieren.
- Vega baut/verifiziert statt Vivi beliebigen Code auszufuehren.

### Block 8 - Remote Skill Hub

ETA: 4-8h

Tasks:

- Remote-Catalog-Format definieren.
- Allowlist fuer Quellen.
- Dry-Run-Install.
- Hash/Manifest-Pruefung.
- Operator-Go.
- Vega-Verifikation vor Aktivierung.

Akzeptanz:

- Kein stiller Remote-Code.
- Kein Credential-Leak.
- Installierte Skills sind nachvollziehbar und abschaltbar.

### Block 9 - Autonomer Skill-Betrieb

ETA: 3-5h

Tasks:

- Vivi kann im Dauerloop sichere Skills nutzen.
- Skills schreiben Memory nur bei dauerhaften Learnings.
- Skill-Fails erzeugen sinnvolle naechste Aktionen.
- Wiederholte Skill-Fails eskalieren zu Vega.

Akzeptanz:

- Kein Endlosdrehen auf kaputtem Skill.
- Keine Scope-Drift aus LIONCOM.
- Operator sieht jederzeit, was Vivi gerade tut.

## Priorisierte Umsetzung

Empfohlene Reihenfolge:

1. Block 1 Registry/API
2. Block 2 Capability Router
3. Block 3 Skill Runtime
4. Block 4 UI Toolbelt
5. Block 6 Image Generation als sichtbarer Beweis
6. Block 5 weitere Builtin-Skills
7. Block 7 Skill Proposal
8. Block 8 Remote Hub
9. Block 9 autonomer Skill-Betrieb

Warum:
Erst muss Vivi wissen, welche Faehigkeiten existieren. Danach kann sie Chat-Intents sauber routen. Erst danach lohnt sich UI und Bildgenerierung.

## Nicht-Ziele fuer den naechsten Schnitt

- Kein unkontrollierter Fork von OpenClaw.
- Kein Remote-Code-Install ohne Gate.
- Kein Umbau der gesamten V2-UI.
- Kein Ersetzen von Vega durch Vivi im Code-/Verifier-Bereich.
- Kein externer Send oder Provider-Key ohne Operator-Go.

## Erfolgskriterien

Der naechste robuste Meilenstein ist erreicht, wenn:

- Vivi im Chat eine Skill-Anfrage erkennt.
- Vivi erklaert, welchen Skill sie nutzt.
- Vivi den Skill ausfuehrt oder sauber fehlende Provider meldet.
- Skill-Runs auditiert werden.
- Gefaehrliche Aktionen Gates erzeugen.
- Vega automatisch als Tech Cell fuer Code-/Skill-Bau genutzt wird.
- Der Operator nicht mehr zwischen Chat, Queue und Tool-Rails raten muss.
