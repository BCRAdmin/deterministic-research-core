# BCRAdmin Portfolio Execution Contract

Stand: 2026-05-18

Status: canonical

## Zweck

Dieser Contract ersetzt lose Handoff-Wahrheit im BCRAdmin-Portfolio durch eine klare Execution-Governance.

Er gilt fuer:

- Vega
- Vega 0
- Vivi
- Room16 / Company Dossier Lab
- Deterministic Research Core
- Utility-Webseiten
- Microtool Starter Kit
- LIONCOM selbst
- Operator-Go-Prozesse

Dieser Contract ist kein Production-, Public-, Financial-Advice-, Provider-, Payment- oder Credential-Go. Er beschreibt, wie Arbeit entschieden, verifiziert, sichtbar gemacht und integriert wird.

## Truth-Hierarchy

Die fuehrende Wahrheit wird in dieser Reihenfolge gelesen:

1. Operator-Go oder Operator-Hold
2. GitHub/CI-Status nach Push
3. Lokale Verifier und Domain-Gates
4. LIONCOM Control Tower
5. Vega-0-Integration und kanonisches Backbone-Memory
6. Projekt- und Role-Registry-Dokumentation
7. Handoff-, Chat-, Queue- und Runtime-Dateien

Eine Handoff-Datei, ein Chat-Report oder eine lokale Queue darf nie alleinige Wahrheit sein. Wenn sie einer hoeheren Ebene widerspricht, gewinnt die hoeher gelistete Ebene.

## Operator-Go

Operator-Go ist erforderlich fuer:

- Production-Launch, Public-Output, DNS, Domain-Switch oder Provider-Umschaltung
- Financial-Advice, Research-Publishing oder oeffentliche Rating-/Guidance-Flaechen
- Credentials, Auth, Secrets, Tokens oder Rechte
- Payment, Checkout, Subscriptions, Rechnungen oder Provider-Abrechnung
- externe E-Mails, Social Posts, Partnerkontakte oder irreversible Zusagen
- Loeschen, irreversible Migrationen oder History-Rewrites
- Dependency-Upgrades ausserhalb eines explizit beauftragten Wartungsschnitts

Gruene Checks, ein fertiger Report oder ein lokaler Preview-Zustand ersetzen kein Operator-Go.

## Erlaubter Standardpfad

Ohne zusaetzliches Operator-Go duerfen Agents:

- Contract-, Rollen- und Projekt-Dokumentation pflegen
- nicht-mutierende Verifier bauen oder schaerfen
- lokale UI-/API-Anzeigen fuer Status und Links ergaenzen
- lokale Proofs, Dry-Runs, Preview-Artefakte und Handoff-Pakete vorbereiten
- kleine Commits pushen, wenn der Auftrag das Pushen erlaubt und die Verifier gruen sind

Dabei bleiben Runtime-, Generated-, Build-, Report-, ZIP- und Dashboard-State-Dateien aus Commits heraus.

## Rollenmodell

### Operator

Der Operator setzt Ziel, Prioritaet, harte Gates und finale externe Freigaben.

### Vega

Vega ist Supervisor, Integrator und Verifier. Vega liest Backbone zuerst, prueft Diffs, baut oder repariert lokale Artefakte, laesst Verifier laufen und stoppt bei roten Gates.

### Vega 0

Vega 0 ist die Integrations- und Reconciliation-Schicht fuer Portfolio-Wahrheit. Vega 0 uebernimmt nur verifizierte Ergebnisse, fuehrt sie in die kanonische Wahrheit zurueck und darf keine roten Verifier, fehlenden Operator-Go oder Public-/Financial-Gates ueberstimmen.

### Vivi

Vivi ist die operative, recherchierende und berichtende Rolle. Vivi arbeitet in kleinen Claims, liefert konkrete Belege, bereitet Handoffs vor und eskaliert Production, Geld, Auth, Credentials, Loeschen, rechtliche Finalisierung und externe Sends.

### LIONCOM

LIONCOM ist die aktive Control Plane. Es macht Status, Gates, Verifier, CI-Stand und naechste Aktion sichtbar, ist aber keine alleinige Wahrheitsschicht gegen Operator-Go, CI oder Verifier.

### Room16

Room16 / Company Dossier Lab bleibt eine Report- und Dossier-Lane. Report-Machine-, API-Guard-, Public-Gate- und Build-Verifier sind fuehrend; Public- und Financial-Advice-Freigaben bleiben geschlossen.

### Deterministic Research Core

Deterministic-Core bleibt die deterministische Regel-, Audit- und Guardrail-Schicht. Audit-Registry, Tests und Coverage-Belege fuehren; keine Research-Publishing- oder Advice-Freigabe entsteht automatisch.

### Utility-Webseiten

Utility-Webseiten duerfen lokal gemessen, verbessert und verifiziert werden. Production, Monetarisierung, AdSense/CMP/TCF, Partnerprogramme und Public-Copy-Gates bleiben Operator-Gates.

### Microtool Starter Kit

Das Starter-Kit ist eine Template- und Factory-Lane. Template-Checks und Opportunity-Gates duerfen verbessert werden; ein neues oeffentliches Microtool, Scaffold-Produkt oder Launch entsteht nur mit Operator-Go.

## Verifier-Vertrag

Der kanonische Portfolio-Verifier ist:

```bash
npm run verify:portfolio-status
```

Er muss mindestens pruefen:

- alle sieben Portfolio-Repos sind sichtbar
- `BCRAdmin/Vivi-os-v1` bleibt archived/read-only/legacy/no-touch
- Production/Public und Financial-Advice sind Operator-Gates
- Branch Protection und Secret Scanning sind ehrlich als plan-/repo-blockiert markiert
- Dependabot, CI und lokale Verifier bleiben Primaerschutz
- LIONCOM-Maintenance-Versionen bleiben unveraendert, solange kein Dependency-Go existiert
- Contract- und Role-Registry-Dokumentation existieren und enthalten die Truth-Hierarchy
- UI/API zeigt den Execution Contract im Portfolio Control Tower

Wenn dieser Verifier rot ist, stoppt der Lauf und es wird berichtet. Es gibt keinen Commit oder Push.

## Control-Tower-Vertrag

Der Portfolio Control Tower zeigt:

- Portfolio-Baseline
- Repo-Status
- Operator-Gates
- GitHub-/Security-Blocker
- Execution-Contract-Version
- Contract- und Role-Registry-Pfade
- Fuehrende Truth-Hierarchy

Die Anzeige ist eine Operator-Oberflaeche, kein Ersatz fuer Verifier, CI oder Operator-Go.

## No-Touch-Regeln

- keine Arbeit an `BCRAdmin/Vivi-os-v1`
- keine Aenderung an Room16-Gates ohne eigenen Auftrag
- keine Aenderung an Deterministic-Core-Gates ohne eigenen Auftrag
- keine Dependency- oder Lockfile-Aenderung ohne explizites Operator-Go
- keine Runtime- oder Generated-Dateien committen
- `dashboard/data/golden_baseline_status.json` bleibt generated und nicht commitbar

## Abschlussregel

Ein Portfolio-Schnitt gilt erst als abgeschlossen, wenn:

1. die erlaubten Doku-/UI-/Verifier-Aenderungen versioniert sind,
2. lokale Verifier gruen sind,
3. keine gesperrten Dateien im Commit sind,
4. der Commit klein und nachvollziehbar ist,
5. Push nur bei explizit erlaubtem Push-Go erfolgt,
6. dauerhafte Learnings ins Backbone oder in Pending-Sync geschrieben wurden.
