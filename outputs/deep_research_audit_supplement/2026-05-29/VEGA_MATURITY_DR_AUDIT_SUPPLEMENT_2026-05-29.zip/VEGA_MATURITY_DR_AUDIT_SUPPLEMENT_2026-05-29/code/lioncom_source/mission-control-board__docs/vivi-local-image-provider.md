# Vivi Lokaler Bildprovider

Ziel: Vivi soll Bilder lokal erzeugen koennen, ohne Abo, ohne Cloud-Send und ohne Fake-Erfolg.

## Entscheidung

- Fuehrender lokaler Provider fuer Vivis aktuellen Skill ist Stable Diffusion WebUI auf `http://127.0.0.1:7860`.
- Vivis Skill `image.generate.local` nutzt die lokale WebUI-API `/sdapi/v1/txt2img`.
- ComfyUI auf `http://127.0.0.1:8188` wird erkannt, aber noch nicht als generische Workflow-Ausfuehrung genutzt.
- Cloud-Bildprovider bleiben Operator-Gate und sind fuer diesen Pfad nicht noetig.

## Kommandos

Aus `mission-control-board`:

```bash
npm run vivi:image:preflight
npm run vivi:image:install-provider
npm run vivi:image:start-provider
npm run vivi:image:provider-check
npm run vivi:image:generate -- --prompt "hyperrealistisches Portrait einer freundlichen Agentin, Studio-Licht"
```

## Speicherregel

Der Provider braucht lokal schnell viel Platz. Der Install-Guard verlangt standardmaessig mindestens 25 GB freien Speicher, damit macOS nicht volllaeuft. Fuer Provider plus brauchbares Modell sind 35 GB freier Speicher entspannter.

Aktive Pfade:

- Provider: `$HOME/Library/Application Support/LIONCOM/local-image-provider/stable-diffusion-webui`
- Modelle: `$HOME/Library/Application Support/LIONCOM/local-image-provider/stable-diffusion-webui/models/Stable-diffusion`
- Vivi-Bildartefakte: `$HOME/Library/Application Support/LIONCOM/runtime-workspace/.runtime/vivi-skills/artifacts/images`
- Provider-Status: `$HOME/Library/Application Support/LIONCOM/runtime-workspace/.runtime/vivi-skills/image-provider/LOCAL_IMAGE_PROVIDER_STATUS.md`

## Modellregel

Mindestens ein `.safetensors`- oder `.ckpt`-Modell muss im Modellordner liegen. Die Lizenz des konkreten Modells entscheidet, ob kommerzielle Nutzung erlaubt ist. Fuer BCR/Vivi gilt: nur Modelle nutzen, deren Lizenz kommerzielle Nutzung erlaubt oder bei unserem Umsatzstand klar abdeckt.

## Betriebsregel

Vivi darf bei Bildwunsch nicht auf generische Cloud-Bildtools ausweichen, wenn der Operator explizit Vivis Skill meint. Der Ablauf ist:

1. Lokalen Provider pruefen.
2. Wenn erreichbar: `image.generate.local` ausfuehren.
3. Wenn nicht erreichbar: `missing-provider` plus Provider-Status-Artefakt schreiben.
4. Kein Fake-Bild und kein stiller Cloud-Send.
