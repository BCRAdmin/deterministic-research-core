import { promises as fs } from 'fs';
import { join } from 'path';

import { WORKSPACE_ROOT } from '../constants/paths';

const GIT_DIR = join(WORKSPACE_ROOT, '.git');

export async function isGitRepo(): Promise<boolean> {
  try {
    await fs.access(GIT_DIR);
    return true;
  } catch {
    return false;
  }
}

export async function getCurrentBranch(): Promise<string> {
  try {
    const headContent = await fs.readFile(join(GIT_DIR, 'HEAD'), 'utf-8');
    const match = headContent.match(/ref: refs\/heads\/(\S+)/);
    return match ? match[1] : 'detached';
  } catch {
    return 'unknown';
  }
}

export async function getLastCommit(): Promise<{ hash: string; message: string } | null> {
  try {
    const branch = await getCurrentBranch();
    if (branch === 'unknown') return null;

    let hash = '';
    if (branch === 'detached') {
      hash = (await fs.readFile(join(GIT_DIR, 'HEAD'), 'utf-8')).trim();
    } else {
      const refPath = join(GIT_DIR, 'refs', 'heads', branch);
      hash = await fs.readFile(refPath, 'utf-8');
    }

    const shortHash = hash.trim().substring(0, 7);

    return {
      hash: shortHash,
      message: 'Commit ' + shortHash,
    };
  } catch {
    return null;
  }
}

export async function hasRemote(): Promise<boolean> {
  try {
    const config = await fs.readFile(join(GIT_DIR, 'config'), 'utf-8');
    return config.includes('[remote "origin"]');
  } catch {
    return false;
  }
}
