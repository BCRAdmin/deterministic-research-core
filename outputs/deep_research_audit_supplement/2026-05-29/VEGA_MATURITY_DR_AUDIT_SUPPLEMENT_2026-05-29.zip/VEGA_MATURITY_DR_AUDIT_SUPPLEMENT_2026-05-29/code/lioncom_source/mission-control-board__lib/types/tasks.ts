// Task Management Types

export interface Task {
  id: string;
  title: string;
  priority: 'P0' | 'P1' | 'P2' | 'P3';
  status: 'open' | 'in-progress' | 'waiting' | 'review' | 'done';
  deadline?: string;
  assignee?: string;
}

export interface TaskQueue {
  active: Task[];
  waiting: Task[];
  completed: CompletedTask[];
}

export interface CompletedTask extends Task {
  completedAt: string;
  duration?: string;
  result?: string;
}

export interface BacklogItem {
  id: string;
  task: string;
  description: string;
  priority: 'P0' | 'P1' | 'P2' | 'P3';
  createdAt: string;
}

export interface Backlog {
  p0: BacklogItem[];
  p1: BacklogItem[];
  p2: BacklogItem[];
  p3: BacklogItem[];
}
