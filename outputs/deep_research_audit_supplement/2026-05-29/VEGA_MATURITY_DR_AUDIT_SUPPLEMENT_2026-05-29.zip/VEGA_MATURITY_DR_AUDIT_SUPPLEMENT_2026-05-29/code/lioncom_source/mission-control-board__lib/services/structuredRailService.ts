import { promises as fs } from 'fs';
import path from 'path';

export interface StructuredRailBlock {
  id: string;
  fields: Record<string, string>;
  lines: string[];
}

export async function ensureRailFile(filePath: string, header: string): Promise<void> {
  try {
    await fs.access(filePath);
  } catch {
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    await fs.writeFile(filePath, normalizeHeader(header), 'utf-8');
  }
}

export async function readRailContent(filePath: string): Promise<string | null> {
  try {
    return await fs.readFile(filePath, 'utf-8');
  } catch {
    return null;
  }
}

export async function appendRailBlock(filePath: string, header: string, block: string): Promise<void> {
  await ensureRailFile(filePath, header);
  await fs.appendFile(filePath, block.endsWith('\n') ? block : `${block}\n`, 'utf-8');
}

export async function transformRailBlocks(
  filePath: string,
  header: string,
  transform: (block: StructuredRailBlock) => StructuredRailBlock | null,
): Promise<{ changed: number; blocks: StructuredRailBlock[] }> {
  const content = await readRailContent(filePath);
  const headerPrefix = extractHeader(content, header);
  const parsed = parseRailBlocks(content);

  let changed = 0;
  const nextBlocks = parsed
    .map((block) => {
      const updated = transform({
        id: block.id,
        fields: { ...block.fields },
        lines: [...block.lines],
      });

      if (!updated) {
        changed += 1;
        return null;
      }

      if (JSON.stringify(updated.lines) !== JSON.stringify(block.lines)) {
        changed += 1;
      }

      return updated;
    })
    .filter((block): block is StructuredRailBlock => Boolean(block));

  if (changed > 0 || !content) {
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    await fs.writeFile(filePath, serializeRail(headerPrefix, nextBlocks), 'utf-8');
  }

  return { changed, blocks: nextBlocks };
}

export function parseRailBlocks(content: string | null): StructuredRailBlock[] {
  if (!content) return [];

  return content
    .split(/^###\s+/m)
    .map((section) => section.trim())
    .filter(Boolean)
    .flatMap((section) => {
      const [headline, ...bodyLines] = section.split('\n');
      const id = headline?.trim();
      if (!id || id.startsWith('#')) return [];

      const fields: Record<string, string> = {};
      for (const line of bodyLines) {
        const match = line.trim().match(/^\-\s*([^:]+):\s*(.+)$/);
        if (match) {
          fields[match[1].trim()] = match[2].trim();
        }
      }

      return [{ id, fields, lines: bodyLines } satisfies StructuredRailBlock];
    });
}

export function updateBlockField(lines: string[], field: string, value: string): string[] {
  const nextLines = [...lines];
  const prefix = `- ${field}:`;
  const index = nextLines.findIndex((line) => line.trim().startsWith(prefix));

  if (index >= 0) {
    nextLines[index] = `${prefix} ${value}`;
    return nextLines;
  }

  const messageIndex = nextLines.findIndex((line) => line.trim().startsWith('- Message:'));
  const insertAt = messageIndex >= 0 ? messageIndex : nextLines.length;
  nextLines.splice(insertAt, 0, `${prefix} ${value}`);
  return nextLines;
}

export function extractField(lines: string[], field: string): string | undefined {
  const prefix = `- ${field}:`;
  const line = lines.find((entry) => entry.trim().startsWith(prefix));
  return line ? line.trim().slice(prefix.length).trim() : undefined;
}

function extractHeader(content: string | null, fallbackHeader: string): string {
  if (!content) return normalizeHeader(fallbackHeader);

  const markerIndex = content.search(/^###\s+/m);
  if (markerIndex === -1) {
    return normalizeHeader(content || fallbackHeader);
  }

  return normalizeHeader(content.slice(0, markerIndex));
}

function normalizeHeader(header: string): string {
  return header.endsWith('\n\n') ? header : header.endsWith('\n') ? `${header}\n` : `${header}\n\n`;
}

function serializeRail(header: string, blocks: StructuredRailBlock[]): string {
  const serializedBlocks = blocks.map((block) => {
    const body = block.lines.join('\n').trimEnd();
    return `### ${block.id}\n${body}`.trimEnd();
  });

  return `${normalizeHeader(header)}${serializedBlocks.length ? `${serializedBlocks.join('\n\n')}\n` : ''}`;
}
