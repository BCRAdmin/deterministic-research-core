import 'server-only';

import os from 'os';
import path from 'path';
import { promises as fs } from 'fs';

export interface DesktopSettings {
  workspaceRoot?: string;
  viviProviderPreset?: 'chatgpt' | 'ollama' | 'lmstudio' | string;
  viviRequestedModel?: string;
}

function supportDir() {
  return path.join(os.homedir(), 'Library', 'Application Support', 'LIONCOM');
}

export function getDesktopSettingsPath() {
  return path.join(supportDir(), 'settings.json');
}

export async function readDesktopSettings(): Promise<DesktopSettings> {
  try {
    return JSON.parse(await fs.readFile(getDesktopSettingsPath(), 'utf-8')) as DesktopSettings;
  } catch {
    return {};
  }
}

export async function saveDesktopSettings(patch: DesktopSettings): Promise<DesktopSettings> {
  const next = {
    ...(await readDesktopSettings()),
    ...patch,
  };

  await fs.mkdir(supportDir(), { recursive: true });
  await fs.writeFile(getDesktopSettingsPath(), `${JSON.stringify(next, null, 2)}\n`, 'utf-8');
  return next;
}
