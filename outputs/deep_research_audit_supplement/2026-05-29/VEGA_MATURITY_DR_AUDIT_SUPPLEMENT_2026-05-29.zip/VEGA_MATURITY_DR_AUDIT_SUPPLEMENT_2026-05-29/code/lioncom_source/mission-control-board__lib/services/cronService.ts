// Cron Service - Nur read-only Cron-Informationen
// Keine Schreiboperationen, keine Trigger

import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

export interface CronEntry {
  schedule: string;
  command: string;
  active: boolean;
}

export interface CronStatus {
  available: boolean;
  entries: CronEntry[];
  hasMorningBriefing: boolean;
  hasNightlyResearch: boolean;
  hasBackup: boolean;
  error?: string;
}

/**
 * Liest die aktuelle Crontab
 * @returns CronStatus oder unknown bei Fehler
 */
export async function getCronStatus(): Promise<CronStatus> {
  try {
    const { stdout } = await execAsync('crontab -l');
    const lines = stdout.split('\n');
    
    const entries: CronEntry[] = [];
    let hasMorningBriefing = false;
    let hasNightlyResearch = false;
    let hasBackup = false;
    
    for (const line of lines) {
      // Ignoriere Kommentare und Leerzeilen
      if (!line.trim() || line.startsWith('#')) continue;
      
      // Suche nach bekannten Jobs
      if (line.includes('morning_briefing')) {
        hasMorningBriefing = true;
        entries.push({
          schedule: extractSchedule(line),
          command: 'morning_briefing',
          active: true
        });
      } else if (line.includes('nightly_research')) {
        hasNightlyResearch = true;
        entries.push({
          schedule: extractSchedule(line),
          command: 'nightly_research',
          active: true
        });
      } else if (line.includes('backup_daily')) {
        hasBackup = true;
        entries.push({
          schedule: extractSchedule(line),
          command: 'backup',
          active: true
        });
      }
    }
    
    return {
      available: true,
      entries,
      hasMorningBriefing,
      hasNightlyResearch,
      hasBackup
    };
  } catch (error) {
    // Keine Crontab oder Fehler
    return {
      available: false,
      entries: [],
      hasMorningBriefing: false,
      hasNightlyResearch: false,
      hasBackup: false,
      error: 'Cron nicht verfuegbar oder nicht konfiguriert'
    };
  }
}

/**
 * Prueft ob Morning Briefing eingeplant ist
 */
export async function isMorningBriefingScheduled(): Promise<boolean> {
  const status = await getCronStatus();
  return status.hasMorningBriefing;
}

/**
 * Prueft ob Nightly Research eingeplant ist
 */
export async function isNightlyResearchScheduled(): Promise<boolean> {
  const status = await getCronStatus();
  return status.hasNightlyResearch;
}

/**
 * Extrahiert Schedule aus Cron-Zeile (erste 5 Felder)
 */
function extractSchedule(line: string): string {
  const parts = line.trim().split(/\s+/);
  if (parts.length >= 5) {
    return parts.slice(0, 5).join(' ');
  }
  return 'unknown';
}
