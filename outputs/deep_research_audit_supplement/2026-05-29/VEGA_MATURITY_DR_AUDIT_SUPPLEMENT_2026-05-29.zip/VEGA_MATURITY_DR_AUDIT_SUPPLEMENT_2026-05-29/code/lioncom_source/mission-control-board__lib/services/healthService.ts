// Health Service - Verdichtungsschicht fuer Gesamtzustand
// Aggregiert Git, Cron, Telegram zu Board-tauglichem Health-Status
// Keine neuen Dateizugriffe, keine eigene Parserlogik

import { getCronStatus } from './cronService';
import { syncGitHubSyncStatus } from './githubSyncService';
import { getTelegramStatus } from './telegramService';

export type SystemHealth = 'healthy' | 'warning' | 'error' | 'unknown';

export interface HealthCheck {
  overall: SystemHealth;
  components: {
    git: SystemHealth;
    cron: SystemHealth;
    telegram: SystemHealth;
  };
  timestamp: string;
}

/**
 * Aggregiert alle Services zu einem Gesamtzustand
 * Nur Verdichtung, keine neue Logik
 */
export async function getSystemHealth(): Promise<HealthCheck> {
  const timestamp = new Date().toISOString();
  
  // Git-Status
  const gitHealth = await checkGitHealth();
  
  // Cron-Status
  const cronHealth = await checkCronHealth();
  
  // Telegram-Status
  const telegramHealth = await checkTelegramHealth();
  
  // Gesamtzustand ableiten
  const overall = deriveOverallHealth(gitHealth, cronHealth, telegramHealth);
  
  return {
    overall,
    components: {
      git: gitHealth,
      cron: cronHealth,
      telegram: telegramHealth
    },
    timestamp
  };
}

/**
 * Git-Health aus vorhandenen Services
 */
async function checkGitHealth(): Promise<SystemHealth> {
  const sync = await syncGitHubSyncStatus().catch(() => null);
  if (!sync) return 'unknown';
  if (sync.state === 'healthy') return 'healthy';
  if (sync.state === 'warning') return 'warning';
  if (sync.state === 'blocked' || sync.state === 'offline') return 'warning';
  return 'unknown';
}

/**
 * Cron-Health aus vorhandenen Services
 */
async function checkCronHealth(): Promise<SystemHealth> {
  const cronStatus = await getCronStatus();
  
  if (!cronStatus.available) return 'error';
  if (!cronStatus.hasMorningBriefing) return 'warning';
  if (cronStatus.error) return 'warning';
  
  return 'healthy';
}

/**
 * Telegram-Health aus vorhandenen Services
 */
async function checkTelegramHealth(): Promise<SystemHealth> {
  const tgStatus = await getTelegramStatus();
  
  if (tgStatus.status === 'OK') return 'healthy';
  if (tgStatus.status === 'WARNING') return 'warning';
  
  return 'unknown';
}

/**
 * Gesamtzustand ableiten
 * error > warning > unknown > healthy (Prioritaet absteigend)
 */
function deriveOverallHealth(
  git: SystemHealth,
  cron: SystemHealth,
  telegram: SystemHealth
): SystemHealth {
  const states = [git, cron, telegram];
  
  if (states.includes('error')) return 'error';
  if (states.includes('warning')) return 'warning';
  if (states.includes('unknown')) return 'unknown';
  
  return 'healthy';
}
