// Operations Mapper - Vereinheitlicht Operations-Daten
// Morning Briefing, Nightly Research, Backup, Cron

import { getCronStatus } from '../services/cronService';
import { getLatestFile } from '../services/fileService';
import { PATHS, CRON_LOGS } from '../constants/paths';

export type OperationStatus = 'scheduled' | 'running' | 'completed' | 'failed' | 'unknown';

export interface MappedOperations {
  morningBriefing: {
    status: OperationStatus;
    lastRun?: string;
    scheduled: boolean;
  };
  nightlyResearch: {
    status: OperationStatus;
    lastRun?: string;
    scheduled: boolean;
  };
  backup: {
    status: OperationStatus;
    lastCommit?: string;
  };
  lastUpdated: string;
}

/**
 * Mappt alle Operations-Status
 */
export async function mapOperations(): Promise<MappedOperations> {
  const timestamp = new Date().toISOString();
  
  const cron = await getCronStatus().catch(() => null);
  const latestBriefing = await getLatestFile(PATHS.DAILY, 'morning_briefing').catch(() => null);
  const latestResearch = await getLatestFile(PATHS.NIGHTLY, 'research').catch(() => null);
  
  return {
    morningBriefing: {
      status: mapMorningBriefingStatus(cron, latestBriefing),
      lastRun: latestBriefing ? extractDateFromFile(latestBriefing) : undefined,
      scheduled: cron?.hasMorningBriefing ?? false
    },
    nightlyResearch: {
      status: mapNightlyResearchStatus(cron, latestResearch),
      lastRun: latestResearch ? extractDateFromFile(latestResearch) : undefined,
      scheduled: cron?.hasNightlyResearch ?? false
    },
    backup: {
      status: mapBackupStatus(cron),
      lastCommit: undefined // Wird später aus Git-Status geholt
    },
    lastUpdated: timestamp
  };
}

/**
 * Mappt Morning Briefing Status
 */
function mapMorningBriefingStatus(
  cron: Awaited<ReturnType<typeof getCronStatus>> | null,
  latestFile: string | null
): OperationStatus {
  if (!cron?.hasMorningBriefing) return 'unknown';
  if (latestFile) return 'completed';
  return 'scheduled';
}

/**
 * Mappt Nightly Research Status
 */
function mapNightlyResearchStatus(
  cron: Awaited<ReturnType<typeof getCronStatus>> | null,
  latestFile: string | null
): OperationStatus {
  if (!cron?.hasNightlyResearch) return 'unknown';
  if (latestFile) return 'completed';
  return 'scheduled';
}

/**
 * Mappt Backup Status
 */
function mapBackupStatus(cron: Awaited<ReturnType<typeof getCronStatus>> | null): OperationStatus {
  if (!cron?.hasBackup) return 'unknown';
  return 'scheduled';
}

/**
 * Extrahiert Datum aus Filename (YYYY-MM-DD)
 */
function extractDateFromFile(filename: string): string | undefined {
  const match = filename.match(/(\d{4}-\d{2}-\d{2})/);
  return match?.[1];
}
