import type { AgentId, Severity } from '@/lib/types';

export type ViviSkillCapability =
  | 'chat.direct'
  | 'task.queue'
  | 'dispatch.route'
  | 'memory.capture'
  | 'obsidian.read'
  | 'obsidian.write_safe'
  | 'lioncom.status.read'
  | 'repo.inspect'
  | 'code.patch'
  | 'code.test'
  | 'browser.inspect'
  | 'web.research'
  | 'media.transcript'
  | 'image.generate'
  | 'image.edit'
  | 'document.create'
  | 'presentation.create'
  | 'spreadsheet.analyze'
  | 'automation.schedule'
  | 'telegram.bridge'
  | 'vega.handoff'
  | 'skill.hub'
  | 'skill.propose'
  | 'skill.remote_dry_run';

export type ViviSkillPermission =
  | 'safe_local_read'
  | 'safe_local_write'
  | 'external_read'
  | 'external_send'
  | 'credentials_auth'
  | 'money_payment'
  | 'destructive_delete'
  | 'production_deploy'
  | 'remote_code_install';

export type ViviSkillRiskLevel = 'safe' | 'guarded' | 'operator_gate' | 'vega_verified';
export type ViviSkillAccent = 'vivi' | 'vega' | 'system';
export type ViviSkillStatus = 'enabled' | 'disabled' | 'blocked' | 'unavailable';

export type ViviSkillHandler =
  | 'lioncom-status-read'
  | 'vivi-memory-capture'
  | 'vivi-dispatch-create'
  | 'vivi-model-route'
  | 'vega-handoff-create'
  | 'repo-inspect-readonly'
  | 'browser-qa-inspect'
  | 'media-youtube-transcript'
  | 'image-generate-provider-check'
  | 'image-generate-local'
  | 'skill-proposal-create'
  | 'skill-hub-local'
  | 'skill-remote-dry-run';

export interface ViviSkillManifest {
  id: string;
  name: string;
  shortName: string;
  description: string;
  operatorSummary: string;
  safeUse: string;
  accent: ViviSkillAccent;
  capabilities: ViviSkillCapability[];
  permissions: ViviSkillPermission[];
  riskLevel: ViviSkillRiskLevel;
  defaultEnabled: boolean;
  tags: string[];
  requiresOperatorGate?: boolean;
  gateReason?: string;
  runtime: {
    kind: 'builtin' | 'local' | 'remote' | 'proposal';
    handler: ViviSkillHandler;
  };
}

export interface ViviSkillStateFile {
  generatedAt: string;
  enabled: Record<string, boolean>;
}

export interface ViviSkill extends ViviSkillManifest {
  status: ViviSkillStatus;
  enabled: boolean;
  health: {
    tone: Severity;
    label: string;
    detail: string;
  };
}

export type ViviSkillRunStatus = 'completed' | 'blocked' | 'failed' | 'missing-provider' | 'proposal';

export interface ViviSkillArtifact {
  label: string;
  kind: 'text' | 'file' | 'link' | 'image' | 'route';
  value: string;
}

export interface ViviSkillRunInput {
  skillId: string;
  sessionId?: string;
  messageId?: string;
  commandRef?: string;
  operatorMessage?: string;
  source?: string;
  requestedBy?: 'operator' | 'vivi' | 'vega' | 'system';
  operatorGateApproved?: boolean;
  payload?: Record<string, string | number | boolean | null>;
}

export interface ViviSkillRun {
  id: string;
  skillId: string;
  skillName: string;
  capability: ViviSkillCapability;
  status: ViviSkillRunStatus;
  tone: Severity;
  startedAt: string;
  finishedAt: string;
  sessionId?: string;
  messageId?: string;
  commandRef?: string;
  requestedBy: 'operator' | 'vivi' | 'vega' | 'system';
  source: string;
  summary: string;
  detail: string;
  nextAction: string;
  artifacts: ViviSkillArtifact[];
}

export type ViviSkillProposalStatus = 'proposed' | 'queued-vega' | 'accepted' | 'rejected' | 'implemented';

export interface ViviSkillProposal {
  id: string;
  createdAt: string;
  title: string;
  requestedCapability: ViviSkillCapability;
  source: string;
  operatorMessage: string;
  reason: string;
  safetyBoundary: string;
  targetAgent: 'vivi' | 'vega';
  acceptanceCriteria: string[];
  status: ViviSkillProposalStatus;
  files: {
    json: string;
    markdown: string;
  };
  handoffRef?: string;
}

export type ViviSkillHubEntryStatus = 'installed' | 'proposal-ready' | 'blocked' | 'dry-run-only';
export type ViviSkillHubRiskLevel = 'safe' | 'guarded' | 'operator-gate';

export interface ViviSkillHubEntry {
  id: string;
  name: string;
  capability: ViviSkillCapability;
  source: 'builtin' | 'local-catalog' | 'planned-local' | 'remote-catalog';
  status: ViviSkillHubEntryStatus;
  riskLevel: ViviSkillHubRiskLevel;
  installMode: 'builtin' | 'vega-build' | 'remote-dry-run' | 'blocked';
  summary: string;
  gateReason?: string;
}

export interface ViviSkillSnapshot {
  generatedAt: string;
  skills: ViviSkill[];
  latestRuns: ViviSkillRun[];
  latestProposals: ViviSkillProposal[];
  hub: {
    entries: ViviSkillHubEntry[];
    remoteDryRunReady: boolean;
    remoteInstallAllowed: false;
    detail: string;
  };
  counts: {
    total: number;
    enabled: number;
    gated: number;
    availableNow: number;
    proposals: number;
  };
}

export type CapabilityRouteKind =
  | 'direct_chat'
  | 'use_skill'
  | 'queue_vivi_task'
  | 'handoff_vega'
  | 'operator_gate'
  | 'missing_skill';

export interface CapabilityRouteDecision {
  kind: CapabilityRouteKind;
  capability: ViviSkillCapability;
  targetAgent: AgentId | 'operator';
  skillId?: string;
  queueAsTask: boolean;
  shouldStartViviLoop: boolean;
  summary: string;
  operatorMessage: string;
  gateReason?: string;
  confidence: number;
}
