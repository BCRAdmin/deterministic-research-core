// Task Queue Parser - Liest TASK_QUEUE.md
// Nur Kerninformationen: active, backlog, done

import { readTextFile } from '../services/fileService';
import { PATHS } from '../constants/paths';

export interface ParsedTaskQueue {
  activeTask?: string;
  backlogCount: number;
  doneCount: number;
  blockedCount: number;
}

/**
 * Parst TASK_QUEUE.md - nur Kerninformationen
 */
export async function parseTaskQueue(): Promise<ParsedTaskQueue | null> {
  const content = await readTextFile(PATHS.TASK_QUEUE);
  if (!content) {
    // Defaults bei Fehlern
    return {
      backlogCount: 0,
      doneCount: 0,
      blockedCount: 0
    };
  }

  return {
    activeTask: extractActiveTask(content),
    backlogCount: extractBacklogCount(content),
    doneCount: extractDoneCount(content),
    blockedCount: extractBlockedCount(content)
  };
}

/**
 * Extrahiert aktiven Task - erste Zeile in "Aktive Tasks"
 */
function extractActiveTask(content: string): string | undefined {
  const lines = content.split('\n');
  let inActiveSection = false;
  
  for (const line of lines) {
    // Sektion erkennen
    if (line.includes('## Aktive Tasks')) {
      inActiveSection = true;
      continue;
    }
    
    // Nächste Sektion = Ende
    if (inActiveSection && line.startsWith('##')) {
      break;
    }
    
    // Erste Task-Zeile finden
    if (inActiveSection && line.includes('|') && line.includes('in-progress')) {
      const parts = line.split('|').map(p => p.trim()).filter(p => p);
      if (parts.length >= 2 && !parts[0].includes('ID')) {
        return parts[1]; // Task-Name
      }
    }
  }
  
  return undefined;
}

/**
 * Zählt Backlog-Items - alle P0-P3 Einträge
 */
function extractBacklogCount(content: string): number {
  const lines = content.split('\n');
  let inBacklog = false;
  let count = 0;
  
  for (const line of lines) {
    if (line.includes('## Priorität') || line.includes('## Backlog')) {
      inBacklog = true;
      continue;
    }
    
    if (inBacklog && line.startsWith('##')) {
      break;
    }
    
    if (inBacklog && line.match(/^\| B-\d+ \|/)) {
      count++;
    }
  }
  
  return count;
}

/**
 * Zählt erledigte Tasks
 */
function extractDoneCount(content: string): number {
  const lines = content.split('\n');
  let inDone = false;
  let count = 0;
  
  for (const line of lines) {
    if (line.includes('Erledigt') || line.includes('## Erledigt')) {
      inDone = true;
      continue;
    }
    
    if (inDone && line.startsWith('##')) {
      break;
    }
    
    if (inDone && line.match(/^\| B-\d+ \|/)) {
      count++;
    }
  }
  
  return count;
}

/**
 * Zählt blockierte/wartende Tasks
 */
function extractBlockedCount(content: string): number {
  const lines = content.split('\n');
  let inBlocked = false;
  let count = 0;
  
  for (const line of lines) {
    if (line.includes('Wartend') || line.includes('## Wartend')) {
      inBlocked = true;
      continue;
    }
    
    if (inBlocked && line.startsWith('##')) {
      break;
    }
    
    if (inBlocked && line.match(/^\| B-\d+ \|/)) {
      count++;
    }
  }
  
  return count;
}
