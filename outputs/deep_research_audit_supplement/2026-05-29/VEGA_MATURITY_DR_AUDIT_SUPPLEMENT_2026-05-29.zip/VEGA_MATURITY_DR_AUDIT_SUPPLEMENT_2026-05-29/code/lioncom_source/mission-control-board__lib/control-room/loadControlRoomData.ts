import 'server-only';

import { promises as fs } from 'fs';
import os from 'os';
import path from 'path';

import { PATHS, WORKSPACE_ROOT } from '../constants/paths';
import { parseDashboard } from '../parsers/dashboardParser';
import { parseHandoff } from '../parsers/handoffParser';
import { parseLearnings } from '../parsers/learningsParser';
import { parseSystemExport } from '../parsers/systemExportParser';
import { syncAllControlPlanes } from '../services/controlPlaneSyncService';
import { getCronStatus } from '../services/cronService';
import { getCurrentBranch, getLastCommit, hasRemote, isGitRepo } from '../services/gitService';
import { getSystemHealth } from '../services/healthService';
import { getDesktopDiagnostics } from '../services/desktopDiagnosticsService';
import { getQualificationStatus } from '../services/qualificationService';
import { getTelegramRelayStatus } from '../services/telegramBridgeService';
import { getTelegramStatus } from '../services/telegramService';
import { syncAutonomyState, type AutonomyStateSnapshot } from '../services/autonomyService';
import type { CodexRuntimeSnapshot } from '../services/codexRuntimeService';
import type { GitHubSyncSnapshot } from '../services/githubSyncService';
import type { RemoteBridgeStatus } from '../services/bridgeStatusService';
import type { ViviRuntimeSnapshot, ViviStateSnapshot } from '../services/viviBridgeService';
import type { WorkEngineStateSnapshot } from '../services/workEngineService';
import { parseCodexChatThread } from '../services/codexBoardService';
import type {
  AgentSignal,
  AutomationSignal,
  BacklogLane,
  BlockerSignal,
  BrainDumpEntry,
  BridgePacket,
  CodexChatEntry,
  ControlRoomData,
  MissionSummary,
  ProjectSignal,
  SourceSnapshot,
  SummaryMetric,
  SystemAlert,
  TaskItem,
  TelemetrySummary,
  TimelineEntry,
  ViviReportEntry,
  WorkIntakeEntry,
} from './types';

interface DashboardStateSnapshot {
  generated?: string;
  layers?: {
    core?: {
      systemState?: string;
      activeTask?: string | null;
      tasksCompleted?: number;
      tasksOpen?: number;
      tasksInProgress?: number;
      backlogStatus?: string;
      lastUpdate?: string;
    };
    execution?: {
      currentPhase?: string;
      progress?: number;
      lastAction?: string;
      nextPhase?: string;
      timeInPhase?: number;
    };
    health?: {
      status?: string;
      lastActivity?: string;
      blockers?: Array<{
        description: string;
        impact?: string;
        workaround?: string;
      }>;
      checks?: {
        runtime?: {
          status?: string;
          agentResponsive?: boolean;
        };
      };
    };
    log?: {
      recentActions?: Array<{
        time?: string;
        message?: string;
        type?: string;
      }>;
    };
  };
  derived?: {
    riskScore?: number;
  };
}

interface LocalDuoLoopStatusSnapshot {
  updatedAt?: string;
  state?: 'running' | 'idle' | 'failed';
  detail?: string;
  lastExitCode?: number;
  workspaceRoot?: string;
  lastMessagePath?: string;
}

const PHASE_PROGRESS: Record<string, number> = {
  INITIALISIERUNG: 5,
  PLANUNG: 24,
  AUSFUEHRUNG: 52,
  'AUSFÜHRUNG': 52,
  VALIDIERUNG: 78,
  ABSCHLUSS: 96,
  INIT: 5,
  PLAN: 24,
  EXEC: 52,
  VALIDATE: 78,
  CLOSE: 96,
  OBSERVE: 12,
};

export async function loadControlRoomData(): Promise<ControlRoomData> {
  const [
    dashboard,
    handoff,
    learnings,
    systemExport,
    health,
    cron,
    telegram,
    gitRepo,
    gitRemote,
    gitCommit,
    gitBranch,
    taskQueueContent,
    backlogContent,
    dashboardState,
    brainDumpContent,
    workIntakeContent,
    codexChatContent,
    codexInboxContent,
    viviCommandQueueContent,
    viviRuntime,
    viviState,
    localDuoLoopStatus,
    viviReportsContent,
    telegramInboxContent,
    telegramOutboxContent,
    repairQueueContent,
    telegramRelay,
    desktop,
    qualification,
  ] = await Promise.all([
    parseDashboard().catch(() => null),
    parseHandoff().catch(() => null),
    parseLearnings().catch(() => ({ items: [], lastUpdated: undefined })),
    parseSystemExport().catch(() => ({ productive: [], prepared: [], openIssues: [], nextSteps: [] })),
    getSystemHealth().catch(() => null),
    getCronStatus().catch(() => null),
    getTelegramStatus().catch(() => null),
    isGitRepo().catch(() => false),
    hasRemote().catch(() => false),
    getLastCommit().catch(() => null),
    getCurrentBranch().catch(() => 'unknown'),
    safeRead(PATHS.TASK_QUEUE),
    safeRead(PATHS.BACKLOG),
    safeJson<DashboardStateSnapshot>(PATHS.DASHBOARD_STATE),
    safeRead(PATHS.BRAIN_DUMP),
    safeRead(PATHS.WORK_INTAKE),
    safeRead(PATHS.CODEX_CHAT_THREAD),
    safeRead(PATHS.CODEX_INBOX),
    safeRead(PATHS.VIVI_COMMAND_QUEUE),
    safeJson<ViviRuntimeSnapshot>(PATHS.VIVI_RUNTIME),
    safeJson<ViviStateSnapshot>(PATHS.VIVI_STATE),
    safeJson<LocalDuoLoopStatusSnapshot>(PATHS.LOCAL_DUO_LOOP_STATUS),
    safeRead(PATHS.VIVI_REPORTS),
    safeRead(PATHS.TELEGRAM_INBOX),
    safeRead(PATHS.TELEGRAM_OUTBOX),
    safeRead(PATHS.REPAIR_QUEUE),
    getTelegramRelayStatus().catch(() => null),
    getDesktopDiagnostics().catch(() => null),
    getQualificationStatus().catch(() => null),
  ]);

  const controlSync = await syncAllControlPlanes({
    viviRuntime,
    viviState,
  });

  const [freshDashboard, freshHandoff, freshSystemExport, freshTaskQueueContent, freshBacklogContent, freshDashboardState] = await Promise.all([
    parseDashboard().catch(() => null),
    parseHandoff().catch(() => null),
    parseSystemExport().catch(() => ({ productive: [], prepared: [], openIssues: [], nextSteps: [] })),
    safeRead(PATHS.TASK_QUEUE),
    safeRead(PATHS.BACKLOG),
    safeJson<DashboardStateSnapshot>(PATHS.DASHBOARD_STATE),
  ]);

  const safeSystemExport = freshSystemExport || systemExport || {
    productive: [],
    prepared: [],
    openIssues: [],
    nextSteps: [],
  };
  const safeLearnings = learnings || { items: [], lastUpdated: undefined };
  const safeHandoff = freshHandoff || handoff || { stable: [], prepared: [], openPoints: [], decisions: [], nextPhase: undefined };

  const taskQueue = parseTaskQueueContent(freshTaskQueueContent || taskQueueContent);
  const backlog = parseBacklogContent(freshBacklogContent || backlogContent);
  const viviReports = parseViviReports(viviReportsContent);
  const effectiveDashboardState = freshDashboardState || dashboardState;
  const telemetry = buildTelemetrySummary(effectiveDashboardState, viviRuntime, localDuoLoopStatus);
  const blockers = buildBlockers(effectiveDashboardState, safeSystemExport.openIssues || [], viviRuntime);
  const codexChat = parseCodexChatThread(codexChatContent);
  const codexInbox = parseBridgePackets(codexInboxContent, 'codex');
  const viviCommandQueue = parseBridgePackets(viviCommandQueueContent, 'vivi');
  const telegramInbox = parseBridgePackets(telegramInboxContent, 'telegram');
  const telegramOutbox = parseBridgePackets(telegramOutboxContent, 'telegram');
  const repairQueue = parseBridgePackets(repairQueueContent, 'repair');
  const workIntakeCount = countStructuredBlocksByStatus(workIntakeContent, ['new']);
  const viviCommandQueueCount = countStructuredBlocksByStatus(viviCommandQueueContent, ['queued', 'new', 'accepted', 'claimed']);
  const repairQueueCount = countStructuredBlocksByStatus(repairQueueContent, ['queued', 'new', 'accepted', 'recovering']);
  const telegramInboxCount = countStructuredBlocks(telegramInboxContent);
  const telegramOutboxCount = countStructuredBlocks(telegramOutboxContent);
  const workEngine = controlSync.workEngine;
  const mission = buildMissionSummary({
    snapshot: effectiveDashboardState,
    viviRuntime,
    viviState,
    fallbackPhase: freshDashboard?.systemStatus?.phase || dashboard?.systemStatus?.phase,
    nextPhase: safeHandoff.nextPhase,
    blockers,
    telemetry,
    nextSteps: safeSystemExport.nextSteps || [],
  });
  const metrics = buildMetrics({
    mission,
    taskQueue,
    backlog,
    telemetry,
    health,
    automationCount: cron?.entries.length || 0,
    workEngine,
  });
  const timeline = buildTimeline({
    snapshot: effectiveDashboardState,
    viviRuntime,
    viviState,
    viviReports,
    lastCommit: gitCommit?.hash,
    decisions: safeHandoff.decisions || [],
    openPoints: safeHandoff.openPoints || [],
    telemetry,
    viviCommands: viviCommandQueue,
  });
  const viviSteps = buildViviSteps({
    snapshot: effectiveDashboardState,
    viviRuntime,
    viviState,
    viviReports,
    telemetry,
    mission,
    viviCommands: viviCommandQueue,
    workIntake: parseWorkIntakeEntries(workIntakeContent),
    repairQueue,
  });
  const sources = await buildSources();
  const alerts = buildEssentialAlerts({
    telemetry,
    sources,
    blockers,
    gitRepo,
    mission,
    remoteBridge: controlSync.remoteBridge,
    githubSync: controlSync.githubSync,
    desktop,
  });
  const maintenance = buildMaintenanceAlerts({
    telemetry,
    cron,
    telegram,
    gitRemote,
    taskQueue,
    workIntakeCount,
    remoteBridge: controlSync.remoteBridge,
    githubSync: controlSync.githubSync,
    codexRuntime: controlSync.codexRuntime,
    desktop,
  });
  const agents = buildAgents({
    health,
    cron,
    telegram,
    gitRepo,
    gitRemote,
    mission,
    blockers,
    telemetry,
    viviRuntime,
    codexChat,
    codexInbox,
    codexRuntime: controlSync.codexRuntime,
    viviCommandQueue,
    viviCommandQueueCount,
    telegramInbox,
    telegramInboxCount,
    repairQueue,
    repairQueueCount,
    remoteBridge: controlSync.remoteBridge,
    githubSync: controlSync.githubSync,
  });
  const projects = await buildProjects();
  const automations = buildAutomations(cron, telegramInbox, telegramOutbox, repairQueue, {
    telegramInboxCount,
    telegramOutboxCount,
    repairQueueCount,
  });
  const notes = buildNotes(safeLearnings.items || [], safeSystemExport.nextSteps || []);
  const brainDump = parseBrainDumpEntries(brainDumpContent);
  const workIntake = parseWorkIntakeEntries(workIntakeContent);
  const autonomy = await syncAutonomyState({
    viviRuntime,
    viviState,
    remoteBridge: controlSync.remoteBridge,
    githubSync: controlSync.githubSync,
    codexRuntime: controlSync.codexRuntime,
    workEngine,
  }).catch(() => defaultAutonomySnapshot());

  return {
    workspaceRoot: WORKSPACE_ROOT,
    generatedAt: new Date().toISOString(),
    mission,
    telemetry,
    blockers,
    alerts,
    maintenance,
    metrics,
    agents,
    activeTasks: taskQueue.active,
    waitingTasks: taskQueue.waiting,
    backlog,
    completedTasks: taskQueue.completed,
    brainDump,
    workIntake,
    workBlocks: workEngine.blocks,
    subtasks: workEngine.subtasks,
    researchQueue: workEngine.researchQueue,
    decisionQueue: workEngine.decisions,
    roadmap: workEngine.roadmap,
    freeze: workEngine.freeze,
    autonomy: normalizeAutonomy(autonomy),
    remoteBridge: normalizeRemoteBridge(controlSync.remoteBridge),
    githubSync: normalizeGitHubSync(controlSync.githubSync),
    codexChat,
    codexRuntime: normalizeCodexRuntime(controlSync.codexRuntime),
    codexInbox,
    viviCommandQueue,
    telegramInbox,
    telegramOutbox,
    telegramRelay: telegramRelay || {
      inboundReady: false,
      outboundReady: false,
      criticalOnly: true,
      detail: 'Telegram mobile bridge snapshot unavailable.',
    },
    desktop: desktop || {
      mode: 'browser',
      workspaceRoot: WORKSPACE_ROOT,
      workspaceValid: false,
      requiredMarkers: [],
      startupState: 'unknown',
      startupDetail: 'Desktop diagnostics are unavailable.',
      issues: [{ severity: 'warning', message: 'Desktop diagnostics snapshot could not be loaded.' }],
      logTail: [],
      settingsPath: 'unknown',
      logPath: 'unknown',
      statusPath: 'unknown',
      asarEnabled: false,
      notarized: false,
      signingMode: 'unknown',
    },
    qualification: qualification || defaultQualificationSnapshot(),
    repairQueue,
    timeline,
    viviSteps,
    viviReports,
    decisions: [...(safeHandoff.decisions || []), ...workEngine.decisions.map((item) => item.title)].slice(0, 8),
    recommendations: dedupeStrings([
      ...(safeSystemExport.nextSteps || []),
      ...workEngine.decisions.map((item) => item.recommendation),
    ]).slice(0, 8),
    projects,
    automations,
    sources,
    notes,
    git: {
      branch: gitBranch,
      hasRemote: gitRemote,
      lastCommit: gitCommit?.hash,
      isRepo: gitRepo,
    },
  };
}

function defaultAutonomySnapshot(): AutonomyStateSnapshot {
  return {
    schemaVersion: '1.0',
    updatedAt: new Date().toISOString(),
    readiness: 'blocked',
    summary: 'Autonomy state could not be synchronized from the current workspace.',
    operatorFreedom: 'Stay in the board manually until the autonomy layer can be synchronized again.',
    notes: ['Autonomy service did not produce a fresh snapshot.'],
    viviLoop: {
      agent: 'vivi',
      state: 'blocked',
      summary: 'Vivi loop snapshot unavailable.',
      backlogCount: 0,
      instructions: ['Repair the autonomy state before trusting automatic task claiming.'],
    },
    codexLoop: {
      agent: 'codex',
      state: 'blocked',
      summary: 'Codex loop snapshot unavailable.',
      backlogCount: 0,
      instructions: ['Repair the autonomy state before trusting automatic task claiming.'],
    },
    activeClaims: [],
    staleClaims: [],
    recentClaims: [],
    claimHistoryCount: 0,
    gates: {
      workEngineReady: false,
      viviBridgeReady: false,
      codexRailReady: false,
      remoteBridgeReady: false,
      githubSyncReady: false,
    },
  };
}

function dedupeStrings(items: string[]): string[] {
  const seen = new Set<string>();

  return items.filter((item) => {
    const normalized = item.trim().toLowerCase();
    if (!normalized || seen.has(normalized)) {
      return false;
    }
    seen.add(normalized);
    return true;
  });
}

function defaultQualificationSnapshot() {
  return {
    overallState: 'not-run' as const,
    releaseDecision: 'blocked' as const,
    summary: 'Qualification has not been executed from this workspace yet.',
    completedSections: 0,
    totalSections: 3,
    sections: [
      {
        id: 'G1' as const,
        title: 'End-to-End Workflow Validation',
        state: 'pending' as const,
        detail: 'No end-to-end validation evidence is available yet.',
        evidencePath: 'QUALIFICATION_RUNS/END_TO_END_VALIDATION.md',
      },
      {
        id: 'G2' as const,
        title: 'Failure and Recovery Validation',
        state: 'pending' as const,
        detail: 'No failure and recovery validation evidence is available yet.',
        evidencePath: 'QUALIFICATION_RUNS/FAILURE_RECOVERY_VALIDATION.md',
      },
      {
        id: 'G3' as const,
        title: 'Production Readiness Review',
        state: 'pending' as const,
        detail: 'No formal readiness review has been captured yet.',
        evidencePath: 'PRODUCTION_READINESS_REVIEW.md',
      },
    ],
    blockers: ['Run the qualification suite before trusting release posture.'],
    residualRisks: [],
    approvedFor: [],
    notApprovedFor: ['Production acceptance'],
    evidencePaths: ['SYSTEM_QUALIFICATION_STATUS.json', 'PRODUCTION_READINESS_REVIEW.md'],
  };
}

async function safeRead(filePath: string): Promise<string | null> {
  try {
    return await fs.readFile(filePath, 'utf-8');
  } catch {
    return null;
  }
}

async function safeJson<T>(filePath: string): Promise<T | null> {
  const content = await safeRead(filePath);
  if (!content) return null;

  try {
    return JSON.parse(content) as T;
  } catch {
    return null;
  }
}

function parseTaskQueueContent(content: string | null): {
  active: TaskItem[];
  waiting: TaskItem[];
  completed: TaskItem[];
} {
  if (!content) {
    return { active: [], waiting: [], completed: [] };
  }

  return {
    active: extractTableRows(content, ['## Aktive Tasks']).map((row) => ({
      id: row[0],
      title: row[1],
      priority: row[2],
      status: row[3],
      deadline: row[4],
      owner: row[5],
    })),
    waiting: extractTableRows(content, ['## Wartend']).map((row) => ({
      id: row[0],
      title: row[1],
      status: 'waiting',
      detail: row[2],
      deadline: row[3],
      owner: row[4],
    })),
    completed: extractTableRows(content, ['## Erledigt']).map((row) => ({
      id: row[0],
      title: row[1],
      status: 'done',
      deadline: row[2],
      detail: row[4],
      owner: row[3],
    })),
  };
}

function parseBacklogContent(content: string | null): BacklogLane[] {
  if (!content) {
    return [];
  }

  return ['P0', 'P1', 'P2', 'P3'].map((lane) => ({
    lane,
    items: extractPriorityRows(content, lane).map((row) => ({
      id: row[0],
      title: row[1],
      status: 'queued',
      priority: lane,
      detail: row[2],
      deadline: row[3],
    })),
  }));
}

function extractTableRows(content: string, markers: string[]): string[][] {
  const lines = content.split('\n');
  const rows: string[][] = [];
  let inSection = false;

  for (const rawLine of lines) {
    const line = rawLine.trim();

    if (markers.some((marker) => line.startsWith(marker))) {
      inSection = true;
      continue;
    }

    if (inSection && line.startsWith('## ')) {
      break;
    }

    if (!inSection || !line.startsWith('|')) {
      continue;
    }

    if (line.includes('----') || line.includes('| ID |')) {
      continue;
    }

    const cells = line
      .split('|')
      .map((cell) => cell.trim())
      .filter((cell) => cell.length > 0);

    if (cells.length === 0) continue;
    if (!cells[0] || !cells[0].startsWith('B-')) continue;

    rows.push(cells);
  }

  return rows;
}

function extractPriorityRows(content: string, lane: string): string[][] {
  const lines = content.split('\n');
  const rows: string[][] = [];
  let inSection = false;

  for (const rawLine of lines) {
    const line = rawLine.trim();

    if (line.includes('## Priorität') && line.includes(lane)) {
      inSection = true;
      continue;
    }

    if (inSection && line.startsWith('## ') && !line.includes(lane)) {
      break;
    }

    if (!inSection || !line.startsWith('|')) {
      continue;
    }

    if (line.includes('----') || line.includes('| ID |')) {
      continue;
    }

    const cells = line
      .split('|')
      .map((cell) => cell.trim())
      .filter((cell) => cell.length > 0);

    if (cells.length === 0) continue;
    if (!cells[0] || !cells[0].startsWith('B-')) continue;

    rows.push(cells);
  }

  return rows;
}

function buildTelemetrySummary(
  snapshot: DashboardStateSnapshot | null,
  viviRuntime: ViviRuntimeSnapshot | null,
  localDuoLoopStatus?: LocalDuoLoopStatusSnapshot | null,
): TelemetrySummary {
  const runtimeLastUpdate = viviRuntime?.runtime.heartbeatAt || viviRuntime?.updatedAt;
  const snapshotLastUpdate = snapshot?.layers?.health?.lastActivity
    || snapshot?.layers?.core?.lastUpdate
    || snapshot?.generated;
  const localLoopLastUpdate = localDuoLoopStatus?.updatedAt;
  const lastUpdate = runtimeLastUpdate || snapshotLastUpdate;
  const runtimeResponsive = viviRuntime?.runtime.responsive ?? Boolean(snapshot?.layers?.health?.checks?.runtime?.agentResponsive);
  const source = runtimeLastUpdate ? relativePath(PATHS.VIVI_RUNTIME) : relativePath(PATHS.DASHBOARD_STATE);
  const localLoopFreshness = localLoopLastUpdate ? ageMinutes(localLoopLastUpdate) : Number.POSITIVE_INFINITY;
  const localLoopFresh = Boolean(localLoopLastUpdate) && localLoopFreshness <= 12;

  if (!lastUpdate && localLoopFresh) {
    return {
      state: 'live',
      freshnessMinutes: localLoopFreshness,
      lastUpdate: localLoopLastUpdate,
      runtimeResponsive: false,
      source: relativePath(PATHS.LOCAL_DUO_LOOP_STATUS),
      detail: `Der lokale Vivi/Codex-Duo-Loop hat die Control Plane ${describeFreshness(localLoopFreshness)} aktualisiert. Direkte Vivi-Runtime-Pakete fehlen noch, daher ist das eine belastbare lokale Fallback-Sicht und noch kein bestätigter Remote-Heartbeat.`,
    };
  }

  if (!lastUpdate) {
    return {
      state: 'absent',
      runtimeResponsive: false,
      source,
      detail: 'Lokal liegt noch kein Vivi-Runtime-Heartbeat vor. Das Board kann deshalb nicht verifizieren, ob Vivi gerade aktiv läuft.',
    };
  }

  const freshnessMinutes = ageMinutes(lastUpdate);
  const freshnessText = describeFreshness(freshnessMinutes);

  if (freshnessMinutes <= 12) {
    const localFallbackDetail = localLoopFresh && !runtimeLastUpdate
      ? ` Der lokale Duo-Loop hat die Control Plane ebenfalls ${describeFreshness(localLoopFreshness)} aktualisiert. Das Board arbeitet damit auf frischer lokaler Fallback-Sicht, solange die Remote-Wahrheit von Vivi noch aussteht.`
      : '';
    return {
      state: 'live',
      freshnessMinutes,
      lastUpdate,
      runtimeResponsive,
      source,
      detail: runtimeResponsive
        ? `Live-Vivi-Telemetrie bestätigt ein frisches, antwortfähiges Signal (${freshnessText}).${localFallbackDetail}`
        : `Die Vivi-Telemetrie ist frisch (${freshnessText}), aber die Runtime hat Vivi nicht ausdrücklich als antwortfähig markiert.${localFallbackDetail}`,
    };
  }

  if (localLoopFresh && runtimeLastUpdate) {
    return {
      state: 'live',
      freshnessMinutes: localLoopFreshness,
      lastUpdate: localLoopLastUpdate,
      runtimeResponsive: false,
      source: relativePath(PATHS.LOCAL_DUO_LOOP_STATUS),
      detail: `Das letzte direkte Vivi-Runtime-Paket ist veraltet (${freshnessText}), aber der lokale Duo-Loop hat die Control Plane ${describeFreshness(localLoopFreshness)} aktualisiert. Behandle das Board lokal als aktuell, solange die Remote-Bestätigung von Vivi noch aussteht.`,
    };
  }

  return {
    state: 'stale',
    freshnessMinutes,
    lastUpdate,
    runtimeResponsive,
    source,
    detail: runtimeResponsive
      ? `Das letzte Vivi-Telemetriesignal ist veraltet (${freshnessText}). Vivi könnte anderswo noch laufen, aber dieses Board kann das nicht aus frischen lokalen Runtime-Daten belegen.`
      : `Das letzte Vivi-Telemetriesignal ist veraltet (${freshnessText}) und bestätigt keine aktuell antwortfähige Runtime.`,
  };
}

function buildBlockers(
  snapshot: DashboardStateSnapshot | null,
  openIssues: string[],
  viviRuntime: ViviRuntimeSnapshot | null,
): BlockerSignal[] {
  const fromSnapshot: BlockerSignal[] = snapshot?.layers?.health?.blockers?.map((item) => ({
    description: item.description,
    impact: item.impact,
    workaround: item.workaround,
  })) || [];

  const fromViviRuntime: BlockerSignal[] = viviRuntime?.blockers || [];

  const fromExport: BlockerSignal[] = openIssues.map((issue) => ({
    description: issue,
  }));

  const merged = [...fromViviRuntime, ...fromSnapshot, ...fromExport];
  const seen = new Set<string>();

  return merged.filter((item) => {
    const key = `${item.description}|${item.impact || ''}|${item.workaround || ''}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, 8);
}

function buildMissionSummary(input: {
  snapshot: DashboardStateSnapshot | null;
  viviRuntime: ViviRuntimeSnapshot | null;
  viviState: ViviStateSnapshot | null;
  fallbackPhase?: string;
  nextPhase?: string;
  blockers: BlockerSignal[];
  telemetry: TelemetrySummary;
  nextSteps: string[];
}): MissionSummary {
  const { snapshot, blockers, telemetry, viviRuntime, viviState } = input;
  const systemState = viviRuntime?.mission.state
    || snapshot?.layers?.core?.systemState
    || (telemetry.state === 'absent' ? 'NO TELEMETRY' : blockers.length > 0 ? 'BLOCKED' : 'ACTIVE');
  const phase = viviState?.currentState
    || viviRuntime?.mission.phase
    || snapshot?.layers?.execution?.currentPhase
    || input.fallbackPhase
    || input.nextPhase
    || 'OBSERVE';
  const progress = viviRuntime?.mission.progress
    ?? snapshot?.layers?.execution?.progress
    ?? PHASE_PROGRESS[phase.toUpperCase()] ?? 18;
  const lastAction = viviRuntime?.mission.currentAction
    || snapshot?.layers?.execution?.lastAction
    || (telemetry.state === 'live'
      ? 'Der Live-Zustand ist sichtbar. Das System wartet auf eine Operator- oder Vivi-Bewegung in den Rails.'
      : telemetry.detail);
  const nextStep = viviRuntime?.mission.nextAction
    || input.nextSteps[0]
    || input.nextPhase
    || (telemetry.state !== 'live'
      ? 'Stelle die Live-Sicht wieder her oder bestätige die Remote-Runtime, bevor du dem Betriebszustand vertraust.'
        : blockers.length > 0
        ? 'Triage den sichtbaren Blocker und entscheide, ob Vivi ihn jetzt löst oder für eine Nacht-Reparatur einreiht.'
        : 'Route die nächste Idee oder das nächste Arbeitspaket in die richtige Lane und halte das Lagebild sauber.');

  let riskScore = snapshot?.derived?.riskScore ?? 18;
  if (telemetry.state !== 'live') riskScore += 18;
  if (blockers.length > 0) riskScore += 10;
  riskScore = Math.min(riskScore, 100);

  let executiveSummary = 'LIONCOM zeigt ein klares lokales Lagebild und kann Arbeit sicher in die richtigen Schienen routen.';
  if (telemetry.state !== 'live') {
    executiveSummary = 'Das Board arbeitet aktuell mit veralteter lokaler Telemetrie. Kommandos, Ideen und Reparaturpakete funktionieren weiter, aber die Live-Sicht auf Vivi ist eingeschränkt, bis wieder ein frisches Runtime-Signal ankommt.';
  } else if (systemState.toUpperCase().includes('BLOCK')) {
    executiveSummary = 'Live-Telemetrie ist verfügbar, aber das aktuelle Missionsbild enthält noch Blocker oder wartende Arbeit, die vor sauberem Vorwärtsgang triagiert werden müssen.';
  }

  return {
    systemState,
    phase,
    progress,
    lastAction,
    nextStep,
    riskScore,
    executiveSummary,
    timeInPhase: snapshot?.layers?.execution?.timeInPhase,
    lastUpdated: telemetry.lastUpdate,
  };
}

function buildMetrics(input: {
  mission: MissionSummary;
  taskQueue: { active: TaskItem[]; waiting: TaskItem[]; completed: TaskItem[] };
  backlog: BacklogLane[];
  telemetry: TelemetrySummary;
  health: Awaited<ReturnType<typeof getSystemHealth>> | null;
  automationCount: number;
  workEngine: WorkEngineStateSnapshot;
}): SummaryMetric[] {
  const backlogCount = input.backlog.reduce((sum, lane) => sum + lane.items.length, 0);
  const activeWorkBlocks = input.workEngine.blocks.filter((block) => block.active).length;
  const healthTone = input.health?.overall === 'healthy'
    ? 'ok'
    : input.health?.overall === 'warning'
      ? 'warning'
      : input.health?.overall === 'error'
        ? 'critical'
        : 'info';

  return [
    {
      label: 'Missionsstatus',
      value: input.mission.systemState,
      detail: input.mission.phase,
      tone: input.mission.systemState.toUpperCase().includes('BLOCK') ? 'warning' : 'ok',
    },
    {
      label: 'Live-Telemetrie',
      value: input.telemetry.state.toUpperCase(),
      detail: input.telemetry.detail,
      tone: input.telemetry.state === 'live' ? 'ok' : input.telemetry.state === 'stale' ? 'warning' : 'critical',
    },
    {
      label: 'Builder-Last',
      value: `${activeWorkBlocks}/${input.workEngine.blocks.length || backlogCount}`,
      detail: `${input.workEngine.subtasks.filter((item) => item.status === 'queued').length} wartend · ${input.taskQueue.completed.length} abgeschlossen · Klick für Werkstattsicht`,
      tone: input.taskQueue.waiting.length > 0 ? 'warning' : 'info',
    },
    {
      label: 'Gesundheitsmesh',
      value: input.health?.overall?.toUpperCase() || 'UNKNOWN',
      detail: 'Git-, Cron- und Relay-Sicht',
      tone: healthTone,
    },
    {
      label: 'Automationsschiene',
      value: String(input.automationCount),
      detail: 'Erkannte Zeitpläne oder Wartungsflüsse',
      tone: input.automationCount > 0 ? 'ok' : 'warning',
    },
    {
      label: 'Risikowert',
      value: `${input.mission.riskScore}/100`,
      detail: input.mission.riskScore > 60 ? 'Vor Vertrauen erst stabilisieren' : 'Unter Kontrolle',
      tone: input.mission.riskScore > 60 ? 'critical' : input.mission.riskScore > 35 ? 'warning' : 'ok',
    },
  ];
}

function buildAgents(input: {
  health: Awaited<ReturnType<typeof getSystemHealth>> | null;
  cron: Awaited<ReturnType<typeof getCronStatus>> | null;
  telegram: Awaited<ReturnType<typeof getTelegramStatus>> | null;
  gitRepo: boolean;
  gitRemote: boolean;
  mission: MissionSummary;
  blockers: BlockerSignal[];
  telemetry: TelemetrySummary;
  viviRuntime: ViviRuntimeSnapshot | null;
  codexChat: CodexChatEntry[];
  codexInbox: BridgePacket[];
  codexRuntime: CodexRuntimeSnapshot;
  viviCommandQueue: BridgePacket[];
  viviCommandQueueCount: number;
  telegramInbox: BridgePacket[];
  telegramInboxCount: number;
  repairQueue: BridgePacket[];
  repairQueueCount: number;
  remoteBridge: RemoteBridgeStatus;
  githubSync: GitHubSyncSnapshot;
}): AgentSignal[] {
  const viviStatus: AgentSignal['status'] = input.telemetry.state === 'live'
    ? (input.telemetry.runtimeResponsive ? 'active' : 'monitoring')
    : input.telemetry.state === 'stale'
      ? 'warning'
      : 'offline';

  return [
    {
      id: 'vivi-core',
      name: 'Vivi Core',
      kind: 'agent',
      status: viviStatus,
      signal: `${input.mission.phase} / ${input.telemetry.state.toUpperCase()}`,
      detail: input.viviRuntime?.warnings?.length
        ? `${input.telemetry.detail} Warning rail: ${input.viviRuntime.warnings[0]}`
        : input.telemetry.detail,
      source: input.telemetry.source,
      lastSeen: input.viviRuntime?.runtime.heartbeatAt || input.telemetry.lastUpdate,
    },
    {
      id: 'mission-control-app',
      name: 'LIONCOM Command Surface',
      kind: 'service',
      status: 'active',
      signal: 'Operator deck online',
      detail: 'Primary local surface for monitoring, routing, Telegram relay and repair escalation.',
      source: 'mission-control-board',
    },
    {
      id: 'dashboard-pipeline',
      name: 'Runtime Telemetry Pipeline',
      kind: 'pipeline',
      status: input.telemetry.state === 'live' ? 'active' : input.telemetry.state === 'stale' ? 'warning' : 'offline',
      signal: input.telemetry.state === 'live' ? 'Fresh snapshot' : 'Visibility degraded',
      detail: input.telemetry.detail,
      source: relativePath(PATHS.DASHBOARD_STATE),
      lastSeen: input.telemetry.lastUpdate,
    },
    {
      id: 'cron-automations',
      name: 'Automation Rail',
      kind: 'automation',
      status: input.cron?.available
        ? (input.cron.hasMorningBriefing || input.cron.hasNightlyResearch || input.cron.hasBackup ? 'active' : 'warning')
        : 'monitoring',
      signal: input.cron?.available ? `${input.cron.entries.length} visible schedule(s)` : 'No local cron visibility',
      detail: input.cron?.available
        ? 'Morning, nightly and backup schedules can be inspected locally.'
        : 'This machine cannot see the production cron rail. Treat cron state as remote or not configured here.',
      source: 'crontab -l',
    },
    {
      id: 'github-backup',
      name: 'Git Backup Rail',
      kind: 'automation',
      status: input.gitRepo
        ? input.githubSync.state === 'healthy'
          ? 'active'
          : input.githubSync.state === 'blocked'
            ? 'warning'
            : 'monitoring'
        : 'offline',
      signal: input.gitRepo ? input.githubSync.state.toUpperCase() : 'No git repo detected',
      detail: input.githubSync.detail,
      source: relativePath(PATHS.GITHUB_SYNC_STATUS),
    },
    {
      id: 'telegram-relay',
      name: 'Telegram Relay',
      kind: 'service',
      status: input.telegram?.status === 'OK' ? 'active' : input.telegram?.status === 'WARNING' ? 'warning' : 'monitoring',
      signal: input.telegram?.status || 'UNKNOWN',
      detail: input.telegramInboxCount > 0
        ? `Mobile bridge has ${input.telegramInboxCount} inbound packet(s) on the rail. ${input.telegram?.lastLogEntry || 'Outbound delivery has no fresh confirmation yet.'}`
        : input.telegram?.lastInboundEntry
          ? `${input.telegram.lastInboundEntry}. ${input.telegram.lastLogEntry || 'Outbound delivery has no fresh confirmation yet.'}`
          : input.telegram?.lastLogEntry || 'Telegram relay has no recent confirmed packet yet.',
      source: input.telegram?.source ? relativePath(input.telegram.source) : 'Telegram secrets + outbox rail',
      lastSeen: input.telegram?.lastInboundTime || input.telegram?.lastLogTime,
    },
    {
      id: 'codex-lane',
      name: 'Codex Deck',
      kind: 'agent',
      status: input.codexRuntime.state === 'attention'
        ? 'warning'
        : input.codexRuntime.state === 'working'
          ? 'active'
          : input.codexRuntime.state === 'reporting'
            ? 'monitoring'
            : 'waiting',
      signal: `${input.codexRuntime.pendingOperatorMessages} operator message(s) / ${input.codexRuntime.queuedPackets} queued packet(s)`,
      detail: input.codexRuntime.stalePendingMessages
        ? `${input.codexRuntime.detail} ${input.codexRuntime.watcherRecommendation}`
        : input.codexRuntime.detail,
      source: relativePath(PATHS.CODEX_RUNTIME),
    },
    {
      id: 'vivi-command-rail',
      name: 'Vivi Command Rail',
      kind: 'pipeline',
      status: input.viviCommandQueueCount > 0 ? 'monitoring' : 'active',
      signal: `${input.viviCommandQueueCount} queued command packet(s)`,
      detail: input.viviCommandQueueCount > 0
        ? 'Direct Vivi commands are staged locally and mirrored into the work intake rail.'
        : 'No direct Vivi command is queued right now.',
      source: relativePath(PATHS.VIVI_COMMAND_QUEUE),
    },
    {
      id: 'vps-live-bridge',
      name: 'VPS Live Bridge',
      kind: 'pipeline',
      status: input.remoteBridge.state === 'live-remote'
        ? 'active'
        : input.remoteBridge.state === 'stale-remote'
          ? 'warning'
          : input.remoteBridge.state === 'planned'
            ? 'waiting'
            : 'monitoring',
      signal: `${input.remoteBridge.state} / ${input.remoteBridge.expectedMode}`,
      detail: `${input.remoteBridge.detail} ${input.remoteBridge.suggestedAction}`,
      source: relativePath(PATHS.REMOTE_BRIDGE_STATUS),
      lastSeen: input.remoteBridge.lastHeartbeatAt,
    },
    {
      id: 'repair-lane',
      name: 'Rescue / Repair Queue',
      kind: 'pipeline',
      status: input.repairQueueCount > 0 ? 'warning' : input.blockers.length > 0 ? 'monitoring' : 'active',
      signal: `${input.repairQueueCount} queued repair packet(s)`,
      detail: input.repairQueueCount > 0
        ? 'System repair packets are queued for Vivi-driven analysis and stabilization.'
        : 'No queued repair packet is waiting right now.',
      source: relativePath(PATHS.REPAIR_QUEUE),
    },
  ];
}

function buildTimeline(input: {
  snapshot: DashboardStateSnapshot | null;
  viviRuntime: ViviRuntimeSnapshot | null;
  viviState: ViviStateSnapshot | null;
  viviReports: ViviReportEntry[];
  lastCommit: string | undefined;
  decisions: string[];
  openPoints: string[];
  telemetry: TelemetrySummary;
  viviCommands: BridgePacket[];
}): TimelineEntry[] {
  const items: TimelineEntry[] = [];

  if (input.telemetry.lastUpdate) {
    items.push({
      time: formatMoment(input.telemetry.lastUpdate),
      label: input.telemetry.state === 'live' ? 'Frische Telemetrie eingezogen' : 'Telemetrie ist veraltet',
      detail: input.telemetry.detail,
      tone: input.telemetry.state === 'live' ? 'ok' : 'warning',
    });
  }

  if (input.viviState?.currentState) {
    items.push({
      time: formatMoment(input.viviState.lastTransitionAt),
      label: `Vivi-Zustand ${input.viviState.currentState}`,
      detail: input.viviState.transitionReason,
      tone: input.viviState.currentState === 'FREEZE'
        ? 'critical'
        : input.viviState.currentState === 'RECOVER'
          ? 'warning'
          : 'info',
    });
  }

  const recentActions: TimelineEntry[] = input.snapshot?.layers?.log?.recentActions?.map((entry) => ({
    time: entry.time || 'recent',
    label: entry.message || 'System update',
    detail: entry.type || 'system',
    tone: entry.type === 'deploy' ? 'ok' : entry.type === 'system' ? 'info' : 'warning',
  })) || [];

  const runtimeSteps: TimelineEntry[] = input.viviRuntime?.recentSteps?.slice(0, 2).map((entry) => ({
    time: formatMoment(entry.time),
    label: entry.label,
    detail: entry.detail,
    tone: entry.tone,
  })) || [];

  const decisionEntries = input.decisions.slice(0, 2).map((decision, index) => ({
    time: `handoff-${index + 1}`,
    label: decision,
    detail: 'Letzte Architekturentscheidung',
    tone: 'info' as const,
  }));

  const blockerEntries = input.openPoints.slice(0, 2).map((item, index) => ({
    time: `open-${index + 1}`,
    label: item,
    detail: 'Offener Punkt aus dem Handoff',
    tone: 'warning' as const,
  }));

  const commitEntry = input.lastCommit
    ? [{ time: 'git', label: `Letzter Commit ${input.lastCommit}`, detail: 'Repository-Gedächtnisschiene', tone: 'ok' as const }]
    : [];

  const viviCommandEntries = input.viviCommands.slice(0, 2).map((entry) => ({
    time: formatMoment(entry.addedAt),
    label: `Vivi-Auftrag eingereiht: ${entry.title}`,
    detail: entry.summary,
    tone: entry.status === 'queued' ? 'info' as const : 'ok' as const,
  }));

  const reportEntries = input.viviReports.slice(0, 2).map((entry) => ({
    time: formatMoment(entry.addedAt),
    label: `Vivi-Report: ${entry.title}`,
    detail: entry.summary,
    tone: entry.kind === 'recovery' ? 'warning' as const : 'ok' as const,
  }));

  return dedupeTimelineEntries([
    ...items,
    ...runtimeSteps,
    ...recentActions,
    ...reportEntries,
    ...viviCommandEntries,
    ...commitEntry,
    ...decisionEntries,
    ...blockerEntries,
  ]).slice(0, 10);
}

function buildViviSteps(input: {
  snapshot: DashboardStateSnapshot | null;
  viviRuntime: ViviRuntimeSnapshot | null;
  viviState: ViviStateSnapshot | null;
  viviReports: ViviReportEntry[];
  telemetry: TelemetrySummary;
  mission: MissionSummary;
  viviCommands: BridgePacket[];
  workIntake: WorkIntakeEntry[];
  repairQueue: BridgePacket[];
}): TimelineEntry[] {
  const steps: TimelineEntry[] = [];

  if (input.telemetry.lastUpdate) {
    steps.push({
      time: formatMoment(input.telemetry.lastUpdate),
      label: input.telemetry.state === 'live' ? 'Vivi-Telemetrie bestätigt' : 'Vivi-Sicht eingeschränkt',
      detail: input.telemetry.detail,
      tone: input.telemetry.state === 'live' ? 'ok' : input.telemetry.state === 'stale' ? 'warning' : 'critical',
    });
  }

  if (input.viviState?.currentState) {
    steps.push({
      time: formatMoment(input.viviState.lastTransitionAt),
      label: `Zustandswechsel -> ${input.viviState.currentState}`,
      detail: input.viviState.transitionReason,
      tone: input.viviState.currentState === 'FREEZE'
        ? 'critical'
        : input.viviState.currentState === 'RECOVER'
          ? 'warning'
          : 'info',
    });
  }

  const recentActions: TimelineEntry[] = input.snapshot?.layers?.log?.recentActions?.map((entry) => ({
    time: entry.time ? formatMoment(entry.time) : 'recent',
    label: entry.message || 'Runtime-Bewegung erkannt',
    detail: entry.type ? `Runtime-Typ: ${entry.type}` : 'Im lokalen Runtime-Log erfasst',
    tone: entry.type === 'error'
      ? 'critical'
      : entry.type === 'warning'
        ? 'warning'
        : entry.type === 'deploy'
          ? 'ok'
          : 'info',
  })) || [];

  const runtimeSteps: TimelineEntry[] = input.viviRuntime?.recentSteps?.slice(0, 4).map((entry) => ({
    time: formatMoment(entry.time),
    label: entry.label,
    detail: entry.detail,
    tone: entry.tone,
  })) || [];

  const commandEntries = input.viviCommands.slice(0, 3).map((entry) => ({
    time: formatMoment(entry.addedAt),
    label: `Für Vivi eingereiht: ${entry.title}`,
    detail: entry.summary,
    tone: entry.status === 'queued' ? 'info' as const : 'ok' as const,
  }));

  const intakeEntries = input.workIntake.slice(0, 3).map((entry) => ({
    time: formatMoment(entry.addedAt),
    label: `Builder intake: ${entry.title}`,
    detail: `${entry.urgency.toUpperCase()} / ${entry.summary}`,
    tone: entry.urgency === 'critical' ? 'critical' as const : entry.urgency === 'high' ? 'warning' as const : 'info' as const,
  }));

  const repairEntries = input.repairQueue.slice(0, 2).map((entry) => ({
    time: formatMoment(entry.addedAt),
    label: `Repair rail: ${entry.title}`,
    detail: entry.summary,
    tone: 'warning' as const,
  }));

  const reportEntries = input.viviReports.slice(0, 3).map((entry) => ({
    time: formatMoment(entry.addedAt),
    label: `${entry.kind.toUpperCase()}: ${entry.title}`,
    detail: `${entry.summary}${entry.nextStep ? ` Next: ${entry.nextStep}` : ''}`,
    tone: entry.kind === 'recovery'
      ? 'warning' as const
      : entry.kind === 'verify'
        ? 'ok' as const
        : 'info' as const,
  }));

  steps.push({
    time: input.mission.lastUpdated ? formatMoment(input.mission.lastUpdated) : 'mission',
    label: `Mission phase ${input.mission.phase}`,
    detail: input.mission.lastAction,
    tone: input.mission.systemState.toUpperCase().includes('BLOCK') ? 'warning' : 'info',
  });

  const merged = [...steps, ...runtimeSteps, ...recentActions, ...commandEntries, ...reportEntries, ...intakeEntries, ...repairEntries];
  if (merged.length === 0) {
    return [{
      time: 'idle',
      label: 'No Vivi step feed is visible yet',
      detail: 'Queue a Vivi command or wait for fresh runtime telemetry to populate this rail.',
      tone: 'warning',
    }];
  }

  return dedupeTimelineEntries(merged).slice(0, 10);
}

function dedupeTimelineEntries(entries: TimelineEntry[]): TimelineEntry[] {
  const seen = new Set<string>();

  return entries.filter((entry) => {
    const key = `${entry.label.trim().toLowerCase()}|${(entry.detail || '').trim().toLowerCase()}|${entry.tone}`;
    if (seen.has(key)) {
      return false;
    }
    seen.add(key);
    return true;
  });
}

async function buildSources(): Promise<SourceSnapshot[]> {
  const trackedSources = [
    { name: 'Dashboard', path: PATHS.DASHBOARD, detail: 'Primary status board' },
    { name: 'Task Queue', path: PATHS.TASK_QUEUE, detail: 'Operational work lanes' },
    { name: 'Backlog', path: PATHS.BACKLOG, detail: 'Queued and future work' },
    { name: 'Handoff', path: PATHS.HANDOFF_NEXT_CHAT, detail: 'Latest operating handoff' },
    { name: 'System Export', path: PATHS.SYSTEM_EXPORT, detail: 'Cross-system snapshot' },
    { name: 'Brain Dump', path: PATHS.BRAIN_DUMP, detail: 'Raw operator ideas' },
    { name: 'Work Intake', path: PATHS.WORK_INTAKE, detail: 'Requests waiting for Vivi decomposition' },
    { name: 'Learnings', path: PATHS.LEARNINGS, detail: 'Durable operator and system learnings' },
    { name: 'Error Classes', path: PATHS.ERROR_CLASSES, detail: 'Recurring anti-pattern register for Vivi and Codex' },
    { name: 'Operator Profile', path: PATHS.OPERATOR_PROFILE, detail: 'How Vivi should interpret the operator' },
    { name: 'Research Playbook', path: PATHS.VIVI_RESEARCH_PLAYBOOK, detail: 'How Vivi should launch research from rough ideas' },
    { name: 'Task Operating Standard', path: PATHS.TASK_OPERATING_STANDARD, detail: 'Task posture, WIP and anti-sloppiness rules' },
    { name: 'Morning Briefing Standard', path: PATHS.MORNING_BRIEFING_STANDARD, detail: 'Signal-first operator briefing rules' },
    { name: 'Model Routing Standard', path: PATHS.MODEL_ROUTING_STANDARD, detail: 'When Vivi should route work to Codex versus routine lanes' },
    { name: 'Vivi Drop Review', path: PATHS.VIVI_DROP_REVIEW, detail: 'Curated review of Vivi review-drop work before integration' },
    { name: 'Codex Chat', path: PATHS.CODEX_CHAT_THREAD, detail: 'Board-first operator and Codex conversation' },
    { name: 'Codex Inbox', path: PATHS.CODEX_INBOX, detail: 'Queued Codex packets' },
    { name: 'Vivi Command Queue', path: PATHS.VIVI_COMMAND_QUEUE, detail: 'Direct Vivi mission commands' },
    { name: 'Vivi Runtime', path: PATHS.VIVI_RUNTIME, detail: 'Fresh runtime heartbeat and recent steps' },
    { name: 'Vivi State', path: PATHS.VIVI_STATE, detail: 'Current operating state machine snapshot' },
    { name: 'Vivi Reports', path: PATHS.VIVI_REPORTS, detail: 'Append-only result and handoff rail' },
    { name: 'Work Blocks', path: PATHS.WORK_BLOCKS, detail: 'Generated execution blocks for Vivi and Codex' },
    { name: 'Subtask Queue', path: PATHS.SUBTASK_QUEUE, detail: 'Generated subtask rail' },
    { name: 'Research Queue', path: PATHS.RESEARCH_QUEUE, detail: 'Generated research and evidence passes' },
    { name: 'Decision Queue', path: PATHS.DECISION_QUEUE, detail: 'Open decisions and watchpoints' },
    { name: 'Freeze Log', path: PATHS.FREEZE_LOG, detail: 'Current freeze posture and required action' },
    { name: 'Work Engine State', path: PATHS.WORK_ENGINE_STATE, detail: 'Structured work-engine snapshot' },
    { name: 'Autonomy State', path: PATHS.AUTONOMY_STATE, detail: 'Worker/supervisor readiness, next dispatch and operator freedom' },
    { name: 'Task Claims', path: PATHS.TASK_CLAIMS, detail: 'Lease ledger for Vivi and Codex ownership' },
    { name: 'Remote Bridge Status', path: PATHS.REMOTE_BRIDGE_STATUS, detail: 'Remote VPS bridge posture' },
    { name: 'GitHub Sync Status', path: PATHS.GITHUB_SYNC_STATUS, detail: 'GitHub sync and freeze reliability status' },
    { name: 'Qualification Status', path: PATHS.SYSTEM_QUALIFICATION_STATUS, detail: 'Formal qualification state and release posture' },
    { name: 'Readiness Review', path: PATHS.PRODUCTION_READINESS_REVIEW, detail: 'Formal production readiness review and blockers' },
    { name: 'Qualification Suite', path: PATHS.QUALIFICATION_SUITE, detail: 'Last full qualification suite run' },
    { name: 'End-to-End Validation', path: PATHS.QUALIFICATION_E2E, detail: 'Evidence for the full operator to Vivi to Codex to report flow' },
    { name: 'Failure Recovery Validation', path: PATHS.QUALIFICATION_FAILURE_RECOVERY, detail: 'Evidence for freeze, repair, recovery and fallback validation' },
    { name: 'Codex Runtime', path: PATHS.CODEX_RUNTIME, detail: 'Board-only Codex runtime snapshot' },
    { name: 'Codex Reports', path: PATHS.CODEX_REPORTS, detail: 'Codex reply history mirrored from the board rail' },
    { name: 'Telegram Inbox', path: PATHS.TELEGRAM_INBOX, detail: 'Inbound mobile commands and dumps' },
    { name: 'Telegram Outbox', path: PATHS.TELEGRAM_OUTBOX, detail: 'Outbound remote relay packets' },
    { name: 'Telegram Policy', path: PATHS.TELEGRAM_MOBILE_POLICY, detail: 'Critical-only mobile escalation policy' },
    { name: 'Autonomy Start Guide', path: PATHS.AUTONOMY_START_GUIDE, detail: 'Start path for the autonomous operating mode' },
    { name: 'Autonomy Operating Standard', path: PATHS.AUTONOMY_OPERATING_STANDARD, detail: 'Claim order, lease discipline and human minimization rules' },
    { name: 'Vivi Autonomy Prompt', path: PATHS.VIVI_AUTONOMY_BOOT_PROMPT, detail: 'Boot prompt that puts Vivi into the worker loop' },
    { name: 'Repair Queue', path: PATHS.REPAIR_QUEUE, detail: 'Queued repair and rescue actions' },
    { name: 'State Cache', path: PATHS.DASHBOARD_STATE, detail: 'Normalized runtime state' },
    { name: 'Desktop Settings', path: path.join(os.homedir(), 'Library', 'Application Support', 'LIONCOM', 'settings.json'), detail: 'Native app workspace selection' },
    { name: 'Desktop Status', path: path.join(os.homedir(), 'Library', 'Application Support', 'LIONCOM', 'desktop-status.json'), detail: 'Native app startup posture' },
    { name: 'Desktop Log', path: path.join(os.homedir(), 'Library', 'Application Support', 'LIONCOM', 'logs', 'desktop.log'), detail: 'Native app startup and runtime log' },
  ];

  return Promise.all(
    trackedSources.map(async (source) => {
      try {
        const stat = await fs.stat(source.path);
        const age = ageMinutes(stat.mtime.toISOString());
        return {
          name: source.name,
          path: relativePath(source.path),
          status: age > 360 ? 'warning' : 'online',
          detail: age > 360 ? `${source.detail} / stale for ${describeFreshness(age)}` : source.detail,
          lastModified: stat.mtime.toISOString(),
        } satisfies SourceSnapshot;
      } catch {
        return {
          name: source.name,
          path: relativePath(source.path),
          status: 'missing',
          detail: `${source.detail} / not found yet`,
        } satisfies SourceSnapshot;
      }
    }),
  );
}

async function buildProjects(): Promise<ProjectSignal[]> {
  const targets = [
    { dir: PATHS.PROJECTS, category: 'project' as const },
    { dir: PATHS.DASHBOARD_DIR, category: 'dashboard' as const },
  ];

  const result: ProjectSignal[] = [];

  for (const target of targets) {
    try {
      const entries = await fs.readdir(target.dir, { withFileTypes: true });
      const files = entries
        .filter((entry) => entry.isFile())
        .filter((entry) => entry.name.endsWith('.md') || entry.name.endsWith('.html'))
        .slice(0, target.category === 'project' ? 10 : 6);

      for (const file of files) {
        const fullPath = path.join(target.dir, file.name);
        const stat = await fs.stat(fullPath);
        result.push({
          name: file.name.replace(/\.(md|html)$/i, '').replace(/_/g, ' '),
          path: relativePath(fullPath),
          modified: stat.mtime.toISOString(),
          category: target.category,
        });
      }
    } catch {
      // Optional directory missing.
    }
  }

  return result.sort((a, b) => (b.modified || '').localeCompare(a.modified || '')).slice(0, 14);
}

function buildAutomations(
  cron: Awaited<ReturnType<typeof getCronStatus>> | null,
  telegramInbox: BridgePacket[],
  telegramOutbox: BridgePacket[],
  repairQueue: BridgePacket[],
  counts: {
    telegramInboxCount: number;
    telegramOutboxCount: number;
    repairQueueCount: number;
  },
): AutomationSignal[] {
  const items: AutomationSignal[] = [];

  if (cron?.available) {
    for (const entry of cron.entries) {
      items.push({
        id: entry.command,
        name: humanizeAutomationName(entry.command),
        status: entry.active ? 'active' : 'scheduled',
        schedule: entry.schedule,
        detail: `Observed via crontab: ${entry.command}`,
      });
    }
  }

  items.push({
    id: 'telegram-bridge',
    name: 'Telegram Bridge',
    status: counts.telegramInboxCount > 0 || counts.telegramOutboxCount > 0 ? 'active' : 'scheduled',
    schedule: 'event-driven',
    detail: counts.telegramInboxCount > 0
      ? `Inbound mobile commands are flowing (${counts.telegramInboxCount} packet(s) on the rail) and outbound relay remains armed.`
      : counts.telegramOutboxCount > 0
        ? 'Outbound packets are being staged for remote delivery.'
        : 'Ready to stage or send packets when operator uses Comms deck.',
  });

  items.push({
    id: 'repair-rail',
    name: 'Repair Rail',
    status: counts.repairQueueCount > 0 ? 'warning' : 'scheduled',
    schedule: 'on demand',
    detail: counts.repairQueueCount > 0 ? 'Repair packets are queued and require Vivi attention.' : 'Critical issues can be escalated into repair packets from the alert deck.',
  });

  if (items.length === 0) {
    items.push({
      id: 'automation-empty',
      name: 'Automation rail',
      status: 'offline',
      schedule: 'not visible',
      detail: 'No local automation visibility is currently available.',
    });
  }

  return items;
}

function buildNotes(
  learnings: Array<{ title: string }> | undefined,
  nextSteps: string[],
): string[] {
  const learningTitles = (learnings || []).slice(0, 3).map((item) => item.title);
  return [...learningTitles, ...nextSteps.slice(0, 3)].filter(Boolean);
}

function buildEssentialAlerts(input: {
  telemetry: TelemetrySummary;
  sources: SourceSnapshot[];
  blockers: BlockerSignal[];
  gitRepo: boolean;
  mission: MissionSummary;
  remoteBridge: RemoteBridgeStatus;
  githubSync: GitHubSyncSnapshot;
  desktop: Awaited<ReturnType<typeof getDesktopDiagnostics>> | null;
}): SystemAlert[] {
  const alerts: SystemAlert[] = [];

  if (input.telemetry.state !== 'live') {
    alerts.push({
      id: 'telemetry-stale',
      severity: input.telemetry.state === 'absent' ? 'critical' : 'warning',
      title: 'Live Vivi visibility is degraded',
      detail: input.telemetry.detail,
      recommendation: 'Dispatch a repair packet to Vivi to restore fresh runtime telemetry or confirm the remote state manually before trusting the board.',
      source: input.telemetry.source,
      action: 'rescue',
    });
  }

  for (const source of input.sources.filter((item) => ['Dashboard', 'Task Queue', 'Handoff', 'State Cache'].includes(item.name) && item.status === 'missing')) {
    alerts.push({
      id: `missing-${source.name.toLowerCase().replace(/\s+/g, '-')}`,
      severity: 'critical',
      title: `${source.name} is missing`,
      detail: `${source.name} is a core command source but is not present in the local workspace picture.`,
      recommendation: 'Generate a repair packet so Vivi can rebuild or relink the missing source before further trust is placed in the dashboard.',
      source: source.path,
      action: 'rescue',
    });
  }

  if (!input.gitRepo) {
    alerts.push({
      id: 'git-missing',
      severity: 'critical',
      title: 'Die Git-Gedächtnisschiene fehlt',
      detail: 'Der Workspace wird nicht als Git-Repository erkannt. Dadurch sind Kommandohistorie und Backup-Gedächtnis gefährdet.',
      recommendation: 'Behandle das System als unsicher, bis der Repository-Zustand wiederhergestellt oder ein frischer lokaler Klon eingebunden ist.',
      source: '.git',
      action: 'rescue',
    });
  }

  if (input.desktop && !input.desktop.workspaceValid) {
    alerts.push({
      id: 'desktop-workspace-invalid',
      severity: 'critical',
      title: 'Desktop workspace root is invalid',
      detail: input.desktop.startupDetail,
      recommendation: 'Do not trust the native command surface until the workspace root markers are restored or the desktop settings point back to the correct LIONCOM root.',
      source: relativePath(input.desktop.settingsPath),
      action: 'rescue',
    });
  }

  if (input.githubSync.state === 'blocked') {
    alerts.push({
      id: 'github-sync-blocked',
      severity: 'warning',
      title: 'GitHub sync is blocked',
      detail: input.githubSync.detail,
      recommendation: 'Preserve local freeze integrity, but repair authenticated GitHub write access before relying on shared remote state.',
      source: relativePath(PATHS.GITHUB_SYNC_STATUS),
      action: 'review',
      actionLabel: 'Fixspur öffnen',
      actionTargetTab: 'system',
      actionTargetAnchor: 'control-reliability',
      followThrough: [
        'Arbeite lokal weiter und behandle LIONCOM plus Vivi_Backup bis dahin als führende Freeze-Spur.',
        'Führe ./scripts/repair_github_sync.sh mit einem Token aus, der echten Repo-Schreibzugriff hat.',
        'Prüfe danach die GitHub-Sync-Diagnose erneut und bestätige, dass der 403-Fehler verschwunden ist.',
        'Vertraue Shared Remote State erst wieder, wenn Push-Readiness und Freeze-Pfad erneut verifiziert sind.',
      ],
    });
  }

  if (input.remoteBridge.expectedMode !== 'local' && input.remoteBridge.state === 'stale-remote') {
    alerts.push({
      id: 'vps-bridge-stale',
      severity: 'warning',
      title: 'Remote Vivi bridge is stale',
      detail: input.remoteBridge.detail,
      recommendation: 'Treat local fallback as temporary only. Restore the VPS heartbeat before trusting the live runtime picture.',
      source: relativePath(PATHS.REMOTE_BRIDGE_STATUS),
      action: 'rescue',
    });
  }

  if (input.mission.systemState.toUpperCase().includes('BLOCK') && input.blockers.length > 0) {
    alerts.push({
      id: 'active-blocker',
      severity: 'warning',
      title: 'Operational blocker is visible',
      detail: input.blockers[0].description,
      recommendation: 'Review the blocker and decide whether to resolve it now or queue it for scheduled repair.',
      source: relativePath(PATHS.DASHBOARD_STATE),
      action: 'review',
    });
  }

  return alerts.slice(0, 4);
}

function buildMaintenanceAlerts(input: {
  telemetry: TelemetrySummary;
  cron: Awaited<ReturnType<typeof getCronStatus>> | null;
  telegram: Awaited<ReturnType<typeof getTelegramStatus>> | null;
  gitRemote: boolean;
  taskQueue: { active: TaskItem[]; waiting: TaskItem[]; completed: TaskItem[] };
  workIntakeCount: number;
  remoteBridge: RemoteBridgeStatus;
  githubSync: GitHubSyncSnapshot;
  codexRuntime: CodexRuntimeSnapshot;
  desktop: Awaited<ReturnType<typeof getDesktopDiagnostics>> | null;
}): SystemAlert[] {
  const items: SystemAlert[] = [];

  if (!input.cron?.available) {
    items.push({
      id: 'cron-visibility',
      severity: 'maintenance',
      title: 'Cron-Schiene ist auf diesem Mac nicht sichtbar',
      detail: 'Diese LIONCOM-Instanz kann die Cron-Pläne lokal nicht direkt lesen. Das ist auf einem Command-Mac akzeptabel, schwächt aber die Sicht auf Automationen.',
      recommendation: 'Reihe einen Night-Sweep ein, wenn du die volle Cron-Sicht lokal gespiegelt haben willst.',
      source: 'crontab -l',
      action: 'queue-night',
    });
  }

  if (!input.telegram?.configured) {
    items.push({
      id: 'telegram-config',
      severity: 'maintenance',
      title: 'Telegram-Bridge ist lokal nicht scharf',
      detail: 'Telegram-Kommandos und ausgehende Pakete lassen sich weiter einreihen, aber die Live-Zustellung ist auf diesem Mac noch nicht aktiviert.',
      recommendation: 'Hinterlege später lokale Bridge-Credentials, wenn dieser Mac auch direkt mobil relayen soll.',
      source: relativePath(PATHS.TELEGRAM_OUTBOX),
      action: 'queue-night',
    });
  }

  if (!input.gitRemote) {
    items.push({
      id: 'git-remote',
      severity: 'maintenance',
      title: 'Remote-Backup-Mirror ist nicht verbunden',
      detail: 'Das lokale Repository existiert, aber aus dieser Umgebung hängt noch keine entfernte Backup-Schiene daran.',
      recommendation: 'Halte lokale Arbeit vorerst sauber und binde später ein Remote an, wenn dieser Mac der führende Command-Host bleibt.',
      source: '.git/config',
      action: 'review',
    });
  }

  if (input.remoteBridge.expectedMode !== 'local' && input.remoteBridge.state !== 'live-remote') {
    items.push({
      id: 'remote-bridge-not-live',
      severity: 'maintenance',
      title: 'Remote-Vivi-Bridge ist noch nicht live',
      detail: input.remoteBridge.detail,
      recommendation: input.remoteBridge.suggestedAction,
      source: relativePath(PATHS.REMOTE_BRIDGE_STATUS),
      action: 'queue-night',
    });
  }

  if (input.githubSync.pushReady === 'unknown') {
    items.push({
      id: 'github-auth-unverified',
      severity: 'maintenance',
      title: 'GitHub-Schreibzugriff ist noch nicht verifiziert',
      detail: 'Remote-Repository-Metadaten sind sichtbar, aber dieser Mac hat noch nicht bewiesen, dass authentifizierte Pushes zuverlässig funktionieren.',
      recommendation: 'Führe zuerst die GitHub-Sync-Diagnose aus, bevor du Freeze- oder Kollaborationsabläufe darüber trägst.',
      source: relativePath(PATHS.GITHUB_SYNC_STATUS),
      action: 'queue-night',
    });
  }

  if (input.codexRuntime.stalePendingMessages) {
    items.push({
      id: 'codex-rail-aging',
      severity: 'maintenance',
      title: 'Codex board rail needs attention',
      detail: input.codexRuntime.detail,
      recommendation: input.codexRuntime.watcherRecommendation,
      source: relativePath(PATHS.CODEX_RUNTIME),
      action: 'review',
    });
  }

  if (input.desktop && input.desktop.mode === 'desktop' && !input.desktop.asarEnabled) {
    items.push({
      id: 'desktop-asar-disabled',
      severity: 'maintenance',
      title: 'Desktop package still runs with asar disabled',
      detail: 'This is acceptable for the current working build, but it remains a release-hardening debt and should be revisited before calling the native package fully polished.',
      recommendation: 'Keep the current stable packaging path, but track a later hardening pass for asar/unpack once it can be done without breaking the embedded server.',
      source: relativePath(path.join(WORKSPACE_ROOT, 'mission-control-board', 'package.json')),
      action: 'queue-night',
    });
  }

  if (input.workIntakeCount > 6 || input.taskQueue.waiting.length > 2) {
    items.push({
      id: 'lane-pressure',
      severity: 'maintenance',
      title: 'Queue pressure is building',
      detail: `There are ${input.workIntakeCount} incoming work packet(s) and ${input.taskQueue.waiting.length} waiting task(s).`,
      recommendation: 'Queue a night triage so Vivi can rebalance backlog, waiting tasks and repair debt while you are away.',
      source: relativePath(PATHS.WORK_INTAKE),
      action: 'queue-night',
    });
  }

  if (input.telemetry.state === 'stale') {
    items.push({
      id: 'telemetry-drift',
      severity: 'maintenance',
      title: 'Telemetry rail needs a more direct bridge',
      detail: 'The board is healthy enough to route work, but not healthy enough to guarantee a real-time picture of the remote runtime.',
      recommendation: 'Prioritize the remote bridge after the current operating surface is stable.',
      source: relativePath(PATHS.DASHBOARD_STATE),
      action: 'queue-night',
    });
  }

  return items.slice(0, 5);
}

function parseBrainDumpEntries(content: string | null): BrainDumpEntry[] {
  if (!content) return [];

  return parseStructuredBlocks(content).map((block) => ({
    id: block.id,
    addedAt: block.fields['Added'] || 'unknown',
    status: block.fields['Status'] || 'raw',
    summary: block.fields['Summary'] || block.body.slice(0, 140),
    context: block.fields['Context'],
    category: block.fields['Category'],
    attachments: parseAttachmentNames(block.fields['Attachments']),
    attachmentCount: parseAttachmentNames(block.fields['Attachments']).length,
  })).slice(0, 8);
}

function parseWorkIntakeEntries(content: string | null): WorkIntakeEntry[] {
  if (!content) return [];

  return parseStructuredBlocks(content).map((block) => ({
    id: block.id,
    addedAt: block.fields['Added'] || 'unknown',
    status: block.fields['Status'] || 'new',
    urgency: block.fields['Urgency'] || 'normal',
    title: block.fields['Title'] || block.id,
    desiredOutcome: block.fields['Desired Outcome'],
    summary: block.fields['Summary'] || block.body.slice(0, 140),
    category: block.fields['Category'],
    attachments: parseAttachmentNames(block.fields['Attachments']),
    attachmentCount: parseAttachmentNames(block.fields['Attachments']).length,
  })).slice(0, 8);
}

function parseBridgePackets(content: string | null, channel: BridgePacket['channel']): BridgePacket[] {
  if (!content) return [];

  return parseStructuredBlocks(content).map((block) => ({
    id: block.id,
    channel,
    addedAt: block.fields['Added'] || 'unknown',
    status: block.fields['Status'] || 'queued',
    title: block.fields['Title'] || block.id,
    summary: block.fields['Summary'] || block.body.slice(0, 160),
    target: block.fields['Target'],
    delivery: block.fields['Delivery'],
    source: block.fields['Source'],
    category: block.fields['Category'],
    priority: block.fields['Priority'] || block.fields['Urgency'] || block.fields['Severity'],
    dispatchTargetMode: block.fields['Dispatch Target Mode'],
    runtimeContext: block.fields['Runtime Context'],
    attachments: parseAttachmentNames(block.fields['Attachments']),
    attachmentCount: parseAttachmentNames(block.fields['Attachments']).length,
  })).slice(0, 8);
}

function parseViviReports(content: string | null): ViviReportEntry[] {
  if (!content) return [];

  return parseStructuredBlocks(content).map((block) => ({
    id: block.id,
    addedAt: block.fields['Added'] || 'unknown',
    kind: block.fields['Kind'] || 'result',
    state: block.fields['State'] || 'unknown',
    phase: block.fields['Phase'] || 'unknown',
    title: block.fields['Title'] || block.id,
    summary: block.fields['Summary'] || block.body.slice(0, 160),
    outcome: block.fields['Outcome'],
    nextStep: block.fields['Next Step'],
    operatorAction: block.fields['Operator Action'],
    commandRef: block.fields['Command Ref'],
  })).slice(0, 8);
}

function normalizeRemoteBridge(status: RemoteBridgeStatus): ControlRoomData['remoteBridge'] {
  return {
    state: status.state,
    detail: status.detail,
    suggestedAction: status.suggestedAction,
    expectedMode: status.expectedMode,
    allowLocalFallback: status.allowLocalFallback,
    source: status.source,
    ingestUrl: status.ingestUrl,
    controlPlaneUrl: status.controlPlaneUrl,
    authReady: status.authReady,
    publicIngestReady: status.publicIngestReady,
    secretSource: [REDACTED]
    remoteHost: status.remoteHost,
    lastHeartbeatAt: status.lastHeartbeatAt,
  };
}

function normalizeGitHubSync(status: GitHubSyncSnapshot): ControlRoomData['githubSync'] {
  return {
    state: status.state,
    pushReady: status.pushReady,
    authMode: status.authMode,
    detail: status.detail,
    suggestedFix: status.suggestedFix,
    lastError: status.lastError,
    remoteConfigured: status.remoteConfigured,
    remoteUrl: status.remoteUrl,
    authLastChecked: status.authLastChecked,
  };
}

function normalizeCodexRuntime(status: CodexRuntimeSnapshot): ControlRoomData['codexRuntime'] {
  return {
    state: status.state,
    pendingOperatorMessages: status.pendingOperatorMessages,
    queuedPackets: status.queuedPackets,
    latestReference: status.latestReference,
    stalePendingMessages: status.stalePendingMessages,
    oldestPendingMinutes: status.oldestPendingMinutes,
    oldestQueuedMinutes: status.oldestQueuedMinutes,
    watcherRecommendation: status.watcherRecommendation,
    detail: status.detail,
  };
}

function normalizeAutonomy(state: AutonomyStateSnapshot): ControlRoomData['autonomy'] {
  return {
    readiness: state.readiness,
    summary: state.summary,
    operatorFreedom: state.operatorFreedom,
    notes: state.notes,
    viviLoop: state.viviLoop,
    codexLoop: state.codexLoop,
    activeClaims: state.activeClaims,
    staleClaims: state.staleClaims,
  };
}

function parseStructuredBlocks(content: string): Array<{ id: string; fields: Record<string, string>; body: string }> {
  const blocks: Array<{ id: string; fields: Record<string, string>; body: string }> = [];

  const sections = content
    .split(/^###\s+/m)
    .map((section) => section.trim())
    .filter(Boolean);

  for (const section of sections) {
    const [headline, ...bodyLines] = section.split('\n');
    const id = headline?.trim();
    const body = bodyLines.join('\n').trim();
    const fields: Record<string, string> = {};

    if (!id || id.startsWith('#')) continue;

    for (const line of body.split('\n')) {
      const fieldMatch = line.match(/^-\s*([^:]+):\s*(.+)$/);
      if (fieldMatch) {
        fields[fieldMatch[1].trim()] = fieldMatch[2].trim();
      }
    }

    blocks.push({ id, fields, body });
  }

  return blocks.reverse();
}

function parseAttachmentNames(value?: string): string[] {
  if (!value) return [];

  return value
    .split('|')
    .map((entry) => entry.trim())
    .filter(Boolean);
}

function countStructuredBlocks(content: string | null): number {
  if (!content) return 0;
  return parseStructuredBlocks(content).length;
}

function countStructuredBlocksByStatus(content: string | null, statuses: string[]): number {
  if (!content) return 0;
  const allowed = new Set(statuses.map((status) => status.toLowerCase()));
  return parseStructuredBlocks(content).filter((block) => allowed.has((block.fields['Status'] || '').trim().toLowerCase())).length;
}

function relativePath(filePath: string): string {
  return path.relative(WORKSPACE_ROOT, filePath) || path.basename(filePath);
}

function humanizeAutomationName(value: string): string {
  switch (value) {
    case 'morning_briefing':
      return 'Morning Briefing';
    case 'nightly_research':
      return 'Nightly Research';
    case 'backup':
      return 'Backup Rail';
    default:
      return value.replace(/[_-]/g, ' ');
  }
}

function ageMinutes(value: string): number {
  const time = new Date(value).getTime();
  if (Number.isNaN(time)) return 999999;
  return Math.max(0, Math.floor((Date.now() - time) / 60000));
}

function describeFreshness(minutes: number): string {
  if (minutes < 1) return 'less than a minute ago';
  if (minutes < 60) return `${minutes} minute${minutes === 1 ? '' : 's'} ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} hour${hours === 1 ? '' : 's'} ago`;
  const days = Math.floor(hours / 24);
  return `${days} day${days === 1 ? '' : 's'} ago`;
}

function formatMoment(value?: string): string {
  if (!value) return 'n/a';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;

  return date.toLocaleString('de-DE', {
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
}
