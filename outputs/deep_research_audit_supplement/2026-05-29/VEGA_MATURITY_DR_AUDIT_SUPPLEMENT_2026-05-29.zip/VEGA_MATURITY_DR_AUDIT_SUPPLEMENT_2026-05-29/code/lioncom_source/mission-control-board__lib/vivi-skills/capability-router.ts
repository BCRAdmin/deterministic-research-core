import type { AgentId } from '@/lib/types';
import type { CapabilityRouteDecision, ViviSkillCapability } from '@/lib/vivi-skills/types';

const DANGEROUS_PATTERNS = [
  /\b(api[-_ ]?key|credential|secret|token|passwort|auth)\b/i,
  /\b(production|prod|live)\s*(deploy|release|push)\b/i,
  /\b(deploye|deploy|veröffentliche|publish)\b/i,
  /\b(lösch|loesch|delete|remove|wipe|prune)\b/i,
  /\b(geld|zahlung|payment|rechnung|invoice|kauf|buy)\b/i,
  /\b(sende|send|email|mail|telegram|slack)\b/i,
];

const IMAGE_PATTERNS = [
  /\b(bild|image|grafik|illustration|foto|portrait|poster|logo|visual)\b/i,
  /\b(generiere|erstelle|erzeuge|zeichne|male|render)\b.*\b(bild|image|grafik|foto|logo)\b/i,
  /\bimage\s*(generation|generate|create)\b/i,
];

const YOUTUBE_TRANSCRIPT_PATTERNS = [
  /(?:https?:\/\/)?(?:www\.|m\.)?(?:youtube\.com|youtu\.be)\/[^\s<>"']+/i,
  /\b(youtube|youtu\.be|video)\b.*\b(zusammenfass|transkript|transcript|untertitel|captions?|ansehen|verarbeiten)\b/i,
  /\b(zusammenfass|transkript|transcript|untertitel|captions?)\b.*\b(youtube|youtu\.be|video)\b/i,
  /\b(fasse|fass)\b.*\b(youtube|youtu\.be|video)\b.*\bzusammen\b/i,
  /\b(youtube|youtu\.be|video)\b.*\bzusammen\b/i,
];

const CODE_PATTERNS = [
  /\b(code|repo|repository|commit|diff|branch|pull request|typescript|react|next\.?js|bug|test|build|lint)\b/i,
  /\b(fixe|fix|debug|debugge|implementiere|patch|refactor|verifiziere)\b.*\b(code|repo|bug|test|build|ui|api)\b/i,
];

const MISSING_SKILL_PATTERNS = [
  /\b(präsentation|praesentation|präsentationsdeck|praesentationsdeck|slide[-_ ]?deck|slides?|folien|powerpoint|deck)\b/i,
  /\b(docx|dokument|word|pdf|brief|vertrag)\b/i,
  /\b(spreadsheet|excel|xlsx|csv|tabelle|tabellenanalyse)\b/i,
  /\b(bild\s*bearbeiten|image\s*edit|foto\s*bearbeiten|hintergrund\s*entfernen)\b/i,
  /\b(skill|fähigkeit|faehigkeit|tool|plugin)\b.*\b(bauen|entwickeln|installieren|laden|fehlt|brauche)\b/i,
  /\b(recherchiere|suche|lies)\b.*\b(web|internet|online|website|url)\b/i,
];

const RESEARCH_PATTERNS = [
  /\b(recherchiere|analysiere|analyse|dossier|report|suche|prüfe|pruefe|lies)\b/i,
  /\b(zusammenfassung|roadmap|plan|konzept|strategie)\b/i,
];

export function routeViviCapability(input: {
  message: string;
  sessionTitle?: string;
  sessionTopic?: string;
}): CapabilityRouteDecision {
  const message = input.message.trim();
  const normalized = message.toLowerCase();

  const dangerous = DANGEROUS_PATTERNS.find((pattern) => pattern.test(message));
  if (dangerous) {
    return decision({
      kind: 'operator_gate',
      capability: inferDangerousCapability(normalized),
      targetAgent: 'operator',
      queueAsTask: false,
      shouldStartViviLoop: false,
      summary: 'Operator-Gate erforderlich',
      operatorMessage: 'Diese Anfrage berührt eine geschützte Aktion. Vivi darf sie vorbereiten, aber nicht ohne Operator-Go ausführen.',
      gateReason: 'Geschützt sind externe Sends, Credentials/Auth, Geld, Löschungen, Production-Deploys und unbekannter Remote-Code.',
      confidence: 0.92,
    });
  }

  if (isTrivialChatMessage(normalized)) {
    return decision({
      kind: 'direct_chat',
      capability: 'chat.direct',
      targetAgent: 'vivi',
      queueAsTask: false,
      shouldStartViviLoop: false,
      summary: 'Kurze Chatnachricht',
      operatorMessage: 'Kurzer Dialog-Ping. Keine Queue, keine Übergabe, kein Skill-Run nötig.',
      confidence: 0.9,
    });
  }

  if (/\b(bild\s*bearbeiten|image\s*edit|foto\s*bearbeiten|hintergrund\s*entfernen)\b/i.test(message)) {
    return decision({
      kind: 'missing_skill',
      capability: 'image.edit',
      targetAgent: 'vega',
      skillId: 'vivi.skill.propose',
      queueAsTask: false,
      shouldStartViviLoop: false,
      summary: 'Bildbearbeitung braucht einen verifizierten Skill',
      operatorMessage: 'Vivi schlägt einen lokalen Bildbearbeitungs-Skill für Vega vor, statt Bildgenerierung und Bildbearbeitung zu vermischen.',
      confidence: 0.84,
    });
  }

  if (IMAGE_PATTERNS.some((pattern) => pattern.test(message))) {
    return decision({
      kind: 'use_skill',
      capability: 'image.generate',
      targetAgent: 'vivi',
      skillId: 'image.generate.local',
      queueAsTask: false,
      shouldStartViviLoop: false,
      summary: 'Bildgenerierung erkannt',
      operatorMessage: 'Vivi nutzt lokale Bildgenerierung, schreibt ein Artefakt oder meldet ehrlich fehlenden Provider.',
      confidence: 0.88,
    });
  }

  if (YOUTUBE_TRANSCRIPT_PATTERNS.some((pattern) => pattern.test(message))) {
    return decision({
      kind: 'use_skill',
      capability: 'media.transcript',
      targetAgent: 'vivi',
      skillId: 'media.youtube.transcript',
      queueAsTask: false,
      shouldStartViviLoop: false,
      summary: 'YouTube-/Video-Transcript erkannt',
      operatorMessage: 'Vivi nutzt den lokalen Media-Ingest, schreibt ein Transcript-Artefakt oder meldet ehrlich ein Source-Gate.',
      confidence: 0.88,
    });
  }

  if (MISSING_SKILL_PATTERNS.some((pattern) => pattern.test(message))) {
    const capability = inferMissingSkillCapability(normalized);
    return decision({
      kind: 'missing_skill',
      capability,
      targetAgent: 'vega',
      skillId: 'vivi.skill.propose',
      queueAsTask: false,
      shouldStartViviLoop: false,
      summary: 'Fehlende oder noch nicht verifizierte Fähigkeit erkannt',
      operatorMessage: 'Vivi erstellt einen Skill-Vorschlag und eine Vega-Bauaufgabe, statt die Anfrage still in eine falsche Queue zu schieben.',
      confidence: 0.8,
    });
  }

  if (CODE_PATTERNS.some((pattern) => pattern.test(message))) {
    return decision({
      kind: 'handoff_vega',
      capability: 'vega.handoff',
      targetAgent: 'vega',
      skillId: 'vega.handoff.create',
      queueAsTask: false,
      shouldStartViviLoop: false,
      summary: 'Technische Arbeit für Vega erkannt',
      operatorMessage: 'Vivi hält den Dialog sichtbar und übergibt Code, Debugging, Tests oder Verifikation an Vega.',
      confidence: 0.84,
    });
  }

  if (looksLikeOperationalTask(message, normalized)) {
    return decision({
      kind: 'queue_vivi_task',
      capability: RESEARCH_PATTERNS.some((pattern) => pattern.test(message)) ? 'web.research' : 'task.queue',
      targetAgent: 'vivi',
      queueAsTask: true,
      shouldStartViviLoop: true,
      summary: 'Vivi-Aufgabe erkannt',
      operatorMessage: 'Vivi antwortet im Chat und legt die Aufgabe zusätzlich in die lokale Arbeitsqueue.',
      confidence: 0.76,
    });
  }

  return decision({
    kind: 'direct_chat',
    capability: 'chat.direct',
    targetAgent: 'vivi',
    queueAsTask: false,
    shouldStartViviLoop: false,
    summary: 'Direkter Vivi-Dialog',
    operatorMessage: 'Normale Dialognachricht. Keine Queue, keine Übergabe, kein Skill-Run nötig.',
    confidence: 0.7,
  });
}

function looksLikeOperationalTask(message: string, normalized: string): boolean {
  if (normalized.length > 700) return true;
  if (/[.!?]\s+[a-zäöüß0-9]/i.test(message) && normalized.length > 220) return true;
  return [
    'analysiere',
    'analyse',
    'audit',
    'baue',
    'bau ',
    'berechne',
    'berichte',
    'erstelle',
    'erzeuge',
    'mach ',
    'plane',
    'prüfe',
    'pruefe',
    'recherchiere',
    'schreibe',
    'starte',
    'suche',
    'teste',
    'ueberpruefe',
    'überprüfe',
    'verifiziere',
  ].some((token) => normalized.includes(token));
}

function isTrivialChatMessage(normalized: string): boolean {
  return [
    'test',
    'ping',
    'hallo',
    'hi',
    'hey',
    'ok',
    'okay',
    'danke',
    'ja',
    'nein',
  ].includes(normalized.trim());
}

function inferDangerousCapability(normalized: string): ViviSkillCapability {
  if (normalized.includes('deploy') || normalized.includes('production') || normalized.includes('prod')) return 'automation.schedule';
  if (normalized.includes('lösch') || normalized.includes('loesch') || normalized.includes('delete') || normalized.includes('remove')) return 'task.queue';
  if (normalized.includes('mail') || normalized.includes('telegram') || normalized.includes('slack') || normalized.includes('sende')) return 'telegram.bridge';
  return 'task.queue';
}

function inferMissingSkillCapability(normalized: string): ViviSkillCapability {
  if (/\b(präsentation|praesentation|präsentationsdeck|praesentationsdeck|slide[-_ ]?deck|slides?|folien|powerpoint|deck)\b/i.test(normalized)) return 'presentation.create';
  if (/\b(docx|dokument|word|pdf|brief|vertrag)\b/i.test(normalized)) return 'document.create';
  if (/\b(spreadsheet|excel|xlsx|csv|tabelle|tabellenanalyse)\b/i.test(normalized)) return 'spreadsheet.analyze';
  if (/\b(bild\s*bearbeiten|image\s*edit|foto\s*bearbeiten|hintergrund\s*entfernen)\b/i.test(normalized)) return 'image.edit';
  if (/\b(recherchiere|suche|lies)\b.*\b(web|internet|online|website|url)\b/i.test(normalized)) return 'web.research';
  return 'skill.propose';
}

function decision(input: Omit<CapabilityRouteDecision, 'targetAgent'> & { targetAgent: AgentId | 'operator' }): CapabilityRouteDecision {
  return input;
}
