import { promises as fs } from 'fs';
import path from 'path';

import { PATHS, WORKSPACE_ROOT } from '../constants/paths';

export interface GitHubSyncDiagnostic {
  checkedAt: string;
  remoteUrl?: string;
  remoteHost?: string;
  remoteType?: 'ssh' | 'https' | 'unknown';
  branch?: string;
  remoteReadOk?: boolean;
  remoteWriteOk?: boolean;
  pushDryRun?: 'ok' | 'failed';
  suggestedFix?: string;
  lastError?: string;
  errors?: string[];
}

export interface GitHubSyncSnapshot {
  schemaVersion: '1.0';
  updatedAt: string;
  branch: string;
  isRepo: boolean;
  remoteConfigured: boolean;
  remoteUrl?: string;
  state: 'healthy' | 'warning' | 'blocked' | 'offline';
  pushReady: 'yes' | 'no' | 'unknown';
  authMode: 'ssh' | 'https' | 'unknown';
  detail: string;
  suggestedFix: string;
  freezeStrategy: string;
  backupRole: string;
  authLastChecked?: string;
  lastError?: string;
}

export async function syncGitHubSyncStatus(): Promise<GitHubSyncSnapshot> {
  const [isRepo, remoteUrl, branch, diagnostic] = await Promise.all([
    hasGitDir(),
    readRemoteUrl(),
    readBranch(),
    safeJson<GitHubSyncDiagnostic>(PATHS.GITHUB_SYNC_DIAGNOSTIC),
  ]);

  let state: GitHubSyncSnapshot['state'] = 'offline';
  let pushReady: GitHubSyncSnapshot['pushReady'] = 'unknown';
  let authMode: GitHubSyncSnapshot['authMode'] = diagnostic?.remoteType || 'unknown';
  let detail = 'No git repository is visible from this workspace.';
  let suggestedFix = diagnostic?.suggestedFix || 'Verify local GitHub authentication before relying on remote sync.';

  if (isRepo && !remoteUrl) {
    state = 'warning';
    detail = 'Local git history exists, but no origin remote is configured.';
    suggestedFix = 'Configure the origin remote before expecting GitHub collaboration or freeze synchronization.';
  } else if (isRepo && remoteUrl) {
    state = 'warning';
    detail = 'Origin exists, but authenticated sync has not been verified from this machine yet.';
    authMode = diagnostic?.remoteType || inferAuthMode(remoteUrl);

    if (diagnostic?.remoteReadOk === true && diagnostic?.remoteWriteOk === true) {
      state = 'healthy';
      pushReady = 'yes';
      detail = 'Remote read/write verification succeeded. Freeze and collaboration sync are ready.';
      suggestedFix = 'No immediate repair is required. Keep freeze snapshots deliberate and continue normal collaboration flow.';
    } else if (diagnostic?.remoteReadOk === true && diagnostic?.remoteWriteOk === false) {
      state = 'blocked';
      pushReady = 'no';
      detail = `Remote read works, but write access is blocked. ${diagnostic.errors?.[0] || 'Fix credentials before relying on GitHub sync.'}`;
      suggestedFix = diagnostic?.suggestedFix || 'Run ./scripts/repair_github_sync.sh with a valid GitHub token, then rerun the sync diagnostic.';
    } else if (diagnostic?.remoteReadOk === false) {
      state = 'blocked';
      pushReady = 'no';
      detail = `Remote read verification failed. ${diagnostic.errors?.[0] || 'Check network or credentials.'}`;
      suggestedFix = diagnostic?.suggestedFix || 'Repair remote reachability or authentication before using GitHub as a trust anchor.';
    }
  }

  const snapshot: GitHubSyncSnapshot = {
    schemaVersion: '1.0',
    updatedAt: new Date().toISOString(),
    branch,
    isRepo,
    remoteConfigured: Boolean(remoteUrl),
    remoteUrl: remoteUrl || undefined,
    state,
    pushReady,
    authMode,
    detail,
    suggestedFix,
    freezeStrategy: 'Freeze final intermediate states in Vivi_Backup. Use LIONCOM for active command work and continuous collaboration state.',
    backupRole: 'Vivi_Backup remains the protected freeze archive. LIONCOM remains the live engineering control repository.',
    authLastChecked: diagnostic?.checkedAt,
    lastError: diagnostic?.lastError,
  };

  await fs.writeFile(PATHS.GITHUB_SYNC_STATUS, renderGitHubStatus(snapshot), 'utf-8');
  return snapshot;
}

async function hasGitDir(): Promise<boolean> {
  try {
    await fs.access(path.join(WORKSPACE_ROOT, '.git'));
    return true;
  } catch {
    return false;
  }
}

async function readBranch(): Promise<string> {
  try {
    const head = await fs.readFile(path.join(WORKSPACE_ROOT, '.git', 'HEAD'), 'utf-8');
    const match = head.match(/ref: refs\/heads\/(\S+)/);
    return match ? match[1] : 'detached';
  } catch {
    return 'unknown';
  }
}

async function readRemoteUrl(): Promise<string | null> {
  try {
    const config = await fs.readFile(path.join(WORKSPACE_ROOT, '.git', 'config'), 'utf-8');
    const remoteBlock = config.match(/\[remote "origin"\]([\s\S]*?)(\n\[|$)/);
    if (!remoteBlock) return null;
    const urlMatch = remoteBlock[1].match(/url\s*=\s*(.+)/);
    return urlMatch?.[1]?.trim() || null;
  } catch {
    return null;
  }
}

function renderGitHubStatus(snapshot: GitHubSyncSnapshot): string {
  return [
    '# GitHub Sync Status',
    '',
    `- Updated: ${snapshot.updatedAt}`,
    `- State: ${snapshot.state}`,
    `- Branch: ${snapshot.branch}`,
    `- Repository Visible: ${snapshot.isRepo ? 'yes' : 'no'}`,
    `- Remote Configured: ${snapshot.remoteConfigured ? 'yes' : 'no'}`,
    `- Remote URL: ${snapshot.remoteUrl || 'none'}`,
    `- Push Ready: ${snapshot.pushReady}`,
    `- Auth Mode: ${snapshot.authMode}`,
    `- Auth Last Checked: ${snapshot.authLastChecked || 'not yet checked from this machine'}`,
    `- Detail: ${snapshot.detail}`,
    `- Suggested Fix: ${snapshot.suggestedFix}`,
    `- Last Error: ${snapshot.lastError || 'none'}`,
    `- Freeze Strategy: ${snapshot.freezeStrategy}`,
    `- Backup Role: ${snapshot.backupRole}`,
    '',
  ].join('\n');
}

function inferAuthMode(remoteUrl: string): GitHubSyncSnapshot['authMode'] {
  if (remoteUrl.startsWith('git@') || remoteUrl.startsWith('ssh://')) return 'ssh';
  if (remoteUrl.startsWith('https://')) return 'https';
  return 'unknown';
}

async function safeJson<T>(filePath: string): Promise<T | null> {
  try {
    return JSON.parse(await fs.readFile(filePath, 'utf-8')) as T;
  } catch {
    return null;
  }
}
