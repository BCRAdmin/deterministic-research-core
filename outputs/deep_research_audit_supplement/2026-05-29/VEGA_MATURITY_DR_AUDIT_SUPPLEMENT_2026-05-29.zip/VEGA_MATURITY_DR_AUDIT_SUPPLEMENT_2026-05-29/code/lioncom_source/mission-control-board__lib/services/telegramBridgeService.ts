import { promises as fs } from 'fs';
import path from 'path';

import { PATHS } from '../constants/paths';
import type { TelegramRelayStatus } from '../control-room/types';
import { appendCodexChatEntry } from './codexBoardService';
import { analyzeOperatorIntent } from './operatorIntentService';
import { appendRailBlock, readRailContent } from './structuredRailService';
import {
  fetchTelegramUpdates,
  loadTelegramCredentials,
  saveTelegramCursor,
  sendTelegramBridgeMessage,
  type TelegramSendResult,
  type TelegramUpdateEnvelope,
} from './telegramService';

const TELEGRAM_INBOX_HEADER = '# Telegram Inbox\n\nInbound mobile packets and commands received through the Telegram bridge.\n\n';
const TELEGRAM_OUTBOX_HEADER = '# Telegram Outbox\n\nOutbound relay packets from LIONCOM for mobile use, alerts and remote operator updates.\n\n';
const TELEGRAM_POLICY_TEMPLATE = `# Telegram Mobile Policy

Stand: 2026-04-15
Ziel: Telegram ist nur mobiler Fallback und Command-Relay, nicht die Hauptarbeitsoberflaeche.

## Erlaubte Mobile Commands

- \/dump <text>: roher Gedanke, landet im Brain Dump
- \/work <text>: neuer Arbeitsauftrag fuer Vivi
- \/research <text>: neue Research-Spur oder Explorationsauftrag
- \/vivi <text>: direkter Vivi-Kommandopaketeingang
- \/codex <text>: direkter Codex-/Board-Auftrag
- \/repair <text>: Rettungs- oder Reparaturpaket
- \/status: kurze operative Lage als mobiler Rueckkanal
- \/help: knappe Telegram-Kommandohilfe

## Mobile Critical Policy

- Nur trust-breaking, sicherheitsrelevante oder operativ blockierende Lagen dürfen als kritisch an den Operator gefunkt werden.
- Wartung, Queue-Druck und Komfortthemen bleiben im Board oder werden fuer Nachtarbeit eingeplant.
- Wenn die Lage kritisch ist, muss der Telegram-Hinweis klar sagen, ob LIONCOM noch sicher nutzbar ist oder ob zuerst Reparatur laufen muss.

## Routing-Regeln

- Mobile Dumps werden niemals still als fertige Aufgaben missverstanden.
- Unklare Signale werden konservativ behandelt und lieber als Dump oder Research eingeordnet.
- Telegram bleibt append-only nachvollziehbar: Inbox fuer Eingang, Outbox fuer Antworten oder Alerts.
`;

export type TelegramRouteMode = 'dump' | 'work' | 'research' | 'vivi' | 'codex' | 'repair' | 'status' | 'help';

export interface TelegramIngressResult {
  ok: boolean;
  inboxEntryId: string;
  route: TelegramRouteMode;
  routedRails: string[];
  summary: string;
  response?: TelegramSendResult;
}

export interface TelegramPollResult {
  ok: boolean;
  processed: number;
  routes: TelegramRouteMode[];
  detail: string;
}

interface ParsedTelegramMessage {
  updateId?: number;
  messageId?: number;
  sender: string;
  chatId?: string;
  sentAt: string;
  rawText: string;
  route: TelegramRouteMode;
  commandToken: [REDACTED]
  body: string;
}

type TelegramSender = NonNullable<NonNullable<TelegramUpdateEnvelope['message']>['from']>;

export async function ensureTelegramMobilePolicy(): Promise<void> {
  try {
    await fs.access(PATHS.TELEGRAM_MOBILE_POLICY);
  } catch {
    await fs.mkdir(path.dirname(PATHS.TELEGRAM_MOBILE_POLICY), { recursive: true });
    await fs.writeFile(PATHS.TELEGRAM_MOBILE_POLICY, TELEGRAM_POLICY_TEMPLATE, 'utf-8');
  }
}

export async function getTelegramRelayStatus(): Promise<TelegramRelayStatus> {
  await ensureTelegramMobilePolicy();
  const [credentials, inboxContent, outboxContent] = await Promise.all([
    loadTelegramCredentials(),
    readRailContent(PATHS.TELEGRAM_INBOX),
    readRailContent(PATHS.TELEGRAM_OUTBOX),
  ]);

  const inboundReady = Boolean(credentials.botToken);
  const outboundReady = Boolean(credentials.botToken && credentials.chatId);
  const inboundCount = countBlocks(inboxContent);
  const outboundCount = countBlocks(outboxContent);

  return {
    inboundReady,
    outboundReady,
    criticalOnly: true,
    detail: inboundReady
      ? `Telegram mobile bridge is armed. ${inboundCount} inbound packet(s), ${outboundCount} outbound packet(s) recorded locally.`
      : 'Telegram mobile bridge is not armed on this machine yet. Local queues still preserve inbound and outbound intent.',
  };
}

export async function ingestTelegramUpdate(update: TelegramUpdateEnvelope, sourceMode: 'webhook' | 'poll' = 'webhook'): Promise<TelegramIngressResult> {
  await ensureTelegramMobilePolicy();
  const parsed = parseTelegramMessage(update);
  const inboxEntryId = buildId('TGI');
  const summary = summarize(parsed.body || parsed.rawText, parsed.commandToken || 'Telegram command');
  const routedRails: string[] = [];

  await appendRailBlock(
    PATHS.TELEGRAM_INBOX,
    TELEGRAM_INBOX_HEADER,
    [
      `### ${inboxEntryId}`,
      `- Added: ${new Date().toISOString()}`,
      `- Source: Telegram ${sourceMode}`,
      '- Status: received',
      `- Title: ${parsed.commandToken || 'telegram message'}`,
      `- Command: ${parsed.route}`,
      `- Sender: ${parsed.sender}`,
      `- Chat: ${parsed.chatId || 'unknown'}`,
      `- Sent At: ${parsed.sentAt}`,
      `- Update: ${parsed.updateId || 'unknown'}`,
      `- Target: ${targetRailLabel(parsed.route)}`,
      `- Summary: ${summary}`,
      '- Message:',
      ...quoteBlock(parsed.rawText),
      '',
    ].join('\n'),
  );

  if (parsed.route === 'status') {
    const response = await replyToTelegram(parsed, 'LIONCOM status', await buildStatusDigest());
    routedRails.push('telegram-outbox');
    return { ok: true, inboxEntryId, route: parsed.route, routedRails, summary, response };
  }

  if (parsed.route === 'help') {
    const response = await replyToTelegram(parsed, 'LIONCOM mobile commands', buildHelpDigest());
    routedRails.push('telegram-outbox');
    return { ok: true, inboxEntryId, route: parsed.route, routedRails, summary, response };
  }

  if (parsed.route === 'dump') {
    await appendBrainDumpFromTelegram(parsed, inboxEntryId);
    routedRails.push('brain-dump');
  }

  if (parsed.route === 'work' || parsed.route === 'research') {
    await appendWorkIntakeFromTelegram(parsed, inboxEntryId, parsed.route === 'research' ? 'explore' : 'normal');
    routedRails.push('work-intake');
  }

  if (parsed.route === 'vivi') {
    await appendViviCommandFromTelegram(parsed, inboxEntryId);
    routedRails.push('vivi-command', 'work-intake');
  }

  if (parsed.route === 'codex') {
    await appendCodexCommandFromTelegram(parsed, inboxEntryId);
    routedRails.push('codex-chat', 'codex-inbox');
  }

  if (parsed.route === 'repair') {
    await appendRepairPacketFromTelegram(parsed, inboxEntryId);
    routedRails.push('repair-queue');
  }

  const response = await replyToTelegram(
    parsed,
    'Telegram packet accepted',
    `Accepted as *${parsed.route}* and routed to ${routedRails.join(', ')}. Reference: ${inboxEntryId}.`,
    'normal',
  );

  if (response.status !== 'failed' || response.detail) {
    routedRails.push('telegram-outbox');
  }

  return {
    ok: true,
    inboxEntryId,
    route: parsed.route,
    routedRails,
    summary,
    response,
  };
}

export async function pollTelegramBridge(limit = 20): Promise<TelegramPollResult> {
  await ensureTelegramMobilePolicy();
  const fetched = await fetchTelegramUpdates(limit);
  if (!fetched.ok) {
    return {
      ok: false,
      processed: 0,
      routes: [],
      detail: fetched.detail,
    };
  }

  const routes: TelegramRouteMode[] = [];
  for (const update of fetched.updates) {
    const result = await ingestTelegramUpdate(update, 'poll');
    routes.push(result.route);
  }

  await saveTelegramCursor(fetched.lastUpdateId);

  return {
    ok: true,
    processed: fetched.updates.length,
    routes,
    detail: fetched.detail,
  };
}

function parseTelegramMessage(update: TelegramUpdateEnvelope): ParsedTelegramMessage {
  const message = update.message;
  const rawText = message?.text?.trim();
  if (!rawText) {
    throw new Error('Telegram update does not contain a text message.');
  }

  const { route, commandToken, body } = splitTelegramCommand(rawText);
  return {
    updateId: update.update_id,
    messageId: message?.message_id,
    sender: buildSenderLabel(message?.from),
    chatId: message?.chat?.id !== undefined ? String(message.chat.id) : undefined,
    sentAt: message?.date ? new Date(message.date * 1000).toISOString() : new Date().toISOString(),
    rawText,
    route,
    commandToken,
    body,
  };
}

function splitTelegramCommand(rawText: string): { route: TelegramRouteMode; commandToken: string; body: string } {
  const trimmed = rawText.trim();
  if (!trimmed.startsWith('/')) {
    return {
      route: 'dump',
      commandToken: [REDACTED]
      body: trimmed,
    };
  }

  const [firstLine, ...restLines] = trimmed.split('\n');
  const [rawCommand, ...inlineParts] = firstLine.trim().split(/\s+/);
  const body = [...inlineParts, ...restLines].join('\n').trim();
  const command = rawCommand.replace(/^\//, '').replace(/@.*$/, '').toLowerCase();

  if (['dump', 'brain', 'idea'].includes(command)) return { route: 'dump', commandToken: rawCommand, body };
  if (['work', 'task'].includes(command)) return { route: 'work', commandToken: rawCommand, body };
  if (['research', 'explore'].includes(command)) return { route: 'research', commandToken: rawCommand, body };
  if (command === 'vivi') return { route: 'vivi', commandToken: rawCommand, body };
  if (command === 'codex') return { route: 'codex', commandToken: rawCommand, body };
  if (['repair', 'fix', 'rescue'].includes(command)) return { route: 'repair', commandToken: rawCommand, body };
  if (command === 'status') return { route: 'status', commandToken: rawCommand, body };
  if (command === 'help') return { route: 'help', commandToken: rawCommand, body };

  return { route: 'dump', commandToken: rawCommand, body: trimmed };
}

async function appendBrainDumpFromTelegram(parsed: ParsedTelegramMessage, reference: string): Promise<void> {
  const entryId = buildId('IDEA');
  const summary = summarize(parsed.body, 'Telegram mobile dump');
  const interpretation = renderInterpretationLines({
    sourceRail: 'brain-dump',
    summary,
    rawText: parsed.body,
    context: `Telegram mobile dump / ${parsed.sender}`,
  });

  await appendRailBlock(
    PATHS.BRAIN_DUMP,
    '# Brain Dump\n\nAppend-only memory rail for raw ideas, sparks and half-formed requests from Control Room.\n\n',
    [
      `### ${entryId}`,
      `- Added: ${new Date().toISOString()}`,
      '- Source: Telegram Mobile Bridge',
      '- Status: raw',
      `- Summary: ${summary}`,
      `- Context: Telegram /dump from ${parsed.sender}`,
      `- Reference: ${reference}`,
      interpretation,
      '- Raw Input:',
      ...quoteBlock(parsed.body || parsed.rawText),
      '',
    ].join('\n'),
  );
}

async function appendWorkIntakeFromTelegram(parsed: ParsedTelegramMessage, reference: string, urgency: 'normal' | 'explore'): Promise<void> {
  const entryId = buildId('WRK');
  const title = deriveTitle(parsed.body, parsed.route === 'research' ? 'Telegram research request' : 'Telegram work request');
  const summary = summarize(parsed.body, title);
  const interpretation = renderInterpretationLines({
    sourceRail: 'work-intake',
    title,
    summary,
    rawText: parsed.body,
    desiredOutcome: parsed.route === 'research' ? 'Clarify whether this should become a new project or a research track.' : 'Turn this mobile request into executable work.',
    priority: urgency,
  });

  await appendRailBlock(
    PATHS.WORK_INTAKE,
    '# Work Intake\n\nControlled queue for requests that Vivi should interpret, split into work blocks and turn into concrete subtasks.\n\n',
    [
      `### ${entryId}`,
      `- Added: ${new Date().toISOString()}`,
      '- Source: Telegram Mobile Bridge',
      '- Status: new',
      `- Urgency: ${urgency}`,
      `- Title: ${title}`,
      `- Desired Outcome: ${parsed.route === 'research' ? 'Run targeted research before execution.' : 'Translate this request into tracked execution.'}`,
      `- Reference: ${reference}`,
      `- Summary: ${summary}`,
      interpretation,
      '- Raw Request:',
      ...quoteBlock(parsed.body || parsed.rawText),
      '',
    ].join('\n'),
  );
}

async function appendViviCommandFromTelegram(parsed: ParsedTelegramMessage, reference: string): Promise<void> {
  const entryId = buildId('VIVI');
  const title = deriveTitle(parsed.body, 'Telegram command for Vivi');
  const summary = summarize(parsed.body, title);
  const interpretation = renderInterpretationLines({
    sourceRail: 'vivi-command',
    title,
    summary,
    rawText: parsed.body,
    context: `Telegram /vivi from ${parsed.sender}`,
    desiredOutcome: 'Execute safely and report back through LIONCOM.',
    priority: 'high',
  });

  await appendRailBlock(
    PATHS.VIVI_COMMAND_QUEUE,
    '# Vivi Command Queue\n\nDirect mission packets for Vivi that require immediate structured execution or routing.\n\n',
    [
      `### ${entryId}`,
      `- Added: ${new Date().toISOString()}`,
      '- Source: Telegram Mobile Bridge',
      '- Status: queued',
      '- Priority: high',
      `- Title: ${title}`,
      `- Target: Vivi` ,
      `- Reference: ${reference}`,
      `- Summary: ${summary}`,
      interpretation,
      '- Raw Request:',
      ...quoteBlock(parsed.body || parsed.rawText),
      '',
    ].join('\n'),
  );

  await appendWorkIntakeFromTelegram(parsed, entryId, 'normal');
}

async function appendCodexCommandFromTelegram(parsed: ParsedTelegramMessage, reference: string): Promise<void> {
  const title = deriveTitle(parsed.body, 'Telegram command for Codex');
  const summary = summarize(parsed.body, title);
  const interpretation = renderInterpretationLines({
    sourceRail: 'codex-command',
    title,
    summary,
    rawText: parsed.body,
    context: `Telegram /codex from ${parsed.sender}`,
    priority: 'high',
  });
  const chatEntry = await appendCodexChatEntry({
    role: 'operator',
    status: 'new',
    message: parsed.body || parsed.rawText,
    summary,
    source: 'Telegram Mobile Bridge',
    reference,
  });

  await appendRailBlock(
    PATHS.CODEX_INBOX,
    '# Codex Inbox\n\nLocal command packets prepared for Codex-side implementation, review or debugging work.\n\n',
    [
      `### ${buildId('CDX')}`,
      `- Added: ${new Date().toISOString()}`,
      '- Source: Telegram Mobile Bridge',
      '- Status: queued',
      '- Priority: high',
      `- Title: ${title}`,
      '- Context: Mobile Codex escalation',
      `- Reference: ${chatEntry.id}`,
      `- Summary: ${summary}`,
      interpretation,
      '- Raw Request:',
      ...quoteBlock(parsed.body || parsed.rawText),
      '',
    ].join('\n'),
  );
}

async function appendRepairPacketFromTelegram(parsed: ParsedTelegramMessage, reference: string): Promise<void> {
  const entryId = buildId('RPR');
  const title = deriveTitle(parsed.body, 'Telegram repair request');
  const summary = summarize(parsed.body, title);

  await appendRailBlock(
    PATHS.REPAIR_QUEUE,
    '# Repair Queue\n\nStructured rescue and stabilization packets for Vivi when the operator sees breakage or trust issues.\n\n',
    [
      `### ${entryId}`,
      `- Added: ${new Date().toISOString()}`,
      '- Source: Telegram Mobile Bridge',
      '- Status: queued',
      '- Priority: high',
      `- Title: ${title}`,
      '- Target: Vivi repair rail',
      `- Reference: ${reference}`,
      `- Summary: ${summary}`,
      '- Message:',
      ...quoteBlock(parsed.body || parsed.rawText),
      '',
    ].join('\n'),
  );
}

async function replyToTelegram(
  parsed: ParsedTelegramMessage,
  title: string,
  message: string,
  priority = 'briefing',
): Promise<TelegramSendResult> {
  const delivery = await sendTelegramBridgeMessage({
    title,
    message,
    priority,
    targetChatId: parsed.chatId,
  });

  await appendRailBlock(
    PATHS.TELEGRAM_OUTBOX,
    TELEGRAM_OUTBOX_HEADER,
    [
      `### ${buildId('TG')}`,
      `- Added: ${new Date().toISOString()}`,
      '- Source: Telegram Mobile Bridge',
      `- Status: ${delivery.status}`,
      `- Priority: ${priority}`,
      `- Title: ${title}`,
      `- Target: ${parsed.chatId || 'Telegram'}`,
      `- Delivery: ${delivery.status}`,
      `- Summary: ${summarize(message, title)}`,
      `- Delivery Detail: ${delivery.detail}`,
      '- Message:',
      ...quoteBlock(message),
      '',
    ].join('\n'),
  );

  return delivery;
}

async function buildStatusDigest(): Promise<string> {
  const [runtime, state, workEngine, remoteBridge, githubSync] = await Promise.all([
    safeJson<{ mission?: { phase?: string; state?: string; progress?: number; currentAction?: string; nextAction?: string }; runtime?: { responsive?: boolean; heartbeatAt?: string } }>(PATHS.VIVI_RUNTIME),
    safeJson<{ currentState?: string; transitionReason?: string }>(PATHS.VIVI_STATE),
    safeJson<{ roadmap?: { focus?: string }; blocks?: Array<{ title?: string; active?: boolean }> }>(PATHS.WORK_ENGINE_STATE),
    safeJson<{ state?: string; detail?: string }>(PATHS.REMOTE_BRIDGE_STATUS),
    safeJson<{ state?: string; pushReady?: string; detail?: string }>(PATHS.GITHUB_SYNC_DIAGNOSTIC),
  ]);

  const activeBlocks = workEngine?.blocks?.filter((block) => block.active).length || 0;
  return [
    `State: ${state?.currentState || runtime?.mission?.state || 'unknown'}`,
    `Phase: ${runtime?.mission?.phase || 'unknown'} / ${runtime?.mission?.progress ?? 'n/a'}%`,
    `Action: ${runtime?.mission?.currentAction || 'none visible'}`,
    `Next: ${runtime?.mission?.nextAction || workEngine?.roadmap?.focus || 'no guided next step yet'}`,
    `Remote bridge: ${remoteBridge?.state || 'unknown'}${remoteBridge?.detail ? ` (${remoteBridge.detail})` : ''}`,
    `GitHub sync: ${githubSync?.state || 'unknown'}${githubSync?.pushReady ? ` / push ${githubSync.pushReady}` : ''}`,
    `Active blocks: ${activeBlocks}`,
    `Heartbeat: ${runtime?.runtime?.heartbeatAt || 'none visible'}`,
  ].join('\n');
}

function buildHelpDigest(): string {
  return [
    'Use one of these commands:',
    '/dump <raw thought>',
    '/work <new work request>',
    '/research <new idea or research seed>',
    '/vivi <direct Vivi command>',
    '/codex <direct Codex command>',
    '/repair <repair or rescue issue>',
    '/status',
  ].join('\n');
}

function deriveTitle(body: string, fallback: string): string {
  const compact = body.replace(/\s+/g, ' ').trim();
  if (!compact) return fallback;
  const firstChunk = compact.split(/[.!?]/)[0]?.trim() || compact;
  return firstChunk.slice(0, 72);
}

function buildSenderLabel(sender?: TelegramSender): string {
  if (!sender) return 'unknown';
  return [sender.first_name, sender.last_name].filter(Boolean).join(' ').trim()
    || sender.username
    || String(sender.id || 'unknown');
}

function targetRailLabel(route: TelegramRouteMode): string {
  if (route === 'dump') return 'BRAIN_DUMP';
  if (route === 'work' || route === 'research') return 'WORK_INTAKE';
  if (route === 'vivi') return 'VIVI_COMMAND_QUEUE';
  if (route === 'codex') return 'CODEX_CHAT_THREAD + CODEX_INBOX';
  if (route === 'repair') return 'REPAIR_QUEUE';
  return 'TELEGRAM_OUTBOX';
}

function buildId(prefix: string): string {
  const iso = new Date().toISOString();
  const stamp = iso.replace(/[-:TZ]/g, '').replace('.', '').slice(0, 17);
  const entropy = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `${prefix}-${stamp}-${entropy}`;
}

function summarize(value: string, fallback: string): string {
  const compact = value.replace(/\s+/g, ' ').trim();
  if (!compact) return fallback;
  return compact.slice(0, 180);
}

function quoteBlock(value: string): string[] {
  return value.split('\n').map((line) => `> ${line}`);
}

function renderInterpretationLines(input: {
  sourceRail: 'work-intake' | 'brain-dump' | 'repair-queue' | 'vivi-command' | 'codex-command' | 'codex-chat';
  title?: string;
  summary?: string;
  rawText?: string;
  context?: string;
  desiredOutcome?: string;
  priority?: string;
}): string {
  const analysis = analyzeOperatorIntent(input);
  return [
    `- Intent: ${analysis.intent}`,
    `- Project Fit: ${analysis.projectFit}`,
    `- Research Mode: ${analysis.researchMode}`,
    `- Operator Mode: ${analysis.operatorMode}`,
    `- Priority Hint: ${analysis.priorityHint}`,
    `- Interpretation Hint: ${analysis.interpretationHint}`,
    analysis.researchPrompt ? `- Research Prompt: ${analysis.researchPrompt}` : null,
    `- Routing Note: ${analysis.routingNote}`,
  ].filter(Boolean).join('\n');
}

async function safeJson<T>(filePath: string): Promise<T | null> {
  try {
    return JSON.parse(await fs.readFile(filePath, 'utf-8')) as T;
  } catch {
    return null;
  }
}

function countBlocks(content: string | null): number {
  if (!content) return 0;
  return (content.match(/^###\s+/gm) || []).length;
}
