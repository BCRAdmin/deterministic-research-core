export type AgentId = 'vivi' | 'vega';
export type AgentAccent = 'vivi' | 'vega';
export type AgentStatus = 'active' | 'ready' | 'busy' | 'warning';
export type ProviderMode = 'local' | 'cloud';
export type ControlPlaneView = 'overview' | 'vivi' | 'vega' | 'portfolio' | 'dispatch' | 'missions' | 'telemetry' | 'backlog' | 'audit';
export type Priority = 'low' | 'normal' | 'high' | 'critical';
export type Severity = 'info' | 'success' | 'warning' | 'critical';
export type AlertActionPath = 'analyse' | 'reparatur' | 'nachtfix' | 'beobachten' | 'operator_gate';

export interface OperatorInfo {
  title: string;
  body: string;
  tone?: Severity;
  actionLabel?: string;
}

export interface OperatorLoopStatus {
  state: 'running' | 'busy' | 'ready' | 'blocked' | 'warning' | 'offline';
  tone: Severity;
  title: string;
  summary: string;
  detail: string;
  nextAction: string;
  claimId?: string;
  taskTitle?: string;
  taskReference?: string;
  lastHeartbeat?: string;
  modelProvider?: string;
  modelName?: string;
  qualityGate: {
    label: string;
    ok: boolean;
    checkedAt?: string;
    failureId?: string;
    failureDetail?: string;
  };
  primaryActionLabel: string;
}

export interface Metric {
  id: string;
  label: string;
  value: string;
  detail: string;
  trend?: string;
  tone?: 'good' | 'warning' | 'danger' | 'neutral';
  sparkline?: number[];
}

export interface Agent {
  id: AgentId;
  name: string;
  label: string;
  role: string;
  accent: AgentAccent;
  status: AgentStatus;
  description: string;
  metrics: Metric[];
  focus: string[];
  identity: {
    status: string;
    uptime: string;
    lastSync: string;
    linkLabel: string;
    health: string;
  };
}

export interface Workspace {
  id: string;
  agentId: AgentId;
  title: string;
  status: string;
  unreadCount?: number;
  updatedAt: string;
  description: string;
}

export interface ChatMessage {
  id: string;
  agentId: AgentId;
  sender: 'operator' | 'vivi' | 'vega' | 'system';
  time: string;
  body: string;
  status?: 'sent' | 'queued' | 'read';
}

export interface AutomationTask {
  id: string;
  agentId: AgentId;
  title: string;
  description: string;
  status: 'active' | 'paused' | 'warning';
}

export interface QueueItem {
  id: string;
  agentId: AgentId;
  title: string;
  type: string;
  priority: Priority;
  status: string;
  updatedAt: string;
  progress?: number;
}

export interface RuntimeProfile {
  agentId: AgentId;
  providerMode: ProviderMode;
  provider: string;
  model: string;
  requestedProvider?: string;
  requestedModel?: string;
  effectiveProvider?: string;
  effectiveModel?: string;
  contextWindow: string;
  fallbackModel: string;
  latency: string;
  lastSync: string;
  status: string;
  modelDetail?: string;
  modelLastError?: string | null;
  tools: string[];
  workspace: {
    repo: string;
    path: string;
    branch: string;
    lastSync: string;
  };
}

export interface ActivitySignal {
  id: string;
  agentId: AgentId;
  time: string;
  actor: string;
  label: string;
  detail: string;
  type: string;
}

export interface Handoff {
  id: string;
  sourceAgentId: AgentId;
  targetAgentId: AgentId;
  title: string;
  detail: string;
  status: string;
  actionLabel: string;
}

export interface IntakeRow {
  id: string;
  agentId: AgentId;
  title: string;
  status: string;
  priority: 'normal' | 'high' | 'critical';
  updatedAt: string;
}

export interface VerificationItem {
  id: string;
  agentId: AgentId;
  title: string;
  status: 'waiting' | 'passed' | 'failed';
  priority: 'normal' | 'high' | 'critical';
  duration: string;
}

export interface RepoSnapshot {
  agentId: AgentId;
  branch: string;
  lastCommit: string;
  commitMessage: string;
  author: string;
  changedFiles: Array<{
    path: string;
    additions: number;
    deletions: number;
  }>;
  reviewTarget: string;
}

export interface PortfolioRepositoryStatus {
  id: string;
  repo: string;
  product: string;
  githubUrl: string;
  localPath: string;
  branch: string;
  lastKnownSha: string;
  lifecycle: 'active' | 'archived';
  ciStatus: 'green' | 'yellow' | 'red' | 'not_applicable';
  e2eStatus: 'green' | 'yellow' | 'red' | 'not_applicable';
  dependabotStatus: 'active' | 'not_applicable';
  branchProtectionStatus: 'blocked_plan_or_public_required' | 'not_applicable';
  secretScanningStatus: [REDACTED]
  risk: 'green' | 'yellow' | 'red';
  requiredChecks: string[];
  publicGate: 'operator_gated' | 'blocked' | 'not_applicable';
  nextAction: string;
}

export interface PortfolioExecutionContract {
  id: string;
  status: 'canonical';
  version: string;
  effectiveFrom: string;
  contractDocPath: string;
  roleRegistryDocPath: string;
  githubDocUrl: string;
  githubRoleRegistryUrl: string;
  verifier: string;
  handoffRule: string;
  truthHierarchy: string[];
  governanceSubjects: string[];
  operatorGoScope: string[];
  noGoScope: string[];
}

export type PortfolioMetricCardId =
  | 'utility-revenue-funnel'
  | 'trust-rule-coverage'
  | 'membership-readiness'
  | 'review-queue'
  | 'outcome-horizons'
  | 'opportunity-backlog'
  | 'maintenance-governance';

export type PortfolioStreamId =
  | 'materialbedarf.measurement'
  | 'elterngeld.trust'
  | 'membership.launchReadiness'
  | 'room16.review'
  | 'deterministic.outcomes'
  | 'microtool.opportunities'
  | 'github.planBlocked'
  | 'generatedStatePolicy';

export type PortfolioMetricStatus = 'active' | 'watching' | 'placeholder' | 'blocked';

export interface PortfolioMetricSignal {
  label: string;
  value: string;
  detail: string;
  tone?: Severity;
}

export interface PortfolioStreamMetric {
  id: PortfolioStreamId;
  cardId: PortfolioMetricCardId;
  title: string;
  repo: string;
  product: string;
  localPath: string;
  lastKnownCommit: string;
  status: PortfolioMetricStatus;
  health: Severity;
  verifier: string;
  remoteCi?: string;
  evidence: string;
  productionGo: boolean;
  publicReady: boolean;
  researchStream: boolean;
  generatedStatePolicy: 'do_not_commit' | 'not_applicable';
  branchProtectionStatus: 'blocked_plan_or_public_required' | 'not_applicable';
  secretScanningStatus: [REDACTED]
  signals: PortfolioMetricSignal[];
  gates: string[];
  nextAction: string;
}

export type PortfolioReviewStreamGroup =
  | 'materialbedarf'
  | 'elterngeld'
  | 'membership'
  | 'room16'
  | 'deterministic'
  | 'microtool'
  | 'maintenance';

export type PortfolioReviewStatus = 'scheduled' | 'waiting_for_data' | 'maintenance_due' | 'blocked';

export interface PortfolioReviewCalendarItem {
  id: string;
  streamId: PortfolioStreamId;
  streamGroup: PortfolioReviewStreamGroup;
  streamLabel: string;
  reviewLabel: string;
  dueDate: string;
  windowLabel: string;
  status: PortfolioReviewStatus;
  expectedData: string[];
  decisionGate: string;
  operatorGate: string;
  noDataStatus: string;
  productionGo: false;
  publicReady: false;
  researchAutoPublish: false;
  affiliateAutoGo: false;
  trustBypass: false;
}

export interface PlanningQualitySurface {
  generated_at: string;
  status: 'PASS' | 'WARN' | 'FAIL' | string;
  source: string;
  surface_version?: string;
  control_capabilities?: {
    approval_actions?: boolean;
    pause_resume_retry?: boolean;
    multi_run_history?: boolean;
    fresh_session_handoff?: boolean;
    long_run_completion_audit?: boolean;
    rule_propagation_audit?: boolean;
    operator_intent_contract?: boolean;
    impact_radius_assessment?: boolean;
    autonomy_governor?: boolean;
    vivi_vega_handoff_inbox?: boolean;
    fresh_session_readiness?: boolean;
    fresh_data_intake?: boolean;
    vivi_job_card_queue?: boolean;
    vivi_runner_mvp?: boolean;
    vivi_supervisor_audit?: boolean;
    commit_cleanup_go_package?: boolean;
    vivi_worker_mvp?: boolean;
    vivi_worker_supervisor_audit?: boolean;
    endgame_roadmap?: boolean;
    autonomy_soak_audit?: boolean;
    vivi_capability_matrix?: boolean;
    capability_registry?: boolean;
    capability_telemetry?: boolean;
    agentization_decision_gate?: boolean;
    agent_product_maturity_contract?: boolean;
    shannon_security_sandbox_contract?: boolean;
    fresh_session_context_budget?: boolean;
    background_quality_gates?: boolean;
    project_vertical_rollout?: boolean;
    launch_readiness_package?: boolean;
    openjarvis_capability_lab?: boolean;
    openjarvis_capability_arena?: boolean;
    openjarvis_decision_gauntlet?: boolean;
    openjarvis_component_adapter?: boolean;
    runtime_dependency?: string;
    n8n_runtime?: boolean;
  };
  active_build_contracts: Array<{
    contract_id?: string;
    status?: string;
    operator_goal?: string;
    target_picture?: string;
    archetype?: string;
    cross_project_effect?: string;
  }>;
  needs_target_picture: Array<{
    contract_id?: string;
    operator_goal?: string;
  }>;
  approval_nodes: Array<{
    contract_id?: string;
    id?: string;
    label?: string;
    status?: string;
    reason?: string;
  }>;
  workflow_runs: Array<{
    run_id?: string;
    status?: string;
    current_step?: string;
    started_at?: string;
    completed_at?: string | null;
    control_state?: string;
    retry_count?: number;
    has_operator_actions?: boolean;
  }>;
  operator_actions?: Array<{
    action_id?: string;
    action_type?: string;
    contract_id?: string;
    approval_node?: string;
    label?: string;
    status?: string;
    allowed_when?: string;
    blocked_when?: string;
    operator_gate_required?: boolean;
    runtime_effect?: string;
  }>;
  run_controls?: Array<{
    control?: string;
    status?: string;
    operator_gate_required?: boolean | string;
    runtime_effect?: string;
  }>;
  fresh_session_handoff?: {
    status?: string;
    path?: string;
    latest_run?: string;
    next_safe_step?: string;
    reading_order?: string[];
  };
  last_verifier: {
    command?: string;
    name?: string;
    status?: string;
  };
  governance?: {
    overall?: string;
    implementation_status?: string;
    coverage_status?: string;
    operator_risk_status?: string;
    policy_gate_status?: string;
    decisions_status?: string;
    unresolved_decisions?: number;
    coverage_gaps?: number;
    active_high_risk_automations?: number;
    guardrail_policy_gates?: number;
    memory_promotion_batches?: number;
    complete_context_items?: number;
    long_run_completion_status?: string;
    vault_umlaut_hygiene_status?: string;
    skill_policy_regression_guard_status?: string;
    rule_propagation_status?: string;
    project_invariant_status?: string;
    agent_entrypoint_status?: string;
    operator_intent_contract_status?: string;
    impact_radius_status?: string;
    autonomy_governor_status?: string;
    autonomy_state?: string;
    autonomy_safe_work_remaining?: number;
    autonomy_dirt_backlog_scan_status?: string;
    autonomy_dirty_project_count?: number;
    autonomy_dirt_handoff_card_count?: number;
    autonomy_dirt_verifier_executed_count?: number;
    autonomy_dirt_verifier_pass_count?: number;
    autonomy_dirt_verifier_fail_count?: number;
    autonomy_dirt_verifier_planned_count?: number;
    vivi_vega_handoff_inbox_status?: string;
    vivi_vega_handoff_action_items?: number;
    vivi_needs_vega_review_count?: number;
    vivi_operator_gate_count?: number;
    vivi_needs_verifier_count?: number;
    fresh_session_readiness_status?: string;
    fresh_session_readiness_warnings?: number;
    fresh_data_intake_status?: string;
    fresh_data_fresh_items?: number;
    fresh_data_action_items?: number;
    fresh_data_operator_gates?: number;
    fresh_data_needs_review?: number;
    vivi_job_card_queue_status?: string;
    vivi_job_card_count?: number;
    vivi_job_cards_ready?: number;
    vivi_runner_status?: string;
    vivi_runner_last_job_card?: string;
    vivi_runner_runtime_action_executed?: boolean;
    vivi_supervisor_status?: string;
    vivi_supervisor_truth_status?: string;
    vivi_supervisor_findings?: number;
    commit_cleanup_go_package_status?: string;
    commit_cleanup_go_package_decisions?: number;
    commit_cleanup_go_runtime_action_executed?: boolean | null;
    endgame_roadmap_status?: string;
    endgame_roadmap_completion_percent?: number;
    endgame_foundation_completion_percent?: number;
    endgame_macro_completion_percent?: number;
    endgame_current_phase?: string;
    endgame_safe_next_blocks?: number;
    vivi_worker_queue_status?: string;
    vivi_worker_ready_count?: number;
    vivi_worker_status?: string;
    vivi_worker_runtime_action_executed?: boolean | null;
    vivi_worker_supervisor_status?: string;
    vivi_worker_supervisor_truth_status?: string;
    capability_registry_status?: string;
    capability_registry_record_count?: number;
    capability_registry_agent_count?: number;
    capability_registry_fail_count?: number;
    capability_telemetry_status?: string;
    capability_telemetry_usage_total?: number;
    capability_telemetry_verified_value_total?: number;
    capability_telemetry_risk_blocked_total?: number;
    capability_telemetry_better_document_total?: number;
    capability_telemetry_verified_surface_total?: number;
    capability_telemetry_agent_candidate_count?: number;
    agentization_decision_gate_status?: string;
    agentization_candidate_agent_count?: number;
    agentization_approved_agent_count?: number;
    agentization_stay_capability_count?: number;
    agent_product_maturity_contract_status?: string;
    agent_product_candidate_count?: number;
    agent_product_ready_count?: number;
    shannon_security_sandbox_status?: string;
    shannon_security_sandbox_fail_count?: number;
    shannon_security_sandbox_runtime_action_executed?: boolean | null;
    fresh_session_context_budget_status?: string;
    fresh_session_context_budget_task_count?: number;
    fresh_session_context_budget_fail_count?: number;
    background_quality_gates_status?: string;
    background_quality_gates_gate_count?: number;
    background_quality_gates_fail_count?: number;
    openjarvis_capability_lab_status?: string;
    openjarvis_source_documents?: number;
    openjarvis_retrieval_status?: string;
    openjarvis_retrieval_pass_count?: number;
    openjarvis_retrieval_question_count?: number;
    openjarvis_code_qa_status?: string;
    openjarvis_runtime_available?: boolean;
    openjarvis_runtime_action_executed?: boolean | null;
    openjarvis_capability_arena_status?: string;
    openjarvis_arena_task_count?: number;
    openjarvis_arena_shadow_pass_count?: number;
    openjarvis_arena_shadow_fail_count?: number;
    openjarvis_arena_shadow_wins?: number;
    openjarvis_arena_baseline_wins?: number;
    openjarvis_arena_ties?: number;
    openjarvis_decision_gauntlet_status?: string;
    openjarvis_decision_status?: string;
    openjarvis_decision_test_count?: number;
    openjarvis_decision_fail_count?: number;
    openjarvis_decision_operator_gate_count?: number;
    openjarvis_component_adapter_status?: string;
    openjarvis_component_count?: number;
    openjarvis_component_adapt_ready_count?: number;
    openjarvis_component_gated_ready_count?: number;
    openjarvis_component_rejected_current_count?: number;
  };
  systemwide_rule_propagation?: {
    status?: string;
    autonomy_governor?: {
      status?: string;
      autonomy_state?: string;
      safe_work_remaining?: boolean;
      next_safe_steps?: Array<{
        workstream_id?: string;
        priority?: string;
        next_safe_step?: string;
      }>;
      blocked_gates?: Array<{
        workstream_id?: string;
        priority?: string;
        operator_gates?: string[];
        next_safe_step?: string;
      }>;
    };
    autonomy_dirt_backlog_scan?: {
      status?: string;
      dirty_project_count?: number;
      handoff_card_count?: number;
      handoff_decision_queue_status?: string;
      handoff_safe_queue_count?: number;
      handoff_operator_gate_queue_count?: number;
      verifier_executed_count?: number;
      verifier_pass_count?: number;
      verifier_fail_count?: number;
      verifier_planned_count?: number;
      path?: string;
      safe_next_actions?: string[];
      next_safe_review?: {
        queue_id?: string;
        card_id?: string;
        project_id?: string;
        ownership?: string;
        count?: number;
        priority?: string;
        decision_type?: string;
        status?: string;
        operator_gate_required?: boolean;
        safe_review_step?: string;
        done_definition?: string;
        evidence_required?: string[];
        recommended_verifiers?: string[];
        sample_paths?: string[];
      };
      safe_work_queue?: Array<{
        queue_id?: string;
        card_id?: string;
        project_id?: string;
        ownership?: string;
        count?: number;
        priority?: string;
        decision_type?: string;
        status?: string;
        safe_review_step?: string;
        done_definition?: string;
      }>;
      operator_gate_queue?: Array<{
        queue_id?: string;
        card_id?: string;
        project_id?: string;
        ownership?: string;
        count?: number;
        priority?: string;
        decision_type?: string;
        status?: string;
        safe_review_step?: string;
      }>;
      handoff_cards?: Array<{
        card_id?: string;
        project_id?: string;
        ownership?: string;
        count?: number;
        sample_paths?: string[];
        recommended_action?: string;
        recommended_verifiers?: string[];
        operator_gate_required?: boolean;
        forbidden_without_operator_go?: string[];
      }>;
    };
    commit_cleanup_go_package?: {
      status?: string;
      package_id?: string;
      runtime_action_executed?: boolean | null;
      summary?: {
        project_count?: number;
        dirty_project_count?: number;
        decision_card_count?: number;
        reviewed_queue_count?: number;
        safe_queue_count?: number;
        operator_gate_queue_count?: number;
        dirt_queue_status?: string;
      };
      allowed_operator_decisions?: string[];
      forbidden_without_operator_go?: string[];
      project_packages?: Array<{
        project_id?: string;
        path?: string;
        role?: string;
        git_status?: string;
        changed_count?: number;
        reviewed_decision_ids?: string[];
        safe_review_decision_ids?: string[];
        operator_gate_decision_ids?: string[];
        suggested_batches?: Array<{
          batch_id?: string;
          ownership?: string;
          count?: number;
          status?: string;
          decision_ids?: string[];
          operator_go_required?: boolean;
        }>;
      }>;
      decision_cards?: Array<{
        decision_id?: string;
        project_id?: string;
        ownership?: string;
        decision_type?: string;
        priority?: string;
        status?: string;
        count?: number;
        operator_gate_required?: boolean;
        recommended_operator_decision?: string;
        next_safe_step?: string;
        recommended_verifiers?: string[];
      }>;
      path?: string;
      next_safe_step?: string;
    };
    vivi_vega_handoff_inbox?: {
      status?: string;
      action_item_count?: number;
      needs_vega_review_count?: number;
      operator_gate_count?: number;
      needs_verifier_count?: number;
      path?: string;
      action_items?: Array<{
        item_id?: string;
        source_kind?: string;
        classification?: string;
        title?: string;
        summary?: string;
        command_ref?: string;
        status?: string;
        operator_gate_required?: boolean;
        next_safe_step?: string;
        recommended_verifiers?: string[];
      }>;
    };
    fresh_session_readiness?: {
      status?: string;
      targets_checked?: number;
      warning_count?: number;
      fail_count?: number;
      warnings?: Array<{
        target_id?: string;
        status?: string;
        missing_fields?: string[];
        summary?: string;
      }>;
    };
    fresh_data_intake?: {
      status?: string;
      fresh_item_count?: number;
      action_item_count?: number;
      operator_gate_count?: number;
      needs_review_count?: number;
      needs_verifier_count?: number;
      path?: string;
      action_items?: Array<{
        item_id?: string;
        project_id?: string;
        artifact_kind?: string;
        classification?: string;
        priority?: string;
        summary?: string;
        next_safe_step?: string;
        operator_gate_required?: boolean;
      }>;
    };
    vivi_job_card_queue?: {
      status?: string;
      job_card_count?: number;
      ready_count?: number;
      waiting_for_operator_count?: number;
      path?: string;
      job_cards?: PlanningQualitySurface['job_cards'];
    };
    vivi_runner_mvp?: {
      status?: string;
      run_id?: string;
      job_card_id?: string;
      runtime_action_executed?: boolean;
      path?: string;
      next_safe_step?: string;
    };
    vivi_supervisor_audit?: {
      status?: string;
      truth_status?: string;
      job_card_id?: string;
      path?: string;
      findings?: Array<{
        severity?: string;
        code?: string;
        message?: string;
      }>;
      next_safe_step?: string;
    };
    vivi_worker_queue?: {
      status?: string;
      worker_card_count?: number;
      ready_count?: number;
      path?: string;
      worker_cards?: Array<{
        worker_card_id?: string;
        status?: string;
        auftrag?: string;
        zielbild?: string;
        output_vertrag?: string[];
        naechster_sicherer_schritt?: string;
      }>;
    };
    vivi_worker_mvp?: {
      status?: string;
      run_id?: string;
      worker_card_id?: string;
      runtime_action_executed?: boolean | null;
      local_artifact_write_executed?: boolean | null;
      path?: string;
      next_safe_step?: string;
    };
    vivi_worker_supervisor_audit?: {
      status?: string;
      truth_status?: string;
      path?: string;
      findings?: Array<{
        severity?: string;
        code?: string;
        message?: string;
      }>;
      next_safe_step?: string;
    };
    endgame_roadmap?: {
      status?: string;
      completion_percent?: number;
      foundation_completion_percent?: number;
      macro_completion_percent?: number;
      current_phase?: string;
      safe_work_remaining?: boolean;
      safe_next_blocks?: Array<{
        block_id?: string;
        title?: string;
        priority?: string;
        affected_projects?: string[];
        next_safe_step?: string;
        verifiers?: string[];
        operator_gates?: string[];
      }>;
      macro_backlog?: Array<{
        block_id?: string;
        title?: string;
        priority?: string;
        status?: string;
        affected_projects?: string[];
        next_safe_step?: string;
        verifiers?: string[];
        operator_gates?: string[];
      }>;
      operator_gates?: Array<{
        phase_id?: string;
        gate?: string;
      }>;
      completion_note?: string;
      path?: string;
    };
    capability_registry?: {
      status?: string;
      record_count?: number;
      sandbox_count?: number;
      gate_count?: number;
      benchmark_count?: number;
      agent_count?: number;
      fail_count?: number;
      runtime_action_executed?: boolean | null;
      path?: string;
      next_safe_step?: string;
    };
    capability_telemetry?: {
      status?: string;
      item_count?: number;
      usage_total?: number;
      ledger_event_count?: number;
      verified_value_total?: number;
      prevented_issue_total?: number;
      risk_blocked_total?: number;
      better_document_total?: number;
      verified_surface_total?: number;
      agent_candidate_count?: number;
      agent_candidate_signal_count?: number;
      runtime_action_executed?: boolean | null;
      path?: string;
      next_safe_step?: string;
    };
    agentization_decision_gate?: {
      status?: string;
      candidate_agent_count?: number;
      approved_agent_count?: number;
      stay_capability_count?: number;
      unsupported_candidate_count?: number;
      fail_count?: number;
      runtime_action_executed?: boolean | null;
      path?: string;
      next_safe_step?: string;
    };
    agent_product_maturity_contract?: {
      status?: string;
      mode?: string;
      candidate_agent_count?: number;
      approved_agent_count?: number;
      product_contract_ready_count?: number;
      fail_count?: number;
      runtime_action_executed?: boolean | null;
      path?: string;
      next_safe_step?: string;
    };
    shannon_security_sandbox_contract?: {
      status?: string;
      canonical_name?: string;
      aliases?: string[];
      fail_count?: number;
      runtime_action_executed?: boolean | null;
      external_action_executed?: boolean | null;
      path?: string;
      next_safe_step?: string;
    };
    fresh_session_context_budget?: {
      status?: string;
      task_count?: number;
      max_default_core_notes?: number;
      fail_count?: number;
      path?: string;
      next_safe_step?: string;
    };
    background_quality_gates?: {
      status?: string;
      gate_count?: number;
      fail_count?: number;
      path?: string;
      next_safe_step?: string;
    };
    openjarvis_capability_lab?: {
      status?: string;
      mode?: string;
      source_of_truth?: boolean;
      source_document_count?: number;
      preflight_status?: string;
      preflight_blocker_count?: number;
      retrieval_status?: string;
      retrieval_question_count?: number;
      retrieval_pass_count?: number;
      code_qa_status?: string;
      code_qa_project_count?: number;
      runtime_available?: boolean;
      runtime_execution_attempted?: boolean;
      runtime_action_executed?: boolean | null;
      adoption_recommendation?: string;
      next_safe_step?: string;
      path?: string;
    };
    openjarvis_capability_arena?: {
      status?: string;
      mode?: string;
      source_of_truth?: boolean;
      task_count?: number;
      source_document_count?: number;
      baseline_document_count?: number;
      shadow_document_count?: number;
      shadow_average_score?: number;
      baseline_average_score?: number;
      shadow_pass_count?: number;
      shadow_fail_count?: number;
      shadow_win_count?: number;
      baseline_win_count?: number;
      tie_count?: number;
      runtime_action_executed?: boolean | null;
      adoption_recommendation?: string;
      next_safe_step?: string;
      path?: string;
    };
    openjarvis_decision_gauntlet?: {
      status?: string;
      decision_status?: string;
      source_of_truth?: boolean;
      test_count?: number;
      pass_count?: number;
      fail_count?: number;
      operator_gate_count?: number;
      local_executable_count?: number;
      runtime_action_executed?: boolean | null;
      runtime_execution_attempted?: boolean | null;
      adoption_recommendation?: string;
      next_safe_step?: string;
      path?: string;
    };
    openjarvis_component_adapter?: {
      status?: string;
      overall_decision?: string;
      component_count?: number;
      adapt_ready_count?: number;
      gated_ready_count?: number;
      rejected_current_count?: number;
      github_digest_status?: string;
      github_digest_mutations_attempted?: boolean;
      automation_candidate?: {
        id?: string;
        cadence?: string;
        status?: string;
        owner?: string;
      };
      local_skill?: {
        name?: string;
        path?: string;
        status?: string;
      };
      path?: string;
    };
  };
  next_safe_step: string;
  stopped_reason: string;
  effect_scope: string;
  contract_quality: {
    status?: string;
    fail_count?: number;
    warn_count?: number;
    items?: number;
  };
  full_check: {
    status?: string;
    generated_at?: string;
  };
  job_cards: Array<{
    job_card_id?: string;
    status?: string;
    auftrag?: string;
    naechster_sicherer_schritt?: string;
    verifier?: string[];
  }>;
}

export interface GoldenBaselineStatus {
  generatedAt?: string;
  verdict: 'pass' | 'fail' | 'unknown';
  mode: string;
  freshness?: 'fresh' | 'stale' | 'critical' | 'failed' | 'unknown';
  ageHours?: number | null;
  nextDueAt?: string | null;
  staleAt?: string | null;
  criticalAt?: string | null;
  failedSteps: string[];
  failedCount?: number;
  stepCount?: number;
  passedSteps?: number;
  reportJsonPath?: string;
  reportMarkdownPath?: string;
  nextAction?: string;
  schedule?: {
    intervalHours: number;
    staleAfterHours: number;
    criticalAfterHours: number;
    dueScript: string;
    launchAgentLabel: string;
  };
  automation?: {
    label?: string;
    checkedAt?: string;
    action?: string;
    reason?: string;
    nextDueAt?: string | null;
    latestBaselineGeneratedAt?: string | null;
    latestBaselineVerdict?: string;
    exitCode?: number | null;
  };
}

export interface GlobalStatus {
  posture: 'STABIL' | 'WARNING' | 'ATTENTION';
  activeMissions: number;
  openQueue: number;
  automationHealth: string;
  bridgeStatus: string;
  lastSignal: string;
  loopHealth: string;
  queueDepth: number;
  syncStatus: string;
  activeClaims: number;
  watcherPosture: string;
}

export interface AgentSummary {
  agentId: AgentId;
  status: string;
  intakeCount: number;
  planningQueue: number;
  activeMissions: number;
  lastAction: string;
}

export interface Mission {
  id: string;
  title: string;
  ownerAgentId: AgentId;
  status: 'intake' | 'planning' | 'active' | 'review' | 'done' | 'blocked';
  priority: Priority;
  progress: number;
  lastUpdate: string;
  nextStep: string;
  handoffHistory: string[];
}

export interface DispatchEvent {
  id: string;
  time: string;
  title: string;
  type: string;
  targetMode: 'Vivi zuerst' | 'Direkt an Vega' | 'Vivi → Vega Handoff' | 'Nur Review';
  priority: Priority;
  status: string;
}

export interface HandoffQueueItem {
  id: string;
  column: 'eingehend' | 'vivi' | 'vega' | 'rueckgabe' | 'blockiert';
  title: string;
  agentId?: AgentId;
  priority: Priority;
  status: string;
}

export interface TelemetrySignal {
  id: string;
  title: string;
  value: string;
  detail: string;
  sourceLabel: string;
  status: 'healthy' | 'warning' | 'critical' | 'standby';
  series: number[];
}

export interface AlertItem {
  id: string;
  severity: Severity;
  source: 'Operator' | 'Vivi' | 'Vega' | 'System' | 'Bridge';
  message: string;
  time: string;
  status: string;
  group?: string;
  actionPath?: AlertActionPath;
  actionLabel?: string;
  recommendation?: string;
  nextStep?: string;
}

export interface BacklogItem {
  id: string;
  title: string;
  source: string;
  recommendedAgentId: AgentId;
  age: string;
  priority: Priority;
  status: 'open' | 'stale' | 'repair' | 'blocked' | 'triage';
  description: string;
  reasonOpen: string;
  nextStep: string;
}

export interface AuditEvent {
  id: string;
  time: string;
  source: 'Operator' | 'Vivi' | 'Vega' | 'System' | 'Bridge';
  event: string;
  type: 'Dispatch' | 'Handoff' | 'Automation' | 'Verification' | 'Commit' | 'Mission' | 'Alert';
  agentId?: AgentId;
  reference: string;
  severity: Severity;
  payload: string;
  before: string;
  after: string;
  traceId: string;
}

export interface ControlPlaneLiveData {
  generatedAt: string;
  source: 'live' | 'fallback';
  operatorLoopStatus: OperatorLoopStatus;
  globalStatus: GlobalStatus;
  agents: Agent[];
  agentSummaries: AgentSummary[];
  missions: Mission[];
  dispatchEvents: DispatchEvent[];
  handoffQueue: HandoffQueueItem[];
  telemetrySignals: TelemetrySignal[];
  alerts: AlertItem[];
  backlogItems: BacklogItem[];
  auditEvents: AuditEvent[];
  activitySignals: ActivitySignal[];
  automationTasks: AutomationTask[];
  queueItems: QueueItem[];
  chatMessages: ChatMessage[];
  workspaces: Workspace[];
  runtimeProfiles: RuntimeProfile[];
  intakeRows: IntakeRow[];
  repoSnapshots: RepoSnapshot[];
  portfolioRepositories: PortfolioRepositoryStatus[];
  portfolioExecutionContract: PortfolioExecutionContract;
  portfolioMetrics: PortfolioStreamMetric[];
  portfolioReviewCalendar: PortfolioReviewCalendarItem[];
  planningQuality: PlanningQualitySurface;
  goldenBaseline: GoldenBaselineStatus;
}
