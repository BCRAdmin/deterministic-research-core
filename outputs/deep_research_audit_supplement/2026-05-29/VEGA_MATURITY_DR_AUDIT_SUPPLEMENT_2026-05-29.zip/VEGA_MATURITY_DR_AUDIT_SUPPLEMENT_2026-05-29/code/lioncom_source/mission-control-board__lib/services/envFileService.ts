import { fileExists, readTextFile } from './fileService';

export interface LoadedEnvCandidate {
  source?: string;
  values: Record<string, string>;
}

export function parseEnvLikeFile(content: string): Record<string, string> {
  const values: Record<string, string> = {};

  for (const rawLine of content.split('\n')) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;

    const match = line.match(/^([A-Z0-9_]+)=(.*)$/);
    if (!match) continue;

    const key = match[1];
    const value = match[2].replace(/^['"]|['"]$/g, '').trim();
    values[key] = value;
  }

  return values;
}

export async function loadEnvFileCandidates(candidates: readonly string[]): Promise<LoadedEnvCandidate> {
  for (const candidate of candidates) {
    if (!(await fileExists(candidate))) {
      continue;
    }

    const content = await readTextFile(candidate);
    if (!content) {
      continue;
    }

    return {
      source: candidate,
      values: parseEnvLikeFile(content),
    };
  }

  return {
    values: {},
  };
}
