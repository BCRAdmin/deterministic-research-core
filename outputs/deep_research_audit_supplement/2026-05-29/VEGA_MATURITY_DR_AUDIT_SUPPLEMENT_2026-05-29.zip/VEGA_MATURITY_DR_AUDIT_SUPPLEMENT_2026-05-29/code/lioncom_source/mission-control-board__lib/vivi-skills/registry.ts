import 'server-only';

import { promises as fs } from 'fs';
import path from 'path';

import { PATHS } from '@/lib/constants/paths';
import { BUILTIN_VIVI_SKILLS } from '@/lib/vivi-skills/builtin-skills';
import { readLatestSkillProposals } from '@/lib/vivi-skills/proposals';
import type {
  ViviSkill,
  ViviSkillHubEntry,
  ViviSkillManifest,
  ViviSkillRun,
  ViviSkillSnapshot,
  ViviSkillStateFile,
} from '@/lib/vivi-skills/types';

const MAX_LATEST_RUNS = 8;

export async function loadViviSkillSnapshot(): Promise<ViviSkillSnapshot> {
  const [state, latestRuns, latestProposals, hubEntries] = await Promise.all([
    readSkillState(),
    readLatestSkillRuns(),
    readLatestSkillProposals(),
    readSkillHubEntries(),
  ]);
  const skills = BUILTIN_VIVI_SKILLS.map((manifest) => hydrateSkill(manifest, state));
  const enabled = skills.filter((skill) => skill.enabled).length;
  const gated = skills.filter((skill) => skill.requiresOperatorGate || skill.riskLevel === 'operator_gate').length;

  return {
    generatedAt: new Date().toISOString(),
    skills,
    latestRuns,
    latestProposals,
    hub: {
      entries: hubEntries,
      remoteDryRunReady: true,
      remoteInstallAllowed: false,
      detail: 'Remote-Skill-Hub ist lokal nur als Dry-Run aktiv. Installationen unbekannten Codes bleiben blockiert.',
    },
    counts: {
      total: skills.length,
      enabled,
      gated,
      availableNow: skills.filter((skill) => skill.status === 'enabled').length,
      proposals: latestProposals.length,
    },
  };
}

export async function getViviSkill(skillId: string): Promise<ViviSkill | null> {
  const state = await readSkillState();
  const manifest = BUILTIN_VIVI_SKILLS.find((skill) => skill.id === skillId);
  return manifest ? hydrateSkill(manifest, state) : null;
}

export async function setViviSkillEnabled(skillId: string, enabled: boolean): Promise<ViviSkillSnapshot> {
  const manifest = BUILTIN_VIVI_SKILLS.find((skill) => skill.id === skillId);
  if (!manifest) throw new Error('skill-not-found');
  const state = await readSkillState();
  const nextState: ViviSkillStateFile = {
    generatedAt: new Date().toISOString(),
    enabled: {
      ...state.enabled,
      [skillId]: enabled,
    },
  };
  await fs.mkdir(path.dirname(PATHS.VIVI_SKILLS_STATE), { recursive: true });
  await fs.writeFile(PATHS.VIVI_SKILLS_STATE, `${JSON.stringify(nextState, null, 2)}\n`, 'utf-8');
  return loadViviSkillSnapshot();
}

export async function readLatestSkillRuns(limit = MAX_LATEST_RUNS): Promise<ViviSkillRun[]> {
  try {
    const content = await fs.readFile(PATHS.VIVI_SKILLS_RUNS_JSONL, 'utf-8');
    return content
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean)
      .map(parseSkillRunLine)
      .filter((run): run is ViviSkillRun => Boolean(run))
      .sort((left, right) => right.startedAt.localeCompare(left.startedAt))
      .slice(0, limit);
  } catch {
    return [];
  }
}

async function readSkillState(): Promise<ViviSkillStateFile> {
  await fs.mkdir(PATHS.VIVI_SKILLS_DIR, { recursive: true });
  try {
    const parsed = JSON.parse(await fs.readFile(PATHS.VIVI_SKILLS_STATE, 'utf-8')) as unknown;
    if (isSkillStateFile(parsed)) return normalizeSkillState(parsed);
  } catch {
    // Missing or malformed state falls back to manifest defaults.
  }

  const state: ViviSkillStateFile = {
    generatedAt: new Date().toISOString(),
    enabled: Object.fromEntries(BUILTIN_VIVI_SKILLS.map((skill) => [skill.id, skill.defaultEnabled])),
  };
  await fs.writeFile(PATHS.VIVI_SKILLS_STATE, `${JSON.stringify(state, null, 2)}\n`, 'utf-8');
  return state;
}

function hydrateSkill(manifest: ViviSkillManifest, state: ViviSkillStateFile): ViviSkill {
  const enabled = state.enabled[manifest.id] ?? manifest.defaultEnabled;
  const blockedByGate = Boolean(manifest.requiresOperatorGate && !enabled);
  return {
    ...manifest,
    enabled,
    status: enabled ? 'enabled' : blockedByGate ? 'blocked' : 'disabled',
    health: enabled
      ? {
          tone: manifest.riskLevel === 'safe' ? 'success' : 'info',
          label: manifest.riskLevel === 'safe' ? 'bereit' : 'kontrolliert',
          detail: manifest.safeUse,
        }
      : {
          tone: 'warning',
          label: 'deaktiviert',
          detail: 'Skill ist im lokalen Vivi-Toolbelt abgeschaltet.',
        },
  };
}

function isSkillStateFile(value: unknown): value is ViviSkillStateFile {
  if (!value || typeof value !== 'object') return false;
  const record = value as Partial<ViviSkillStateFile>;
  return typeof record.generatedAt === 'string' && Boolean(record.enabled) && typeof record.enabled === 'object';
}

function normalizeSkillState(state: ViviSkillStateFile): ViviSkillStateFile {
  const knownIds = new Set(BUILTIN_VIVI_SKILLS.map((skill) => skill.id));
  const enabled: Record<string, boolean> = {};
  for (const skill of BUILTIN_VIVI_SKILLS) {
    enabled[skill.id] = state.enabled[skill.id] ?? skill.defaultEnabled;
  }
  for (const [skillId, value] of Object.entries(state.enabled)) {
    if (knownIds.has(skillId)) enabled[skillId] = Boolean(value);
  }
  return { generatedAt: state.generatedAt, enabled };
}

function parseSkillRunLine(line: string): ViviSkillRun | null {
  try {
    const value = JSON.parse(line) as unknown;
    if (!value || typeof value !== 'object') return null;
    const run = value as Partial<ViviSkillRun>;
    if (!run.id || !run.skillId || !run.startedAt || !run.status) return null;
    return {
      id: String(run.id),
      skillId: String(run.skillId),
      skillName: String(run.skillName || run.skillId),
      capability: run.capability || 'chat.direct',
      status: run.status,
      tone: run.tone || 'info',
      startedAt: String(run.startedAt),
      finishedAt: String(run.finishedAt || run.startedAt),
      sessionId: typeof run.sessionId === 'string' ? run.sessionId : undefined,
      messageId: typeof run.messageId === 'string' ? run.messageId : undefined,
      commandRef: typeof run.commandRef === 'string' ? run.commandRef : undefined,
      requestedBy: run.requestedBy || 'system',
      source: String(run.source || 'Vivi Skill Runtime'),
      summary: String(run.summary || run.skillId),
      detail: String(run.detail || ''),
      nextAction: String(run.nextAction || ''),
      artifacts: Array.isArray(run.artifacts) ? run.artifacts.filter((artifact) => Boolean(artifact && typeof artifact === 'object')) as ViviSkillRun['artifacts'] : [],
    };
  } catch {
    return null;
  }
}

async function readSkillHubEntries(): Promise<ViviSkillHubEntry[]> {
  const catalogPath = path.join(process.cwd(), 'data', 'vivi-skills', 'catalog.json');
  try {
    const parsed = JSON.parse(await fs.readFile(catalogPath, 'utf-8')) as unknown;
    if (!parsed || typeof parsed !== 'object') return defaultHubEntries();
    const entries = (parsed as { entries?: unknown }).entries;
    if (!Array.isArray(entries)) return defaultHubEntries();
    const parsedEntries = entries.map(parseHubEntry).filter((entry): entry is ViviSkillHubEntry => Boolean(entry));
    return parsedEntries.length ? parsedEntries : defaultHubEntries();
  } catch {
    return defaultHubEntries();
  }
}

function defaultHubEntries(): ViviSkillHubEntry[] {
  return BUILTIN_VIVI_SKILLS.map((skill) => ({
    id: skill.id,
    name: skill.name,
    capability: skill.capabilities[0] || 'chat.direct',
    source: 'builtin',
    status: 'installed',
    riskLevel: skill.riskLevel === 'operator_gate' ? 'operator-gate' : skill.riskLevel === 'safe' ? 'safe' : 'guarded',
    installMode: 'builtin',
    summary: skill.operatorSummary,
  }));
}

function parseHubEntry(value: unknown): ViviSkillHubEntry | null {
  if (!value || typeof value !== 'object') return null;
  const record = value as Partial<ViviSkillHubEntry>;
  if (!record.id || !record.name || !record.capability) return null;
  return {
    id: String(record.id),
    name: String(record.name),
    capability: record.capability,
    source: record.source || 'local-catalog',
    status: record.status || 'proposal-ready',
    riskLevel: record.riskLevel || 'guarded',
    installMode: record.installMode || 'vega-build',
    summary: String(record.summary || ''),
    gateReason: typeof record.gateReason === 'string' ? record.gateReason : undefined,
  };
}
