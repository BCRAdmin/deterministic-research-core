import { promises as fs } from 'fs';
import path from 'path';

import { PATHS } from '../constants/paths';
import type { BlockerSignal, TimelineEntry, ViviReportEntry } from '../control-room/types';
import { syncAllControlPlanes } from './controlPlaneSyncService';
import { appendRailBlock, extractField, parseRailBlocks, readRailContent, transformRailBlocks, updateBlockField } from './structuredRailService';

export type ViviOperatingState =
  | 'IDLE'
  | 'INTAKE'
  | 'ANALYZE'
  | 'PLAN'
  | 'EXECUTE'
  | 'VERIFY'
  | 'REPORT'
  | 'FREEZE'
  | 'RECOVER';

export interface ViviRuntimeSnapshot {
  schemaVersion: '1.0';
  updatedAt: string;
  source: string;
  runId?: string;
  runtime: {
    heartbeatAt: string;
    responsive: boolean;
    channel: string;
    host?: string;
  };
  mission: {
    state: string;
    operatingState: ViviOperatingState;
    phase: string;
    progress: number;
    activeTask?: string;
    currentAction?: string;
    nextAction?: string;
    commandRef?: string;
  };
  blockers: BlockerSignal[];
  warnings: string[];
  recentSteps: TimelineEntry[];
  latestReport?: {
    id: string;
    kind: string;
    summary: string;
    nextStep?: string;
    addedAt: string;
  };
}

export interface ViviStateSnapshot {
  schemaVersion: '1.0';
  updatedAt: string;
  currentState: ViviOperatingState;
  previousState: ViviOperatingState | null;
  phase: string;
  progress: number;
  enteredAt: string;
  lastTransitionAt: string;
  transitionReason: string;
  currentAction?: string;
  nextAction?: string;
  commandRef?: string;
  runId?: string;
  requiresOperator: boolean;
  requiresCodex: boolean;
  transitionIntegrity: 'initial' | 'valid' | 'invalid';
  guardNote?: string;
}

export interface ViviSignalPayload {
  source?: string;
  runId?: string;
  event?: 'heartbeat' | 'transition' | 'report' | 'handoff' | 'verify' | 'recovery';
  heartbeatAt?: string;
  state?: string;
  phase?: string;
  progress?: number;
  activeTask?: string;
  currentAction?: string;
  nextAction?: string;
  responsive?: boolean;
  host?: string;
  channel?: string;
  commandRef?: string;
  transitionReason?: string;
  stepLabel?: string;
  stepDetail?: string;
  stepTone?: TimelineEntry['tone'];
  stepType?: string;
  blockers?: Array<string | { description: string; impact?: string; workaround?: string }>;
  warnings?: string[];
  reportKind?: 'result' | 'handoff' | 'verify' | 'recovery';
  reportTitle?: string;
  resultSummary?: string;
  outcome?: string;
  nextOperatorAction?: string;
  notes?: string;
}

interface ViviBridgeSnapshot {
  runtime: ViviRuntimeSnapshot | null;
  state: ViviStateSnapshot | null;
  reports: ViviReportEntry[];
}

let viviSignalQueue: Promise<void> = Promise.resolve();

export async function readViviBridgeSnapshot(): Promise<ViviBridgeSnapshot> {
  await reconcileBusinessFollowUps();
  const [runtimeContent, stateContent, reportsContent] = await Promise.all([
    safeRead(PATHS.VIVI_RUNTIME),
    safeRead(PATHS.VIVI_STATE),
    safeRead(PATHS.VIVI_REPORTS),
  ]);

  return {
    runtime: parseJson<ViviRuntimeSnapshot>(runtimeContent),
    state: parseJson<ViviStateSnapshot>(stateContent),
    reports: parseViviReports(reportsContent),
  };
}

export async function ingestViviSignal(payload: ViviSignalPayload) {
  return enqueueViviSignal(() => ingestViviSignalInternal(payload));
}

async function enqueueViviSignal<T>(operation: () => Promise<T>): Promise<T> {
  const next = viviSignalQueue.then(operation, operation);
  // Serialize ingest updates so fast follow-up signals do not read a stale state snapshot.
  viviSignalQueue = next.then(() => undefined, () => undefined);
  return next;
}

async function ingestViviSignalInternal(payload: ViviSignalPayload) {
  const now = new Date().toISOString();
  const existing = await readViviBridgeSnapshot();

  const operatingState = normalizeOperatingState(
    payload.state,
    payload.phase,
    payload.currentAction,
    payload.event,
  );

  const previousState = existing.state?.currentState || existing.runtime?.mission.operatingState || null;
  const transitionGuard = evaluateTransition(previousState, operatingState, payload.event);
  const enteredAt = previousState === operatingState
    ? existing.state?.enteredAt || now
    : now;
  const currentAction = payload.currentAction || existing.runtime?.mission.currentAction || existing.state?.currentAction;
  const nextAction = payload.nextAction || existing.runtime?.mission.nextAction || existing.state?.nextAction;
  const heartbeatAt = payload.heartbeatAt || now;
  const step = buildStep(payload, operatingState, now);
  const blockers = normalizeBlockers(payload.blockers);
  const warnings = Array.isArray(payload.warnings) ? payload.warnings.filter(Boolean).slice(0, 8) : [];
  if (!transitionGuard.allowed && transitionGuard.message) {
    warnings.unshift(transitionGuard.message);
    blockers.unshift({
      description: 'Invalid Vivi state transition detected',
      impact: transitionGuard.message,
      workaround: 'Freeze or Codex review before trusting this runtime flow.',
    });
  }
  const latestReport = buildLatestReport(payload, now);

  const runtime: ViviRuntimeSnapshot = {
    schemaVersion: '1.0',
    updatedAt: now,
    source: payload.source || existing.runtime?.source || 'LIONCOM bridge',
    runId: payload.runId || existing.runtime?.runId,
    runtime: {
      heartbeatAt,
      responsive: payload.responsive ?? existing.runtime?.runtime.responsive ?? true,
      channel: payload.channel || existing.runtime?.runtime.channel || 'api',
      host: payload.host || existing.runtime?.runtime.host,
    },
    mission: {
      state: payload.state || existing.runtime?.mission.state || inferMissionState(operatingState, blockers.length),
      operatingState,
      phase: payload.phase || existing.runtime?.mission.phase || 'OBSERVE',
      progress: coerceProgress(payload.progress, existing.runtime?.mission.progress),
      activeTask: payload.activeTask || existing.runtime?.mission.activeTask,
      currentAction,
      nextAction,
      commandRef: payload.commandRef || existing.runtime?.mission.commandRef,
    },
    blockers,
    warnings,
    recentSteps: mergeSteps(step, existing.runtime?.recentSteps || []),
    latestReport,
  };

  const state: ViviStateSnapshot = {
    schemaVersion: '1.0',
    updatedAt: now,
    currentState: operatingState,
    previousState,
    phase: runtime.mission.phase,
    progress: runtime.mission.progress,
    enteredAt,
    lastTransitionAt: now,
    transitionReason: payload.transitionReason || payload.event || currentAction || 'heartbeat update',
    currentAction,
    nextAction,
    commandRef: payload.commandRef || existing.state?.commandRef,
    runId: payload.runId || existing.state?.runId,
    requiresOperator: Boolean(
      blockers.length > 0
      || warnings.some((warning) => warning.toLowerCase().includes('operator'))
      || (payload.event === 'handoff' && nextAction),
    ),
    requiresCodex: !transitionGuard.allowed || operatingState === 'FREEZE' || warnings.some((warning) => /codex|debug|repair|invalid/i.test(warning)),
    transitionIntegrity: previousState ? (transitionGuard.allowed ? 'valid' : 'invalid') : 'initial',
    guardNote: transitionGuard.allowed ? undefined : transitionGuard.message,
  };

  await Promise.all([
    writeJsonAtomic(PATHS.VIVI_RUNTIME, runtime),
    writeJsonAtomic(PATHS.VIVI_STATE, state),
  ]);

  const reportEntry = buildReportEntry(payload, runtime, state, now);
  if (reportEntry) {
    await appendReportEntry(reportEntry);
    await seedFollowUpWorkFromReport(reportEntry);
  }

  await maybeEscalateForBridgeIssues({
    payload,
    runtime,
    state,
    reportEntry,
    transitionWarning: transitionGuard.allowed ? undefined : transitionGuard.message,
  });

  await synchronizeQueues(payload, runtime, state);
  await syncAllControlPlanes({ viviRuntime: runtime, viviState: state });

  return {
    runtime,
    state,
    reportEntry,
  };
}

interface FollowUpMissionBlueprint {
  triggerRef: string;
  nextRef: string;
  title: string;
  desiredOutcome: string;
  category: string;
  priority: 'high' | 'normal';
  context: string;
  rawRequest: string;
}

const BUSINESS_FOLLOW_UPS: FollowUpMissionBlueprint[] = [
  {
    triggerRef: 'FIN-PLATFORM-20260416-01',
    nextRef: 'FIN-PLATFORM-20260417-02',
    title: 'Membership-Finanzplattform Phase 2: Angebot, Landing Page und MVP-Scope',
    desiredOutcome: 'Ein marktnahes Angebots- und Produktpaket mit Nutzenversprechen, Landing-Page-Struktur, Founder-Offer, MVP-Grenzen und bewussten Nicht-MVP-Punkten liegt sauber vor.',
    category: 'research-brief',
    priority: 'high',
    context: 'Fortsetzung des vorhandenen Business-Cases. Das ist echte Business-Arbeit fuer morgen, nicht interne LION-Pflege.',
    rawRequest: 'Arbeite auf Basis des bestehenden Business-Case-Briefs jetzt Phase 2 aus. Liefere ein klares Nutzenversprechen, die Struktur einer Landing Page, ein Founder-Angebot, einen scharfen MVP-Scope, eine Liste von Dingen, die bewusst NICHT im MVP landen, sowie die wichtigsten offenen Entscheidungen fuer den Operator. Nutze die vorhandene Finanzplattform-Idee als reale Produktspur und formuliere das Ergebnis entscheidungsreif.',
  },
  {
    triggerRef: 'FIN-PLATFORM-20260417-02',
    nextRef: 'FIN-PLATFORM-20260417-03',
    title: 'Membership-Finanzplattform Phase 3: Datenquellen, Produktionsworkflow und Launch-Risiken',
    desiredOutcome: 'Ein umsetzungsnahes Paket mit Datenquellenoptionen, Kostenrahmen, Content-/Report-Workflow, Launch-Risiken und einem 30/60/90-Tage-Plan liegt sauber vor.',
    category: 'research-brief',
    priority: 'high',
    context: 'Direkte Folgearbeit zur Membership-Finanzplattform. Vivi soll die Business-Spur weiterziehen, solange keine hoeherpriorisierte operatornahe Mission offen ist.',
    rawRequest: 'Arbeite fuer dieselbe Membership-Finanzplattform jetzt Phase 3 aus. Liefere eine realistische Auswahl moeglicher Datenquellen, grobe Kostenhebel, einen Produktions- und Analyseworkflow, Launch-Risiken, noetige Rollen bzw. Automationen sowie einen klaren 30/60/90-Tage-Plan. Halte das Ergebnis entscheidungsreif und anschlussfaehig an das Phase-2-Paket.',
  },
  {
    triggerRef: 'FIN-PLATFORM-20260417-03',
    nextRef: 'FIN-PLATFORM-20260417-04',
    title: 'Membership-Finanzplattform Phase 4: Preis-, Packaging- und Unit-Economics-Varianten',
    desiredOutcome: 'Ein sauberes Paket mit Preisvarianten, Founder-/Standard-Tiers, grober Unit-Economics-Sicht, realistischen Conversion-Annahmen und klarer Preisempfehlung fuer den Start liegt vor.',
    category: 'research-brief',
    priority: 'high',
    context: 'Die Finanzplattform-Spur soll nach Datenquellen und Workflow in die kommerzielle Realitaet gezogen werden. Fokus auf echtes Angebots- und Umsatzdenken.',
    rawRequest: 'Arbeite fuer dieselbe Membership-Finanzplattform jetzt Phase 4 aus. Liefere mehrere Preis- und Packaging-Varianten, eine ehrliche Unit-Economics-Sicht fuer den Start, Founder- versus spaeteres Standard-Angebot, grobe Conversion-Annahmen, Churn-Risiken und eine klare Preisempfehlung fuer das Launchfenster.',
  },
  {
    triggerRef: 'FIN-PLATFORM-20260417-04',
    nextRef: 'FIN-PLATFORM-20260417-05',
    title: 'Membership-Finanzplattform Phase 5: Entscheidungsdeck fuer den Operator',
    desiredOutcome: 'Ein kompaktes, aber belastbares Entscheidungsdeck mit den wichtigsten Freigaben, Optionen, Risiken, empfohlenen Pfaden und klarer Default-Empfehlung liegt sauber vor.',
    category: 'decision-sync',
    priority: 'high',
    context: 'Der Operator soll nicht alle Details lesen muessen, sondern die echten Business-Entscheidungen gebuendelt vorfinden.',
    rawRequest: 'Verdichte die Membership-Finanzplattform nach den bisherigen Phasen jetzt zu einem echten Entscheidungsdeck fuer den Operator. Liefere nur die relevanten Entscheidungen, jeweils mit Option A/B/C, Risiken, Empfehlung, Default-Pfad und was als Naechstes freigegeben werden sollte.',
  },
  {
    triggerRef: 'FIN-PLATFORM-20260417-05',
    nextRef: 'FIN-PLATFORM-20260417-06',
    title: 'Membership-Finanzplattform Phase 6: Landing-Page-Copy und Member-Journey',
    desiredOutcome: 'Ein anschlussfaehiges Paket mit Hero-Copy, Sections, CTA-Logik, Onboarding-Flow, Member-Journey und Retention-Hooks liegt sauber vor.',
    category: 'research-brief',
    priority: 'high',
    context: 'Nach dem Entscheidungsdeck soll die Finanzplattform fuer echte Kommunikation und Produktfuehrung vorbereitet werden.',
    rawRequest: 'Arbeite fuer dieselbe Membership-Finanzplattform jetzt Phase 6 aus. Liefere die Landing-Page-Copy, die wichtigsten Sections, CTA-Logik, eine klare Member-Journey vom Erstbesuch bis zur wiederkehrenden Nutzung sowie einfache Retention-Hooks, die ohne persoenliche Selbstdarstellung des Operators funktionieren.',
  },
  {
    triggerRef: 'FIN-PLATFORM-20260417-06',
    nextRef: 'FIN-PLATFORM-20260417-07',
    title: 'Membership-Finanzplattform Phase 7: Go-to-Market und Akquisitionsplan',
    desiredOutcome: 'Ein realistischer Startplan mit Kanaelen, Experimenten, Content-Rhythmus, Messpunkten, Risiken und einem kleinen Launch-Playbook fuer die ersten 90 Tage liegt sauber vor.',
    category: 'research-brief',
    priority: 'high',
    context: 'Die Business-Spur soll bis zum realistischen Launch- und Akquisitionspfad weitergezogen werden.',
    rawRequest: 'Arbeite fuer dieselbe Membership-Finanzplattform jetzt Phase 7 aus. Liefere einen realistischen Go-to-Market- und Akquisitionsplan fuer die ersten 90 Tage mit Kanaelen, Experimenten, Messpunkten, Content-Rhythmus, Risikoannahmen und einem kleinen Launch-Playbook, das ohne persoenliche Sichtbarkeit des Operators auskommt.',
  },
  {
    triggerRef: 'FIN-PLATFORM-20260417-07',
    nextRef: 'FIN-PLATFORM-20260417-08',
    title: 'Membership-Finanzplattform Phase 8: Proof-Asset-Paket bauen',
    desiredOutcome: 'Ein belastbares Proof-Asset-Paket mit 2 bis 3 oeffentlichen Beispielanalysen, einer Methodik-Seite und einer Wochenbrief-Vorschau liegt vor und kann direkt fuer Landing Page, Waitlist und Founder-Verkauf genutzt werden.',
    category: 'execution',
    priority: 'high',
    context: 'Nach GTM muss das bestehende Produkt jetzt echte Beweisflaechen bekommen. Fokus auf Marktfaehigkeit, nicht auf neue Produktideen.',
    rawRequest: 'Arbeite fuer die bestehende Membership-Finanzplattform jetzt Phase 8 aus. Erstelle ein Proof-Asset-Paket: zwei bis drei oeffentliche Beispielanalysen bzw. Profilvorschauen, eine klare Methodik-Seite und eine Vorschau fuer einen Wochenbrief. Ziel ist, dass kalte Besucher echte Produktbeweise sehen, bevor sie Founder-Preis oder Waitlist-CTA sehen. Halte das Ergebnis operator-sicher, konkret und anschlussfaehig an die bisherigen Phasen 2 bis 7.',
  },
  {
    triggerRef: 'FIN-PLATFORM-20260417-08',
    nextRef: 'FIN-PLATFORM-20260417-09',
    title: 'Membership-Finanzplattform Phase 9: Waitlist- und Founder-Sequenz',
    desiredOutcome: 'Eine klare Waitlist- und Founder-Sequenz mit mehreren E-Mails, Segmentierung, CTA-Folge und Triggern fuer warme versus kalte Interessenten liegt vor.',
    category: 'execution',
    priority: 'high',
    context: 'Direkte Folgearbeit nach dem Proof-Asset-Paket. Bestehendes Produkt weiter verkaufsfaehig machen, noch keine neue Produktspur.',
    rawRequest: 'Arbeite fuer dieselbe Membership-Finanzplattform jetzt Phase 9 aus. Liefere eine Waitlist- und Founder-Sequenz mit drei bis vier E-Mails, klarer Segmentierung fuer warme versus kalte Interessenten, CTA-Folge von Produktbeweis zu Founder-Deal sowie einer ruhigen, hochwertigen Tonalitaet. Das Ergebnis soll direkt an die bisherige Business-Spur und das Proof-Asset-Paket anschliessen.',
  },
  {
    triggerRef: 'FIN-PLATFORM-20260417-09',
    nextRef: 'FIN-PLATFORM-20260417-10',
    title: 'Membership-Finanzplattform Phase 10: Partner- und Distributionsliste',
    desiredOutcome: 'Eine priorisierte Liste geeigneter Newsletter, Communities, Partner oder Verteilwege mit Fit, Nutzenversprechen, Outreach-Raster und Reihenfolge fuer den Launch liegt vor.',
    category: 'execution',
    priority: 'high',
    context: 'Fortsetzung der bestehenden Finanzplattform-Business-Spur. Fokus auf geliehene Distribution ohne Massenrauschen.',
    rawRequest: 'Arbeite fuer dieselbe Membership-Finanzplattform jetzt Phase 10 aus. Liefere eine priorisierte Partner- und Distributionsliste mit fuenf bis zehn konkreten Zielen, jeweils mit Fit, warum der Kanal oder Partner passt, welchem Nutzenversprechen wir dort auftreten sollten und in welcher Reihenfolge diese Kontakte oder Plattformen fuer einen ruhigen Launch sinnvoll sind.',
  },
  {
    triggerRef: 'FIN-PLATFORM-20260417-10',
    nextRef: 'FIN-PLATFORM-20260417-11',
    title: 'Membership-Finanzplattform Phase 11: Ausbau, Differenzierung und moegliche Erweiterungen',
    desiredOutcome: 'Ein Ausbaupaket mit Differenzierungshebeln, moeglichen Premium-Erweiterungen, Community- oder Tool-Elementen, Automationsideen und einem Pfad von MVP zu staerkerem Produkt-Moat liegt vor.',
    category: 'research-brief',
    priority: 'normal',
    context: 'Diese Phase kommt erst nach den vorhandenen Business-Cases und dem Verkaufspfad. Ziel ist Ausbau des bestehenden Produkts vor neuen Produkten.',
    rawRequest: 'Arbeite fuer dieselbe Membership-Finanzplattform jetzt Phase 11 aus. Gehe davon aus, dass die bisherigen Business-Cases und die Launch-Spur stehen. Liefere jetzt konkrete Ausbau- und Differenzierungsmoeglichkeiten: welche Features, Services, Tool-Elemente, Community-Bausteine, Automationen oder Datentiefe das bestehende Produkt deutlich staerker machen koennen. Ziel ist zunaechst Ausbau des vorhandenen Produkts, nicht sofort eine neue Produktidee.',
  },
  {
    triggerRef: 'FIN-PLATFORM-20260417-11',
    nextRef: 'FIN-PLATFORM-20260417-12',
    title: 'Membership-Finanzplattform Phase 12: Launch-Implementierungs-Backlog',
    desiredOutcome: 'Ein konkreter Build-Backlog fuer Landing Page, Proof-Seiten, Founder-Funnel, Wochenbrief-Vorschau und Partner-Outreach liegt vor, sauber in Arbeitsbloecke, Prioritaeten und Abhaengigkeiten zerlegt.',
    category: 'workflow-upgrade',
    priority: 'high',
    context: 'Nach Strategie und Ausbau muss das bestehende Produkt jetzt in echte Umsetzungsarbeit uebersetzt werden. Das ist Launch-Arbeit, keine neue Produktsuche.',
    rawRequest: 'Arbeite fuer dieselbe Membership-Finanzplattform jetzt Phase 12 aus. Uebersetze die bisherigen Phasen 2 bis 11 in einen konkreten Launch-Implementierungs-Backlog: welche Seiten, Komponenten, Assets, E-Mail-Elemente, Datenfluesse, Automationen und Content-Bloecke jetzt gebaut werden muessen, in welcher Reihenfolge, mit welchen Abhaengigkeiten und was davon zuerst Marktbeweis schafft.',
  },
  {
    triggerRef: 'FIN-PLATFORM-20260417-12',
    nextRef: 'FIN-PLATFORM-20260417-13',
    title: 'Membership-Finanzplattform Phase 13: Proof-Analysen in publizierbare Erstfassungen',
    desiredOutcome: 'Drei publizierbare Erstfassungen fuer oeffentliche Beispielanalysen oder Profilvorschauen liegen vor und koennen direkt als Trust-Assets fuer Landing Page, Waitlist und Founder-Launch genutzt werden.',
    category: 'execution',
    priority: 'high',
    context: 'Bestehendes Produkt jetzt in reale Marktartefakte verwandeln. Fokus auf konkrete Beweisflaechen statt weiterer Strategie.',
    rawRequest: 'Arbeite fuer dieselbe Membership-Finanzplattform jetzt Phase 13 aus. Erstelle drei publizierbare Erstfassungen fuer oeffentliche Beispielanalysen oder Profilvorschauen, die direkt fuer Landing Page, Waitlist und Founder-Sequenz genutzt werden koennen. Halte Tonalitaet, Methodik und Produktbeweis konsistent mit den bisherigen Phasen.',
  },
  {
    triggerRef: 'FIN-PLATFORM-20260417-13',
    nextRef: 'FIN-PLATFORM-20260417-14',
    title: 'Membership-Finanzplattform Phase 14: Founder-Launch Operating System',
    desiredOutcome: 'Ein operatives Founder-Launch-System mit Wochenrhythmus, Metriken, Signalgrenzen, Experiment-Logik und Automationsplan liegt vor und kann von Vivi spaeter eigenstaendig mitgetragen werden.',
    category: 'workflow-upgrade',
    priority: 'high',
    context: 'Das Produkt soll nicht nur gut aussehen, sondern wiederholbar wachsen koennen. Fokus auf ein ruhiges Betriebssystem fuer den Launch, nicht auf bloesse Ideenproduktion.',
    rawRequest: 'Arbeite fuer dieselbe Membership-Finanzplattform jetzt Phase 14 aus. Liefere ein Founder-Launch Operating System: Wochenrhythmus, Kernmetriken, Stop-or-go-Signale, Content-Takt, Outreach-Takt, Waitlist-Bewegung, Founder-Conversion, Member-Aktivierung und welche Teile davon spaeter durch Vivi oder Automationen wiederholbar getragen werden koennen.',
  },
  {
    triggerRef: 'FIN-PLATFORM-20260417-14',
    nextRef: 'FIN-PLATFORM-20260417-15',
    title: 'Membership-Finanzplattform Phase 15: Ausbaupfad nach den ersten 25 Foundern',
    desiredOutcome: 'Ein priorisierter Ausbaupfad fuer das bestehende Produkt nach den ersten 25 Foundern liegt vor, inklusive Moat-Hebeln, Produktvertiefung, Automationen und klaren Stopps gegen Feature-Verzettelung.',
    category: 'research-brief',
    priority: 'normal',
    context: 'Neue Produkte kommen erst spaeter. Zunaechst soll das bestehende Produkt maximal ausgeschoepft und sauber staerker gemacht werden.',
    rawRequest: 'Arbeite fuer dieselbe Membership-Finanzplattform jetzt Phase 15 aus. Gehe davon aus, dass die ersten 25 Founder erreicht wurden. Liefere einen priorisierten Ausbaupfad fuer das bestehende Produkt: welche Vertiefungen, Automationen, Member-Routinen, Daten- oder Watchpoint-Funktionen den staerksten Hebel bringen und welche Ideen bewusst nicht verfolgt werden sollten, damit das Produkt fokussiert bleibt.',
  },
];

async function seedFollowUpWorkFromReport(entry: ViviReportEntry): Promise<void> {
  if (entry.state !== 'REPORT' || !entry.commandRef) {
    return;
  }

  const blueprint = BUSINESS_FOLLOW_UPS.find((item) => item.triggerRef === entry.commandRef);
  if (!blueprint) {
    return;
  }

  const [viviCommandContent, workIntakeContent, reportsContent] = await Promise.all([
    readRailContent(PATHS.VIVI_COMMAND_QUEUE),
    readRailContent(PATHS.WORK_INTAKE),
    readRailContent(PATHS.VIVI_REPORTS),
  ]);

  if (
    railAlreadyContainsReference(viviCommandContent, blueprint.nextRef)
    || railAlreadyContainsReference(workIntakeContent, blueprint.nextRef)
    || railAlreadyContainsReference(reportsContent, blueprint.nextRef, 'Command Ref')
  ) {
    return;
  }

  const now = new Date().toISOString();
  const packetId = buildId('VIVI', now);
  const sharedBlock = [
    `- Added: ${now}`,
    '- Source: Automation follow-up engine',
    `- Status: queued`,
    `- Priority: ${blueprint.priority}`,
    `- Category: ${blueprint.category}`,
    `- Title: ${blueprint.title}`,
    '- Target: Vivi',
    `- Context: ${blueprint.context}`,
    `- Reference: ${blueprint.nextRef}`,
    '- Delivery: local-queue',
    `- Summary: ${summarizeForRail(blueprint.rawRequest, blueprint.title)}`,
    `- Desired Outcome: ${blueprint.desiredOutcome}`,
    '- Intent: research',
    '- Project Fit: existing',
    '- Research Mode: primary',
    '- Operator Mode: mixed',
    `- Priority Hint: ${blueprint.priority}`,
    '- Example Handling: reference',
    '- Interpretation Hint: Diese Folgephase wurde aus einem abgeschlossenen Vivi-Report automatisch abgeleitet und soll die bestehende Business-Spur ohne Leerlauf weiterziehen.',
    '- Routing Note: Route this through the builder lane. Treat this as internal follow-up work that should stay behind fresh operator backlog but remain immediately claimable once the current business lane is clear.',
    '- Raw Request:',
    ...blueprint.rawRequest.split('\n').map((line) => `> ${line}`),
    '',
  ];

  await Promise.all([
    appendRailBlock(
      PATHS.VIVI_COMMAND_QUEUE,
      '# Vivi Command Queue\n\nDirect operator and Codex-to-Vivi command packets staged by LIONCOM.\n\n',
      `### ${packetId}\n${sharedBlock.join('\n')}`,
    ),
    appendRailBlock(
      PATHS.WORK_INTAKE,
      '# Work Intake\n\nControlled queue for requests that Vivi should analyze first, then split into work blocks and subtasks.\n\n',
      `### ${packetId}\n${[
        `- Added: ${now}`,
        '- Source: Automation follow-up engine',
        '- Status: new',
        `- Urgency: ${blueprint.priority}`,
        `- Category: ${blueprint.category}`,
        `- Title: ${blueprint.title}`,
        `- Desired Outcome: ${blueprint.desiredOutcome}`,
        `- Summary: ${summarizeForRail(blueprint.rawRequest, blueprint.title)}`,
        '- Intent: research',
        '- Project Fit: existing',
        '- Research Mode: primary',
        '- Operator Mode: mixed',
        `- Priority Hint: ${blueprint.priority}`,
        '- Example Handling: reference',
        '- Interpretation Hint: Diese Folgephase wurde aus einem abgeschlossenen Vivi-Report automatisch abgeleitet und soll die bestehende Business-Spur ohne Leerlauf weiterziehen.',
        '- Routing Note: Route this through the builder lane. Treat this as internal follow-up work that should stay behind fresh operator backlog but remain immediately claimable once the current business lane is clear.',
        `- Reference: ${blueprint.nextRef}`,
        '- Raw Request:',
        ...blueprint.rawRequest.split('\n').map((line) => `> ${line}`),
        '',
      ].join('\n')}`,
    ),
  ]);
}

async function reconcileBusinessFollowUps(): Promise<void> {
  const reports = parseViviReports(await safeRead(PATHS.VIVI_REPORTS));
  for (const report of reports) {
    await seedFollowUpWorkFromReport(report);
  }
}

function railAlreadyContainsReference(content: string | null, reference: string, field = 'Reference'): boolean {
  if (!content) return false;
  return parseRailBlocks(content).some((block) => {
    const current = field === 'Reference' ? block.fields['Reference'] : block.fields[field];
    return current === reference || block.id === reference;
  });
}

function summarizeForRail(value: string, fallback: string): string {
  const compact = value.replace(/\s+/g, ' ').trim();
  if (!compact) return fallback;
  return compact.slice(0, 180);
}

const ALLOWED_STATE_TRANSITIONS: Record<ViviOperatingState, ViviOperatingState[]> = {
  IDLE: ['INTAKE', 'ANALYZE', 'PLAN', 'EXECUTE', 'FREEZE', 'RECOVER', 'REPORT', 'IDLE'],
  INTAKE: ['INTAKE', 'ANALYZE', 'PLAN', 'EXECUTE', 'VERIFY', 'FREEZE', 'RECOVER', 'REPORT', 'IDLE'],
  ANALYZE: ['ANALYZE', 'PLAN', 'EXECUTE', 'VERIFY', 'FREEZE', 'REPORT', 'RECOVER', 'IDLE'],
  PLAN: ['PLAN', 'ANALYZE', 'EXECUTE', 'VERIFY', 'FREEZE', 'REPORT', 'RECOVER', 'IDLE'],
  EXECUTE: ['EXECUTE', 'ANALYZE', 'PLAN', 'VERIFY', 'FREEZE', 'RECOVER', 'REPORT', 'IDLE'],
  VERIFY: ['VERIFY', 'ANALYZE', 'PLAN', 'EXECUTE', 'FREEZE', 'RECOVER', 'REPORT', 'IDLE'],
  REPORT: ['REPORT', 'IDLE', 'INTAKE', 'ANALYZE', 'PLAN', 'EXECUTE', 'VERIFY', 'RECOVER'],
  FREEZE: ['FREEZE', 'RECOVER', 'REPORT', 'IDLE'],
  RECOVER: ['RECOVER', 'ANALYZE', 'PLAN', 'EXECUTE', 'VERIFY', 'REPORT', 'FREEZE', 'IDLE'],
};

function evaluateTransition(
  previousState: ViviOperatingState | null,
  nextState: ViviOperatingState,
  event?: ViviSignalPayload['event'],
): { allowed: boolean; message?: string } {
  if (!previousState) {
    return { allowed: true };
  }

  if (previousState === nextState) {
    return { allowed: true };
  }

  if (event === 'heartbeat') {
    return { allowed: true };
  }

  if (ALLOWED_STATE_TRANSITIONS[previousState]?.includes(nextState)) {
    return { allowed: true };
  }

  return {
    allowed: false,
    message: `Transition ${previousState} -> ${nextState} is outside the allowed Vivi operating flow.`,
  };
}

async function synchronizeQueues(
  payload: ViviSignalPayload,
  runtime: ViviRuntimeSnapshot,
  state: ViviStateSnapshot,
): Promise<void> {
  const commandRefs = [payload.commandRef, payload.activeTask, runtime.mission.activeTask, state.commandRef]
    .filter((value): value is string => Boolean(value));

  if (commandRefs.length === 0) {
    return;
  }

  const status = mapRailStatus(state.currentState, payload.event);
  const detail = runtime.mission.currentAction || payload.stepLabel || payload.resultSummary || payload.outcome || state.transitionReason;

  await Promise.all([
    syncRailStatus(
      PATHS.VIVI_COMMAND_QUEUE,
      '# Vivi Command Queue\n\nDirect operator and Codex-to-Vivi command packets staged by LIONCOM.\n\n',
      commandRefs,
      status,
      detail,
    ),
    syncRailStatus(
      PATHS.WORK_INTAKE,
      '# Work Intake\n\nControlled queue for requests that Vivi should interpret, split into work blocks and turn into concrete subtasks.\n\n',
      commandRefs,
      status,
      detail,
    ),
    syncRailStatus(
      PATHS.REPAIR_QUEUE,
      '# Repair Queue\n\nOperational repair and rescue packets generated by LIONCOM when visibility, runtime safety or core rails need attention.\n\n',
      commandRefs,
      status,
      detail,
    ),
  ]);
}

async function syncRailStatus(
  filePath: string,
  header: string,
  references: string[],
  status: string,
  detail?: string,
): Promise<void> {
  await transformRailBlocks(filePath, header, (block) => {
    const blockReference = extractField(block.lines, 'Reference');
    const targetMatches = references.some((reference) => reference === block.id || reference === blockReference);
    if (!targetMatches) return block;

    const currentStatus = normalizeRailStatus(extractField(block.lines, 'Status'));
    const terminalStatus = ['closed', 'answered', 'reported', 'done'].includes(currentStatus);
    let nextLines = terminalStatus ? block.lines : updateBlockField(block.lines, 'Status', status);
    if (detail) {
      nextLines = updateBlockField(nextLines, 'Latest Sync', detail);
    }

    return {
      ...block,
      lines: nextLines,
    };
  });
}

function mapRailStatus(state: ViviOperatingState, event?: ViviSignalPayload['event']): string {
  if (state === 'FREEZE') return 'frozen';
  if (state === 'RECOVER') return 'recovering';
  if (state === 'REPORT') return event === 'handoff' ? 'handoff-ready' : 'reported';
  if (state === 'VERIFY') return 'verifying';
  if (state === 'EXECUTE') return 'executing';
  if (state === 'PLAN') return 'planned';
  if (state === 'ANALYZE') return 'analyzing';
  if (state === 'INTAKE') return 'accepted';
  return 'queued';
}

function buildLatestReport(payload: ViviSignalPayload, now: string) {
  if (!payload.resultSummary && !payload.outcome && !payload.nextOperatorAction) {
    return undefined;
  }

  return {
    id: buildId('VREP', now),
    kind: payload.reportKind || payload.event || 'result',
    summary: payload.resultSummary || payload.outcome || payload.nextOperatorAction || 'Vivi report captured',
    nextStep: payload.nextOperatorAction || payload.nextAction,
    addedAt: now,
  };
}

function buildReportEntry(
  payload: ViviSignalPayload,
  runtime: ViviRuntimeSnapshot,
  state: ViviStateSnapshot,
  now: string,
): ViviReportEntry | null {
  if (!payload.reportKind && !payload.resultSummary && !payload.outcome && payload.event !== 'handoff') {
    return null;
  }

  return {
    id: buildId('VREP', now),
    addedAt: now,
    kind: payload.reportKind || payload.event || 'result',
    state: state.currentState,
    phase: runtime.mission.phase,
    title: payload.reportTitle || payload.resultSummary || payload.outcome || 'Vivi runtime report',
    summary: payload.resultSummary || payload.outcome || payload.nextOperatorAction || 'Vivi reported an update.',
    outcome: payload.outcome,
    nextStep: payload.nextOperatorAction || runtime.mission.nextAction,
    operatorAction: payload.nextOperatorAction,
    commandRef: payload.commandRef || runtime.mission.commandRef,
  };
}

function buildStep(
  payload: ViviSignalPayload,
  operatingState: ViviOperatingState,
  now: string,
): TimelineEntry {
  const tone = payload.stepTone
    || (payload.event === 'recovery'
      ? 'warning'
      : payload.event === 'verify'
        ? 'ok'
        : payload.event === 'handoff'
          ? 'info'
          : 'info');

  return {
    time: now,
    label: payload.stepLabel || payload.currentAction || `${operatingState} heartbeat received`,
    detail: payload.stepDetail
      || payload.resultSummary
      || payload.outcome
      || payload.nextOperatorAction
      || payload.phase
      || 'No extra detail supplied',
    tone,
  };
}

function mergeSteps(step: TimelineEntry, existing: TimelineEntry[]): TimelineEntry[] {
  return [step, ...existing].slice(0, 12);
}

function normalizeBlockers(payload: ViviSignalPayload['blockers']): BlockerSignal[] {
  if (!Array.isArray(payload)) {
    return [];
  }

  return payload
    .map((item) => {
      if (typeof item === 'string') {
        return { description: item } satisfies BlockerSignal;
      }

      if (!item?.description) {
        return null;
      }

      return {
        description: item.description,
        impact: item.impact,
        workaround: item.workaround,
      } satisfies BlockerSignal;
    })
    .filter((item): item is BlockerSignal => Boolean(item))
    .slice(0, 8);
}

function inferMissionState(state: ViviOperatingState, blockerCount: number): string {
  if (state === 'FREEZE') return 'FROZEN';
  if (state === 'RECOVER') return 'RECOVERING';
  if (blockerCount > 0) return 'BLOCKED';
  if (state === 'IDLE') return 'IDLE';
  return 'ACTIVE';
}

function coerceProgress(input: number | undefined, fallback?: number): number {
  if (typeof input === 'number' && Number.isFinite(input)) {
    return Math.max(0, Math.min(100, Math.round(input)));
  }

  return fallback ?? 0;
}

function normalizeOperatingState(
  explicitState?: string,
  phase?: string,
  currentAction?: string,
  event?: string,
): ViviOperatingState {
  const candidates = [explicitState, phase, currentAction, event]
    .filter(Boolean)
    .join(' ')
    .toUpperCase();

  if (!candidates) return 'IDLE';
  if (candidates.includes('FREEZE') || candidates.includes('FROZEN')) return 'FREEZE';
  if (candidates.includes('RECOVER') || candidates.includes('RESCUE') || candidates.includes('REPAIR')) return 'RECOVER';
  if (candidates.includes('VERIFY') || candidates.includes('VALID') || candidates.includes('TEST') || candidates.includes('QA')) return 'VERIFY';
  if (candidates.includes('REPORT') || candidates.includes('HANDOFF') || candidates.includes('FINAL')) return 'REPORT';
  if (candidates.includes('EXEC') || candidates.includes('BUILD') || candidates.includes('RUN') || candidates.includes('IMPLEMENT')) return 'EXECUTE';
  if (candidates.includes('PLAN') || candidates.includes('SCOPE')) return 'PLAN';
  if (candidates.includes('ANALYZE') || candidates.includes('ANALYSE') || candidates.includes('RESEARCH') || candidates.includes('TRIAGE')) return 'ANALYZE';
  if (candidates.includes('INTAKE') || candidates.includes('REQUEST') || candidates.includes('QUEUE')) return 'INTAKE';
  return 'IDLE';
}

function buildId(prefix: string, iso: string): string {
  const stamp = iso.replace(/[-:TZ]/g, '').replace('.', '').slice(0, 17);
  const entropy = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `${prefix}-${stamp}-${entropy}`;
}

async function appendReportEntry(entry: ViviReportEntry): Promise<void> {
  const block = `### ${entry.id}\n- Added: ${entry.addedAt}\n- Kind: ${entry.kind}\n- State: ${entry.state}\n- Phase: ${entry.phase}\n- Title: ${entry.title}\n- Command Ref: ${entry.commandRef || 'None supplied'}\n- Summary: ${entry.summary}\n- Outcome: ${entry.outcome || 'No explicit outcome supplied'}\n- Next Step: ${entry.nextStep || 'No next step supplied'}\n- Operator Action: ${entry.operatorAction || 'No operator action requested'}\n\n`;

  await ensureFile(
    PATHS.VIVI_REPORTS,
    '# Vivi Reports\n\nAppend-only result, verify, recovery and handoff rail for Vivi.\n\n',
  );
  await fs.appendFile(PATHS.VIVI_REPORTS, block, 'utf-8');
}

function parseViviReports(content: string | null): ViviReportEntry[] {
  if (!content) return [];

  return parseStructuredBlocks(content).map((block) => ({
    id: block.id,
    addedAt: block.fields['Added'] || 'unknown',
    kind: block.fields['Kind'] || 'result',
    state: block.fields['State'] || 'unknown',
    phase: block.fields['Phase'] || 'unknown',
    title: block.fields['Title'] || block.id,
    commandRef: block.fields['Command Ref'],
    summary: block.fields['Summary'] || block.body.slice(0, 160),
    outcome: block.fields['Outcome'],
    nextStep: block.fields['Next Step'],
    operatorAction: block.fields['Operator Action'],
  })).slice(0, 8);
}

function parseStructuredBlocks(content: string): Array<{ id: string; fields: Record<string, string>; body: string }> {
  const blocks: Array<{ id: string; fields: Record<string, string>; body: string }> = [];

  const sections = content
    .split(/^###\s+/m)
    .map((section) => section.trim())
    .filter(Boolean);

  for (const section of sections) {
    const [headline, ...bodyLines] = section.split('\n');
    const id = headline?.trim();
    const body = bodyLines.join('\n').trim();
    const fields: Record<string, string> = {};

    if (!id || id.startsWith('#')) continue;

    for (const line of body.split('\n')) {
      const match = line.match(/^-\s*([^:]+):\s*(.+)$/);
      if (match) {
        fields[match[1].trim()] = match[2].trim();
      }
    }

    blocks.push({ id, fields, body });
  }

  return blocks.reverse();
}

async function maybeEscalateForBridgeIssues(input: {
  payload: ViviSignalPayload;
  runtime: ViviRuntimeSnapshot;
  state: ViviStateSnapshot;
  reportEntry: ViviReportEntry | null;
  transitionWarning?: string;
}): Promise<void> {
  const reference = input.payload.commandRef || input.runtime.mission.commandRef || input.runtime.mission.activeTask;
  if (!reference) return;

  const reasons: string[] = [];
  if (input.transitionWarning) reasons.push(input.transitionWarning);
  if (input.state.currentState === 'FREEZE') reasons.push('Vivi entered FREEZE and needs technical review.');
  if (input.runtime.blockers.length > 0) reasons.push(`Runtime blockers: ${input.runtime.blockers.map((item) => item.description).join(' | ')}`);
  if (input.payload.event === 'handoff') reasons.push('Vivi explicitly created a handoff event.');

  if (reasons.length === 0) {
    return;
  }

  await Promise.all([
    ensureCodexEscalationPacket({
      reference,
      title: `Vivi escalation: ${input.runtime.mission.activeTask || input.runtime.mission.phase || input.state.currentState}`,
      summary: reasons.join(' '),
      priority: input.state.currentState === 'FREEZE' || input.transitionWarning ? 'critical' : 'high',
      context: `State: ${input.state.currentState} / ${input.runtime.mission.phase}`,
      rawRequest: [
        `Reference: ${reference}`,
        `State: ${input.state.currentState}`,
        `Phase: ${input.runtime.mission.phase}`,
        `Current Action: ${input.runtime.mission.currentAction || 'n/a'}`,
        `Next Action: ${input.runtime.mission.nextAction || 'n/a'}`,
        `Reasons: ${reasons.join(' | ')}`,
        `Latest Report: ${input.reportEntry?.summary || 'No explicit report entry.'}`,
      ].join('\n'),
    }),
    ensureRepairPacket({
      reference,
      title: `Repair signal: ${input.runtime.mission.activeTask || input.runtime.mission.phase || input.state.currentState}`,
      severity: input.state.currentState === 'FREEZE' || input.transitionWarning ? 'critical' : 'high',
      problem: reasons.join(' '),
      recommendation: input.state.currentState === 'FREEZE'
        ? 'Freeze the affected mission, review the runtime signal path and resume only after Codex-level verification.'
        : 'Inspect the runtime flow, reconcile Vivi state and verify the next safe step.',
    }),
  ]);
}

async function ensureCodexEscalationPacket(input: {
  reference: string;
  title: string;
  summary: string;
  priority: 'critical' | 'high';
  context: string;
  rawRequest: string;
}): Promise<void> {
  const header = '# Codex Inbox\n\nLocal command packets prepared for Codex-side implementation, review or debugging work.\n\n';
  const existing = parseRailBlocks(await readRailContent(PATHS.CODEX_INBOX));
  const duplicate = existing.find((block) => {
    const reference = block.fields['Reference'];
    const summary = block.fields['Summary'] || '';
    const status = normalizeRailStatus(block.fields['Status']);
    return reference === input.reference && summary === input.summary && !['answered', 'closed'].includes(status);
  });

  if (duplicate) {
    return;
  }

  const now = new Date().toISOString();
  const id = buildId('CDX', now);
  const block = `### ${id}
- Added: ${now}
- Source: Vivi bridge auto-escalation
- Status: queued
- Priority: ${input.priority}
- Title: ${input.title}
- Context: ${input.context}
- Reference: ${input.reference}
- Summary: ${input.summary}
- Routing Note: Automatically escalated from the Vivi runtime bridge because the state machine or runtime trust requires Codex review.
- Raw Request:
${input.rawRequest.split('\n').map((line) => `> ${line}`).join('\n')}

`;

  await appendRailBlock(PATHS.CODEX_INBOX, header, block);
}

async function ensureRepairPacket(input: {
  reference: string;
  title: string;
  severity: 'critical' | 'high';
  problem: string;
  recommendation: string;
}): Promise<void> {
  const header = '# Repair Queue\n\nOperational repair and rescue packets generated by LIONCOM when visibility, runtime safety or core rails need attention.\n\n';
  const existing = parseRailBlocks(await readRailContent(PATHS.REPAIR_QUEUE));
  const duplicate = existing.find((block) => {
    const reference = block.fields['Reference'];
    const title = block.fields['Title'] || '';
    const status = normalizeRailStatus(block.fields['Status']);
    return (reference === input.reference || title === input.title) && !['reported', 'answered', 'closed'].includes(status);
  });

  if (duplicate) {
    return;
  }

  const now = new Date().toISOString();
  const id = buildId('FIX', now);
  const block = `### ${id}
- Added: ${now}
- Source: Vivi runtime guard
- Status: queued
- Severity: ${input.severity}
- Mode: rescue
- Title: ${input.title}
- Reference: ${input.reference}
- Summary: ${input.problem}
- Target: Vivi
- Recommendation: ${input.recommendation}
- Problem:
> ${input.problem}

`;

  await appendRailBlock(PATHS.REPAIR_QUEUE, header, block);
}

function normalizeRailStatus(value?: string): string {
  return value?.trim().toLowerCase() || '';
}

async function safeRead(filePath: string): Promise<string | null> {
  try {
    return await fs.readFile(filePath, 'utf-8');
  } catch {
    return null;
  }
}

function parseJson<T>(content: string | null): T | null {
  if (!content) return null;

  try {
    return JSON.parse(content) as T;
  } catch {
    return null;
  }
}

async function ensureFile(filePath: string, header: string): Promise<void> {
  try {
    await fs.access(filePath);
  } catch {
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    await fs.writeFile(filePath, header, 'utf-8');
  }
}

async function writeJsonAtomic(filePath: string, payload: unknown): Promise<void> {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  const tempPath = `${filePath}.tmp`;
  await fs.writeFile(tempPath, `${JSON.stringify(payload, null, 2)}\n`, 'utf-8');
  await fs.rename(tempPath, filePath);
}
