import 'server-only';

import { promises as fs } from 'fs';

import { PATHS } from '@/lib/constants/paths';
import { loadControlRoomData } from '@/lib/control-room/loadControlRoomData';
import { loadPortfolioExecutionContract, loadPortfolioRepositories } from '@/lib/portfolio-control-tower';
import { loadPortfolioMetrics } from '@/lib/portfolio/portfolio-metrics';
import { loadPortfolioReviewCalendar } from '@/lib/portfolio/review-calendar';
import type {
  BridgePacket,
  CodexChatEntry,
  ControlRoomData,
  SystemAlert,
  TaskItem,
  TimelineEntry,
  ViviReportEntry,
  WorkBlockItem,
  WorkIntakeEntry,
} from '@/lib/control-room/types';
import * as mock from '@/lib/mock-data';
import type {
  ActivitySignal,
  Agent,
  AgentId,
  AgentStatus,
  AgentSummary,
  AlertActionPath,
  AlertItem,
  AutomationTask,
  AuditEvent,
  BacklogItem,
  ChatMessage,
  ControlPlaneLiveData,
  DispatchEvent,
  GlobalStatus,
  GoldenBaselineStatus,
  HandoffQueueItem,
  IntakeRow,
  Mission,
  OperatorLoopStatus,
  PlanningQualitySurface,
  Priority,
  QueueItem,
  RepoSnapshot,
  RuntimeProfile,
  Severity,
  TelemetrySignal,
  Workspace,
} from '@/lib/types';

const MAX_LIST = 8;
const PLANNING_QUALITY_SURFACE_PATH =
  process.env.PIG_QUALITY_OS_SURFACE_PATH ||
  '/Users/BjornRosinger/Documents/DreamFactory/Project-Intelligence-Graph/outputs/project_intelligence_graph/quality_os_operator_surface.json';

const timeFormatter = new Intl.DateTimeFormat('de-DE', {
  hour: '2-digit',
  minute: '2-digit',
  hour12: false,
});

export async function loadControlPlaneV2Data(): Promise<ControlPlaneLiveData> {
  try {
    const [controlRoomData, loopStatus, qualityGate, goldenBaseline, goldenBaselineAutomation, planningQuality] = await Promise.all([
      loadControlRoomData(),
      readJsonFile<LocalDuoLoopRuntimeStatus>(PATHS.LOCAL_DUO_LOOP_STATUS),
      readJsonFile<ViviReportQualityGateStatus>(PATHS.VIVI_REPORT_QUALITY_GATE_STATUS),
      readJsonFile<GoldenBaselineStatus>(PATHS.GOLDEN_BASELINE_STATUS),
      readJsonFile<GoldenBaselineAutomationStatus>(PATHS.GOLDEN_BASELINE_AUTOMATION_STATUS),
      readJsonFile<PlanningQualitySurface>(PLANNING_QUALITY_SURFACE_PATH),
    ]);
    return mapControlRoomData(controlRoomData, loopStatus, qualityGate, goldenBaseline, goldenBaselineAutomation, planningQuality);
  } catch {
    return {
      generatedAt: new Date().toISOString(),
      source: 'fallback',
      operatorLoopStatus: mock.operatorLoopStatus,
      globalStatus: mock.globalStatus,
      agents: mock.agents,
      agentSummaries: mock.agentSummaries,
      missions: mock.missions,
      dispatchEvents: mock.dispatchEvents,
      handoffQueue: mock.handoffQueue,
      telemetrySignals: mock.telemetrySignals,
      alerts: mock.alerts,
      backlogItems: mock.backlogItems,
      auditEvents: mock.auditEvents,
      activitySignals: mock.activitySignals,
      automationTasks: mock.automationTasks,
      queueItems: mock.queueItems,
      chatMessages: mock.chatMessages,
      workspaces: mock.workspaces,
      runtimeProfiles: mock.runtimeProfiles,
      intakeRows: mock.intakeRows,
      repoSnapshots: mock.repoSnapshots,
      portfolioRepositories: mock.portfolioRepositories,
      portfolioExecutionContract: mock.portfolioExecutionContract,
      portfolioMetrics: mock.portfolioMetrics,
      portfolioReviewCalendar: mock.portfolioReviewCalendar,
      planningQuality: mock.planningQuality,
      goldenBaseline: mock.goldenBaseline,
    };
  }
}

interface LocalDuoLoopRuntimeStatus {
  updatedAt?: string;
  state?: string;
  detail?: string;
  lastExitCode?: number;
  lastHeartbeatAt?: string;
  lastClaimId?: string;
  lastClaimTitle?: string;
  lastTaskRef?: string;
  requestedProvider?: string;
  effectiveProvider?: string;
  requestedModel?: string;
  effectiveModel?: string;
  fallbackModel?: string;
  modelState?: string;
  modelDetail?: string;
  lastModelError?: string | null;
  projectLane?: string;
}

interface ViviReportQualityGateStatus {
  checkedAt?: string;
  claimId?: string;
  commandRef?: string;
  title?: string;
  ok?: boolean;
  failures?: Array<{
    id?: string;
    detail?: string;
  }>;
}

interface GoldenBaselineAutomationStatus {
  label?: string;
  checkedAt?: string;
  action?: string;
  reason?: string;
  nextDueAt?: string | null;
  latestBaselineGeneratedAt?: string | null;
  latestBaselineVerdict?: string;
  exitCode?: number | null;
}

async function readJsonFile<T>(filePath: string): Promise<T | null> {
  try {
    return JSON.parse(await fs.readFile(filePath, 'utf8')) as T;
  } catch {
    return null;
  }
}

function mapControlRoomData(
  data: ControlRoomData,
  loopStatus: LocalDuoLoopRuntimeStatus | null,
  qualityGate: ViviReportQualityGateStatus | null,
  goldenBaselineRaw?: GoldenBaselineStatus | null,
  goldenBaselineAutomation?: GoldenBaselineAutomationStatus | null,
  planningQualityRaw?: PlanningQualitySurface | null,
): ControlPlaneLiveData {
  const openWorkIntake = data.workIntake.filter((entry) => isOpenStatus(entry.status));
  const openViviCommandQueue = data.viviCommandQueue.filter(isOpenPacket);
  const openCodexInbox = data.codexInbox.filter(isOpenPacket);
  const openRepairQueue = data.repairQueue.filter(isOpenPacket);
  const openBacklogItems = data.backlog.reduce((sum, lane) => sum + lane.items.filter((item) => isOpenStatus(item.status)).length, 0);
  const openQueue =
    openWorkIntake.length +
    openViviCommandQueue.length +
    openCodexInbox.length +
    openRepairQueue.length +
    data.waitingTasks.length +
    openBacklogItems;
  const criticalAlerts = [...data.alerts, ...data.maintenance].filter((alert) => alert.severity === 'critical').length;
  const warningAlerts = [...data.alerts, ...data.maintenance].filter((alert) => alert.severity === 'warning' || alert.severity === 'maintenance').length;
  const activeMissions = data.workBlocks.filter((block) => block.active).length + data.activeTasks.length;
  const automationHealth = data.qualification.overallState === 'blocked' ? '71%' : data.qualification.overallState === 'warning' ? '86%' : '94%';

  const globalStatus: GlobalStatus = {
    posture: criticalAlerts > 0 || data.autonomy.readiness === 'blocked' ? 'ATTENTION' : warningAlerts > 0 ? 'WARNING' : 'STABIL',
    activeMissions,
    openQueue,
    automationHealth,
    bridgeStatus: bridgeLabel(data.remoteBridge.state),
    lastSignal: `${formatTime(data.generatedAt)} · ${data.timeline[0]?.label ?? data.mission.lastAction}`,
    loopHealth: data.telemetry.state === 'live' ? 'Stabil' : data.telemetry.state === 'stale' ? 'Veraltet' : 'Fehlt',
    queueDepth: openQueue,
    syncStatus: data.telemetry.state === 'live' ? 'Frisch' : 'Veraltet',
    activeClaims: data.autonomy.activeClaims.length,
    watcherPosture: postureLabel(data.autonomy.readiness),
  };
  const operatorLoopStatus = buildOperatorLoopStatus(data, loopStatus, qualityGate);

  const agents = buildAgents(data, globalStatus);
  const agentSummaries = buildAgentSummaries(data);
  const missions = withFallback(buildMissions(data), mock.missions);
  const dispatchEvents = withFallback(buildDispatchEvents(data), mock.dispatchEvents);
  const handoffQueue = withFallback(buildHandoffQueue(data), mock.handoffQueue);
  const telemetrySignals = buildTelemetrySignals(data, globalStatus);
  const alerts = withFallback([...data.alerts, ...data.maintenance].slice(0, MAX_LIST).map(mapAlert), mock.alerts);
  const backlogItems = withFallback(buildBacklogItems(data), mock.backlogItems);
  const auditEvents = withFallback(buildAuditEvents(data), mock.auditEvents);
  const activitySignals = withFallback(buildActivitySignals(data), mock.activitySignals);
  const automationTasks = withFallback(buildAutomationTasks(data), mock.automationTasks);
  const queueItems = withFallback(buildQueueItems(data), mock.queueItems);
  const chatMessages = withFallback(buildChatMessages(data), mock.chatMessages);
  const workspaces = buildWorkspaces(data);
  const runtimeProfiles = buildRuntimeProfiles(data);
  const intakeRows = withFallback(buildIntakeRows(data), mock.intakeRows);
  const repoSnapshots = buildRepoSnapshots(data);
  const portfolioRepositories = loadPortfolioRepositories();
  const portfolioExecutionContract = loadPortfolioExecutionContract();
  const portfolioMetrics = loadPortfolioMetrics();
  const portfolioReviewCalendar = loadPortfolioReviewCalendar();
  const planningQuality = buildPlanningQualitySurface(planningQualityRaw);
  const goldenBaseline = buildGoldenBaselineStatus(goldenBaselineRaw, goldenBaselineAutomation);

  return {
    generatedAt: data.generatedAt,
    source: 'live',
    operatorLoopStatus,
    globalStatus,
    agents,
    agentSummaries,
    missions,
    dispatchEvents,
    handoffQueue,
    telemetrySignals,
    alerts,
    backlogItems,
    auditEvents,
    activitySignals,
    automationTasks,
    queueItems,
    chatMessages,
    workspaces,
    runtimeProfiles,
    intakeRows,
    repoSnapshots,
    portfolioRepositories,
    portfolioExecutionContract,
    portfolioMetrics,
    portfolioReviewCalendar,
    planningQuality,
    goldenBaseline,
  };
}

function buildPlanningQualitySurface(surface?: PlanningQualitySurface | null): PlanningQualitySurface {
  if (!surface) return mock.planningQuality;
  return {
    ...mock.planningQuality,
    ...surface,
    active_build_contracts: Array.isArray(surface.active_build_contracts) ? surface.active_build_contracts : [],
    needs_target_picture: Array.isArray(surface.needs_target_picture) ? surface.needs_target_picture : [],
    approval_nodes: Array.isArray(surface.approval_nodes) ? surface.approval_nodes : [],
    workflow_runs: Array.isArray(surface.workflow_runs) ? surface.workflow_runs : [],
    operator_actions: Array.isArray(surface.operator_actions) ? surface.operator_actions : [],
    run_controls: Array.isArray(surface.run_controls) ? surface.run_controls : [],
    job_cards: Array.isArray(surface.job_cards) ? surface.job_cards : [],
    control_capabilities: surface.control_capabilities || mock.planningQuality.control_capabilities,
    fresh_session_handoff: surface.fresh_session_handoff || mock.planningQuality.fresh_session_handoff,
    governance: surface.governance || mock.planningQuality.governance,
    contract_quality: surface.contract_quality || mock.planningQuality.contract_quality,
    full_check: surface.full_check || mock.planningQuality.full_check,
    last_verifier: surface.last_verifier || mock.planningQuality.last_verifier,
  };
}

function buildGoldenBaselineStatus(
  status?: GoldenBaselineStatus | null,
  automation?: GoldenBaselineAutomationStatus | null,
): GoldenBaselineStatus {
  if (!status) {
    return {
      ...mock.goldenBaseline,
      automation: automation ? normalizeGoldenBaselineAutomation(automation) : undefined,
    };
  }
  const verdict = status.verdict === 'pass' || status.verdict === 'fail' ? status.verdict : 'unknown';
  const failedSteps = Array.isArray(status.failedSteps) ? status.failedSteps.filter(Boolean) : [];
  const generatedAt = status.generatedAt;
  const freshness = normalizeGoldenBaselineFreshness(status.freshness, generatedAt, verdict, status.schedule);
  const ageHours = typeof status.ageHours === 'number' ? status.ageHours : ageHoursSince(generatedAt);

  return {
    generatedAt,
    verdict,
    mode: status.mode || 'unbekannt',
    freshness,
    ageHours,
    nextDueAt: status.nextDueAt || addHours(generatedAt, status.schedule?.intervalHours || 12),
    staleAt: status.staleAt || addHours(generatedAt, status.schedule?.staleAfterHours || 14),
    criticalAt: status.criticalAt || addHours(generatedAt, status.schedule?.criticalAfterHours || 24),
    failedSteps,
    failedCount: Number.isFinite(status.failedCount) ? Number(status.failedCount) : failedSteps.length,
    stepCount: Number.isFinite(status.stepCount) ? Number(status.stepCount) : 0,
    passedSteps: Number.isFinite(status.passedSteps) ? Number(status.passedSteps) : 0,
    reportJsonPath: status.reportJsonPath,
    reportMarkdownPath: status.reportMarkdownPath,
    nextAction: status.nextAction || nextGoldenBaselineAction(verdict, freshness),
    schedule: status.schedule || mock.goldenBaseline.schedule,
    automation: automation ? normalizeGoldenBaselineAutomation(automation) : status.automation,
  };
}

function normalizeGoldenBaselineAutomation(status: GoldenBaselineAutomationStatus) {
  return {
    label: status.label || 'com.lioncom.golden-baseline',
    checkedAt: status.checkedAt,
    action: status.action || 'unknown',
    reason: status.reason,
    nextDueAt: status.nextDueAt,
    latestBaselineGeneratedAt: status.latestBaselineGeneratedAt,
    latestBaselineVerdict: status.latestBaselineVerdict,
    exitCode: typeof status.exitCode === 'number' ? status.exitCode : null,
  };
}

function normalizeGoldenBaselineFreshness(
  freshness: GoldenBaselineStatus['freshness'],
  generatedAt: string | undefined,
  verdict: GoldenBaselineStatus['verdict'],
  schedule: GoldenBaselineStatus['schedule'] | undefined,
): GoldenBaselineStatus['freshness'] {
  if (freshness) return freshness;
  if (!generatedAt) return 'unknown';
  if (verdict === 'fail') return 'failed';
  const age = ageHoursSince(generatedAt);
  if (age === null) return 'unknown';
  if (age >= (schedule?.criticalAfterHours || 24)) return 'critical';
  if (age >= (schedule?.staleAfterHours || 14)) return 'stale';
  return 'fresh';
}

function ageHoursSince(value?: string): number | null {
  if (!value) return null;
  const time = new Date(value).getTime();
  if (!Number.isFinite(time)) return null;
  return Math.max(0, Math.round(((Date.now() - time) / 3_600_000) * 10) / 10);
}

function addHours(value: string | undefined, hours: number): string | null {
  if (!value) return null;
  const time = new Date(value).getTime();
  if (!Number.isFinite(time)) return null;
  return new Date(time + hours * 3_600_000).toISOString();
}

function nextGoldenBaselineAction(
  verdict: GoldenBaselineStatus['verdict'],
  freshness: GoldenBaselineStatus['freshness'],
): string {
  if (verdict === 'fail') return 'Failed Steps reparieren und Golden Baseline erneut starten.';
  if (freshness === 'critical') return 'Golden Baseline sofort neu starten.';
  if (freshness === 'stale') return 'Golden Baseline ist faellig und sollte neu laufen.';
  if (freshness === 'unknown') return 'Golden Baseline einmal ausfuehren.';
  return 'Keine Aktion. Gate ist frisch.';
}

function buildOperatorLoopStatus(
  data: ControlRoomData,
  loopStatus: LocalDuoLoopRuntimeStatus | null,
  qualityGate: ViviReportQualityGateStatus | null,
): OperatorLoopStatus {
  const activeClaim = data.autonomy.activeClaims.find((claim) => claim.agent === 'vivi');
  const gateFailure = qualityGate?.failures?.[0];
  const gateBlocksActiveClaim = qualityGate?.ok === false
    && Boolean(qualityGate.claimId && activeClaim?.id && qualityGate.claimId === activeClaim.id);
  const activeQualityGate = gateBlocksActiveClaim ? qualityGate : null;
  const activeGateFailure = activeQualityGate?.failures?.[0];
  const loopFresh = isFreshIso(loopStatus?.lastHeartbeatAt || loopStatus?.updatedAt, 15);
  const claimTitle = loopStatus?.lastClaimTitle || activeClaim?.title || data.autonomy.viviLoop.selectedTask?.title;
  const claimId = loopStatus?.lastClaimId || activeClaim?.id || data.autonomy.viviLoop.activeClaimId;
  const taskReference = loopStatus?.lastTaskRef || activeClaim?.reference || data.autonomy.viviLoop.selectedTask?.reference;
  const provider = providerLabel(loopStatus?.effectiveProvider || loopStatus?.requestedProvider || data.desktop.viviEffectiveProvider || data.desktop.viviRequestedProvider);
  const model = loopStatus?.effectiveModel || loopStatus?.requestedModel || data.desktop.viviEffectiveModel || data.desktop.viviRequestedModel;

  if (gateBlocksActiveClaim) {
    return {
      state: 'blocked',
      tone: 'warning',
      title: 'Vivi wartet auf Report-Korrektur',
      summary: claimTitle
        ? `Vivi arbeitet weiter an "${operatorText(claimTitle)}", aber das Quality-Gate blockiert den Abschluss.`
        : 'Vivi arbeitet weiter, aber das Quality-Gate blockiert den Abschluss.',
      detail: humanGateDetail(gateFailure?.id, gateFailure?.detail),
      nextAction: 'Korrektur neu starten. Vivi soll den aktuellen Report neu schreiben und /api/health, Raw-HTTP-Probe und lokalen Route-Bridge-Transport sauber trennen.',
      claimId,
      taskTitle: claimTitle ? operatorText(claimTitle) : undefined,
      taskReference,
      lastHeartbeat: formatDateTime(loopStatus?.lastHeartbeatAt || loopStatus?.updatedAt || activeClaim?.lastHeartbeatAt),
      modelProvider: provider,
      modelName: model,
      qualityGate: {
        label: 'Quality Gate blockiert',
        ok: false,
        checkedAt: formatDateTime(qualityGate?.checkedAt),
        failureId: gateFailure?.id,
        failureDetail: humanGateDetail(gateFailure?.id, gateFailure?.detail),
      },
      primaryActionLabel: 'Korrektur neu starten',
    };
  }

  if (!loopStatus && data.autonomy.viviLoop.state === 'ready') {
    return {
      state: 'ready',
      tone: 'success',
      title: 'Vivi ist bereit',
      summary: 'Aktuell läuft keine blockierende Vivi-Claim. Neue Sessions oder Dispatches können Vivi wieder starten.',
      detail: operatorText(data.autonomy.viviLoop.summary),
      nextAction: 'Neue Arbeit über Vivi Command oder Dispatch Bridge anlegen.',
      modelProvider: provider,
      modelName: model,
      qualityGate: {
        label: 'Kein aktueller Gate-Block',
        ok: true,
      },
      primaryActionLabel: 'Vivi starten',
    };
  }

  if (!loopFresh && loopStatus) {
    return {
      state: 'warning',
      tone: 'warning',
      title: 'Vivi-Heartbeat prüfen',
      summary: 'Der letzte lokale Loop-Status ist sichtbar, aber nicht mehr frisch genug für unbeaufsichtigtes Vertrauen.',
      detail: loopStatus.detail ? operatorText(loopStatus.detail) : operatorText(data.autonomy.viviLoop.summary),
      nextAction: 'Vivi neu anstoßen und danach prüfen, ob Heartbeat und Claim-Lease wieder frisch sind.',
      claimId,
      taskTitle: claimTitle ? operatorText(claimTitle) : undefined,
      taskReference,
      lastHeartbeat: formatDateTime(loopStatus.lastHeartbeatAt || loopStatus.updatedAt),
      modelProvider: provider,
      modelName: model,
      qualityGate: {
        label: activeQualityGate?.ok === false ? 'Gate prüfen' : 'Kein aktueller Gate-Block',
        ok: activeQualityGate?.ok !== false,
        checkedAt: formatDateTime(activeQualityGate?.checkedAt),
        failureId: activeGateFailure?.id,
        failureDetail: activeGateFailure?.detail ? humanGateDetail(activeGateFailure.id, activeGateFailure.detail) : undefined,
      },
      primaryActionLabel: 'Vivi neu anstoßen',
    };
  }

  if (data.autonomy.viviLoop.state === 'busy' || loopStatus?.state === 'running') {
    return {
      state: 'running',
      tone: 'success',
      title: 'Vivi arbeitet lokal',
      summary: claimTitle
        ? `Aktiver Lauf: ${operatorText(claimTitle)}.`
        : operatorText(data.autonomy.viviLoop.summary),
      detail: loopStatus?.detail ? operatorText(loopStatus.detail) : operatorText(data.autonomy.viviLoop.summary),
      nextAction: activeQualityGate?.ok === false
        ? 'Gate-Hinweis beobachten. Wenn der gleiche Fehler wiederholt auftaucht, Korrektur neu starten.'
        : 'Keine Aktion nötig. Neue Eingaben können weiter über Vivi Command oder Dispatch Bridge eingehen.',
      claimId,
      taskTitle: claimTitle ? operatorText(claimTitle) : undefined,
      taskReference,
      lastHeartbeat: formatDateTime(loopStatus?.lastHeartbeatAt || loopStatus?.updatedAt || activeClaim?.lastHeartbeatAt),
      modelProvider: provider,
      modelName: model,
      qualityGate: {
        label: activeQualityGate?.ok === false ? 'Gate-Warnung' : 'Quality Gate frei',
        ok: activeQualityGate?.ok !== false,
        checkedAt: formatDateTime(activeQualityGate?.checkedAt),
        failureId: activeGateFailure?.id,
        failureDetail: activeGateFailure?.detail ? humanGateDetail(activeGateFailure.id, activeGateFailure.detail) : undefined,
      },
      primaryActionLabel: 'Vivi neu anstoßen',
    };
  }

  return {
    state: data.autonomy.viviLoop.state === 'blocked' ? 'blocked' : 'ready',
    tone: data.autonomy.viviLoop.state === 'blocked' ? 'critical' : 'info',
    title: data.autonomy.viviLoop.state === 'blocked' ? 'Vivi blockiert' : 'Vivi bereit',
    summary: operatorText(data.autonomy.viviLoop.summary),
    detail: data.autonomy.viviLoop.instructions.map(operatorText).join(' '),
    nextAction: data.autonomy.viviLoop.state === 'blocked'
      ? 'Autonomie-Gate prüfen, bevor weitere Arbeit an Vivi delegiert wird.'
      : 'Neue Arbeit über Vivi Command oder Dispatch Bridge anlegen.',
    claimId,
    taskTitle: claimTitle ? operatorText(claimTitle) : undefined,
    taskReference,
    lastHeartbeat: formatDateTime(loopStatus?.lastHeartbeatAt || loopStatus?.updatedAt || activeClaim?.lastHeartbeatAt),
    modelProvider: provider,
    modelName: model,
    qualityGate: {
      label: activeQualityGate?.ok === false ? 'Gate prüfen' : 'Kein aktueller Gate-Block',
      ok: activeQualityGate?.ok !== false,
      checkedAt: formatDateTime(activeQualityGate?.checkedAt),
      failureId: activeGateFailure?.id,
      failureDetail: activeGateFailure?.detail ? humanGateDetail(activeGateFailure.id, activeGateFailure.detail) : undefined,
    },
    primaryActionLabel: 'Vivi starten',
  };
}

function buildAgents(data: ControlRoomData, status: GlobalStatus): Agent[] {
  const vivi = mock.agents.find((agent) => agent.id === 'vivi')!;
  const vega = mock.agents.find((agent) => agent.id === 'vega')!;
  const viviOpen = data.workIntake.filter((entry) => isOpenStatus(entry.status)).length
    + data.viviCommandQueue.filter(isOpenPacket).length
    + data.autonomy.viviLoop.backlogCount;
  const vegaOpen = data.codexInbox.filter(isOpenPacket).length
    + data.repairQueue.filter(isOpenPacket).length
    + data.autonomy.codexLoop.backlogCount;
  const viviActive = data.workBlocks.filter((block) => block.owner !== 'codex' && block.active).length + data.autonomy.activeClaims.filter((claim) => claim.agent === 'vivi').length;
  const vegaActive = data.workBlocks.filter((block) => block.owner === 'codex' && block.active).length + data.autonomy.activeClaims.filter((claim) => claim.agent === 'codex').length;
  const vegaVerificationCount = Math.max(
    data.subtasks.filter((task) => task.owner === 'codex').length,
    data.codexRuntime.queuedPackets + data.codexRuntime.pendingOperatorMessages,
  );

  return [
    {
      ...vivi,
      status: agentState(data.autonomy.viviLoop.state),
      identity: {
        ...vivi.identity,
        status: localStatus(data.autonomy.viviLoop.state),
        lastSync: freshnessLabel(data.telemetry.freshnessMinutes),
        linkLabel: status.bridgeStatus,
        health: data.telemetry.runtimeResponsive ? 'STABIL' : 'ACHTUNG',
      },
      metrics: [
        metric('vivi-intake', 'Intake', String(viviOpen), `${data.workIntake.filter((entry) => isOpenStatus(entry.status)).length} Eingänge · ${data.viviCommandQueue.filter(isOpenPacket).length} Vivi-Aufträge`, viviOpen),
        metric('vivi-planning', 'Planung', String(data.autonomy.viviLoop.backlogCount), operatorText(data.autonomy.viviLoop.summary), data.autonomy.viviLoop.backlogCount),
        metric('vivi-active', 'Aktive Missionen', String(viviActive), `${data.autonomy.activeClaims.filter((claim) => claim.agent === 'vivi').length} aktive Claims`, viviActive),
        metric('vivi-health', 'Automationszustand', status.automationHealth, operatorText(data.qualification.summary), Number(status.automationHealth.replace('%', ''))),
      ],
    },
    {
      ...vega,
      status: agentState(data.autonomy.codexLoop.state),
      identity: {
        ...vega.identity,
        status: localStatus(data.autonomy.codexLoop.state),
        lastSync: freshnessLabel(data.codexRuntime.oldestQueuedMinutes ?? data.telemetry.freshnessMinutes),
        linkLabel: data.git.isRepo ? data.git.branch : 'Kein Repo',
        health: localStatus(data.githubSync.state),
      },
      metrics: [
        metric('vega-code', 'Code-Aufgaben', String(vegaOpen), `${data.codexInbox.filter(isOpenPacket).length} Vega-Pakete · ${data.repairQueue.filter(isOpenPacket).length} Reparaturen`, vegaOpen),
        metric('vega-verification', 'Verifikationen', String(vegaVerificationCount), operatorText(data.codexRuntime.detail), vegaVerificationCount),
        metric('vega-repo', 'Repository Integrität', data.githubSync.state === 'healthy' ? '98%' : '82%', operatorText(data.githubSync.detail), data.githubSync.state === 'healthy' ? 98 : 82),
        metric('vega-coverage', 'Runtime-Status', localStatus(data.codexRuntime.state), operatorText(data.codexRuntime.watcherRecommendation), data.codexRuntime.pendingOperatorMessages),
      ],
    },
  ];
}

function buildAgentSummaries(data: ControlRoomData): AgentSummary[] {
  return [
    {
      agentId: 'vivi',
      status: data.autonomy.viviLoop.state,
      intakeCount: data.workIntake.filter((entry) => isOpenStatus(entry.status)).length + data.viviCommandQueue.filter(isOpenPacket).length,
      planningQueue: data.autonomy.viviLoop.backlogCount,
      activeMissions: data.workBlocks.filter((block) => block.owner !== 'codex' && block.active).length,
      lastAction: operatorText(data.viviSteps[0]?.label ?? data.mission.lastAction),
    },
    {
      agentId: 'vega',
      status: data.autonomy.codexLoop.state,
      intakeCount: data.codexInbox.filter(isOpenPacket).length + data.repairQueue.filter(isOpenPacket).length,
      planningQueue: data.autonomy.codexLoop.backlogCount,
      activeMissions: data.workBlocks.filter((block) => block.owner === 'codex' && block.active).length,
      lastAction: operatorText(data.codexChat[0]?.summary ?? data.git.lastCommit ?? data.codexRuntime.detail),
    },
  ];
}

function buildMissions(data: ControlRoomData): Mission[] {
  const activeClaims = data.autonomy.activeClaims.slice(0, 3).map((claim): Mission => ({
    id: claim.id,
    title: operatorText(claim.title),
    ownerAgentId: claim.agent === 'codex' ? 'vega' : 'vivi',
    status: 'active',
    priority: priorityFromText(claim.priority || claim.reason),
    progress: claim.agent === 'vivi' ? 62 : 55,
    lastUpdate: formatTime(claim.lastHeartbeatAt || claim.claimedAt),
    nextStep: `Aktiver Lauf. Lease bis ${formatTime(claim.leaseUntil)}; Details im aktuellen Claim-Log prüfen.`,
    handoffHistory: [operatorText(claim.sourceRail), operatorText(claim.claimState), claim.agent === 'codex' ? 'Vega führt aus' : 'Vivi führt aus'],
  }));
  const toBlockMission = (block: WorkBlockItem): Mission => {
    const status = missionStatus(block);
    return {
      id: block.id,
      title: operatorText(block.title),
      ownerAgentId: block.owner === 'codex' ? 'vega' : 'vivi',
      status,
      priority: priorityFromText(block.priority),
      progress: missionProgress(block.overallScore, status),
      lastUpdate: formatTime(data.generatedAt),
      nextStep: status === 'done'
        ? 'Abgeschlossen. Details bleiben im Audit-Log nachvollziehbar.'
        : operatorText(block.desiredOutcome || block.summary),
      handoffHistory: [operatorText(block.sourceRail), operatorText(block.stage), block.requiresCodex ? 'Vivi → Vega möglich' : 'Vivi-Orchestrierung'],
    };
  };

  const orderedBlocks = [...data.workBlocks].sort((left, right) => {
    if (left.active !== right.active) return left.active ? -1 : 1;
    return priorityRank(priorityFromText(right.priority)) - priorityRank(priorityFromText(left.priority));
  });
  const openBlocks = orderedBlocks.filter((block) => block.active).map(toBlockMission);
  const completedBlocks = orderedBlocks.filter((block) => !block.active).map(toBlockMission);

  const taskMissions = [...data.activeTasks, ...data.waitingTasks]
    .filter((task) => !isLegacyPlaceholderTask(task))
    .map((task, index): Mission => ({
      id: task.id,
      title: operatorText(task.title),
      ownerAgentId: task.owner?.toLowerCase().includes('codex') ? 'vega' : 'vivi',
      status: task.status.toLowerCase().includes('wait') ? 'intake' : 'active',
      priority: priorityFromText(task.priority),
      progress: taskMissionProgress(task.status, index),
      lastUpdate: formatTime(task.deadline || data.generatedAt),
      nextStep: operatorText(task.detail || 'Nächsten Operator-Schritt klären'),
      handoffHistory: [task.owner || 'System-Queue', operatorText(task.status)],
    }));

  return [...activeClaims, ...openBlocks, ...taskMissions, ...completedBlocks].slice(0, MAX_LIST) satisfies Mission[];
}

function taskMissionProgress(status: string, index: number): number {
  const normalized = status.toLowerCase();
  if (normalized.includes('done')) return 100;
  if (normalized.includes('active') || normalized.includes('progress')) return Math.min(86, 52 + (index % 4) * 7);
  if (normalized.includes('wait') || normalized.includes('queue')) return Math.min(48, 18 + (index % 5) * 6);
  return Math.min(72, 34 + (index % 5) * 8);
}

function isLegacyPlaceholderTask(task: TaskItem): boolean {
  const text = `${task.id} ${task.title} ${task.detail} ${task.status}`.toLowerCase();
  return text.includes('no waiting task')
    || text.includes('no completed task')
    || text.includes('control plane idle')
    || text.includes('kontrollebene idle')
    || text.includes('board synchronized');
}

function buildDispatchEvents(data: ControlRoomData): DispatchEvent[] {
  const packets = [
    ...data.repairQueue.map((packet) => ({ packet, mode: 'Direkt an Vega' as const, type: 'Repair' })),
    ...data.codexInbox.map((packet) => ({ packet, mode: 'Direkt an Vega' as const, type: 'Code' })),
    ...data.viviCommandQueue.map((packet) => ({ packet, mode: 'Vivi zuerst' as const, type: 'Mission' })),
    ...data.workIntake.map((entry) => ({ packet: intakeToPacket(entry), mode: 'Vivi zuerst' as const, type: entry.category || 'Mission' })),
  ];

  return [...packets]
    .sort((left, right) => compareTimestampDesc(left.packet.addedAt, right.packet.addedAt))
    .slice(0, MAX_LIST)
    .map(({ packet, mode, type }) => ({
    id: `dispatch-${packet.id}`,
    time: formatTime(packet.addedAt),
    title: operatorText(packet.title),
    type,
    targetMode: dispatchTargetModeFromText(packet.dispatchTargetMode)
      ?? (packet.channel === 'repair' ? 'Direkt an Vega' : packet.target?.toLowerCase().includes('codex') || packet.target?.toLowerCase().includes('vega') ? 'Direkt an Vega' : mode),
    priority: priorityFromText(packet.priority || packet.category || packet.summary),
    status: operatorText(packet.status),
  }));
}

function buildHandoffQueue(data: ControlRoomData): HandoffQueueItem[] {
  const entries: HandoffQueueItem[] = [
    ...data.workIntake.slice(0, 3).map((entry) => ({
      id: `hq-intake-${entry.id}`,
      column: 'eingehend' as const,
      title: operatorText(entry.title),
      agentId: 'vivi' as const,
      priority: priorityFromText(entry.urgency),
      status: operatorText(entry.status),
    })),
    ...data.viviCommandQueue.slice(0, 3).map((packet) => packetQueueItem(packet, 'vivi')),
    ...data.codexInbox.slice(0, 3).map((packet) => packetQueueItem(packet, 'vega')),
    ...data.repairQueue.slice(0, 3).map((packet) => packetQueueItem(packet, 'blockiert')),
  ];

  return entries.slice(0, MAX_LIST);
}

function buildTelemetrySignals(data: ControlRoomData, status: GlobalStatus): TelemetrySignal[] {
  const healthValue = Number(status.automationHealth.replace('%', '')) || 0;
  return [
    signal('tel-queue', 'Queue-Tiefe', String(status.queueDepth), `${data.waitingTasks.length} wartend · ${data.activeTasks.length} aktiv`, 'Quelle: Eingang, Vivi-Queue, Vega-Inbox, Reparatur-Queue, Backlog', status.queueDepth, status.queueDepth > 40 ? 'warning' : 'healthy'),
    signal('tel-loop', 'Vivi-Telemetrie-Frische', data.telemetry.freshnessMinutes === undefined ? 'n/a' : `${data.telemetry.freshnessMinutes}m`, operatorText(data.telemetry.detail), 'Quelle: Vivi Runtime-Telemetrie / lokaler Duo-Loop', data.telemetry.freshnessMinutes ?? 12, data.telemetry.state === 'live' ? 'healthy' : 'warning'),
    signal('tel-success', 'Systemzustand', status.automationHealth, operatorText(data.qualification.summary), 'Quelle: Qualification Snapshot + ControlRoomData', healthValue, healthValue > 80 ? 'healthy' : 'warning'),
    signal('tel-error', 'Alarmdruck', String(data.alerts.length + data.maintenance.length), `${data.alerts.length} Alarme · ${data.maintenance.length} Wartung`, 'Quelle: Alerts und Maintenance Rails', data.alerts.length + data.maintenance.length, data.alerts.some((alert) => alert.severity === 'critical') ? 'critical' : 'warning'),
    signal('tel-runtime', 'Vivi Runtime-Modell', data.desktop.viviEffectiveProvider || data.desktop.viviRequestedProvider || 'lokal', data.desktop.viviEffectiveModel || data.desktop.viviRequestedModel || operatorText(data.desktop.startupDetail), 'Quelle: Desktop Runtime Settings / Vivi Provider', 74, 'standby'),
  ];
}

function buildBacklogItems(data: ControlRoomData): BacklogItem[] {
  const laneItems = data.backlog.flatMap((lane) =>
    lane.items.map((item) => ({
      id: item.id,
      title: operatorText(item.title),
      source: lane.lane,
      recommendedAgentId: recommendedAgent(item.title, lane.lane, item.owner),
      age: item.deadline ? formatTime(item.deadline) : freshnessLabel(data.telemetry.freshnessMinutes),
      priority: priorityFromText(item.priority),
      status: backlogStatus(item.status, lane.lane),
      description: operatorText(item.detail || item.title),
      reasonOpen: operatorText(item.status || 'Offener Queue-Eintrag'),
      nextStep: recommendedAgent(item.title, lane.lane, item.owner) === 'vega' ? 'An Vega zur technischen Prüfung routen.' : 'An Vivi zur Intake- und Routing-Klärung geben.',
    })),
  );

  const repairItems = data.repairQueue.map((packet): BacklogItem => ({
    id: packet.id,
    title: operatorText(packet.title),
    source: 'Reparatur-Queue',
    recommendedAgentId: 'vega' as const,
    age: formatTime(packet.addedAt),
    priority: priorityFromText(packet.category || packet.summary),
    status: packet.status.toLowerCase().includes('block') ? 'blocked' : 'repair',
    description: operatorText(packet.summary),
    reasonOpen: operatorText(packet.status),
    nextStep: 'An Vega routen und technische Hinweise prüfen.',
  }));

  return [...laneItems, ...repairItems].slice(0, MAX_LIST) satisfies BacklogItem[];
}

function buildAuditEvents(data: ControlRoomData): AuditEvent[] {
  const timelineEvents = data.timeline.slice(0, 5).map((entry, index): AuditEvent => ({
    id: `audit-timeline-${index}`,
    time: formatTime(entry.time),
    source: sourceFromText(entry.label),
    event: operatorText(entry.label),
    type: auditType(entry.label),
    agentId: agentFromText(`${entry.label} ${entry.detail ?? ''}`),
    reference: operatorText(entry.detail || data.mission.phase),
    severity: severityFromTone(entry.tone),
    payload: entry.detail ? `Kurzinfo: ${operatorText(entry.detail)}` : 'Kurzinfo: Systemsignal ohne Zusatzdetails',
    before: 'Vorheriger Kontrollstatus',
    after: operatorText(entry.label),
    traceId: `trace-v2-${index + 1}`,
  }));

  const codexEvents = data.codexChat.slice(0, 3).map((entry): AuditEvent => ({
    id: `audit-codex-${entry.id}`,
    time: formatTime(entry.addedAt),
    source: 'Vega' as const,
    event: operatorText(entry.summary),
    type: 'Verification' as const,
    agentId: 'vega' as const,
    reference: entry.reference || entry.id,
    severity: entry.status.toLowerCase().includes('fail') ? 'warning' : 'info',
    payload: `Operatorfreundliche Notiz: ${operatorText(entry.message || entry.summary)}`,
    before: 'Vega-Queue',
    after: operatorText(entry.status),
    traceId: `trace-codex-${entry.id}`,
  }));

  return [...timelineEvents, ...codexEvents].slice(0, MAX_LIST) satisfies AuditEvent[];
}

function buildActivitySignals(data: ControlRoomData): ActivitySignal[] {
  const timeline = data.timeline.slice(0, 4).map((entry, index) => activityFromTimeline(entry, index));
  const vivi = data.viviSteps.slice(0, 3).map((entry, index) => ({
    id: `sig-vivi-live-${index}`,
    agentId: 'vivi' as const,
    time: formatTime(entry.time),
    actor: 'Vivi',
    label: operatorText(entry.label),
    detail: operatorText(entry.detail || data.mission.lastAction),
    type: 'VIVI',
  }));
  const codex = data.codexChat.slice(0, 3).map((entry, index) => ({
    id: `sig-vega-live-${index}`,
    agentId: 'vega' as const,
    time: formatTime(entry.addedAt),
    actor: 'Vega',
    label: operatorText(entry.summary),
    detail: operatorText(entry.message || entry.status),
    type: 'VEGA',
  }));

  return [...timeline, ...vivi, ...codex].slice(0, MAX_LIST);
}

function buildAutomationTasks(data: ControlRoomData): AutomationTask[] {
  return data.automations.slice(0, MAX_LIST).map((automation) => ({
    id: automation.id,
    agentId: recommendedAgent(automation.name, automation.detail),
    title: operatorText(automation.name),
    description: `${operatorSchedule(automation.schedule)} · ${operatorText(automation.detail)}`,
    status: automation.status === 'warning' || automation.status === 'offline' ? 'warning' : automation.status === 'scheduled' ? 'paused' : 'active',
  }));
}

function operatorSchedule(schedule: string): string {
  const normalized = schedule.trim().toLowerCase();
  if (normalized === 'event-driven') return 'ereignisgesteuert';
  if (normalized === 'on demand') return 'bei Bedarf';
  if (normalized === 'not visible') return 'nicht sichtbar';
  if (/^\d/.test(normalized) || normalized.includes('*')) return `Zeitplan ${schedule}`;
  return operatorText(schedule);
}

function buildQueueItems(data: ControlRoomData): QueueItem[] {
  const subtasks = data.subtasks.slice(0, 6).map((task): QueueItem => ({
    id: task.id,
    agentId: task.owner === 'codex' ? 'vega' : 'vivi',
    title: operatorText(task.title),
    type: task.lane,
    priority: priorityFromText(task.detail),
    status: operatorText(task.status),
    updatedAt: formatTime(data.generatedAt),
    progress: task.status === 'done' ? 100 : task.status === 'active' ? 62 : 12,
  }));
  const packets = [...data.viviCommandQueue, ...data.codexInbox, ...data.repairQueue].slice(0, 6).map((packet): QueueItem => ({
    id: `queue-${packet.id}`,
    agentId: packet.channel === 'vivi' || packet.target?.toLowerCase().includes('vivi') ? 'vivi' : 'vega',
    title: operatorText(packet.title),
    type: packet.channel,
    priority: priorityFromText(packet.category || packet.summary),
    status: operatorText(packet.status),
    updatedAt: formatTime(packet.addedAt),
    progress: packet.status.toLowerCase().includes('done') ? 100 : 35,
  }));

  return [...subtasks, ...packets].slice(0, MAX_LIST) satisfies QueueItem[];
}

function buildChatMessages(data: ControlRoomData): ChatMessage[] {
  const viviReports = data.viviReports.slice(0, 4).map((report) => messageFromViviReport(report));
  const codexMessages = data.codexChat.slice(0, 4).map((entry) => messageFromCodex(entry));
  const viviQueue = data.viviCommandQueue.slice(0, 2).map((packet) => messageFromPacket(packet, 'vivi'));

  return [...viviReports, ...viviQueue, ...codexMessages].slice(0, MAX_LIST);
}

function buildWorkspaces(data: ControlRoomData): Workspace[] {
  return mock.workspaces.map((workspace) => {
    if (workspace.agentId === 'vivi' && workspace.id === 'vivi-operator-requests') {
      return { ...workspace, unreadCount: data.viviCommandQueue.length, updatedAt: formatTime(data.generatedAt), status: data.autonomy.viviLoop.state };
    }
    if (workspace.agentId === 'vega' && workspace.id === 'vega-code-tasks') {
      return { ...workspace, unreadCount: data.codexInbox.length + data.repairQueue.length, updatedAt: formatTime(data.generatedAt), status: data.autonomy.codexLoop.state };
    }
    return workspace;
  });
}

function buildRuntimeProfiles(data: ControlRoomData): RuntimeProfile[] {
  return mock.runtimeProfiles.map((profile) => {
    if (profile.agentId === 'vivi') {
      return {
        ...profile,
        provider: providerLabel(data.desktop.viviEffectiveProvider || data.desktop.viviRequestedProvider),
        model: data.desktop.viviEffectiveModel || data.desktop.viviRequestedModel || profile.model,
        requestedProvider: providerLabel(data.desktop.viviRequestedProvider),
        requestedModel: data.desktop.viviRequestedModel,
        effectiveProvider: providerLabel(data.desktop.viviEffectiveProvider),
        effectiveModel: data.desktop.viviEffectiveModel,
        fallbackModel: data.desktop.viviFallbackModel || profile.fallbackModel,
        latency: data.telemetry.freshnessMinutes === undefined ? profile.latency : `${Math.max(20, data.telemetry.freshnessMinutes * 10)} ms`,
        lastSync: freshnessLabel(data.telemetry.freshnessMinutes),
        status: localStatus(data.desktop.viviModelState || (data.telemetry.runtimeResponsive ? 'healthy' : 'warning')),
        modelDetail: data.desktop.viviModelDetail,
        modelLastError: data.desktop.viviModelLastError,
        workspace: { ...profile.workspace, path: data.desktop.workspaceRoot, lastSync: freshnessLabel(data.telemetry.freshnessMinutes) },
      };
    }

    return {
      ...profile,
      provider: 'Vega Runtime',
      model: profile.model,
      fallbackModel: profile.fallbackModel,
      lastSync: freshnessLabel(data.codexRuntime.oldestQueuedMinutes ?? data.telemetry.freshnessMinutes),
      status: localStatus(data.githubSync.state),
      modelDetail: operatorText(data.codexRuntime.detail),
      workspace: {
        ...profile.workspace,
        repo: data.githubSync.remoteUrl || profile.workspace.repo,
        path: data.workspaceRoot,
        branch: data.git.branch,
        lastSync: freshnessLabel(data.codexRuntime.oldestQueuedMinutes ?? data.telemetry.freshnessMinutes),
      },
    };
  });
}

function buildIntakeRows(data: ControlRoomData): IntakeRow[] {
  return data.workIntake.slice(0, 5).map((entry) => ({
    id: entry.id,
    agentId: 'vivi',
    title: operatorText(entry.title),
    status: operatorText(entry.status),
    priority: priorityFromText(entry.urgency) === 'critical' ? 'critical' : priorityFromText(entry.urgency) === 'high' ? 'high' : 'normal',
    updatedAt: formatTime(entry.addedAt),
  }));
}

function buildRepoSnapshots(data: ControlRoomData): RepoSnapshot[] {
  const base = mock.repoSnapshots[0];
  return [
    {
      ...base,
      branch: data.git.branch,
      lastCommit: data.git.lastCommit?.slice(0, 8) || base.lastCommit,
      commitMessage: operatorText(data.githubSync.detail || data.codexRuntime.detail),
      author: data.githubSync.authMode ? `GitHub Sync (${data.githubSync.authMode})` : base.author,
      reviewTarget: data.githubSync.pushReady === 'yes' ? 'Remote bereit' : 'Lokale Prüfung',
    },
  ];
}

function mapAlert(alert: SystemAlert): AlertItem {
  const action = deriveAlertActionPath(alert);
  return {
    id: alert.id,
    severity: severityFromAlert(alert.severity),
    source: sourceFromText(alert.source),
    message: operatorText(alert.title),
    time: formatTime(alert.detail),
    status: operatorText(alert.actionLabel || alert.action),
    group: action.group,
    actionPath: action.actionPath,
    actionLabel: action.actionLabel,
    recommendation: action.recommendation,
    nextStep: action.nextStep,
  };
}

function deriveAlertActionPath(alert: SystemAlert): {
  group: string;
  actionPath: AlertActionPath;
  actionLabel: string;
  recommendation: string;
  nextStep: string;
} {
  const text = `${alert.id} ${alert.title} ${alert.detail} ${alert.recommendation} ${alert.source} ${alert.actionLabel ?? ''}`.toLowerCase();
  const recommendation = operatorText(alert.recommendation || alert.detail || 'Alert lokal prüfen und erst nach Verifikation weiter eskalieren.');

  if (text.includes('github') || text.includes('git-g') || text.includes('403') || text.includes('write access') || text.includes('auth')) {
    return {
      group: 'GitHub / Auth / Sync',
      actionPath: 'operator_gate',
      actionLabel: 'Operator-Gate',
      recommendation,
      nextStep: 'Lokal weiterarbeiten; Auth-, Token- oder Remote-Schritte erst nach Operator-Go öffnen.',
    };
  }

  if (text.includes('bridge') || text.includes('telegram') || text.includes('vps') || text.includes('remote')) {
    return {
      group: 'Bridge / Remote',
      actionPath: 'operator_gate',
      actionLabel: 'Operator-Gate',
      recommendation,
      nextStep: 'Lokalen Fallback als Wahrheit nutzen; Bridge-Aktivierung oder externe Zustellung erst nach Operator-Go.',
    };
  }

  if (alert.action === 'rescue' || text.includes('rebuild') || text.includes('repair') || text.includes('wiederher')) {
    return {
      group: 'Reparatur',
      actionPath: 'reparatur',
      actionLabel: 'Reparaturpfad',
      recommendation,
      nextStep: 'Lokales Rettungspaket ableiten, kleinsten Fix bauen und denselben Verifier erneut laufen lassen.',
    };
  }

  if (alert.action === 'queue-night' || text.includes('night') || text.includes('cron') || text.includes('wartung')) {
    return {
      group: 'Nachtlauf / Wartung',
      actionPath: 'nachtfix',
      actionLabel: 'Nacht-Fix',
      recommendation,
      nextStep: 'Als lokalen Wartungsblock einreihen, bis der nächste Langlauf ihn verifiziert abarbeitet.',
    };
  }

  if (alert.action === 'review' || text.includes('review') || text.includes('analyse') || text.includes('blocker')) {
    return {
      group: 'Analyse',
      actionPath: 'analyse',
      actionLabel: 'Analysepfad',
      recommendation,
      nextStep: 'Evidence, Quelle und Auswirkung prüfen; danach Reparatur, Gate oder Beobachtung eindeutig setzen.',
    };
  }

  return {
    group: 'Beobachtung',
    actionPath: 'beobachten',
    actionLabel: 'Beobachten',
    recommendation,
    nextStep: 'Weiter beobachten und erst aktiv werden, wenn ein Verifier kippt oder ein Operator-Gate sichtbar wird.',
  };
}

function metric(id: string, label: string, value: string, detail: string, seed: number) {
  return { id, label, value, detail, sparkline: series(seed) };
}

function signal(
  id: string,
  title: string,
  value: string,
  detail: string,
  sourceLabel: string,
  seed: number,
  status: TelemetrySignal['status'],
): TelemetrySignal {
  return { id, title, value, detail, sourceLabel, status, series: series(seed) };
}

function packetQueueItem(packet: BridgePacket, column: HandoffQueueItem['column']): HandoffQueueItem {
  return {
    id: `hq-${packet.channel}-${packet.id}`,
    column,
    title: operatorText(packet.title),
    agentId: column === 'vivi' ? 'vivi' : 'vega',
    priority: priorityFromText(packet.category || packet.summary),
    status: operatorText(packet.status),
  };
}

function activityFromTimeline(entry: TimelineEntry, index: number): ActivitySignal {
  const agentId = agentFromText(`${entry.label} ${entry.detail ?? ''}`) ?? 'vivi';
  return {
    id: `sig-live-${index}`,
    agentId,
    time: formatTime(entry.time),
    actor: agentId === 'vega' ? 'Vega' : 'Vivi',
    label: operatorText(entry.label),
    detail: operatorText(entry.detail || entry.label),
    type: entry.tone.toUpperCase(),
  };
}

function messageFromViviReport(report: ViviReportEntry): ChatMessage {
  return {
    id: `vivi-report-${localId(report.id)}`,
    agentId: 'vivi',
    sender: 'vivi',
    time: formatTime(report.addedAt),
    body: operatorText(report.summary || report.outcome || report.nextStep || report.title),
    status: report.state === 'done' ? 'read' : 'queued',
  };
}

function messageFromCodex(entry: CodexChatEntry): ChatMessage {
  return {
    id: `codex-chat-${localId(entry.id)}`,
    agentId: 'vega',
    sender: entry.role === 'operator' ? 'operator' : entry.role === 'system' ? 'system' : 'vega',
    time: formatTime(entry.addedAt),
    body: operatorText(entry.message || entry.summary),
    status: entry.status.toLowerCase().includes('pending') ? 'queued' : 'read',
  };
}

function messageFromPacket(packet: BridgePacket, agentId: AgentId): ChatMessage {
  return {
    id: `packet-message-${localId(packet.id)}`,
    agentId,
    sender: packet.source?.toLowerCase().includes('operator') ? 'operator' : 'system',
    time: formatTime(packet.addedAt),
    body: operatorText(packet.summary || packet.title),
    status: packet.status.toLowerCase().includes('queued') ? 'queued' : 'read',
  };
}

function localId(value: string): string {
  const normalized = value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);
  return normalized || 'entry';
}

function intakeToPacket(entry: WorkIntakeEntry): BridgePacket {
  return {
    id: entry.id,
    channel: 'vivi',
    addedAt: entry.addedAt,
    status: entry.status,
    title: entry.title,
    summary: entry.summary,
    category: entry.urgency,
  };
}

function missionStatus(block: WorkBlockItem): Mission['status'] {
  const status = block.stage.toLowerCase();
  if (!block.active) return 'done';
  if (status.includes('block')) return 'blocked';
  if (status.includes('review') || status.includes('verify') || status.includes('valid')) return 'review';
  if (status.includes('plan')) return 'planning';
  if (status.includes('intake') || status.includes('queue')) return 'intake';
  return 'active';
}

function missionProgress(score: number | undefined, status: Mission['status']): number {
  if (status === 'done') return 100;
  if (status === 'blocked') return clamp(Math.round(score ?? 18), 12, 40);
  if (status === 'review') return clamp(Math.round(score ?? 78), 55, 95);
  if (status === 'planning') return clamp(Math.round(score ?? 35), 20, 70);
  if (status === 'intake') return clamp(Math.round(score ?? 18), 8, 45);
  return clamp(Math.round(score ?? 62), 25, 92);
}

function backlogStatus(status: string, lane: string): BacklogItem['status'] {
  const value = `${status} ${lane}`.toLowerCase();
  if (value.includes('block')) return 'blocked';
  if (value.includes('stale')) return 'stale';
  if (value.includes('repair')) return 'repair';
  if (value.includes('triage')) return 'triage';
  return 'open';
}

function agentState(state: string): AgentStatus {
  if (state === 'busy') return 'busy';
  if (state === 'attention' || state === 'blocked') return 'warning';
  if (state === 'ready') return 'ready';
  return 'active';
}

function recommendedAgent(title: string, source = '', owner = ''): AgentId {
  const text = `${title} ${source} ${owner}`.toLowerCase();
  return /codex|vega|code|repo|commit|repair|debug|test|verification|github|diff/.test(text) ? 'vega' : 'vivi';
}

function agentFromText(text: string): AgentId | undefined {
  const value = text.toLowerCase();
  if (/vega|codex|code|repo|commit|test|verification|repair/.test(value)) return 'vega';
  if (/vivi|intake|planning|mission|operator/.test(value)) return 'vivi';
  return undefined;
}

function priorityFromText(value?: string | null): Priority {
  const text = (value || '').toLowerCase();
  if (/critical|kritisch|block/.test(text)) return 'critical';
  if (/high|hoch|urgent/.test(text)) return 'high';
  if (/low|explore|niedrig/.test(text)) return 'low';
  return 'normal';
}

function priorityRank(priority: Priority): number {
  if (priority === 'critical') return 4;
  if (priority === 'high') return 3;
  if (priority === 'normal') return 2;
  return 1;
}

function isOpenPacket(packet: BridgePacket): boolean {
  return isOpenStatus(packet.status);
}

function isOpenStatus(status?: string | null): boolean {
  const value = (status || '').trim().toLowerCase();
  if (!value) return true;
  if (/(done|closed|answered|reported|complete|completed|archived|removed|parked|released|resolved|abgeschlossen|erledigt|geschlossen)/.test(value)) {
    return false;
  }
  return true;
}

function dispatchTargetModeFromText(value?: string | null): DispatchEvent['targetMode'] | undefined {
  const text = (value || '').toLowerCase();
  if (!text) return undefined;
  if (text.includes('handoff') || text.includes('übergabe') || text.includes('vivi → vega') || text.includes('vivi -> vega')) return 'Vivi → Vega Handoff';
  if (text.includes('nur review') || text.includes('nur prüfung') || text.includes('review')) return 'Nur Review';
  if (text.includes('direkt') && (text.includes('vega') || text.includes('codex'))) return 'Direkt an Vega';
  if (text.includes('vivi')) return 'Vivi zuerst';
  return undefined;
}

function severityFromAlert(severity: SystemAlert['severity']): Severity {
  if (severity === 'critical') return 'critical';
  if (severity === 'warning' || severity === 'maintenance') return 'warning';
  return 'info';
}

function severityFromTone(tone: TimelineEntry['tone']): Severity {
  if (tone === 'critical') return 'critical';
  if (tone === 'warning') return 'warning';
  if (tone === 'ok') return 'success';
  return 'info';
}

function sourceFromText(source: string): AlertItem['source'] {
  const value = source.toLowerCase();
  if (value.includes('vivi')) return 'Vivi';
  if (value.includes('vega') || value.includes('codex') || value.includes('git')) return 'Vega';
  if (value.includes('bridge') || value.includes('telegram')) return 'Bridge';
  if (value.includes('operator')) return 'Operator';
  return 'System';
}

function auditType(label: string): AuditEvent['type'] {
  const value = label.toLowerCase();
  if (value.includes('handoff') || value.includes('bridge')) return 'Handoff';
  if (value.includes('dispatch')) return 'Dispatch';
  if (value.includes('commit') || value.includes('git')) return 'Commit';
  if (value.includes('verify') || value.includes('test')) return 'Verification';
  if (value.includes('alert') || value.includes('warn')) return 'Alert';
  if (value.includes('automation') || value.includes('sync')) return 'Automation';
  return 'Mission';
}

function bridgeLabel(state: ControlRoomData['remoteBridge']['state']): string {
  if (state === 'live-remote' || state === 'local-ready') return 'ONLINE';
  if (state === 'stale-remote' || state === 'planned') return 'WARNING';
  return 'OFFLINE';
}

function postureLabel(state: ControlRoomData['autonomy']['readiness']): string {
  if (state === 'ready') return 'Stabil';
  if (state === 'warning') return 'Achtung';
  return 'Blockiert';
}

function providerLabel(provider?: string): string {
  if (!provider) return 'Lokale Runtime';
  if (provider === 'lmstudio') return 'LM Studio';
  if (provider === 'ollama') return 'Ollama';
  if (provider === 'chatgpt') return 'ChatGPT';
  return provider;
}

function isFreshIso(value: string | undefined, maxAgeMinutes: number): boolean {
  if (!value) return false;
  const time = new Date(value).getTime();
  if (!Number.isFinite(time)) return false;
  return Date.now() - time <= maxAgeMinutes * 60_000;
}

function formatDateTime(value: string | undefined): string | undefined {
  if (!value) return undefined;
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return value;
  return new Intl.DateTimeFormat('de-DE', {
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  }).format(date);
}

function humanGateDetail(id: string | undefined, detail: string | undefined): string {
  if (id === 'contradictory_raw_http_truth') {
    return 'Vivi hat im Abschlussreport zwei Dinge vermischt: Die App-Health ist erreichbar, gleichzeitig behauptet der Report aber, Raw-HTTP 4107/3007 sei unerreichbar. Das ist wahrscheinlich Report-Drift, nicht automatisch ein App-Ausfall.';
  }
  if (id === 'missing_source_gate') {
    return 'Im Vivi-Report fehlt die Source-Gate-Zeile. Bei internen LIONCOM-Aufträgen reicht künftig eine interne Runner-Evidence-Warnung; bei externen Fakten bleibt das Gate hart.';
  }
  if (id === 'source_gate_inferred_internal') {
    return 'Interner LIONCOM-Report ohne externe Fakten. Das Source-Gate wurde als nicht anwendbar behandelt; Vivi soll die Zeile beim nächsten Report trotzdem sichtbar schreiben.';
  }

  if (detail) return operatorText(detail);
  return 'Das Quality-Gate hat den Abschluss vorsorglich blockiert. Der aktuelle Report muss mit frischer Kontrollwahrheit wiederholt werden.';
}

function localStatus(value: string): string {
  const labels: Record<string, string> = {
    attention: 'ACHTUNG',
    busy: 'BESCHÄFTIGT',
    healthy: 'STABIL',
    idle: 'BEREIT',
    reporting: 'BERICHT',
    ready: 'BEREIT',
    requested: 'ANGEFORDERT',
    standby: 'BEREITSCHAFT',
    stale: 'VERALTET',
    working: 'AKTIV',
    warning: 'WARNUNG',
  };

  return labels[value.toLowerCase()] ?? value.toUpperCase();
}

function operatorText(value: string): string {
  return value
    .replace(/(.+?)\s+is currently leased to Vivi until\s+([^.\n]+)\.?/gi, 'Vivi arbeitet aktuell an "$1". Lease bis $2.')
    .replace(/(.+?)\s+is currently leased to Codex until\s+([^.\n]+)\.?/gi, 'Vega arbeitet aktuell an "$1". Lease bis $2.')
    .replace(/Autonomous Content Creation Backlog: Utility Track/gi, 'Autonomer Content-Backlog: Utility-Strecke')
    .replace(/Autonomous Idle Recovery/gi, 'Autonome Leerlauf-Recovery')
    .replace(/Autoresearch-Support/gi, 'Autorecherche-Support')
    .replace(/Content Creation Backlog/gi, 'Content-Backlog')
    .replace(/Control Plane/gi, 'Kontrollebene')
    .replace(/Code Tasks/gi, 'Code-Aufgaben')
    .replace(/Backlog Synthesis From Signals/gi, 'Rückstau-Synthese aus Signalen')
    .replace(/V2 Night Watchdog Repair Drill/gi, 'V2-Nachtwächter-Reparaturprobe')
    .replace(/V2 Night Run Block 01: Default Route und Flight-Pack Betriebsprüfung/gi, 'V2-Nachtlauf Block 01: Standardroute und Flight-Pack-Betriebsprüfung')
    .replace(/V2 Local-bereit Hardening: Vivi Sessions, Chats und Offline-Arbeitskontinuität/gi, 'V2-Lokalhärtung: Vivi-Sessions, Chats und Offline-Arbeitskontinuität')
    .replace(/Vivi Dauerloop Continuity Sweep/gi, 'Vivi-Dauerloop-Kontinuitätsprüfung')
    .replace(/Operator Workflow Rehearsal/gi, 'Operator-Workflow-Probelauf')
    .replace(/Vivi Session Lifecycle Verification/gi, 'Vivi-Session-Lebenszyklus-Verifikation')
    .replace(/Vivi Session Lifecycle Verifikation/gi, 'Vivi-Session-Lebenszyklus-Verifikation')
    .replace(/V2 Flight Pack Offline Readiness/gi, 'V2-Flight-Pack-Offline-Bereitschaft')
    .replace(/Productive Refill/gi, 'produktiver Refill')
    .replace(/Roadmap Scan/gi, 'Roadmap-Prüfung')
    .replace(/VQG Loop Guard/gi, 'VQG-Loop-Schutz')
    .replace(/Local Operations Playbook Refinement/gi, 'lokale Betriebsanleitung schärfen')
    .replace(/Continuity Sweep/gi, 'Kontinuitätsprüfung')
    .replace(/Synthesis From Signals/gi, 'Synthese aus Signalen')
    .replace(/Operations Playbook/gi, 'Betriebsanleitung')
    .replace(/Vega verifier livechat\s+\S+/gi, 'Vega-Livechat geprüft')
    .replace(/Codex has replied recently/gi, 'Vega hat kürzlich geantwortet')
    .replace(/the board rail is synchronized/gi, 'die Board-Schiene ist synchronisiert')
    .replace(/Diagnose failure surface/gi, 'Fehlerfläche diagnostizieren')
    .replace(/Email Automation Full Flow Gap/gi, 'E-Mail-Automation Ablauf-Lücke')
    .replace(/Full Flow Gap/gi, 'Ablauf-Lücke')
    .replace(/Helpful Social Reply Draft Queue/gi, 'Hilfreiche Social-Antwort-Entwürfe')
    .replace(/Invalid Vivi state transition detected/gi, 'Ungültiger Vivi-Zustandswechsel erkannt')
    .replace(/Vivi\s*→\s*Vega Handoff/gi, 'Vivi → Vega Übergabe')
    .replace(/Vivi\s*->\s*Vega Handoff/gi, 'Vivi → Vega Übergabe')
    .replace(/Handoff from Vivi/gi, 'Übergabe von Vivi')
    .replace(/Handoff to Vega/gi, 'Übergabe zu Vega')
    .replace(/Handoff/gi, 'Übergabe')
    .replace(/The local Duo Loop is operational/gi, 'Der lokale Duo-Loop ist betriebsbereit')
    .replace(/Vivi sharpens the local Betriebsanleitung so the operator can work with Vivi during travel without remembering internal rails\./gi, 'Vivi schärft die lokale Betriebsanleitung, damit der Operator unterwegs mit Vivi arbeiten kann, ohne interne Rails erinnern zu müssen.')
    .replace(/Vivi turns the aktuell V2 state, operator feedback und latest reports into a concrete local build queue instead of repeating readiness sweeps\./gi, 'Vivi überführt den aktuellen V2-Zustand, Operator-Feedback und letzte Reports in eine konkrete lokale Build-Queue, statt Bereitschaftsprüfungen zu wiederholen.')
    .replace(/Vivi turns the aktuell V2 state.*?readiness sweeps\.?/gi, 'Vivi überführt den aktuellen V2-Zustand, Operator-Feedback und letzte Reports in eine konkrete lokale Build-Queue, statt Bereitschaftsprüfungen zu wiederholen.')
    .replace(/Vivi is aktivly working on/gi, 'Vivi arbeitet aktiv an')
    .replace(/Vivi is actively working on/gi, 'Vivi arbeitet aktiv an')
    .replace(/Backlog floor was empty/gi, 'Die Rückstau-Fläche war leer')
    .replace(/autonomous refill/gi, 'autonomer Refill')
    .replace(/Project Lane/gi, 'Projektspur')
    .replace(/Resource Class/gi, 'Ressourcenklasse')
    .replace(/Parallel Policy/gi, 'Parallelregel')
    .replace(/Next Claim/gi, 'Nächste Claim')
    .replace(/Synthesize Backlog/gi, 'Rückstau synthetisieren')
    .replace(/Convert recent UI comments, reports, audit findings, und quality-gate warnings into a deduplicated V2 Backlog/gi, 'Aktuelle UI-Kommentare, Reports, Audit-Funde und Qualitätsgate-Warnungen in einen deduplizierten V2-Rückstau überführen')
    .replace(/Assign Owners und Status/gi, 'Owner und Status zuweisen')
    .replace(/quality-gate/gi, 'Qualitätsgate')
    .replace(/Model Truth/gi, 'Modellwahrheit')
    .replace(/Project Scan/gi, 'Projekt-Scan')
    .replace(/Public Preview Regression Sweep/gi, 'Public-Preview-Regressionsprüfung')
    .replace(/Quality Drift Sweep/gi, 'Qualitätsdrift-Prüfung')
    .replace(/Research Source Citation Visibility/gi, 'Quellenzitat-Sichtbarkeit')
    .replace(/Repair signal:/gi, 'Reparatursignal:')
    .replace(/Repair rail has priority over normal execution when trust, visibility or runtime safety is degraded/gi, 'Reparaturen haben Vorrang, wenn Vertrauen, Sichtbarkeit oder Runtime-Sicherheit schwächer werden')
    .replace(/Repair Prep/gi, 'Reparaturvorbereitung')
    .replace(/No immediate intervention is needed\. Watch for the next operator packet\./gi, 'Keine sofortige Intervention nötig. Beobachte das nächste Operator-Paket.')
    .replace(/No immediate repair is required\. Keep freeze snapshots deliberate and continue normal collaboration flow\./gi, 'Keine sofortige Reparatur nötig. Freeze-Snapshots bewusst halten und normal weiterarbeiten.')
    .replace(/Keep the current claim alive with heartbeat updates instead of switching tracks silently\./gi, 'Aktuelle Claim mit Heartbeats lebendig halten und nicht still die Spur wechseln.')
    .replace(/Vivi checks whether the latest V2[- ]Flight[- ]Pack.*?right rails\.?/gi, 'Vivi prüft, ob der aktuelle V2-Flight-Pack für Reise- und Offline-Arbeit nützlich ist und die richtigen Rails enthält.')
    .replace(/Vivi checks whether the V2 night watchdog, health rail, repair mode und LaunchAgents are bereit for unattended local work\./gi, 'Vivi prüft, ob Nachtwächter, Health-Schiene, Reparaturmodus und LaunchAgents für unbeaufsichtigte lokale Arbeit bereit sind.')
    .replace(/Vivi checks whether the V2 night watchdog.*?unattended local work\.?/gi, 'Vivi prüft, ob Nachtwächter, Health-Schiene, Reparaturmodus und LaunchAgents für unbeaufsichtigte lokale Arbeit bereit sind.')
    .replace(/Vivi verifies new-session.*?Vega data separation\.?/gi, 'Vivi prüft neue Sessions, Session-Wechsel, Archivieren, Leere-Session-Entfernung, Auto-Start-Kontext, Provider-Vererbung und Vega-Datentrennung.')
    .replace(/Vivi rehearses the real local operator workflow.*?offline recovery\.?/gi, 'Vivi probt den echten lokalen Operator-Ablauf von Session-Start über Dispatch, Routing, Bericht-Übergabe, Audit-Spur und Offline-Recovery.')
    .replace(/Vivi verifies new-session.*?Vega data separation\.?/gi, 'Vivi prüft neue Sessions, Session-Wechsel, Archivieren, Leere-Session-Entfernung, Auto-Start-Kontext, Provider-Vererbung und Vega-Datentrennung.')
    .replace(/Vivi converts recent UI comments.*?real next actions\.?/gi, 'Vivi überführt aktuelle UI-Kommentare, Reports, Audit-Funde und Qualitätsgate-Warnungen in einen deduplizierten V2-Rückstau mit echten nächsten Aktionen.')
    .replace(/Vivi keeps the local night-run alive.*?continuity step\.?/gi, 'Vivi hält den lokalen Nachtlauf lebendig, liest aktuelle V2-, Autonomie-, Queue- und Audit-Signale und erzeugt daraus den nächsten sicheren operatornahen Kontinuitätsschritt.')
    .replace(/The local duo loop could not claim the next Vivi mission from the Control Plane\./gi, 'Der lokale Duo-Loop konnte gerade keine nächste Vivi-Mission über die Kontrollebene ziehen.')
    .replace(/The local duo loop could not claim the next Vivi mission from the Kontrollebene\./gi, 'Der lokale Duo-Loop konnte gerade keine nächste Vivi-Mission über die Kontrollebene ziehen.')
    .replace(/Escalate to Codex only when the work becomes technically deep, risky or review-bound\./gi, 'Nur an Vega eskalieren, wenn die Arbeit technisch tief, riskant oder reviewpflichtig wird.')
    .replace(/This claim is stale and should be reconciled before new work is claimed\./gi, 'Diese Claim ist alt und muss bereinigt werden, bevor neue Arbeit gezogen wird.')
    .replace(/Watch for the next operator packet/gi, 'Nächstes Operator-Paket beobachten')
    .replace(/Remote read\/write verification succeeded/gi, 'Remote-Lese-/Schreibprüfung erfolgreich')
    .replace(/The requested URL returned error:\s*(\d+)/gi, 'Der Remote-Aufruf wurde mit Fehler $1 abgelehnt')
    .replace(/The requested URL returned error/gi, 'Der Remote-Aufruf wurde abgelehnt')
    .replace(/Freeze and collaboration sync are ready/gi, 'Freeze und Kollaborations-Sync sind bereit')
    .replace(/Queue pressure is building/gi, 'Queue-Druck steigt')
    .replace(/Vega board rail needs attention/gi, 'Vega-Board-Schiene braucht Aufmerksamkeit')
    .replace(/Desktop package still runs with asar disabled/gi, 'Desktop-Paket läuft noch mit deaktiviertem ASAR')
    .replace(/\brepair-queue\b/gi, 'Reparatur-Queue')
    .replace(/\bREPORT\b/g, 'Bericht')
    .replace(/\breported\b/gi, 'berichtet')
    .replace(/\breview\b/gi, 'Prüfung')
    .replace(/Runtime Settings/gi, 'Runtime-Einstellungen')
    .replace(/Vivi Provider/gi, 'Vivi-Provider')
    .replace(/Structured Codex packets/gi, 'Strukturierte Vega-Pakete')
    .replace(/Codex packets/gi, 'Vega-Pakete')
    .replace(/Codex packet/gi, 'Vega-Paket')
    .replace(/Codex rail/gi, 'Vega-Schiene')
    .replace(/Codex/gi, 'Vega')
    .replace(/Verification/gi, 'Verifikation')
    .replace(/Repair Queue/gi, 'Reparatur-Queue')
    .replace(/Vivi Queue/gi, 'Vivi-Queue')
    .replace(/Codex Inbox/gi, 'Vega-Inbox')
    .replace(/Work Intake/gi, 'Eingang')
    .replace(/Backlog/gi, 'Backlog')
    .replace(/Inbox/gi, 'Eingang')
    .replace(/Commands/gi, 'Aufträge')
    .replace(/Claims/gi, 'Claims')
    .replace(/Source Extraction/gi, 'Quellenextraktion')
    .replace(/Stabilize degraded path/gi, 'Degradierten Pfad stabilisieren')
    .replace(/Transition/gi, 'Übergang')
    .replace(/Utility Track/gi, 'Utility-Strecke')
    .replace(/Verify repair and publish report/gi, 'Reparatur prüfen und Bericht veröffentlichen')
    .replace(/Vivi Self-Correction Sweep/gi, 'Vivi-Selbstkorrekturprüfung')
    .replace(/Weekly Issue/gi, 'Wöchentliche Issue')
    .replace(/Mission Phase Execute/gi, 'Missionsphase Ausführung')
    .replace(/Control Plane V2 Local-Ready Sweep/gi, 'Kontrollebene V2 Local-Ready-Prüfung')
    .replace(/Local-Ready-Prüfung/gi, 'Lokal-Bereitschaftsprüfung')
    .replace(/Control Plane V2 QA Polish Sweep/gi, 'Kontrollebene V2 QA-Polish-Prüfung')
    .replace(/Memory und Report Ingest Sweep/gi, 'Memory- und Report-Eingangsprüfung')
    .replace(/Memory and Report Ingest Sweep/gi, 'Memory- und Report-Eingangsprüfung')
    .replace(/Qualification suite passed/gi, 'Qualifikationssuite bestanden')
    .replace(/The product is locally complete/gi, 'Das Produkt ist lokal vollständig')
    .replace(/und Das Produkt/gi, 'und das Produkt')
    .replace(/The remaining gaps are activation steps for external channels/gi, 'Die offenen Punkte sind Aktivierungsschritte für externe Kanäle')
    .replace(/not missing engineering capability/gi, 'keine fehlende Entwicklungsfähigkeit')
    .replace(/Acknowledge or close the stale Codex packet now/gi, 'Das veraltete Codex-Paket jetzt bestätigen oder schließen')
    .replace(/Acknowledge or close the stale Vega-Paket now/gi, 'Das veraltete Vega-Paket jetzt bestätigen oder schließen')
    .replace(/Acknowledge or close the stale .+? now/gi, 'Das veraltete Paket jetzt bestätigen oder schließen')
    .replace(/so the board remains the single trustworthy command surface/gi, 'damit das Board die einzige verlässliche Steuerfläche bleibt')
    .replace(/Structured Codex packets are queued and waiting to be answered/gi, 'Strukturierte Codex-Pakete warten auf Antwort')
    .replace(/Structured Codex packets are queued and waiting to be claimed or answered/gi, 'Strukturierte Codex-Pakete warten darauf, gezogen oder beantwortet zu werden')
    .replace(/Structured Vega packets are queued and waiting to be answered/gi, 'Strukturierte Vega-Pakete warten auf Antwort')
    .replace(/Structured Vega packets are queued and waiting to be claimed or answered/gi, 'Strukturierte Vega-Pakete warten darauf, gezogen oder beantwortet zu werden')
    .replace(/Vega-Pakete are queued und waiting to be answered/gi, 'Vega-Pakete warten auf Antwort')
    .replace(/Vega-Pakete are queued und waiting to be claimed or answered/gi, 'Vega-Pakete warten darauf, gezogen oder beantwortet zu werden')
    .replace(/Vega-Pakete are wartend und waiting to be claimed or answered/gi, 'Vega-Pakete warten darauf, gezogen oder beantwortet zu werden')
    .replace(/Vega-Pakete are wartend und waiting to be answered/gi, 'Vega-Pakete warten auf Antwort')
    .replace(/\bare wartend\b/gi, 'warten')
    .replace(/\bare waiting\b/gi, 'warten')
    .replace(/\bwaiting to be claimed or answered\b/gi, 'warten darauf, gezogen oder beantwortet zu werden')
    .replace(/\bwaiting to be answered\b/gi, 'warten auf Antwort')
    .replace(/\bwaiting\b/gi, 'wartend')
    .replace(/\bqueued\b/gi, 'wartend')
    .replace(/Repair packets are wartend und require Vivi attention\./gi, 'Reparaturpakete warten und benötigen Vivi-Prüfung.')
    .replace(/Repair packets warten und require Vivi attention\./gi, 'Reparaturpakete warten und benötigen Vivi-Prüfung.')
    .replace(/The Codex rail is aging/gi, 'Die Codex-Schiene wird älter')
    .replace(/The Vega rail is aging/gi, 'Die Vega-Schiene wird älter')
    .replace(/The Vega-Schiene is aging/gi, 'Die Vega-Schiene wird älter')
    .replace(/Vega-Schiene is aging/gi, 'Vega-Schiene wird älter')
    .replace(/Codex rail is aging/gi, 'Die Codex-Schiene wird älter')
    .replace(/oldest queued packet/gi, 'ältestes wartendes Paket')
    .replace(/Local Duo-Loop/gi, 'Lokaler Duo-Loop')
    .replace(/Board local as aktuell/gi, 'Board lokal als aktuell')
    .replace(/Remote confirmation/gi, 'Remote-Bestätigung')
    .replace(/is still pending/gi, 'steht noch aus')
    .replace(/Observed via crontab:/gi, 'Aus lokaler Crontab erkannt:')
    .replace(/Inbound mobile commands are flowing \((\d+) packet\(s\) on the rail\) and outbound relay remains armed\./gi, 'Mobile Eingangsbefehle laufen ($1 Paket(e) auf der Schiene); das Ausgangs-Relay ist bereit.')
    .replace(/Outbound packets are being staged for remote delivery\./gi, 'Ausgehende Pakete werden für spätere Zustellung vorbereitet.')
    .replace(/Ready to stage or send packets when operator uses Comms deck\./gi, 'Bereit, sobald der Operator den Kommunikationsbereich nutzt.')
    .replace(/Repair packets are queued and require Vivi attention\./gi, 'Reparaturpakete warten und benötigen Vivi-Prüfung.')
    .replace(/Inbound mobile Aufträge are flowing \((\d+) packet\(s\) on the rail\) und outbound relay remains armed\./gi, 'Mobile Eingangsbefehle laufen ($1 Paket(e) auf der Schiene); das Ausgangs-Relay ist bereit.')
    .replace(/Critical issues can be escalated into repair packets from the alert deck\./gi, 'Kritische Hinweise können aus der Alarmfläche in Reparaturpakete übergeben werden.')
    .replace(/No local automation visibility is currently available\./gi, 'Aktuell ist keine lokale Automationssicht verfügbar.')
    .replace(/Repair Rail/gi, 'Reparatur-Schiene')
    .replace(/^- Title:/gim, '- Titel:')
    .replace(/^- Priority:/gim, '- Priorität:')
    .replace(/^- Reason:/gim, '- Grund:')
    .replace(/^- Result:/gim, '- Ergebnis:')
    .replace(/^- Evidence:/gim, '- Nachweis:')
    .replace(/^- Cleanup:/gim, '- Bereinigung:')
    .replace(/^- Handoff:/gim, '- Übergabe:')
    .replace(/- Session:/gim, '- Session:')
    .replace(/- Workspace Root:/gim, '- Workspace:')
    .replace(/- Workdir:/gim, '- Arbeitsordner:')
    .replace(/- Topic:/gim, '- Thema:')
    .replace(/\bpass\/fail result\b/gi, 'Pass/Fail-Ergebnis')
    .replace(/\bas acceptance evidence\b/gi, 'als Abnahmenachweis')
    .replace(/\buse the ([^.\n]+?) for\b/gi, '$1 als')
    .replace(/\bwith Priorität\b/gi, 'mit Priorität')
    .replace(/-?\s*Raw HTTP 4107\/3007:\s*unreachable\s*\(not_run;\s*effective_transport:\s*local_route_bridge ok\)/gi, 'Raw-HTTP-Probe nicht ausgeführt; lokaler Route-Bridge-Transport ist erreichbar.')
    .replace(/raw_http_probe: not_run; effective_transport: local_route_bridge ok/gi, 'Raw-HTTP-Probe nicht ausgeführt; lokaler Route-Bridge-Transport ist erreichbar.')
    .replace(/-?\s*No immediate patch required/gi, 'Keine unmittelbare Reparatur erforderlich')
    .replace(/-?\s*No artifacts generated/gi, 'Keine Artefakte erzeugt')
    .replace(/-?\s*Source Gate:\s*no/gi, 'Quellen-Gate: nicht erforderlich')
    .replace(/VQG auto-correction applied because the only failure was idle closure wording\./gi, 'VQG-Autokorrektur angewendet: Einziger Fehler war eine unzulässige Idle-Abschlussformulierung.')
    .replace(/Raw HTTP Probes sind grün; keine Transport-Probleme\./gi, 'Raw-HTTP-Proben sind grün; keine Transportprobleme.')
    .replace(/Raw HTTP probes are not required for this internal Backlog task as per `Source-Light-Lock`\./gi, 'Raw-HTTP-Proben sind für diese interne Rückstau-Aufgabe laut `Source-Light-Lock` nicht erforderlich.')
    .replace(/The local bridge is confirmed operational via the runner evidence/gi, 'Die lokale Bridge ist über Runner-Nachweise als funktionsfähig bestätigt')
    .replace(/\*\*System Health\*\*/gi, '**Systemzustand**')
    .replace(/\*\*Operator Mode\*\*/gi, '**Operator-Modus**')
    .replace(/\*\*Session Lifecycle\*\*/gi, '**Session-Lebenszyklus**')
    .replace(/\*\*Monitoring\*\*/gi, '**Überwachung**')
    .replace(/\boverall: healthy\b/gi, 'Gesamtstatus: gesund')
    .replace(/\boperational\b/gi, 'betriebsbereit')
    .replace(/\bRun `([^`]+)`/gi, '`$1` ausführen')
    .replace(/is stale/gi, 'ist veraltet')
    .replace(/but the local/gi, 'aber der lokale')
    .replace(/has updated/gi, 'hat aktualisiert')
    .replace(/minutes ago/gi, 'Minuten zuvor')
    .replace(/less than a minute ago/gi, 'vor weniger als einer Minute')
    .replace(/hours ago/gi, 'Stunden zuvor')
    .replace(/Treat/gi, 'Behandle')
    .replace(/current/gi, 'aktuell')
    .replace(/while/gi, 'solange')
    .replace(/outside the allowed Vivi operating flow/gi, 'außerhalb des erlaubten Vivi-Ablaufs')
    .replace(/\bis außerhalb\b/gi, 'liegt außerhalb')
    .replace(/Quality Gate/gi, 'Qualitätsgate')
    .replace(/state transition/gi, 'Zustandswechsel')
    .replace(/blocked/gi, 'blockiert')
    .replace(/closed/gi, 'geschlossen')
    .replace(/executing/gi, 'in Ausführung')
    .replace(/queued/gi, 'wartend')
    .replace(/oldest queued packet/gi, 'ältestes wartendes Paket')
    .replace(/watcher/gi, 'Watcher')
    .replace(/runtime blockers/gi, 'Runtime-Blocker')
    .replace(/No new packet/gi, 'Kein neues Paket')
    .replace(/standby/gi, 'Bereitschaft')
    .replace(/ready/gi, 'bereit')
    .replace(/active/gi, 'aktiv')
    .replace(/Vega\/Vega/gi, 'Vega')
    .replace(/Kontrollebene V2 Local-bereit Sweep/gi, 'Kontrollebene V2 Lokal-Bereitschaftsprüfung')
    .replace(/Local-Ready-Prüfung/gi, 'Lokal-Bereitschaftsprüfung')
    .replace(/V2 Local-bereit Hardening: Vivi Sessions, Chats und Offline-Arbeitskontinuität/gi, 'V2-Lokalhärtung: Vivi-Sessions, Chats und Offline-Arbeitskontinuität')
    .replace(/Kontrollebene V2 QA Polish Sweep/gi, 'Kontrollebene V2 QA-Polish-Prüfung')
    .replace(/Vega board rail needs attention/gi, 'Vega-Board-Schiene braucht Aufmerksamkeit')
    .replace(/Inbound mobile Aufträge are flowing \((\d+) packet\(s\) on the rail\) und outbound relay remains armed\./gi, 'Mobile Eingangsbefehle laufen ($1 Paket(e) auf der Schiene); das Ausgangs-Relay ist bereit.')
    .replace(/Inbound mobile .*?(\d+) packet\(s\) on the rail.*?outbound relay remains armed\./gi, 'Mobile Eingangsbefehle laufen ($1 Paket(e) auf der Schiene); das Ausgangs-Relay ist bereit.')
    .replace(/Vivi rehearses the real local operator workflow.*?offline recovery\.?/gi, 'Vivi probt den echten lokalen Operator-Ablauf von Session-Start über Dispatch, Routing, Bericht-Übergabe, Audit-Spur und Offline-Recovery.')
    .replace(/Vivi keeps the local night-run alive.*?continuity step\.?/gi, 'Vivi hält den lokalen Nachtlauf lebendig, liest aktuelle V2-, Autonomie-, Queue- und Audit-Signale und erzeugt daraus den nächsten sicheren operatornahen Kontinuitätsschritt.')
    .replace(/Vivi turns the aktuell V2 state/gi, 'Vivi überführt den aktuellen V2-Zustand')
    .replace(/operator feedback und latest reports into a concrete local build queue instead of repeating readiness sweeps\.?/gi, 'Operator-Feedback und letzte Reports in eine konkrete lokale Build-Queue, statt Bereitschaftsprüfungen zu wiederholen.')
    .replace(/\sand\s/gi, ' und ')
    .replace(/Repair packets are wartend und require Vivi attention\./gi, 'Reparaturpakete warten und benötigen Vivi-Prüfung.')
    .replace(/Repair packets warten und require Vivi attention\./gi, 'Reparaturpakete warten und benötigen Vivi-Prüfung.')
    .replace(/und Das Produkt/gi, 'und das Produkt')
    .replace(/schließen damit/gi, 'schließen, damit');
}

function freshnessLabel(minutes?: number): string {
  if (minutes === undefined) return 'gerade eben';
  if (minutes < 1) return 'unter 1m';
  if (minutes < 60) return `vor ${Math.round(minutes)}m`;
  return `vor ${Math.round(minutes / 60)}h`;
}

function formatTime(value?: string | null): string {
  if (!value) return '--:--';
  const parsed = Date.parse(value);
  if (!Number.isNaN(parsed)) return timeFormatter.format(parsed);
  const match = value.match(/\b\d{1,2}:\d{2}(?::\d{2})?\b/);
  if (match) return match[0];
  return value.slice(0, 12);
}

function compareTimestampDesc(left?: string | null, right?: string | null): number {
  const leftTime = left ? Date.parse(left) : 0;
  const rightTime = right ? Date.parse(right) : 0;
  const safeLeft = Number.isNaN(leftTime) ? 0 : leftTime;
  const safeRight = Number.isNaN(rightTime) ? 0 : rightTime;
  return safeRight - safeLeft;
}

function series(seed: number): number[] {
  const base = clamp(Math.round(seed), 4, 96);
  return Array.from({ length: 8 }, (_, index) => clamp(base + Math.round(Math.sin(index + base) * 8) + index * 2, 2, 100));
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

function withFallback<T>(items: T[], fallback: T[]): T[] {
  return items.length > 0 ? items : fallback;
}
