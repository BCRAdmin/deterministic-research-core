import 'server-only';

import os from 'os';
import path from 'path';
import { promises as fs } from 'fs';

import type { DesktopDiagnostics, DesktopLaunchIssue } from '../control-room/types';
import { PATHS, WORKSPACE_ROOT } from '../constants/paths';
import { getDesktopSettingsPath, readDesktopSettings, type DesktopSettings } from './desktopSettingsService';

interface DesktopStatusSnapshot {
  state?: DesktopDiagnostics['startupState'];
  detail?: string;
  workspaceRoot?: string;
  workspaceValid?: boolean;
  issues?: DesktopLaunchIssue[];
  serverPort?: number;
  serverPath?: string;
  isPackaged?: boolean;
  startedAt?: string;
  updatedAt?: string;
}

interface LocalDuoLoopStatusSnapshot {
  requestedProvider?: string;
  effectiveProvider?: string;
  requestedModel?: string;
  effectiveModel?: string;
  fallbackModel?: string;
  modelState?: string;
  modelDetail?: string;
  lastModelError?: string | null;
}

interface ViviModelOverrideSnapshot {
  providerPreset?: string;
  requestedModel?: string;
}

function supportDir() {
  return path.join(os.homedir(), 'Library', 'Application Support', 'LIONCOM');
}

function logPath() {
  return path.join(supportDir(), 'logs', 'desktop.log');
}

function statusPath() {
  return path.join(supportDir(), 'desktop-status.json');
}

export async function getDesktopDiagnostics(): Promise<DesktopDiagnostics> {
  const [settings, status, logTail, packageMeta, localLoop] = await Promise.all([
    readDesktopSettings(),
    safeJson<DesktopStatusSnapshot>(statusPath()),
    readLogTail(logPath(), 12),
    safeJson<{ version?: string; build?: { asar?: boolean } }>(path.join(WORKSPACE_ROOT, 'mission-control-board', 'package.json')),
    safeJson<LocalDuoLoopStatusSnapshot>(PATHS.LOCAL_DUO_LOOP_STATUS),
  ]);
  const override = await safeJson<ViviModelOverrideSnapshot>(PATHS.VIVI_MODEL_OVERRIDE);

  const workspaceRoot = status?.workspaceRoot || settings?.workspaceRoot || WORKSPACE_ROOT;
  const requiredMarkers = await checkWorkspaceMarkers(workspaceRoot);
  const workspaceValid = requiredMarkers.every((marker) => marker.present);
  const issues: DesktopLaunchIssue[] = [];

  for (const issue of status?.issues || []) {
    issues.push(issue);
  }

  if (!workspaceValid) {
    const missing = requiredMarkers.filter((marker) => !marker.present).map((marker) => marker.name).join(', ');
    issues.push({
      severity: 'critical',
      message: `Workspace markers missing: ${missing}. LIONCOM should not be trusted as a desktop command surface until the workspace root is corrected.`,
    });
  }

  const startupState = status?.state || (workspaceValid ? 'ready' : 'warning');
  const startupDetail = status?.detail
    || (workspaceValid
      ? 'Desktop workspace markers look healthy and the native shell has a valid control root.'
      : 'Desktop workspace root is incomplete. System deck should be treated as degraded until the root is corrected.');

  return {
    mode: status ? 'desktop' : 'browser',
    appVersion: packageMeta?.version,
    workspaceRoot,
    workspaceValid,
    requiredMarkers,
    serverPort: status?.serverPort,
    startupState,
    startupDetail,
    issues: dedupeIssues(issues),
    logTail,
    settingsPath: getDesktopSettingsPath(),
    logPath: logPath(),
    statusPath: statusPath(),
    asarEnabled: packageMeta?.build?.asar !== false,
    notarized: false,
    signingMode: 'ad-hoc',
    viviRequestedProvider: normalizeProvider(settings, localLoop, override),
    viviRequestedModel: override?.requestedModel || settings?.viviRequestedModel || localLoop?.requestedModel,
    viviEffectiveProvider: localLoop?.effectiveProvider || localLoop?.requestedProvider || settings?.viviProviderPreset,
    viviEffectiveModel: localLoop?.effectiveModel || localLoop?.requestedModel || settings?.viviRequestedModel,
    viviFallbackModel: localLoop?.fallbackModel,
    viviModelState: localLoop?.modelState,
    viviModelDetail: localLoop?.modelDetail,
    viviModelLastError: localLoop?.lastModelError ?? null,
  };
}

function normalizeProvider(
  settings: DesktopSettings,
  localLoop: LocalDuoLoopStatusSnapshot | null,
  override: ViviModelOverrideSnapshot | null,
): string | undefined {
  return override?.providerPreset || settings?.viviProviderPreset || localLoop?.requestedProvider || localLoop?.effectiveProvider;
}

async function checkWorkspaceMarkers(workspaceRoot: string): Promise<DesktopDiagnostics['requiredMarkers']> {
  const markers = [
    { name: 'mission-control-board', path: path.join(workspaceRoot, 'mission-control-board') },
    { name: 'VIVI_CONTROL_LOOP.md', path: path.join(workspaceRoot, 'VIVI_CONTROL_LOOP.md') },
    { name: 'WORK_INTAKE.md', path: path.join(workspaceRoot, 'WORK_INTAKE.md') },
    { name: 'COMMUNICATION_MESH.md', path: path.join(workspaceRoot, 'COMMUNICATION_MESH.md') },
  ];

  return Promise.all(
    markers.map(async (marker) => ({
      name: marker.name,
      present: await exists(marker.path),
    })),
  );
}

async function readLogTail(filePath: string, limit: number): Promise<string[]> {
  try {
    const content = await fs.readFile(filePath, 'utf-8');
    return content.split('\n').map((line) => line.trim()).filter(Boolean).slice(-limit);
  } catch {
    return [];
  }
}

function dedupeIssues(issues: DesktopLaunchIssue[]): DesktopLaunchIssue[] {
  const seen = new Set<string>();
  return issues.filter((issue) => {
    const key = `${issue.severity}:${issue.message}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, 6);
}

async function exists(target: string): Promise<boolean> {
  try {
    await fs.access(target);
    return true;
  } catch {
    return false;
  }
}

async function safeJson<T>(filePath: string): Promise<T | null> {
  try {
    return JSON.parse(await fs.readFile(filePath, 'utf-8')) as T;
  } catch {
    return null;
  }
}
