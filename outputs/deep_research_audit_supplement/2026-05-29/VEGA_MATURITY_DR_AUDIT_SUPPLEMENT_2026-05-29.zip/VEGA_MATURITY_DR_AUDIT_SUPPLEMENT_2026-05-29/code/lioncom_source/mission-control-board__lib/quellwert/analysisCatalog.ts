export type QuellwertAnalysis = {
  slug: string;
  ticker: string;
  company: string;
  shortName: string;
  sector: string;
  title: string;
  subtitle: string;
  asOfDate: string;
  priceBasisDate: string;
  sourceBatch: string;
  reportId: string;
  qualityScore: number;
  publicationStatus: 'pilot_ready' | 'manual_review' | 'hidden';
  visibility: 'public' | 'hidden';
  readingMinutes: number;
  sourceCount: number;
  displayStatus: 'Pilot-Entwurf' | 'Public-Ready-Kandidat';
  nonAdvice?: {
    status: 'visible';
    label: string;
  };
  gate?: {
    id: string;
    sourceReview: 'pass' | 'needs_review';
    nonAdvice: 'pass';
    operatorGoRequired: boolean;
    officialSourceLabel: string;
    officialSourceHref: string;
  };
  summary: string;
  thesis: string;
  articleBody?: string[];
  kpis: string[];
  watchpoints: string[];
  risks: string[];
  evidence: Array<{
    label: string;
    sourceId: string;
    sourceType: string;
    href?: string;
  }>;
  localArtifacts: string[];
};

export type QuellwertGateSummary = {
  reviewLabel: string;
  sourceLabel: string;
  externalLabel: string;
};

const currentBatch = 'phase12_current_batch_003';
const asOfDate = '2026-05-08';

export const quellwertAnalyses: QuellwertAnalysis[] = [
  {
    slug: 'alphabet-googl-cloud-ai-capex-pilot',
    ticker: 'GOOGL',
    company: 'Alphabet Inc.',
    shortName: 'Alphabet',
    sector: 'Plattformen / Cloud',
    title: 'Alphabet: Cloud-Wachstum trifft AI-Capex-Prüfung',
    subtitle:
      'Ein Research-Agent-Pilot zu Cloud-Dynamik, operativer Marge, Infrastrukturinvestitionen und Free-Cashflow-Qualität.',
    asOfDate,
    priceBasisDate: asOfDate,
    sourceBatch: currentBatch,
    reportId: 'GOOGL_2026-05-08',
    qualityScore: 95,
    publicationStatus: 'pilot_ready',
    visibility: 'public',
    readingMinutes: 9,
    sourceCount: 3,
    displayStatus: 'Public-Ready-Kandidat',
    nonAdvice: {
      status: 'visible',
      label: 'keine Anlageberatung, keine persönliche Empfehlung, keine Aufforderung zu einer Transaktion',
    },
    gate: {
      id: 'quellwert-googl-public-ready-v1',
      sourceReview: 'needs_review',
      nonAdvice: 'pass',
      operatorGoRequired: true,
      officialSourceLabel: 'Alphabet Q1 2026 Earnings Release',
      officialSourceHref:
        'https://s206.q4cdn.com/479360582/files/doc_financials/2026/q1/2026q1-alphabet-earnings-release.pdf',
    },
    summary:
      'Alphabet zeigt im geprüften Q1-Release und im lokalen Evidence-Paket starke operative Signale: 109,9 Mrd. USD Quartalsumsatz, 20,0 Mrd. USD Google-Cloud-Umsatz, 63 % Cloud-Wachstum und 36,1 % operative Marge. Die offene Frage ist, wie stark AI-Infrastrukturinvestitionen die freie Cashflow-Konversion belasten, bevor zusätzliche Erlöse sichtbar werden.',
    thesis:
      'Die Quellwert-These ist ein hochwertiges Anzeigen- und Cloud-Geschäft in einer investitionsintensiven AI-Phase. Der Artikel gewichtet deshalb Cloud-Wachstum, operative Marge, Capex, Free Cashflow und Datenqualität stärker als isolierte Einmalgewinne.',
    articleBody: [
      'Alphabet wird in dieser Preview nicht über ein einzelnes Wachstumsnarrativ gelesen. Der Schwerpunkt liegt auf der Frage, ob Cloud-Dynamik und Anzeigenqualität die höhere Infrastrukturintensität tragen.',
      'Die Zahlen werden deshalb getrennt betrachtet: wiederkehrende operative Marge, Capex, freie Cashflow-Konversion und nicht-operative Erträge. Das offene Registry-Delta bleibt ein Review-Punkt, kein stiller Freigabestempel.',
    ],
    kpis: [
      'Q1-Umsatz: 109,9 Mrd. USD laut Alphabet Q1 2026 Earnings Release.',
      'Google Cloud: 20,0 Mrd. USD Umsatz und 63 % Wachstum.',
      'Operative Marge: 36,1 %; Q1-Capex: 35,674 Mrd. USD.',
      'TTM Free Cashflow: 64,429 Mrd. USD; Other Income enthielt einen Netto-Gewinn von 37,7 Mrd. USD.',
    ],
    watchpoints: [
      'AI-Capex muss in belastbare zusätzliche Umsätze und Cashflow-Qualität übersetzen.',
      'Cloud-Wachstum bleibt der wichtigste Gegenpol zur höheren Kapitalintensität.',
      'Nicht-operative Erträge werden getrennt von wiederkehrender operativer Qualität betrachtet.',
    ],
    risks: [
      'Regulatorischer Druck auf Such- und Werbegeschäft.',
      'Höhere Infrastrukturkosten ohne ausreichende Monetarisierung.',
      'Technische Überhitzung oder schwächere Cashflow-Konversion.',
    ],
    evidence: [
      {
        label: 'Alphabet Q1 2026 Earnings Release',
        sourceId: 'GOOGL_ALPHABET_Q1_2026_RELEASE',
        sourceType: 'earnings_release',
        href: 'https://s206.q4cdn.com/479360582/files/doc_financials/2026/q1/2026q1-alphabet-earnings-release.pdf',
      },
      {
        label: 'SEC CompanyFacts',
        sourceId: 'GOOGL_SEC_COMPANYFACTS_1652044',
        sourceType: 'sec_filing',
        href: 'https://data.sec.gov/api/xbrl/companyfacts/CIK0001652044.json',
      },
      {
        label: 'Lokales Evidence-Paket',
        sourceId: 'GOOGL_2026-05-08',
        sourceType: 'research_agent_bundle',
      },
    ],
    localArtifacts: [
      'publish_report.md',
      'publish_report_quality_score.json',
      'report_manifest.json',
      'source_registry.json',
    ],
  },
  {
    slug: 'snowflake-snow-ai-data-cloud-sbc-pilot',
    ticker: 'SNOW',
    company: 'Snowflake Inc.',
    shortName: 'Snowflake',
    sector: 'Data Cloud / AI-Infrastruktur',
    title: 'Snowflake: AI Data Cloud mit SBC- und Bewertungsdisziplin',
    subtitle:
      'Ein Research-Agent-Pilot zu Produktumsatz, Net Revenue Retention, RPO, Großkunden und Verwässerungsrisiken.',
    asOfDate,
    priceBasisDate: asOfDate,
    sourceBatch: currentBatch,
    reportId: 'SNOW_2026-05-08',
    qualityScore: 95,
    publicationStatus: 'pilot_ready',
    visibility: 'public',
    readingMinutes: 10,
    sourceCount: 2,
    displayStatus: 'Pilot-Entwurf',
    nonAdvice: {
      status: 'visible',
      label: 'keine Anlageberatung, keine persönliche Empfehlung, keine Aufforderung zu einer Transaktion',
    },
    summary:
      'Snowflake bleibt im lokalen Evidence-Paket operativ interessant: Produktumsatz, RPO, Net Revenue Retention und große Unternehmenskunden zeigen Tiefe. Gleichzeitig bleiben Verwässerung, freie Cashflow-Qualität und schwächere Markttechnik zentrale Prüfstellen.',
    thesis:
      'Die Quellwert-These trennt die Qualität der AI-Data-Cloud-Franchise von der Frage, ob Wachstum, Kundenbindung und freie Cashflows die aktuelle Bewertung und die Verwässerung sauber tragen.',
    articleBody: [
      'Snowflake wird als Qualitäts- und Disziplinfrage gelesen: Produktumsatz, Net Revenue Retention, RPO und Großkunden zeigen Nachfrage, während aktienbasierte Vergütung und freie Cashflow-Qualität eigene Prüfstellen bleiben.',
      'Die Markttechnik erscheint nur als Risiko- und Kontextsignal. Die Preview enthält keine Handlungsvorgabe; entscheidend ist, ob Verbrauchsdynamik, Kundenbindung und Verwässerung sauber zusammenpassen.',
    ],
    kpis: [
      'Produktumsatz: 4,47 Mrd. USD im lokalen Evidence-Paket.',
      'Net Revenue Retention: 125,0 %; RPO: 9,77 Mrd. USD.',
      'Großkunden: 733 Kunden mit mehr als 1 Mio. USD Produktumsatz.',
      'Adjusted Free Cashflow: 1,19 Mrd. USD; SBC/Umsatz: 26,4 %.',
    ],
    watchpoints: [
      'Kundenbindung und RPO müssen weiter in belastbare Umsatzqualität übersetzen.',
      'Verwässerung bleibt ein eigener Bewertungs- und Qualitätsfilter.',
      'Die Markttechnik wird als Risikosignal behandelt, nicht als Handlungsvorgabe.',
    ],
    risks: [
      'Abschwächung im Verbrauchsmodell oder langsamere Enterprise-Nachfrage.',
      'Hohe aktienbasierte Vergütung im Verhältnis zum Umsatz.',
      'Bewertungsdruck, falls Cashflow-Qualität und Wachstum auseinanderlaufen.',
    ],
    evidence: [
      {
        label: 'SEC CompanyFacts',
        sourceId: 'SNOW_SEC_COMPANYFACTS_1640147',
        sourceType: 'sec_filing',
        href: 'https://data.sec.gov/api/xbrl/companyfacts/CIK0001640147.json',
      },
      {
        label: 'Lokales Evidence-Paket',
        sourceId: 'SNOW_2026-05-08',
        sourceType: 'research_agent_bundle',
      },
    ],
    localArtifacts: [
      'publish_report.md',
      'publish_report_quality_score.json',
      'report_manifest.json',
      'source_registry.json',
    ],
  },
  {
    slug: 'microsoft-msft-cloud-ai-capex-pilot',
    ticker: 'MSFT',
    company: 'Microsoft Corp.',
    shortName: 'Microsoft',
    sector: 'Cloud / Enterprise Software',
    title: 'Microsoft: Cloud-Qualität gegen AI-Capex-Hürde',
    subtitle:
      'Ein Research-Agent-Pilot zu Microsoft Cloud, Azure, AI-Umsatzlauf, Free Cashflow und Reinvestitionsdruck.',
    asOfDate,
    priceBasisDate: asOfDate,
    sourceBatch: currentBatch,
    reportId: 'MSFT_2026-05-08',
    qualityScore: 92,
    publicationStatus: 'pilot_ready',
    visibility: 'public',
    readingMinutes: 9,
    sourceCount: 2,
    displayStatus: 'Pilot-Entwurf',
    nonAdvice: {
      status: 'visible',
      label: 'keine Anlageberatung, keine persönliche Empfehlung, keine Aufforderung zu einer Transaktion',
    },
    summary:
      'Microsoft liefert im lokalen Evidence-Paket starke Cloud- und AI-Signale. Die Kernfrage ist nicht die Relevanz der Plattform, sondern ob Kapazitätsaufbau und Datacenter-Investitionen schnell genug in dauerhafte Free-Cashflow-Hebel übersetzen.',
    thesis:
      'Die Quellwert-These ist ein sehr starkes Enterprise-Software- und Cloud-Geschäft mit sichtbarer AI-Nachfrage, bei dem Bewertungsdisziplin und Capex-Produktivität die entscheidenden Prüfstellen bleiben.',
    articleBody: [
      'Microsoft wird als starke Cloud- und Enterprise-Plattform mit AI-Investitionszyklus gelesen. Der Artikel trennt Nachfragebelege von der Frage, ob Kapazitätsaufbau in dauerhafte Cashflow-Hebel übersetzt.',
      'Im Vordergrund stehen Azure-Wachstum, Microsoft Cloud, Capex-Produktivität und freie Cashflow-Konversion. Die Preview bleibt lokal, bis Quellenlage und Review vollständig nachvollziehbar sind.',
    ],
    kpis: [
      'Q3-Umsatz: 82,89 Mrd. USD im lokalen Evidence-Paket.',
      'Microsoft Cloud: 54,50 Mrd. USD Umsatz und 29,0 % Wachstum.',
      'Azure-Wachstum: 40,0 %; AI-Umsatzlauf über 37,00 Mrd. USD.',
      'TTM-Umsatz: 311,90 Mrd. USD; TTM Free Cashflow: 67,65 Mrd. USD.',
    ],
    watchpoints: [
      'AI-Kapazitätsausbau muss sich in Marge und Free Cashflow niederschlagen.',
      'Azure-Wachstum bleibt der zentrale Nachweis für Enterprise-AI-Nachfrage.',
      'Reinvestitionen werden getrennt von dauerhaftem Cashflow-Hebel bewertet.',
    ],
    risks: [
      'AI-Infrastrukturkosten steigen schneller als Monetarisierung und Marge.',
      'Enterprise-IT-Ausgaben oder Cloud-Wachstum schwächen sich ab.',
      'Regulatorischer Druck und Bewertungsdruck bei ausbleibender Cashflow-Verbesserung.',
    ],
    evidence: [
      {
        label: 'SEC CompanyFacts',
        sourceId: 'MSFT_SEC_COMPANYFACTS_789019',
        sourceType: 'sec_filing',
        href: 'https://data.sec.gov/api/xbrl/companyfacts/CIK0000789019.json',
      },
      {
        label: 'Lokales Evidence-Paket',
        sourceId: 'MSFT_2026-05-08',
        sourceType: 'research_agent_bundle',
      },
    ],
    localArtifacts: [
      'publish_report.md',
      'publish_report_quality_score.json',
      'report_manifest.json',
      'source_registry.json',
    ],
  },
  {
    slug: 'nvidia-nvda-ai-fcf-review',
    ticker: 'NVDA',
    company: 'NVIDIA Corp.',
    shortName: 'NVIDIA',
    sector: 'Halbleiter / AI-Infrastruktur',
    title: 'NVIDIA: zurückgestellt bis manueller Review abgeschlossen ist',
    subtitle: 'Interner Kandidat, aktuell nicht öffentlich geroutet.',
    asOfDate,
    priceBasisDate: asOfDate,
    sourceBatch: currentBatch,
    reportId: 'NVDA_2026-05-08',
    qualityScore: 75,
    publicationStatus: 'manual_review',
    visibility: 'hidden',
    readingMinutes: 0,
    sourceCount: 0,
    displayStatus: 'Pilot-Entwurf',
    summary: 'Zurückgestellt.',
    thesis: 'Zurückgestellt.',
    kpis: [],
    watchpoints: [],
    risks: [],
    evidence: [],
    localArtifacts: [],
  },
  {
    slug: 'micron-technology-mu-room16-preview',
    ticker: 'MU',
    company: 'Micron Technology Inc.',
    shortName: 'Micron',
    sector: 'Speicher / Halbleiter',
    title: 'Micron: zurückgestellt bis manueller Review abgeschlossen ist',
    subtitle: 'Interner Kandidat, aktuell nicht öffentlich geroutet.',
    asOfDate,
    priceBasisDate: asOfDate,
    sourceBatch: currentBatch,
    reportId: 'MU_2026-05-08',
    qualityScore: 74,
    publicationStatus: 'manual_review',
    visibility: 'hidden',
    readingMinutes: 0,
    sourceCount: 0,
    displayStatus: 'Pilot-Entwurf',
    summary: 'Zurückgestellt.',
    thesis: 'Zurückgestellt.',
    kpis: [],
    watchpoints: [],
    risks: [],
    evidence: [],
    localArtifacts: [],
  },
];

export function getPublicAnalyses() {
  return quellwertAnalyses.filter(
    (analysis) => analysis.publicationStatus === 'pilot_ready' && analysis.visibility === 'public',
  );
}

export function getFeaturedAnalysis() {
  return getPublicAnalyses()[0];
}

export function getPublicAnalysisBySlug(slug: string) {
  return getPublicAnalyses().find((analysis) => analysis.slug === slug);
}

export function getAdjacentPublicAnalyses(slug: string) {
  const analyses = getPublicAnalyses();
  const index = analyses.findIndex((analysis) => analysis.slug === slug);

  if (index === -1) {
    return { prev: undefined, next: undefined } as const;
  }

  return {
    prev: index > 0 ? analyses[index - 1] : undefined,
    next: index < analyses.length - 1 ? analyses[index + 1] : undefined,
  } as const;
}

export function getInternalReviewAnalyses() {
  return quellwertAnalyses.filter((analysis) => analysis.visibility === 'hidden');
}

export function getAnalysisGateSummary(analysis: QuellwertAnalysis): QuellwertGateSummary {
  if (analysis.gate) {
    return {
      reviewLabel:
        analysis.gate.sourceReview === 'pass' ? 'Quellenprüfung bestätigt' : 'Quellenprüfung offen',
      sourceLabel: analysis.gate.officialSourceLabel,
      externalLabel: analysis.gate.operatorGoRequired
        ? 'Operator-Go erforderlich'
        : 'Operator-Go dokumentiert',
    };
  }

  return {
    reviewLabel: 'Pilot-Gate offen',
    sourceLabel: 'Lokales Evidence-Paket',
    externalLabel: 'Nicht extern freigegeben',
  };
}
