import { spawn } from 'child_process';
import { promises as fs } from 'fs';
import path from 'path';

import { WORKSPACE_ROOT } from '@/lib/constants/paths';

export interface LocalViviStartResult {
  ok: boolean;
  mode: 'launchagent' | 'direct-script' | 'unavailable';
  detail: string;
}

export async function startLocalDuoLoop(): Promise<LocalViviStartResult> {
  const launchResult = await kickstartLaunchAgent();
  if (launchResult.ok) return launchResult;

  const directResult = await startDirectLoopScript();
  return directResult.ok
    ? directResult
    : { ok: false, mode: 'unavailable', detail: `${launchResult.detail} Fallback: ${directResult.detail}` };
}

async function kickstartLaunchAgent(): Promise<LocalViviStartResult> {
  const uid = typeof process.getuid === 'function' ? process.getuid() : null;
  const plistPath = path.join(process.env.HOME || '', 'Library', 'LaunchAgents', 'com.lioncom.local-duo-loop.plist');

  try {
    await fs.access(plistPath);
  } catch {
    return { ok: false, mode: 'unavailable', detail: 'LaunchAgent ist nicht installiert.' };
  }

  if (uid === null) {
    return { ok: false, mode: 'unavailable', detail: 'Lokale Benutzer-ID konnte nicht ermittelt werden.' };
  }

  return new Promise((resolve) => {
    const child = spawn('/bin/launchctl', ['kickstart', '-k', `gui/${uid}/com.lioncom.local-duo-loop`], {
      env: buildLoopEnv(),
      stdio: 'ignore',
    });
    child.on('error', () => resolve({ ok: false, mode: 'unavailable', detail: 'LaunchAgent konnte nicht gestartet werden.' }));
    child.on('close', (code) => {
      resolve(code === 0
        ? { ok: true, mode: 'launchagent', detail: 'Lokaler Vivi-Duo-Loop wurde per LaunchAgent gestartet.' }
        : { ok: false, mode: 'unavailable', detail: `LaunchAgent Kickstart endete mit Code ${code ?? 'unbekannt'}.` });
    });
  });
}

async function startDirectLoopScript(): Promise<LocalViviStartResult> {
  const scriptPath = path.join(WORKSPACE_ROOT, 'scripts', 'run_local_duo_loop.sh');

  try {
    await fs.access(scriptPath);
  } catch {
    return { ok: false, mode: 'unavailable', detail: 'Lokales Vivi-Startskript wurde nicht gefunden.' };
  }

  try {
    const child = spawn('/bin/bash', [scriptPath], {
      cwd: WORKSPACE_ROOT,
      detached: true,
      env: buildLoopEnv(),
      stdio: 'ignore',
    });
    child.unref();
    return { ok: true, mode: 'direct-script', detail: 'Lokaler Vivi-Duo-Loop wurde direkt als Hintergrundlauf gestartet.' };
  } catch {
    return { ok: false, mode: 'unavailable', detail: 'Lokaler Vivi-Duo-Loop konnte nicht gestartet werden.' };
  }
}

function buildLoopEnv(): NodeJS.ProcessEnv {
  return {
    ...process.env,
    VIVI_WORKSPACE_ROOT: WORKSPACE_ROOT,
    LIONCOM_WORKSPACE_ROOT: WORKSPACE_ROOT,
    LIONCOM_APP_ROOT: path.join(WORKSPACE_ROOT, 'mission-control-board'),
  };
}
