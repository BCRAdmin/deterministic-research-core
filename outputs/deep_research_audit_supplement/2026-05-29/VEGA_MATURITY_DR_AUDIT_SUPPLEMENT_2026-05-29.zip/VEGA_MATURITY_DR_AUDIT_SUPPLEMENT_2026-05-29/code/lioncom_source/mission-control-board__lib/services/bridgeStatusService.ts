import { promises as fs } from 'fs';

import { PATHS } from '../constants/paths';
import type { ViviRuntimeSnapshot } from './viviBridgeService';
import { loadBridgeSecretStatus } from './bridgeSecretService';

export interface RemoteBridgeConfig {
  schemaVersion: '1.2';
  expectedMode: 'local' | 'vps' | 'hybrid';
  allowLocalFallback: boolean;
  controlPlaneUrl: string;
  ingestUrl: string;
  authMode: 'none' | 'bearer';
  staleAfterMinutes: number;
  offlineAfterMinutes: number;
  acceptedRemoteChannels: string[];
  acceptedLocalHosts: string[];
  remoteHost?: string;
  notes?: string;
}

export interface RemoteBridgeStatus {
  schemaVersion: '1.1';
  updatedAt: string;
  expectedMode: RemoteBridgeConfig['expectedMode'];
  allowLocalFallback: boolean;
  state: 'planned' | 'local-ready' | 'live-remote' | 'stale-remote' | 'offline';
  source: string;
  detail: string;
  suggestedAction: string;
  ingestUrl: string;
  controlPlaneUrl: string;
  authMode: RemoteBridgeConfig['authMode'];
  authReady: boolean;
  publicIngestReady: boolean;
  secretSource?: string;
  remoteHost?: string;
  lastHeartbeatAt?: string;
}

const DEFAULT_CONFIG: RemoteBridgeConfig = {
  schemaVersion: '1.2',
  expectedMode: 'hybrid',
  allowLocalFallback: true,
  controlPlaneUrl: 'http://127.0.0.1:3007',
  ingestUrl: 'http://127.0.0.1:3007/api/vivi',
  authMode: 'bearer',
  staleAfterMinutes: 12,
  offlineAfterMinutes: 45,
  acceptedRemoteChannels: ['vps', 'bridge', 'remote'],
  acceptedLocalHosts: ['lioncom-local', 'localhost', '127.0.0.1', 'local', 'local-mac'],
  remoteHost: 'vivi-vps',
  notes: 'Store the real LIONCOM_BRIDGE_TOKEN only in local secret storage or the VPS environment, never in git. Use hybrid while the Mac remains the operator control plane and the VPS is the remote worker.',
};

export async function ensureRemoteBridgeConfig(): Promise<RemoteBridgeConfig> {
  const existing = await safeJson<RemoteBridgeConfig>(PATHS.REMOTE_BRIDGE_CONFIG);
  if (existing) {
    const next: RemoteBridgeConfig = {
      ...DEFAULT_CONFIG,
      ...existing,
      schemaVersion: '1.2',
      controlPlaneUrl: normalizeBaseUrl(existing.controlPlaneUrl || stripApiSuffix(existing.ingestUrl) || DEFAULT_CONFIG.controlPlaneUrl),
      ingestUrl: normalizeIngestUrl(existing.ingestUrl || DEFAULT_CONFIG.ingestUrl),
      staleAfterMinutes: existing.staleAfterMinutes ?? DEFAULT_CONFIG.staleAfterMinutes,
      offlineAfterMinutes: existing.offlineAfterMinutes ?? DEFAULT_CONFIG.offlineAfterMinutes,
      acceptedRemoteChannels: existing.acceptedRemoteChannels?.length
        ? existing.acceptedRemoteChannels
        : DEFAULT_CONFIG.acceptedRemoteChannels,
      acceptedLocalHosts: existing.acceptedLocalHosts?.length
        ? existing.acceptedLocalHosts
        : DEFAULT_CONFIG.acceptedLocalHosts,
    };

    if (JSON.stringify(next) !== JSON.stringify(existing)) {
      await fs.writeFile(PATHS.REMOTE_BRIDGE_CONFIG, JSON.stringify(next, null, 2) + '\n', 'utf-8');
    }

    return next;
  }

  await fs.writeFile(PATHS.REMOTE_BRIDGE_CONFIG, JSON.stringify(DEFAULT_CONFIG, null, 2) + '\n', 'utf-8');
  return DEFAULT_CONFIG;
}

export async function syncRemoteBridgeStatus(viviRuntime: ViviRuntimeSnapshot | null): Promise<RemoteBridgeStatus> {
  const [config, secrets] = await Promise.all([
    ensureRemoteBridgeConfig(),
    loadBridgeSecretStatus(),
  ]);
  const heartbeatAt = viviRuntime?.runtime.heartbeatAt;
  const freshness = heartbeatAt ? ageMinutes(heartbeatAt) : Number.POSITIVE_INFINITY;
  const source = `${viviRuntime?.source || 'none'} / ${viviRuntime?.runtime.channel || 'none'}`;
  const host = (viviRuntime?.runtime.host || '').trim().toLowerCase();
  const channel = (viviRuntime?.runtime.channel || '').trim().toLowerCase();
  const remoteSignal = config.acceptedRemoteChannels.includes(channel)
    || (Boolean(host) && !config.acceptedLocalHosts.includes(host));
  const controlPlaneUrl = normalizeBaseUrl(config.controlPlaneUrl);
  const ingestUrl = normalizeIngestUrl(secrets.publicIngestUrl || config.ingestUrl);
  const publicIngestReady = secrets.publicIngestReady;
  const authReady = config.authMode === 'none' ? true : secrets.authReady;

  let state: RemoteBridgeStatus['state'] = 'planned';
  let detail = 'Remote bridge has not emitted a runtime signal yet.';
  let suggestedAction = 'Keep local fallback visible and arm the external bridge when you want live VPS truth in the board.';

  if (!viviRuntime) {
    state = config.expectedMode === 'local' ? 'local-ready' : 'planned';
    detail = config.expectedMode === 'local'
      ? 'Local-only bridge mode is configured and waiting for the next local Vivi heartbeat.'
      : 'No Vivi runtime snapshot exists yet. The bridge contract is present, but runtime signaling has not started.';
    suggestedAction = publicIngestReady
      ? 'Start the VPS emitter and verify that it can reach the declared ingest URL.'
      : 'Arm the public ingest URL first, then deploy the emitter to the VPS.';
  } else if (!publicIngestReady && remoteSignal) {
    state = 'local-ready';
    detail = 'Remote-style telemetry is visible, but the bridge ingest surface is still local-only. Treat this as rehearsal data, not proof of real VPS reachability.';
    suggestedAction = 'Arm a public ingest URL or tunnel, then redeploy the VPS emitter so remote telemetry becomes authoritative.';
  } else if (remoteSignal && freshness <= config.staleAfterMinutes) {
    state = 'live-remote';
    detail = `Fresh VPS-originated Vivi telemetry is visible (${describeFreshness(freshness)}).`;
    suggestedAction = authReady
      ? 'Remote bridge is healthy. Keep the VPS emitter running and monitor stale transitions.'
      : 'Telemetry is visible, but bridge auth is not armed locally. Add the bridge token before treating the channel as hardened.';
  } else if (remoteSignal && freshness <= config.offlineAfterMinutes) {
    state = 'stale-remote';
    detail = `The last VPS-originated Vivi heartbeat is stale (${describeFreshness(freshness)}).`;
    suggestedAction = 'Restore the VPS emitter or confirm that the current run is intentionally paused before trusting the live picture.';
  } else if (remoteSignal) {
    state = 'offline';
    detail = `The remote Vivi bridge has gone offline (${describeFreshness(freshness)}). Local fallback should not be treated as authoritative.`;
    suggestedAction = 'Run a rescue/repair pass and restore the VPS emitter before continuing remote-first operation.';
  } else if (config.allowLocalFallback) {
    state = 'local-ready';
    detail = publicIngestReady
      ? 'Local bridge rails are healthy, but no authoritative VPS signal has been observed yet.'
      : 'Local bridge rails are healthy. External activation is still pending, so the board is only proving the local control plane.';
    suggestedAction = publicIngestReady
      ? 'Trigger a real VPS heartbeat and keep local fallback as a safety net.'
      : 'Arm the bridge secrets and render the VPS deployment bundle before expecting real remote supervision.';
  } else {
    state = 'offline';
    detail = 'Only local fallback signals exist and remote fallback is disabled.';
    suggestedAction = 'Re-enable fallback or restore the authoritative VPS bridge before using the board.';
  }

  const status: RemoteBridgeStatus = {
    schemaVersion: '1.1',
    updatedAt: new Date().toISOString(),
    expectedMode: config.expectedMode,
    allowLocalFallback: config.allowLocalFallback,
    state,
    source,
    detail,
    suggestedAction,
    ingestUrl,
    controlPlaneUrl,
    authMode: config.authMode,
    authReady,
    publicIngestReady,
    secretSource: [REDACTED]
    remoteHost: viviRuntime?.runtime.host || secrets.remoteHost || config.remoteHost,
    lastHeartbeatAt: heartbeatAt,
  };

  await fs.writeFile(PATHS.REMOTE_BRIDGE_STATUS, JSON.stringify(status, null, 2) + '\n', 'utf-8');
  return status;
}

function normalizeIngestUrl(value: string): string {
  const trimmed = value.trim().replace(/\/+$/, '');
  if (trimmed.endsWith('/api/vivi')) return trimmed;
  return `${trimmed}/api/vivi`;
}

function normalizeBaseUrl(value: string): string {
  return stripApiSuffix(value).trim().replace(/\/+$/, '');
}

function stripApiSuffix(value: string): string {
  return value.trim().replace(/\/api\/vivi\/?$/i, '');
}

async function safeJson<T>(filePath: string): Promise<T | null> {
  try {
    return JSON.parse(await fs.readFile(filePath, 'utf-8')) as T;
  } catch {
    return null;
  }
}

function ageMinutes(value: string): number {
  const time = new Date(value).getTime();
  if (Number.isNaN(time)) return Number.POSITIVE_INFINITY;
  return Math.max(0, Math.floor((Date.now() - time) / 60000));
}

function describeFreshness(minutes: number): string {
  if (!Number.isFinite(minutes)) return 'no signal yet';
  if (minutes < 1) return 'less than a minute ago';
  if (minutes < 60) return `${minutes} minute${minutes === 1 ? '' : 's'} ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} hour${hours === 1 ? '' : 's'} ago`;
  const days = Math.floor(hours / 24);
  return `${days} day${days === 1 ? '' : 's'} ago`;
}
