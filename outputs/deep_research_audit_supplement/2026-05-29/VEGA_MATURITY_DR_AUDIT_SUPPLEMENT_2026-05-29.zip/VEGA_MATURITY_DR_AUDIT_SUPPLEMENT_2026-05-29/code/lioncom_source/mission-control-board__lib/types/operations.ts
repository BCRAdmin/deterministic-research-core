// Operations Types - Daily/Nightly/Backup

export interface DailyBriefing {
  date: string;
  generatedAt: string;
  openTasks: number;
  priorities: string[];
  blocked: string[];
}

export interface NightlyResearch {
  date: string;
  topic: string;
  status: 'scheduled' | 'running' | 'completed' | 'failed';
  output?: string;
}

export interface BackupStatus {
  lastBackup: string;
  status: 'success' | 'failed' | 'unknown';
  githubSync: boolean;
  lastCommit?: string;
}

export interface CronJob {
  name: string;
  schedule: string;
  enabled: boolean;
  lastRun?: string;
}

export interface OperationsSummary {
  dailyBriefings: DailyBriefing[];
  nightlyResearch: NightlyResearch[];
  backup: BackupStatus;
  cronJobs: CronJob[];
}
