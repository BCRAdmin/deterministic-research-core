export type ThemeVariant = 'knight' | 'signals';
export type TabId =
  | 'command'
  | 'approvals'
  | 'builder'
  | 'research'
  | 'projects'
  | 'agents'
  | 'automations'
  | 'comms'
  | 'codex'
  | 'system';

export interface MissionSummary {
  systemState: string;
  phase: string;
  progress: number;
  lastAction: string;
  nextStep: string;
  riskScore: number;
  executiveSummary: string;
  timeInPhase?: number;
  lastUpdated?: string;
}

export interface TelemetrySummary {
  state: 'live' | 'stale' | 'absent';
  freshnessMinutes?: number;
  lastUpdate?: string;
  runtimeResponsive: boolean;
  source: string;
  detail: string;
}

export interface BlockerSignal {
  description: string;
  impact?: string;
  workaround?: string;
}

export interface SystemAlert {
  id: string;
  severity: 'critical' | 'warning' | 'maintenance' | 'info';
  title: string;
  detail: string;
  recommendation: string;
  source: string;
  action: 'rescue' | 'queue-night' | 'review' | 'none';
  actionLabel?: string;
  actionTargetTab?: TabId;
  actionTargetAnchor?: string;
  followThrough?: string[];
}

export interface SummaryMetric {
  label: string;
  value: string;
  detail?: string;
  tone: 'ok' | 'warning' | 'critical' | 'info';
}

export interface AgentSignal {
  id: string;
  name: string;
  kind: 'agent' | 'automation' | 'service' | 'pipeline';
  status: 'active' | 'monitoring' | 'warning' | 'waiting' | 'offline';
  signal: string;
  detail: string;
  source: string;
  lastSeen?: string;
}

export interface TaskItem {
  id: string;
  title: string;
  status: string;
  priority?: string;
  owner?: string;
  deadline?: string;
  detail?: string;
}

export interface BacklogLane {
  lane: string;
  items: TaskItem[];
}

export interface BrainDumpEntry {
  id: string;
  addedAt: string;
  status: string;
  summary: string;
  context?: string;
  category?: string;
  attachments?: string[];
  attachmentCount?: number;
}

export interface CodexChatEntry {
  id: string;
  addedAt: string;
  role: 'operator' | 'codex' | 'system';
  status: string;
  summary: string;
  message: string;
  source?: string;
  reference?: string;
}

export interface WorkIntakeEntry {
  id: string;
  addedAt: string;
  status: string;
  urgency: string;
  title: string;
  desiredOutcome?: string;
  summary: string;
  category?: string;
  attachments?: string[];
  attachmentCount?: number;
}

export interface BridgePacket {
  id: string;
  channel: 'telegram' | 'codex' | 'repair' | 'vivi';
  addedAt: string;
  status: string;
  title: string;
  summary: string;
  target?: string;
  delivery?: string;
  source?: string;
  category?: string;
  priority?: string;
  dispatchTargetMode?: string;
  runtimeContext?: string;
  attachments?: string[];
  attachmentCount?: number;
}

export interface TelegramRelayStatus {
  inboundReady: boolean;
  outboundReady: boolean;
  criticalOnly: boolean;
  detail: string;
}

export interface DesktopLaunchIssue {
  severity: 'warning' | 'critical';
  message: string;
}

export interface DesktopDiagnostics {
  mode: 'desktop' | 'browser';
  appVersion?: string;
  workspaceRoot: string;
  workspaceValid: boolean;
  requiredMarkers: Array<{ name: string; present: boolean }>;
  serverPort?: number;
  startupState: 'ready' | 'starting' | 'warning' | 'failed' | 'unknown';
  startupDetail: string;
  issues: DesktopLaunchIssue[];
  logTail: string[];
  settingsPath: string;
  logPath: string;
  statusPath: string;
  asarEnabled: boolean;
  notarized: boolean;
  signingMode: 'ad-hoc' | 'configured' | 'unknown';
  viviRequestedProvider?: 'chatgpt' | 'ollama' | 'lmstudio' | string;
  viviRequestedModel?: string;
  viviEffectiveProvider?: 'chatgpt' | 'ollama' | 'lmstudio' | string;
  viviEffectiveModel?: string;
  viviFallbackModel?: string;
  viviModelState?: string;
  viviModelDetail?: string;
  viviModelLastError?: string | null;
}

export interface QualificationSection {
  id: 'G1' | 'G2' | 'G3';
  title: string;
  state: 'passed' | 'warning' | 'failed' | 'pending';
  detail: string;
  evidencePath: string;
}

export interface QualificationSnapshot {
  overallState: 'ready' | 'warning' | 'blocked' | 'not-run';
  releaseDecision: 'approved' | 'blocked' | 'conditional';
  updatedAt?: string;
  summary: string;
  completedSections: number;
  totalSections: number;
  sections: QualificationSection[];
  blockers: string[];
  residualRisks: string[];
  approvedFor: string[];
  notApprovedFor: string[];
  evidencePaths: string[];
}

export interface WorkBlockItem {
  id: string;
  title: string;
  lane: 'builder' | 'research' | 'repair' | 'bridge';
  stage: string;
  owner: 'vivi' | 'codex' | 'shared';
  priority: string;
  summary: string;
  desiredOutcome?: string;
  sourceRail: string;
  duplicateCount?: number;
  mergedRails?: string[];
  overallScore?: number;
  active: boolean;
  requiresCodex: boolean;
  requiresOperator: boolean;
}

export interface SubtaskItem {
  id: string;
  blockId: string;
  lane: 'builder' | 'research' | 'repair' | 'bridge';
  owner: 'vivi' | 'codex' | 'shared';
  status: 'done' | 'active' | 'queued';
  title: string;
  detail: string;
}

export interface DecisionItem {
  id: string;
  blockId?: string;
  title: string;
  reason: string;
  recommendation: string;
  status: 'open' | 'watching';
}

export interface ResearchItem {
  id: string;
  blockId: string;
  title: string;
  reason: string;
  status: 'queued' | 'active' | 'watching';
}

export interface FreezeStatus {
  state: 'clear' | 'watching' | 'frozen';
  reason: string;
  requiredAction: string;
}

export interface RoadmapItem {
  id: string;
  title: string;
  owner: 'vivi' | 'codex' | 'shared';
  lane: 'builder' | 'research' | 'repair' | 'bridge';
  stage: string;
  priority: string;
  actionWindow: 'now' | 'next' | 'later';
  overallScore: number;
  importance: number;
  expectedOutcome: number;
  downstreamLeverage: number;
  rationale: string;
}

export interface ExecutionRoadmap {
  focus: string;
  summary: string[];
  now: RoadmapItem[];
  next: RoadmapItem[];
  later: RoadmapItem[];
}

export interface AutonomyClaim {
  id: string;
  agent: 'vivi' | 'codex';
  claimState: 'claimed' | 'working' | 'completed' | 'released' | 'escalated' | 'stale';
  taskId: string;
  taskType: 'repair' | 'vivi-command' | 'work-block' | 'research' | 'codex-inbox' | 'decision';
  sourceRail: string;
  title: string;
  priority: 'critical' | 'high' | 'normal' | 'explore';
  projectLane?: string;
  reason: string;
  detail: string;
  reference?: string;
  claimedAt: string;
  lastHeartbeatAt: string;
  leaseUntil: string;
  stale: boolean;
  outcome?: string;
  modelRouteSnapshotAtClaimStart?: {
    capturedAt: string;
    source: 'autonomy-claim';
    requestedProvider?: string | null;
    requestedModel?: string | null;
    effectiveProvider?: string | null;
    effectiveModel?: string | null;
    modelState?: string | null;
    modelDetail?: string | null;
    claimModelRouteReason?: string | null;
    routeProbeOk?: boolean | null;
    routeProbeCheckedAt?: string | null;
    routeStatusPath: string;
    loopStatusPath: string;
  };
}

export interface AutonomyDispatchStatus {
  agent: 'vivi' | 'codex';
  state: 'ready' | 'busy' | 'attention' | 'blocked';
  summary: string;
  backlogCount: number;
  activeClaimId?: string;
  selectedTask?: {
    id: string;
    title: string;
    sourceRail: string;
    priority: 'critical' | 'high' | 'normal' | 'explore';
    projectLane?: string;
    reason: string;
    reference?: string;
  };
  instructions: string[];
}

export interface AutonomyStatus {
  readiness: 'ready' | 'warning' | 'blocked';
  summary: string;
  operatorFreedom: string;
  notes: string[];
  viviLoop: AutonomyDispatchStatus;
  codexLoop: AutonomyDispatchStatus;
  activeClaims: AutonomyClaim[];
  staleClaims: AutonomyClaim[];
}

export interface BridgeStatus {
  state: 'planned' | 'local-ready' | 'live-remote' | 'stale-remote' | 'offline';
  detail: string;
  suggestedAction: string;
  expectedMode: 'local' | 'vps' | 'hybrid';
  allowLocalFallback: boolean;
  source: string;
  ingestUrl: string;
  controlPlaneUrl: string;
  authReady: boolean;
  publicIngestReady: boolean;
  secretSource?: string;
  remoteHost?: string;
  lastHeartbeatAt?: string;
}

export interface GitHubSyncStatus {
  state: 'healthy' | 'warning' | 'blocked' | 'offline';
  pushReady: 'yes' | 'no' | 'unknown';
  authMode?: 'ssh' | 'https' | 'unknown';
  detail: string;
  suggestedFix?: string;
  lastError?: string;
  remoteConfigured: boolean;
  remoteUrl?: string;
  authLastChecked?: string;
}

export interface CodexRuntimeStatus {
  state: 'idle' | 'attention' | 'working' | 'reporting';
  pendingOperatorMessages: number;
  queuedPackets: number;
  latestReference?: string;
  stalePendingMessages: boolean;
  oldestPendingMinutes?: number;
  oldestQueuedMinutes?: number;
  watcherRecommendation: string;
  detail: string;
}

export interface TimelineEntry {
  time: string;
  label: string;
  detail?: string;
  tone: 'ok' | 'warning' | 'critical' | 'info';
}

export interface ViviReportEntry {
  id: string;
  addedAt: string;
  kind: string;
  state: string;
  phase: string;
  title: string;
  summary: string;
  outcome?: string;
  nextStep?: string;
  operatorAction?: string;
  commandRef?: string;
}

export interface ProjectSignal {
  name: string;
  path: string;
  modified?: string;
  category: 'project' | 'dashboard' | 'doc';
}

export interface AutomationSignal {
  id: string;
  name: string;
  status: 'active' | 'scheduled' | 'warning' | 'offline';
  schedule: string;
  detail: string;
}

export interface SourceSnapshot {
  name: string;
  path: string;
  status: 'online' | 'warning' | 'missing';
  detail: string;
  lastModified?: string;
}

export interface ControlRoomData {
  workspaceRoot: string;
  generatedAt: string;
  mission: MissionSummary;
  telemetry: TelemetrySummary;
  blockers: BlockerSignal[];
  alerts: SystemAlert[];
  maintenance: SystemAlert[];
  metrics: SummaryMetric[];
  agents: AgentSignal[];
  activeTasks: TaskItem[];
  waitingTasks: TaskItem[];
  backlog: BacklogLane[];
  completedTasks: TaskItem[];
  brainDump: BrainDumpEntry[];
  workIntake: WorkIntakeEntry[];
  workBlocks: WorkBlockItem[];
  subtasks: SubtaskItem[];
  researchQueue: ResearchItem[];
  decisionQueue: DecisionItem[];
  roadmap: ExecutionRoadmap;
  freeze: FreezeStatus;
  autonomy: AutonomyStatus;
  remoteBridge: BridgeStatus;
  githubSync: GitHubSyncStatus;
  codexChat: CodexChatEntry[];
  codexRuntime: CodexRuntimeStatus;
  codexInbox: BridgePacket[];
  viviCommandQueue: BridgePacket[];
  telegramInbox: BridgePacket[];
  telegramOutbox: BridgePacket[];
  telegramRelay: TelegramRelayStatus;
  desktop: DesktopDiagnostics;
  qualification: QualificationSnapshot;
  repairQueue: BridgePacket[];
  timeline: TimelineEntry[];
  viviSteps: TimelineEntry[];
  viviReports: ViviReportEntry[];
  decisions: string[];
  recommendations: string[];
  projects: ProjectSignal[];
  automations: AutomationSignal[];
  sources: SourceSnapshot[];
  notes: string[];
  git: {
    branch: string;
    hasRemote: boolean;
    lastCommit?: string;
    isRepo: boolean;
  };
}
