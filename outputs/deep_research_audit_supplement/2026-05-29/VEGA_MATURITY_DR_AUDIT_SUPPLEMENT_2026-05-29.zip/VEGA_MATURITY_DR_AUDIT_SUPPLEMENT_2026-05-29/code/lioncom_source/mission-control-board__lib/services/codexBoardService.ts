import { PATHS } from '../constants/paths';
import type { CodexChatEntry } from '../control-room/types';
import { appendRailBlock, ensureRailFile, extractField, parseRailBlocks, readRailContent, transformRailBlocks, updateBlockField } from './structuredRailService';

const CODEX_CHAT_HEADER = '# Codex Chat Thread\n\nAppend-only board-first conversation rail between operator and Codex.\n\n';

export interface CodexChatPayload {
  role: CodexChatEntry['role'];
  status?: string;
  message: string;
  summary?: string;
  source?: string;
  reference?: string;
}

export async function readCodexChatThread(): Promise<CodexChatEntry[]> {
  const blocks = parseRailBlocks(await safeRead(PATHS.CODEX_CHAT_THREAD));
  return blocksToChatEntries(blocks);
}

export async function appendCodexChatEntry(payload: CodexChatPayload): Promise<CodexChatEntry> {
  const now = new Date().toISOString();
  const entry: CodexChatEntry = {
    id: buildId('CCHAT', now),
    addedAt: now,
    role: payload.role,
    status: payload.status || (payload.role === 'operator' ? 'new' : 'sent'),
    summary: payload.summary || summarize(payload.message),
    message: payload.message.trim(),
    source: payload.source || inferSource(payload.role),
    reference: payload.reference,
  };

  const block = [
    `### ${entry.id}`,
    `- Added: ${entry.addedAt}`,
    `- Role: ${entry.role}`,
    `- Status: ${entry.status}`,
    `- Source: ${entry.source || 'Unknown'}`,
    `- Reference: ${entry.reference || 'None supplied'}`,
    `- Summary: ${entry.summary}`,
    '- Message:',
    ...entry.message.split('\n').map((line) => `> ${line}`),
    '',
  ].join('\n');

  await appendRailBlock(PATHS.CODEX_CHAT_THREAD, CODEX_CHAT_HEADER, `${block}\n`);
  return entry;
}

export async function reconcileCodexChat(reference?: string, replyToId?: string): Promise<void> {
  const thread = await readCodexChatThread();
  const replyTarget = thread.find((entry) => entry.id === replyToId)
    || thread.find((entry) => entry.role === 'operator' && entry.reference === reference && entry.status === 'new')
    || thread.find((entry) => entry.role === 'operator' && entry.reference === reference && entry.status === 'claimed')
    || thread.find((entry) => entry.role === 'operator' && entry.status === 'new');

  if (!replyTarget) return;

  await transformRailBlocks(PATHS.CODEX_CHAT_THREAD, CODEX_CHAT_HEADER, (block) => {
    if (block.id !== replyTarget.id) return block;

    return {
      ...block,
      fields: { ...block.fields, Status: 'answered' },
      lines: updateBlockField(block.lines, 'Status', 'answered'),
    };
  });
}

export async function claimCodexWork(reference?: string, replyToId?: string): Promise<void> {
  if (!reference && !replyToId) return;

  await transformRailBlocks(PATHS.CODEX_CHAT_THREAD, CODEX_CHAT_HEADER, (block) => {
    const blockReference = extractField(block.lines, 'Reference');
    const status = normalizeField(extractField(block.lines, 'Status'));
    const isTarget = block.id === replyToId || blockReference === reference;
    if (!isTarget) return block;
    if (!['new', 'queued', 'claimed'].includes(status)) return block;

    return {
      ...block,
      lines: updateBlockField(block.lines, 'Status', 'claimed'),
    };
  });

  await setCodexInboxStatus(reference || replyToId, 'claimed');
}

export async function closeCodexWork(reference?: string, replyToId?: string): Promise<void> {
  if (!reference && !replyToId) return;

  await transformRailBlocks(PATHS.CODEX_CHAT_THREAD, CODEX_CHAT_HEADER, (block) => {
    const blockReference = extractField(block.lines, 'Reference');
    const isTarget = block.id === replyToId || blockReference === reference;
    if (!isTarget) return block;

    return {
      ...block,
      lines: updateBlockField(block.lines, 'Status', 'closed'),
    };
  });

  await setCodexInboxStatus(reference || replyToId, 'closed');
}

export async function markCodexInboxHandled(reference?: string): Promise<void> {
  if (!reference) return;

  await setCodexInboxStatus(reference, 'answered');
}

export function parseCodexChatThread(content: string | null): CodexChatEntry[] {
  return blocksToChatEntries(parseRailBlocks(content));
}

function blocksToChatEntries(blocks: ReturnType<typeof parseRailBlocks>): CodexChatEntry[] {
  return blocks.map((block) => {
    const messageLines: string[] = [];
    let captureMessage = false;

    for (const line of block.lines) {
      const trimmed = line.trim();

      if (trimmed.startsWith('- Message:')) {
        captureMessage = true;
        const rest = trimmed.replace(/^- Message:\s*/, '');
        if (rest) messageLines.push(rest);
        continue;
      }

      if (captureMessage) {
        if (trimmed.startsWith('> ')) {
          messageLines.push(trimmed.slice(2));
          continue;
        }

        if (!trimmed) {
          continue;
        }
      }
    }

    return {
      id: block.id,
      addedAt: block.fields['Added'] || 'unknown',
      role: normalizeRole(block.fields['Role']),
      status: block.fields['Status'] || 'unknown',
      summary: block.fields['Summary'] || summarize(messageLines.join('\n') || block.id),
      message: messageLines.join('\n').trim() || block.fields['Summary'] || block.id,
      source: block.fields['Source'],
      reference: block.fields['Reference'],
    } satisfies CodexChatEntry;
  }).reverse().slice(0, 24);
}

function normalizeRole(value?: string): CodexChatEntry['role'] {
  const lowered = value?.trim().toLowerCase();
  if (lowered === 'codex') return 'codex';
  if (lowered === 'system') return 'system';
  return 'operator';
}

function normalizeField(value?: string): string {
  return value?.trim().toLowerCase() || '';
}

function summarize(value: string): string {
  const compact = value.replace(/\s+/g, ' ').trim();
  if (!compact) return 'Codex board message';
  return compact.slice(0, 180);
}

function inferSource(role: CodexChatEntry['role']): string {
  if (role === 'codex') return 'Codex';
  if (role === 'system') return 'LIONCOM system';
  return 'Mission Control App';
}

async function setCodexInboxStatus(reference: string | undefined, status: string): Promise<void> {
  if (!reference) return;

  await transformRailBlocks(
    PATHS.CODEX_INBOX,
    '# Codex Inbox\n\nLocal command packets prepared for Codex-side implementation, review or debugging work.\n\n',
    (block) => {
      const blockReference = extractField(block.lines, 'Reference');
      if (block.id !== reference && blockReference !== reference) return block;

      return {
        ...block,
        lines: updateBlockField(block.lines, 'Status', status),
      };
    },
  );
}

function buildId(prefix: string, iso: string): string {
  const stamp = iso.replace(/[-:TZ]/g, '').replace('.', '').slice(0, 17);
  const entropy = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `${prefix}-${stamp}-${entropy}`;
}

async function safeRead(filePath: string): Promise<string | null> {
  await ensureRailFile(filePath, CODEX_CHAT_HEADER);
  return readRailContent(filePath);
}
