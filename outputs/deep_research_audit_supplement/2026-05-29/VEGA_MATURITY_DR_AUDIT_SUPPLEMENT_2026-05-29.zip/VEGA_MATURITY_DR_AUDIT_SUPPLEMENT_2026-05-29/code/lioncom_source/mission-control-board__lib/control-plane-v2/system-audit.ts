import 'server-only';

import { promises as fs } from 'fs';
import path from 'path';

import { PATHS, WORKSPACE_ROOT } from '@/lib/constants/paths';
import { loadControlPlaneV2Data } from '@/lib/control-plane-v2/live-data';
import type { OperatorLoopStatus } from '@/lib/types';

export type SystemAuditSeverity = 'ok' | 'warning' | 'critical';

export interface SystemAuditCheck {
  id: string;
  label: string;
  severity: SystemAuditSeverity;
  summary: string;
  detail: string;
}

export interface SystemAuditSnapshot {
  generatedAt: string;
  overall: 'ready' | 'attention' | 'blocked';
  score: number;
  checks: SystemAuditCheck[];
  nextActions: string[];
}

interface ViviSessionLite {
  id?: string;
  title?: string;
  status?: string;
  updatedAt?: string;
}

interface LocalLoopStatusLite {
  updatedAt?: string;
  state?: string;
  detail?: string;
  lastExitCode?: number;
}

export async function loadSystemAudit(): Promise<SystemAuditSnapshot> {
  const checks: SystemAuditCheck[] = [];
  const generatedAt = new Date().toISOString();

  const liveData = await loadControlPlaneV2Data();
  checks.push({
    id: 'control-plane-data',
    label: 'Control Plane V2 Daten',
    severity: liveData.source === 'live' ? 'ok' : 'critical',
    summary: liveData.source === 'live' ? 'Live-Snapshot aktiv' : 'Fallback-Daten aktiv',
    detail: liveData.source === 'live'
      ? `Snapshot ${liveData.generatedAt}, Queue ${liveData.globalStatus.queueDepth}, Claims ${liveData.globalStatus.activeClaims}.`
      : 'V2 fällt auf Mock-Daten zurück. Vor produktiver Nutzung muss der lokale ControlRoom-Snapshot wieder lesbar sein.',
  });

  checks.push(await fileCheck('vivi-chat-sessions', 'Vivi Session-Datei', PATHS.VIVI_CHAT_SESSIONS, true));
  checks.push(await fileCheck('vivi-chat-thread', 'Vivi Chat-Rail', PATHS.VIVI_CHAT_THREAD, true));
  checks.push(await fileCheck('vivi-command-queue', 'Vivi Command Queue', PATHS.VIVI_COMMAND_QUEUE, true));
  checks.push(await fileCheck('work-intake', 'Work Intake', PATHS.WORK_INTAKE, true));
  checks.push(await fileCheck('vivi-runtime', 'Vivi Runtime', PATHS.VIVI_RUNTIME, true));
  checks.push(await fileCheck('vivi-state', 'Vivi State', PATHS.VIVI_STATE, true));

  const sessions = await readJsonArray<ViviSessionLite>(PATHS.VIVI_CHAT_SESSIONS);
  const staleWaiting = sessions.filter((session) => session.status === 'waiting' && isOlderThan(session.updatedAt, 8 * 60 * 60 * 1000));
  checks.push({
    id: 'vivi-sessions',
    label: 'Vivi Sessions',
    severity: sessions.length === 0 ? 'warning' : staleWaiting.length > 0 ? 'warning' : 'ok',
    summary: sessions.length === 0 ? 'Keine aktive Session' : `${sessions.length} aktive Sessions`,
    detail: staleWaiting.length > 0
      ? `${staleWaiting.length} Session(s) warten seit mehr als 8 Stunden auf Vivi. In v2 werden sie als Aufmerksamkeit markiert.`
      : 'Session-Liste ist lesbar; neue Sessions erhalten automatisch Boot-Kontext.',
  });

  const chatThread = await readText(PATHS.VIVI_CHAT_THREAD);
  checks.push({
    id: 'vivi-auto-boot-context',
    label: 'Vivi Auto-Boot-Kontext',
    severity: chatThread.includes('Vivi Auto-Start-Kontext') ? 'ok' : 'warning',
    summary: chatThread.includes('Vivi Auto-Start-Kontext') ? 'Boot-Kontext vorhanden' : 'Boot-Kontext fehlt noch',
    detail: chatThread.includes('Vivi Auto-Start-Kontext')
      ? 'Vivi bekommt die Backbone-/Vault-Lesereihenfolge automatisch in neue Sessions geschrieben.'
      : 'Lege eine neue Vivi-Session an oder speichere eine bestehende, damit der Startkontext sichtbar im Rail landet.',
  });

  checks.push(await fileCheck('local-loop-status', 'Lokaler Duo-Loop Status', PATHS.LOCAL_DUO_LOOP_STATUS, false));
  const loopStatus = await readJsonObject<LocalLoopStatusLite>(PATHS.LOCAL_DUO_LOOP_STATUS);
  if (loopStatus) {
    checks.push({
      id: 'local-loop-freshness',
      label: 'Lokaler Duo-Loop Heartbeat',
      severity: isOlderThan(loopStatus.updatedAt, 2 * 60 * 60 * 1000) ? 'warning' : 'ok',
      summary: loopStatus.state ? `Status ${loopStatus.state}` : 'Statusdatei lesbar',
      detail: `${loopStatus.updatedAt ?? 'ohne Zeitstempel'} · ${loopStatus.detail ?? 'kein Detail'} · Exit ${loopStatus.lastExitCode ?? 'unbekannt'}`,
    });
  }

  checks.push(await fileCheck(
    'launchagent',
    'Vivi LaunchAgent',
    path.join(process.env.HOME || '', 'Library', 'LaunchAgents', 'com.lioncom.local-duo-loop.plist'),
    false,
  ));
  checks.push(await fileCheck(
    'runtime-app-sync',
    'Runtime App-Sync',
    path.join(WORKSPACE_ROOT, 'mission-control-board', '.next', 'BUILD_ID'),
    false,
  ));

  const score = scoreChecks(checks);
  const overall = checks.some((check) => check.severity === 'critical')
    ? 'blocked'
    : checks.some((check) => check.severity === 'warning')
      ? 'attention'
      : 'ready';

  return {
    generatedAt,
    overall,
    score,
    checks,
    nextActions: buildNextActions(checks, liveData.operatorLoopStatus),
  };
}

async function fileCheck(id: string, label: string, targetPath: string, critical: boolean): Promise<SystemAuditCheck> {
  try {
    const stat = await fs.stat(targetPath);
    return {
      id,
      label,
      severity: stat.size > 0 || stat.isDirectory() ? 'ok' : critical ? 'critical' : 'warning',
      summary: stat.isDirectory() ? 'Ordner vorhanden' : `${formatBytes(stat.size)}`,
      detail: targetPath,
    };
  } catch {
    return {
      id,
      label,
      severity: critical ? 'critical' : 'warning',
      summary: 'Fehlt',
      detail: targetPath,
    };
  }
}

async function readText(targetPath: string): Promise<string> {
  try {
    return await fs.readFile(targetPath, 'utf-8');
  } catch {
    return '';
  }
}

async function readJsonArray<T>(targetPath: string): Promise<T[]> {
  try {
    const parsed = JSON.parse(await fs.readFile(targetPath, 'utf-8')) as unknown;
    return Array.isArray(parsed) ? parsed as T[] : [];
  } catch {
    return [];
  }
}

async function readJsonObject<T>(targetPath: string): Promise<T | null> {
  try {
    const parsed = JSON.parse(await fs.readFile(targetPath, 'utf-8')) as unknown;
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed as T : null;
  } catch {
    return null;
  }
}

function scoreChecks(checks: SystemAuditCheck[]): number {
  if (checks.length === 0) return 0;
  const lost = checks.reduce((sum, check) => sum + (check.severity === 'critical' ? 22 : check.severity === 'warning' ? 8 : 0), 0);
  return Math.max(0, Math.min(100, 100 - lost));
}

function buildNextActions(checks: SystemAuditCheck[], loop?: OperatorLoopStatus): string[] {
  const actions = checks
    .filter((check) => check.severity !== 'ok')
    .slice(0, 4)
    .map((check) => `${check.label}: ${check.summary}`);

  if (actions.length > 0) {
    return actions;
  }
  if (loop?.state === 'running') {
    return [
      `Vivi arbeitet lokal${loop.taskTitle ? ` an "${loop.taskTitle}"` : ''}. Beobachte Fortschritt, Gate-Status und Session-Ausgabe.`,
      'Neue Operator-Eingaben können weiter über Vivi Command oder Dispatch Bridge eingehen.',
    ];
  }
  if (loop?.state === 'ready') {
    return ['System ist lokal arbeitsbereit. Nächster sinnvoller Schritt: Vivi-Session öffnen oder neuen Dispatch anlegen.'];
  }
  return ['System ist lokal arbeitsbereit. Prüfe Vivi-Session, Dispatch Bridge und aktuellen Loop-Status.'];
}

function isOlderThan(value: string | undefined, maxAgeMs: number): boolean {
  const time = value ? Date.parse(value) : NaN;
  return Number.isNaN(time) || Date.now() - time > maxAgeMs;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
