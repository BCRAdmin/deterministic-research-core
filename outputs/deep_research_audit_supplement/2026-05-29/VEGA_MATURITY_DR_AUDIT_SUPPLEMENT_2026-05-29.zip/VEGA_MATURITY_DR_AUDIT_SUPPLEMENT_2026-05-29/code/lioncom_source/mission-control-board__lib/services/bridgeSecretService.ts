import os from 'os';
import path from 'path';

import { WORKSPACE_ROOT } from '../constants/paths';
import { loadEnvFileCandidates } from './envFileService';

export interface BridgeSecretSnapshot {
  bridgeToken?: string;
  publicIngestUrl?: string;
  remoteHost?: string;
  source?: string;
  hasWorkspaceFile: boolean;
  hasHomeEnvFile: boolean;
  authReady: boolean;
  publicIngestReady: boolean;
}

const BRIDGE_SECRET_CANDIDATES = [
  path.join(WORKSPACE_ROOT, '.secrets', 'lioncom_bridge.env'),
  path.join(WORKSPACE_ROOT, '.secrets', 'lioncom_bridge'),
  path.join(os.homedir(), '.openclaw', 'secrets', 'lioncom_bridge.env'),
] as const;

export async function loadBridgeSecretStatus(): Promise<BridgeSecretSnapshot> {
  const loaded = await loadEnvFileCandidates(BRIDGE_SECRET_CANDIDATES);
  const values = loaded.values;

  const bridgeToken = firstNonEmpty(
    process.env.LIONCOM_BRIDGE_TOKEN,
    values.LIONCOM_BRIDGE_TOKEN,
  );
  const publicIngestUrl = firstNonEmpty(
    process.env.LIONCOM_PUBLIC_INGEST_URL,
    process.env.LIONCOM_INGEST_URL,
    values.LIONCOM_PUBLIC_INGEST_URL,
    values.LIONCOM_INGEST_URL,
  );
  const remoteHost = firstNonEmpty(
    process.env.VIVI_SIGNAL_HOST,
    process.env.LIONCOM_REMOTE_HOST,
    values.VIVI_SIGNAL_HOST,
    values.LIONCOM_REMOTE_HOST,
  );

  return {
    bridgeToken,
    publicIngestUrl,
    remoteHost,
    source: loaded.source || inferEnvironmentSource(bridgeToken, publicIngestUrl, remoteHost),
    hasWorkspaceFile: Boolean(loaded.source?.includes(`${path.sep}.secrets${path.sep}`)),
    hasHomeEnvFile: Boolean(loaded.source?.includes(`${path.sep}.openclaw${path.sep}secrets${path.sep}`)),
    authReady: Boolean(bridgeToken),
    publicIngestReady: Boolean(publicIngestUrl && isPublicUrl(publicIngestUrl)),
  };
}

function firstNonEmpty(...values: Array<string | undefined>): string | undefined {
  for (const value of values) {
    const trimmed = value?.trim();
    if (trimmed) return trimmed;
  }

  return undefined;
}

function inferEnvironmentSource(...values: Array<string | undefined>): string | undefined {
  return values.some((value) => value?.trim()) ? 'environment' : undefined;
}

function isPublicUrl(value: string): boolean {
  try {
    const parsed = new URL(value);
    const host = parsed.hostname.trim().toLowerCase();
    return !['127.0.0.1', 'localhost', '::1'].includes(host);
  } catch {
    return false;
  }
}
