import path from 'path';
import { promises as fs } from 'fs';

import { PATHS, WORKSPACE_ROOT } from '../constants/paths';

export interface StoredAttachment {
  name: string;
  absolutePath: string;
  relativePath: string;
  mimeType: string;
  size: number;
}

interface FileLike {
  name?: string;
  type?: string;
  size?: number;
  arrayBuffer: () => Promise<ArrayBuffer>;
}

function isFileLike(value: FormDataEntryValue): value is File {
  return typeof value !== 'string'
    && typeof (value as Partial<FileLike>).arrayBuffer === 'function';
}

function sanitizeFilename(filename: string): string {
  const normalized = filename
    .normalize('NFKD')
    .replace(/[^\w.\- ]+/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .trim();

  return normalized || 'attachment';
}

export async function storeUploadedAttachments(input: {
  scope: 'brain-dump' | 'work-intake' | 'telegram-packet';
  entryId: string;
  files: FormDataEntryValue[];
}): Promise<StoredAttachment[]> {
  const attachments = input.files.filter(isFileLike).filter((file) => Number(file.size || 0) > 0);
  if (attachments.length === 0) {
    return [];
  }

  const targetDir = path.join(PATHS.ATTACHMENTS_DIR, input.scope, input.entryId);
  await fs.mkdir(targetDir, { recursive: true });

  const stored = await Promise.all(attachments.map(async (file, index) => {
    const safeName = sanitizeFilename(file.name || `attachment-${index + 1}`);
    const storedName = `${String(index + 1).padStart(2, '0')}-${safeName}`;
    const absolutePath = path.join(targetDir, storedName);
    const buffer = Buffer.from(await file.arrayBuffer());

    await fs.writeFile(absolutePath, buffer);

    return {
      name: file.name || safeName,
      absolutePath,
      relativePath: path.relative(WORKSPACE_ROOT, absolutePath),
      mimeType: file.type || 'application/octet-stream',
      size: buffer.byteLength,
    };
  }));

  return stored;
}

export function renderAttachmentLines(attachments: StoredAttachment[]): string {
  if (attachments.length === 0) {
    return '';
  }

  return [
    `- Attachments Count: ${attachments.length}`,
    `- Attachments: ${attachments.map((item) => item.name).join(' | ')}`,
    `- Attachment Paths: ${attachments.map((item) => item.relativePath).join(' | ')}`,
  ].join('\n') + '\n';
}
