export type ViviProviderMode = 'cloud' | 'local';
export type ViviProviderPreset = 'chatgpt' | 'lmstudio' | 'ollama' | 'openrouter';

export interface ViviProviderOption {
  value: ViviProviderPreset;
  label: string;
  mode: ViviProviderMode;
  detail: string;
}

export interface ViviModelOption {
  id: string;
  label: string;
  provider: ViviProviderPreset;
  mode: ViviProviderMode;
  source: 'catalog' | 'fallback' | 'live';
}

export interface ViviProviderStatus {
  key: string;
  value: ViviProviderPreset;
  mode: ViviProviderMode;
  label: string;
  available: boolean;
  modelCount: number;
  liveModelCount: number;
  fallbackModelCount: number;
  source: 'live' | 'fallback' | 'empty';
  detail: string;
  warning?: string;
}

export interface ViviModelCatalog {
  generatedAt: string;
  providers: ViviProviderOption[];
  models: ViviModelOption[];
  providerStatus: ViviProviderStatus[];
  warnings: string[];
}

export const VIVI_PROVIDER_OPTIONS: ViviProviderOption[] = [
  { value: 'lmstudio', label: 'LM Studio lokal', mode: 'local', detail: 'Lokale LM-Studio-Modelle aus /v1/models.' },
  { value: 'ollama', label: 'Ollama lokal', mode: 'local', detail: 'Lokal gespeicherte Ollama-Modelle aus /api/tags.' },
  { value: 'ollama', label: 'Ollama Cloud', mode: 'cloud', detail: 'Ollama-Providerpfad mit Cloud-Offload-Modellen.' },
  { value: 'chatgpt', label: 'ChatGPT Cloud', mode: 'cloud', detail: 'Bekannte ChatGPT/Codex-Modelle.' },
  { value: 'openrouter', label: 'OpenRouter', mode: 'cloud', detail: 'OpenRouter-Modellkatalog, wenn erreichbar.' },
];

const FALLBACK_MODELS: ViviModelOption[] = [
  { id: 'qwen3.5-vivi:9b', label: 'qwen3.5-vivi:9b', provider: 'lmstudio', mode: 'local', source: 'fallback' },
  { id: 'qwen2.5-coder:7b', label: 'qwen2.5-coder:7b', provider: 'ollama', mode: 'local', source: 'fallback' },
  { id: 'deepseek-v4-pro:cloud', label: 'deepseek-v4-pro:cloud', provider: 'ollama', mode: 'cloud', source: 'catalog' },
  { id: 'kimi-k2.6:cloud', label: 'kimi-k2.6:cloud', provider: 'ollama', mode: 'cloud', source: 'catalog' },
  { id: 'gpt-5.4', label: 'gpt-5.4', provider: 'chatgpt', mode: 'cloud', source: 'catalog' },
  { id: 'gpt-5.4-mini', label: 'gpt-5.4-mini', provider: 'chatgpt', mode: 'cloud', source: 'catalog' },
  { id: 'gpt-5.5', label: 'gpt-5.5', provider: 'chatgpt', mode: 'cloud', source: 'catalog' },
  { id: 'openai/gpt-5.4', label: 'openai/gpt-5.4', provider: 'openrouter', mode: 'cloud', source: 'fallback' },
  { id: 'openai/gpt-chat-latest', label: 'openai/gpt-chat-latest', provider: 'openrouter', mode: 'cloud', source: 'fallback' },
  { id: 'deepseek/deepseek-v4-pro', label: 'deepseek/deepseek-v4-pro', provider: 'openrouter', mode: 'cloud', source: 'fallback' },
  { id: 'moonshotai/kimi-k2.6', label: 'moonshotai/kimi-k2.6', provider: 'openrouter', mode: 'cloud', source: 'fallback' },
];

const PREFERRED_MODEL_ORDER: Record<string, string[]> = {
  'local:lmstudio': ['qwen3.5-vivi:9b'],
  'local:ollama': ['qwen3.5-vivi:9b', 'qwen3.5:9b', 'gemma4:e4b', 'qwen2.5-coder:7b', 'qwen2.5-coder:3b'],
  'cloud:ollama': ['deepseek-v4-pro:cloud', 'kimi-k2.6:cloud', 'glm-5.1:cloud'],
  'cloud:chatgpt': ['gpt-5.4', 'gpt-5.4-mini', 'gpt-5.5'],
  'cloud:openrouter': ['openai/gpt-5.4', 'openai/gpt-chat-latest', 'deepseek/deepseek-v4-pro', 'moonshotai/kimi-k2.6'],
};

export function providerModeForPreset(provider: ViviProviderPreset, requestedMode?: ViviProviderMode): ViviProviderMode {
  if (provider === 'chatgpt' || provider === 'openrouter') return 'cloud';
  if (provider === 'lmstudio') return 'local';
  return requestedMode === 'cloud' ? 'cloud' : 'local';
}

export function normalizeViviProviderPreset(value?: string): ViviProviderPreset {
  if (value === 'chatgpt' || value === 'ollama' || value === 'lmstudio' || value === 'openrouter') return value;
  return 'lmstudio';
}

export function normalizeViviProviderMode(value: string | undefined, provider: ViviProviderPreset): ViviProviderMode {
  if (value === 'cloud' || value === 'local') return providerModeForPreset(provider, value);
  return providerModeForPreset(provider);
}

export function defaultViviModel(provider: ViviProviderPreset, mode?: ViviProviderMode): string {
  const providerMode = providerModeForPreset(provider, mode);
  return FALLBACK_MODELS.find((model) => model.provider === provider && model.mode === providerMode)?.id
    ?? FALLBACK_MODELS.find((model) => model.provider === provider)?.id
    ?? 'qwen3.5-vivi:9b';
}

export function modelsForProvider(
  catalog: Pick<ViviModelCatalog, 'models'>,
  provider: ViviProviderPreset,
  mode?: ViviProviderMode,
): ViviModelOption[] {
  const providerMode = providerModeForPreset(provider, mode);
  const seen = new Set<string>();
  return catalog.models
    .filter((model) => model.provider === provider && model.mode === providerMode)
    .filter((model) => {
      if (seen.has(model.id)) return false;
      seen.add(model.id);
      return true;
    })
    .sort(compareViviModels);
}

export function normalizeViviRequestedModel(
  provider: ViviProviderPreset,
  value?: string,
  mode?: ViviProviderMode,
  catalog: Pick<ViviModelCatalog, 'models'> = { models: FALLBACK_MODELS },
): string {
  const requested = value?.trim() || '';
  const providerMode = providerModeForPreset(provider, mode);
  const allowed = modelsForProvider(catalog, provider, providerMode);
  if (requested && allowed.some((model) => model.id === requested)) return requested;
  return allowed[0]?.id ?? defaultViviModel(provider, providerMode);
}

export function createFallbackViviModelCatalog(warnings: string[] = []): ViviModelCatalog {
  const models = sortViviModelOptions(FALLBACK_MODELS);
  return {
    generatedAt: new Date().toISOString(),
    providers: VIVI_PROVIDER_OPTIONS,
    models,
    providerStatus: createViviProviderStatus(models, warnings),
    warnings,
  };
}

export function mergeModelOptions(...groups: ViviModelOption[][]): ViviModelOption[] {
  const seen = new Set<string>();
  const merged: ViviModelOption[] = [];
  for (const group of groups) {
    for (const model of group) {
      const key = `${model.mode}:${model.provider}:${model.id}`;
      if (seen.has(key)) continue;
      seen.add(key);
      merged.push(model);
    }
  }
  return sortViviModelOptions(merged);
}

export function createViviProviderStatus(
  models: ViviModelOption[],
  warnings: string[] = [],
): ViviProviderStatus[] {
  return VIVI_PROVIDER_OPTIONS.map((provider) => {
    const providerModels = modelsForProvider({ models }, provider.value, provider.mode);
    const liveModelCount = providerModels.filter((model) => model.source === 'live').length;
    const fallbackModelCount = providerModels.filter((model) => model.source !== 'live').length;
    const warning = matchingProviderWarning(provider, warnings);
    const source = liveModelCount > 0 ? 'live' : fallbackModelCount > 0 ? 'fallback' : 'empty';
    return {
      key: providerKey(provider.value, provider.mode),
      value: provider.value,
      mode: provider.mode,
      label: provider.label,
      available: providerModels.length > 0,
      modelCount: providerModels.length,
      liveModelCount,
      fallbackModelCount,
      source,
      detail: source === 'live'
        ? `${liveModelCount} Live-Modelle erkannt.`
        : source === 'fallback'
          ? `${fallbackModelCount} kuratierte Fallback-Modelle verfügbar; Live-Katalog nicht bestätigt.`
          : 'Keine Modelle verfügbar.',
      warning,
    };
  });
}

export function providerKey(provider: ViviProviderPreset, mode?: ViviProviderMode): string {
  return `${providerModeForPreset(provider, mode)}:${provider}`;
}

export function modelSourceLabel(source: ViviModelOption['source']): string {
  if (source === 'live') return 'live';
  if (source === 'catalog') return 'kuratiert';
  return 'fallback';
}

export function sortViviModelOptions(models: ViviModelOption[]): ViviModelOption[] {
  return [...models].sort(compareViviModels);
}

function compareViviModels(left: ViviModelOption, right: ViviModelOption): number {
  const leftRank = modelRank(left);
  const rightRank = modelRank(right);
  if (leftRank !== rightRank) return leftRank - rightRank;
  const sourceDelta = sourceRank(left.source) - sourceRank(right.source);
  if (sourceDelta !== 0) return sourceDelta;
  return left.id.localeCompare(right.id);
}

function modelRank(model: ViviModelOption): number {
  const preferred = PREFERRED_MODEL_ORDER[providerKey(model.provider, model.mode)] || [];
  const exact = preferred.indexOf(model.id);
  if (exact >= 0) return exact;
  const normalized = model.id.toLowerCase();
  if (/gpt-5|gpt-chat|deepseek|kimi|qwen3\.5/.test(normalized)) return 100;
  if (/claude|gemini|llama|mistral/.test(normalized)) return 150;
  return 300;
}

function sourceRank(source: ViviModelOption['source']): number {
  if (source === 'live') return 0;
  if (source === 'catalog') return 1;
  return 2;
}

function matchingProviderWarning(provider: ViviProviderOption, warnings: string[]): string | undefined {
  const label = provider.label.toLowerCase();
  const providerName = provider.value.toLowerCase();
  return warnings.find((warning) => {
    const normalized = warning.toLowerCase();
    return normalized.includes(providerName) || normalized.includes(label.split(' ')[0] || providerName);
  });
}
