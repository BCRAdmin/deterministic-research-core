// File Service - Nur read-only Dateizugriff
// Keine Parser-Logik, keine UI-Logik, keine Secrets

import { promises as fs } from 'fs';
import { join } from 'path';

/**
 * Liest eine Textdatei
 * @param path - Absoluter Pfad zur Datei
 * @returns Datei-Inhalt oder null bei Fehler
 */
export async function readTextFile(path: string): Promise<string | null> {
  try {
    const content = await fs.readFile(path, 'utf-8');
    return content;
  } catch (error) {
    if ((error as NodeJS.ErrnoException)?.code !== 'ENOENT') {
      console.warn(`Datei nicht lesbar: ${path}`, error);
    }
    return null;
  }
}

/**
 * Prueft ob eine Datei existiert
 * @param path - Absoluter Pfad
 * @returns true wenn existiert, sonst false
 */
export async function fileExists(path: string): Promise<boolean> {
  try {
    await fs.access(path);
    return true;
  } catch {
    return false;
  }
}

/**
 * Listet alle Dateien in einem Verzeichnis
 * @param path - Absoluter Pfad zum Verzeichnis
 * @returns Array von Dateinamen oder leeres Array
 */
export async function listFiles(path: string): Promise<string[]> {
  try {
    const entries = await fs.readdir(path, { withFileTypes: true });
    return entries
      .filter(entry => entry.isFile())
      .map(entry => entry.name);
  } catch (error) {
    if ((error as NodeJS.ErrnoException)?.code !== 'ENOENT') {
      console.warn(`Verzeichnis nicht lesbar: ${path}`, error);
    }
    return [];
  }
}

/**
 * Findet die neueste Datei in einem Verzeichnis
 * Optional nach Pattern filtern
 * @param path - Absoluter Pfad zum Verzeichnis
 * @param pattern - Optional: Pattern im Dateinamen (z.B. 'morning_briefing')
 * @returns Dateiname oder null
 */
export async function getLatestFile(
  path: string,
  pattern?: string
): Promise<string | null> {
  try {
    const entries = await fs.readdir(path, { withFileTypes: true });
    const files = entries
      .filter(entry => entry.isFile())
      .filter(entry => !pattern || entry.name.includes(pattern));
    
    if (files.length === 0) {
      return null;
    }
    
    // Sortiere nach Modifikationsdatum (neueste zuerst)
    const filesWithStats = await Promise.all(
      files.map(async (file) => {
        const stat = await fs.stat(join(path, file.name));
        return { name: file.name, mtime: stat.mtime };
      })
    );
    
    filesWithStats.sort((a, b) => b.mtime.getTime() - a.mtime.getTime());
    return filesWithStats[0]?.name || null;
  } catch (error) {
    if ((error as NodeJS.ErrnoException)?.code !== 'ENOENT') {
      console.warn(`Fehler beim Suchen neueste Datei: ${path}`, error);
    }
    return null;
  }
}
