import 'server-only';

import { promises as fs } from 'fs';
import path from 'path';

import { WORKSPACE_ROOT } from '@/lib/constants/paths';
import {
  operatorGoProjectSources,
  type OperatorGoManifest,
  type OperatorGoItem,
  type OperatorGoProject,
  type OperatorGoProjectSource,
} from '@/lib/control-room/operator-go-inbox-data';

export type OperatorGoReviewState = 'pending' | 'approved' | 'needs_changes';

interface OperatorGoStoredItemState {
  reviewState: OperatorGoReviewState;
  note?: string;
  approvedAt?: string;
  scheduledFor?: string;
  publishedAt?: string;
  lastPipelineError?: string;
  lastPipelineRunAt?: string;
  updatedAt?: string;
}

interface OperatorGoStoredState {
  items: Record<string, OperatorGoStoredItemState>;
}

export interface OperatorGoHealthSnapshot {
  ok: boolean;
  checkedAt?: string;
  summary: string;
  nextDueItemId?: string;
  nextDueAt?: string;
  authOk?: boolean;
  authMessage?: string;
}

export interface OperatorGoResolvedItem extends OperatorGoItem {
  reviewState: OperatorGoReviewState;
  note?: string;
  approvedAt?: string;
  scheduledFor?: string;
  publishedAt?: string;
  lastPipelineError?: string;
  lastPipelineRunAt?: string;
  updatedAt?: string;
  resolvedPreviewUrl?: string;
  resolvedLiveUrl?: string;
  resolvedLocalPreviewUrl?: string;
}

export interface OperatorGoSnapshot {
  batchTime: string;
  projects: Array<OperatorGoProject & { pendingCount: number; approvedCount: number }>;
  pendingItems: OperatorGoResolvedItem[];
  approvedItems: OperatorGoResolvedItem[];
  publishedItems: OperatorGoResolvedItem[];
  health: OperatorGoHealthSnapshot | null;
}

const OPERATOR_GO_STATE_PATH = path.join(WORKSPACE_ROOT, '.recovery', 'operator-go-state.json');
const OPERATOR_GO_HEALTH_PATH = path.join(WORKSPACE_ROOT, '.recovery', 'operator-go-health.json');
const EMPTY_STATE: OperatorGoStoredState = { items: {} };
const OPERATOR_GO_TIME_ZONE = 'Europe/Berlin';
const OPERATOR_GO_BATCH_HOUR = 12;

export async function getOperatorGoSnapshot(): Promise<OperatorGoSnapshot> {
  const manifestPayload = await loadOperatorGoPayload();
  const stored = await readState();
  const resolved = manifestPayload.items.map((item) => ({
    ...item,
    reviewState: stored.items[item.id]?.reviewState ?? 'pending',
    note: stored.items[item.id]?.note,
    approvedAt: stored.items[item.id]?.approvedAt,
    scheduledFor: stored.items[item.id]?.scheduledFor,
    publishedAt: stored.items[item.id]?.publishedAt,
    lastPipelineError: stored.items[item.id]?.lastPipelineError,
    lastPipelineRunAt: stored.items[item.id]?.lastPipelineRunAt,
    updatedAt: stored.items[item.id]?.updatedAt,
    resolvedPreviewUrl: resolvePreviewUrl(item),
    resolvedLiveUrl: resolveLiveUrl(item),
    resolvedLocalPreviewUrl: resolveLocalPreviewUrl(item),
  }));

  const pendingItems = resolved.filter((item) => item.reviewState !== 'approved' && !item.publishedAt);
  const approvedItems = resolved
    .filter((item) => item.reviewState === 'approved' && !item.publishedAt)
    .sort((left, right) => {
      const leftSchedule = left.scheduledFor || '9999-12-31T12:00:00+02:00';
      const rightSchedule = right.scheduledFor || '9999-12-31T12:00:00+02:00';
      return leftSchedule.localeCompare(rightSchedule) || (left.approvedAt || '').localeCompare(right.approvedAt || '');
    });
  const publishedItems = resolved
    .filter((item) => Boolean(item.publishedAt))
    .sort((left, right) => (right.publishedAt || '').localeCompare(left.publishedAt || ''));

  const projects = manifestPayload.projects.map((project) => ({
    ...project,
    pendingCount: pendingItems.filter((item) => item.projectId === project.id).length,
    approvedCount: approvedItems.filter((item) => item.projectId === project.id).length,
  }));

  return {
    batchTime: manifestPayload.batchTime,
    projects,
    pendingItems,
    approvedItems,
    publishedItems,
    health: await readHealthState(),
  };
}

const PROJECT_LIVE_BASE_URLS: Record<string, string> = {
  materialbedarf: 'https://materialbedarf-rechner.de',
  elterngeld: 'https://mein-elterngeldrechner.de',
  lioncom: 'http://127.0.0.1:4107',
};

function resolvePreviewUrl(item: OperatorGoItem): string | undefined {
  return item.previewUrl || item.localPreviewUrl || item.livePreviewUrl || resolveLiveUrl(item);
}

function resolveLiveUrl(item: OperatorGoItem): string | undefined {
  if (item.livePreviewUrl) return item.livePreviewUrl;
  const baseUrl = PROJECT_LIVE_BASE_URLS[item.projectId];
  if (!baseUrl) return undefined;
  if (item.expectedLivePath) return `${baseUrl}${item.expectedLivePath}`;
  return baseUrl;
}

function resolveLocalPreviewUrl(item: OperatorGoItem): string | undefined {
  if (item.localPreviewUrl) return item.localPreviewUrl;
  if (item.projectId === 'lioncom') return 'http://127.0.0.1:4107/control-plane-v2?source=operator-go&legacyTab=approvals';
  return undefined;
}

export async function setOperatorGoApproval(itemId: string): Promise<OperatorGoSnapshot> {
  const state = await readState();
  const approvedAt = new Date();
  const now = approvedAt.toISOString();
  const existing = state.items[itemId];

  state.items[itemId] = {
    ...existing,
    reviewState: 'approved',
    approvedAt: now,
    scheduledFor: existing?.scheduledFor ?? getNextOperatorGoBatchSlot(approvedAt),
    publishedAt: undefined,
    lastPipelineError: undefined,
    updatedAt: now,
  };
  await writeState(state);
  return getOperatorGoSnapshot();
}

export async function requestOperatorGoChanges(itemId: string, note?: string): Promise<OperatorGoSnapshot> {
  const state = await readState();
  const now = new Date().toISOString();
  state.items[itemId] = {
    ...state.items[itemId],
    reviewState: 'needs_changes',
    note: note?.trim() || state.items[itemId]?.note,
    scheduledFor: undefined,
    updatedAt: now,
  };
  await writeState(state);
  return getOperatorGoSnapshot();
}

export async function saveOperatorGoNote(itemId: string, note: string): Promise<OperatorGoSnapshot> {
  const state = await readState();
  const now = new Date().toISOString();
  const existing = state.items[itemId];
  state.items[itemId] = {
    reviewState: existing?.reviewState ?? 'pending',
    note,
    approvedAt: existing?.approvedAt,
    scheduledFor: existing?.scheduledFor,
    publishedAt: existing?.publishedAt,
    lastPipelineError: existing?.lastPipelineError,
    lastPipelineRunAt: existing?.lastPipelineRunAt,
    updatedAt: now,
  };
  await writeState(state);
  return getOperatorGoSnapshot();
}

export async function resetOperatorGoItem(itemId: string): Promise<OperatorGoSnapshot> {
  const state = await readState();
  const now = new Date().toISOString();
  state.items[itemId] = {
    reviewState: 'pending',
    note: state.items[itemId]?.note,
    scheduledFor: undefined,
    publishedAt: undefined,
    lastPipelineError: state.items[itemId]?.lastPipelineError,
    lastPipelineRunAt: state.items[itemId]?.lastPipelineRunAt,
    updatedAt: now,
  };
  delete state.items[itemId].approvedAt;
  await writeState(state);
  return getOperatorGoSnapshot();
}

export async function scheduleOperatorGoItem(itemId: string, scheduledFor: string): Promise<OperatorGoSnapshot> {
  const state = await readState();
  const now = new Date().toISOString();
  const existing = state.items[itemId];

  state.items[itemId] = {
    reviewState: existing?.reviewState ?? 'approved',
    note: existing?.note,
    approvedAt: existing?.approvedAt ?? now,
    scheduledFor,
    publishedAt: existing?.publishedAt,
    lastPipelineError: existing?.lastPipelineError,
    lastPipelineRunAt: existing?.lastPipelineRunAt,
    updatedAt: now,
  };

  await writeState(state);
  return getOperatorGoSnapshot();
}

async function readState(): Promise<OperatorGoStoredState> {
  try {
    const raw = await fs.readFile(OPERATOR_GO_STATE_PATH, 'utf8');
    const parsed = JSON.parse(raw) as Partial<OperatorGoStoredState>;
    return { items: parsed.items ?? {} };
  } catch {
    await ensureStateFile();
    return { ...EMPTY_STATE };
  }
}

async function writeState(state: OperatorGoStoredState): Promise<void> {
  await ensureStateFile();
  await fs.writeFile(OPERATOR_GO_STATE_PATH, JSON.stringify(state, null, 2), 'utf8');
}

async function ensureStateFile(): Promise<void> {
  await fs.mkdir(path.dirname(OPERATOR_GO_STATE_PATH), { recursive: true });
  try {
    await fs.access(OPERATOR_GO_STATE_PATH);
  } catch {
    await fs.writeFile(OPERATOR_GO_STATE_PATH, JSON.stringify(EMPTY_STATE, null, 2), 'utf8');
  }
}

async function readHealthState(): Promise<OperatorGoHealthSnapshot | null> {
  try {
    const raw = await fs.readFile(OPERATOR_GO_HEALTH_PATH, 'utf8');
    return JSON.parse(raw) as OperatorGoHealthSnapshot;
  } catch {
    return null;
  }
}

async function loadOperatorGoPayload(): Promise<{
  batchTime: string;
  projects: OperatorGoProject[];
  items: OperatorGoItem[];
}> {
  const manifests = await Promise.all(operatorGoProjectSources.map(loadManifestForSource));
  const projects = manifests.map(({ project }) => project);
  const items = manifests.flatMap(({ items }) => items);
  const batchTime = manifests.find((entry) => entry.batchTime)?.batchTime ?? '12:00 Europe/Berlin';

  return { batchTime, projects, items };
}

async function loadManifestForSource(source: OperatorGoProjectSource): Promise<{
  batchTime?: string;
  project: OperatorGoProject;
  items: OperatorGoItem[];
}> {
  try {
    const raw = await fs.readFile(source.manifestPath, 'utf8');
    const parsed = JSON.parse(raw) as Partial<OperatorGoManifest>;
    const project = parsed.project?.id ? parsed.project : source;
    const items = Array.isArray(parsed.items)
      ? parsed.items
          .filter(isOperatorGoItem)
          .map((item) => ({
            ...item,
            projectId: item.projectId || project.id,
          }))
      : [];

    return {
      batchTime: parsed.batchTime,
      project,
      items,
    };
  } catch {
    return {
      project: source,
      items: [],
    };
  }
}

function isOperatorGoItem(value: unknown): value is OperatorGoItem {
  if (!value || typeof value !== 'object') return false;
  const candidate = value as Partial<OperatorGoItem>;

  return Boolean(
    candidate.id
    && candidate.title
    && candidate.kind
    && candidate.priority
    && candidate.operatorNeed
    && candidate.why
    && candidate.chosenVariant
    && candidate.rationale
    && Array.isArray(candidate.flags)
    && Array.isArray(candidate.benefits)
    && Array.isArray(candidate.risks)
    && Array.isArray(candidate.liveImpact)
    && Array.isArray(candidate.verification)
    && Array.isArray(candidate.previewSections)
    && Array.isArray(candidate.previewCtas)
    && Array.isArray(candidate.supportingPaths),
  );
}

function getNextOperatorGoBatchSlot(now: Date): string {
  const currentBerlin = getZonedParts(now, OPERATOR_GO_TIME_ZONE);
  const targetDay = currentBerlin.hour >= OPERATOR_GO_BATCH_HOUR
    ? currentBerlin.day + 1
    : currentBerlin.day;

  return zonedWallTimeToUtcIso({
    year: currentBerlin.year,
    month: currentBerlin.month,
    day: targetDay,
    hour: OPERATOR_GO_BATCH_HOUR,
    minute: 0,
    second: 0,
    timeZone: OPERATOR_GO_TIME_ZONE,
  });
}

function getZonedParts(date: Date, timeZone: string) {
  const formatter = new Intl.DateTimeFormat('en-US', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23',
  });
  const values: Record<string, string> = {};

  for (const part of formatter.formatToParts(date)) {
    if (part.type !== 'literal') values[part.type] = part.value;
  }

  return {
    year: Number(values.year),
    month: Number(values.month),
    day: Number(values.day),
    hour: Number(values.hour),
    minute: Number(values.minute),
    second: Number(values.second),
  };
}

function zonedWallTimeToUtcIso(input: {
  year: number;
  month: number;
  day: number;
  hour: number;
  minute: number;
  second: number;
  timeZone: string;
}) {
  const wallTimeAsUtc = Date.UTC(input.year, input.month - 1, input.day, input.hour, input.minute, input.second);
  const firstGuess = new Date(wallTimeAsUtc);
  const firstOffset = getTimeZoneOffsetMs(firstGuess, input.timeZone);
  const secondGuess = new Date(wallTimeAsUtc - firstOffset);
  const secondOffset = getTimeZoneOffsetMs(secondGuess, input.timeZone);

  return new Date(wallTimeAsUtc - secondOffset).toISOString();
}

function getTimeZoneOffsetMs(date: Date, timeZone: string): number {
  const parts = getZonedParts(date, timeZone);
  const zonedTimestamp = Date.UTC(
    parts.year,
    parts.month - 1,
    parts.day,
    parts.hour,
    parts.minute,
    parts.second,
  );

  return zonedTimestamp - date.getTime();
}
