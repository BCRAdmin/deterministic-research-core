import 'server-only';

import { promises as fs } from 'fs';
import path from 'path';

import { PATHS } from '@/lib/constants/paths';
import { dispatchControlPlaneTask, type ControlPlaneDispatchResult } from '@/lib/services/controlPlaneDispatchService';
import {
  ROADMAP_CARD_STATUSES,
  type RoadmapCard,
  type RoadmapCardCounts,
  type RoadmapCardCreateInput,
  type RoadmapCardPriority,
  type RoadmapCardRuntime,
  type RoadmapCardSnapshot,
  type RoadmapCardStatus,
  type RoadmapCardTargetMode,
  type RoadmapCardTaskType,
  type RoadmapCardUpdateInput,
} from '@/lib/types/roadmap-cards';

interface RoadmapCardFile {
  version: 1;
  updatedAt: string;
  cards: RoadmapCard[];
}

export interface RoadmapCardMutationResult {
  card: RoadmapCard;
  snapshot: RoadmapCardSnapshot;
}

export interface RoadmapCardEnqueueResult extends RoadmapCardMutationResult {
  dispatch: ControlPlaneDispatchResult;
}

export class RoadmapCardNotFoundError extends Error {
  constructor(cardId: string) {
    super(`Roadmap-Karte nicht gefunden: ${cardId}`);
    this.name = 'RoadmapCardNotFoundError';
  }
}

export class RoadmapCardValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'RoadmapCardValidationError';
  }
}

const priorities: RoadmapCardPriority[] = ['low', 'normal', 'high', 'critical'];
const taskTypes: RoadmapCardTaskType[] = ['Mission', 'Research', 'Code', 'Repair', 'Verification', 'Follow-up'];
const targetModes: RoadmapCardTargetMode[] = ['Vivi zuerst', 'Direkt an Vega', 'Vivi → Vega Handoff', 'Nur Review'];
const runtimes: RoadmapCardRuntime[] = ['Local', 'Cloud', 'Auto'];

const SEED_CARD: RoadmapCard = {
  id: 'roadmap-20260528-clawhub-audit-gate',
  title: 'ClawHub Audit Gate & Vivi Media Adapter',
  summary: 'ClawHub/OpenClaw-Audit als lokale, source-gated Fähigkeit für LIONCOM und Vivi prüfen, ohne externe Skill-Runtime ungeprüft zu übernehmen.',
  sourcePath: '/Users/BjornRosinger/Documents/Codex/2026-05-28/ich-m-chte-vivi-testen-sie/openclaw_full_audit_2026-05-28/OPENCLAW_CLAWHUB_FULL_AUDIT_2026-05-28.md',
  status: 'parked',
  priority: 'high',
  gate: 'Operator-Go vor Runtime-/Skill-Import',
  risk: 'Externe Skill-, Runtime- oder Media-Adapter-Übernahme darf Obsidian-, Source- und Operator-Gates nicht umgehen.',
  targetMode: 'Direkt an Vega',
  taskType: 'Code',
  runtime: 'Local',
  reviewAt: '2026-06-02T07:00:00.000Z',
  nextStep: 'Interne ClawHub-Audit-Gates und Vivi-Media/Transcript-Adapter als lokale, source-gated Fähigkeit planen und implementieren.',
  createdAt: '2026-05-28T00:00:00.000Z',
  updatedAt: '2026-05-28T00:00:00.000Z',
};

export function isRoadmapCardNotFoundError(error: unknown): error is RoadmapCardNotFoundError {
  return error instanceof RoadmapCardNotFoundError;
}

export function isRoadmapCardValidationError(error: unknown): error is RoadmapCardValidationError {
  return error instanceof RoadmapCardValidationError;
}

export async function getRoadmapCardsSnapshot(): Promise<RoadmapCardSnapshot> {
  const cards = await loadCards();
  return buildSnapshot(cards);
}

export async function createRoadmapCard(input: RoadmapCardCreateInput): Promise<RoadmapCardMutationResult> {
  const cards = await loadCards();
  const now = new Date().toISOString();
  const title = clean(input.title, 160);

  if (!title) {
    throw new RoadmapCardValidationError('Titel fehlt.');
  }

  const id = clean(input.id, 120) || `roadmap-${timestampId(now)}-${slugify(title)}`;
  if (cards.some((card) => card.id === id)) {
    throw new RoadmapCardValidationError(`Roadmap-Karte existiert bereits: ${id}`);
  }

  const card: RoadmapCard = {
    id,
    title,
    summary: clean(input.summary, 1200) || title,
    sourcePath: clean(input.sourcePath, 1200) || 'not_set',
    status: coerceStatus(input.status, 'parked'),
    priority: coercePriority(input.priority, 'normal'),
    gate: clean(input.gate, 500) || 'Operator-Review vor Umsetzung',
    risk: clean(input.risk, 700) || 'Risiko noch nicht bewertet.',
    targetMode: coerceTargetMode(input.targetMode, 'Vivi → Vega Handoff'),
    taskType: coerceTaskType(input.taskType, 'Mission'),
    runtime: coerceRuntime(input.runtime, 'Local'),
    reviewAt: coerceIso(input.reviewAt, now),
    nextStep: clean(input.nextStep, 1200) || 'Nächsten sicheren Schritt konkretisieren.',
    createdAt: now,
    updatedAt: now,
    note: clean(input.note, 2000) || undefined,
  };

  const nextCards = sortCards([card, ...cards]);
  await writeCards(nextCards, now);
  return { card, snapshot: buildSnapshot(nextCards) };
}

export async function updateRoadmapCard(cardId: string, input: RoadmapCardUpdateInput): Promise<RoadmapCardMutationResult> {
  const cards = await loadCards();
  const index = cards.findIndex((card) => card.id === cardId);
  if (index < 0) throw new RoadmapCardNotFoundError(cardId);

  const now = new Date().toISOString();
  const current = cards[index];
  const updated: RoadmapCard = {
    ...current,
    status: input.status ? coerceStatus(input.status, current.status) : current.status,
    reviewAt: input.reviewAt !== undefined ? coerceIso(input.reviewAt, current.reviewAt) : current.reviewAt,
    note: input.note !== undefined ? clean(input.note, 2000) || undefined : current.note,
    updatedAt: now,
  };

  const nextCards = sortCards(cards.map((card) => (card.id === cardId ? updated : card)));
  await writeCards(nextCards, now);
  return { card: updated, snapshot: buildSnapshot(nextCards) };
}

export async function enqueueRoadmapCard(cardId: string): Promise<RoadmapCardEnqueueResult> {
  const cards = await loadCards();
  const card = cards.find((candidate) => candidate.id === cardId);
  if (!card) throw new RoadmapCardNotFoundError(cardId);

  if (card.status === 'done') {
    throw new RoadmapCardValidationError('Erledigte Roadmap-Karten werden nicht erneut eingereiht.');
  }

  const dispatch = await dispatchControlPlaneTask(
    {
      title: card.title,
      description: renderDispatchDescription(card),
      taskType: card.taskType,
      targetMode: card.targetMode,
      priority: card.priority,
      runtime: card.runtime,
      attachments: card.sourcePath,
    },
    { sourceLabel: 'LIONCOM Roadmap Card Registry' },
  );

  const now = new Date().toISOString();
  const updated: RoadmapCard = {
    ...card,
    status: 'queued',
    dispatchRef: dispatch.reference,
    updatedAt: now,
  };
  const nextCards = sortCards(cards.map((candidate) => (candidate.id === cardId ? updated : candidate)));
  await writeCards(nextCards, now);

  return {
    card: updated,
    snapshot: buildSnapshot(nextCards),
    dispatch,
  };
}

async function loadCards(): Promise<RoadmapCard[]> {
  const cards = await readCardsFile();
  const now = new Date().toISOString();
  const dueMaterialized = cards.map((card) => materializeDueStatus(card, now));
  const changed = JSON.stringify(cards) !== JSON.stringify(dueMaterialized);

  if (changed) {
    await writeCards(dueMaterialized, now);
  }

  return sortCards(dueMaterialized);
}

async function readCardsFile(): Promise<RoadmapCard[]> {
  try {
    const raw = await fs.readFile(PATHS.ROADMAP_CARDS, 'utf8');
    if (!raw.trim()) return seedCards();

    const parsed = JSON.parse(raw) as Partial<RoadmapCardFile> | RoadmapCard[];
    const candidates = Array.isArray(parsed) ? parsed : Array.isArray(parsed.cards) ? parsed.cards : [];
    const cards = candidates.filter(isRoadmapCard);

    if (cards.length === 0) return seedCards();
    return cards;
  } catch (error) {
    if (error && typeof error === 'object' && 'code' in error && error.code === 'ENOENT') {
      return seedCards();
    }
    throw error;
  }
}

async function seedCards(): Promise<RoadmapCard[]> {
  const cards = [SEED_CARD];
  await writeCards(cards, new Date().toISOString());
  return cards;
}

async function writeCards(cards: RoadmapCard[], updatedAt: string): Promise<void> {
  const file: RoadmapCardFile = {
    version: 1,
    updatedAt,
    cards: sortCards(cards),
  };

  await fs.mkdir(path.dirname(PATHS.ROADMAP_CARDS), { recursive: true });
  await fs.writeFile(PATHS.ROADMAP_CARDS, `${JSON.stringify(file, null, 2)}\n`, 'utf8');
}

function buildSnapshot(cards: RoadmapCard[]): RoadmapCardSnapshot {
  const generatedAt = new Date().toISOString();
  const sorted = sortCards(cards);
  const dueCards = sorted.filter((card) => isDueCard(card, generatedAt));
  return {
    cards: sorted,
    dueCards,
    counts: countCards(sorted, dueCards.length),
    generatedAt,
    storagePath: PATHS.ROADMAP_CARDS,
  };
}

function countCards(cards: RoadmapCard[], due: number): RoadmapCardCounts {
  const counts: RoadmapCardCounts = {
    total: cards.length,
    due,
    parked: 0,
    review_due: 0,
    queued: 0,
    done: 0,
    blocked: 0,
  };

  for (const card of cards) {
    counts[card.status] += 1;
  }

  return counts;
}

function materializeDueStatus(card: RoadmapCard, now: string): RoadmapCard {
  if (card.status !== 'parked') return card;
  if (!isDueReviewAt(card.reviewAt, now)) return card;
  return { ...card, status: 'review_due', updatedAt: now };
}

function isDueCard(card: RoadmapCard, now: string): boolean {
  if (card.status === 'done' || card.status === 'queued' || card.status === 'blocked') return false;
  return card.status === 'review_due' || isDueReviewAt(card.reviewAt, now);
}

function isDueReviewAt(value: string, now: string): boolean {
  const reviewMs = Date.parse(value);
  if (Number.isNaN(reviewMs)) return false;
  return reviewMs <= Date.parse(now);
}

function isRoadmapCard(value: unknown): value is RoadmapCard {
  if (!value || typeof value !== 'object') return false;
  const card = value as Partial<RoadmapCard>;

  return Boolean(
    typeof card.id === 'string'
    && typeof card.title === 'string'
    && typeof card.summary === 'string'
    && typeof card.sourcePath === 'string'
    && isStatus(card.status)
    && priorities.includes(card.priority as RoadmapCardPriority)
    && typeof card.gate === 'string'
    && typeof card.risk === 'string'
    && targetModes.includes(card.targetMode as RoadmapCardTargetMode)
    && taskTypes.includes(card.taskType as RoadmapCardTaskType)
    && runtimes.includes(card.runtime as RoadmapCardRuntime)
    && typeof card.reviewAt === 'string'
    && typeof card.nextStep === 'string'
    && typeof card.createdAt === 'string'
    && typeof card.updatedAt === 'string'
  );
}

function renderDispatchDescription(card: RoadmapCard): string {
  return [
    card.summary,
    '',
    `Quelle: ${card.sourcePath}`,
    `Gate: ${card.gate}`,
    `Risiko: ${card.risk}`,
    `Nächster Schritt: ${card.nextStep}`,
    card.note ? `Notiz: ${card.note}` : null,
  ].filter(Boolean).join('\n');
}

function sortCards(cards: RoadmapCard[]): RoadmapCard[] {
  const priorityRank: Record<RoadmapCardPriority, number> = {
    critical: 0,
    high: 1,
    normal: 2,
    low: 3,
  };
  const statusRank: Record<RoadmapCardStatus, number> = {
    review_due: 0,
    parked: 1,
    blocked: 2,
    queued: 3,
    done: 4,
  };

  return [...cards].sort((left, right) => {
    const dueDiff = Number(isDueCard(right, new Date().toISOString())) - Number(isDueCard(left, new Date().toISOString()));
    if (dueDiff !== 0) return dueDiff;
    const statusDiff = statusRank[left.status] - statusRank[right.status];
    if (statusDiff !== 0) return statusDiff;
    const priorityDiff = priorityRank[left.priority] - priorityRank[right.priority];
    if (priorityDiff !== 0) return priorityDiff;
    return left.reviewAt.localeCompare(right.reviewAt) || left.title.localeCompare(right.title);
  });
}

function coerceStatus(value: string | undefined, fallback: RoadmapCardStatus): RoadmapCardStatus {
  if (!value) return fallback;
  if (!isStatus(value)) throw new RoadmapCardValidationError(`Ungültiger Status: ${value}`);
  return value;
}

function isStatus(value: unknown): value is RoadmapCardStatus {
  return ROADMAP_CARD_STATUSES.includes(value as RoadmapCardStatus);
}

function coercePriority(value: string | undefined, fallback: RoadmapCardPriority): RoadmapCardPriority {
  return priorities.find((priority) => priority === value) ?? fallback;
}

function coerceTaskType(value: string | undefined, fallback: RoadmapCardTaskType): RoadmapCardTaskType {
  return taskTypes.find((taskType) => taskType === value) ?? fallback;
}

function coerceTargetMode(value: string | undefined, fallback: RoadmapCardTargetMode): RoadmapCardTargetMode {
  return targetModes.find((targetMode) => targetMode === value) ?? fallback;
}

function coerceRuntime(value: string | undefined, fallback: RoadmapCardRuntime): RoadmapCardRuntime {
  return runtimes.find((runtime) => runtime === value) ?? fallback;
}

function coerceIso(value: string | undefined, fallback: string): string {
  const cleaned = clean(value, 80);
  if (!cleaned) return fallback;
  const timestamp = Date.parse(cleaned);
  if (Number.isNaN(timestamp)) throw new RoadmapCardValidationError(`Ungültige Wiedervorlage: ${cleaned}`);
  return new Date(timestamp).toISOString();
}

function clean(value: string | undefined, maxLength: number): string {
  return typeof value === 'string' ? value.trim().slice(0, maxLength) : '';
}

function timestampId(isoDate: string): string {
  return isoDate.replace(/[-:TZ]/g, '').replace('.', '').slice(0, 17);
}

function slugify(value: string): string {
  const slug = value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48);
  return slug || 'card';
}
