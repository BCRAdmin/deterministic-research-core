import path from 'path';
import { existsSync } from 'fs';

const envRoot = process.env.VIVI_WORKSPACE_ROOT?.trim();

function looksLikeWorkspaceRoot(candidate: string): boolean {
  return [
    'VIVI_CONTROL_LOOP.md',
    'WORK_INTAKE.md',
    'mission-control-board',
  ].every((entry) => existsSync(path.join(candidate, entry)));
}

function searchWorkspaceRoot(start: string): string | null {
  let current = path.resolve(start);

  for (let depth = 0; depth < 8; depth += 1) {
    if (looksLikeWorkspaceRoot(current)) {
      return current;
    }

    const parent = path.dirname(current);
    if (parent === current) break;
    current = parent;
  }

  return null;
}

export const WORKSPACE_ROOT = envRoot
  ? path.resolve(envRoot)
  : searchWorkspaceRoot(process.cwd())
    || searchWorkspaceRoot(__dirname)
    || path.resolve(process.cwd(), '..');

export const PATHS = {
  ROOM16_REPORTS_DIR: path.join(process.env.HOME || WORKSPACE_ROOT, 'Documents', 'Room 16 Reports'),
  DASHBOARD: path.join(WORKSPACE_ROOT, 'DASHBOARD.md'),
  TASK_QUEUE: path.join(WORKSPACE_ROOT, 'TASK_QUEUE.md'),
  BACKLOG: path.join(WORKSPACE_ROOT, 'BACKLOG.md'),
  LEARNINGS: path.join(WORKSPACE_ROOT, 'LEARNINGS.md'),
  ERROR_CLASSES: path.join(WORKSPACE_ROOT, 'ERROR_CLASSES.md'),
  OPERATOR_PROFILE: path.join(WORKSPACE_ROOT, 'OPERATOR_PROFILE.md'),
  VIVI_RESEARCH_PLAYBOOK: path.join(WORKSPACE_ROOT, 'VIVI_RESEARCH_PLAYBOOK.md'),
  SYSTEM_EXPORT: path.join(WORKSPACE_ROOT, 'SYSTEM_EXPORT.md'),
  HANDOFF_NEXT_CHAT: path.join(WORKSPACE_ROOT, 'HANDOFF_NEXT_CHAT.md'),
  BUILD_PROTOCOL: path.join(WORKSPACE_ROOT, 'BUILD_PROTOCOL.md'),
  HEARTBEAT: path.join(WORKSPACE_ROOT, 'HEARTBEAT.md'),
  BRAIN_DUMP: path.join(WORKSPACE_ROOT, 'BRAIN_DUMP.md'),
  WORK_INTAKE: path.join(WORKSPACE_ROOT, 'WORK_INTAKE.md'),
  CODEX_INBOX: path.join(WORKSPACE_ROOT, 'CODEX_INBOX.md'),
  CODEX_CHAT_SESSIONS: path.join(WORKSPACE_ROOT, 'CODEX_CHAT_SESSIONS.json'),
  CODEX_CHAT_THREAD: path.join(WORKSPACE_ROOT, 'CODEX_CHAT_THREAD.md'),
  CODEX_RUNTIME: path.join(WORKSPACE_ROOT, 'CODEX_RUNTIME.json'),
  CODEX_REPORTS: path.join(WORKSPACE_ROOT, 'CODEX_REPORTS.md'),
  VIVI_COMMAND_QUEUE: path.join(WORKSPACE_ROOT, 'VIVI_COMMAND_QUEUE.md'),
  VIVI_CHAT_SESSIONS: path.join(WORKSPACE_ROOT, 'VIVI_CHAT_SESSIONS.json'),
  VIVI_CHAT_THREAD: path.join(WORKSPACE_ROOT, 'VIVI_CHAT_THREAD.md'),
  VIVI_SKILL_RUNS: path.join(WORKSPACE_ROOT, 'VIVI_SKILL_RUNS.md'),
  VIVI_RUNTIME: path.join(WORKSPACE_ROOT, 'VIVI_RUNTIME.json'),
  VIVI_STATE: path.join(WORKSPACE_ROOT, 'VIVI_STATE.json'),
  VIVI_REPORTS: path.join(WORKSPACE_ROOT, 'VIVI_REPORTS.md'),
  TELEGRAM_INBOX: path.join(WORKSPACE_ROOT, 'TELEGRAM_INBOX.md'),
  TELEGRAM_OUTBOX: path.join(WORKSPACE_ROOT, 'TELEGRAM_OUTBOX.md'),
  TELEGRAM_MOBILE_POLICY: path.join(WORKSPACE_ROOT, 'TELEGRAM_MOBILE_POLICY.md'),
  TELEGRAM_CURSOR: path.join(WORKSPACE_ROOT, '.openclaw', 'telegram-cursor.json'),
  ATTACHMENTS_DIR: path.join(WORKSPACE_ROOT, 'ATTACHMENTS'),
  SECRETS_DIR: [REDACTED]
  REPAIR_QUEUE: path.join(WORKSPACE_ROOT, 'REPAIR_QUEUE.md'),
  WORK_BLOCKS: path.join(WORKSPACE_ROOT, 'WORK_BLOCKS.md'),
  SUBTASK_QUEUE: path.join(WORKSPACE_ROOT, 'SUBTASK_QUEUE.md'),
  RESEARCH_QUEUE: path.join(WORKSPACE_ROOT, 'RESEARCH_QUEUE.md'),
  DECISION_QUEUE: path.join(WORKSPACE_ROOT, 'DECISION_QUEUE.md'),
  FREEZE_LOG: path.join(WORKSPACE_ROOT, 'FREEZE_LOG.md'),
  FREEZE_POLICY: path.join(WORKSPACE_ROOT, 'FREEZE_POLICY.md'),
  TASK_CLAIMS: path.join(WORKSPACE_ROOT, 'TASK_CLAIMS.md'),
  AUTONOMY_STATE: path.join(WORKSPACE_ROOT, 'AUTONOMY_STATE.json'),
  WORK_ENGINE_STATE: path.join(WORKSPACE_ROOT, 'WORK_ENGINE_STATE.json'),
  LOCAL_DUO_LOOP_STATUS: path.join(WORKSPACE_ROOT, '.runtime', 'local-duo-loop-status.json'),
  VIVI_MODEL_ROUTE_STATUS: path.join(WORKSPACE_ROOT, '.runtime', 'vivi-model-route-status.json'),
  VIVI_REPORT_QUALITY_GATE_STATUS: path.join(WORKSPACE_ROOT, '.runtime', 'vivi-report-quality-gate-status.json'),
  VIVI_MODEL_OVERRIDE: path.join(WORKSPACE_ROOT, '.runtime', 'vivi-model-override.json'),
  VIVI_SKILLS_DIR: path.join(WORKSPACE_ROOT, '.runtime', 'vivi-skills'),
  VIVI_SKILLS_ARTIFACTS_DIR: path.join(WORKSPACE_ROOT, '.runtime', 'vivi-skills', 'artifacts'),
  VIVI_SKILLS_IMAGE_ARTIFACTS_DIR: path.join(WORKSPACE_ROOT, '.runtime', 'vivi-skills', 'artifacts', 'images'),
  VIVI_SKILLS_PROPOSALS_DIR: path.join(WORKSPACE_ROOT, '.runtime', 'vivi-skills', 'proposals'),
  VIVI_SKILLS_PROPOSALS_JSONL: path.join(WORKSPACE_ROOT, '.runtime', 'vivi-skills', 'proposals.jsonl'),
  VIVI_SKILLS_REMOTE_CATALOG: path.join(WORKSPACE_ROOT, '.runtime', 'vivi-skills', 'remote-catalog.json'),
  VIVI_SKILLS_STATE: path.join(WORKSPACE_ROOT, '.runtime', 'vivi-skills', 'enabled-skills.json'),
  VIVI_SKILLS_RUNS_JSONL: path.join(WORKSPACE_ROOT, '.runtime', 'vivi-skills', 'runs.jsonl'),
  VIVI_SKILLS_LATEST_RUN: path.join(WORKSPACE_ROOT, '.runtime', 'vivi-skills', 'latest-run.json'),
  ROADMAP_CARDS: path.join(WORKSPACE_ROOT, '.runtime', 'roadmap-cards', 'cards.json'),
  EXECUTION_PLAN: path.join(WORKSPACE_ROOT, 'EXECUTION_PLAN.md'),
  MISSION_PRIORITY_BOARD: path.join(WORKSPACE_ROOT, 'MISSION_PRIORITY_BOARD.md'),
  GITHUB_SYNC_STATUS: path.join(WORKSPACE_ROOT, 'GITHUB_SYNC_STATUS.md'),
  GITHUB_SYNC_DIAGNOSTIC: path.join(WORKSPACE_ROOT, 'GITHUB_SYNC_DIAGNOSTIC.json'),
  REMOTE_BRIDGE_CONFIG: path.join(WORKSPACE_ROOT, 'REMOTE_BRIDGE_CONFIG.json'),
  REMOTE_BRIDGE_STATUS: path.join(WORKSPACE_ROOT, 'REMOTE_BRIDGE_STATUS.json'),
  VPS_LIVE_BRIDGE: path.join(WORKSPACE_ROOT, 'VPS_LIVE_BRIDGE.md'),
  SYSTEM_QUALIFICATION_STATUS: path.join(WORKSPACE_ROOT, 'SYSTEM_QUALIFICATION_STATUS.json'),
  PRODUCTION_READINESS_REVIEW: path.join(WORKSPACE_ROOT, 'PRODUCTION_READINESS_REVIEW.md'),
  QUALIFICATION_RUNS: path.join(WORKSPACE_ROOT, 'QUALIFICATION_RUNS'),
  QUALIFICATION_E2E: path.join(WORKSPACE_ROOT, 'QUALIFICATION_RUNS', 'END_TO_END_VALIDATION.md'),
  QUALIFICATION_FAILURE_RECOVERY: path.join(WORKSPACE_ROOT, 'QUALIFICATION_RUNS', 'FAILURE_RECOVERY_VALIDATION.md'),
  QUALIFICATION_SUITE: path.join(WORKSPACE_ROOT, 'QUALIFICATION_RUNS', 'QUALIFICATION_SUITE_LAST_RUN.md'),

  DAILY: path.join(WORKSPACE_ROOT, 'DAILY'),
  NIGHTLY: path.join(WORKSPACE_ROOT, 'NIGHTLY'),
  SOPS: path.join(WORKSPACE_ROOT, 'SOPs'),
  DOCS_DIR: path.join(WORKSPACE_ROOT, 'docs'),
  STANDARDS_DIR: path.join(WORKSPACE_ROOT, 'docs', 'standards'),
  REVIEW_DIR: path.join(WORKSPACE_ROOT, 'docs', 'review'),
  PROMPTS_DIR: path.join(WORKSPACE_ROOT, 'prompts'),
  TEMPLATES: path.join(WORKSPACE_ROOT, 'templates'),
  SCRIPTS: path.join(WORKSPACE_ROOT, 'scripts'),
  PROJECTS: path.join(WORKSPACE_ROOT, 'PROJECTS'),
  DEPLOY_DIR: path.join(WORKSPACE_ROOT, 'deploy'),
  REMOTE_BRIDGE_BUNDLE_DIR: path.join(WORKSPACE_ROOT, 'deploy', 'remote-bridge'),
  MORNING_BRIEFING_STANDARD: path.join(WORKSPACE_ROOT, 'docs', 'standards', 'MORNING_BRIEFING_STANDARD.md'),
  TASK_OPERATING_STANDARD: path.join(WORKSPACE_ROOT, 'docs', 'standards', 'TASK_OPERATING_STANDARD.md'),
  MODEL_ROUTING_STANDARD: path.join(WORKSPACE_ROOT, 'docs', 'standards', 'MODEL_ROUTING_STANDARD.md'),
  AUTONOMY_OPERATING_STANDARD: path.join(WORKSPACE_ROOT, 'docs', 'standards', 'AUTONOMY_OPERATING_STANDARD.md'),
  VIVI_DROP_REVIEW: path.join(WORKSPACE_ROOT, 'docs', 'review', 'VIVI_DROP_REVIEW.md'),
  VIVI_AUTONOMY_BOOT_PROMPT: path.join(WORKSPACE_ROOT, 'prompts', 'VIVI_AUTONOMY_BOOT_PROMPT.md'),
  AUTONOMY_START_GUIDE: path.join(WORKSPACE_ROOT, 'AUTONOMY_START_GUIDE.md'),
  DASHBOARD_DIR: path.join(WORKSPACE_ROOT, 'dashboard'),
  DASHBOARD_STATE: path.join(WORKSPACE_ROOT, 'dashboard', 'data', 'system_state.json'),
  GOLDEN_BASELINE_STATUS: path.join(WORKSPACE_ROOT, 'dashboard', 'data', 'golden_baseline_status.json'),
  GOLDEN_BASELINE_AUTOMATION_STATUS: path.join(WORKSPACE_ROOT, 'dashboard', 'data', 'golden_baseline_automation_status.json'),
  DASHBOARD_ACTIVITY_LOG: path.join(WORKSPACE_ROOT, 'dashboard', 'logs', 'activity.log'),
  WORKSPACE_STATE: path.join(WORKSPACE_ROOT, '.openclaw', 'workspace-state.json'),
} as const;

export const CRON_LOGS = {
  MORNING_BRIEFING: path.join(WORKSPACE_ROOT, 'DAILY', 'cron_morning.log'),
  NIGHTLY_RESEARCH: path.join(WORKSPACE_ROOT, 'NIGHTLY', 'cron_research.log'),
} as const;
