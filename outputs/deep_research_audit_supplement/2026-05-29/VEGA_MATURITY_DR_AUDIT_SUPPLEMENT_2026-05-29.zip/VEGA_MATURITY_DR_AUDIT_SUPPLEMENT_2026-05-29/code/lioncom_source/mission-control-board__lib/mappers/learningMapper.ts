// Learning Mapper - Vereinheitlicht Learnings zu UI-Format
// Keine neue Logik, nur Normalisierung

import { parseLearnings } from '../parsers/learningsParser';
import type { ParsedLearning } from '../parsers/learningsParser';

export type LearningSeverity = 'error' | 'warning' | 'info';

export interface MappedLearning {
  id: string;
  title: string;
  severity: LearningSeverity;
}

export interface MappedLearnings {
  items: MappedLearning[];
  lastUpdated?: string;
  errorCount: number;
  warningCount: number;
}

/**
 * Mappt geparste Learnings zu UI-Format
 */
export async function mapLearnings(): Promise<MappedLearnings> {
  const parsed = await parseLearnings().catch(() => ({ items: [], lastUpdated: undefined }));
  
  const items = parsed.items.map(mapLearning);
  
  return {
    items: items.slice(0, 5), // Max 5 für v1
    lastUpdated: parsed.lastUpdated,
    errorCount: items.filter(i => i.severity === 'error').length,
    warningCount: items.filter(i => i.severity === 'warning').length
  };
}

/**
 * Mappt einzelnes Learning
 */
function mapLearning(parsed: ParsedLearning): MappedLearning {
  return {
    id: parsed.id,
    title: parsed.title,
    severity: mapSeverity(parsed.type)
  };
}

/**
 * Mappt Learning-Type zu Severity
 */
function mapSeverity(type: ParsedLearning['type']): LearningSeverity {
  switch (type) {
    case 'error': return 'error';
    case 'fix': return 'info';
    case 'principle':
    default: return 'warning';
  }
}
