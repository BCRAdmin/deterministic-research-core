// Dashboard Parser - Liest DASHBOARD.md
// Nur Kerninformationen: Phase + Komponenten-Status

import { readTextFile } from '../services/fileService';
import { PATHS } from '../constants/paths';
import type { SystemStatus, ComponentStatus } from '../types/status';

export interface ParsedDashboard {
  systemStatus: SystemStatus;
}

/**
 * Parst DASHBOARD.md - nur Phase und Komponenten
 */
export async function parseDashboard(): Promise<ParsedDashboard> {
  const content = await readTextFile(PATHS.DASHBOARD);
  if (!content) {
    return {
      systemStatus: {
        phase: 'INITIALISIERUNG',
        components: [],
        lastUpdated: new Date().toISOString()
      }
    };
  }

  return {
    systemStatus: {
      phase: extractPhase(content),
      components: extractComponents(content),
      lastUpdated: new Date().toISOString()
    }
  };
}

/**
 * Extrahiert aktuelle Phase - robust mit Fallback
 */
function extractPhase(content: string): SystemStatus['phase'] {
  // Suche nach **Phase** | ✅ PHASE
  const match = content.match(/\*\*Phase\*\*[\s|]*✅?\s*(\w+)/i);
  const phase = match?.[1]?.toUpperCase() || 'INITIALISIERUNG';
  
  const validPhases: SystemStatus['phase'][] = [
    'INITIALISIERUNG', 'PLANUNG', 'AUSFÜHRUNG', 'VALIDIERUNG', 'ABSCHLUSS'
  ];
  
  return validPhases.includes(phase as SystemStatus['phase']) 
    ? phase as SystemStatus['phase'] 
    : 'INITIALISIERUNG';
}

/**
 * Extrahiert Komponenten-Status - defensive Implementierung
 */
function extractComponents(content: string): ComponentStatus[] {
  const components: ComponentStatus[] = [];
  const lines = content.split('\n');
  
  for (const line of lines) {
    // Suche nach | Name | Status | Zeilen
    if (!line.includes('|')) continue;
    
    const parts = line.split('|')
      .map(p => p.trim().replace(/\*\*/g, ''))
      .filter(p => p.length > 0);
    
    if (parts.length < 2) continue;
    
    const [name, statusText] = parts;
    
    // Überspringe Header-Zeilen
    if (name.toLowerCase().includes('komponente')) continue;
    if (name.toLowerCase().includes('phase')) continue;
    
    // Status ableiten
    let status: ComponentStatus['status'] = 'NICHT_VERFÜGBAR';
    const lowerStatus = statusText.toLowerCase();
    
    if (lowerStatus.includes('produktiv') || lowerStatus.includes('🟢')) {
      status = 'PRODUKTIV';
    } else if (lowerStatus.includes('dokumentiert') || lowerStatus.includes('🟡')) {
      status = 'DOKUMENTIERT';
    }
    
    components.push({ name, status });
  }
  
  return components;
}
