// Learnings Parser - Liest LEARNINGS.md
// Nur Kerninformationen: aktuelle Learnings, Probleme, Fixes

import { readTextFile } from '../services/fileService';
import { PATHS } from '../constants/paths';

export interface ParsedLearning {
  id: string;
  title: string;
  type: 'error' | 'fix' | 'principle';
}

export interface ParsedLearnings {
  items: ParsedLearning[];
  lastUpdated?: string;
}

/**
 * Parst LEARNINGS.md - nur aktuelle Eintraege
 */
export async function parseLearnings(): Promise<ParsedLearnings> {
  const content = await readTextFile(PATHS.LEARNINGS);
  if (!content) {
    return { items: [], lastUpdated: undefined };
  }

  const items = extractLearnings(content);
  const lastUpdated = extractLastUpdate(content);

  return {
    items: items.slice(0, 5), // Max 5 fuer v1
    lastUpdated
  };
}

/**
 * Extrahiert Learning-Eintraege aus ### Abschnitten
 */
function extractLearnings(content: string): ParsedLearning[] {
  const learnings: ParsedLearning[] = [];
  const lines = content.split('\n');
  
  let currentId = '';
  let currentTitle = '';
  let currentType: ParsedLearning['type'] = 'principle';
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    
    // Abschnitts-Header erkennen: ### 1. Titel
    const headerMatch = line.match(/^###\s+(\d+)\.?\s*(.+)/);
    if (headerMatch) {
      // Vorherigen speichern
      if (currentId && currentTitle) {
        learnings.push({
          id: currentId,
          title: currentTitle,
          type: currentType
        });
      }
      
      currentId = headerMatch[1];
      currentTitle = headerMatch[2].trim();
      
      // Typ aus naechsten Zeilen ableiten
      currentType = determineType(lines, i);
      
      continue;
    }
  }
  
  // Letzten speichern
  if (currentId && currentTitle) {
    learnings.push({
      id: currentId,
      title: currentTitle,
      type: currentType
    });
  }
  
  return learnings;
}

/**
 * Bestimmt Typ aus Kontext
 */
function determineType(lines: string[], startIdx: number): ParsedLearning['type'] {
  // Pruefe naechste 5 Zeilen auf Schluesselwoerter
  const context = lines.slice(startIdx, startIdx + 5).join(' ').toLowerCase();
  
  if (context.includes('fehler') || context.includes('error')) {
    return 'error';
  }
  if (context.includes('fix') || context.includes('loesung') || context.includes('behoben')) {
    return 'fix';
  }
  
  return 'principle';
}

/**
 * Extrahiert letztes Update-Datum
 */
function extractLastUpdate(content: string): string | undefined {
  const match = content.match(/Letzte Aktualisierung:\s*(.+)/i);
  return match?.[1]?.trim();
}
