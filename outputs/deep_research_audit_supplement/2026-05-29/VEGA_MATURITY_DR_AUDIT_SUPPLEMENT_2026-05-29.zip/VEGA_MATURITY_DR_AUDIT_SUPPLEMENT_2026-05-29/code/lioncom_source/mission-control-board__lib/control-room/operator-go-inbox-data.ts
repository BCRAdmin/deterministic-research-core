export type OperatorGoPriority = 'kritisch' | 'hoch' | 'normal' | 'später';
export type OperatorGoKind = 'Blogpost' | 'Tool Update' | 'Website Block' | 'Launch Gate';

export interface OperatorGoProject {
  id: string;
  label: string;
  subtitle: string;
}

export interface OperatorGoItem {
  id: string;
  projectId: string;
  title: string;
  kind: OperatorGoKind;
  priority: OperatorGoPriority;
  flags: string[];
  operatorNeed: string;
  why: string;
  chosenVariant: string;
  rationale: string;
  benefits: string[];
  risks: string[];
  liveImpact: string[];
  verification: string[];
  deployMode: string;
  expectedLivePath?: string;
  previewUrl?: string;
  localPreviewUrl?: string;
  livePreviewUrl?: string;
  previewTitle: string;
  previewLead: string;
  previewSections: string[];
  previewCtas: string[];
  supportingPaths: string[];
}

export interface OperatorGoManifest {
  batchTime?: string;
  project: OperatorGoProject;
  items: OperatorGoItem[];
}

export interface OperatorGoProjectSource extends OperatorGoProject {
  manifestPath: string;
}

export const operatorGoProjectSources: OperatorGoProjectSource[] = [
  {
    id: 'materialbedarf',
    label: 'materialbedarf-rechner.de',
    subtitle: 'Tool-, Content- und Indexierungsblöcke mit Operator-Go',
    manifestPath: '/Users/BjornRosinger/Dreamfactory/utility webseite/materialbedarf-rechner.de/ops/OPERATOR_GO_MANIFEST.json',
  },
  {
    id: 'elterngeld',
    label: 'mein-elterngeldrechner.de',
    subtitle: 'Aktuell kein freigabereifes Operator-Paket',
    manifestPath: '/Users/BjornRosinger/Dreamfactory/utility webseite/mein-elterngeldrechner.de/docs/OPERATOR_GO_MANIFEST.json',
  },
  {
    id: 'lioncom',
    label: 'LIONCOM',
    subtitle: 'Aktuell kein freigabereifes Operator-Paket',
    manifestPath: '/Users/BjornRosinger/Documents/DreamFactory/LIONCOM/mission-control-board/.recovery/operator-go-manifest.json',
  },
];
