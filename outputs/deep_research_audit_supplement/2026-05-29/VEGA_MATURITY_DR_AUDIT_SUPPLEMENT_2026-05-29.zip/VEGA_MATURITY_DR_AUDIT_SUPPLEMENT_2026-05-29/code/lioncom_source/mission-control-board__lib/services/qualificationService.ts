import { promises as fs } from 'fs';

import { PATHS } from '../constants/paths';
import type { QualificationSnapshot } from '../control-room/types';

const DEFAULT_SNAPSHOT: QualificationSnapshot = {
  overallState: 'not-run',
  releaseDecision: 'blocked',
  updatedAt: undefined,
  summary: 'System qualification has not been executed from this workspace yet.',
  completedSections: 0,
  totalSections: 3,
  sections: [
    {
      id: 'G1',
      title: 'End-to-End Workflow Validation',
      state: 'pending',
      detail: 'No workflow validation evidence has been recorded yet.',
      evidencePath: 'QUALIFICATION_RUNS/END_TO_END_VALIDATION.md',
    },
    {
      id: 'G2',
      title: 'Failure and Recovery Validation',
      state: 'pending',
      detail: 'No failure and recovery evidence has been recorded yet.',
      evidencePath: 'QUALIFICATION_RUNS/FAILURE_RECOVERY_VALIDATION.md',
    },
    {
      id: 'G3',
      title: 'Production Readiness Review',
      state: 'pending',
      detail: 'No formal readiness review has been recorded yet.',
      evidencePath: 'PRODUCTION_READINESS_REVIEW.md',
    },
  ],
  blockers: [
    'Run the qualification suite before treating this workspace as release-assessed.',
  ],
  residualRisks: [],
  approvedFor: [],
  notApprovedFor: ['Production acceptance'],
  evidencePaths: [
    'SYSTEM_QUALIFICATION_STATUS.json',
    'PRODUCTION_READINESS_REVIEW.md',
  ],
};

export async function getQualificationStatus(): Promise<QualificationSnapshot> {
  const parsed = await safeJson<QualificationSnapshot>(PATHS.SYSTEM_QUALIFICATION_STATUS);
  if (!parsed) {
    return DEFAULT_SNAPSHOT;
  }

  return {
    ...DEFAULT_SNAPSHOT,
    ...parsed,
    sections: Array.isArray(parsed.sections) && parsed.sections.length > 0 ? parsed.sections : DEFAULT_SNAPSHOT.sections,
    blockers: Array.isArray(parsed.blockers) ? parsed.blockers : DEFAULT_SNAPSHOT.blockers,
    residualRisks: Array.isArray(parsed.residualRisks) ? parsed.residualRisks : DEFAULT_SNAPSHOT.residualRisks,
    approvedFor: Array.isArray(parsed.approvedFor) ? parsed.approvedFor : DEFAULT_SNAPSHOT.approvedFor,
    notApprovedFor: Array.isArray(parsed.notApprovedFor) ? parsed.notApprovedFor : DEFAULT_SNAPSHOT.notApprovedFor,
    evidencePaths: Array.isArray(parsed.evidencePaths) && parsed.evidencePaths.length > 0
      ? parsed.evidencePaths
      : DEFAULT_SNAPSHOT.evidencePaths,
  };
}

async function safeJson<T>(filePath: string): Promise<T | null> {
  try {
    return JSON.parse(await fs.readFile(filePath, 'utf-8')) as T;
  } catch {
    return null;
  }
}
