import baseline from '@/data/portfolio-control-tower-baseline.json';
import type { PortfolioExecutionContract, PortfolioRepositoryStatus } from '@/lib/types';

interface PortfolioBaselineFile {
  schemaVersion: number;
  asOf: string;
  source: string;
  executionContract: PortfolioExecutionContract;
  repositories: PortfolioRepositoryStatus[];
}

export const portfolioControlTowerBaseline = baseline as PortfolioBaselineFile;

export function loadPortfolioRepositories(): PortfolioRepositoryStatus[] {
  return portfolioControlTowerBaseline.repositories;
}

export function loadPortfolioExecutionContract(): PortfolioExecutionContract {
  return portfolioControlTowerBaseline.executionContract;
}
