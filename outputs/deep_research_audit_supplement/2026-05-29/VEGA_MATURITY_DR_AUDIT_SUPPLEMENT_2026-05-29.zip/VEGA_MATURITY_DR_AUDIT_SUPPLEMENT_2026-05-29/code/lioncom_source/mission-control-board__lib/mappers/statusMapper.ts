// Status Mapper - Vereinheitlicht Parser/Services zu UI-Status
// Nur Mapping, keine Dateizugriffe, keine UI-Logik

import { getSystemHealth } from '../services/healthService';
import { getCronStatus } from '../services/cronService';
import { syncGitHubSyncStatus } from '../services/githubSyncService';
import { getTelegramStatus } from '../services/telegramService';
import { getLastCommit } from '../services/gitService';
import { parseDashboard } from '../parsers/dashboardParser';

export type StatusValue = 'healthy' | 'warning' | 'error' | 'unknown';

export interface MappedStatus {
  openclaw: StatusValue;
  telegram: StatusValue;
  cron: StatusValue;
  github: StatusValue;
  morningBriefing: StatusValue;
  nightlyResearch: StatusValue;
  phase: string;
  lastUpdated: string;
}

/**
 * Mappt alle Services/Parser zu einheitlichem Status
 */
export async function mapStatus(): Promise<MappedStatus> {
  const timestamp = new Date().toISOString();
  
  // Parallel alle Status-Quellen abfragen
  const [
    health,
    cron,
    telegram,
    githubSync,
    gitCommit,
    dashboard
  ] = await Promise.all([
    getSystemHealth().catch(() => null),
    getCronStatus().catch(() => null),
    getTelegramStatus().catch(() => null),
    syncGitHubSyncStatus().catch(() => null),
    getLastCommit().catch(() => null),
    parseDashboard().catch(() => null)
  ]);
  
  return {
    openclaw: mapOpenClawStatus(health),
    telegram: mapTelegramStatus(telegram),
    cron: mapCronStatus(cron),
    github: mapGitHubStatus(githubSync, gitCommit),
    morningBriefing: mapMorningBriefingStatus(cron, telegram),
    nightlyResearch: mapNightlyResearchStatus(cron),
    phase: dashboard?.systemStatus?.phase || 'INITIALISIERUNG',
    lastUpdated: timestamp
  };
}

/**
 * OpenClaw-Status aus Health-Check
 */
function mapOpenClawStatus(health: Awaited<ReturnType<typeof getSystemHealth>> | null): StatusValue {
  if (!health) return 'unknown';
  return health.overall;
}

/**
 * Telegram-Status
 */
function mapTelegramStatus(telegram: Awaited<ReturnType<typeof getTelegramStatus>> | null): StatusValue {
  if (!telegram) return 'unknown';
  if (telegram.status === 'OK') return 'healthy';
  if (telegram.status === 'WARNING') return 'warning';
  return 'unknown';
}

/**
 * Cron-Status
 */
function mapCronStatus(cron: Awaited<ReturnType<typeof getCronStatus>> | null): StatusValue {
  if (!cron) return 'unknown';
  if (!cron.available) return 'error';
  if (cron.hasMorningBriefing && cron.hasNightlyResearch) return 'healthy';
  if (cron.hasMorningBriefing || cron.hasNightlyResearch) return 'warning';
  return 'warning';
}

/**
 * GitHub-Status
 */
function mapGitHubStatus(
  sync: Awaited<ReturnType<typeof syncGitHubSyncStatus>> | null,
  commit: Awaited<ReturnType<typeof getLastCommit>> | null
): StatusValue {
  if (!sync) return 'unknown';
  if (sync.state === 'blocked' || sync.state === 'offline') return 'error';
  if (sync.state === 'warning') return 'warning';
  if (!commit) return 'warning';
  return 'healthy';
}

/**
 * Morning Briefing Status
 */
function mapMorningBriefingStatus(
  cron: Awaited<ReturnType<typeof getCronStatus>> | null,
  telegram: Awaited<ReturnType<typeof getTelegramStatus>> | null
): StatusValue {
  if (!cron?.hasMorningBriefing) return 'error';
  if (telegram?.status === 'OK') return 'healthy';
  if (telegram?.status === 'WARNING') return 'warning';
  return 'unknown';
}

/**
 * Nightly Research Status
 */
function mapNightlyResearchStatus(cron: Awaited<ReturnType<typeof getCronStatus>> | null): StatusValue {
  if (!cron) return 'unknown';
  if (cron.hasNightlyResearch) return 'healthy';
  return 'warning';
}
