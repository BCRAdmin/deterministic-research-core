// System Status Types

export interface SystemStatus {
  phase: 'INITIALISIERUNG' | 'PLANUNG' | 'AUSFÜHRUNG' | 'VALIDIERUNG' | 'ABSCHLUSS';
  components: ComponentStatus[];
  lastUpdated: string;
}

export interface ComponentStatus {
  name: string;
  status: 'PRODUKTIV' | 'DOKUMENTIERT' | 'NICHT_VERFÜGBAR';
  details?: string;
}

export interface DashboardData {
  systemStatus: SystemStatus;
  trends: TrendItem[];
  nextSteps: NextStep[];
}

export interface TrendItem {
  id: string;
  title: string;
  status: 'UMSETZBAR' | 'PLANUNG' | 'EVALUATION';
  priority: number;
}

export interface NextStep {
  priority: 'P0' | 'P1' | 'P2' | 'P3';
  task: string;
  status: 'Bereit' | 'In Arbeit' | 'Blockiert';
}
