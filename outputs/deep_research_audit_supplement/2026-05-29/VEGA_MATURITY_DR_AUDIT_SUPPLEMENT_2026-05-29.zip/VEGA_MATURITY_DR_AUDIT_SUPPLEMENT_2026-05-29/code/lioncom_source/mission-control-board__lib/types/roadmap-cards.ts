import type { Priority } from '@/lib/types';

export const ROADMAP_CARD_STATUSES = ['parked', 'review_due', 'queued', 'done', 'blocked'] as const;

export type RoadmapCardStatus = (typeof ROADMAP_CARD_STATUSES)[number];
export type RoadmapCardPriority = Priority;
export type RoadmapCardTaskType = 'Mission' | 'Research' | 'Code' | 'Repair' | 'Verification' | 'Follow-up';
export type RoadmapCardTargetMode = 'Vivi zuerst' | 'Direkt an Vega' | 'Vivi → Vega Handoff' | 'Nur Review';
export type RoadmapCardRuntime = 'Local' | 'Cloud' | 'Auto';

export interface RoadmapCard {
  id: string;
  title: string;
  summary: string;
  sourcePath: string;
  status: RoadmapCardStatus;
  priority: RoadmapCardPriority;
  gate: string;
  risk: string;
  targetMode: RoadmapCardTargetMode;
  taskType: RoadmapCardTaskType;
  runtime: RoadmapCardRuntime;
  reviewAt: string;
  nextStep: string;
  createdAt: string;
  updatedAt: string;
  dispatchRef?: string;
  note?: string;
}

export interface RoadmapCardCounts {
  total: number;
  due: number;
  parked: number;
  review_due: number;
  queued: number;
  done: number;
  blocked: number;
}

export interface RoadmapCardSnapshot {
  cards: RoadmapCard[];
  dueCards: RoadmapCard[];
  counts: RoadmapCardCounts;
  generatedAt: string;
  storagePath: string;
}

export interface RoadmapCardCreateInput {
  id?: string;
  title?: string;
  summary?: string;
  sourcePath?: string;
  status?: RoadmapCardStatus;
  priority?: RoadmapCardPriority;
  gate?: string;
  risk?: string;
  targetMode?: RoadmapCardTargetMode;
  taskType?: RoadmapCardTaskType;
  runtime?: RoadmapCardRuntime;
  reviewAt?: string;
  nextStep?: string;
  note?: string;
}

export interface RoadmapCardUpdateInput {
  status?: RoadmapCardStatus;
  reviewAt?: string;
  note?: string;
}
