// Learnings and Risk Types

export interface Learning {
  id: string;
  category: 'error' | 'fix' | 'principle' | 'workflow';
  title: string;
  description: string;
  date: string;
}

export interface Risk {
  id: string;
  description: string;
  probability: 'Hoch' | 'Mittel' | 'Niedrig';
  mitigation: string;
  status: 'Offen' | 'Behoben' | 'Akzeptiert';
}

export interface PhaseReview {
  phase: string;
  completed: boolean;
  learnings: string[];
  blockers: string[];
}

export interface LearningArchive {
  learnings: Learning[];
  risks: Risk[];
  phaseReviews: PhaseReview[];
}
