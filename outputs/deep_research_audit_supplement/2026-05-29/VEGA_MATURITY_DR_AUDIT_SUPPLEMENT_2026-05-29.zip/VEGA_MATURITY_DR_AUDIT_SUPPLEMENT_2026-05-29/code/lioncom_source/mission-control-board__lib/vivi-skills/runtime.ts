import 'server-only';

import { spawn } from 'child_process';
import { promises as fs } from 'fs';
import path from 'path';

import { PATHS, WORKSPACE_ROOT } from '@/lib/constants/paths';
import { readDesktopSettings } from '@/lib/services/desktopSettingsService';
import { appendRailBlock, parseRailBlocks, readRailContent } from '@/lib/services/structuredRailService';
import { getViviSkill } from '@/lib/vivi-skills/registry';
import { createViviSkillProposal, readLatestSkillProposals } from '@/lib/vivi-skills/proposals';
import type {
  ViviSkill,
  ViviSkillArtifact,
  ViviSkillCapability,
  ViviSkillHubEntry,
  ViviSkillRun,
  ViviSkillRunInput,
  ViviSkillRunStatus,
} from '@/lib/vivi-skills/types';

const VIVI_SKILL_RUNS_HEADER = '# Vivi Skill Runs\n\nAppend-only rail for Vivi skill routing, executions, gates and artifacts.\n\n';
const CODEX_INBOX_HEADER = '# Codex Inbox\n\nTechnical handoffs queued for Vega / Codex.\n\n';
const LOCAL_PROBE_TIMEOUT_MS = 900;
const LOCAL_IMAGE_TIMEOUT_MS = 180_000;
const MEDIA_INGEST_TIMEOUT_MS = 75_000;
const MAX_FAILURE_ESCALATION_LOOKBACK = 10;
const LOCAL_IMAGE_PROVIDER_STATUS = path.join(
  WORKSPACE_ROOT,
  '.runtime',
  'vivi-skills',
  'image-provider',
  'LOCAL_IMAGE_PROVIDER_STATUS.md',
);
const MEDIA_INGEST_ARTIFACTS_DIR = path.join(PATHS.VIVI_SKILLS_ARTIFACTS_DIR, 'media-ingest');

interface SkillExecutionResult {
  capability: ViviSkillCapability;
  status: ViviSkillRunStatus;
  tone: ViviSkillRun['tone'];
  summary: string;
  detail: string;
  nextAction: string;
  artifacts: ViviSkillArtifact[];
}

interface ProcessResult {
  ok: boolean;
  command: string;
  args: string[];
  code: number | null;
  signal: string | null;
  stdout: string;
  stderr: string;
  detail: string;
  timedOut: boolean;
}

interface YtDlpRunner {
  command: string;
  argsPrefix: string[];
  label: string;
  version: string;
}

interface YoutubeTarget {
  videoId: string;
  url: string;
  input: string;
}

export async function runViviSkill(input: ViviSkillRunInput): Promise<ViviSkillRun> {
  const startedAt = new Date().toISOString();
  const skill = await getViviSkill(input.skillId);
  if (!skill) {
    const run = buildRun(input, {
      id: slugTimestamp('VSKILLRUN', startedAt),
      skillId: input.skillId,
      skillName: input.skillId,
      capability: 'chat.direct',
      status: 'failed',
      tone: 'critical',
      startedAt,
      summary: 'Skill nicht gefunden',
      detail: `Für ${input.skillId} existiert kein lokales Skill-Manifest.`,
      nextAction: 'Skill zuerst als Manifest registrieren oder als Missing-Skill-Proposal an Vega geben.',
      artifacts: [],
    });
    await persistSkillRun(run);
    await maybeEscalateRepeatedSkillFailure(run);
    return run;
  }

  const gateReason = requiredGateReason(skill);
  if (!skill.enabled || (gateReason && !input.operatorGateApproved)) {
    const run = buildRun(input, {
      id: slugTimestamp('VSKILLRUN', startedAt),
      skillId: skill.id,
      skillName: skill.name,
      capability: skill.capabilities[0] ?? 'chat.direct',
      status: 'blocked',
      tone: 'warning',
      startedAt,
      summary: !skill.enabled ? 'Skill ist deaktiviert' : 'Operator-Gate erforderlich',
      detail: !skill.enabled
        ? `${skill.name} ist im lokalen Vivi-Toolbelt deaktiviert.`
        : gateReason ?? 'Dieser Skill benötigt vor Ausführung eine Freigabe.',
      nextAction: !skill.enabled ? 'Skill im Vivi-Toolbelt aktivieren.' : 'Operator-Go einholen und Lauf erneut starten.',
      artifacts: [],
    });
    await persistSkillRun(run);
    await maybeEscalateRepeatedSkillFailure(run);
    return run;
  }

  let result: SkillExecutionResult;
  try {
    result = await executeBuiltinSkill(skill, input);
  } catch (error) {
    result = {
      capability: skill.capabilities[0] ?? 'chat.direct',
      status: 'failed',
      tone: 'critical',
      summary: 'Skill-Lauf fehlgeschlagen',
      detail: error instanceof Error ? error.message : String(error),
      nextAction: 'Vega soll den Skill-Lauf und die lokale Runtime prüfen.',
      artifacts: [],
    };
  }

  const run = buildRun(input, {
    id: slugTimestamp('VSKILLRUN', startedAt),
    skillId: skill.id,
    skillName: skill.name,
    startedAt,
    ...result,
  });
  await persistSkillRun(run);
  await maybeEscalateRepeatedSkillFailure(run);
  return run;
}

export async function createVegaHandoffFromSkill(input: ViviSkillRunInput): Promise<ViviSkillRun> {
  return runViviSkill({ ...input, skillId: 'vega.handoff.create' });
}

async function executeBuiltinSkill(skill: ViviSkill, input: ViviSkillRunInput): Promise<SkillExecutionResult> {
  switch (skill.runtime.handler) {
    case 'lioncom-status-read':
      return readLioncomStatus();
    case 'vivi-model-route':
      return readViviModelRoute();
    case 'image-generate-provider-check':
      return checkImageProviders();
    case 'image-generate-local':
      return generateLocalImage(input);
    case 'repo-inspect-readonly':
      return inspectRepoReadonly();
    case 'browser-qa-inspect':
      return inspectBrowserQa();
    case 'media-youtube-transcript':
      return ingestYoutubeTranscript(input);
    case 'vivi-dispatch-create':
      return prepareDispatch(input);
    case 'vega-handoff-create':
      return createVegaHandoff(input);
    case 'vivi-memory-capture':
      return captureMemoryHint(input);
    case 'skill-proposal-create':
      return proposeMissingSkill(input);
    case 'skill-hub-local':
      return readLocalSkillHub();
    case 'skill-remote-dry-run':
      return runRemoteSkillDryRun();
    default:
      return {
        capability: skill.capabilities[0] ?? 'chat.direct',
        status: 'proposal',
        tone: 'info',
        summary: 'Skill-Handler wartet auf Implementierung',
        detail: `${skill.name} ist im Manifest vorhanden, aber der Handler ist noch nicht aktiv verdrahtet.`,
        nextAction: 'Vega soll den Handler in der nächsten Skill-Ausbaustufe implementieren.',
        artifacts: [],
      };
  }
}

async function readLioncomStatus(): Promise<SkillExecutionResult> {
  const [loopStatus, gateStatus, sessionsRaw, queue, intake] = await Promise.all([
    readJsonFile<Record<string, unknown>>(PATHS.LOCAL_DUO_LOOP_STATUS),
    readJsonFile<Record<string, unknown>>(PATHS.VIVI_REPORT_QUALITY_GATE_STATUS),
    readJsonFile<unknown[]>(PATHS.VIVI_CHAT_SESSIONS),
    readRailContent(PATHS.VIVI_COMMAND_QUEUE),
    readRailContent(PATHS.WORK_INTAKE),
  ]);
  const sessions = Array.isArray(sessionsRaw) ? sessionsRaw.length : 0;
  const queueCount = parseRailBlocks(queue).filter(isOpenRailBlock).length;
  const intakeCount = parseRailBlocks(intake).filter(isOpenRailBlock).length;
  const state = stringValue(loopStatus?.state) || 'unbekannt';
  const claim = stringValue(loopStatus?.lastClaimId) || 'keine aktive Claim im Statusfile';
  const gateOk = gateStatus?.ok === true;
  return {
    capability: 'lioncom.status.read',
    status: 'completed',
    tone: gateOk ? 'success' : 'info',
    summary: `LIONCOM lokal gelesen: Loop ${state}, ${queueCount} Queue, ${intakeCount} Intake, ${sessions} Vivi-Sessions.`,
    detail: `Aktive/letzte Claim: ${claim}. Quality Gate: ${gateOk ? 'frei' : 'prüfen oder nicht gesetzt'}.`,
    nextAction: queueCount + intakeCount > 0 ? 'Vivi kann die offenen lokalen Rails priorisieren.' : 'Keine offene lokale Vivi-Queue aus diesem Snapshot.',
    artifacts: [
      { label: 'Vivi Loop Status', kind: 'file', value: PATHS.LOCAL_DUO_LOOP_STATUS },
      { label: 'Quality Gate Status', kind: 'file', value: PATHS.VIVI_REPORT_QUALITY_GATE_STATUS },
    ],
  };
}

async function readViviModelRoute(): Promise<SkillExecutionResult> {
  const [settings, override] = await Promise.all([
    readDesktopSettings(),
    readJsonFile<Record<string, unknown>>(PATHS.VIVI_MODEL_OVERRIDE),
  ]);
  const requestedProvider = stringValue(override?.requestedProvider) || stringValue(override?.provider) || settings.viviProviderPreset || 'lmstudio';
  const requestedModel = stringValue(override?.requestedModel) || stringValue(override?.model) || settings.viviRequestedModel || 'nicht gesetzt';
  const effectiveProvider = stringValue(override?.effectiveProvider) || requestedProvider;
  const effectiveModel = stringValue(override?.effectiveModel) || requestedModel;
  const mismatch = requestedProvider !== effectiveProvider || requestedModel !== effectiveModel;
  return {
    capability: 'chat.direct',
    status: 'completed',
    tone: mismatch ? 'warning' : 'success',
    summary: `Vivi-Modellroute: angefordert ${requestedProvider}/${requestedModel}, effektiv ${effectiveProvider}/${effectiveModel}.`,
    detail: mismatch
      ? 'Anforderung und effektiver Pfad weichen voneinander ab. Das ist ok, wenn ein lokaler Fallback aktiv ist, muss aber sichtbar bleiben.'
      : 'Anforderung und effektiver Modellpfad stimmen überein oder es liegt kein separater Fallback vor.',
    nextAction: mismatch ? 'Runtime-Karte prüfen und bei Bedarf Provider neu speichern.' : 'Vivi kann diesen Pfad für direkte Antworten nutzen.',
    artifacts: [
      { label: 'Modell-Override', kind: 'file', value: PATHS.VIVI_MODEL_OVERRIDE },
    ],
  };
}

async function checkImageProviders(): Promise<SkillExecutionResult> {
  const [comfy, stableDiffusion] = await Promise.all([
    probeLocalEndpoint('http://127.0.0.1:8188/system_stats'),
    probeLocalEndpoint('http://127.0.0.1:7860/sdapi/v1/options'),
  ]);
  const gatedCloud = [
    process.env.OPENAI_API_KEY || process.env.LIONCOM_OPENAI_API_KEY ? 'OpenAI Images API-Key vorhanden' : '',
    process.env.REPLICATE_API_TOKEN ? 'Replicate API-Token vorhanden' : '',
  ].filter(Boolean);
  const localProviders = [
    comfy.ok ? 'ComfyUI 8188 erreichbar' : '',
    stableDiffusion.ok ? 'Stable Diffusion WebUI 7860 erreichbar' : '',
  ].filter(Boolean);
  const hasProvider = localProviders.length > 0;

  return {
    capability: 'image.generate',
    status: hasProvider ? 'completed' : 'missing-provider',
    tone: hasProvider ? 'success' : 'warning',
    summary: hasProvider
      ? `Bildprovider verfügbar: ${localProviders.join(', ')}.`
      : 'Bildgenerierung erkannt, aber kein lokaler Bildprovider ist erreichbar.',
    detail: [
      comfy.detail,
      stableDiffusion.detail,
      gatedCloud.length ? `Cloud-Provider wären nur mit Operator-Gate nutzbar: ${gatedCloud.join(', ')}.` : 'Keine Cloud-Bildprovider-Credentials im Prozess sichtbar.',
      'Lokale Vorbereitung: im mission-control-board `npm run vivi:image:preflight` und danach bei Bedarf `npm run vivi:image:start-provider` ausführen.',
    ].join(' '),
    nextAction: hasProvider
      ? 'Vivi kann jetzt image.generate.local ausführen und ein lokales Artefakt schreiben.'
      : 'Lokalen Stable-Diffusion-WebUI-Provider vorbereiten/starten: npm run vivi:image:preflight, dann npm run vivi:image:start-provider. Cloud bleibt gesperrt.',
    artifacts: [
      { label: 'ComfyUI Probe', kind: 'link', value: 'http://127.0.0.1:8188/system_stats' },
      { label: 'Stable Diffusion Probe', kind: 'link', value: 'http://127.0.0.1:7860/sdapi/v1/options' },
      { label: 'Lokaler Provider Status', kind: 'file', value: LOCAL_IMAGE_PROVIDER_STATUS },
    ],
  };
}

async function generateLocalImage(input: ViviSkillRunInput): Promise<SkillExecutionResult> {
  const prompt = cleanPrompt(String(input.payload?.prompt || input.operatorMessage || ''));
  if (!prompt) {
    return {
      capability: 'image.generate',
      status: 'proposal',
      tone: 'warning',
      summary: 'Bildwunsch braucht einen Prompt.',
      detail: 'Vivi hat Bildgenerierung erkannt, aber keinen lesbaren Bildprompt gefunden.',
      nextAction: 'Bitte beschreibe kurz Motiv, Stil und Format; Vivi erzeugt dann ein lokales Artefakt, wenn ein Provider läuft.',
      artifacts: [],
    };
  }

  const stableDiffusionProbe = await probeLocalEndpoint('http://127.0.0.1:7860/sdapi/v1/options');
  if (!stableDiffusionProbe.ok) {
    const setupFile = await writeTextArtifact(
      PATHS.VIVI_SKILLS_IMAGE_ARTIFACTS_DIR,
      'image-provider-setup',
      [
        '# Lokaler Bildprovider fehlt',
        '',
        `Prompt: ${prompt}`,
        '',
        'Vivi hat den Bildwunsch erkannt, aber keinen lokalen Stable-Diffusion-WebUI-Provider auf Port 7860 erreicht.',
        'ComfyUI wird aktuell als Provider erkannt, aber die generische Workflow-Ausführung bleibt bis zur Workflow-Konfiguration gesperrt.',
        '',
        'Sichere Optionen:',
        '- Im mission-control-board `npm run vivi:image:preflight` ausführen.',
        '- Stable Diffusion WebUI lokal mit `npm run vivi:image:start-provider` starten und danach erneut senden.',
        '- Einen ComfyUI-Workflow lokal hinterlegen und von Vega verifizieren lassen.',
        '- Cloud-Bildprovider erst nach bewusstem Operator-Gate einrichten.',
        '',
      ].join('\n'),
      'md',
    );
    return {
      capability: 'image.generate',
      status: 'missing-provider',
      tone: 'warning',
      summary: 'Bildprompt erkannt, aber kein lokaler Bildgenerator ist erreichbar.',
      detail: stableDiffusionProbe.detail,
      nextAction: 'Stable Diffusion WebUI lokal starten oder Vega einen verifizierten ComfyUI-Workflow bauen lassen.',
      artifacts: [
        { label: 'Provider-Hinweis', kind: 'file', value: setupFile },
        { label: 'Lokaler Provider Status', kind: 'file', value: LOCAL_IMAGE_PROVIDER_STATUS },
        { label: 'Prompt', kind: 'text', value: prompt },
      ],
    };
  }

  const body = {
    prompt,
    negative_prompt: 'text, watermark, low quality, blurry, distorted',
    steps: numberPayload(input, 'steps', 18),
    cfg_scale: numberPayload(input, 'cfgScale', 6),
    width: numberPayload(input, 'width', 768),
    height: numberPayload(input, 'height', 768),
    batch_size: 1,
    n_iter: 1,
    sampler_name: 'DPM++ 2M Karras',
  };

  const response = await postJson('http://127.0.0.1:7860/sdapi/v1/txt2img', body, LOCAL_IMAGE_TIMEOUT_MS);
  if (!response.ok) {
    return {
      capability: 'image.generate',
      status: 'failed',
      tone: 'critical',
      summary: 'Lokale Bildgenerierung ist fehlgeschlagen.',
      detail: response.detail,
      nextAction: 'Vega soll Provider-Log und Prompt prüfen; Vivi meldet keinen Fake-Erfolg.',
      artifacts: [
        { label: 'Prompt', kind: 'text', value: prompt },
      ],
    };
  }

  const image = extractFirstStableDiffusionImage(response.value);
  if (!image) {
    return {
      capability: 'image.generate',
      status: 'failed',
      tone: 'critical',
      summary: 'Bildprovider antwortete ohne Bildartefakt.',
      detail: 'Stable Diffusion WebUI lieferte HTTP OK, aber kein images[0] im erwarteten Format.',
      nextAction: 'Provider-Version und API-Antwort von Vega prüfen lassen.',
      artifacts: [
        { label: 'Prompt', kind: 'text', value: prompt },
      ],
    };
  }

  await fs.mkdir(PATHS.VIVI_SKILLS_IMAGE_ARTIFACTS_DIR, { recursive: true });
  const filePath = path.join(PATHS.VIVI_SKILLS_IMAGE_ARTIFACTS_DIR, `${slugTimestamp('VIVIIMG')}.png`);
  await fs.writeFile(filePath, Buffer.from(image, 'base64'));

  return {
    capability: 'image.generate',
    status: 'completed',
    tone: 'success',
    summary: 'Bild lokal erzeugt.',
    detail: `Vivi hat den Prompt lokal über Stable Diffusion WebUI verarbeitet und ein PNG-Artefakt geschrieben. Prompt: ${truncate(prompt, 360)}`,
    nextAction: 'Artefakt prüfen; bei Änderungswunsch neue Nachricht mit gewünschter Korrektur senden.',
    artifacts: [
      { label: 'Bildartefakt', kind: 'image', value: filePath },
      { label: 'Prompt', kind: 'text', value: prompt },
    ],
  };
}

async function inspectRepoReadonly(): Promise<SkillExecutionResult> {
  const packageJson = await readJsonFile<{ scripts?: Record<string, string>; version?: string }>(path.join(process.cwd(), 'package.json'));
  const head = await readGitHead();
  const verifierScripts = Object.keys(packageJson?.scripts ?? {}).filter((script) => script.startsWith('verify:') || script.startsWith('vivi:'));
  return {
    capability: 'repo.inspect',
    status: 'completed',
    tone: 'success',
    summary: `Repo read-only geprüft: Branch ${head}, ${verifierScripts.length} Vivi/V2-Verifier-Skripte sichtbar.`,
    detail: `App-Version ${packageJson?.version ?? 'unbekannt'}. Wichtige Verifier: ${verifierScripts.slice(0, 8).join(', ') || 'keine gefunden'}.`,
    nextAction: 'Für Codeänderungen Vega-Übergabe erstellen; Vivi bleibt bei Read-only-Lage und Operator-Kontext.',
    artifacts: [
      { label: 'Repo Root', kind: 'file', value: process.cwd() },
      { label: 'Workspace Root', kind: 'file', value: WORKSPACE_ROOT },
    ],
  };
}

async function inspectBrowserQa(): Promise<SkillExecutionResult> {
  const visualVerifier = path.join(process.cwd(), 'scripts', 'verify_control_plane_v2_visual.mjs');
  const localVerifier = path.join(process.cwd(), 'scripts', 'verify_control_plane_v2_local.mjs');
  const [visualExists, localExists] = await Promise.all([fileExists(visualVerifier), fileExists(localVerifier)]);
  return {
    capability: 'browser.inspect',
    status: visualExists && localExists ? 'completed' : 'failed',
    tone: visualExists && localExists ? 'success' : 'warning',
    summary: visualExists && localExists
      ? 'Browser-/Visual-QA-Rails sind lokal vorhanden.'
      : 'Mindestens ein V2-Browser-/Verifier-Skript fehlt.',
    detail: `Visual-QA: ${visualExists ? 'vorhanden' : 'fehlt'}. Lokaler V2-Verifier: ${localExists ? 'vorhanden' : 'fehlt'}.`,
    nextAction: visualExists && localExists
      ? 'Vega kann bei UI-Änderungen die bestehenden Verifier ausführen.'
      : 'Verifier-Pfad reparieren, bevor UI-Arbeit grün gemeldet wird.',
    artifacts: [
      { label: 'Visual Verifier', kind: 'file', value: visualVerifier },
      { label: 'V2 Local Verifier', kind: 'file', value: localVerifier },
    ],
  };
}

async function ingestYoutubeTranscript(input: ViviSkillRunInput): Promise<SkillExecutionResult> {
  const target = extractYoutubeTarget(input);
  if (!target) {
    return {
      capability: 'media.transcript',
      status: 'proposal',
      tone: 'warning',
      summary: 'YouTube-Transcript braucht eine Video-URL oder Video-ID.',
      detail: 'Vivi hat eine Media-/YouTube-Anfrage erkannt, aber keinen eindeutigen YouTube-Link und keine 11-stellige Video-ID gefunden.',
      nextAction: 'YouTube-Link erneut senden oder ein lokales Transcript-Artefakt an Vivi übergeben.',
      artifacts: [],
    };
  }

  const providedTranscript = stringValue(input.payload?.transcriptText).trim();
  const runDir = path.join(MEDIA_INGEST_ARTIFACTS_DIR, `${target.videoId}-${slugTimestamp('YTINGEST')}`);
  await fs.mkdir(runDir, { recursive: true });

  if (providedTranscript) {
    const transcriptFile = path.join(runDir, `transcript-${target.videoId}.txt`);
    await fs.writeFile(transcriptFile, youtubeTranscriptFile(target, providedTranscript, 'operator_provided'), 'utf-8');
    const statusFile = await writeYoutubeIngestStatus({
      runDir,
      target,
      sourceGate: 'source_available',
      result: 'operator_transcript_used',
      detail: 'Operator-/lokales Transcript wurde übernommen; kein externer Fetch nötig.',
      checks: [],
    });
    return {
      capability: 'media.transcript',
      status: 'completed',
      tone: 'success',
      summary: 'YouTube-Transcript aus lokal übergebenem Text gesichert.',
      detail: `Source Gate: source_available. Vivi kann die Zusammenfassung aus ${transcriptFile} erstellen.`,
      nextAction: 'Transcript-Artefakt zusammenfassen und offene Quellen-/Recherchefragen separat markieren.',
      artifacts: [
        { label: 'Media-Ingest Status', kind: 'file', value: statusFile },
        { label: 'Transcript', kind: 'file', value: transcriptFile },
        { label: 'Video', kind: 'link', value: target.url },
      ],
    };
  }

  const runnerResolution = await resolveYtDlpRunner();
  if (!runnerResolution.runner) {
    const statusFile = await writeYoutubeIngestStatus({
      runDir,
      target,
      sourceGate: 'source_blocked',
      result: 'missing_yt_dlp',
      detail: 'Weder `yt-dlp` im PATH noch `python3 -m yt_dlp` ist verfügbar.',
      checks: runnerResolution.checks,
    });
    return {
      capability: 'media.transcript',
      status: 'missing-provider',
      tone: 'warning',
      summary: 'YouTube-Transcript blockiert: yt-dlp fehlt.',
      detail: 'Source Gate: source_blocked. Der lokale Media-Ingest braucht `yt-dlp` oder das Python-Modul `yt_dlp`; ohne Fetch-Tool darf Vivi den Videoinhalt nicht behaupten.',
      nextAction: 'Vega soll yt-dlp lokal bereitstellen oder dem Skill ein Transcript-/Caption-Artefakt übergeben.',
      artifacts: [
        { label: 'Media-Ingest Status', kind: 'file', value: statusFile },
        { label: 'Video', kind: 'link', value: target.url },
      ],
    };
  }

  const metadata = await runYtDlp(runnerResolution.runner, [
    '--dump-single-json',
    '--skip-download',
    '--no-playlist',
    '--no-warnings',
    target.url,
  ], runDir);
  const metadataFile = await writeYoutubeMetadataArtifact(runDir, metadata);

  const captions = await runYtDlp(runnerResolution.runner, [
    '--skip-download',
    '--no-playlist',
    '--write-subs',
    '--write-auto-subs',
    '--sub-langs',
    'de.*,de,en.*,en',
    '--sub-format',
    'vtt',
    '--output',
    path.join(runDir, '%(id)s.%(ext)s'),
    target.url,
  ], runDir);

  const captionFiles = await readCaptionFiles(runDir);
  const transcriptText = captionFiles.length ? captionToPlainText(captionFiles[0].content) : '';

  if (transcriptText) {
    const transcriptFile = path.join(runDir, `transcript-${target.videoId}.txt`);
    await fs.writeFile(transcriptFile, youtubeTranscriptFile(target, transcriptText, captionFiles[0].filePath), 'utf-8');
    const statusFile = await writeYoutubeIngestStatus({
      runDir,
      target,
      sourceGate: 'source_available',
      result: 'captions_extracted',
      detail: `Runner: ${runnerResolution.runner.label}. Caption-Datei: ${captionFiles[0].filePath}.`,
      checks: [metadata, captions],
    });
    return {
      capability: 'media.transcript',
      status: 'completed',
      tone: 'success',
      summary: 'YouTube-Captions extrahiert und als Transcript-Artefakt gesichert.',
      detail: `Source Gate: source_available. Tool: ${runnerResolution.runner.label}. Transcript-Länge: ${transcriptText.length} Zeichen.`,
      nextAction: 'Vivi kann jetzt ausschließlich aus dem Transcript-Artefakt zusammenfassen; zusätzliche Behauptungen brauchen weitere Quellen.',
      artifacts: [
        { label: 'Media-Ingest Status', kind: 'file', value: statusFile },
        { label: 'Transcript', kind: 'file', value: transcriptFile },
        { label: 'Raw Captions', kind: 'file', value: captionFiles[0].filePath },
        ...(metadataFile ? [{ label: 'Metadata', kind: 'file' as const, value: metadataFile }] : []),
        { label: 'Video', kind: 'link', value: target.url },
      ],
    };
  }

  const statusFile = await writeYoutubeIngestStatus({
    runDir,
    target,
    sourceGate: 'source_blocked',
    result: metadata.ok ? 'metadata_only_no_captions' : 'fetch_failed',
    detail: [
      `Runner: ${runnerResolution.runner.label}.`,
      metadata.ok ? 'Metadaten wurden gelesen, aber kein Caption-Transcript wurde geschrieben.' : 'Metadaten konnten nicht verifiziert gelesen werden.',
      captions.ok ? 'yt-dlp meldete Erfolg, aber im Artefaktordner lag keine VTT/SRT-Datei.' : `Caption-Fetch scheiterte: ${captions.detail}`,
    ].join(' '),
    checks: [metadata, captions],
  });

  return {
    capability: 'media.transcript',
    status: 'blocked',
    tone: 'warning',
    summary: 'YouTube-Transcript nicht verfügbar.',
    detail: [
      'Source Gate: source_blocked.',
      `Tool: ${runnerResolution.runner.label}.`,
      metadata.ok ? 'Metadaten sind vorhanden, aber ohne Caption-Text reicht das nicht für eine Inhaltszusammenfassung.' : 'YouTube-Fetch oder Netzwerkpfad ist blockiert.',
      captions.stderr ? `Letzter yt-dlp-Hinweis: ${truncate(captions.stderr, 420)}` : captions.detail,
    ].join(' '),
    nextAction: 'Transcript/Captions lokal bereitstellen, YouTube-Netzpfad freigeben oder einen separaten ASR-/Whisper-Fallback von Vega verifizieren lassen.',
    artifacts: [
      { label: 'Media-Ingest Status', kind: 'file', value: statusFile },
      ...(metadataFile ? [{ label: 'Metadata', kind: 'file' as const, value: metadataFile }] : []),
      { label: 'Video', kind: 'link', value: target.url },
    ],
  };
}

async function prepareDispatch(input: ViviSkillRunInput): Promise<SkillExecutionResult> {
  const raw = input.operatorMessage || String(input.payload?.title || 'Operator-Auftrag');
  return {
    capability: 'dispatch.route',
    status: 'completed',
    tone: 'info',
    summary: 'Dispatch-Empfehlung vorbereitet.',
    detail: `Vivi würde diesen Auftrag zuerst strukturieren und danach je nach Inhalt an Vivi oder Vega routen: ${truncate(raw, 240)}`,
    nextAction: 'Für operative Übergabe die Dispatch-Brücke nutzen oder den Auftrag als Vivi-Queue/Übergabe materialisieren.',
    artifacts: [
      { label: 'Empfohlene Route', kind: 'route', value: raw.match(/code|repo|bug|test|build/i) ? 'Vega Tech Cell' : 'Vivi Command' },
    ],
  };
}

async function createVegaHandoff(input: ViviSkillRunInput): Promise<SkillExecutionResult> {
  const now = new Date().toISOString();
  const handoffId = input.commandRef || slugTimestamp('VIVIVEGA', now);
  const title = truncate(input.operatorMessage || 'Technische Aufgabe aus Vivi-Chat', 120);
  const block = [
    `### ${handoffId}`,
    `- Added: ${now}`,
    '- Source: Vivi Capability Router',
    '- Status: queued',
    '- Priority: normal',
    '- Category: vivi-skill-handoff',
    '- Project Lane: lioncom-core',
    '- Target: Vega',
    `- Session Id: ${input.sessionId || 'unknown'}`,
    `- Reference: ${handoffId}`,
    `- Title: ${title}`,
    '- Desired Outcome: Technische Prüfung, Code-/Verifier-Arbeit oder klare Rückfrage an Vivi/Operator.',
    '- Raw Request:',
    ...quoteLines(input.operatorMessage || 'Keine Operator-Nachricht übergeben.'),
    '',
  ].join('\n');
  await appendRailBlock(PATHS.CODEX_INBOX, CODEX_INBOX_HEADER, `${block}\n`);

  return {
    capability: 'vega.handoff',
    status: 'completed',
    tone: 'info',
    summary: 'Vega-Übergabe erstellt.',
    detail: `Technische Anfrage wurde lokal in die Vega/Codex-Inbox geschrieben: ${handoffId}.`,
    nextAction: 'Vega prüft Code, Debugging, Tests oder Verifikation; Vivi hält den Operator-Dialog sichtbar.',
    artifacts: [
      { label: 'Vega Inbox', kind: 'file', value: PATHS.CODEX_INBOX },
      { label: 'Übergabe-Referenz', kind: 'route', value: handoffId },
    ],
  };
}

async function captureMemoryHint(input: ViviSkillRunInput): Promise<SkillExecutionResult> {
  const text = truncate(input.operatorMessage || String(input.payload?.memoryText || ''), 420);
  return {
    capability: 'memory.capture',
    status: text ? 'completed' : 'proposal',
    tone: text ? 'info' : 'warning',
    summary: text ? 'Memory-Hinweis lokal markiert.' : 'Memory-Hinweis braucht Inhalt.',
    detail: text
      ? `Der Hinweis wurde im Skill-Run-Audit verankert: ${text}`
      : 'Für dauerhafte Human-Overview-Aktualisierung braucht Vivi eine konkrete Projektwahrheit oder Regel.',
    nextAction: text
      ? 'Vega/Vivi muss daraus bei Relevanz einen Vault-Eintrag machen.'
      : 'Konkrete dauerhafte Erkenntnis formulieren.',
    artifacts: [
      { label: 'Skill Audit', kind: 'file', value: PATHS.VIVI_SKILL_RUNS },
    ],
  };
}

async function proposeMissingSkill(input: ViviSkillRunInput): Promise<SkillExecutionResult> {
  const requestedCapability = normalizeCapability(String(input.payload?.capability || input.payload?.requestedCapability || 'skill.propose'));
  const proposal = await createViviSkillProposal({
    requestedCapability,
    source: input.source || 'Vivi Chat Capability Router',
    operatorMessage: input.operatorMessage,
    reason: String(input.payload?.reason || 'Vivi kann diese Fähigkeit noch nicht sicher lokal ausführen und erstellt deshalb einen Vega-Bauauftrag.'),
  });

  return {
    capability: 'skill.propose',
    status: 'proposal',
    tone: 'info',
    summary: `Skill-Vorschlag erstellt: ${proposal.requestedCapability}.`,
    detail: `Vivi hat keinen sicheren aktiven Skill für ${proposal.requestedCapability} genutzt. Der Vorschlag wurde lokal gespeichert und als Vega-Übergabe queued: ${proposal.handoffRef || proposal.id}.`,
    nextAction: 'Vega baut/verifiziert den Skill oder lehnt ihn begründet ab; Vivi bleibt bis dahin ehrlich im Chat.',
    artifacts: [
      { label: 'Skill Proposal JSON', kind: 'file', value: proposal.files.json },
      { label: 'Skill Proposal Markdown', kind: 'file', value: proposal.files.markdown },
      { label: 'Vega-Übergabe', kind: 'route', value: proposal.handoffRef || proposal.id },
    ],
  };
}

async function readLocalSkillHub(): Promise<SkillExecutionResult> {
  const [entries, proposals] = await Promise.all([
    readLocalSkillCatalogEntries(),
    readLatestSkillProposals(5),
  ]);
  const installed = entries.filter((entry) => entry.status === 'installed').length;
  const proposalReady = entries.filter((entry) => entry.status === 'proposal-ready').length;
  const blocked = entries.filter((entry) => entry.status === 'blocked').length;

  return {
    capability: 'skill.hub',
    status: 'completed',
    tone: blocked ? 'warning' : 'success',
    summary: `Skill-Hub lokal gelesen: ${installed} installiert, ${proposalReady} vorschlagsbereit, ${blocked} geblockt.`,
    detail: [
      entries.map((entry) => `${entry.name}: ${entry.status} (${entry.capability})`).join('; '),
      proposals.length ? `Letzte Vorschläge: ${proposals.map((proposal) => proposal.title).join(' | ')}` : 'Keine aktuellen Skill-Vorschläge im lokalen Rail.',
    ].join('\n'),
    nextAction: proposalReady > 0
      ? 'Bei passender Operator-Anfrage erstellt Vivi automatisch einen Skill-Vorschlag für Vega.'
      : 'Installierte Skills nutzen; Remote-Installationen bleiben geblockt.',
    artifacts: [
      { label: 'Lokaler Skill-Katalog', kind: 'file', value: path.join(process.cwd(), 'data', 'vivi-skills', 'catalog.json') },
      { label: 'Skill-Proposals', kind: 'file', value: PATHS.VIVI_SKILLS_PROPOSALS_JSONL },
    ],
  };
}

async function runRemoteSkillDryRun(): Promise<SkillExecutionResult> {
  await fs.mkdir(path.dirname(PATHS.VIVI_SKILLS_REMOTE_CATALOG), { recursive: true });
  const existing = await readJsonFile<Record<string, unknown>>(PATHS.VIVI_SKILLS_REMOTE_CATALOG);
  const nextCatalog = existing || {
    generatedAt: new Date().toISOString(),
    mode: 'dry-run-only',
    allowedSources: [],
    pendingManifests: [],
    policy: 'Kein Netzwerk, kein Download, kein Install. Vega muss jeden Remote-Skill manuell prüfen.',
  };
  await fs.writeFile(PATHS.VIVI_SKILLS_REMOTE_CATALOG, `${JSON.stringify(nextCatalog, null, 2)}\n`, 'utf-8');

  return {
    capability: 'skill.remote_dry_run',
    status: 'completed',
    tone: 'info',
    summary: 'Remote-Skill-Hub bleibt im Dry-Run.',
    detail: 'Vivi hat den lokalen Remote-Katalog geprüft/angelegt. Es werden keine externen Quellen gezogen und kein unbekannter Code installiert.',
    nextAction: 'Wenn ein Remote-Skill wirklich gebraucht wird, erzeugt Vivi ein Proposal und Vega baut/verifiziert lokal.',
    artifacts: [
      { label: 'Remote Dry-Run Katalog', kind: 'file', value: PATHS.VIVI_SKILLS_REMOTE_CATALOG },
    ],
  };
}

async function persistSkillRun(run: ViviSkillRun): Promise<void> {
  await fs.mkdir(PATHS.VIVI_SKILLS_DIR, { recursive: true });
  await Promise.all([
    fs.appendFile(PATHS.VIVI_SKILLS_RUNS_JSONL, `${JSON.stringify(run)}\n`, 'utf-8'),
    fs.writeFile(PATHS.VIVI_SKILLS_LATEST_RUN, `${JSON.stringify(run, null, 2)}\n`, 'utf-8'),
    appendRailBlock(PATHS.VIVI_SKILL_RUNS, VIVI_SKILL_RUNS_HEADER, `${skillRunMarkdown(run)}\n`),
  ]);
}

async function maybeEscalateRepeatedSkillFailure(run: ViviSkillRun): Promise<void> {
  if (!['failed', 'missing-provider'].includes(run.status)) return;
  const runs = await readRecentSkillRuns(MAX_FAILURE_ESCALATION_LOOKBACK);
  const sameProblem = runs
    .filter((entry) => entry.skillId === run.skillId && entry.status === run.status)
    .slice(0, 3);
  if (sameProblem.length < 3) return;

  const day = run.startedAt.slice(0, 10).replace(/\D/g, '');
  const marker = `Skill Failure Key: ${run.skillId}:${run.status}:${day}`;
  const inbox = await readRailContent(PATHS.CODEX_INBOX) || '';
  if (inbox.includes(marker)) return;

  const block = [
    `### ${slugTimestamp('VIVISKILLFAIL')}`,
    `- Added: ${new Date().toISOString()}`,
    '- Source: Vivi Skill Runtime',
    '- Status: queued',
    '- Priority: high',
    '- Category: vivi-skill-failure-review',
    '- Project Lane: lioncom-core',
    '- Target: Vega',
    `- Skill Id: ${run.skillId}`,
    `- Failure Status: ${run.status}`,
    `- ${marker}`,
    `- Title: Wiederholter Skill-Blocker bei ${run.skillName}`,
    '- Desired Outcome: Fehlerursache lokalisieren, Provider-/Rail-Konfiguration reparieren oder Skill ehrlich deaktivieren.',
    '- Detail:',
    ...quoteLines(run.detail),
    '',
  ].join('\n');
  await appendRailBlock(PATHS.CODEX_INBOX, CODEX_INBOX_HEADER, `${block}\n`);
}

async function readRecentSkillRuns(limit: number): Promise<ViviSkillRun[]> {
  try {
    const content = await fs.readFile(PATHS.VIVI_SKILLS_RUNS_JSONL, 'utf-8');
    return content
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean)
      .map((line) => {
        try {
          return JSON.parse(line) as ViviSkillRun;
        } catch {
          return null;
        }
      })
      .filter((entry): entry is ViviSkillRun => Boolean(entry?.skillId && entry?.status && entry?.startedAt))
      .sort((left, right) => right.startedAt.localeCompare(left.startedAt))
      .slice(0, limit);
  } catch {
    return [];
  }
}

function buildRun(
  input: ViviSkillRunInput,
  value: Omit<ViviSkillRun, 'finishedAt' | 'requestedBy' | 'source' | 'sessionId' | 'messageId' | 'commandRef'>,
): ViviSkillRun {
  return {
    ...value,
    finishedAt: new Date().toISOString(),
    sessionId: input.sessionId,
    messageId: input.messageId,
    commandRef: input.commandRef,
    requestedBy: input.requestedBy || 'operator',
    source: input.source || 'Vivi Skill Runtime',
  };
}

function requiredGateReason(skill: ViviSkill): string | null {
  if (skill.permissions.some((permission) => [
    'external_send',
    'credentials_auth',
    'money_payment',
    'destructive_delete',
    'production_deploy',
    'remote_code_install',
  ].includes(permission))) {
    return skill.gateReason || 'Dieser Skill berührt eine geschützte Aktion und braucht Operator-Go.';
  }
  return null;
}

async function resolveYtDlpRunner(): Promise<{ runner: YtDlpRunner | null; checks: ProcessResult[] }> {
  const direct = await runProcess('yt-dlp', ['--version'], { timeoutMs: 5_000, maxOutputChars: 4_000 });
  if (direct.ok) {
    const version = lastOutputLine(direct.stdout) || 'version unknown';
    return {
      runner: {
        command: 'yt-dlp',
        argsPrefix: [],
        label: `yt-dlp ${version}`,
        version,
      },
      checks: [direct],
    };
  }

  const pythonModule = await runProcess('python3', ['-m', 'yt_dlp', '--version'], { timeoutMs: 8_000, maxOutputChars: 4_000 });
  if (pythonModule.ok) {
    const version = lastOutputLine(pythonModule.stdout) || 'version unknown';
    return {
      runner: {
        command: 'python3',
        argsPrefix: ['-m', 'yt_dlp'],
        label: `python3 -m yt_dlp ${version}`,
        version,
      },
      checks: [direct, pythonModule],
    };
  }

  return { runner: null, checks: [direct, pythonModule] };
}

async function runYtDlp(runner: YtDlpRunner, args: string[], cwd: string): Promise<ProcessResult> {
  return runProcess(runner.command, [...runner.argsPrefix, ...args], {
    cwd,
    timeoutMs: MEDIA_INGEST_TIMEOUT_MS,
    maxOutputChars: 120_000,
  });
}

async function runProcess(
  command: string,
  args: string[],
  options: { cwd?: string; timeoutMs?: number; maxOutputChars?: number } = {},
): Promise<ProcessResult> {
  const timeoutMs = options.timeoutMs ?? 30_000;
  const maxOutputChars = options.maxOutputChars ?? 80_000;

  return new Promise((resolve) => {
    let settled = false;
    let stdout = '';
    let stderr = '';
    let timedOut = false;
    const child = spawn(command, args, {
      cwd: options.cwd,
      env: process.env,
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    const timer = setTimeout(() => {
      timedOut = true;
      child.kill('SIGTERM');
    }, timeoutMs);

    function finish(result: Omit<ProcessResult, 'command' | 'args' | 'stdout' | 'stderr' | 'timedOut'>) {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve({
        ...result,
        command,
        args,
        stdout,
        stderr,
        timedOut,
      });
    }

    child.stdout?.on('data', (chunk: Buffer) => {
      stdout = appendCapped(stdout, chunk.toString('utf-8'), maxOutputChars);
    });
    child.stderr?.on('data', (chunk: Buffer) => {
      stderr = appendCapped(stderr, chunk.toString('utf-8'), maxOutputChars);
    });
    child.on('error', (error) => {
      finish({
        ok: false,
        code: null,
        signal: null,
        detail: error instanceof Error ? error.message : String(error),
      });
    });
    child.on('close', (code, signal) => {
      finish({
        ok: code === 0,
        code,
        signal,
        detail: timedOut
          ? `timeout after ${timeoutMs}ms`
          : `exit ${code ?? 'unknown'}${signal ? ` signal ${signal}` : ''}`,
      });
    });
  });
}

function extractYoutubeTarget(input: ViviSkillRunInput): YoutubeTarget | null {
  const raw = [
    stringValue(input.payload?.url),
    stringValue(input.payload?.videoId),
    input.operatorMessage || '',
  ].filter(Boolean).join('\n');
  const trimmed = raw.trim();
  if (!trimmed) return null;

  const directId = trimmed.match(/^[A-Za-z0-9_-]{11}$/)?.[0];
  if (directId) {
    return {
      videoId: directId,
      url: `https://www.youtube.com/watch?v=${directId}`,
      input: directId,
    };
  }

  const candidates = trimmed.match(/(?:https?:\/\/)?(?:www\.|m\.)?(?:youtube\.com|youtu\.be)\/[^\s<>"']+/gi) || [];
  for (const candidate of candidates) {
    const clean = candidate.replace(/[),.;\]]+$/g, '');
    const id = youtubeIdFromCandidate(clean);
    if (id) {
      return {
        videoId: id,
        url: `https://www.youtube.com/watch?v=${id}`,
        input: clean,
      };
    }
  }

  const embedded = trimmed.match(/(?:watch\?[^ \n\r\t]*v=|youtu\.be\/|shorts\/|embed\/)([A-Za-z0-9_-]{11})/i)?.[1];
  if (embedded) {
    return {
      videoId: embedded,
      url: `https://www.youtube.com/watch?v=${embedded}`,
      input: embedded,
    };
  }

  return null;
}

function youtubeIdFromCandidate(candidate: string): string | null {
  const withProtocol = candidate.startsWith('http') ? candidate : `https://${candidate}`;
  try {
    const url = new URL(withProtocol);
    const host = url.hostname.toLowerCase();
    if (host === 'youtu.be') {
      const id = url.pathname.split('/').filter(Boolean)[0] || '';
      return /^[A-Za-z0-9_-]{11}$/.test(id) ? id : null;
    }
    if (!host.endsWith('youtube.com')) return null;
    const fromQuery = url.searchParams.get('v') || '';
    if (/^[A-Za-z0-9_-]{11}$/.test(fromQuery)) return fromQuery;
    const parts = url.pathname.split('/').filter(Boolean);
    const index = parts.findIndex((part) => ['shorts', 'embed', 'live'].includes(part));
    const fromPath = index >= 0 ? parts[index + 1] || '' : '';
    return /^[A-Za-z0-9_-]{11}$/.test(fromPath) ? fromPath : null;
  } catch {
    return null;
  }
}

async function writeYoutubeMetadataArtifact(runDir: string, result: ProcessResult): Promise<string | null> {
  const output = result.stdout.trim();
  if (!output) return null;
  const filePath = path.join(runDir, 'metadata.json');
  try {
    const parsed = JSON.parse(output) as unknown;
    await fs.writeFile(filePath, `${JSON.stringify(parsed, null, 2)}\n`, 'utf-8');
  } catch {
    await fs.writeFile(filePath, output, 'utf-8');
  }
  return filePath;
}

async function readCaptionFiles(runDir: string): Promise<Array<{ filePath: string; content: string }>> {
  const names = await fs.readdir(runDir).catch(() => []);
  const captionNames = names
    .filter((name) => /\.(vtt|srt)$/i.test(name))
    .sort((left, right) => captionPriority(left) - captionPriority(right) || left.localeCompare(right));
  const files: Array<{ filePath: string; content: string }> = [];
  for (const name of captionNames) {
    const filePath = path.join(runDir, name);
    const content = await fs.readFile(filePath, 'utf-8').catch(() => '');
    if (content.trim()) files.push({ filePath, content });
  }
  return files;
}

function captionPriority(name: string): number {
  const lower = name.toLowerCase();
  if (/[._-]de([._-]|$)/.test(lower)) return 0;
  if (/[._-]en([._-]|$)/.test(lower)) return 1;
  return 2;
}

function captionToPlainText(content: string): string {
  const lines: string[] = [];
  let previous = '';
  for (const rawLine of content.split(/\r?\n/)) {
    const cleaned = decodeBasicHtmlEntities(rawLine)
      .replace(/<[^>]+>/g, '')
      .replace(/\{\\an\d+\}/g, '')
      .replace(/\s+/g, ' ')
      .trim();
    if (!cleaned) continue;
    if (/^(WEBVTT|Kind:|Language:|NOTE|STYLE|REGION)$/i.test(cleaned)) continue;
    if (/^\d+$/.test(cleaned)) continue;
    if (/-->/i.test(cleaned)) continue;
    if (cleaned === previous) continue;
    lines.push(cleaned);
    previous = cleaned;
  }
  return lines.join('\n').trim();
}

function youtubeTranscriptFile(target: YoutubeTarget, transcript: string, source: string): string {
  return [
    `Source Gate: source_available`,
    `Video ID: ${target.videoId}`,
    `URL: ${target.url}`,
    `Transcript Source: ${source}`,
    '',
    transcript.trim(),
    '',
  ].join('\n');
}

async function writeYoutubeIngestStatus(input: {
  runDir: string;
  target: YoutubeTarget;
  sourceGate: 'source_available' | 'source_blocked';
  result: string;
  detail: string;
  checks: ProcessResult[];
}): Promise<string> {
  const filePath = path.join(input.runDir, 'MEDIA_INGEST_STATUS.md');
  const body = [
    '# Vivi YouTube Media Ingest',
    '',
    `- Video ID: ${input.target.videoId}`,
    `- URL: ${input.target.url}`,
    `- Original Input: ${input.target.input}`,
    `- Source Gate: ${input.sourceGate}`,
    `- Result: ${input.result}`,
    `- Detail: ${input.detail}`,
    `- Created: ${new Date().toISOString()}`,
    '',
    '## Policy',
    '- Captions/transcript only; no video download.',
    '- No cookies, credentials or third-party transcript provider were used.',
    '- Vivi may summarize only when a transcript artifact exists.',
    '',
    input.checks.length ? '## Tool Checks' : '',
    ...input.checks.flatMap(formatProcessResult),
    '',
  ].filter((line) => line !== '').join('\n');
  await fs.writeFile(filePath, body, 'utf-8');
  return filePath;
}

function formatProcessResult(result: ProcessResult): string[] {
  return [
    `### ${result.command}`,
    `- Args: ${result.args.map(shellDisplayArg).join(' ')}`,
    `- OK: ${result.ok}`,
    `- Exit: ${result.code ?? 'null'}${result.signal ? ` (${result.signal})` : ''}`,
    `- Detail: ${result.detail}`,
    result.stdout.trim() ? `- Stdout: ${truncate(result.stdout, 800)}` : '- Stdout: empty',
    result.stderr.trim() ? `- Stderr: ${truncate(result.stderr, 1200)}` : '- Stderr: empty',
    '',
  ];
}

function shellDisplayArg(value: string): string {
  return /^[A-Za-z0-9_./:=@%+-]+$/.test(value) ? value : JSON.stringify(value);
}

async function readJsonFile<T>(filePath: string): Promise<T | null> {
  try {
    return JSON.parse(await fs.readFile(filePath, 'utf-8')) as T;
  } catch {
    return null;
  }
}

async function probeLocalEndpoint(url: string): Promise<{ ok: boolean; detail: string }> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), LOCAL_PROBE_TIMEOUT_MS);
  try {
    const response = await fetch(url, { cache: 'no-store', signal: controller.signal });
    return {
      ok: response.ok,
      detail: `${url}: HTTP ${response.status}.`,
    };
  } catch (error) {
    return {
      ok: false,
      detail: `${url}: nicht erreichbar (${error instanceof Error ? error.name : 'fetch_failed'}).`,
    };
  } finally {
    clearTimeout(timer);
  }
}

async function postJson(url: string, body: Record<string, unknown>, timeoutMs: number): Promise<{ ok: boolean; detail: string; value: unknown }> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      method: 'POST',
      cache: 'no-store',
      signal: controller.signal,
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(body),
    });
    const text = await response.text();
    let value: unknown = null;
    try {
      value = text ? JSON.parse(text) : null;
    } catch {
      value = { raw: text.slice(0, 1000) };
    }
    return {
      ok: response.ok,
      detail: `${url}: HTTP ${response.status}${response.ok ? '' : ` - ${text.slice(0, 400)}`}`,
      value,
    };
  } catch (error) {
    return {
      ok: false,
      detail: `${url}: nicht erreichbar (${error instanceof Error ? error.name : 'fetch_failed'}).`,
      value: null,
    };
  } finally {
    clearTimeout(timer);
  }
}

function extractFirstStableDiffusionImage(value: unknown): string | null {
  if (!value || typeof value !== 'object') return null;
  const images = (value as { images?: unknown }).images;
  if (!Array.isArray(images) || typeof images[0] !== 'string') return null;
  return images[0].replace(/^data:image\/\w+;base64,/, '').trim() || null;
}

async function writeTextArtifact(directory: string, prefix: string, content: string, extension: string): Promise<string> {
  await fs.mkdir(directory, { recursive: true });
  const filePath = path.join(directory, `${slugTimestamp(prefix)}.${extension}`);
  await fs.writeFile(filePath, content, 'utf-8');
  return filePath;
}

async function readLocalSkillCatalogEntries(): Promise<ViviSkillHubEntry[]> {
  const catalogPath = path.join(process.cwd(), 'data', 'vivi-skills', 'catalog.json');
  try {
    const parsed = JSON.parse(await fs.readFile(catalogPath, 'utf-8')) as unknown;
    const entries = parsed && typeof parsed === 'object' ? (parsed as { entries?: unknown }).entries : null;
    if (!Array.isArray(entries)) return [];
    return entries.map(parseHubEntry).filter((entry): entry is ViviSkillHubEntry => Boolean(entry));
  } catch {
    return [];
  }
}

function parseHubEntry(value: unknown): ViviSkillHubEntry | null {
  if (!value || typeof value !== 'object') return null;
  const record = value as Partial<ViviSkillHubEntry>;
  if (!record.id || !record.name || !record.capability) return null;
  return {
    id: String(record.id),
    name: String(record.name),
    capability: record.capability,
    source: record.source || 'local-catalog',
    status: record.status || 'proposal-ready',
    riskLevel: record.riskLevel || 'guarded',
    installMode: record.installMode || 'vega-build',
    summary: String(record.summary || ''),
    gateReason: typeof record.gateReason === 'string' ? record.gateReason : undefined,
  };
}

async function readGitHead(): Promise<string> {
  try {
    const head = (await fs.readFile(path.join(process.cwd(), '.git', 'HEAD'), 'utf-8')).trim();
    if (head.startsWith('ref:')) return head.split('/').pop() || head;
    return head.slice(0, 12);
  } catch {
    return 'unbekannt';
  }
}

async function fileExists(filePath: string): Promise<boolean> {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

function isOpenRailBlock(block: ReturnType<typeof parseRailBlocks>[number]): boolean {
  const status = String(block.fields.Status || block.fields.State || '').toLowerCase();
  return !['done', 'erledigt', 'closed', 'archived', 'parked', 'released'].some((token) => status.includes(token));
}

function skillRunMarkdown(run: ViviSkillRun): string {
  return [
    `### ${run.id}`,
    `- Added: ${run.startedAt}`,
    `- Finished: ${run.finishedAt}`,
    `- Skill Id: ${run.skillId}`,
    `- Skill Name: ${run.skillName}`,
    `- Capability: ${run.capability}`,
    `- Status: ${run.status}`,
    `- Tone: ${run.tone}`,
    `- Source: ${run.source}`,
    `- Requested By: ${run.requestedBy}`,
    run.sessionId ? `- Session Id: ${run.sessionId}` : null,
    run.messageId ? `- Message Id: ${run.messageId}` : null,
    run.commandRef ? `- Reference: ${run.commandRef}` : null,
    `- Summary: ${run.summary}`,
    `- Next Action: ${run.nextAction}`,
    '- Detail:',
    ...quoteLines(run.detail),
    run.artifacts.length ? '- Artifacts:' : null,
    ...run.artifacts.map((artifact) => `  - ${artifact.label} (${artifact.kind}): ${artifact.value}`),
    '',
  ].filter((line): line is string => Boolean(line)).join('\n');
}

function quoteLines(value: string): string[] {
  return value.split(/\r?\n/).map((line) => `  ${line}`);
}

function slugTimestamp(prefix: string, iso = new Date().toISOString()): string {
  const compact = iso.replace(/\D/g, '').slice(0, 17);
  const suffix = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `${prefix}-${compact}-${suffix}`;
}

function stringValue(value: unknown): string {
  return typeof value === 'string' ? value : '';
}

function numberPayload(input: ViviSkillRunInput, key: string, fallback: number): number {
  const value = input.payload?.[key];
  return typeof value === 'number' && Number.isFinite(value) ? value : fallback;
}

function cleanPrompt(value: string): string {
  return value
    .replace(/\b(erstelle|erzeuge|generiere|mach|male|zeichne|render)\b/gi, '')
    .replace(/\b(mir|bitte|ein|eine|einen|bild|image|foto|grafik|illustration)\b/gi, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function normalizeCapability(value: string): ViviSkillCapability {
  const capabilities: ViviSkillCapability[] = [
    'chat.direct',
    'task.queue',
    'dispatch.route',
    'memory.capture',
    'obsidian.read',
    'obsidian.write_safe',
    'lioncom.status.read',
    'repo.inspect',
    'code.patch',
    'code.test',
    'browser.inspect',
    'web.research',
    'media.transcript',
    'image.generate',
    'image.edit',
    'document.create',
    'presentation.create',
    'spreadsheet.analyze',
    'automation.schedule',
    'telegram.bridge',
    'vega.handoff',
    'skill.hub',
    'skill.propose',
    'skill.remote_dry_run',
  ];
  return capabilities.includes(value as ViviSkillCapability) ? value as ViviSkillCapability : 'skill.propose';
}

function truncate(value: string, maxLength: number): string {
  const clean = value.replace(/\s+/g, ' ').trim();
  return clean.length <= maxLength ? clean : `${clean.slice(0, maxLength - 1).trim()}…`;
}

function appendCapped(current: string, nextChunk: string, maxLength: number): string {
  const next = current + nextChunk;
  return next.length <= maxLength ? next : next.slice(next.length - maxLength);
}

function lastOutputLine(value: string): string {
  const lines = value.trim().split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  return lines[lines.length - 1] || '';
}

function decodeBasicHtmlEntities(value: string): string {
  return value
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, ' ');
}
