// Handoff Parser - Liest HANDOFF_NEXT_CHAT.md
// Nur Kerninformationen: stabil, vorbereitet, offen, Entscheidungen

import { readTextFile } from '../services/fileService';
import { PATHS } from '../constants/paths';

export interface ParsedHandoff {
  stable: string[];
  prepared: string[];
  openPoints: string[];
  decisions: string[];
  nextPhase?: string;
}

/**
 * Parst HANDOFF_NEXT_CHAT.md
 */
export async function parseHandoff(): Promise<ParsedHandoff | null> {
  const content = await readTextFile(PATHS.HANDOFF_NEXT_CHAT);
  if (!content) {
    return {
      stable: [],
      prepared: [],
      openPoints: [],
      decisions: []
    };
  }

  return {
    stable: extractTableSection(content, 'SYSTEMSTAND', 'Vorbereitet'),
    prepared: extractTableSection(content, 'Vorbereitet', 'Offen'),
    openPoints: extractListSection(content, 'Offene Baustellen', 'Architektur'),
    decisions: extractListSection(content, 'Architektur-Entscheidungen', 'Nächste'),
    nextPhase: extractNextPhase(content)
  };
}

/**
 * Extrahiert Tabellen-Zeilen aus einem Abschnitt
 */
function extractTableSection(content: string, startMarker: string, endMarker: string): string[] {
  const lines = content.split('\n');
  const items: string[] = [];
  let inSection = false;

  for (const line of lines) {
    if (line.includes(startMarker) && !line.includes('Nicht')) {
      inSection = true;
      continue;
    }

    if (inSection && (line.includes(endMarker) || line.startsWith('###'))) {
      break;
    }

    // Tabellen-Zeilen: | Name | Status |
    if (inSection && line.startsWith('|')) {
      const parts = line.split('|').map(p => p.trim()).filter(p => p);
      if (parts.length >= 2 && !parts[0].includes('Komponente')) {
        items.push(parts[0]);
      }
    }
  }

  return items.slice(0, 8);
}

/**
 * Extrahiert Listen aus einem Abschnitt
 */
function extractListSection(content: string, startMarker: string, endMarker: string): string[] {
  const lines = content.split('\n');
  const items: string[] = [];
  let inSection = false;

  for (const line of lines) {
    if (line.includes(startMarker)) {
      inSection = true;
      continue;
    }

    if (inSection && (line.includes(endMarker) || line.startsWith('###') || line.startsWith('---'))) {
      break;
    }

    // Listen-Zeilen: - Item
    if (inSection && line.startsWith('-')) {
      const item = line.replace(/^-\s*/, '').trim();
      if (item && !item.includes('---')) {
        items.push(item);
      }
    }
  }

  return items.slice(0, 6);
}

/**
 * Extrahiert nächste Phase
 */
function extractNextPhase(content: string): string | undefined {
  const lines = content.split('\n');
  
  for (const line of lines) {
    if (line.includes('Nächste Phase') || line.includes('Nächste empfohlene')) {
      // Nächste nicht-leere Zeile
      const idx = lines.indexOf(line);
      for (let i = idx + 1; i < lines.length && i < idx + 5; i++) {
        const nextLine = lines[i].trim();
        if (nextLine && !nextLine.startsWith('#') && !nextLine.startsWith('---')) {
          return nextLine.replace(/^[-\d.\s]*/, '').trim();
        }
      }
    }
  }
  
  return undefined;
}
