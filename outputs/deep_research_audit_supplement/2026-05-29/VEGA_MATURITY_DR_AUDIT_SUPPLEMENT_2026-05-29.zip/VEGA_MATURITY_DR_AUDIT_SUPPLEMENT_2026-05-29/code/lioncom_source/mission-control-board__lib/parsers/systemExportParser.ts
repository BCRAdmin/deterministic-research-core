// System Export Parser - Liest SYSTEM_EXPORT.md
// Nur Kerninformationen: produktiv, vorbereitet, offen, naechste Schritte

import { readTextFile } from '../services/fileService';
import { PATHS } from '../constants/paths';

export interface ParsedSystemExport {
  productive: string[];
  prepared: string[];
  openIssues: string[];
  nextSteps: string[];
  lastUpdated?: string;
}

/**
 * Parst SYSTEM_EXPORT.md
 */
export async function parseSystemExport(): Promise<ParsedSystemExport | null> {
  const content = await readTextFile(PATHS.SYSTEM_EXPORT);
  if (!content) {
    return {
      productive: [],
      prepared: [],
      openIssues: [],
      nextSteps: []
    };
  }

  return {
    productive: extractSection(content, 'Produktive Komponenten', 'Prototyp-Bereiche'),
    prepared: extractSection(content, 'Vorbereitete Bereiche', 'Aktuelle Baustellen'),
    openIssues: extractSection(content, 'Aktuelle Baustellen', 'Architektur'),
    nextSteps: extractSection(content, 'Nächste empfohlene Schritte', '---'),
    lastUpdated: extractDate(content)
  };
}

/**
 * Extrahiert Listen aus einem Abschnitt
 */
function extractSection(content: string, startMarker: string, endMarker: string): string[] {
  const lines = content.split('\n');
  const items: string[] = [];
  let inSection = false;

  for (const line of lines) {
    // Sektions-Start
    if (line.includes(startMarker)) {
      inSection = true;
      continue;
    }

    // Sektions-Ende
    if (inSection && (line.includes(endMarker) || line.startsWith('##'))) {
      break;
    }

    // Item-Zeilen: - Item oder | Item |
    if (inSection) {
      const match = line.match(/^[-|]\s*(.+?)(?:\s*\||\s*$)/);
      if (match) {
        const item = match[1].trim();
        if (item && !item.includes('---') && !item.toLowerCase().includes('komponente')) {
          items.push(item);
        }
      }
    }
  }

  return items.slice(0, 10); // Max 10 fuer v1
}

/**
 * Extrahiert Datum aus Header
 */
function extractDate(content: string): string | undefined {
  const match = content.match(/Datum:\*\*\s*(.+)/i);
  return match?.[1]?.trim();
}
