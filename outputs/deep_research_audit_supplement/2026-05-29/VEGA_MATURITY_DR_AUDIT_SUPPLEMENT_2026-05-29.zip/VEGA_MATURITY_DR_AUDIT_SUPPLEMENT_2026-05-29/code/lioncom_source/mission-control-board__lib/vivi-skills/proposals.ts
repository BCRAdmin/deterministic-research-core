import 'server-only';

import { promises as fs } from 'fs';
import path from 'path';

import { PATHS } from '@/lib/constants/paths';
import { appendRailBlock } from '@/lib/services/structuredRailService';
import type { ViviSkillCapability, ViviSkillProposal } from '@/lib/vivi-skills/types';

const CODEX_INBOX_HEADER = '# Codex Inbox\n\nTechnical handoffs queued for Vega / Codex.\n\n';
const MAX_PROPOSALS = 10;

export interface CreateViviSkillProposalInput {
  title?: string;
  requestedCapability: ViviSkillCapability;
  source?: string;
  operatorMessage?: string;
  reason?: string;
  targetAgent?: 'vivi' | 'vega';
  acceptanceCriteria?: string[];
}

export async function createViviSkillProposal(input: CreateViviSkillProposalInput): Promise<ViviSkillProposal> {
  const now = new Date().toISOString();
  const id = slugTimestamp('VSKILLPROP', now);
  const title = truncate(input.title || proposalTitle(input.requestedCapability, input.operatorMessage), 120);
  const targetAgent = input.targetAgent || 'vega';
  const jsonPath = path.join(PATHS.VIVI_SKILLS_PROPOSALS_DIR, `${id}.json`);
  const markdownPath = path.join(PATHS.VIVI_SKILLS_PROPOSALS_DIR, `${id}.md`);
  const handoffRef = slugTimestamp('VIVISKILL', now);

  const proposal: ViviSkillProposal = {
    id,
    createdAt: now,
    title,
    requestedCapability: input.requestedCapability,
    source: input.source || 'Vivi Skill Runtime',
    operatorMessage: truncate(input.operatorMessage || '', 1600),
    reason: input.reason || 'Vivi hat eine gewünschte Fähigkeit erkannt, die noch keinen sicheren lokalen Skill-Lauf hat.',
    safetyBoundary: [
      'Lokale Umsetzung zuerst.',
      'Keine externen Sends, Credentials, Käufe, Löschungen, Production-Deploys oder unbekannter Remote-Code ohne Operator-Go.',
      'Vega baut/verifiziert den Skill, bevor Vivi ihn autonom verwendet.',
    ].join(' '),
    targetAgent,
    acceptanceCriteria: input.acceptanceCriteria?.length ? input.acceptanceCriteria : defaultAcceptanceCriteria(input.requestedCapability),
    status: 'queued-vega',
    files: {
      json: jsonPath,
      markdown: markdownPath,
    },
    handoffRef,
  };

  await fs.mkdir(PATHS.VIVI_SKILLS_PROPOSALS_DIR, { recursive: true });
  await Promise.all([
    fs.writeFile(jsonPath, `${JSON.stringify(proposal, null, 2)}\n`, 'utf-8'),
    fs.writeFile(markdownPath, proposalMarkdown(proposal), 'utf-8'),
    fs.appendFile(PATHS.VIVI_SKILLS_PROPOSALS_JSONL, `${JSON.stringify(proposal)}\n`, 'utf-8'),
    appendRailBlock(PATHS.CODEX_INBOX, CODEX_INBOX_HEADER, `${proposalHandoffMarkdown(proposal)}\n`),
  ]);

  return proposal;
}

export async function readLatestSkillProposals(limit = MAX_PROPOSALS): Promise<ViviSkillProposal[]> {
  try {
    const content = await fs.readFile(PATHS.VIVI_SKILLS_PROPOSALS_JSONL, 'utf-8');
    return content
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean)
      .map(parseProposalLine)
      .filter((proposal): proposal is ViviSkillProposal => Boolean(proposal))
      .sort((left, right) => right.createdAt.localeCompare(left.createdAt))
      .slice(0, limit);
  } catch {
    return [];
  }
}

function parseProposalLine(line: string): ViviSkillProposal | null {
  try {
    const value = JSON.parse(line) as unknown;
    if (!value || typeof value !== 'object') return null;
    const record = value as Partial<ViviSkillProposal>;
    if (!record.id || !record.createdAt || !record.requestedCapability) return null;
    return {
      id: String(record.id),
      createdAt: String(record.createdAt),
      title: String(record.title || record.id),
      requestedCapability: record.requestedCapability,
      source: String(record.source || 'Vivi Skill Runtime'),
      operatorMessage: String(record.operatorMessage || ''),
      reason: String(record.reason || ''),
      safetyBoundary: String(record.safetyBoundary || ''),
      targetAgent: record.targetAgent === 'vivi' ? 'vivi' : 'vega',
      acceptanceCriteria: Array.isArray(record.acceptanceCriteria) ? record.acceptanceCriteria.map(String) : [],
      status: record.status || 'proposed',
      files: {
        json: String(record.files?.json || ''),
        markdown: String(record.files?.markdown || ''),
      },
      handoffRef: typeof record.handoffRef === 'string' ? record.handoffRef : undefined,
    };
  } catch {
    return null;
  }
}

function defaultAcceptanceCriteria(capability: ViviSkillCapability): string[] {
  const common = [
    'Operator sieht eine kurze deutsche Erfolgs- oder Blocker-Antwort im Vivi-Chat.',
    'Alle Artefakte liegen lokal im Runtime-Workspace und sind im Skill-Run referenziert.',
    'Verifier deckt Erfolgs-, Blocker- und Fallback-Pfad ab.',
  ];
  if (capability === 'image.generate') {
    return [
      'Lokaler Bildprovider wird erkannt und ohne Provider ehrlich als missing-provider gemeldet.',
      'Bei verfügbarem Provider entsteht ein PNG-Artefakt mit Pfad im Chat.',
      ...common,
    ];
  }
  if (capability === 'presentation.create') {
    return [
      'Vivi erzeugt einen lokalen Präsentationsentwurf oder eine klare Vega-Bauaufgabe.',
      'Keine Cloud- oder Canva-Aktion ohne Operator-Gate.',
      ...common,
    ];
  }
  if (capability === 'document.create') {
    return [
      'Vivi erzeugt lokale Markdown/DOCX-Vorlage oder schlägt eine Vega-Umsetzung vor.',
      ...common,
    ];
  }
  if (capability === 'media.transcript') {
    return [
      'YouTube-/Media-URL wird validiert und ohne Video-Download verarbeitet.',
      'Ohne Transcript-Artefakt meldet Vivi `source_blocked` statt den Inhalt zu behaupten.',
      'Transcript, Metadaten und Source-Gate-Status liegen als lokale Artefakte vor.',
      ...common,
    ];
  }
  return common;
}

function proposalTitle(capability: ViviSkillCapability, message?: string): string {
  const prefix = `Skill-Vorschlag: ${capability}`;
  const trimmed = truncate(message || '', 80);
  return trimmed ? `${prefix} - ${trimmed}` : prefix;
}

function proposalMarkdown(proposal: ViviSkillProposal): string {
  return [
    `# ${proposal.title}`,
    '',
    `- Id: ${proposal.id}`,
    `- Erstellt: ${proposal.createdAt}`,
    `- Capability: ${proposal.requestedCapability}`,
    `- Quelle: ${proposal.source}`,
    `- Ziel-Agent: ${proposal.targetAgent}`,
    `- Status: ${proposal.status}`,
    proposal.handoffRef ? `- Vega-Übergabe: ${proposal.handoffRef}` : null,
    '',
    '## Warum',
    proposal.reason,
    '',
    '## Sicherheitsgrenze',
    proposal.safetyBoundary,
    '',
    '## Operator-Nachricht',
    proposal.operatorMessage || 'Keine Operator-Nachricht übergeben.',
    '',
    '## Akzeptanzkriterien',
    ...proposal.acceptanceCriteria.map((criterion) => `- ${criterion}`),
    '',
  ].filter((line): line is string => Boolean(line)).join('\n');
}

function proposalHandoffMarkdown(proposal: ViviSkillProposal): string {
  return [
    `### ${proposal.handoffRef || proposal.id}`,
    `- Added: ${proposal.createdAt}`,
    '- Source: Vivi Skill Proposal',
    '- Status: queued',
    '- Priority: normal',
    '- Category: vivi-skill-proposal',
    '- Project Lane: lioncom-core',
    '- Target: Vega',
    `- Capability: ${proposal.requestedCapability}`,
    `- Reference: ${proposal.id}`,
    `- Title: ${proposal.title}`,
    '- Desired Outcome: Sicheren lokalen Skill bauen oder klar begründet blockieren; keine externen Sends und kein Remote-Code-Install.',
    '- Acceptance Criteria:',
    ...proposal.acceptanceCriteria.map((criterion) => `  ${criterion}`),
    '- Raw Request:',
    ...quoteLines(proposal.operatorMessage || proposal.reason),
    '',
  ].join('\n');
}

function quoteLines(value: string): string[] {
  return value.split(/\r?\n/).map((line) => `  ${line}`);
}

function slugTimestamp(prefix: string, iso = new Date().toISOString()): string {
  const compact = iso.replace(/\D/g, '').slice(0, 17);
  const suffix = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `${prefix}-${compact}-${suffix}`;
}

function truncate(value: string, maxLength: number): string {
  const clean = value.replace(/\s+/g, ' ').trim();
  return clean.length <= maxLength ? clean : `${clean.slice(0, maxLength - 1).trim()}…`;
}
