import fs from 'node:fs/promises';
import path from 'node:path';

import { PATHS, WORKSPACE_ROOT } from '@/lib/constants/paths';
import { loadControlPlaneV2Data } from '@/lib/control-plane-v2/live-data';
import { loadSystemAudit } from '@/lib/control-plane-v2/system-audit';

const PACK_DIR = path.join(WORKSPACE_ROOT, '.runtime', 'control-plane-v2-flight-pack');
const MAX_TEXT_CHARS = 9000;

function resolveControlPlaneBaseUrl(baseUrl?: string): string {
  const resolved = (baseUrl || process.env.LIONCOM_BASE_URL || 'http://127.0.0.1:4107').replace(/\/$/, '');
  try {
    const url = new URL(resolved);
    if (url.hostname === 'localhost') url.hostname = '127.0.0.1';
    return url.toString().replace(/\/$/, '');
  } catch {
    return resolved.replace('://localhost', '://127.0.0.1');
  }
}

function buildDiagnosticEndpoints(baseUrl: string) {
  return {
    controlPlaneV2: `${baseUrl}/api/control-plane-v2`,
    autonomy: `${baseUrl}/api/autonomy`,
    health: `${baseUrl}/api/health`,
    flightPack: `${baseUrl}/api/control-plane-v2/flight-pack`,
  } as const;
}

type JsonValue = string | number | boolean | null | JsonValue[] | { [key: string]: JsonValue };

export interface FlightPackFileSummary {
  path: string;
  exists: boolean;
  bytes: number;
  modifiedAt: string | null;
  tail?: string;
  json?: JsonValue;
  error?: string;
}

export interface CleanupManifestSummary {
  manifestPath: string | null;
  quarantinePath: string | null;
  updatedAt: string | null;
  totalActions: number;
  quarantined: number;
  deleted: number;
  classes: string[];
}

export interface ControlPlaneV2FlightPack {
  schemaVersion: 1;
  createdAt: string;
  createdAtBerlin: string;
  workspaceRoot: string;
  route: string;
  diagnosticEndpoints: ReturnType<typeof buildDiagnosticEndpoints>;
  status: {
    source: string;
    loopState: string;
    loopTitle: string;
    loopClaimId?: string;
    loopTaskTitle?: string;
    loopTaskReference?: string;
    qualityGateOk: boolean;
    qualityGateLabel: string;
    releaseReady: boolean;
  };
  controlPlane: Awaited<ReturnType<typeof loadControlPlaneV2Data>>;
  systemAudit: Awaited<ReturnType<typeof loadSystemAudit>>;
  cleanup: CleanupManifestSummary;
  rails: {
    localDuoLoopStatus: FlightPackFileSummary;
    viviNightWatchdog: FlightPackFileSummary;
    viviNightWatchdogWrapper: FlightPackFileSummary;
    viviNightWatchdogLaunchAgent: FlightPackFileSummary;
    viviAutonomyHealth: FlightPackFileSummary;
    viviReportQualityGate: FlightPackFileSummary;
    viviModelRoute: FlightPackFileSummary;
    autonomyState: FlightPackFileSummary;
    viviChatSessions: FlightPackFileSummary;
    viviChatArchive: FlightPackFileSummary;
    viviCommandQueue: FlightPackFileSummary;
    taskClaims: FlightPackFileSummary;
    viviReports: FlightPackFileSummary;
    goldenBaseline: FlightPackFileSummary;
  };
  files: {
    json: string;
    markdown: string;
  };
}

export async function createControlPlaneV2FlightPack(baseUrl?: string): Promise<ControlPlaneV2FlightPack> {
  const controlPlaneBaseUrl = resolveControlPlaneBaseUrl(baseUrl);
  const diagnosticEndpoints = buildDiagnosticEndpoints(controlPlaneBaseUrl);
  const [controlPlane, systemAudit, rails, cleanup] = await Promise.all([
    loadControlPlaneV2Data(),
    loadSystemAudit(),
    buildRailSummaries(),
    findLatestCleanupManifest(),
  ]);
  const createdAt = new Date().toISOString();
  const packBaseName = createdAt.replace(/[:.]/g, '-');
  const jsonPath = path.join(PACK_DIR, `${packBaseName}.json`);
  const mdPath = path.join(PACK_DIR, `${packBaseName}.md`);
  const qualityGate = controlPlane.operatorLoopStatus.qualityGate;
  const pack: ControlPlaneV2FlightPack = {
    schemaVersion: 1,
    createdAt,
    createdAtBerlin: formatBerlin(createdAt),
    workspaceRoot: WORKSPACE_ROOT,
    route: `${controlPlaneBaseUrl}/control-plane-v2`,
    diagnosticEndpoints,
    status: {
      source: controlPlane.source,
      loopState: controlPlane.operatorLoopStatus.state,
      loopTitle: controlPlane.operatorLoopStatus.title,
      loopClaimId: controlPlane.operatorLoopStatus.claimId,
      loopTaskTitle: controlPlane.operatorLoopStatus.taskTitle,
      loopTaskReference: controlPlane.operatorLoopStatus.taskReference,
      qualityGateOk: Boolean(qualityGate?.ok),
      qualityGateLabel: qualityGate?.label ?? 'Kein Gate-Status',
      releaseReady: controlPlane.source === 'live' && Boolean(qualityGate?.ok) && systemAudit.overall !== 'blocked',
    },
    controlPlane,
    systemAudit,
    cleanup,
    rails,
    files: {
      json: jsonPath,
      markdown: mdPath,
    },
  };

  await fs.mkdir(PACK_DIR, { recursive: true });
  const markdown = renderFlightPackMarkdown(pack);
  await Promise.all([
    fs.writeFile(jsonPath, `${JSON.stringify(pack, null, 2)}\n`, 'utf-8'),
    fs.writeFile(mdPath, markdown, 'utf-8'),
    fs.writeFile(path.join(PACK_DIR, 'latest.json'), `${JSON.stringify(pack, null, 2)}\n`, 'utf-8'),
    fs.writeFile(path.join(PACK_DIR, 'latest.md'), markdown, 'utf-8'),
  ]);

  return pack;
}

async function findLatestCleanupManifest(): Promise<CleanupManifestSummary> {
  const candidates = [
    path.join(process.env.HOME || '', 'Documents', 'New project', '.runtime', 'cleanup-quarantine'),
    path.join(WORKSPACE_ROOT, '.runtime', 'cleanup-quarantine'),
  ].filter(Boolean);

  const manifests: Array<{ path: string; statMtime: number }> = [];
  for (const root of candidates) {
    try {
      const entries = await fs.readdir(root, { withFileTypes: true });
      for (const entry of entries) {
        if (!entry.isDirectory()) continue;
        const manifestPath = path.join(root, entry.name, 'MANIFEST.tsv');
        try {
          const stat = await fs.stat(manifestPath);
          manifests.push({ path: manifestPath, statMtime: stat.mtimeMs });
        } catch {
          // Older cleanup folders may not have a manifest.
        }
      }
    } catch {
      // Cleanup quarantine is optional.
    }
  }

  const latest = manifests.sort((a, b) => b.statMtime - a.statMtime)[0];
  if (!latest) {
    return {
      manifestPath: null,
      quarantinePath: null,
      updatedAt: null,
      totalActions: 0,
      quarantined: 0,
      deleted: 0,
      classes: [],
    };
  }

  const raw = await fs.readFile(latest.path, 'utf-8');
  const rows = raw
    .split('\n')
    .slice(1)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => line.split('\t'));
  const classes = Array.from(new Set(rows.map((row) => row[1]).filter(Boolean))).sort();
  const stat = await fs.stat(latest.path);
  return {
    manifestPath: latest.path,
    quarantinePath: path.dirname(latest.path),
    updatedAt: stat.mtime.toISOString(),
    totalActions: rows.length,
    quarantined: rows.filter((row) => row[0] === 'quarantine').length,
    deleted: rows.filter((row) => row[0] === 'delete').length,
    classes,
  };
}

export async function readLatestControlPlaneV2FlightPack(): Promise<ControlPlaneV2FlightPack | null> {
  try {
    const raw = await fs.readFile(path.join(PACK_DIR, 'latest.json'), 'utf-8');
    return JSON.parse(raw) as ControlPlaneV2FlightPack;
  } catch {
    return null;
  }
}

async function buildRailSummaries(): Promise<ControlPlaneV2FlightPack['rails']> {
  const summaries = await Promise.all([
    summarizeFile(PATHS.LOCAL_DUO_LOOP_STATUS, 'json'),
    summarizeFile(path.join(WORKSPACE_ROOT, '.runtime', 'vivi-night-watchdog-status.json'), 'json'),
    summarizeFile(path.join(process.env.HOME || '/Users/BjornRosinger', '.lioncom/bin/run_vivi_night_watchdog.sh'), 'text'),
    summarizeFile(path.join(process.env.HOME || '/Users/BjornRosinger', 'Library/LaunchAgents/com.lioncom.vivi-night-watchdog.plist'), 'text'),
    summarizeFile(path.join(WORKSPACE_ROOT, '.runtime', 'vivi-autonomy-health.json'), 'json'),
    summarizeFile(PATHS.VIVI_REPORT_QUALITY_GATE_STATUS, 'json'),
    summarizeFile(path.join(WORKSPACE_ROOT, '.runtime', 'vivi-model-route-status.json'), 'json'),
    summarizeFile(PATHS.AUTONOMY_STATE, 'json'),
    summarizeFile(PATHS.VIVI_CHAT_SESSIONS, 'json'),
    summarizeFile(path.join(WORKSPACE_ROOT, 'VIVI_CHAT_SESSIONS_ARCHIVE.json'), 'json'),
    summarizeFile(PATHS.VIVI_COMMAND_QUEUE, 'text'),
    summarizeFile(PATHS.TASK_CLAIMS, 'text'),
    summarizeFile(PATHS.VIVI_REPORTS, 'text'),
    summarizeFile(PATHS.GOLDEN_BASELINE_STATUS, 'json'),
  ]);

  return {
    localDuoLoopStatus: summaries[0],
    viviNightWatchdog: summaries[1],
    viviNightWatchdogWrapper: summaries[2],
    viviNightWatchdogLaunchAgent: summaries[3],
    viviAutonomyHealth: summaries[4],
    viviReportQualityGate: summaries[5],
    viviModelRoute: summaries[6],
    autonomyState: summaries[7],
    viviChatSessions: summaries[8],
    viviChatArchive: summaries[9],
    viviCommandQueue: summaries[10],
    taskClaims: summaries[11],
    viviReports: summaries[12],
    goldenBaseline: summaries[13],
  };
}

async function summarizeFile(filePath: string, mode: 'json' | 'text'): Promise<FlightPackFileSummary> {
  try {
    const stat = await fs.stat(filePath);
    const raw = await fs.readFile(filePath, 'utf-8');
    const summary: FlightPackFileSummary = {
      path: filePath,
      exists: true,
      bytes: stat.size,
      modifiedAt: stat.mtime.toISOString(),
    };

    if (mode === 'json') {
      summary.json = toJsonValue(JSON.parse(raw));
    } else {
      summary.tail = raw.slice(-MAX_TEXT_CHARS);
    }

    return summary;
  } catch (error) {
    return {
      path: filePath,
      exists: false,
      bytes: 0,
      modifiedAt: null,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

function toJsonValue(value: unknown): JsonValue {
  if (value === null || typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
    return value;
  }
  if (Array.isArray(value)) {
    return value.slice(0, 80).map(toJsonValue);
  }
  if (typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>)
        .slice(0, 120)
        .map(([key, entry]) => [key, toJsonValue(entry)]),
    );
  }
  return String(value);
}

function renderFlightPackMarkdown(pack: ControlPlaneV2FlightPack): string {
  const checksGreen = pack.systemAudit.checks.filter((check) => check.severity === 'ok').length;
  const checksTotal = pack.systemAudit.checks.length;
  const activeMission = pack.controlPlane.missions[0];
  const sessions = asArray(pack.rails.viviChatSessions.json);
  const sessionCount = sessions ? sessions.length : 'unbekannt';
  const archive = asArray(pack.rails.viviChatArchive.json);
  const archiveCount = archive ? archive.length : 'unbekannt';
  const latestSession = sessions?.[0];
  const latestSessionTitle = readString(latestSession, 'title') || 'keine aktive Session erkannt';
  const latestSessionStatus = readString(latestSession, 'status') || 'unbekannt';
  const latestSessionModel = readString(latestSession, 'requestedModel') || 'nicht gesetzt';
  const nightWatchdog = pack.rails.viviNightWatchdog.json;
  const nightWatchdogOk = isObject(nightWatchdog) && nightWatchdog.ok === true;
  const nightWatchdogCheckedAt = isObject(nightWatchdog) ? readString(nightWatchdog, 'checkedAt') : null;
  const nightWatchdogMode = isObject(nightWatchdog) ? readString(nightWatchdog, 'mode') : null;
  const nightWatchdogRecommendation = isObject(nightWatchdog) ? readString(nightWatchdog, 'recommendation') : null;
  const nightWatchdogFinalHealth = isObject(nightWatchdog) && isObject(nightWatchdog.finalHealth)
    ? nightWatchdog.finalHealth
    : null;
  const nightWatchdogFinalHealthOk = Boolean(nightWatchdogFinalHealth?.ok);
  const nightWatchdogFailures = countArray(nightWatchdogFinalHealth?.failures);
  const nightWatchdogWarnings = countArray(nightWatchdogFinalHealth?.warnings);
  const autonomyHealth = pack.rails.viviAutonomyHealth.json;
  const autonomyHealthOk = isObject(autonomyHealth) && autonomyHealth.ok === true;
  const autonomyRotation = isObject(autonomyHealth) ? autonomyHealth.rotationPolicy : undefined;
  const autonomyRotationWindow = isObject(autonomyRotation) && typeof autonomyRotation.recentSlugCooldownWindow === 'number'
    ? autonomyRotation.recentSlugCooldownWindow
    : 'unbekannt';
  const recentNightSlugs = asArray(isObject(autonomyHealth) ? autonomyHealth.recentNightSlugs : undefined)
    ?.map((entry) => String(entry))
    .filter(Boolean)
    .join(', ') || 'nicht verfuegbar';
  const repeatedSlugRecord = isObject(autonomyHealth) ? autonomyHealth.repeatedSlugs : undefined;
  const repeatedSlugs = isObject(repeatedSlugRecord)
    ? Object.entries(repeatedSlugRecord)
        .filter(([, count]) => typeof count === 'number' && count > 0)
        .map(([slug, count]) => `${slug} (${count})`)
    : [];
  const productiveRefill = isObject(autonomyHealth) ? autonomyHealth.productiveRefill : undefined;
  const productiveRefillEligible = isObject(productiveRefill) && productiveRefill.eligible === true;
  const productiveRefillCatalog = asArray(isObject(productiveRefill) ? productiveRefill.catalogSlugs : undefined)
    ?.map((entry) => String(entry))
    .filter(Boolean)
    .join(', ') || 'nicht verfuegbar';
  const productiveRecent = asArray(isObject(productiveRefill) ? productiveRefill.recentProductiveSlugs : undefined)
    ?.map((entry) => String(entry))
    .filter(Boolean)
    .join(', ') || 'keine';
  const hardeningCoverage = asArray(isObject(productiveRefill) ? productiveRefill.distinctHardeningSlugs : undefined)
    ?.map((entry) => String(entry))
    .filter(Boolean)
    .join(', ') || 'nicht verfuegbar';
  const modelRoute = pack.rails.viviModelRoute.json;
  const effectiveModel = isObject(modelRoute) && isObject(modelRoute.effective)
    ? [readString(modelRoute.effective, 'provider'), readString(modelRoute.effective, 'model')].filter(Boolean).join('/')
    : 'nicht bestaetigt';
  const includedRails: Array<[string, FlightPackFileSummary]> = [
    ['Lokaler Duo-Loop', pack.rails.localDuoLoopStatus],
    ['Nachtlauf-Watchdog', pack.rails.viviNightWatchdog],
    ['Nachtlauf-Watchdog Wrapper', pack.rails.viviNightWatchdogWrapper],
    ['Nachtlauf-Watchdog LaunchAgent', pack.rails.viviNightWatchdogLaunchAgent],
    ['Autonomie-Health', pack.rails.viviAutonomyHealth],
    ['Report-Quality-Gate', pack.rails.viviReportQualityGate],
    ['Modellroute', pack.rails.viviModelRoute],
    ['Autonomie-State', pack.rails.autonomyState],
    ['Vivi Sessions', pack.rails.viviChatSessions],
    ['Vivi Session-Archiv', pack.rails.viviChatArchive],
    ['Vivi Command Queue', pack.rails.viviCommandQueue],
    ['Task Claims', pack.rails.taskClaims],
    ['Vivi Reports', pack.rails.viviReports],
    ['Golden Baseline', pack.rails.goldenBaseline],
  ];
  const cleanupClasses = pack.cleanup.classes.length > 0
    ? pack.cleanup.classes.join(', ')
    : 'keine Cleanup-Klassen im letzten Manifest';

  return [
    '# LIONCOM Control Plane V2 Flight Pack',
    '',
    `- Erstellt: ${pack.createdAt} / ${pack.createdAtBerlin}`,
    `- Route: ${pack.route}`,
    `- Workspace: ${pack.workspaceRoot}`,
    `- Quelle: ${pack.status.source}`,
    `- Vivi Loop: ${pack.status.loopState} / ${pack.status.loopTitle}`,
    `- Aktive Claim: ${pack.status.loopClaimId || 'keine aktive Claim'}`,
    `- Aktiver Auftrag: ${pack.status.loopTaskTitle || 'kein aktiver Auftrag'}`,
    `- Command Ref: ${pack.status.loopTaskReference || 'keine aktive Referenz'}`,
    `- Quality Gate: ${pack.status.qualityGateOk ? 'frei' : 'blockiert'} (${pack.status.qualityGateLabel})`,
    `- Release Ready: ${pack.status.releaseReady ? 'ja' : 'nein'}`,
    `- Nachtlauf-Watchdog: ${nightWatchdogOk ? 'gruen' : 'nicht gruen/noch nicht gelaufen'}`,
    `- Autonomie-Health: ${autonomyHealthOk ? 'gruen' : 'nicht gruen/noch nicht gelaufen'}`,
    `- Systemaudit: ${pack.systemAudit.overall}, ${checksGreen}/${checksTotal} Checks gruen`,
    `- Vivi Sessions: ${sessionCount} aktiv sichtbar, ${archiveCount} archiviert`,
    '',
    '## Aktive Lage',
    '',
    activeMission
      ? `- ${activeMission.id}: ${activeMission.title} (${activeMission.status}, ${activeMission.progress}%)`
      : '- Keine Mission im Snapshot sichtbar.',
    `- Queue: ${pack.controlPlane.globalStatus.queueDepth}`,
    `- Bridge: ${pack.controlPlane.globalStatus.bridgeStatus}`,
    `- Letztes Signal: ${pack.controlPlane.globalStatus.lastSignal}`,
    '',
    '## Vivi Lokal Arbeiten',
    '',
    `- Aktuelle Session: ${latestSessionTitle} (${latestSessionStatus})`,
    `- Angefragtes Vivi-Modell: ${latestSessionModel}`,
    `- Laufender Loop: ${pack.status.loopTitle}`,
    `- Laufende Claim: ${pack.status.loopClaimId || 'keine aktive Claim'}`,
    `- Laufende Referenz: ${pack.status.loopTaskReference || 'keine aktive Referenz'}`,
    `- Neue Vivi-Session: in der V2-Vivi-Ansicht ueber den Session-Dialog anlegen; die Daten landen lokal in ${pack.rails.viviChatSessions.path}.`,
    `- Alte Sessions entfernen/archivieren: ueber die V2-Session-Aktionen; Archiv liegt lokal in ${pack.rails.viviChatArchive.path}.`,
    '- Autostart-Kontext: neue Operator-Nachrichten erzeugen ein Command-Ref und werden in die Vivi-Queue geschrieben, damit Vivi nicht erst manuell gesagt bekommen muss, welche Rails zu lesen sind.',
    '',
    '## Autonomie-Rotation',
    '',
    `- Refill-Rotation: ${autonomyHealthOk ? 'gruen' : 'nicht gruen'}; Cooldown-Fenster: letzte ${autonomyRotationWindow} Night-Run-Slugs.`,
    `- Letzte Night-Run-Slugs: ${recentNightSlugs}`,
    repeatedSlugs.length > 0
      ? `- Wiederholte Slugs im Fenster: ${repeatedSlugs.join(', ')}`
      : '- Wiederholte Slugs im Fenster: keine.',
    `- Effektive Vivi-Modellroute: ${effectiveModel}`,
    `- Watchdog-Status: ${nightWatchdogOk ? 'bereit' : 'nicht bestaetigt'}`,
    '- Bedeutung: Wenn Vivi keine echte Operator-Arbeit findet, rotiert sie durch sinnvolle V2-/Nachtrun-Pruefungen statt denselben Sweep sofort zu wiederholen.',
    '',
    '## Watchdog Betriebsstatus',
    '',
    `- Letzter Watchdog-Lauf: ${nightWatchdogOk ? 'gruen' : 'nicht gruen/noch nicht bestaetigt'} (${nightWatchdogMode || 'Modus unbekannt'})`,
    `- Geprueft: ${nightWatchdogCheckedAt ? formatBerlin(nightWatchdogCheckedAt) : 'kein Zeitstempel'}`,
    `- Final Health: ${nightWatchdogFinalHealthOk ? 'gruen' : 'nicht gruen/fehlt'}; Failures: ${nightWatchdogFailures}; Warnungen: ${nightWatchdogWarnings}`,
    `- Empfehlung: ${nightWatchdogRecommendation || 'keine Empfehlung im Statusfile'}`,
    `- Statusartefakt: ${pack.rails.viviNightWatchdog.path}`,
    '- Bedeutung: Der Watchdog darf nicht nur installiert sein; er muss einen aktuellen gruenen Reparaturstatus schreiben, sonst gilt der Nachtlauf nicht als belastbar.',
    '',
    '## Watchdog Installation',
    '',
    `- Wrapper: ${pack.rails.viviNightWatchdogWrapper.path}`,
    `- Wrapper-Status: ${pack.rails.viviNightWatchdogWrapper.exists ? 'enthalten' : 'fehlt'}`,
    `- LaunchAgent: ${pack.rails.viviNightWatchdogLaunchAgent.path}`,
    `- LaunchAgent-Status: ${pack.rails.viviNightWatchdogLaunchAgent.exists ? 'enthalten' : 'fehlt'}`,
    '- StartInterval: 300 Sekunden',
    '- Ausfuehrung: mission-control-board/scripts/run_vivi_night_watchdog.mjs --repair',
    '- Bedeutung: Der Flight-Pack dokumentiert die installierte Watchdog-Schicht, damit Offline- oder Reisebetrieb nicht nur Source-Code, sondern auch die wirklich aktive macOS-Automation pruefen kann.',
    '',
    '## Produktiver Refill',
    '',
    `- Status: ${productiveRefillEligible ? 'aktivierbar' : 'noch an Hardening gekoppelt'}`,
    `- Hardening-Abdeckung: ${hardeningCoverage}`,
    `- Letzte produktive Refill-Slugs: ${productiveRecent}`,
    `- Produktive Refill-Kandidaten: ${productiveRefillCatalog}`,
    '- Bedeutung: Wenn V2 stabil ist und Vivi keine echte offene Arbeit findet, erzeugt der Refill lokale V2-Produktarbeit wie Workflow-Rehearsal, Backlog-Synthese, Roadmap-Scan oder Operations-Playbook statt Leerlauf.',
    '',
    '## Retention und Cleanup',
    '',
    `- Letztes Manifest: ${pack.cleanup.manifestPath || 'kein Cleanup-Manifest gefunden'}`,
    `- Quarantaene: ${pack.cleanup.quarantinePath || 'keine Quarantaene gefunden'}`,
    `- Aktualisiert: ${pack.cleanup.updatedAt ? formatBerlin(pack.cleanup.updatedAt) : 'n/a'}`,
    `- Aktionen: ${pack.cleanup.totalActions} gesamt, ${pack.cleanup.quarantined} quarantänisiert, ${pack.cleanup.deleted} geloescht.`,
    `- Klassen: ${cleanupClasses}`,
    '- Bedeutung: Build-/Dependency-/Tmp-Dirt darf entfernt werden, aber Rails, Reports, Memory, Credentials und aktuelle Runtime-Wahrheit bleiben geschuetzt.',
    '',
    '## Offline-Kurzablauf',
    '',
    `1. LIONCOM lokal starten oder offen lassen und diese Route nutzen: ${pack.route}`,
    `2. Wenn Vivi nicht arbeitet: POST ${pack.route.replace(/\/control-plane-v2$/, '/api/control-plane-v2/vivi-loop/start')} ausloesen oder in V2 "Vivi starten" klicken.`,
    '3. Vor laengerem Offline-Arbeiten Flight-Pack neu erzeugen: npm run control-plane-v2:flight-pack',
    '4. Bei Warnlage zuerst Quality Gate, aktive Claim und Session-Status im Pack pruefen; keine externen Sends, Credentials, Geld oder Production-Gates offline freigeben.',
    '',
    '## Lokale Diagnose-Endpunkte',
    '',
    `- Control Plane V2: ${pack.diagnosticEndpoints.controlPlaneV2}`,
    `- Autonomie und Claims: ${pack.diagnosticEndpoints.autonomy}`,
    `- Health: ${pack.diagnosticEndpoints.health}`,
    `- Flight-Pack API: ${pack.diagnosticEndpoints.flightPack}`,
    '- Bedeutung: Diese Endpunkte sind lokale Nur-Lesen-/Diagnosepfade fuer Operatoren und Verifier. Sie ersetzen keine externen Sends, Deploys oder Credential-Aktionen.',
    '',
    '## Enthaltene lokale Rails',
    '',
    '| Rail | Status | Groesse | Geaendert | Pfad |',
    '| --- | --- | ---: | --- | --- |',
    ...includedRails.map(([label, file]) => renderRailRow(label, file)),
    '',
    '## Naechste Operator-Aktionen',
    '',
    ...pack.systemAudit.nextActions.slice(0, 8).map((action) => `- ${action}`),
    '',
    '## Dateien',
    '',
    `- JSON: ${pack.files.json}`,
    `- Markdown: ${pack.files.markdown}`,
    '',
  ].join('\n');
}

function renderRailRow(label: string, file: FlightPackFileSummary): string {
  const status = file.exists ? 'enthalten' : 'fehlt';
  const modified = file.modifiedAt ? formatBerlin(file.modifiedAt) : 'n/a';
  return `| ${escapeTable(label)} | ${status} | ${file.bytes} | ${escapeTable(modified)} | ${escapeTable(file.path)} |`;
}

function escapeTable(value: string): string {
  return value.replace(/\|/g, '\\|').replace(/\n/g, ' ');
}

function asArray(value: JsonValue | undefined): JsonValue[] | null {
  return Array.isArray(value) ? value : null;
}

function countArray(value: JsonValue | undefined): number {
  return Array.isArray(value) ? value.length : 0;
}

function readString(value: JsonValue | undefined, key: string): string | null {
  if (!isObject(value)) return null;
  const entry = value[key];
  return typeof entry === 'string' && entry.trim() ? entry : null;
}

function isObject(value: JsonValue | undefined): value is { [key: string]: JsonValue } {
  return Boolean(value && typeof value === 'object' && !Array.isArray(value));
}

function formatBerlin(iso: string): string {
  return new Intl.DateTimeFormat('de-DE', {
    dateStyle: 'medium',
    timeStyle: 'medium',
    timeZone: 'Europe/Berlin',
  }).format(new Date(iso));
}
