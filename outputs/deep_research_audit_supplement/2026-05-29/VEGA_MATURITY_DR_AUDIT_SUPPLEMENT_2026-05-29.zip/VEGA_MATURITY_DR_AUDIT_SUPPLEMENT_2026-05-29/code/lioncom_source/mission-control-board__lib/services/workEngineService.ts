import { promises as fs } from 'fs';

import { PATHS } from '../constants/paths';
import type { RemoteBridgeStatus } from './bridgeStatusService';
import type { GitHubSyncSnapshot } from './githubSyncService';
import { analyzeOperatorIntent, type OperatorIntentAnalysis, type OperatorIntentKind, type OperatorMode, type OperatorProjectFit, type OperatorResearchMode } from './operatorIntentService';
import { parseRailBlocks, readRailContent } from './structuredRailService';
import type { ViviRuntimeSnapshot, ViviStateSnapshot } from './viviBridgeService';

export type WorkLane = 'builder' | 'research' | 'repair' | 'bridge';
export type WorkStage = 'INTAKE' | 'ANALYZE' | 'PLAN' | 'EXECUTE' | 'VERIFY' | 'REPORT' | 'FREEZE' | 'RECOVER' | 'DONE';

export interface WorkEngineBlock {
  id: string;
  addedAt?: string;
  sourceRail: 'work-intake' | 'brain-dump' | 'repair-queue';
  sourceActor?: string;
  title: string;
  summary: string;
  desiredOutcome?: string;
  priority: 'critical' | 'high' | 'normal' | 'explore';
  lane: WorkLane;
  stage: WorkStage;
  owner: 'vivi' | 'codex' | 'shared';
  active: boolean;
  requiresCodex: boolean;
  requiresOperator: boolean;
  intent: OperatorIntentKind;
  projectFit: OperatorProjectFit;
  researchMode: OperatorResearchMode;
  operatorMode: OperatorMode;
  interpretationHint: string;
  researchPrompt?: string;
  reference?: string;
  duplicateCount?: number;
  mergedRails?: WorkEngineBlock['sourceRail'][];
  overallScore?: number;
}

export interface WorkEngineSubtask {
  id: string;
  blockId: string;
  lane: WorkLane;
  owner: 'vivi' | 'codex' | 'shared';
  status: 'done' | 'active' | 'queued';
  title: string;
  detail: string;
}

export interface WorkEngineDecision {
  id: string;
  blockId?: string;
  title: string;
  reason: string;
  recommendation: string;
  status: 'open' | 'watching';
}

export interface WorkEngineResearchItem {
  id: string;
  blockId: string;
  title: string;
  reason: string;
  projectFit: OperatorProjectFit;
  researchMode: OperatorResearchMode;
  brief: string;
  nextAction: string;
  status: 'queued' | 'active' | 'watching';
}

export interface WorkEngineRoadmapItem {
  id: string;
  title: string;
  owner: 'vivi' | 'codex' | 'shared';
  lane: WorkLane;
  stage: WorkStage;
  priority: WorkEngineBlock['priority'];
  actionWindow: 'now' | 'next' | 'later';
  overallScore: number;
  importance: number;
  expectedOutcome: number;
  downstreamLeverage: number;
  rationale: string;
}

export interface WorkEngineRoadmap {
  focus: string;
  summary: string[];
  now: WorkEngineRoadmapItem[];
  next: WorkEngineRoadmapItem[];
  later: WorkEngineRoadmapItem[];
}

type RoadmapContext = {
  remoteBridge: Pick<RemoteBridgeStatus, 'state' | 'expectedMode' | 'detail' | 'allowLocalFallback' | 'source'>;
  githubSync: Pick<GitHubSyncSnapshot, 'state' | 'pushReady' | 'detail' | 'remoteConfigured'>;
  viviState: ViviStateSnapshot | null;
};

interface LocalDuoLoopStatus {
  updatedAt?: string;
  state?: string;
  detail?: string;
  lastExitCode?: number;
}

export interface WorkEngineStateSnapshot {
  schemaVersion: '1.0';
  updatedAt: string;
  blocks: WorkEngineBlock[];
  subtasks: WorkEngineSubtask[];
  researchQueue: WorkEngineResearchItem[];
  decisions: WorkEngineDecision[];
  roadmap: WorkEngineRoadmap;
  freeze: {
    state: 'clear' | 'watching' | 'frozen';
    reason: string;
    requiredAction: string;
  };
  remoteBridge: RemoteBridgeStatus;
  github: Pick<GitHubSyncSnapshot, 'state' | 'pushReady' | 'detail' | 'remoteConfigured' | 'remoteUrl' | 'authLastChecked'>;
}

export async function syncWorkEngineState(input: {
  viviRuntime: ViviRuntimeSnapshot | null;
  viviState: ViviStateSnapshot | null;
  remoteBridge: RemoteBridgeStatus;
  githubSync: GitHubSyncSnapshot;
}): Promise<WorkEngineStateSnapshot> {
  const [workIntakeContent, brainDumpContent, repairQueueContent, localDuoLoop] = await Promise.all([
    readRailContent(PATHS.WORK_INTAKE),
    readRailContent(PATHS.BRAIN_DUMP),
    readRailContent(PATHS.REPAIR_QUEUE),
    safeJson<LocalDuoLoopStatus>(PATHS.LOCAL_DUO_LOOP_STATUS),
  ]);

  const workBlocks = parseRailBlocks(workIntakeContent).map((block) => createBlockFromRail(block, 'work-intake'));
  const brainBlocks = parseRailBlocks(brainDumpContent)
    .filter((block) => normalizeField(block.fields['Status']) === 'raw')
    .slice(0, 4)
    .map((block) => createBlockFromRail(block, 'brain-dump'));
  const repairBlocks = parseRailBlocks(repairQueueContent)
    .map((block) => createBlockFromRail(block, 'repair-queue'))
    .filter((block) => !shouldSuppressVisibilityRepairBlock(block, input.remoteBridge, localDuoLoop));

  const blocks = prioritizeVisibleBlocks(
    dedupeBlocks([...workBlocks, ...brainBlocks, ...repairBlocks])
      .filter((block) => !shouldSuppressVisibilityRepairBlock(block, input.remoteBridge, localDuoLoop))
      .filter((block) => !isHistoricalValidationArtifact(block)),
  ).slice(0, 24);
  const subtasks = blocks.flatMap((block) => buildSubtasks(block));
  const researchQueue = blocks
    .filter((block) => !['REPORT', 'DONE', 'FREEZE'].includes(block.stage))
    .filter((block) => block.lane === 'research' || block.priority === 'explore' || block.researchMode !== 'none')
    .slice(0, 12)
    .map((block) => ({
      id: `${block.id}-R1`,
      blockId: block.id,
      title: block.title,
      reason: block.summary,
      projectFit: block.projectFit,
      researchMode: block.researchMode,
      brief: block.researchPrompt || block.interpretationHint,
      nextAction: block.projectFit === 'new-track'
        ? 'Clarify whether this becomes a new mission, backlog track or stays research-only.'
        : block.researchMode === 'primary'
          ? 'Extract questions, assumptions, risks and a recommended next move.'
          : 'Run a short evidence pass so Vivi can continue with a cleaner execution picture.',
      status: block.stage === 'EXECUTE' ? 'active' : block.stage === 'FREEZE' ? 'watching' : 'queued',
    } satisfies WorkEngineResearchItem));

  const decisions: WorkEngineDecision[] = [];
  for (const block of blocks) {
    if (!block.desiredOutcome || block.requiresOperator || block.stage === 'FREEZE') {
      decisions.push({
        id: `${block.id}-D1`,
        blockId: block.id,
        title: block.title,
        reason: !block.desiredOutcome
          ? 'Desired outcome is missing or underspecified.'
          : block.stage === 'FREEZE'
            ? 'This block is frozen and requires a deliberate operator choice.'
            : 'This block has elevated risk or missing certainty and should not advance silently.',
        recommendation: block.requiresCodex
          ? 'In Codex prüfen und die Mission danach aus dem Board heraus freigeben oder neu zuschneiden.'
          : 'Confirm the intended outcome or let Vivi continue with the current safe interpretation.',
        status: block.stage === 'FREEZE' ? 'open' : 'watching',
      });
    }
  }

  if (input.remoteBridge.state !== 'live-remote' && input.remoteBridge.expectedMode !== 'local') {
    decisions.push({
      id: 'BRIDGE-REMOTE-DECISION',
      title: 'Remote Vivi bridge is not live yet',
      reason: input.remoteBridge.detail,
      recommendation: 'Keep local fallback operational, but do not treat the VPS view as authoritative until a fresh remote heartbeat lands.',
      status: input.remoteBridge.state === 'stale-remote' ? 'open' : 'watching',
    });
  }

  if (input.githubSync.state === 'blocked') {
    decisions.push({
      id: 'GITHUB-AUTH-DECISION',
      title: 'GitHub sync is blocked',
      reason: input.githubSync.detail,
      recommendation: 'Keep working locally and preserve freeze integrity, but repair write auth before relying on GitHub collaboration.',
      status: 'open',
    });
  }

  const roadmap = buildRoadmap(blocks, {
    remoteBridge: input.remoteBridge,
    githubSync: input.githubSync,
    viviState: input.viviState,
  });

  const freeze = deriveFreezeState({ blocks, viviState: input.viviState, remoteBridge: input.remoteBridge, githubSync: input.githubSync });

  const snapshot: WorkEngineStateSnapshot = {
    schemaVersion: '1.0',
    updatedAt: new Date().toISOString(),
    blocks,
    subtasks,
    researchQueue,
    decisions: decisions.slice(0, 12),
    roadmap,
    freeze,
    remoteBridge: input.remoteBridge,
    github: {
      state: input.githubSync.state,
      pushReady: input.githubSync.pushReady,
      detail: input.githubSync.detail,
      remoteConfigured: input.githubSync.remoteConfigured,
      remoteUrl: input.githubSync.remoteUrl,
      authLastChecked: input.githubSync.authLastChecked,
    },
  };

  await Promise.all([
    fs.writeFile(PATHS.WORK_ENGINE_STATE, JSON.stringify(snapshot, null, 2) + '\n', 'utf-8'),
    fs.writeFile(PATHS.WORK_BLOCKS, renderWorkBlocks(blocks), 'utf-8'),
    fs.writeFile(PATHS.SUBTASK_QUEUE, renderSubtasks(subtasks), 'utf-8'),
    fs.writeFile(PATHS.RESEARCH_QUEUE, renderResearchQueue(researchQueue), 'utf-8'),
    fs.writeFile(PATHS.DECISION_QUEUE, renderDecisionQueue(snapshot.decisions), 'utf-8'),
    fs.writeFile(PATHS.EXECUTION_PLAN, renderExecutionPlan(snapshot.roadmap), 'utf-8'),
    fs.writeFile(PATHS.MISSION_PRIORITY_BOARD, renderMissionPriorityBoard(snapshot.roadmap, blocks), 'utf-8'),
    fs.writeFile(PATHS.FREEZE_LOG, renderFreezeLog(snapshot.freeze), 'utf-8'),
    ensureFreezePolicy(),
  ]);

  return snapshot;
}

function createBlockFromRail(
  block: ReturnType<typeof parseRailBlocks>[number],
  sourceRail: WorkEngineBlock['sourceRail'],
): WorkEngineBlock {
  const title = block.fields['Title'] || block.fields['Summary'] || block.id;
  const summary = block.fields['Summary'] || title;
  const rawText = extractQuotedBody(block.lines);
  const analysis = analyzeOperatorIntent({
    sourceRail,
    title,
    summary,
    rawText,
    context: `${block.fields['Context'] || ''} ${block.fields['Recommendation'] || ''}`.trim(),
    desiredOutcome: block.fields['Desired Outcome'],
    priority: block.fields['Priority'] || block.fields['Urgency'] || block.fields['Severity'],
  });
  const priority = inferPriority(block.fields['Priority'] || block.fields['Urgency'] || block.fields['Severity'], analysis);
  const combined = `${title} ${summary} ${rawText} ${block.fields['Context'] || ''} ${block.fields['Recommendation'] || ''}`.toLowerCase();
  const lane = inferLane(sourceRail, combined, priority, analysis);
  const stage = inferStage(block.fields['Status']);
  const requiresCodex = analysis.requiresCodex
    || /codex|debug|typescript|next\.|electron|github|architecture|refactor|migration|schema|auth|credential|token|ssh|dns|ci|pipeline|desktop build/.test(combined)
    || sourceRail === 'repair-queue';
  const requiresOperator = /approve|approval|decision|operator confirmation|human decision|needs operator|credentials?|token|login|payment|billing|dns|ssh key|manual step|external access/.test(combined) || stage === 'FREEZE';
  const owner: WorkEngineBlock['owner'] = requiresCodex && lane !== 'research'
    ? sourceRail === 'repair-queue' ? 'shared' : 'codex'
    : lane === 'research'
      ? 'vivi'
      : requiresOperator
        ? 'shared'
        : 'vivi';

  return {
    id: block.id,
    addedAt: block.fields['Added'],
    sourceRail,
    sourceActor: block.fields['Source'],
    title,
    summary,
    desiredOutcome: block.fields['Desired Outcome'],
    priority,
    lane,
    stage,
    owner,
    active: ['ANALYZE', 'PLAN', 'EXECUTE', 'VERIFY', 'RECOVER'].includes(stage),
    requiresCodex,
    requiresOperator,
    intent: analysis.intent,
    projectFit: analysis.projectFit,
    researchMode: analysis.researchMode,
    operatorMode: analysis.operatorMode,
    interpretationHint: block.fields['Interpretation Hint'] || analysis.interpretationHint,
    researchPrompt: block.fields['Research Prompt'] || analysis.researchPrompt,
    reference: block.fields['Reference'],
  };
}

function buildSubtasks(block: WorkEngineBlock): WorkEngineSubtask[] {
  const templates = block.lane === 'repair'
    ? [
        ['Diagnose failure surface', 'Inspect the affected runtime, rail or visibility break and confirm the real fault.'],
        ['Stabilize degraded path', 'Restore safe operation before resuming normal execution.'],
        ['Verify repair and publish report', 'Confirm the repair outcome and write an explicit result.'],
      ]
    : block.lane === 'research'
      ? [
          ['Interpret intent and extract questions', 'Turn the raw request into answerable questions and assumptions.'],
          ['Run evidence pass', 'Collect findings, contradictions and risk notes before committing to execution.'],
          ['Prepare recommendation and handoff', 'Summarize the research result in a form Vivi or Codex can execute safely.'],
        ]
      : block.owner === 'codex'
        ? [
            ['Acknowledge command packet', 'Claim the board-side Codex packet and preserve its reference.'],
            ['Perform technical implementation or diagnosis', 'Work the code, debug path or architecture decision.'],
            ['Return result to board', 'Write a clear report so Vivi can continue or the operator can review.'],
          ]
        : [
            ['Interpret and structure mission', 'Convert the raw mission into an explicit objective, constraints and expected result.'],
            ['Execute the current work block', 'Advance the main implementation, integration or builder task.'],
            ['Verify and report', 'Check the result and publish the next safe action.'],
          ];

  const stageIndex = stageProgressIndex(block.stage);

  return templates.map(([title, detail], index) => ({
    id: `${block.id}-S${index + 1}`,
    blockId: block.id,
    lane: block.lane,
    owner: block.owner,
    status: index < stageIndex ? 'done' : index === stageIndex ? 'active' : 'queued',
    title,
    detail,
  }));
}

function deriveFreezeState(input: {
  blocks: WorkEngineBlock[];
  viviState: ViviStateSnapshot | null;
  remoteBridge: RemoteBridgeStatus;
  githubSync: GitHubSyncSnapshot;
}): WorkEngineStateSnapshot['freeze'] {
  if (input.viviState?.currentState === 'FREEZE') {
    return {
      state: 'frozen',
      reason: input.viviState.transitionReason || 'Vivi explicitly entered FREEZE.',
      requiredAction: input.viviState.nextAction || 'Operator or Codex must review the frozen state before execution continues.',
    };
  }

  if (input.githubSync.state === 'blocked' || input.remoteBridge.state === 'stale-remote') {
    return {
      state: 'watching',
      reason: input.githubSync.state === 'blocked'
        ? input.githubSync.detail
        : input.remoteBridge.detail,
      requiredAction: input.githubSync.state === 'blocked'
        ? 'Keep freeze-quality local history intact until GitHub sync is repaired.'
        : 'Repair or confirm the remote bridge before treating the VPS picture as authoritative.',
    };
  }

  if (input.blocks.some((block) => block.stage === 'FREEZE')) {
    return {
      state: 'watching',
      reason: 'At least one work block is frozen or awaiting explicit operator review.',
      requiredAction: 'Review the frozen work block in Builder/Research before continuing.',
    };
  }

  return {
    state: 'clear',
    reason: 'No explicit freeze condition is active.',
    requiredAction: 'Continue normal operation and keep reports explicit.',
  };
}

async function ensureFreezePolicy(): Promise<void> {
  try {
    await fs.access(PATHS.FREEZE_POLICY);
  } catch {
    await fs.writeFile(
      PATHS.FREEZE_POLICY,
      '# Freeze Policy\n\n- Freeze when Vivi cannot verify the result honestly.\n- Freeze when remote runtime visibility becomes untrustworthy.\n- Freeze when GitHub sync or local safety rails are too broken to preserve trustworthy history.\n- Do not silently continue after a freeze.\n- Every freeze must name the reason and the required operator or Codex action.\n',
      'utf-8',
    );
  }
}

async function safeJson<T>(filePath: string): Promise<T | null> {
  try {
    return JSON.parse(await fs.readFile(filePath, 'utf-8')) as T;
  } catch {
    return null;
  }
}

function renderWorkBlocks(blocks: WorkEngineBlock[]): string {
  const header = '# Work Blocks\n\nGenerated operating blocks derived from raw intake, repair packets and direct mission queues.\n\n';
  if (blocks.length === 0) return header;

  return `${header}${blocks.map((block) => [
    `### ${block.id}`,
    `- Source Rail: ${block.sourceRail}`,
    `- Title: ${block.title}`,
    `- Priority: ${block.priority}`,
    `- Lane: ${block.lane}`,
    `- Stage: ${block.stage}`,
    `- Owner: ${block.owner}`,
    `- Intent: ${block.intent}`,
    `- Project Fit: ${block.projectFit}`,
    `- Research Mode: ${block.researchMode}`,
    `- Operator Mode: ${block.operatorMode}`,
    `- Requires Codex: ${block.requiresCodex ? 'yes' : 'no'}`,
    `- Requires Operator: ${block.requiresOperator ? 'yes' : 'no'}`,
    block.duplicateCount && block.duplicateCount > 1 ? `- Duplicate Count: ${block.duplicateCount}` : null,
    block.mergedRails?.length ? `- Merged Rails: ${block.mergedRails.join(', ')}` : null,
    typeof block.overallScore === 'number' ? `- Overall Score: ${block.overallScore.toFixed(1)}` : null,
    `- Desired Outcome: ${block.desiredOutcome || 'not specified yet'}`,
    `- Interpretation Hint: ${block.interpretationHint}`,
    block.researchPrompt ? `- Research Prompt: ${block.researchPrompt}` : null,
    `- Summary: ${block.summary}`,
    block.reference ? `- Reference: ${block.reference}` : null,
    '',
  ].filter(Boolean).join('\n')).join('\n')}`;
}

function renderSubtasks(subtasks: WorkEngineSubtask[]): string {
  const header = '# Subtask Queue\n\nGenerated subtasks for Vivi and Codex execution.\n\n';
  if (subtasks.length === 0) return header;

  return `${header}${subtasks.map((subtask) => [
    `### ${subtask.id}`,
    `- Block ID: ${subtask.blockId}`,
    `- Lane: ${subtask.lane}`,
    `- Owner: ${subtask.owner}`,
    `- Status: ${subtask.status}`,
    `- Title: ${subtask.title}`,
    `- Detail: ${subtask.detail}`,
    '',
  ].join('\n')).join('\n')}`;
}

function renderResearchQueue(items: WorkEngineResearchItem[]): string {
  const header = '# Research Queue\n\nGenerated research questions and evidence passes.\n\n';
  if (items.length === 0) return header;

  return `${header}${items.map((item) => [
    `### ${item.id}`,
    `- Block ID: ${item.blockId}`,
    `- Status: ${item.status}`,
    `- Project Fit: ${item.projectFit}`,
    `- Research Mode: ${item.researchMode}`,
    `- Title: ${item.title}`,
    `- Reason: ${item.reason}`,
    `- Brief: ${item.brief}`,
    `- Next Action: ${item.nextAction}`,
    '',
  ].join('\n')).join('\n')}`;
}

function renderDecisionQueue(items: WorkEngineDecision[]): string {
  const header = '# Decision Queue\n\nOpen decisions and watchpoints that should not disappear into free text.\n\n';
  if (items.length === 0) return header;

  return `${header}${items.map((item) => [
    `### ${item.id}`,
    item.blockId ? `- Block ID: ${item.blockId}` : null,
    `- Status: ${item.status}`,
    `- Title: ${item.title}`,
    `- Reason: ${item.reason}`,
    `- Recommendation: ${item.recommendation}`,
    '',
  ].filter(Boolean).join('\n')).join('\n')}`;
}

function renderFreezeLog(freeze: WorkEngineStateSnapshot['freeze']): string {
  return [
    '# Freeze Log',
    '',
    `- State: ${freeze.state}`,
    `- Reason: ${freeze.reason}`,
    `- Required Action: ${freeze.requiredAction}`,
    '',
  ].join('\n');
}

function dedupeBlocks(blocks: WorkEngineBlock[]): WorkEngineBlock[] {
  const grouped = new Map<string, WorkEngineBlock[]>();

  for (const block of blocks) {
    const key = canonicalBlockKey(block);
    const bucket = grouped.get(key) || [];
    bucket.push(block);
    grouped.set(key, bucket);
  }

  return Array.from(grouped.values())
    .map((bucket) => mergeBlockGroup(bucket))
    .sort((left, right) => {
      const scoreGap = (right.overallScore || 0) - (left.overallScore || 0);
      if (Math.abs(scoreGap) > 0.01) return scoreGap;

      const priorityGap = comparePriority(left.priority, right.priority);
      if (priorityGap !== 0) return priorityGap;

      return stageWeight(right.stage) - stageWeight(left.stage);
    });
}

function prioritizeVisibleBlocks(blocks: WorkEngineBlock[]): WorkEngineBlock[] {
  return [...blocks].sort((left, right) => {
    const operatorGap = visibleOperatorPriority(right) - visibleOperatorPriority(left);
    if (operatorGap !== 0) return operatorGap;

    const scoreGap = (right.overallScore || 0) - (left.overallScore || 0);
    if (Math.abs(scoreGap) > 0.01) return scoreGap;

    const priorityGap = comparePriority(left.priority, right.priority);
    if (priorityGap !== 0) return priorityGap;

    return stageWeight(right.stage) - stageWeight(left.stage);
  });
}

function mergeBlockGroup(bucket: WorkEngineBlock[]): WorkEngineBlock {
  const sorted = [...bucket].sort((left, right) => blockDominanceScore(right) - blockDominanceScore(left));
  const primary = sorted[0];
  const mergedRails = Array.from(new Set(sorted.map((block) => block.sourceRail)));
  const mergedSummary = sorted
    .map((block) => block.summary)
    .filter(Boolean)
    .sort((left, right) => right.length - left.length)[0] || primary.summary;
  const desiredOutcome = sorted.find((block) => block.desiredOutcome)?.desiredOutcome || primary.desiredOutcome;
  const priority = sorted.reduce((best, block) => comparePriority(block.priority, best) < 0 ? block.priority : best, primary.priority);
  const lane = highestLane(sorted.map((block) => block.lane));
  const stage = highestStage(sorted.map((block) => block.stage));
  const owner = mergeOwner(sorted.map((block) => block.owner));
  const requiresCodex = sorted.some((block) => block.requiresCodex);
  const requiresOperator = sorted.some((block) => block.requiresOperator);
  const active = sorted.some((block) => block.active);
  const intent = mostCommon(sorted.map((block) => block.intent)) || primary.intent;
  const projectFit = mostCommon(sorted.map((block) => block.projectFit)) || primary.projectFit;
  const researchMode = highestResearchMode(sorted.map((block) => block.researchMode));
  const operatorMode = mergeOperatorModes(sorted.map((block) => block.operatorMode));
  const interpretationHint = sorted
    .map((block) => block.interpretationHint)
    .filter((value): value is string => Boolean(value))
    .sort((left, right) => right.length - left.length)[0] || primary.interpretationHint;
  const researchPrompt = sorted
    .map((block) => block.researchPrompt)
    .filter((value): value is string => Boolean(value))
    .sort((left, right) => right.length - left.length)[0] || primary.researchPrompt;
  const overallScore = scoreBlock({
    ...primary,
    summary: mergedSummary,
    desiredOutcome,
    priority,
    lane,
    stage,
    owner,
    requiresCodex,
    requiresOperator,
    active,
    intent,
    projectFit,
    researchMode,
    operatorMode,
    interpretationHint,
    researchPrompt,
  });

  return {
    ...primary,
    summary: mergedSummary,
    desiredOutcome,
    priority,
    lane,
    stage,
    owner,
    requiresCodex,
    requiresOperator,
    active,
    intent,
    projectFit,
    researchMode,
    operatorMode,
    interpretationHint,
    researchPrompt,
    duplicateCount: bucket.length,
    mergedRails,
    overallScore,
  };
}

function buildRoadmap(
  blocks: WorkEngineBlock[],
  context: RoadmapContext,
): WorkEngineRoadmap {
  const ranked = blocks
    .filter((block) => block.stage !== 'DONE')
    .map((block) => {
      const importance = computeImportance(block, context);
      const expectedOutcome = computeExpectedOutcome(block);
      const downstreamLeverage = computeDownstreamLeverage(block, context);
      const overallScore = Number((importance * 0.42 + expectedOutcome * 0.28 + downstreamLeverage * 0.3).toFixed(1));
      const actionWindow: WorkEngineRoadmapItem['actionWindow'] = overallScore >= 8.7
        ? 'now'
        : overallScore >= 7.2
          ? 'next'
          : 'later';

      return {
        id: block.id,
        title: block.title,
        owner: block.owner,
        lane: block.lane,
        stage: block.stage,
        priority: block.priority,
        actionWindow,
        overallScore,
        importance,
        expectedOutcome,
        downstreamLeverage,
        rationale: buildRationale(block, { importance, expectedOutcome, downstreamLeverage, context }),
      } satisfies WorkEngineRoadmapItem;
    })
    .sort((left, right) => right.overallScore - left.overallScore);

  const now = ranked.filter((item) => item.actionWindow === 'now').slice(0, 6);
  const next = ranked.filter((item) => item.actionWindow === 'next').slice(0, 6);
  const later = ranked.filter((item) => item.actionWindow === 'later').slice(0, 6);
  const top = ranked[0];

  return {
    focus: top
      ? `${top.title} is the highest-leverage block to close next.`
      : 'No active roadmap item is visible yet.',
    summary: [
      top
        ? `Highest priority right now: ${top.title} (${top.overallScore.toFixed(1)} / 10).`
        : 'No active priority item is currently visible.',
      context.remoteBridge.state !== 'live-remote' && context.remoteBridge.expectedMode !== 'local'
        ? 'Remote Vivi visibility is still not authoritative; do not confuse local telemetry with verified VPS truth.'
        : 'Runtime visibility is healthy enough to trust the current local picture.',
      context.githubSync.state === 'blocked'
        ? 'GitHub write sync remains blocked, so freeze-quality local history still matters.'
        : 'GitHub sync posture is not the main blocker for the next build step.',
    ],
    now,
    next,
    later,
  };
}

function computeImportance(
  block: WorkEngineBlock,
  context: RoadmapContext,
): number {
  let value = block.priority === 'critical' ? 10 : block.priority === 'high' ? 8.6 : block.priority === 'explore' ? 4.8 : 6.6;

  if (block.lane === 'repair') value += 0.8;
  if (block.stage === 'FREEZE') value += 0.7;
  if (context.viviState?.currentState === 'FREEZE' && block.requiresOperator) value += 0.5;
  if (block.title.toLowerCase().includes('vps live runtime bridge') && context.remoteBridge.state !== 'live-remote') value += 1.1;
  if (block.title.toLowerCase().includes('github sync') && context.githubSync.state === 'blocked') value += 0.8;

  return clampScore(value);
}

function computeExpectedOutcome(block: WorkEngineBlock): number {
  const title = block.title.toLowerCase();

  if (title.includes('vps live runtime bridge')) return 9.8;
  if (title.includes('autonomous work engine')) return 9.6;
  if (title.includes('board-only codex')) return 9.2;
  if (title.includes('github sync')) return 8.4;
  if (block.lane === 'repair') return 8.8;
  if (block.lane === 'bridge') return 8.7;
  if (block.lane === 'builder') return 7.9;
  if (block.lane === 'research') return 6.7;

  return 7.2;
}

function computeDownstreamLeverage(
  block: WorkEngineBlock,
  context: Pick<RoadmapContext, 'remoteBridge' | 'githubSync'>,
): number {
  const title = block.title.toLowerCase();
  let value = block.lane === 'bridge' ? 8.8 : block.lane === 'repair' ? 8.2 : block.lane === 'builder' ? 7.6 : 6.3;

  if (title.includes('vps live runtime bridge') && context.remoteBridge.state !== 'live-remote') value += 1.0;
  if (title.includes('autonomous work engine')) value += 1.0;
  if (title.includes('board-only codex')) value += 0.8;
  if (title.includes('github sync') && context.githubSync.state === 'blocked') value += 0.7;
  if (block.requiresCodex && block.owner !== 'vivi') value += 0.3;
  if (block.duplicateCount && block.duplicateCount > 1) value += 0.2;

  return clampScore(value);
}

function buildRationale(
  block: WorkEngineBlock,
  input: {
    importance: number;
    expectedOutcome: number;
    downstreamLeverage: number;
    context: Pick<RoadmapContext, 'remoteBridge' | 'githubSync'>;
  },
): string {
  const reasons = [
    `${block.priority} priority`,
    `${block.lane} lane`,
    block.requiresCodex ? 'needs Codex-grade handling' : 'routine-safe for Vivi',
  ];

  if (block.duplicateCount && block.duplicateCount > 1) {
    reasons.push(`collapses ${block.duplicateCount} duplicate signals into one tracked block`);
  }

  if (block.title.toLowerCase().includes('vps live runtime bridge') && input.context.remoteBridge.state !== 'live-remote') {
    reasons.push('restores the missing trustworthy VPS view');
  }

  if (block.title.toLowerCase().includes('github sync') && input.context.githubSync.state === 'blocked') {
    reasons.push('removes the current GitHub collaboration bottleneck');
  }

  reasons.push(
    `importance ${input.importance.toFixed(1)}/10`,
    `outcome ${input.expectedOutcome.toFixed(1)}/10`,
    `leverage ${input.downstreamLeverage.toFixed(1)}/10`,
  );

  return reasons.join(', ');
}

function scoreBlock(block: WorkEngineBlock): number {
  const base = computeImportance(block, {
    remoteBridge: {
      state: 'local-ready',
      detail: '',
      expectedMode: 'local',
      allowLocalFallback: true,
      source: 'work-engine',
    },
    githubSync: {
      state: 'healthy',
      pushReady: 'yes',
      detail: '',
      remoteConfigured: true,
    },
    viviState: null,
  });

  return Number((base * 0.5 + computeExpectedOutcome(block) * 0.25 + computeDownstreamLeverage(block, {
    remoteBridge: {
      state: 'local-ready',
      detail: '',
      expectedMode: 'local',
      allowLocalFallback: true,
      source: 'work-engine',
    },
    githubSync: {
      state: 'healthy',
      pushReady: 'yes',
      detail: '',
      remoteConfigured: true,
    },
  }) * 0.25).toFixed(1));
}

function canonicalBlockKey(block: WorkEngineBlock): string {
  return normalizeText(block.title);
}

function isHistoricalValidationArtifact(block: WorkEngineBlock): boolean {
  const combined = [
    block.title,
    block.summary,
    block.reference || '',
    block.researchPrompt || '',
    block.interpretationHint || '',
  ].join(' ').toLowerCase();

  if (
    combined.includes('control plane integration test')
    || combined.includes('autonomy smoke test')
    || combined.includes('board routing check')
    || combined.includes('operator intent routing verification')
    || combined.includes('test comms membership')
    || combined.includes('test2 comms membership')
    || combined.includes('systemtest fuer bridge-routing')
    || combined.includes('systemtest fuer bridge routing')
    || combined.includes('kategorie test vivi')
    || combined.includes('technical nachweis')
    || combined.includes('build_blocks_roadmap')
    || combined.includes('build block a')
    || combined.includes('build block b')
    || combined.includes('build block c')
    || combined.includes('build block d')
    || combined.includes('test-mesh-')
    || combined.includes('tg-bridge')
    || combined.includes(' e2e ')
  ) {
    return true;
  }

  if (
    block.title.toLowerCase().startsWith('autonomy handoff auto-')
    || block.title.toLowerCase().startsWith('test bridge popup')
    || block.title.toLowerCase().startsWith('test2 bridge popup')
    || block.title.toLowerCase().startsWith('test comms membership')
    || block.title.toLowerCase().startsWith('test2 comms membership')
    || block.title.toLowerCase().startsWith('kategorie test vivi')
    || block.title.toLowerCase().startsWith('operator intent routing verification')
    || block.title.toLowerCase().startsWith('repair signal: fail-')
    || block.title.toLowerCase().startsWith('repair signal: test-20260415-001')
  ) {
    return true;
  }

  if (combined.includes('mobile fallback confirms bridge trust was broken for fail-')) {
    return true;
  }

  if (
    combined.includes('invalid vivi state transition detected')
    && (
      combined.includes('report -> verify')
      || combined.includes('report -> execute')
      || combined.includes('fail-20260415')
      || combined.includes('test-20260415-001')
    )
  ) {
    return true;
  }

  return false;
}

function normalizeText(value: string): string {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function shouldSuppressVisibilityRepairBlock(
  block: WorkEngineBlock,
  remoteBridge: RemoteBridgeStatus,
  localDuoLoop: LocalDuoLoopStatus | null,
): boolean {
  if (!block.title.toLowerCase().includes('live vivi visibility is degraded')) return false;
  if (!isFreshLocalDuoLoop(localDuoLoop)) return false;
  return remoteBridge.state === 'local-ready' || remoteBridge.allowLocalFallback;
}

function isFreshLocalDuoLoop(localDuoLoop: LocalDuoLoopStatus | null): boolean {
  if (!localDuoLoop?.updatedAt) return false;
  if (localDuoLoop.lastExitCode && localDuoLoop.lastExitCode !== 0) return false;
  const state = normalizeField(localDuoLoop.state);
  if (!['idle', 'running'].includes(state)) return false;
  const age = ageMinutes(localDuoLoop.updatedAt);
  return age !== undefined && age <= 10;
}

function ageMinutes(value?: string): number | undefined {
  if (!value) return undefined;
  const parsed = Date.parse(value);
  if (!Number.isFinite(parsed)) return undefined;
  return Math.max(0, Math.floor((Date.now() - parsed) / 60000));
}

function blockDominanceScore(block: WorkEngineBlock): number {
  const sourceBoost = block.sourceRail === 'repair-queue' ? 2.2 : block.sourceRail === 'work-intake' ? 1.4 : 0.6;
  const stageBoost = stageWeight(block.stage) / 10;
  const priorityBoost = block.priority === 'critical' ? 1.8 : block.priority === 'high' ? 1.2 : block.priority === 'explore' ? 0.2 : 0.8;
  const recencyBoost = block.addedAt ? Math.max(0, Date.parse(block.addedAt) / 1e13) : 0;
  return sourceBoost + stageBoost + priorityBoost + recencyBoost;
}

function visibleOperatorPriority(block: WorkEngineBlock): number {
  if (block.sourceRail === 'repair-queue') return 100;
  if (isOperatorDrivenWorkBlock(block) && block.lane !== 'research') return 90;
  if (isOperatorDrivenWorkBlock(block)) return 78;
  if (isInternalCodexSeed(block.sourceActor)) return 30;
  return 55;
}

function isOperatorDrivenWorkBlock(block: WorkEngineBlock): boolean {
  if (isInternalCodexSeed(block.sourceActor)) return false;
  if (isOperatorSource(block.sourceActor)) return true;
  return block.sourceRail === 'brain-dump' || block.sourceRail === 'work-intake';
}

function isOperatorSource(source?: string): boolean {
  const normalized = normalizeField(source);
  return [
    'mission control app',
    'telegram mobile bridge',
    'telegram',
    'operator',
    'board',
  ].some((needle) => normalized.includes(needle));
}

function isInternalCodexSeed(source?: string): boolean {
  const normalized = normalizeField(source);
  return [
    'codex supervisor',
    'codex',
    'automation',
    'system',
  ].some((needle) => normalized.includes(needle));
}

function highestLane(lanes: WorkLane[]): WorkLane {
  if (lanes.includes('repair')) return 'repair';
  if (lanes.includes('bridge')) return 'bridge';
  if (lanes.includes('builder')) return 'builder';
  return 'research';
}

function highestResearchMode(modes: OperatorResearchMode[]): OperatorResearchMode {
  if (modes.includes('primary')) return 'primary';
  if (modes.includes('supporting')) return 'supporting';
  return 'none';
}

function highestStage(stages: WorkStage[]): WorkStage {
  return [...stages].sort((left, right) => stageWeight(right) - stageWeight(left))[0] || 'INTAKE';
}

function mergeOwner(owners: Array<WorkEngineBlock['owner']>): WorkEngineBlock['owner'] {
  const unique = Array.from(new Set(owners));
  if (unique.length === 1) return unique[0];
  if (unique.includes('shared')) return 'shared';
  if (unique.includes('codex') && unique.includes('vivi')) return 'shared';
  return unique[0];
}

function mergeOperatorModes(modes: OperatorMode[]): OperatorMode {
  const unique = Array.from(new Set(modes));
  if (unique.length === 1) return unique[0];
  return 'mixed';
}

function mostCommon<T extends string>(values: T[]): T | null {
  if (!values.length) return null;
  const counts = new Map<T, number>();
  for (const value of values) {
    counts.set(value, (counts.get(value) || 0) + 1);
  }

  return Array.from(counts.entries()).sort((left, right) => right[1] - left[1])[0]?.[0] || null;
}

function stageWeight(stage: WorkStage): number {
  switch (stage) {
    case 'FREEZE':
      return 95;
    case 'REPORT':
      return 90;
    case 'VERIFY':
      return 80;
    case 'EXECUTE':
      return 70;
    case 'RECOVER':
      return 65;
    case 'PLAN':
      return 55;
    case 'ANALYZE':
      return 40;
    case 'DONE':
      return 10;
    case 'INTAKE':
    default:
      return 20;
  }
}

function clampScore(value: number): number {
  return Number(Math.max(1, Math.min(10, value)).toFixed(1));
}

function renderExecutionPlan(roadmap: WorkEngineRoadmap): string {
  const renderSection = (title: string, items: WorkEngineRoadmapItem[]) => {
    if (items.length === 0) {
      return `## ${title}\n\n- Nothing currently ranked in this band.\n`;
    }

    return [
      `## ${title}`,
      '',
      ...items.flatMap((item) => [
        `### ${item.id}`,
        `- Title: ${item.title}`,
        `- Owner: ${item.owner}`,
        `- Lane: ${item.lane}`,
        `- Stage: ${item.stage}`,
        `- Priority: ${item.priority}`,
        `- Overall Score: ${item.overallScore.toFixed(1)}`,
        `- Importance: ${item.importance}/10`,
        `- Expected Outcome: ${item.expectedOutcome}/10`,
        `- Downstream Leverage: ${item.downstreamLeverage}/10`,
        `- Why now: ${item.rationale}`,
        '',
      ]),
    ].join('\n');
  };

  return [
    '# Execution Plan',
    '',
    `- Focus: ${roadmap.focus}`,
    '',
    '## Summary',
    '',
    ...roadmap.summary.map((line) => `- ${line}`),
    '',
    renderSection('Now', roadmap.now),
    renderSection('Next', roadmap.next),
    renderSection('Later', roadmap.later),
  ].join('\n');
}

function renderMissionPriorityBoard(roadmap: WorkEngineRoadmap, blocks: WorkEngineBlock[]): string {
  return [
    '# Mission Priority Board',
    '',
    `- Focus: ${roadmap.focus}`,
    `- Active Blocks: ${blocks.filter((block) => block.active).length}`,
    `- Visible Blocks: ${blocks.length}`,
    '',
    '## Ranking Logic',
    '',
    '- Importance: how urgent and trust-critical the work is for the system.',
    '- Expected Outcome: how much concrete system progress the block produces once completed.',
    '- Downstream Leverage: how strongly the block unlocks later work or reduces repeated friction.',
    '',
    '## Top Priority',
    '',
    ...roadmap.now.slice(0, 5).flatMap((item, index) => [
      `### ${index + 1}. ${item.title}`,
      `- ID: ${item.id}`,
      `- Score: ${item.overallScore.toFixed(1)}`,
      `- Owner: ${item.owner}`,
      `- Action Window: ${item.actionWindow}`,
      `- Reason: ${item.rationale}`,
      '',
    ]),
  ].join('\n');
}

function inferPriority(value: string | undefined, analysis: OperatorIntentAnalysis): WorkEngineBlock['priority'] {
  const normalized = normalizeField(value);
  if (normalized === 'critical' || normalized === 'p0') return 'critical';
  if (normalized === 'high' || normalized === 'p1') return 'high';
  if (normalized === 'explore' || normalized === 'research') return 'explore';
  if (!normalized && analysis.priorityHint === 'critical') return 'critical';
  if (!normalized && analysis.priorityHint === 'high') return 'high';
  if (!normalized && analysis.priorityHint === 'explore') return 'explore';
  return 'normal';
}

function inferLane(
  sourceRail: WorkEngineBlock['sourceRail'],
  combined: string,
  priority: WorkEngineBlock['priority'],
  analysis: OperatorIntentAnalysis,
): WorkLane {
  if (sourceRail === 'repair-queue') return 'repair';
  if (analysis.lane === 'repair' || analysis.lane === 'bridge') return analysis.lane;
  if (analysis.researchMode === 'primary') return 'research';
  if (priority === 'explore' || /research|analyse|analyze|compare|idea|question|investigate|evaluate/.test(combined)) return 'research';
  if (/codex|debug|typescript|electron|next\.|github|bridge|review/.test(combined)) return 'bridge';
  return 'builder';
}

function inferStage(value?: string): WorkStage {
  const normalized = normalizeField(value);
  if (['accepted', 'new', 'queued', 'raw'].includes(normalized)) return 'INTAKE';
  if (['analyzing', 'analyse', 'analyze'].includes(normalized)) return 'ANALYZE';
  if (['planned', 'planning'].includes(normalized)) return 'PLAN';
  if (['executing', 'in-progress', 'working', 'claimed'].includes(normalized)) return 'EXECUTE';
  if (['verifying', 'verify', 'review'].includes(normalized)) return 'VERIFY';
  if (['reported', 'report'].includes(normalized)) return 'REPORT';
  if (['done', 'closed', 'answered'].includes(normalized)) return 'DONE';
  if (['freeze', 'frozen'].includes(normalized)) return 'FREEZE';
  if (['recover', 'recovery'].includes(normalized)) return 'RECOVER';
  return 'INTAKE';
}

function stageProgressIndex(stage: WorkStage): number {
  switch (stage) {
    case 'INTAKE':
    case 'ANALYZE':
      return 0;
    case 'PLAN':
    case 'EXECUTE':
    case 'RECOVER':
      return 1;
    case 'VERIFY':
      return 2;
    case 'REPORT':
    case 'DONE':
      return 3;
    case 'FREEZE':
      return 1;
    default:
      return 0;
  }
}

function comparePriority(left: WorkEngineBlock['priority'], right: WorkEngineBlock['priority']): number {
  const order = { critical: 0, high: 1, normal: 2, explore: 3 };
  return order[left] - order[right];
}

function normalizeField(value?: string): string {
  return value?.trim().toLowerCase() || '';
}

function extractQuotedBody(lines: string[]): string {
  return lines
    .filter((line) => line.trim().startsWith('>'))
    .map((line) => line.replace(/^\s*>\s?/, '').trim())
    .filter(Boolean)
    .join('\n');
}
