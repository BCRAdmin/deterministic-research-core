import { promises as fs } from 'fs';
import path from 'path';

import { PATHS } from '../constants/paths';
import type { GitHubSyncSnapshot } from './githubSyncService';
import type { RemoteBridgeStatus } from './bridgeStatusService';
import type { CodexRuntimeSnapshot } from './codexRuntimeService';
import type { WorkEngineStateSnapshot } from './workEngineService';
import type { ViviRuntimeSnapshot, ViviStateSnapshot } from './viviBridgeService';
import { readRailContent } from './structuredRailService';

interface WorkItem {
  id: string;
  status: string;
  urgency: string;
  title: string;
  desiredOutcome?: string;
  summary: string;
}

interface BridgeItem {
  id: string;
  status: string;
  title: string;
  summary: string;
}

export async function syncLegacyControlPlane(): Promise<void> {
  const [
    runtime,
    state,
    workIntakeContent,
    viviQueueContent,
    repairQueueContent,
    reportsContent,
    workEngine,
    codexRuntime,
    remoteBridge,
  ] = await Promise.all([
    safeJson<ViviRuntimeSnapshot>(PATHS.VIVI_RUNTIME),
    safeJson<ViviStateSnapshot>(PATHS.VIVI_STATE),
    readRailContent(PATHS.WORK_INTAKE),
    readRailContent(PATHS.VIVI_COMMAND_QUEUE),
    readRailContent(PATHS.REPAIR_QUEUE),
    readRailContent(PATHS.VIVI_REPORTS),
    safeJson<WorkEngineStateSnapshot>(PATHS.WORK_ENGINE_STATE),
    safeJson<CodexRuntimeSnapshot>(PATHS.CODEX_RUNTIME),
    safeJson<RemoteBridgeStatus>(PATHS.REMOTE_BRIDGE_STATUS),
  ]);

  const syncStatus = await safeRead(PATHS.GITHUB_SYNC_STATUS);
  const githubStatus = parseGitHubStatus(syncStatus);
  const workItems = parseWorkItems(workIntakeContent);
  const viviCommands = parseBridgeItems(viviQueueContent);
  const repairItems = parseBridgeItems(repairQueueContent);
  const reportItems = parseReportItems(reportsContent);

  const phase = mapPhase(runtime?.mission.phase, state?.currentState);
  const lastAction = runtime?.mission.currentAction || state?.currentAction || 'Board control rails synchronized';
  const nextAction = runtime?.mission.nextAction || state?.nextAction || 'Observe runtime rails';
  const progress = runtime?.mission.progress ?? state?.progress ?? 0;
  const blockers = runtime?.blockers || [];
  const warnings = runtime?.warnings || [];
  const activeTaskId = runtime?.mission.activeTask || state?.commandRef || viviCommands[0]?.id;
  const activeTask = workItems.find((item) => item.id === activeTaskId)
    || viviCommands.find((item) => item.id === activeTaskId)
    || workItems[0]
    || viviCommands[0];

  const activeTasks = buildActiveTasks(workItems, activeTask, runtime, state, workEngine);
  const waitingTasks = buildWaitingTasks(workItems, repairItems, workEngine);
  const completedTasks = buildCompletedTasks(reportItems, workEngine);
  const backlog = buildBacklogSections(workItems, repairItems, workEngine);
  const riskScore = workEngine?.freeze.state === 'frozen'
    ? 86
    : workEngine?.freeze.state === 'watching'
      ? 58
      : blockers.length > 0
        ? 72
        : warnings.length > 0
          ? 38
          : 18;

  const dashboardMd = `# DASHBOARD

## Systemstatus

| Komponente | Status |
| --- | --- |
| **Phase** | ✅ ${phase} |
| Vivi Runtime | ${runtime ? '🟢 PRODUKTIV' : '🟡 DOKUMENTIERT'} |
| Vivi State | ${state ? '🟢 PRODUKTIV' : '🟡 DOKUMENTIERT'} |
| Work Engine | ${workEngine ? '🟢 PRODUKTIV' : '🟡 DOKUMENTIERT'} |
| Remote Bridge | ${remoteBridge ? remoteBridge.state.toUpperCase() : 'PLANNED'} |
| Codex Runtime | ${codexRuntime ? codexRuntime.state.toUpperCase() : 'IDLE'} |
| GitHub Sync | ${githubStatus?.state?.toUpperCase() || 'UNKNOWN'} |
| Work Intake | ${workItems.length > 0 ? '🟢 PRODUKTIV' : '🟡 DOKUMENTIERT'} |
| Command Queue | ${viviCommands.length > 0 ? '🟢 PRODUKTIV' : '🟡 DOKUMENTIERT'} |
| Repair Queue | ${repairItems.length > 0 ? '🟢 PRODUKTIV' : '🟡 DOKUMENTIERT'} |

## Lage

- Fortschritt: ${progress}%
- Aktive Aktion: ${lastAction}
- Nächster Schritt: ${nextAction}
- Blocker: ${blockers.length > 0 ? blockers[0].description : 'Keine kritischen Blocker sichtbar'}
- Warnungen: ${warnings.length > 0 ? warnings.join(' | ') : 'Keine aktiven Warnungen'}
- Freeze: ${workEngine?.freeze.state || 'clear'}
- Remote Bridge: ${remoteBridge?.detail || 'Noch kein Remote-Status erzeugt'}
- GitHub Sync: ${githubStatus?.detail || 'Noch kein GitHub-Sync-Status erzeugt'}
`;

  const taskQueueMd = `# TASK_QUEUE

## Aktive Tasks
| ID | Titel | Priorität | Status | Deadline | Owner |
| --- | --- | --- | --- | --- | --- |
${activeTasks.length > 0 ? activeTasks.map((item) => `| ${item.id} | ${escapeCell(item.title)} | ${item.priority} | ${item.status} | ${item.deadline} | ${item.owner} |`).join('\n') : '| B-0001 | Control plane idle | P2 | observe | n/a | Vivi |'}

## Wartend
| ID | Titel | Grund | Deadline | Owner |
| --- | --- | --- | --- | --- |
${waitingTasks.length > 0 ? waitingTasks.map((item) => `| ${item.id} | ${escapeCell(item.title)} | ${escapeCell(item.reason)} | ${item.deadline} | ${item.owner} |`).join('\n') : '| B-1001 | No waiting task | Board synchronized | n/a | LIONCOM |'}

## Erledigt
| ID | Titel | Erledigt Am | Owner | Detail |
| --- | --- | --- | --- | --- |
${completedTasks.length > 0 ? completedTasks.map((item) => `| ${item.id} | ${escapeCell(item.title)} | ${item.completedAt} | ${item.owner} | ${escapeCell(item.detail)} |`).join('\n') : '| B-2001 | No completed task mirrored yet | n/a | Vivi | Awaiting first report |'}
`;

  const backlogMd = `# BACKLOG

${backlog.map((section) => `## Priorität ${section.priority}
| ID | Titel | Detail | Ziel |
| --- | --- | --- | --- |
${section.items.length > 0 ? section.items.map((item) => `| ${item.id} | ${escapeCell(item.title)} | ${escapeCell(item.detail)} | ${escapeCell(item.target)} |`).join('\n') : `| B-${section.priority === 'P0' ? '3001' : section.priority === 'P1' ? '3002' : section.priority === 'P2' ? '3003' : '3004'} | No ${section.priority} backlog | Awaiting routed intake | Observe |`}
`).join('\n')}`;

  const handoffMd = `# HANDOFF_NEXT_CHAT

### SYSTEMSTAND
| Komponente | Status |
| --- | --- |
| LIONCOM Control Plane | stabil |
| Vivi Runtime Rail | ${runtime ? 'stabil' : 'vorbereitet'} |
| Codex Board Rail | ${codexRuntime?.state || 'vorbereitet'} |
| Remote Bridge | ${remoteBridge?.state || 'planned'} |
| GitHub Sync | ${githubStatus?.state || 'unknown'} |
| Freeze Posture | ${workEngine?.freeze.state || 'clear'} |

### Vorbereitet
| Komponente | Status |
| --- | --- |
| Legacy mirrors | vorbereitet |
| Runtime ingest | vorbereitet |
| Board chat relay | vorbereitet |
| Work engine | ${workEngine ? 'produktiv' : 'vorbereitet'} |

### Offene Baustellen
${blockers.length > 0 ? blockers.map((blocker) => `- ${blocker.description}`).join('\n') : '- Keine kritische Baustelle im Spiegelbild sichtbar'}
${workEngine?.decisions.length ? workEngine.decisions.slice(0, 3).map((item) => `- Entscheidung: ${item.title}`).join('\n') : ''}

### Architektur-Entscheidungen
- LIONCOM-Rails sind die führende Wahrheit.
- Legacy-Dateien werden gespiegelt, nicht manuell geführt.
- Vivi meldet Zustandswechsel über /api/vivi oder direkte Rails.
- Work Blocks und Subtasks werden aus Intake, Repair und Bridge-Rails abgeleitet.
- Vivi_Backup bleibt das Freeze-Archiv, LIONCOM bleibt das Live-Arbeitsrepo.

### Nächste Phase
${phase}
`;

  const systemExportMd = `# SYSTEM_EXPORT

**Datum:** ${new Date().toISOString()}

## Produktive Komponenten
- LIONCOM board chat rail
- Vivi runtime rail
- Vivi state rail
- Vivi reports rail
- Work engine rails
- Remote bridge status rail
- GitHub sync status rail

## Vorbereitete Bereiche
- Legacy compatibility mirrors
- Codex escalation inbox
- Repair queue
- Freeze policy

## Aktuelle Baustellen
${blockers.length > 0 ? blockers.map((blocker) => `- ${blocker.description}`).join('\n') : '- Keine kritische Baustelle aus dem Runtime-Snapshot'}
${remoteBridge && remoteBridge.state !== 'live-remote' ? `- Remote bridge: ${remoteBridge.detail}` : ''}
${githubStatus && githubStatus.state !== 'healthy' ? `- GitHub sync: ${githubStatus.detail}` : ''}

## Nächste empfohlene Schritte
- Halte die Runtime-Signale frisch
- Arbeite neue Intake-Pakete über Vivi oder Codex ab
- Nutze die Repair Queue nur bei echter Betriebsstörung
- Respektiere Freeze-Posture und GitHub-Sync-Status, bevor du finalen Vertrauen annimmst
`;

  const stateJson = {
    generated: new Date().toISOString(),
    layers: {
      core: {
        systemState: blockers.length > 0 ? 'BLOCKED' : runtime?.mission.state || 'ACTIVE',
        activeTask: activeTaskId || null,
        tasksCompleted: completedTasks.length,
        tasksOpen: activeTasks.length + waitingTasks.length,
        tasksInProgress: activeTasks.length,
        backlogStatus: backlog.some((section) => section.items.length > 0) ? 'queued' : 'clear',
        lastUpdate: runtime?.updatedAt || state?.updatedAt,
      },
      execution: {
        currentPhase: phase,
        progress,
        lastAction,
        nextPhase: nextAction,
        timeInPhase: 0,
      },
      health: {
        status: blockers.length > 0 ? 'warning' : runtime?.runtime.responsive === false ? 'warning' : 'ok',
        lastActivity: runtime?.runtime.heartbeatAt || state?.updatedAt,
        blockers,
        checks: {
          runtime: {
            status: runtime?.runtime.responsive === false ? 'warning' : 'ok',
            agentResponsive: runtime?.runtime.responsive ?? false,
          },
        },
      },
      log: {
        recentActions: [
          {
            time: runtime?.updatedAt || state?.updatedAt || new Date().toISOString(),
            message: lastAction,
            type: blockers.length > 0 ? 'warning' : 'system',
          },
          ...reportItems.slice(0, 3).map((item) => ({
            time: item.completedAt,
            message: item.title,
            type: 'deploy',
          })),
        ],
      },
    },
    derived: {
      riskScore,
    },
  };

  await Promise.all([
    writeFile(PATHS.DASHBOARD, dashboardMd),
    writeFile(PATHS.TASK_QUEUE, taskQueueMd),
    writeFile(PATHS.BACKLOG, backlogMd),
    writeFile(PATHS.HANDOFF_NEXT_CHAT, handoffMd),
    writeFile(PATHS.SYSTEM_EXPORT, systemExportMd),
    writeJson(PATHS.DASHBOARD_STATE, stateJson),
  ]);
}

function buildActiveTasks(
  workItems: WorkItem[],
  activeTask: WorkItem | BridgeItem | undefined,
  runtime: ViviRuntimeSnapshot | null,
  state: ViviStateSnapshot | null,
  workEngine: WorkEngineStateSnapshot | null,
) {
  if (workEngine?.blocks.length) {
    return workEngine.blocks
      .filter((block) => block.active)
      .slice(0, 5)
      .map((block, index) => ({
        id: toBoardId(block.id, 1 + index),
        title: block.title,
        priority: mapPriority(block.priority),
        status: mapStatus(block.stage),
        deadline: 'n/a',
        owner: capitalize(block.owner),
      }));
  }

  const items = (activeTask ? [activeTask] : workItems.slice(0, 2)).slice(0, 3);
  return items.map((item, index) => ({
    id: toBoardId(item.id, 1 + index),
    title: item.title,
    priority: mapPriority('urgency' in item ? item.urgency : undefined),
    status: mapStatus(runtime?.mission.operatingState || state?.currentState || item.status),
    deadline: 'n/a',
    owner: index === 0 ? 'Vivi' : 'LIONCOM',
  }));
}

function buildWaitingTasks(workItems: WorkItem[], repairItems: BridgeItem[], workEngine: WorkEngineStateSnapshot | null) {
  if (workEngine?.subtasks.length) {
    return workEngine.subtasks
      .filter((item) => item.status !== 'done')
      .slice(0, 6)
      .map((item, index) => ({
        id: toBoardId(item.id, 100 + index),
        title: item.title,
        reason: item.detail,
        deadline: 'n/a',
        owner: capitalize(item.owner),
      }));
  }

  const waitingWork = workItems.filter((item) => !['executing', 'verifying', 'reported', 'done'].includes(item.status.toLowerCase())).slice(0, 4);
  const waitingRepairs = repairItems.slice(0, 2);

  return [
    ...waitingWork.map((item, index) => ({
      id: toBoardId(item.id, 100 + index),
      title: item.title,
      reason: item.summary,
      deadline: 'n/a',
      owner: 'Vivi',
    })),
    ...waitingRepairs.map((item, index) => ({
      id: toBoardId(item.id, 200 + index),
      title: item.title,
      reason: item.summary,
      deadline: 'n/a',
      owner: 'Repair rail',
    })),
  ].slice(0, 6);
}

function buildCompletedTasks(reportItems: Array<{ id: string; title: string; completedAt: string; owner: string; detail: string }>, workEngine: WorkEngineStateSnapshot | null) {
  const completedFromEngine = workEngine?.blocks
    .filter((block) => ['REPORT', 'DONE'].includes(block.stage))
    .slice(0, 4)
    .map((block, index) => ({
      id: toBoardId(block.id, 700 + index),
      title: block.title,
      completedAt: new Date().toISOString(),
      owner: capitalize(block.owner),
      detail: block.summary,
    })) || [];

  return [...completedFromEngine, ...reportItems].slice(0, 6);
}

function buildBacklogSections(workItems: WorkItem[], repairItems: BridgeItem[], workEngine: WorkEngineStateSnapshot | null) {
  const sections = ['P0', 'P1', 'P2', 'P3'].map((priority) => ({ priority, items: [] as Array<{ id: string; title: string; detail: string; target: string }> }));

  if (workEngine?.blocks.length) {
    for (const block of workEngine.blocks) {
      const section = sections.find((entry) => entry.priority === mapPriority(block.priority)) || sections[2];
      section.items.push({
        id: toBoardId(block.id, 300 + section.items.length),
        title: block.title,
        detail: block.summary,
        target: block.desiredOutcome || `${block.lane} / ${block.stage}`,
      });
    }
    return sections;
  }

  for (const item of workItems) {
    const priority = mapPriority(item.urgency);
    const section = sections.find((entry) => entry.priority === priority) || sections[2];
    section.items.push({
      id: toBoardId(item.id, 300 + section.items.length),
      title: item.title,
      detail: item.summary,
      target: item.desiredOutcome || 'Interpret and route safely',
    });
  }

  for (const item of repairItems) {
    sections[0].items.push({
      id: toBoardId(item.id, 500 + sections[0].items.length),
      title: item.title,
      detail: item.summary,
      target: 'Stabilize and verify',
    });
  }

  return sections;
}

function parseWorkItems(content: string | null): WorkItem[] {
  return parseStructuredBlocks(content).map((block) => ({
    id: block.id,
    status: block.fields['Status'] || 'new',
    urgency: block.fields['Urgency'] || 'normal',
    title: block.fields['Title'] || block.id,
    desiredOutcome: block.fields['Desired Outcome'],
    summary: block.fields['Summary'] || block.id,
  }));
}

function parseBridgeItems(content: string | null): BridgeItem[] {
  return parseStructuredBlocks(content).map((block) => ({
    id: block.id,
    status: block.fields['Status'] || 'queued',
    title: block.fields['Title'] || block.id,
    summary: block.fields['Summary'] || block.id,
  }));
}

function parseReportItems(content: string | null) {
  return parseStructuredBlocks(content).map((block, index) => ({
    id: toBoardId(block.id, 700 + index),
    title: block.fields['Title'] || block.id,
    completedAt: block.fields['Added'] || 'n/a',
    owner: 'Vivi',
    detail: block.fields['Summary'] || 'Runtime report',
  }));
}

function parseStructuredBlocks(content: string | null): Array<{ id: string; fields: Record<string, string> }> {
  if (!content) return [];

  return content
    .split(/^###\s+/m)
    .map((section) => section.trim())
    .filter(Boolean)
    .flatMap((section) => {
      const [headline, ...bodyLines] = section.split('\n');
      const id = headline?.trim();
      if (!id || id.startsWith('#')) return [];
      const fields: Record<string, string> = {};
      for (const line of bodyLines) {
        const match = line.trim().match(/^\-\s*([^:]+):\s*(.+)$/);
        if (match) fields[match[1].trim()] = match[2].trim();
      }
      return [{ id, fields }];
    })
    .reverse();
}

function mapPhase(phase?: string, state?: string): string {
  const candidate = (phase || state || 'INITIALISIERUNG').toUpperCase();
  if (candidate.includes('VERIFY')) return 'VALIDIERUNG';
  if (candidate.includes('REPORT')) return 'ABSCHLUSS';
  if (candidate.includes('EXEC')) return 'AUSFÜHRUNG';
  if (candidate.includes('PLAN')) return 'PLANUNG';
  if (candidate.includes('ANALYZE') || candidate.includes('INTAKE')) return 'INITIALISIERUNG';
  return ['INITIALISIERUNG', 'PLANUNG', 'AUSFÜHRUNG', 'VALIDIERUNG', 'ABSCHLUSS'].includes(candidate)
    ? candidate
    : 'INITIALISIERUNG';
}

function mapPriority(urgency?: string): 'P0' | 'P1' | 'P2' | 'P3' {
  const value = (urgency || '').toLowerCase();
  if (value === 'critical' || value === 'p0') return 'P0';
  if (value === 'high' || value === 'p1') return 'P1';
  if (value === 'low' || value === 'p3') return 'P3';
  return 'P2';
}

function mapStatus(value?: string): string {
  const candidate = (value || '').toLowerCase();
  if (candidate.includes('verify')) return 'verify';
  if (candidate.includes('report') || candidate.includes('done')) return 'done';
  if (candidate.includes('plan')) return 'planned';
  if (candidate.includes('analy')) return 'analyzing';
  if (candidate.includes('freeze')) return 'blocked';
  if (candidate.includes('recover')) return 'recovery';
  if (candidate.includes('execute')) return 'in-progress';
  return candidate || 'open';
}

function toBoardId(id: string, fallbackNumber: number): string {
  if (id.startsWith('B-')) return id;
  const compact = id.replace(/[^A-Z0-9]/gi, '').slice(-4);
  return `B-${compact || String(fallbackNumber).padStart(4, '0')}`;
}

function escapeCell(value: string): string {
  return value.replace(/\|/g, '/');
}

function capitalize(value: string): string {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function parseGitHubStatus(content: string | null): GitHubSyncSnapshot | null {
  if (!content) return null;
  const fields = new Map<string, string>();
  for (const line of content.split('\n')) {
    const match = line.match(/^\-\s*([^:]+):\s*(.+)$/);
    if (match) fields.set(match[1].trim(), match[2].trim());
  }

  if (!fields.size) return null;

  return {
    schemaVersion: '1.0',
    updatedAt: fields.get('Updated') || new Date().toISOString(),
    branch: fields.get('Branch') || 'unknown',
    isRepo: fields.get('Repository Visible') === 'yes',
    remoteConfigured: fields.get('Remote Configured') === 'yes',
    remoteUrl: fields.get('Remote URL') || undefined,
    state: (fields.get('State') || 'warning').toLowerCase() as GitHubSyncSnapshot['state'],
    pushReady: (fields.get('Push Ready') || 'unknown').toLowerCase() as GitHubSyncSnapshot['pushReady'],
    authMode: (fields.get('Auth Mode') || 'unknown').toLowerCase() as GitHubSyncSnapshot['authMode'],
    detail: fields.get('Detail') || 'GitHub sync status not parsed.',
    suggestedFix: fields.get('Suggested Fix') || 'Verify local authentication before relying on GitHub sync.',
    freezeStrategy: fields.get('Freeze Strategy') || '',
    backupRole: fields.get('Backup Role') || '',
    authLastChecked: fields.get('Auth Last Checked') || undefined,
  };
}

async function writeFile(filePath: string, content: string): Promise<void> {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, `${content.trimEnd()}\n`, 'utf-8');
}

async function writeJson(filePath: string, payload: unknown): Promise<void> {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, `${JSON.stringify(payload, null, 2)}\n`, 'utf-8');
}

async function safeJson<T>(filePath: string): Promise<T | null> {
  try {
    return JSON.parse(await fs.readFile(filePath, 'utf-8')) as T;
  } catch {
    return null;
  }
}

async function safeRead(filePath: string): Promise<string | null> {
  try {
    return await fs.readFile(filePath, 'utf-8');
  } catch {
    return null;
  }
}
