export type OperatorIntentKind = 'execute' | 'research' | 'explore' | 'repair' | 'review' | 'codex';
export type OperatorProjectFit = 'existing' | 'new-track' | 'unknown';
export type OperatorMode = 'direct' | 'rough' | 'mixed';
export type OperatorResearchMode = 'none' | 'supporting' | 'primary';
export type OperatorRoutingLane = 'builder' | 'research' | 'repair' | 'bridge';
export type OperatorPriorityHint = 'critical' | 'high' | 'normal' | 'explore';
export type OperatorExampleHandling = 'literal' | 'reference' | 'none';

export interface OperatorIntentAnalysis {
  intent: OperatorIntentKind;
  projectFit: OperatorProjectFit;
  operatorMode: OperatorMode;
  researchMode: OperatorResearchMode;
  lane: OperatorRoutingLane;
  requiresCodex: boolean;
  priorityHint: OperatorPriorityHint;
  exampleHandling: OperatorExampleHandling;
  interpretationHint: string;
  routingNote: string;
  researchPrompt?: string;
}

export function analyzeOperatorIntent(input: {
  sourceRail?: 'work-intake' | 'brain-dump' | 'repair-queue' | 'vivi-command' | 'codex-command' | 'codex-chat';
  title?: string;
  summary?: string;
  rawText?: string;
  context?: string;
  desiredOutcome?: string;
  priority?: string;
}): OperatorIntentAnalysis {
  const title = input.title?.trim() || '';
  const summary = input.summary?.trim() || '';
  const rawText = input.rawText?.trim() || '';
  const context = input.context?.trim() || '';
  const desiredOutcome = input.desiredOutcome?.trim() || '';
  const combined = compact([title, summary, rawText, context, desiredOutcome].join(' '));
  const titleCompact = compact(title);
  const buildBlockTitle = /^build block [a-z]/.test(titleCompact);
  const existingSystemSignal = containsAny(combined, [
    'lioncom', 'vivi', 'dashboard', 'board', 'bridge', 'repo', 'workflow', 'task', 'builder',
    'research deck', 'codex', 'control plane', 'mission control', 'github sync', 'runtime bridge',
    'autonomous work engine', 'board-only codex',
  ]);
  const emergencyRepairSignal = containsSignal(combined, [
    'broken', 'blocker', 'incident', 'failure', 'error', 'bug', 'degraded', 'stale', 'down',
    'fehler', 'kaputt', 'störung', 'blockiert', 'degradiert',
  ]);

  const hasResearchSignal = containsAny(combined, [
    'research', 'analyse', 'analyze', 'investigate', 'compare', 'evaluate', 'evidence',
    'brainstorm', 'idea', 'question', 'explore', 'find out', 'understand',
    'forschung', 'recherche', 'analys', 'vergleich', 'idee', 'ideen', 'verstehen', 'prüf',
  ]);
  const hasRepairSignal = input.sourceRail === 'repair-queue'
    || emergencyRepairSignal
    || (!buildBlockTitle && containsAny(combined, ['repair request', 'repair packet', 'rescue mode', 'debug this', 'fix this now', 'reparier das']));
  const hasReviewSignal = containsAny(combined, [
    'review', 'check', 'verify', 'validate', 'quality', 'audit',
    'prüf', 'kontroll', 'reviewen', 'qualität',
  ]);
  const hasCodexSignal = input.sourceRail === 'codex-command' || input.sourceRail === 'codex-chat' || containsAny(combined, [
    'codex', 'typescript', 'next.js', 'nextjs', 'electron', 'github', 'architecture', 'refactor',
    'api', 'server', 'repo', 'debug', 'fix', 'bridge', 'dashboard', 'board',
  ]);
  const hasExplicitNewTrackSignal = containsAny(combined, [
    'new project', 'new idea', 'new concept', 'from scratch', 'brand new', 'separate repo',
    'neues projekt', 'neue idee', 'neues system', 'eigene app', 'eigene os', 'separat',
  ]);
  const hasReferenceSignal = containsAny(combined, [
    'similar to', 'similar style', 'like ', 'inspired by', 'reference', 'as reference',
    'ähnlich', 'im stil von', 'orientiere dich an', 'inspiriert von', 'als referenz',
    'nimm das als referenz', 'so wie', 'richtung von',
  ]);
  const hasLiteralSignal = containsAny(combined, [
    'exactly like', 'exact copy', '1:1', 'as close as possible', 'copy this',
    'genau so', 'möglichst nah', 'so nah wie möglich', '1 zu 1', 'kopiere das',
  ]);
  const hasNewTrackSignal = !buildBlockTitle && hasExplicitNewTrackSignal;
  const hasExistingTrackSignal = existingSystemSignal || buildBlockTitle;
  const explicitCodexDirective = input.sourceRail === 'codex-command'
    || input.sourceRail === 'codex-chat'
    || containsAny(combined, ['codex should', 'send to codex', 'codex handle', 'codex review', 'review with codex', 'for codex']);
  const directSignals = countMatches(combined, [
    'mach', 'zieh durch', 'fang an', 'setze um', 'build', 'implement', 'fix', 'do it',
    'start', 'execute', 'carry on', 'through', 'fertig machen',
  ]);
  const roughSignals = countMatches(combined, [
    'vielleicht', 'maybe', 'wäre cool', 'idea', 'idee', 'ich denke', 'ich glaube',
    'so ein bisschen', 'irgendwie', 'mal sehen', 'half-formed', 'rough',
  ]);

  const explicitPriority = normalizePriority(input.priority);

  if (buildBlockTitle) {
    const lane: OperatorRoutingLane = containsAny(titleCompact, ['runtime bridge', 'codex operating rail', 'github sync'])
      ? 'bridge'
      : 'builder';
    const requiresCodex = lane === 'bridge' || containsAny(combined, ['github', 'bridge', 'api', 'server', 'electron', 'next.js']);
    const operatorMode: OperatorMode = directSignals > 0 ? 'direct' : 'mixed';

    return {
      intent: 'execute',
      projectFit: 'existing',
      operatorMode,
      researchMode: 'none',
      lane,
      requiresCodex,
      priorityHint: explicitPriority || (requiresCodex ? 'high' : 'normal'),
      exampleHandling: hasLiteralSignal ? 'literal' : hasReferenceSignal ? 'reference' : 'none',
      interpretationHint: `This is an existing LIONCOM build block and should stay inside the active system track. ${requiresCodex ? 'Prepare Codex-grade implementation context where technical depth is required.' : 'Treat it as a structured execution mission for Vivi first.'} ${hasReferenceSignal && !hasLiteralSignal ? 'Examples inside the request should guide the direction, not become a blind 1:1 copy.' : ''}`,
      routingNote: `Route this through the ${lane} lane and keep it attached to the active LIONCOM mission stack.`,
    };
  }

  const projectFit: OperatorProjectFit = hasNewTrackSignal
    ? 'new-track'
    : hasExistingTrackSignal
      ? 'existing'
      : 'unknown';
  const operatorMode: OperatorMode = directSignals > 0 && roughSignals > 0
    ? 'mixed'
    : directSignals > 0
      ? 'direct'
      : roughSignals > 0 || input.sourceRail === 'brain-dump'
        ? 'rough'
        : 'mixed';

  let intent: OperatorIntentKind = 'execute';
  if (hasRepairSignal) intent = 'repair';
  else if ((input.sourceRail === 'codex-command' || input.sourceRail === 'codex-chat') && hasCodexSignal) intent = 'codex';
  else if (hasReviewSignal && explicitCodexDirective) intent = 'codex';
  else if (hasReviewSignal) intent = 'review';
  else if (hasResearchSignal && directSignals === 0) intent = 'research';
  else if (input.sourceRail === 'brain-dump' || hasNewTrackSignal || roughSignals >= 2) intent = 'explore';
  else if (hasCodexSignal && directSignals > 0 && explicitCodexDirective) intent = 'codex';

  if (input.sourceRail === 'vivi-command' && intent !== 'repair' && (!explicitCodexDirective || intent === 'review')) {
    intent = 'execute';
  }

  if (input.sourceRail === 'brain-dump' && intent !== 'repair' && intent !== 'codex') {
    intent = 'explore';
  }

  const researchMode: OperatorResearchMode = intent === 'research' || intent === 'explore'
    ? 'primary'
    : hasResearchSignal || hasReferenceSignal || (projectFit === 'new-track' && !desiredOutcome) || (operatorMode !== 'direct' && !desiredOutcome)
      ? 'supporting'
      : 'none';

  const lane: OperatorRoutingLane = hasRepairSignal
    ? 'repair'
    : input.sourceRail === 'vivi-command'
      ? 'bridge'
      : intent === 'codex'
      ? 'bridge'
      : researchMode === 'primary'
        ? 'research'
        : hasCodexSignal
          ? 'bridge'
          : 'builder';

  const requiresCodex = input.sourceRail === 'codex-command'
    || input.sourceRail === 'codex-chat'
    || containsAny(combined, ['codex should', 'send to codex', 'codex review', 'codex handle'])
    || (intent === 'repair' && containsAny(combined, ['api', 'repo', 'bridge', 'server', 'typescript', 'github']))
    || (buildBlockTitle && containsAny(combined, ['github', 'bridge', 'api', 'electron', 'next.js', 'server']));
  const priorityHint = explicitPriority
    || (intent === 'repair' ? 'critical' : intent === 'codex' || directSignals > 0 ? 'high' : researchMode === 'primary' ? 'explore' : 'normal');
  const exampleHandling: OperatorExampleHandling = hasLiteralSignal
    ? 'literal'
    : hasReferenceSignal
      ? 'reference'
      : 'none';

  const interpretationHint = buildInterpretationHint({
    intent,
    projectFit,
    operatorMode,
    researchMode,
    requiresCodex,
    hasDesiredOutcome: Boolean(desiredOutcome),
    sourceRail: input.sourceRail,
    exampleHandling,
  });

  const routingNote = buildRoutingNote({
    intent,
    lane,
    projectFit,
    researchMode,
    requiresCodex,
    sourceRail: input.sourceRail,
    exampleHandling,
  });

  const researchPrompt = researchMode === 'none'
    ? undefined
    : buildResearchPrompt({ intent, projectFit, desiredOutcome, title, summary });

  return {
    intent,
    projectFit,
    operatorMode,
    researchMode,
    lane,
    requiresCodex,
    priorityHint,
    exampleHandling,
    interpretationHint,
    routingNote,
    researchPrompt,
  };
}

function buildInterpretationHint(input: {
  intent: OperatorIntentKind;
  projectFit: OperatorProjectFit;
  operatorMode: OperatorMode;
  researchMode: OperatorResearchMode;
  requiresCodex: boolean;
  hasDesiredOutcome: boolean;
  sourceRail?: 'work-intake' | 'brain-dump' | 'repair-queue' | 'vivi-command' | 'codex-command' | 'codex-chat';
  exampleHandling: OperatorExampleHandling;
}): string {
  const parts: string[] = [];

  if (input.sourceRail === 'vivi-command') {
    parts.push('This came through the Bridge lane and should be treated as a concrete mission, not a loose brainstorm.');
  } else if (input.sourceRail === 'work-intake' || input.sourceRail === 'brain-dump') {
    parts.push('This came through the Comms side and should be interpreted and structured before hard implementation begins.');
  }

  if (input.intent === 'explore') {
    parts.push('This reads like a rough idea stream that should be clarified before execution.');
  } else if (input.intent === 'research') {
    parts.push('This reads like a research request and should be framed into explicit questions first.');
  } else if (input.intent === 'repair') {
    parts.push('This is a repair-focused request and should stabilize trust before normal progress resumes.');
  } else if (input.intent === 'codex') {
    parts.push('This likely needs Codex-grade technical handling after Vivi structures the packet cleanly.');
  } else {
    parts.push('This can move toward execution once the mission is structured cleanly.');
  }

  if (input.projectFit === 'new-track') {
    parts.push('Treat it as a potential new track instead of forcing it into an existing mission too early.');
  } else if (input.projectFit === 'existing') {
    parts.push('It likely belongs to an existing mission or active system lane.');
  }

  if (!input.hasDesiredOutcome) {
    parts.push('The desired end state is still implicit and should be surfaced during analysis.');
  }

  if (input.exampleHandling === 'reference') {
    parts.push('The cited examples should be treated as references or inspiration, not as a blind blueprint.');
  } else if (input.exampleHandling === 'literal') {
    parts.push('The operator is signaling that example fidelity matters and the implementation may stay close to the reference.');
  }

  if (input.operatorMode !== 'direct') {
    parts.push('Translate the rough wording into structured intent without asking for prompt cleanup.');
  }

  if (input.researchMode !== 'none') {
    parts.push('A visible research step should happen before the idea disappears into raw text.');
  }

  if (input.requiresCodex) {
    parts.push('Prepare a clean escalation packet if the work becomes technically deep.');
  }

  return parts.join(' ');
}

function buildRoutingNote(input: {
  intent: OperatorIntentKind;
  lane: OperatorRoutingLane;
  projectFit: OperatorProjectFit;
  researchMode: OperatorResearchMode;
  requiresCodex: boolean;
  sourceRail?: 'work-intake' | 'brain-dump' | 'repair-queue' | 'vivi-command' | 'codex-command' | 'codex-chat';
  exampleHandling: OperatorExampleHandling;
}): string {
  const phrases = [`Route this through the ${input.lane} lane.`];

  if (input.sourceRail === 'vivi-command') {
    phrases.push('Treat this as Bridge work: build, fix, verify or deliver the concrete mission.');
  } else if (input.sourceRail === 'work-intake' || input.sourceRail === 'brain-dump') {
    phrases.push('Treat this as Comms work: understand the goal, structure the work and decide whether it becomes execution, research, backlog or escalation.');
  }

  if (input.researchMode === 'primary') {
    phrases.push('Start with structured research before committing to implementation.');
  } else if (input.researchMode === 'supporting') {
    phrases.push('Keep a supporting research pass visible while execution is being prepared.');
  }

  if (input.exampleHandling === 'reference') {
    phrases.push('Use examples as directional references unless the operator explicitly asks for near-copy fidelity.');
  }

  if (input.projectFit === 'new-track') {
    phrases.push('Treat it as a new track until evidence says it should join an existing mission.');
  }

  if (input.requiresCodex) {
    phrases.push('Escalate to Codex once the packet is structured enough for hard technical work.');
  }

  return phrases.join(' ');
}

function buildResearchPrompt(input: {
  intent: OperatorIntentKind;
  projectFit: OperatorProjectFit;
  desiredOutcome: string;
  title: string;
  summary: string;
}): string {
  if (input.projectFit === 'new-track') {
    return `Clarify whether "${input.title || input.summary}" should become a new mission, backlog track or remain only an idea.`;
  }

  if (input.intent === 'research') {
    return `Turn "${input.title || input.summary}" into answerable research questions, assumptions, risks and next actions.`;
  }

  return `Clarify the hidden goal behind "${input.title || input.summary}" and determine the safest next action before implementation.`;
}

function normalizePriority(value?: string): OperatorPriorityHint | null {
  const normalized = compact(value || '');
  if (!normalized) return null;
  if (containsAny(normalized, ['critical', 'p0'])) return 'critical';
  if (containsAny(normalized, ['high', 'p1', 'urgent'])) return 'high';
  if (containsAny(normalized, ['explore', 'research'])) return 'explore';
  return 'normal';
}

function compact(value: string): string {
  return value.toLowerCase().replace(/\s+/g, ' ').trim();
}

function containsAny(haystack: string, needles: string[]): boolean {
  return needles.some((needle) => haystack.includes(needle));
}

function containsSignal(haystack: string, needles: string[]): boolean {
  return needles.some((needle) => {
    const escaped = needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '\\s+');
    return new RegExp(`(^|[^a-z0-9])${escaped}([^a-z0-9]|$)`, 'i').test(haystack);
  });
}

function countMatches(haystack: string, needles: string[]): number {
  return needles.reduce((count, needle) => count + (haystack.includes(needle) ? 1 : 0), 0);
}
