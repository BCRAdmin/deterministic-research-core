import os from 'os';
import path from 'path';
import { promises as fs } from 'fs';

import { PATHS, WORKSPACE_ROOT } from '../constants/paths';
import type { StoredAttachment } from './attachmentService';
import { readTextFile } from './fileService';
import { loadEnvFileCandidates } from './envFileService';

export interface TelegramStatus {
  configured: boolean;
  hasSecretsFile: [REDACTED]
  hasHomeEnvFile: boolean;
  hasWebhookSecret: [REDACTED]
  lastLogEntry?: string;
  lastLogTime?: string;
  lastInboundEntry?: string;
  lastInboundTime?: string;
  status: 'OK' | 'WARNING' | 'UNKNOWN';
  source?: string;
}

export interface TelegramCredentials {
  botToken?: string;
  chatId?: string;
  webhookSecret?: string;
  source?: string;
  hasConfigFile: boolean;
  hasHomeEnvFile: boolean;
}

export interface TelegramSendResult {
  delivered: boolean;
  status: 'sent' | 'queued' | 'failed';
  detail: string;
  target?: string;
}

export interface TelegramUpdateEnvelope {
  update_id?: number;
  message?: {
    message_id?: number;
    date?: number;
    text?: string;
    chat?: {
      id?: number | string;
      type?: string;
      title?: string;
    };
    from?: {
      id?: number | string;
      is_bot?: boolean;
      first_name?: string;
      last_name?: string;
      username?: string;
    };
  };
}

export interface TelegramFetchResult {
  ok: boolean;
  updates: TelegramUpdateEnvelope[];
  lastUpdateId?: number;
  detail: string;
}

const TELEGRAM_CONFIG_CANDIDATES = [
  path.join(WORKSPACE_ROOT, '.secrets', 'telegram'),
  path.join(os.homedir(), '.openclaw', 'secrets', 'telegram.env'),
] as const;

const TELEGRAM_LOG_CANDIDATES = [
  PATHS.TELEGRAM_OUTBOX,
  PATHS.DASHBOARD_ACTIVITY_LOG,
  path.join(WORKSPACE_ROOT, 'DAILY', 'cron_morning.log'),
] as const;

export async function getTelegramStatus(): Promise<TelegramStatus> {
  const credentials = await loadTelegramCredentials();
  const [logSignals, inboundSignals] = await Promise.all([
    collectTelegramLogSignals(),
    collectTelegramInboundSignals(),
  ]);

  let status: TelegramStatus['status'] = 'UNKNOWN';
  if (logSignals.kind === 'sent' || inboundSignals.kind === 'received') {
    status = 'OK';
  } else if (credentials.botToken && credentials.chatId) {
    status = logSignals.kind === 'failed' ? 'WARNING' : 'OK';
  } else if (credentials.hasConfigFile || credentials.hasHomeEnvFile) {
    status = 'WARNING';
  }

  return {
    configured: Boolean(credentials.botToken && credentials.chatId),
    hasSecretsFile: [REDACTED]
    hasHomeEnvFile: credentials.hasHomeEnvFile,
    hasWebhookSecret: [REDACTED]
    lastLogEntry: logSignals.entry,
    lastLogTime: logSignals.time,
    lastInboundEntry: inboundSignals.entry,
    lastInboundTime: inboundSignals.time,
    status,
    source: credentials.source,
  };
}

export async function isTelegramConfigured(): Promise<boolean> {
  const status = await getTelegramStatus();
  return status.configured;
}

export async function loadTelegramCredentials(): Promise<TelegramCredentials> {
  const loaded = await loadEnvFileCandidates(TELEGRAM_CONFIG_CANDIDATES);
  if (loaded.source) {
    const values = loaded.values;
    return {
      botToken: [REDACTED]
      chatId: values.TELEGRAM_CHAT_ID,
      webhookSecret: [REDACTED]
      source: loaded.source,
      hasConfigFile: loaded.source.endsWith('/.secrets/telegram'),
      hasHomeEnvFile: loaded.source.endsWith('/telegram.env'),
    };
  }

  return {
    hasConfigFile: false,
    hasHomeEnvFile: false,
  };
}

export async function sendTelegramBridgeMessage(input: {
  title: string;
  message: string;
  priority?: string;
  targetChatId?: string;
  attachments?: StoredAttachment[];
}): Promise<TelegramSendResult> {
  const credentials = await loadTelegramCredentials();
  const text = buildTelegramText(input.title, input.message, input.priority);
  const targetChatId = input.targetChatId || credentials.chatId;
  const attachments = input.attachments || [];

  if (!credentials.botToken || !targetChatId) {
    return {
      delivered: false,
      status: 'queued',
      detail: attachments.length > 0
        ? `Telegram credentials are not configured locally yet. Packet and ${attachments.length} attachment(s) were stored for later relay.`
        : 'Telegram credentials are not configured locally yet. Packet stored for later relay.',
      target: targetChatId,
    };
  }

  try {
    const body = new URLSearchParams({
      chat_id: targetChatId,
      text,
      parse_mode: 'Markdown',
      disable_web_page_preview: 'true',
    });

    const response = await fetch(`https://api.telegram.org/bot${credentials.botToken}/sendMessage`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: body.toString(),
      cache: 'no-store',
    });

    if (!response.ok) {
      return {
        delivered: false,
        status: 'failed',
        detail: `Telegram returned HTTP ${response.status}`,
        target: targetChatId,
      };
    }

    for (const attachment of attachments) {
      const documentForm = new FormData();
      const buffer = await fs.readFile(attachment.absolutePath);
      documentForm.set('chat_id', targetChatId);
      documentForm.set(
        'document',
        new Blob([buffer], { type: attachment.mimeType || 'application/octet-stream' }),
        attachment.name,
      );

      const documentResponse = await fetch(`https://api.telegram.org/bot${credentials.botToken}/sendDocument`, {
        method: 'POST',
        body: documentForm,
        cache: 'no-store',
      });

      if (!documentResponse.ok) {
        return {
          delivered: false,
          status: 'failed',
          detail: `Telegram delivered the text packet, but attachment upload failed for ${attachment.name} with HTTP ${documentResponse.status}.`,
          target: targetChatId,
        };
      }
    }

    return {
      delivered: true,
      status: 'sent',
      detail: attachments.length > 0
        ? `Telegram packet and ${attachments.length} attachment(s) delivered successfully.`
        : 'Telegram packet delivered successfully.',
      target: targetChatId,
    };
  } catch (error) {
    return {
      delivered: false,
      status: 'failed',
      detail: error instanceof Error ? error.message : 'Unknown telegram transport error',
      target: targetChatId,
    };
  }
}

export async function fetchTelegramUpdates(limit = 20): Promise<TelegramFetchResult> {
  const credentials = await loadTelegramCredentials();
  if (!credentials.botToken) {
    return {
      ok: false,
      updates: [],
      detail: 'Telegram bot token is not configured locally.',
    };
  }

  const cursor = await loadTelegramCursor();
  const params = new URLSearchParams({
    timeout: '1',
    allowed_updates: JSON.stringify(['message']),
    limit: String(Math.max(1, Math.min(limit, 100))),
  });

  if (typeof cursor.nextOffset === 'number') {
    params.set('offset', String(cursor.nextOffset));
  }

  try {
    const response = await fetch(`https://api.telegram.org/bot${credentials.botToken}/getUpdates?${params.toString()}`, {
      cache: 'no-store',
    });

    if (!response.ok) {
      return {
        ok: false,
        updates: [],
        detail: `Telegram getUpdates returned HTTP ${response.status}`,
      };
    }

    const payload = await response.json() as {
      ok?: boolean;
      result?: TelegramUpdateEnvelope[];
      description?: string;
    };

    if (!payload.ok) {
      return {
        ok: false,
        updates: [],
        detail: payload.description || 'Telegram getUpdates did not return ok=true.',
      };
    }

    const updates = payload.result || [];
    const lastUpdateId = updates.length > 0 ? updates[updates.length - 1]?.update_id : cursor.lastUpdateId;
    return {
      ok: true,
      updates,
      lastUpdateId,
      detail: updates.length > 0 ? `${updates.length} update(s) fetched from Telegram.` : 'No fresh Telegram updates were available.',
    };
  } catch (error) {
    return {
      ok: false,
      updates: [],
      detail: error instanceof Error ? error.message : 'Unknown telegram polling error',
    };
  }
}

export async function loadTelegramCursor(): Promise<{ lastUpdateId?: number; nextOffset?: number }> {
  try {
    return JSON.parse(await fs.readFile(PATHS.TELEGRAM_CURSOR, 'utf-8')) as { lastUpdateId?: number; nextOffset?: number };
  } catch {
    return {};
  }
}

export async function saveTelegramCursor(lastUpdateId?: number): Promise<void> {
  if (typeof lastUpdateId !== 'number') {
    return;
  }

  await fs.mkdir(path.dirname(PATHS.TELEGRAM_CURSOR), { recursive: true });
  await fs.writeFile(
    PATHS.TELEGRAM_CURSOR,
    JSON.stringify({
      lastUpdateId,
      nextOffset: lastUpdateId + 1,
      updatedAt: new Date().toISOString(),
    }, null, 2),
    'utf-8',
  );
}

async function collectTelegramLogSignals(): Promise<{ entry?: string; time?: string; kind: 'sent' | 'failed' | 'queued' | 'unknown' }> {
  for (const candidate of TELEGRAM_LOG_CANDIDATES) {
    const content = await readTextFile(candidate);
    if (!content) continue;

    const lines = content.split('\n').filter(Boolean);
    for (let index = lines.length - 1; index >= 0; index -= 1) {
      const line = lines[index].trim();
      const time = extractTimestamp(line);

      if (line.includes('Delivery: sent') || line.includes('Telegram erfolgreich gesendet')) {
        return { entry: 'Outbound packet delivered', time, kind: 'sent' };
      }

      if (line.includes('Delivery: failed') || line.includes('Telegram-Fehler')) {
        return { entry: 'Outbound delivery failed', time, kind: 'failed' };
      }

      if (line.includes('Delivery: queued')) {
        return { entry: 'Outbound packet queued', time, kind: 'queued' };
      }
    }
  }

  return { kind: 'unknown' };
}

async function collectTelegramInboundSignals(): Promise<{ entry?: string; time?: string; kind: 'received' | 'unknown' }> {
  const content = await readTextFile(PATHS.TELEGRAM_INBOX);
  if (!content) {
    return { kind: 'unknown' };
  }

  const sections = content.split(/^###\s+/m).map((section) => section.trim()).filter(Boolean);
  for (let index = sections.length - 1; index >= 0; index -= 1) {
    const section = sections[index];
    const lines = section.split('\n').map((line) => line.trim());
    const summaryLine = lines.find((line) => line.startsWith('- Summary:'));
    if (!summaryLine) continue;

    const addedLine = lines.find((line) => line.startsWith('- Added:'));
    return {
      entry: summaryLine.replace(/^- Summary:\s*/, '').trim(),
      time: addedLine?.replace(/^- Added:\s*/, '').trim(),
      kind: 'received',
    };
  }

  return { kind: 'unknown' };
}

function extractTimestamp(value: string): string | undefined {
  const bracketMatch = value.match(/\[([^\]]+)\]/);
  if (bracketMatch) {
    return bracketMatch[1];
  }

  const inlineMatch = value.match(/\b\d{4}-\d{2}-\d{2}T[^\s]+/);
  if (inlineMatch) {
    return inlineMatch[0];
  }

  return undefined;
}

function buildTelegramText(title: string, message: string, priority?: string): string {
  const header = `*LIONCOM Relay*\n*${escapeTelegramMarkdown(title)}*`;
  const body = escapeTelegramMarkdown(message);
  const priorityLine = priority ? `\n_Priority:_ ${escapeTelegramMarkdown(priority)}` : '';
  return `${header}${priorityLine}\n\n${body}`.trim();
}

function escapeTelegramMarkdown(value: string): string {
  return value.replace(/([_\*\[\]\(\)~`>#+\-=|{}.!])/g, '\\$1');
}
