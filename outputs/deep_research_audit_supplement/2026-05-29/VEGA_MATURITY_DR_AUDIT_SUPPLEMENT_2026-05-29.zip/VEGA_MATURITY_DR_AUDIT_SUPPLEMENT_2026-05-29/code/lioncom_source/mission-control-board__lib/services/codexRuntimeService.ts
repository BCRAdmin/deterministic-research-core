import { promises as fs } from 'fs';

import { PATHS } from '../constants/paths';
import { parseRailBlocks, readRailContent } from './structuredRailService';

export interface CodexRuntimeSnapshot {
  schemaVersion: '1.1';
  updatedAt: string;
  state: 'idle' | 'attention' | 'working' | 'reporting';
  pendingOperatorMessages: number;
  queuedPackets: number;
  latestReference?: string;
  lastOperatorMessage?: {
    id: string;
    addedAt: string;
    summary: string;
  };
  lastCodexReply?: {
    id: string;
    addedAt: string;
    summary: string;
  };
  stalePendingMessages: boolean;
  oldestPendingMinutes?: number;
  oldestQueuedMinutes?: number;
  watcherRecommendation: string;
  detail: string;
}

export async function syncCodexRuntime(): Promise<CodexRuntimeSnapshot> {
  const [threadContent, inboxContent] = await Promise.all([
    readRailContent(PATHS.CODEX_CHAT_THREAD),
    readRailContent(PATHS.CODEX_INBOX),
  ]);

  const threadBlocks = parseRailBlocks(threadContent);
  const inboxBlocks = parseRailBlocks(inboxContent);
  const operatorMessages = threadBlocks.filter((block) => normalizeField(block.fields['Role']) === 'operator');
  const codexMessages = threadBlocks.filter((block) => normalizeField(block.fields['Role']) === 'codex');
  const pendingOperatorBlocks = operatorMessages.filter((block) => ['new', 'claimed'].includes(normalizeField(block.fields['Status'])));
  const actionablePendingOperatorBlocks = pendingOperatorBlocks.filter((block) => {
    const age = ageMinutes(block.fields['Added']);
    if (age !== undefined && age > 180) return false;
    return !hasLaterCodexReplyForReference(block, codexMessages);
  });
  const historicalPendingOperatorBlocks = pendingOperatorBlocks.filter((block) => !actionablePendingOperatorBlocks.includes(block));
  const pendingOperatorMessages = actionablePendingOperatorBlocks.filter((block) => normalizeField(block.fields['Status']) === 'new').length;
  const claimedPackets = inboxBlocks.filter((block) => ['claimed', 'working'].includes(normalizeField(block.fields['Status']))).length;
  const queuedPacketBlocks = inboxBlocks.filter((block) => ['queued', 'new', 'claimed', 'working'].includes(normalizeField(block.fields['Status'])));
  const queuedPackets = queuedPacketBlocks.length;
  const reportingPackets = inboxBlocks.filter((block) => ['answered', 'reported'].includes(normalizeField(block.fields['Status']))).length;
  const oldestPendingMinutes = oldestAgeMinutes(actionablePendingOperatorBlocks.map((block) => block.fields['Added']));
  const oldestQueuedMinutes = oldestAgeMinutes(queuedPacketBlocks.map((block) => block.fields['Added']));
  const stalePendingMessages = historicalPendingOperatorBlocks.length > 0 || (oldestPendingMinutes ?? 0) >= 10 || (oldestQueuedMinutes ?? 0) >= 15;

  let state: CodexRuntimeSnapshot['state'] = 'idle';
  let detail = 'Aktuell wartet kein Vega-Arbeitspaket.';
  let watcherRecommendation = 'Gerade ist kein Watcher-Eingriff nötig.';

  if (pendingOperatorMessages > 0) {
    state = 'attention';
    detail = 'Operator-Nachrichten warten in der Board-Schiene auf eine Vega-Bestätigung.';
    watcherRecommendation = 'Die wartende Operator-Nachricht bestätigen oder beantworten, bevor neue Pakete auflaufen.';
  } else if (claimedPackets > 0) {
    state = 'working';
    detail = 'Vega-Arbeit wurde gezogen und läuft aktiv durch den Board-Lifecycle.';
    watcherRecommendation = 'Den Antwortpfad im Board aktuell halten, damit gezogene Pakete nicht in stille Arbeit abdriften.';
  } else if (queuedPackets > 0) {
    state = 'attention';
    detail = 'Strukturierte Vega-Pakete warten darauf, gezogen oder beantwortet zu werden.';
    watcherRecommendation = 'Die wartenden Pakete prüfen und sie entweder ziehen oder explizit über die Board-Schiene schließen.';
  } else if (reportingPackets > 0 || codexMessages.length > 0) {
    state = 'reporting';
    detail = 'Vega hat kürzlich geantwortet und die Board-Schiene ist synchronisiert.';
    watcherRecommendation = 'Keine sofortige Intervention nötig. Auf das nächste Operator-Paket achten.';
  }

  if (state !== 'attention' && historicalPendingOperatorBlocks.length > 0 && queuedPackets === 0) {
    detail = 'Aktuell wartet kein Vega-Paket, aber in der Board-Historie liegen noch alte ungeklärte Operator-Nachrichten.';
    watcherRecommendation = 'Ein späterer Hygiene-Lauf kann die alten Board-Nachrichten archivieren oder beantworten, damit die Runtime-Wahrheit ruhig bleibt.';
  }

  if (stalePendingMessages) {
    const staleParts = [
      oldestPendingMinutes ? `älteste aktive Operator-Nachricht: ${oldestPendingMinutes}m` : null,
      oldestQueuedMinutes ? `ältestes wartendes Paket: ${oldestQueuedMinutes}m` : null,
      historicalPendingOperatorBlocks.length ? `alte ungeklärte Nachrichten: ${historicalPendingOperatorBlocks.length}` : null,
    ].filter(Boolean).join(' / ');
    detail = staleParts
      ? `${detail} Die Vega-Schiene wird älter (${staleParts}).`
      : `${detail} Die Vega-Schiene wird älter.`;
    watcherRecommendation = pendingOperatorMessages > 0 || queuedPackets > 0
      ? 'Das veraltete Vega-Paket jetzt bestätigen oder schließen, damit das Board die einzige verlässliche Steuerfläche bleibt.'
      : 'Aktuell blockiert kein Vega-Paket, aber alte Board-Historie sollte in einem separaten Hygiene-Lauf bereinigt werden.';
  }

  const runtime: CodexRuntimeSnapshot = {
    schemaVersion: '1.1',
    updatedAt: new Date().toISOString(),
    state,
    pendingOperatorMessages,
    queuedPackets,
    latestReference: operatorMessages[0]?.fields['Reference'] || codexMessages[0]?.fields['Reference'],
    lastOperatorMessage: actionablePendingOperatorBlocks[0] || operatorMessages[0]
      ? {
          id: (actionablePendingOperatorBlocks[0] || operatorMessages[0]).id,
          addedAt: (actionablePendingOperatorBlocks[0] || operatorMessages[0]).fields['Added'] || 'unknown',
          summary: (actionablePendingOperatorBlocks[0] || operatorMessages[0]).fields['Summary'] || (actionablePendingOperatorBlocks[0] || operatorMessages[0]).id,
        }
      : undefined,
    lastCodexReply: codexMessages[0]
      ? {
          id: codexMessages[0].id,
          addedAt: codexMessages[0].fields['Added'] || 'unknown',
          summary: codexMessages[0].fields['Summary'] || codexMessages[0].id,
        }
      : undefined,
    stalePendingMessages,
    oldestPendingMinutes,
    oldestQueuedMinutes,
    watcherRecommendation,
    detail,
  };

  await Promise.all([
    fs.writeFile(PATHS.CODEX_RUNTIME, JSON.stringify(runtime, null, 2) + '\n', 'utf-8'),
    fs.writeFile(PATHS.CODEX_REPORTS, renderCodexReports(codexMessages), 'utf-8'),
  ]);

  return runtime;
}

function renderCodexReports(codexMessages: ReturnType<typeof parseRailBlocks>): string {
  const header = '# Codex Reports\n\nAppend-only mirrored Codex reply rail derived from CODEX_CHAT_THREAD.\n\n';
  if (codexMessages.length === 0) {
    return header;
  }

  const blocks = codexMessages.map((block) => {
    const message = extractMessage(block.lines);
    return [
      `### ${block.id}`,
      `- Added: ${block.fields['Added'] || 'unknown'}`,
      `- Kind: response`,
      `- Status: ${block.fields['Status'] || 'reported'}`,
      `- Reference: ${block.fields['Reference'] || 'None supplied'}`,
      `- Summary: ${block.fields['Summary'] || block.id}`,
      '- Message:',
      ...message.split('\n').map((line) => `> ${line}`),
      '',
    ].join('\n');
  });

  return `${header}${blocks.join('\n')}`;
}

function extractMessage(lines: string[]): string {
  const messageLines: string[] = [];
  let capture = false;

  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('- Message:')) {
      capture = true;
      const rest = trimmed.replace(/^- Message:\s*/, '');
      if (rest) messageLines.push(rest);
      continue;
    }

    if (!capture) continue;
    if (trimmed.startsWith('> ')) {
      messageLines.push(trimmed.slice(2));
    }
  }

  return messageLines.join('\n').trim() || 'No reply text captured.';
}

function normalizeField(value?: string): string {
  return value?.trim().toLowerCase() || '';
}

function oldestAgeMinutes(values: Array<string | undefined>): number | undefined {
  const ages = values
    .map((value) => ageMinutes(value))
    .filter((value): value is number => typeof value === 'number' && Number.isFinite(value));

  if (ages.length === 0) return undefined;
  return Math.max(...ages);
}

function ageMinutes(value?: string): number | undefined {
  if (!value) return undefined;
  const parsed = new Date(value).getTime();
  if (Number.isNaN(parsed)) return undefined;
  return Math.max(0, Math.floor((Date.now() - parsed) / 60000));
}

function hasLaterCodexReplyForReference(
  operatorBlock: ReturnType<typeof parseRailBlocks>[number],
  codexMessages: ReturnType<typeof parseRailBlocks>,
): boolean {
  const reference = normalizeField(operatorBlock.fields['Reference']);
  if (!reference) return false;

  const operatorAdded = Date.parse(operatorBlock.fields['Added'] || '');
  if (!Number.isFinite(operatorAdded)) return false;

  return codexMessages.some((block) => {
    const codexReference = normalizeField(block.fields['Reference']);
    if (codexReference !== reference) return false;
    const codexAdded = Date.parse(block.fields['Added'] || '');
    if (!Number.isFinite(codexAdded)) return false;
    return codexAdded >= operatorAdded;
  });
}
