#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const LIONCOM_ROOT = path.resolve(APP_ROOT, '..');
const ROOM16_APP_ROOT = '/Users/BjornRosinger/Documents/DreamFactory/Project-Intelligence-Graph/company-dossier-lab/room16-app';
const MATERIALBEDARF_ROOT = '/Users/BjornRosinger/Dreamfactory/utility webseite/materialbedarf-rechner.de';
const OUT_DIR = path.join(APP_ROOT, '.runtime', 'golden-baseline');
const DASHBOARD_DATA_DIR = path.join(LIONCOM_ROOT, 'dashboard', 'data');
const RUNTIME_DASHBOARD_DATA_DIR = path.join(
  process.env.HOME || '',
  'Library',
  'Application Support',
  'LIONCOM',
  'runtime-workspace',
  'dashboard',
  'data',
);
const SCHEDULE_INTERVAL_HOURS = Number(process.env.LIONCOM_GOLDEN_BASELINE_INTERVAL_HOURS || 12);
const STALE_AFTER_HOURS = Number(process.env.LIONCOM_GOLDEN_BASELINE_STALE_AFTER_HOURS || 14);
const CRITICAL_AFTER_HOURS = Number(process.env.LIONCOM_GOLDEN_BASELINE_CRITICAL_AFTER_HOURS || 24);
const CONTROL_PLANE_BASE_URL = (process.env.LIONCOM_BASE_URL || 'http://127.0.0.1:4107').replace(/\/$/, '');
const ROOM16_BASE_URL = (process.env.ROOM16_APP_BASE_URL || 'http://127.0.0.1:4516').replace(/\/$/, '');
const SKIP_NETWORK = process.argv.includes('--skip-network');
const FAST = process.argv.includes('--fast');
let managedRoom16Server = null;

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function tail(value, max = 3000) {
  return String(value || '').slice(-max);
}

function runStep(id, label, command, args, options = {}) {
  const startedAt = new Date();
  const result = spawnSync(command, args, {
    cwd: options.cwd,
    env: { ...process.env, ...options.env },
    encoding: 'utf8',
    timeout: options.timeoutMs || 180_000,
    maxBuffer: 1024 * 1024 * 20,
  });
  const timedOut = result.error?.code === 'ETIMEDOUT';
  const status = !timedOut && result.status === 0 ? 'pass' : 'fail';
  return {
    id,
    label,
    status,
    command: [command, ...args],
    cwd: options.cwd,
    startedAt: startedAt.toISOString(),
    completedAt: new Date().toISOString(),
    elapsedMs: Date.now() - startedAt.getTime(),
    exitCode: result.status,
    signal: result.signal,
    error: timedOut ? `Timed out after ${options.timeoutMs || 180_000}ms` : result.error?.message || null,
    stdoutTail: tail(result.stdout),
    stderrTail: tail(result.stderr),
  };
}

function npmStep(id, label, cwd, script, options = {}) {
  return runStep(id, label, 'npm', ['run', script], { cwd, ...options });
}

function sleepMs(ms) {
  const marker = new Int32Array(new SharedArrayBuffer(4));
  Atomics.wait(marker, 0, 0, ms);
}

function room16HealthOk() {
  try {
    const result = spawnSync('curl', ['-fsS', `${ROOM16_BASE_URL}/api/health`], {
      encoding: 'utf8',
      timeout: 5_000,
      maxBuffer: 1024 * 1024,
    });
    return result.status === 0 && /"ok"\s*:\s*true/.test(result.stdout || '');
  } catch {
    return false;
  }
}

function room16Port() {
  try {
    return new URL(ROOM16_BASE_URL).port || '4516';
  } catch {
    return '4516';
  }
}

function room16ServerReadyStep() {
  const startedAt = new Date();
  if (room16HealthOk()) {
    return {
      id: 'room16_server_ready',
      label: 'Room 16 Local Server Ready',
      status: 'pass',
      command: ['curl', '-fsS', `${ROOM16_BASE_URL}/api/health`],
      cwd: ROOM16_APP_ROOT,
      startedAt: startedAt.toISOString(),
      completedAt: new Date().toISOString(),
      elapsedMs: Date.now() - startedAt.getTime(),
      exitCode: 0,
      signal: null,
      error: null,
      stdoutTail: 'existing server healthy',
      stderrTail: '',
    };
  }

  ensureDir(OUT_DIR);
  const logPath = path.join(OUT_DIR, 'room16-managed-server.log');
  const log = fs.openSync(logPath, 'a');
  managedRoom16Server = spawn(process.execPath, ['server.mjs', '--static', '--port', room16Port()], {
    cwd: ROOM16_APP_ROOT,
    stdio: ['ignore', log, log],
    detached: false,
  });

  for (let attempt = 0; attempt < 40; attempt += 1) {
    if (room16HealthOk()) {
      return {
        id: 'room16_server_ready',
        label: 'Room 16 Local Server Ready',
        status: 'pass',
        command: [process.execPath, 'server.mjs', '--static', '--port', room16Port()],
        cwd: ROOM16_APP_ROOT,
        startedAt: startedAt.toISOString(),
        completedAt: new Date().toISOString(),
        elapsedMs: Date.now() - startedAt.getTime(),
        exitCode: 0,
        signal: null,
        error: null,
        stdoutTail: `managed server pid ${managedRoom16Server.pid}; log=${logPath}`,
        stderrTail: '',
      };
    }
    sleepMs(500);
  }

  return {
    id: 'room16_server_ready',
    label: 'Room 16 Local Server Ready',
    status: 'fail',
    command: [process.execPath, 'server.mjs', '--static', '--port', room16Port()],
    cwd: ROOM16_APP_ROOT,
    startedAt: startedAt.toISOString(),
    completedAt: new Date().toISOString(),
    elapsedMs: Date.now() - startedAt.getTime(),
    exitCode: 1,
    signal: null,
    error: `Room 16 server did not become healthy at ${ROOM16_BASE_URL}`,
    stdoutTail: `log=${logPath}`,
    stderrTail: '',
  };
}

function cleanupManagedRoom16Server() {
  if (!managedRoom16Server?.pid) return;
  try {
    managedRoom16Server.kill();
  } catch {
    // Best-effort cleanup; the baseline report has already captured the step result.
  }
}

function addHours(iso, hours) {
  const time = new Date(iso).getTime();
  if (!Number.isFinite(time)) return null;
  return new Date(time + hours * 60 * 60 * 1000).toISOString();
}

function baselineFreshness(createdAt, verdict) {
  if (!createdAt) return 'unknown';
  if (verdict === 'fail') return 'failed';
  const time = new Date(createdAt).getTime();
  if (!Number.isFinite(time)) return 'unknown';
  const ageHours = (Date.now() - time) / 3_600_000;
  if (ageHours >= CRITICAL_AFTER_HOURS) return 'critical';
  if (ageHours >= STALE_AFTER_HOURS) return 'stale';
  return 'fresh';
}

function buildDashboardStatus(report, jsonPath, mdPath) {
  const failedSteps = report.steps.filter((step) => step.status !== 'pass').map((step) => step.id);
  const generatedAt = report.createdAt;
  const freshness = baselineFreshness(generatedAt, report.verdict);
  const ageHours = generatedAt
    ? Math.max(0, Math.round(((Date.now() - new Date(generatedAt).getTime()) / 3_600_000) * 10) / 10)
    : null;
  const nextDueAt = addHours(generatedAt, SCHEDULE_INTERVAL_HOURS);
  const staleAt = addHours(generatedAt, STALE_AFTER_HOURS);
  const criticalAt = addHours(generatedAt, CRITICAL_AFTER_HOURS);
  const nextAction = report.verdict === 'fail'
    ? 'Failed steps reparieren und Golden Baseline erneut laufen lassen.'
    : freshness === 'critical'
      ? 'Golden Baseline ist kritisch veraltet und muss sofort neu laufen.'
      : freshness === 'stale'
        ? 'Golden Baseline ist faellig und sollte neu laufen.'
        : 'Keine Aktion. Gate ist frisch.';

  return {
    generatedAt,
    verdict: report.verdict,
    mode: report.mode,
    freshness,
    ageHours,
    nextDueAt,
    staleAt,
    criticalAt,
    failedSteps,
    failedCount: failedSteps.length,
    stepCount: report.steps.length,
    passedSteps: report.steps.filter((step) => step.status === 'pass').length,
    reportJsonPath: jsonPath,
    reportMarkdownPath: mdPath,
    nextAction,
    schedule: {
      intervalHours: SCHEDULE_INTERVAL_HOURS,
      staleAfterHours: STALE_AFTER_HOURS,
      criticalAfterHours: CRITICAL_AFTER_HOURS,
      dueScript: 'npm run baseline:golden:due',
      launchAgentLabel: 'com.lioncom.golden-baseline',
    },
  };
}

function writeReports(report) {
  ensureDir(OUT_DIR);
  ensureDir(DASHBOARD_DATA_DIR);
  const jsonPath = path.join(OUT_DIR, 'latest-golden-baseline.json');
  const mdPath = path.join(OUT_DIR, 'latest-golden-baseline.md');
  fs.writeFileSync(jsonPath, JSON.stringify(report, null, 2), 'utf8');
  fs.writeFileSync(
    mdPath,
    [
      '# DreamFactory Golden Baseline',
      '',
      `Created: ${report.createdAt}`,
      `Verdict: ${report.verdict}`,
      `Mode: ${report.mode}`,
      '',
      '## Steps',
      '',
      ...report.steps.map((step) => [
        `### ${step.status === 'pass' ? 'PASS' : 'FAIL'} ${step.label}`,
        '',
        `- ID: \`${step.id}\``,
        `- Command: \`${step.command.join(' ')}\``,
        `- CWD: \`${step.cwd}\``,
        `- Exit: ${step.exitCode}`,
        step.stderrTail ? `- Stderr tail:\n\n\`\`\`text\n${step.stderrTail}\n\`\`\`` : '- Stderr tail: empty',
        ''
      ].join('\n')),
    ].join('\n'),
    'utf8',
  );
  const dashboardStatus = JSON.stringify(buildDashboardStatus(report, jsonPath, mdPath), null, 2);

  for (const dashboardDir of [DASHBOARD_DATA_DIR, RUNTIME_DASHBOARD_DATA_DIR]) {
    if (!dashboardDir) continue;
    ensureDir(dashboardDir);
    fs.writeFileSync(path.join(dashboardDir, 'golden_baseline_status.json'), dashboardStatus, 'utf8');
  }
  return { jsonPath, mdPath };
}

const steps = [];
steps.push(npmStep('lioncom_operator_go_health', 'LIONCOM Operator-Go Health', APP_ROOT, 'operator-go:health', { timeoutMs: 90_000 }));
steps.push(npmStep('lioncom_control_plane_v2_flight_pack', 'LIONCOM Control Plane V2 Flight Pack Refresh', APP_ROOT, 'control-plane-v2:flight-pack', {
  timeoutMs: 120_000,
  env: { LIONCOM_BASE_URL: CONTROL_PLANE_BASE_URL },
}));
steps.push(npmStep('lioncom_control_plane_v2', 'LIONCOM Control Plane V2 Verify', APP_ROOT, 'verify:control-plane-v2', { timeoutMs: 180_000 }));
steps.push(npmStep('lioncom_control_plane_v2_visual', 'LIONCOM Control Plane V2 Visual QA', APP_ROOT, 'verify:control-plane-v2:visual', {
  timeoutMs: 180_000,
  env: { LIONCOM_BASE_URL: CONTROL_PLANE_BASE_URL },
}));
steps.push(npmStep('quellwert_public_catalog_contract', 'Quellwert Public Catalog Contract', APP_ROOT, 'verify:quellwert-public-catalog-contract', { timeoutMs: 180_000 }));
steps.push(npmStep('quellwert_membership_preview', 'Quellwert Membership Preview Verify', APP_ROOT, 'verify:quellwert-membership-preview', {
  timeoutMs: 240_000,
  env: { LIONCOM_BASE_URL: CONTROL_PLANE_BASE_URL },
}));
steps.push(npmStep('lioncom_clean_dry', 'LIONCOM Cleaner Dry Run', APP_ROOT, 'clean:dry', { timeoutMs: 60_000 }));
steps.push(npmStep('lioncom_retention_clean_dry', 'LIONCOM Retention Cleaner Dry Run', APP_ROOT, 'clean:retention:dry', { timeoutMs: 60_000 }));

steps.push(room16ServerReadyStep());
if (!FAST) {
  steps.push(npmStep('room16_hardening_once', 'Room 16 Screenshot Hardening', ROOM16_APP_ROOT, 'hardening:once', {
    timeoutMs: 300_000,
    env: { ROOM16_APP_BASE_URL: ROOM16_BASE_URL },
  }));
}
steps.push(npmStep('room16_verify', 'Room 16 App Verify', ROOM16_APP_ROOT, 'verify', {
  timeoutMs: 120_000,
  env: {
    ROOM16_APP_BASE_URL: ROOM16_BASE_URL,
    ...(FAST ? { ROOM16_VERIFY_SKIP_HARDENING_STATE: '1' } : {}),
  },
}));
steps.push(npmStep('room16_report_machine', 'Room 16 Report Machine Verify', ROOM16_APP_ROOT, 'verify:report-machine', {
  timeoutMs: 120_000,
  env: { ROOM16_APP_BASE_URL: ROOM16_BASE_URL },
}));
steps.push(npmStep('room16_clean_dry', 'Room 16 Cleaner Dry Run', ROOM16_APP_ROOT, 'clean:dry', { timeoutMs: 60_000 }));
steps.push(npmStep('room16_retention_clean_dry', 'Room 16 Retention Cleaner Dry Run', ROOM16_APP_ROOT, 'clean:retention:dry', { timeoutMs: 60_000 }));

if (FAST) {
  steps.push(npmStep('materialbedarf_local_qa', 'Materialbedarf Local QA', MATERIALBEDARF_ROOT, 'check:qa', { timeoutMs: 180_000 }));
} else if (SKIP_NETWORK) {
  steps.push(npmStep('materialbedarf_build', 'Materialbedarf Build', MATERIALBEDARF_ROOT, 'build', { timeoutMs: 240_000 }));
  steps.push(npmStep('materialbedarf_check_export', 'Materialbedarf Export Check', MATERIALBEDARF_ROOT, 'check:export', { timeoutMs: 120_000 }));
  steps.push(npmStep('materialbedarf_check_qa', 'Materialbedarf QA', MATERIALBEDARF_ROOT, 'check:qa', { timeoutMs: 180_000 }));
} else {
  steps.push(npmStep('materialbedarf_monitor_baseline', 'Materialbedarf Build + QA + Live Monitoring', MATERIALBEDARF_ROOT, 'monitor:baseline', { timeoutMs: 360_000 }));
}
steps.push(npmStep('materialbedarf_clean_dry', 'Materialbedarf Cleaner Dry Run', MATERIALBEDARF_ROOT, 'clean:dry', { timeoutMs: 60_000 }));

const report = {
  createdAt: new Date().toISOString(),
  mode: FAST ? 'fast' : SKIP_NETWORK ? 'full-local' : 'full-with-readonly-network',
  verdict: steps.every((step) => step.status === 'pass') ? 'pass' : 'fail',
  steps,
};
const paths = writeReports(report);
cleanupManagedRoom16Server();
console.log(JSON.stringify({ verdict: report.verdict, ...paths, failedSteps: steps.filter((step) => step.status !== 'pass').map((step) => step.id) }, null, 2));
if (report.verdict !== 'pass') process.exitCode = 1;
