#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';

const workspaceRoot = process.env.VIVI_WORKSPACE_ROOT
  || process.env.LIONCOM_WORKSPACE_ROOT
  || '/Users/BjornRosinger/Library/Application Support/LIONCOM/runtime-workspace';
const verifyOnly = process.argv.includes('--verify');
const now = new Date().toISOString();
const maxAgeMs = Number(process.env.LIONCOM_MATERIALIZED_FOLLOWUP_DEDUPE_HOURS || 24) * 60 * 60 * 1000;
const queuePath = path.join(workspaceRoot, 'VIVI_COMMAND_QUEUE.md');
const claimsPath = path.join(workspaceRoot, 'TASK_CLAIMS.md');

function readText(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch {
    return '';
  }
}

function parseRail(content) {
  const marker = content.search(/^###\s+/m);
  const header = marker >= 0 ? content.slice(0, marker) : content;
  const body = marker >= 0 ? content.slice(marker) : '';
  const blocks = body
    .split(/^###\s+/m)
    .map((section) => section.trim())
    .filter(Boolean)
    .map((section, index) => {
      const [headline, ...lines] = section.split('\n');
      const fields = {};
      for (const line of lines) {
        const match = line.trim().match(/^\-\s*([^:]+):\s*(.*)$/);
        if (match) fields[match[1].trim()] = match[2].trim();
      }
      return {
        id: headline.trim(),
        index,
        lines,
        fields,
        raw: section,
      };
    });
  return { header, blocks };
}

function serializeRail(header, blocks) {
  const normalizedHeader = header.endsWith('\n\n') ? header : header.endsWith('\n') ? `${header}\n` : `${header}\n\n`;
  return `${normalizedHeader}${blocks.map((block) => `### ${block.id}\n${block.lines.join('\n').trimEnd()}`).join('\n\n')}\n`;
}

function normalized(value) {
  return String(value || '').trim().replace(/\s+/g, ' ').toLowerCase();
}

function isTerminalStatus(value) {
  return ['answered', 'archived', 'closed', 'completed', 'done', 'parked', 'released', 'reported', 'resolved'].includes(normalized(value));
}

function addedTime(block) {
  const raw = block.fields.Added || block.fields['Claimed At'] || '';
  const parsed = Date.parse(raw);
  return Number.isFinite(parsed) ? parsed : 0;
}

function parseActiveClaimTaskIds(content) {
  const active = new Set();
  const parsed = parseRail(content);
  for (const block of parsed.blocks) {
    const state = normalized(block.fields.State);
    const stale = normalized(block.fields.Stale);
    if ((state === 'working' || state === 'claimed') && stale !== 'yes') {
      const taskId = block.fields['Task ID'];
      if (taskId) active.add(taskId);
    }
  }
  return active;
}

function updateField(lines, field, value) {
  const prefix = `- ${field}:`;
  const next = [...lines];
  const index = next.findIndex((line) => line.trim().startsWith(prefix));
  if (index >= 0) {
    next[index] = `${prefix} ${value}`;
    return next;
  }
  const rawIndex = next.findIndex((line) => line.trim().startsWith('- Raw Request:'));
  const insertAt = rawIndex >= 0 ? rawIndex : next.length;
  next.splice(insertAt, 0, `${prefix} ${value}`);
  return next;
}

function fieldsFromLines(lines) {
  const fields = {};
  for (const line of lines) {
    const match = line.trim().match(/^\-\s*([^:]+):\s*(.*)$/);
    if (match) fields[match[1].trim()] = match[2].trim();
  }
  return fields;
}

function isMaterializedFollowup(block) {
  return normalized(block.fields.Source) === 'vivi report materializer'
    || block.raw.includes('- Source: Vivi Report Materializer');
}

function buildGroups(blocks) {
  const groups = new Map();
  for (const block of blocks) {
    if (!isMaterializedFollowup(block)) continue;
    const title = normalized(block.fields.Title);
    if (!title) continue;
    const added = addedTime(block);
    const key = `${title}`;
    const entry = { block, added };
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(entry);
  }
  return Array.from(groups.entries())
    .map(([title, entries]) => ({
      title,
      entries: entries
        .filter((entry) => entry.added > 0)
        .sort((a, b) => a.added - b.added),
    }))
    .filter((group) => group.entries.length > 1);
}

function duplicateClusters(entries) {
  const clusters = [];
  for (const entry of entries) {
    const latest = clusters[clusters.length - 1];
    if (!latest || entry.added - latest[latest.length - 1].added > maxAgeMs) {
      clusters.push([entry]);
    } else {
      latest.push(entry);
    }
  }
  return clusters.filter((cluster) => cluster.length > 1);
}

function chooseKeeper(cluster, activeTaskIds) {
  const activeEntries = cluster.filter((entry) => activeTaskIds.has(entry.block.id));
  if (activeEntries.length === 1) return activeEntries[0];
  return cluster.reduce((keeper, entry) => (entry.added > keeper.added ? entry : keeper), cluster[0]);
}

function reconcile() {
  if (!fs.existsSync(queuePath)) {
    return { ok: true, workspaceRoot, verifyOnly, checkedAt: now, changed: 0, closed: [], unresolved: [], path: queuePath };
  }

  const parsed = parseRail(readText(queuePath));
  const activeTaskIds = parseActiveClaimTaskIds(readText(claimsPath));
  const closed = [];
  const unresolved = [];
  const changedById = new Map();

  for (const group of buildGroups(parsed.blocks)) {
    for (const cluster of duplicateClusters(group.entries)) {
      const activeEntries = cluster.filter((entry) => activeTaskIds.has(entry.block.id));
      if (activeEntries.length > 1) {
        unresolved.push({
          title: group.title,
          reason: 'mehrere aktive Claims mit gleichem materialisiertem Titel',
          ids: activeEntries.map((entry) => entry.block.id),
        });
        continue;
      }

      const keeper = chooseKeeper(cluster, activeTaskIds);
      for (const entry of cluster) {
        const block = entry.block;
        if (block.id === keeper.block.id || isTerminalStatus(block.fields.Status)) continue;
        if (activeTaskIds.has(block.id)) {
          unresolved.push({
            title: group.title,
            reason: 'aktiver Claim wird nicht automatisch geschlossen',
            ids: [block.id],
            keeper: keeper.block.id,
          });
          continue;
        }

        let lines = updateField(block.lines, 'Status', 'reported');
        lines = updateField(lines, 'Closed At', now);
        lines = updateField(lines, 'Duplicate Of', keeper.block.id);
        lines = updateField(
          lines,
          'Resolution',
          'Geschlossen als wiederholter materialisierter Vivi-Folgeauftrag mit gleichem Titel innerhalb des Dedupe-Fensters.',
        );
        lines = updateField(
          lines,
          'Evidence',
          'scripts/materialize_vivi_report_next_task.py verhindert frische Titelduplikate; dieser ältere offene Queue-Block bleibt als Audit-Spur erhalten.',
        );
        changedById.set(block.id, { ...block, lines, fields: fieldsFromLines(lines) });
        closed.push({
          id: block.id,
          title: block.fields.Title || group.title,
          duplicateOf: keeper.block.id,
          previousStatus: block.fields.Status || 'unknown',
        });
      }
    }
  }

  const blocks = parsed.blocks.map((block) => changedById.get(block.id) || block);
  if (!verifyOnly && changedById.size > 0) {
    fs.writeFileSync(queuePath, serializeRail(parsed.header, blocks), 'utf8');
  }

  const openDuplicateGroups = [];
  for (const group of buildGroups(blocks)) {
    for (const cluster of duplicateClusters(group.entries)) {
      const open = cluster
        .map((entry) => entry.block)
        .filter((block) => !isTerminalStatus(block.fields.Status));
      if (open.length > 1) {
        openDuplicateGroups.push({
          title: group.title,
          ids: open.map((block) => block.id),
          statuses: open.map((block) => block.fields.Status || 'unknown'),
        });
      }
    }
  }

  return {
    ok: unresolved.length === 0 && openDuplicateGroups.length === 0,
    workspaceRoot,
    verifyOnly,
    checkedAt: now,
    dedupeWindowHours: maxAgeMs / 60 / 60 / 1000,
    changed: verifyOnly ? 0 : changedById.size,
    closed: verifyOnly ? [] : closed,
    wouldClose: verifyOnly ? closed : [],
    unresolved,
    openDuplicateGroups,
  };
}

const result = reconcile();
console.log(JSON.stringify(result, null, 2));
if (!result.ok) process.exit(1);
