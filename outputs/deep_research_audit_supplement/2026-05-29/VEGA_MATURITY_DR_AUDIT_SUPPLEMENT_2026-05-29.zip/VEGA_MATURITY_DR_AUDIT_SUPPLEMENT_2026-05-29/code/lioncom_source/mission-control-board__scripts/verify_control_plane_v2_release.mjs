#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const appRoot = path.resolve(scriptDir, '..');
const baseUrl = (process.env.LIONCOM_BASE_URL || 'http://127.0.0.1:4107').replace(/\/$/, '');
const failures = [];
const warnings = [];
const steps = [];

const releaseTextFiles = [
  'components/audit-timeline.tsx',
  'components/automation-list.tsx',
  'components/backlog-list.tsx',
  'components/dispatch-composer.tsx',
  'components/sidebar-nav.tsx',
  'components/overview-page.tsx',
  'components/telemetry-page.tsx',
  'components/vivi-chat-console.tsx',
  'components/vivi-command-page.tsx',
  'components/vega-tech-cell-page.tsx',
  'components/workspace-list.tsx',
  'components/queue-overview.tsx',
].map((file) => path.join(appRoot, file));

const forbiddenReleaseCopy = [
  /kommt später/i,
  /werden später/i,
  /wird später/i,
  /künftig/i,
  /kein Dummy/i,
  /\bDummy\b/i,
  /Mockup/i,
  /Roh-JSON/i,
  /raw JSON/i,
  /interne JSON-Payloads/i,
  /internen Runner-Dumps/i,
];

function runStep(id, label, command, args, options = {}) {
  const startedAt = new Date();
  const result = spawnSync(command, args, {
    cwd: options.cwd || appRoot,
    env: { ...process.env, ...options.env },
    encoding: 'utf8',
    timeout: options.timeoutMs || 300_000,
    maxBuffer: 1024 * 1024 * 30,
  });
  const ok = result.status === 0 && !result.error;
  const step = {
    id,
    label,
    ok,
    command: [command, ...args].join(' '),
    cwd: options.cwd || appRoot,
    elapsedMs: Date.now() - startedAt.getTime(),
    exitCode: result.status,
    error: result.error?.message || null,
    stdoutTail: tail(result.stdout),
    stderrTail: tail(result.stderr),
  };
  steps.push(step);
  if (!ok) failures.push({ name: label, detail: step.stderrTail || step.stdoutTail || step.error || 'failed' });
  return ok;
}

function runShellStep(id, label, shellCommand, options = {}) {
  return runStep(id, label, 'bash', ['-lc', shellCommand], options);
}

function tail(value, max = 2600) {
  return String(value || '').slice(-max);
}

function scanReleaseCopy() {
  const hits = [];
  for (const filePath of releaseTextFiles) {
    if (!fs.existsSync(filePath)) {
      hits.push(`${filePath}: fehlt`);
      continue;
    }
    const content = fs.readFileSync(filePath, 'utf8');
    for (const pattern of forbiddenReleaseCopy) {
      if (pattern.test(content)) {
        hits.push(`${path.relative(appRoot, filePath)}: ${pattern.source}`);
      }
    }
  }

  if (hits.length > 0) {
    failures.push({ name: 'release copy ohne future-/dummy-sprache', detail: hits.join('; ') });
  }
  return hits;
}

function latestGoldenBaselineIsFresh() {
  const reportPath = path.join(appRoot, '.runtime', 'golden-baseline', 'latest-golden-baseline.json');
  if (!fs.existsSync(reportPath)) return { ok: false, detail: 'kein Golden-Baseline-Report vorhanden' };

  try {
    const report = JSON.parse(fs.readFileSync(reportPath, 'utf8'));
    const ageMs = Date.now() - Date.parse(report.createdAt || '');
    const maxAgeMs = Number(process.env.LIONCOM_RELEASE_BASELINE_MAX_AGE_HOURS || 12) * 60 * 60 * 1000;
    const visualStep = Array.isArray(report.steps)
      ? report.steps.find((step) => step.id === 'lioncom_control_plane_v2_visual')
      : null;
    const ok = report.verdict === 'pass'
      && report.mode === 'fast'
      && Number.isFinite(ageMs)
      && ageMs <= maxAgeMs
      && visualStep?.status === 'pass';
    return {
      ok,
      detail: ok
        ? `fresh pass @ ${report.createdAt}`
        : `verdict=${report.verdict}; mode=${report.mode}; ageMs=${Number.isFinite(ageMs) ? ageMs : 'unknown'}; visual=${visualStep?.status || 'missing'}`,
    };
  } catch (error) {
    return { ok: false, detail: error instanceof Error ? error.message : String(error) };
  }
}

async function fetchJson(pathname) {
  const response = await fetch(`${baseUrl}${pathname}`, {
    cache: 'no-store',
    signal: AbortSignal.timeout(10_000),
  });
  const text = await response.text();
  let body = null;
  try {
    body = JSON.parse(text);
  } catch {
    failures.push({ name: `${pathname} JSON`, detail: text.slice(0, 500) });
  }
  return { status: response.status, body };
}

async function waitForHealth() {
  for (let attempt = 0; attempt < 15; attempt += 1) {
    try {
      const health = await fetchJson('/api/health');
      if (health.status === 200 && (health.body?.overall === 'healthy' || health.body?.status === 'ok')) {
        return true;
      }
    } catch {
      // Retry below.
    }
    await new Promise((resolve) => setTimeout(resolve, 1000));
  }
  failures.push({ name: 'runtime health', detail: `${baseUrl}/api/health nicht healthy` });
  return false;
}

async function verifyLiveContracts() {
  const root = await fetch(`${baseUrl}/`, {
    cache: 'no-store',
    redirect: 'manual',
    signal: AbortSignal.timeout(10_000),
  });
  const rootLocation = root.headers.get('location') || '';
  if (!(root.status >= 300 && root.status < 400 && rootLocation.includes('/control-plane-v2'))) {
    failures.push({ name: 'v2 default route', detail: `HTTP ${root.status}; location=${rootLocation || 'missing'}` });
  }

  const snapshot = await fetchJson('/api/control-plane-v2');
  if (snapshot.status !== 200) {
    failures.push({ name: 'control-plane-v2 api', detail: `HTTP ${snapshot.status}` });
    return;
  }
  const data = snapshot.body;
  const contracts = [
    ['live source', data?.source === 'live', `source=${data?.source}`],
    ['vivi loop sichtbar', Boolean(data?.operatorLoopStatus?.state), data?.operatorLoopStatus?.state || 'missing'],
    ['quality gate frei oder sichtbar', Boolean(data?.operatorLoopStatus?.qualityGate?.label), data?.operatorLoopStatus?.qualityGate?.label || 'missing'],
    ['missionen vorhanden', Array.isArray(data?.missions) && data.missions.length > 0, `${data?.missions?.length || 0}`],
    ['audit events vorhanden', Array.isArray(data?.auditEvents) && data.auditEvents.length > 0, `${data?.auditEvents?.length || 0}`],
    ['activity signals vorhanden', Array.isArray(data?.activitySignals) && data.activitySignals.length > 0, `${data?.activitySignals?.length || 0}`],
  ];
  for (const [name, ok, detail] of contracts) {
    if (!ok) failures.push({ name, detail });
  }
  if (data?.globalStatus?.posture !== 'STABIL') {
    warnings.push({ name: 'systemhaltung', detail: `posture=${data?.globalStatus?.posture}; echte Arbeitslage, kein Release-Blocker` });
  }

  const audit = await fetchJson('/api/control-plane-v2/audit');
  if (audit.status !== 200) {
    failures.push({ name: 'system audit api', detail: `HTTP ${audit.status}` });
  } else if (audit.body?.overall === 'critical') {
    failures.push({ name: 'system audit critical', detail: JSON.stringify(audit.body).slice(0, 1000) });
  }

  const viviChat = await fetchJson('/api/vivi-chat');
  if (viviChat.status !== 200 || !Array.isArray(viviChat.body?.sessions)) {
    failures.push({ name: 'vivi chat lifecycle api', detail: `HTTP ${viviChat.status}` });
  }
}

async function main() {
  const textHits = scanReleaseCopy();
  if (textHits.length > 0) {
    printResult();
    process.exitCode = 1;
    return;
  }

  runStep('build', 'Next Build + Standalone Preflight', 'npm', ['run', 'build'], { timeoutMs: 420_000 });
  if (failures.length === 0) {
    runStep('sync-live', 'Desktop Live Sync', 'npm', ['run', 'desktop:sync-live'], { timeoutMs: 180_000 });
    runShellStep('runtime-sync', 'Runtime Workspace Sync', 'bash ../scripts/sync_runtime_workspace.sh', { cwd: appRoot, timeoutMs: 120_000 });
    runShellStep('restart-runtime', 'Local Control Plane Restart', 'launchctl kickstart -k gui/$(id -u)/com.lioncom.local-control-plane', { timeoutMs: 60_000 });
    await waitForHealth();
  }
  if (failures.length === 0) {
    await verifyLiveContracts();
  }
  if (failures.length === 0) {
    runStep('vivi-model-route', 'Vivi Model Route Probe', 'npm', ['run', 'vivi:model-route'], { timeoutMs: 120_000 });
  }
  if (failures.length === 0) {
    runStep('flight-pack-prehealth', 'Control Plane V2 Flight Pack Pre-Health Refresh', 'npm', ['run', 'control-plane-v2:flight-pack'], { timeoutMs: 120_000 });
  }
  if (failures.length === 0) {
    runStep('vivi-night-health', 'Vivi Night Run Health', 'npm', ['run', 'vivi:night-health'], { timeoutMs: 120_000 });
  }
  if (failures.length === 0) {
    runStep('vivi-night-watchdog', 'Vivi Night Run Watchdog', 'npm', ['run', 'vivi:night-watchdog'], { timeoutMs: 120_000 });
  }
  if (failures.length === 0) {
    runStep('vivi-session-health', 'Vivi Session Lifecycle Health', 'npm', ['run', 'vivi:session-health'], { timeoutMs: 120_000 });
  }
  if (failures.length === 0) {
    runStep('vivi-flight-local', 'Vivi Flight Local Acceptance', 'npm', ['run', 'vivi:flight-local'], { timeoutMs: 240_000 });
  }
  if (failures.length === 0) {
    runStep('vivi-skill-registry', 'Vivi Skill Registry Health', 'npm', ['run', 'vivi:skill-registry'], { timeoutMs: 120_000 });
  }
  if (failures.length === 0) {
    runStep('vivi-capability-router', 'Vivi Capability Router Health', 'npm', ['run', 'vivi:capability-router'], { timeoutMs: 120_000 });
  }
  if (failures.length === 0) {
    runStep('vivi-skill-runtime', 'Vivi Skill Runtime Health', 'npm', ['run', 'vivi:skill-runtime'], { timeoutMs: 180_000 });
  }
  if (failures.length === 0) {
    runStep('vivi-quality-gate-contract', 'Vivi Report Quality Gate Contract', 'npm', ['run', 'vivi:quality-gate-contract'], { timeoutMs: 120_000 });
  }
  if (failures.length === 0) {
    runStep('vivi-materializer-contract', 'Vivi Report Materializer Contract', 'npm', ['run', 'vivi:materializer-contract'], { timeoutMs: 120_000 });
  }
  if (failures.length === 0) {
    runStep('codex-loop-guards', 'Resolved Codex Loop Guard Hygiene', 'npm', ['run', 'verify:codex-loop-guards'], { timeoutMs: 120_000 });
  }
  if (failures.length === 0) {
    runStep('v2-dispatch-closures', 'Resolved V2 Dispatch Closure Hygiene', 'npm', ['run', 'verify:v2-dispatch-closures'], { timeoutMs: 120_000 });
  }
  if (failures.length === 0) {
    runStep('materialized-followups', 'Repeated Materialized Followup Hygiene', 'npm', ['run', 'verify:materialized-followups'], { timeoutMs: 120_000 });
  }
  if (failures.length === 0) {
    runStep('stale-refill-queue', 'Stale Autonomous Refill Queue Hygiene', 'npm', ['run', 'verify:stale-refill-queue'], { timeoutMs: 120_000 });
  }
  if (failures.length === 0) {
    runStep('flight-pack', 'Control Plane V2 Flight Pack', 'npm', ['run', 'control-plane-v2:flight-pack'], { timeoutMs: 120_000 });
  }
  if (failures.length === 0) {
    runStep('v2-api', 'Control Plane V2 API Verifier', 'npm', ['run', 'verify:control-plane-v2:mutating'], { timeoutMs: 240_000 });
  }
  if (failures.length === 0) {
    runStep('v2-visual', 'Control Plane V2 Visual Verifier', 'npm', ['run', 'verify:control-plane-v2:visual'], { timeoutMs: 240_000 });
  }
  if (failures.length === 0) {
    const baseline = latestGoldenBaselineIsFresh();
    if (baseline.ok) {
      steps.push({
        id: 'golden-fast-fresh',
        label: 'Golden Baseline Fast Freshness',
        ok: true,
        command: 'reuse latest fresh baseline',
        cwd: appRoot,
        elapsedMs: 0,
        exitCode: 0,
        error: null,
        stdoutTail: baseline.detail,
        stderrTail: '',
      });
    } else {
      runStep('golden-fast', 'Golden Baseline Fast', 'npm', ['run', 'baseline:golden:fast'], { timeoutMs: 900_000 });
    }
  }

  printResult();
  if (failures.length > 0) process.exitCode = 1;
}

function printResult() {
  const result = {
    ok: failures.length === 0,
    baseUrl,
    steps,
    warnings,
    failures,
    releaseState: failures.length === 0 ? 'freeze-ready' : 'blocked',
  };
  console.log(JSON.stringify(result, null, 2));
}

main().catch((error) => {
  failures.push({ name: 'release verifier exception', detail: error instanceof Error ? error.stack || error.message : String(error) });
  printResult();
  process.exitCode = 1;
});
