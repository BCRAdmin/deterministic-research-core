#!/usr/bin/env node

import { execFileSync } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const appRoot = path.resolve(__dirname, '..');
const lioncomRoot = path.resolve(appRoot, '..');
const workspaceRoot = process.env.LIONCOM_WORKSPACE_ROOT
  || process.env.VIVI_WORKSPACE_ROOT
  || path.join(process.env.HOME || '/Users/BjornRosinger', 'Library/Application Support/LIONCOM/runtime-workspace');
const baseUrl = (process.env.LIONCOM_BASE_URL || 'http://127.0.0.1:4107').replace(/\/$/, '');

const checks = [];

function record(status, name, detail = '') {
  checks.push({ status, name, detail });
}

function pass(name, detail) {
  record('pass', name, detail);
}

function warn(name, detail) {
  record('warn', name, detail);
}

function fail(name, detail) {
  record('fail', name, detail);
}

function readJson(filePath) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return null;
  }
}

async function fetchJson(pathname) {
  try {
    const response = await fetch(`${baseUrl}${pathname}`, {
      signal: AbortSignal.timeout(10_000),
      cache: 'no-store',
    });
    const body = await response.json();
    return { ok: response.ok, status: response.status, body };
  } catch (error) {
    return { ok: false, status: 0, body: null, error: error instanceof Error ? error.message : String(error) };
  }
}

function ageMinutes(value) {
  if (!value) return Number.POSITIVE_INFINITY;
  const time = Date.parse(value);
  if (!Number.isFinite(time)) return Number.POSITIVE_INFINITY;
  return Math.max(0, (Date.now() - time) / 60_000);
}

function minutesUntil(value) {
  if (!value) return Number.NEGATIVE_INFINITY;
  const time = Date.parse(value);
  if (!Number.isFinite(time)) return Number.NEGATIVE_INFINITY;
  return (time - Date.now()) / 60_000;
}

function sha256(filePath) {
  try {
    return crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex');
  } catch {
    return null;
  }
}

function commandOutput(command, args) {
  try {
    return execFileSync(command, args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();
  } catch (error) {
    return error instanceof Error ? error.message : String(error);
  }
}

function commandJson(command, args) {
  try {
    const output = execFileSync(command, args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();
    return { ok: true, output, body: JSON.parse(output) };
  } catch (error) {
    return {
      ok: false,
      output: '',
      body: null,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

function validateSkillFrontmatter(filePath) {
  try {
    const text = fs.readFileSync(filePath, 'utf8');
    const match = text.match(/^---\n([\s\S]*?)\n---/);
    if (!match) return { ok: false, detail: 'frontmatter fehlt' };
    const descriptionLine = match[1].split('\n').find((line) => line.startsWith('description:'));
    if (descriptionLine && descriptionLine.includes(': ') && !/^description:\s*["']/.test(descriptionLine)) {
      const value = descriptionLine.replace(/^description:\s*/, '');
      if (value.includes(':')) return { ok: false, detail: 'description mit Doppelpunkt ist nicht gequoted' };
    }
    return { ok: true, detail: 'frontmatter ok' };
  } catch (error) {
    return { ok: false, detail: error instanceof Error ? error.message : String(error) };
  }
}

function launchAgentReady(status) {
  if (/state = running/.test(status) || /state = spawn scheduled/.test(status)) {
    return true;
  }
  if (!/run interval =/.test(status)) {
    return false;
  }
  return !/last exit code = [1-9]\d*/.test(status);
}

function launchAgentDetail(status) {
  if (/state = running/.test(status)) return 'state=running';
  if (/state = spawn scheduled/.test(status)) return 'state=spawn scheduled';
  if (/run interval =/.test(status) && /last exit code = 0/.test(status)) return 'interval loaded; last exit=0';
  if (/run interval =/.test(status)) return 'interval loaded';
  return status.slice(0, 240);
}

async function main() {
  const controlPlane = await fetchJson('/api/control-plane-v2');
  if (!controlPlane.ok) {
    fail('control-plane-v2 api erreichbar', `HTTP ${controlPlane.status || 'failed'} ${controlPlane.error || ''}`.trim());
  } else {
    const data = controlPlane.body;
    const loop = data?.operatorLoopStatus;
    pass('control-plane-v2 api erreichbar', `source=${data?.source || 'unknown'}`);
    data?.source === 'live' ? pass('v2 nutzt live daten', 'source=live') : fail('v2 nutzt live daten', `source=${data?.source || 'missing'}`);
    if (loop?.state === 'running') {
      pass('vivi loop laeuft', loop.taskTitle || loop.summary || 'running');
    } else if (loop?.state === 'ready' || loop?.state === 'idle') {
      pass('vivi loop bereit', loop?.state);
    } else {
      warn('vivi loop nicht running', loop?.state || 'missing');
    }
    loop?.qualityGate?.ok !== false ? pass('aktiver quality gate status frei', loop?.qualityGate?.label || 'frei') : warn('aktiver quality gate status blockiert', `${loop?.qualityGate?.failureId || 'unknown'}: ${loop?.qualityGate?.failureDetail || ''}`);
  }

  const autonomy = await fetchJson('/api/autonomy');
  if (!autonomy.ok) {
    fail('autonomie api erreichbar', `HTTP ${autonomy.status || 'failed'} ${autonomy.error || ''}`.trim());
  } else {
    const data = autonomy.body;
    data?.readiness === 'ready'
      ? pass('autonomie readiness bereit', 'ready')
      : fail('autonomie readiness bereit', data?.readiness || 'missing');
    const staleClaims = Array.isArray(data?.staleClaims) ? data.staleClaims : [];
    staleClaims.length === 0
      ? pass('keine stale claims', '0')
      : fail('keine stale claims', staleClaims.map((claim) => claim?.id || claim?.taskId || 'unknown').join(', '));

    const viviState = data?.viviLoop?.state;
    const activeClaims = Array.isArray(data?.activeClaims) ? data.activeClaims : [];
    const activeViviClaims = activeClaims.filter((claim) => (
      claim?.agent === 'vivi'
      && ['claimed', 'working'].includes(String(claim?.claimState || '').toLowerCase())
    ));
    if (viviState === 'busy') {
      const leaseMargins = activeViviClaims.map((claim) => minutesUntil(claim?.leaseUntil));
      const minLease = leaseMargins.length > 0 ? Math.min(...leaseMargins) : Number.NEGATIVE_INFINITY;
      activeViviClaims.length > 0 && minLease >= 5
        ? pass('aktive vivi-claim lease stabil', `${activeViviClaims.length} Claim, min ${minLease.toFixed(1)} min`)
        : fail('aktive vivi-claim lease stabil', activeViviClaims.length > 0 ? `min ${minLease.toFixed(1)} min` : 'keine aktive Vivi-Claim trotz busy');
    } else {
      pass('aktive vivi-claim lease stabil', `vivi=${viviState || 'unknown'}`);
    }
  }

  const loopStatusPath = path.join(workspaceRoot, '.runtime/local-duo-loop-status.json');
  const loopStatus = readJson(loopStatusPath);
  if (!loopStatus) {
    fail('local duo loop status lesbar', loopStatusPath);
  } else {
    const heartbeatAge = ageMinutes(loopStatus.lastHeartbeatAt || loopStatus.updatedAt);
    heartbeatAge <= 10 ? pass('local duo loop heartbeat frisch', `${heartbeatAge.toFixed(1)} min`) : fail('local duo loop heartbeat frisch', `${heartbeatAge.toFixed(1)} min`);
    loopStatus.projectLane === 'lioncom-core' ? pass('vivi projektspur lioncom-core', loopStatus.projectLane) : fail('vivi projektspur lioncom-core', loopStatus.projectLane || 'missing');
    loopStatus.effectiveProvider && loopStatus.effectiveModel
      ? pass('vivi modellroute sichtbar', `${loopStatus.effectiveProvider}/${loopStatus.effectiveModel}`)
      : fail('vivi modellroute sichtbar', `${loopStatus.effectiveProvider || 'missing'}/${loopStatus.effectiveModel || 'missing'}`);
  }

  const sourceRunner = path.join(lioncomRoot, 'scripts/run_local_duo_loop.sh');
  const runtimeRunner = path.join(workspaceRoot, 'scripts/run_local_duo_loop.sh');
  const automationRunner = path.join(process.env.HOME || '/Users/BjornRosinger', 'Library/Application Support/LIONCOM/automation/run_local_duo_loop.sh');
  const hashes = [sourceRunner, runtimeRunner, automationRunner].map((filePath) => sha256(filePath));
  hashes.every(Boolean) && new Set(hashes).size === 1
    ? pass('runner-kopien synchron', hashes[0])
    : fail('runner-kopien synchron', JSON.stringify({ source: hashes[0], runtime: hashes[1], automation: hashes[2] }));

  const runnerText = fs.existsSync(sourceRunner) ? fs.readFileSync(sourceRunner, 'utf8') : '';
  runnerText.includes('recover_current_report_from_log_if_needed')
    ? pass('runner report-recovery rail aktiv', 'latest visible REPORT wins')
    : fail('runner report-recovery rail aktiv', 'recover_current_report_from_log_if_needed fehlt');
  runnerText.includes('skipped duplicate last-message REPORT')
    ? pass('runner report-dedupe rail aktiv', 'identische Reports werden nicht erneut persistiert')
    : fail('runner report-dedupe rail aktiv', 'Duplicate-Report-Schutz fehlt');
  runnerText.includes('autonomy_request_with_retry') && runnerText.includes('autonomy_complete_post_failed_after_retry')
    ? pass('runner autonomy-complete retry aktiv', 'Complete-POST wird nicht mehr single-shot behandelt')
    : fail('runner autonomy-complete retry aktiv', 'Complete-POST-Retry fehlt');
  runnerText.includes('qwen35_warmup_warn')
    ? pass('runner warmup-fehler kompakt', 'Qwen/LM-Studio-Warmup schreibt keine Python-Tracebacks mehr')
    : fail('runner warmup-fehler kompakt', 'Warmup-Fehler koennen noch rohe Tracebacks erzeugen');
  runnerText.includes('awaiting new operator input') && runnerText.includes('claim remains active') && runnerText.includes('Report-Closure-Lock')
    ? pass('runner idle-abschluss prompt-scharf', 'Korrektur- und Basis-Prompt blockieren await-input/claim-active Abschluesse')
    : fail('runner idle-abschluss prompt-scharf', 'Runner-Prompt enthaelt nicht die volle Idle-Verbotsliste');
  runnerText.includes('append_vivi_idle_closure_correction_report') && runnerText.includes('idle_closure_autocorrect')
    ? pass('runner idle-closure autocorrect aktiv', 'rein sprachliche Idle-Closure-Fails bekommen deterministischen Verifier-Folgebericht')
    : fail('runner idle-closure autocorrect aktiv', 'Deterministische Idle-Closure-Korrektur fehlt');
  runnerText.includes('vivi_quality_autocorrectable_failure_detected') && runnerText.includes('stale_model_truth_after_route_probe')
    ? pass('runner kombinierte vqg-autokorrektur aktiv', 'Idle-Closure plus stale model truth wird deterministisch korrigierbar')
    : fail('runner kombinierte vqg-autokorrektur aktiv', 'Bekannte Kombi aus idle closure und stale model truth bleibt zu bruechig');
  runnerText.includes('vivi_idle_autocorrect_report_exists_for_current_claim') && runnerText.includes('Supervisor Correction: idle_closure_autocorrect')
    ? pass('runner idle-autocorrect claim-scope sicher', 'Duplicate-Guard prueft Claim und Command-Ref im selben REPORT-Block')
    : fail('runner idle-autocorrect claim-scope sicher', 'Duplicate-Guard darf nicht global ueber alte Reports greifen');
  runnerText.includes('ensure_internal_source_gate_for_current_report') && runnerText.includes('Source Gate: not_applicable (internal backlog; no external factual claims)')
    ? pass('runner source-gate normalisierung aktiv', 'interne LIONCOM-Reports bekommen fehlendes Source Gate vor VQG ergaenzt')
    : fail('runner source-gate normalisierung aktiv', 'fehlendes Source Gate bleibt als wiederkehrender Format-Drift liegen');
  runnerText.includes('fresh vivi-model-route probe matches effective local provider/model')
    ? pass('runner modellwahrheit nutzt route-probe', 'fresh route probe fuehrt')
    : fail('runner modellwahrheit nutzt route-probe', 'Model-Verifikation-Lock ist veraltet');
  runnerText.includes('schreibe im REPORT exakt ein Feld wie `model_verification: needs_vega_review`')
    ? fail('runner alte requested-modellregel entfernt', 'alter needs_vega_review-Zwang noch vorhanden')
    : pass('runner alte requested-modellregel entfernt', 'kein alter needs_vega_review-Zwang');

  const qualityGateScript = path.join(lioncomRoot, 'scripts/vivi_report_quality_gate.py');
  const qualityGateText = fs.existsSync(qualityGateScript) ? fs.readFileSync(qualityGateScript, 'utf8') : '';
  qualityGateText.includes('stale_model_truth_after_route_probe')
    ? pass('vqg modellwahrheit hard-gate aktiv', 'stale requested truth wird blockiert')
    : fail('vqg modellwahrheit hard-gate aktiv', 'stale_model_truth_after_route_probe fehlt');
  qualityGateText.includes('claim remains active') && qualityGateText.includes('await new operator input')
    ? pass('vqg idle-abschlussformulierungen blockiert', 'claim-remains-active/await-input Phrasen sind verboten')
    : fail('vqg idle-abschlussformulierungen blockiert', 'zusätzliche idle Abschluss-Phrasen fehlen');

  const refillScript = path.join(lioncomRoot, 'scripts/seed_autonomous_refill.py');
  const runtimeRefillScript = path.join(workspaceRoot, 'scripts/seed_autonomous_refill.py');
  const refillText = fs.existsSync(refillScript) ? fs.readFileSync(refillScript, 'utf8') : '';
  refillText.includes('RECENT_SLUG_COOLDOWN_WINDOW = 4') && refillText.includes('slug_counts.get(slug, 0) >= 1')
    ? pass('autonomer refill rotiert night-run slugs', 'letzte 4 Night-Run-Slugs werden vor Wiederholung gemieden')
    : fail('autonomer refill rotiert night-run slugs', 'aktueller Refill kann zu schnell dieselben Night-Run-Slugs wiederholen');
  refillText.includes('PRODUCTIVE_REFILL_BLUEPRINTS') && refillText.includes('productive_refill_eligible') && refillText.includes('choose_lioncom_v2_refill_blueprint') && refillText.includes('V2-OPERATOR-WORKFLOW-REHEARSAL')
    ? pass('produktiver v2-refill vorhanden', 'nach Hardening-Coverage erzeugt Vivi lokale V2-Produktarbeit statt sterilem Leerlauf')
    : fail('produktiver v2-refill vorhanden', 'Productive-Refill-Engine fehlt oder ist nicht im V2-Nachtmodus verdrahtet');
  const refillHashes = [refillScript, runtimeRefillScript].map((filePath) => sha256(filePath));
  refillHashes.every(Boolean) && new Set(refillHashes).size === 1
    ? pass('autonomer refill runtime-synchron', refillHashes[0])
    : fail('autonomer refill runtime-synchron', JSON.stringify({ source: refillHashes[0], runtime: refillHashes[1] }));

  const qualityGateContract = commandJson('node', [path.join(appRoot, 'scripts/verify_vivi_report_quality_gate_contract.mjs')]);
  if (qualityGateContract.ok && qualityGateContract.body?.ok === true) {
    pass('vqg contract-fixtures gruen', `${qualityGateContract.body.checks?.length || 0} Fixtures`);
  } else {
    fail('vqg contract-fixtures gruen', qualityGateContract.error || qualityGateContract.output || 'Contract-Fixtures fehlgeschlagen');
  }

  const materializerContract = commandJson('node', [path.join(appRoot, 'scripts/verify_vivi_report_materializer_contract.mjs')]);
  if (materializerContract.ok && materializerContract.body?.ok === true) {
    pass('report-materializer contract-fixtures gruen', `${materializerContract.body.checks?.length || 0} Fixtures`);
  } else {
    fail('report-materializer contract-fixtures gruen', materializerContract.error || materializerContract.output || 'Materializer-Contract fehlgeschlagen');
  }

  const materializedFollowups = commandJson('node', [path.join(appRoot, 'scripts/reconcile_repeated_materialized_followups.mjs'), '--verify']);
  if (materializedFollowups.ok && materializedFollowups.body?.ok === true) {
    pass('materialisierte followups ohne offene titelduplikate', `window=${materializedFollowups.body.dedupeWindowHours || 24}h`);
  } else {
    fail('materialisierte followups ohne offene titelduplikate', materializedFollowups.error || materializedFollowups.output || 'Materialisierte Followup-Duplikate offen');
  }

  const staleRefillQueue = commandJson('node', [path.join(appRoot, 'scripts/reconcile_stale_autonomous_refill_queue.mjs'), '--verify']);
  if (staleRefillQueue.ok && staleRefillQueue.body?.ok === true) {
    pass('alte autonome refill-queue sauber geparkt', `threshold=${staleRefillQueue.body.staleAfterHours || 24}h`);
  } else {
    fail('alte autonome refill-queue sauber geparkt', staleRefillQueue.error || staleRefillQueue.output || 'Alte autonome Refill-Queue enthaelt offene Spuren');
  }

  const watchdogScript = path.join(appRoot, 'scripts/run_vivi_night_watchdog.mjs');
  const watchdogText = fs.existsSync(watchdogScript) ? fs.readFileSync(watchdogScript, 'utf8') : '';
  watchdogText.includes('maybeRefreshFlightPack') && watchdogText.includes('LIONCOM_FLIGHT_PACK_REFRESH_MINUTES') && watchdogText.includes('create_control_plane_v2_flight_pack.mjs')
    ? pass('watchdog flight-pack refresh rail aktiv', 'alter Offline-Pack wird vor Health automatisch erneuert')
    : fail('watchdog flight-pack refresh rail aktiv', 'Watchdog kann stale Flight-Pack nicht selbst auffrischen');
  watchdogText.includes('needsStaleRefillRepair') && watchdogText.includes('reconcile_stale_autonomous_refill_queue.mjs') && watchdogText.includes('reconcile-stale-refill-queue')
    ? pass('watchdog stale-refill repair rail aktiv', 'alte Refill-Spuren werden im Repair-Modus geparkt')
    : fail('watchdog stale-refill repair rail aktiv', 'Watchdog kann stale Refill-Spuren nicht selbst reparieren');
  watchdogText.includes('needsWatchdogAgentRepair') && watchdogText.includes('kickstart-vivi-night-watchdog') && watchdogText.includes('com.lioncom.vivi-night-watchdog')
    ? pass('watchdog launchagent repair rail aktiv', 'roter Watchdog-LaunchAgent wird im Repair-Modus neu angestupst')
    : fail('watchdog launchagent repair rail aktiv', 'Watchdog-Repair kann den eigenen LaunchAgent nicht gezielt reparieren');
  watchdogText.includes('needsFlightPackRepair') && watchdogText.includes('refresh-flight-pack-contract') && watchdogText.includes('refresh-flight-pack-after-green-status')
    ? pass('watchdog finaler flight-pack refresh aktiv', 'Repair erzeugt nach gruenem Watchdog-Status einen finalen Offline-Pack')
    : fail('watchdog finaler flight-pack refresh aktiv', 'Watchdog-Repair muss Flight-Pack-Contract-Fails reparieren und nach gruenem Status final neu schreiben');

  const skillRoot = path.join(process.env.HOME || '/Users/BjornRosinger', '.codex/skills');
  const backboneSkills = [
    path.join(skillRoot, 'vega-obsidian-memory/SKILL.md'),
    path.join(skillRoot, 'vega-project-brain/SKILL.md'),
    path.join(skillRoot, 'vega-session-bootstrap/SKILL.md'),
    path.join(skillRoot, 'vivi-session-start/SKILL.md'),
  ];
  const badSkills = backboneSkills
    .map((filePath) => ({ filePath, ...validateSkillFrontmatter(filePath) }))
    .filter((result) => !result.ok);
  badSkills.length === 0
    ? pass('backbone skill-frontmatter gueltig', `${backboneSkills.length} Skills`)
    : fail('backbone skill-frontmatter gueltig', badSkills.map((result) => `${result.filePath}: ${result.detail}`).join('; '));

  const syncScript = path.join(lioncomRoot, 'scripts/sync_runtime_workspace.sh');
  const syncText = fs.existsSync(syncScript) ? fs.readFileSync(syncScript, 'utf8') : '';
  syncText.includes('VIVI_REPORT_QUALITY.md')
    ? pass('runtime-sync schuetzt vqg-ledger', 'VIVI_REPORT_QUALITY.md excluded')
    : fail('runtime-sync schuetzt vqg-ledger', syncScript);

  const qualityLedger = path.join(workspaceRoot, 'VIVI_REPORT_QUALITY.md');
  fs.existsSync(qualityLedger)
    ? pass('vivi quality ledger vorhanden', qualityLedger)
    : warn('vivi quality ledger vorhanden', 'noch kein Gate-Ledger nach letztem Sync geschrieben');

  const reportLedgerCompactor = path.join(lioncomRoot, 'scripts/compact_vivi_report_ledger.py');
  const runtimeReportLedgerCompactor = path.join(workspaceRoot, 'scripts/compact_vivi_report_ledger.py');
  fs.existsSync(reportLedgerCompactor) && fs.existsSync(runtimeReportLedgerCompactor)
    ? pass('vivi report ledger compaction vorhanden', 'VIVI_REPORTS.md dedupe/retention rail aktiv')
    : fail('vivi report ledger compaction vorhanden', JSON.stringify({ source: fs.existsSync(reportLedgerCompactor), runtime: fs.existsSync(runtimeReportLedgerCompactor) }));

  const watchdogStatusPath = path.join(workspaceRoot, '.runtime/vivi-night-watchdog-status.json');
  const watchdogStatus = readJson(watchdogStatusPath);
  const flightPackMarkdown = path.join(workspaceRoot, '.runtime/control-plane-v2-flight-pack/latest.md');
  const flightPackJson = path.join(workspaceRoot, '.runtime/control-plane-v2-flight-pack/latest.json');
  if (fs.existsSync(flightPackMarkdown)) {
    const flightPackText = fs.readFileSync(flightPackMarkdown, 'utf8');
    const flightPackSnapshot = readJson(flightPackJson);
    const requiredFlightPackSections = [
      '## Vivi Lokal Arbeiten',
      '## Autonomie-Rotation',
      'Refill-Rotation:',
      'Wiederholte Slugs im Fenster:',
      '## Watchdog Betriebsstatus',
      'Letzter Watchdog-Lauf:',
      'Final Health:',
      'Statusartefakt:',
      '## Watchdog Installation',
      'Wrapper:',
      'Wrapper-Status: enthalten',
      'LaunchAgent:',
      'LaunchAgent-Status: enthalten',
      'StartInterval: 300 Sekunden',
      'run_vivi_night_watchdog.mjs --repair',
      '## Produktiver Refill',
      'Produktive Refill-Kandidaten:',
      'Aktive Claim:',
      'Command Ref:',
      'Laufende Referenz:',
      '## Offline-Kurzablauf',
      '## Lokale Diagnose-Endpunkte',
      'http://127.0.0.1:4107/api/control-plane-v2',
      'http://127.0.0.1:4107/api/autonomy',
      'http://127.0.0.1:4107/api/health',
      'http://127.0.0.1:4107/api/control-plane-v2/flight-pack',
      '## Enthaltene lokale Rails',
      'http://127.0.0.1:4107/control-plane-v2',
      'VIVI_CHAT_SESSIONS.json',
      'VIVI_COMMAND_QUEUE.md',
      'Task Claims',
      '## Retention und Cleanup',
      'Letztes Manifest:',
      'Quarantaene:',
      'Aktionen:',
      'Build-/Dependency-/Tmp-Dirt darf entfernt werden',
      'MANIFEST.tsv',
    ];
    if (watchdogStatus?.ok === true) {
      requiredFlightPackSections.push('Letzter Watchdog-Lauf: gruen', 'Final Health: gruen');
    }
    const missingFlightPackSections = requiredFlightPackSections.filter((token) => !flightPackText.includes(token));
    missingFlightPackSections.length === 0
      ? pass('flight-pack offline operatorbericht vorhanden', flightPackMarkdown)
      : fail('flight-pack offline operatorbericht vorhanden', `missing=${missingFlightPackSections.join(', ')}`);
    const flightPackAge = ageMinutes(flightPackSnapshot?.createdAt);
    const generatedFilesExist = Boolean(
      flightPackSnapshot?.files?.json
      && flightPackSnapshot?.files?.markdown
      && fs.existsSync(flightPackSnapshot.files.json)
      && fs.existsSync(flightPackSnapshot.files.markdown),
    );
    const watchdogRailsPresent = Boolean(
      flightPackSnapshot?.rails?.viviNightWatchdogWrapper?.exists === true
      && flightPackSnapshot?.rails?.viviNightWatchdogLaunchAgent?.exists === true
    );
    const diagnosticEndpoints = flightPackSnapshot?.diagnosticEndpoints || {};
    const diagnosticEndpointsPresent = Boolean(
      diagnosticEndpoints.controlPlaneV2 === `${baseUrl}/api/control-plane-v2`
      && diagnosticEndpoints.autonomy === `${baseUrl}/api/autonomy`
      && diagnosticEndpoints.health === `${baseUrl}/api/health`
      && diagnosticEndpoints.flightPack === `${baseUrl}/api/control-plane-v2/flight-pack`
    );
    if (!flightPackSnapshot?.createdAt) {
      fail('flight-pack snapshot-metadaten lesbar', flightPackJson);
    } else if (!generatedFilesExist) {
      fail('flight-pack snapshot-metadaten lesbar', `createdAt=${flightPackSnapshot.createdAt}; erzeugte Dateien fehlen`);
    } else if (flightPackAge <= 180) {
      pass('flight-pack snapshot frisch', `${flightPackAge.toFixed(1)} min`);
    } else {
      warn('flight-pack snapshot frisch', `${flightPackAge.toFixed(1)} min; vor Offline-Arbeit neu erzeugen`);
    }
    watchdogRailsPresent
      ? pass('flight-pack watchdog-installation json lesbar', 'Wrapper und LaunchAgent im JSON-Snapshot enthalten')
      : fail('flight-pack watchdog-installation json lesbar', 'latest.json muss viviNightWatchdogWrapper und viviNightWatchdogLaunchAgent enthalten');
    diagnosticEndpointsPresent
      ? pass('flight-pack diagnose-endpunkte json lesbar', 'lokale Diagnose-Endpunkte im JSON-Snapshot enthalten')
      : fail('flight-pack diagnose-endpunkte json lesbar', 'latest.json muss controlPlaneV2/autonomy/health/flightPack Diagnose-Endpunkte enthalten');
  } else {
    fail('flight-pack offline operatorbericht vorhanden', flightPackMarkdown);
  }

  const autonomyHealth = commandJson('python3', [path.join(lioncomRoot, 'scripts/check_vivi_autonomy_health.py'), workspaceRoot]);
  if (autonomyHealth.ok && autonomyHealth.body) {
    const autonomyHealthPath = path.join(workspaceRoot, '.runtime/vivi-autonomy-health.json');
    fs.mkdirSync(path.dirname(autonomyHealthPath), { recursive: true });
    fs.writeFileSync(autonomyHealthPath, `${autonomyHealth.output}\n`, 'utf8');
    autonomyHealth.body.ok === true
      ? pass('vivi autonomie health', Array.isArray(autonomyHealth.body.risks) && autonomyHealth.body.risks.length > 0 ? autonomyHealth.body.risks.join(', ') : 'ok')
      : fail('vivi autonomie health', Array.isArray(autonomyHealth.body.risks) ? autonomyHealth.body.risks.join(', ') : 'not ok');
  } else {
    fail('vivi autonomie health', autonomyHealth.error || 'Autonomie-Health konnte nicht gelesen werden');
  }

  const launchStatus = commandOutput('launchctl', ['print', `gui/${process.getuid?.() ?? 501}/com.lioncom.local-duo-loop`]);
  launchAgentReady(launchStatus)
    ? pass('launchagent local-duo-loop bereit', launchAgentDetail(launchStatus))
    : fail('launchagent local-duo-loop bereit', launchStatus.slice(0, 240));

  const watchdogLaunchStatus = commandOutput('launchctl', ['print', `gui/${process.getuid?.() ?? 501}/com.lioncom.vivi-night-watchdog`]);
  launchAgentReady(watchdogLaunchStatus)
    ? pass('launchagent vivi-night-watchdog bereit', launchAgentDetail(watchdogLaunchStatus))
    : fail('launchagent vivi-night-watchdog bereit', watchdogLaunchStatus.slice(0, 240));

  const watchdogWrapperPath = path.join(process.env.HOME || '/Users/BjornRosinger', '.lioncom/bin/run_vivi_night_watchdog.sh');
  const watchdogPlistPath = path.join(process.env.HOME || '/Users/BjornRosinger', 'Library/LaunchAgents/com.lioncom.vivi-night-watchdog.plist');
  const watchdogWrapperText = fs.existsSync(watchdogWrapperPath) ? fs.readFileSync(watchdogWrapperPath, 'utf8') : '';
  const watchdogPlistText = fs.existsSync(watchdogPlistPath) ? fs.readFileSync(watchdogPlistPath, 'utf8') : '';
  watchdogWrapperText.includes(`cd "${appRoot}"`) && watchdogWrapperText.includes('scripts/run_vivi_night_watchdog.mjs --repair')
    ? pass('watchdog wrapper zeigt auf aktuelle app', watchdogWrapperPath)
    : fail('watchdog wrapper zeigt auf aktuelle app', 'Wrapper fehlt, zeigt nicht auf mission-control-board oder startet nicht im Repair-Modus');
  watchdogPlistText.includes('<string>com.lioncom.vivi-night-watchdog</string>')
    && watchdogPlistText.includes(watchdogWrapperPath)
    && watchdogPlistText.includes('<integer>300</integer>')
    && watchdogPlistText.includes('vivi_night_watchdog.out.log')
    && watchdogPlistText.includes('vivi_night_watchdog.err.log')
    ? pass('watchdog launchagent plist stabil', watchdogPlistPath)
    : fail('watchdog launchagent plist stabil', 'Plist fehlt, falscher Wrapper, falsches Intervall oder fehlende Logs');

  if (!watchdogStatus) {
    fail('watchdog statusartefakt lesbar', watchdogStatusPath);
  } else {
    const watchdogStatusAge = ageMinutes(watchdogStatus.checkedAt);
    if (!watchdogStatus.finalHealth) {
      fail('watchdog letzter reparaturlauf gruen', 'finalHealth fehlt');
    } else if (watchdogStatus.ok !== true) {
      warn('watchdog letzter reparaturlauf gruen', watchdogStatus.recommendation || 'letzter Watchdog-Lauf war nicht gruen; aktuelle Health-Checks entscheiden fuehrend');
    } else {
      pass('watchdog letzter reparaturlauf gruen', watchdogStatus.recommendation || 'ok');
    }
    watchdogStatusAge <= 90
      ? pass('watchdog statusartefakt frisch', `${watchdogStatusAge.toFixed(1)} min`)
      : warn('watchdog statusartefakt frisch', `${watchdogStatusAge.toFixed(1)} min; Watchdog-Intervall pruefen`);
  }

  const failures = checks.filter((check) => check.status === 'fail');
  const warnings = checks.filter((check) => check.status === 'warn');
  const summary = {
    ok: failures.length === 0,
    checkedAt: new Date().toISOString(),
    baseUrl,
    workspaceRoot,
    checks,
    warnings,
    failures,
  };

  console.log(JSON.stringify(summary, null, 2));
  if (failures.length > 0) process.exit(1);
}

main().catch((error) => {
  console.error(error instanceof Error ? error.stack || error.message : error);
  process.exit(1);
});
