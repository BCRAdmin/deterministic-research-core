#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const appRoot = path.resolve(__dirname, '..');
const repoRoot = path.resolve(appRoot, '..');
const baselinePath = path.join(appRoot, 'data', 'portfolio-control-tower-baseline.json');
const gitignorePath = path.join(repoRoot, '.gitignore');
const packageJsonPath = path.join(appRoot, 'package.json');
const packageLockPath = path.join(appRoot, 'package-lock.json');
const typesPath = path.join(appRoot, 'lib', 'types.ts');
const liveDataPath = path.join(appRoot, 'lib', 'control-plane-v2', 'live-data.ts');
const portfolioLibPath = path.join(appRoot, 'lib', 'portfolio-control-tower.ts');
const portfolioMetricsPath = path.join(appRoot, 'lib', 'portfolio', 'portfolio-metrics.ts');
const reviewCalendarPath = path.join(appRoot, 'lib', 'portfolio', 'review-calendar.ts');
const pagePath = path.join(appRoot, 'components', 'portfolio-control-tower-page.tsx');
const sidebarPath = path.join(appRoot, 'components', 'sidebar-nav.tsx');
const closeoutDocPath = path.join(appRoot, 'docs', 'portfolio-control-tower-v1-maintenance-closeout.md');
const promptRegistryDocPath = path.join(appRoot, 'docs', 'VEGA_PROMPT_REGISTRY_2026-05-18.md');
const operatorReadinessDocPath = path.join(appRoot, 'docs', 'operator-readiness-pass-2026-05-21.md');
const operatorReadinessJsonPath = path.join(appRoot, 'docs', 'operator-readiness-pass-2026-05-21.json');
const membershipVerifierPagePath = path.join(appRoot, 'app', 'membership', 'verifier', 'page.tsx');
const failures = [];
const checks = [];

function pass(name, detail = '') {
  checks.push({ name, status: 'pass', detail });
}

function fail(name, detail) {
  checks.push({ name, status: 'fail', detail });
  failures.push({ name, detail });
}

function requireCondition(condition, name, detail) {
  if (condition) pass(name, detail);
  else fail(name, detail);
}

function readText(filePath) {
  return fs.readFileSync(filePath, 'utf8');
}

function readJson(filePath) {
  return JSON.parse(readText(filePath));
}

function commandText(command, args, cwd) {
  try {
    return execFileSync(command, args, { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim();
  } catch {
    return null;
  }
}

function commandOk(command, args, cwd) {
  try {
    execFileSync(command, args, { cwd, stdio: 'ignore' });
    return true;
  } catch {
    return false;
  }
}

function lockVersion(packageLock, packageName) {
  return packageLock.packages?.[`node_modules/${packageName}`]?.version || null;
}

function streamSourceBlock(source, streamId) {
  const marker = `id: '${streamId}'`;
  const start = source.indexOf(marker);
  if (start === -1) return '';
  const next = source.indexOf('\n  {', start + marker.length);
  return source.slice(start, next === -1 ? source.length : next);
}

function reviewCalendarBlocks(source, streamId) {
  const marker = `streamId: '${streamId}'`;
  const blocks = [];
  let searchFrom = 0;

  while (searchFrom < source.length) {
    const start = source.indexOf(marker, searchFrom);
    if (start === -1) break;
    const blockStart = source.lastIndexOf('\n  {', start);
    const nextBlock = source.indexOf('\n  {', start + marker.length);
    const arrayEnd = source.indexOf('\n];', start + marker.length);
    const blockEnd = nextBlock === -1 ? arrayEnd : Math.min(nextBlock, arrayEnd === -1 ? nextBlock : arrayEnd);
    blocks.push(source.slice(blockStart === -1 ? start : blockStart, blockEnd === -1 ? source.length : blockEnd));
    searchFrom = start + marker.length;
  }

  return blocks;
}

function allBlocksInclude(blocks, text) {
  return blocks.length > 0 && blocks.every((block) => block.includes(text));
}

const baseline = JSON.parse(readText(baselinePath));
const packageJson = readJson(packageJsonPath);
const packageLock = readJson(packageLockPath);
const repositories = Array.isArray(baseline.repositories) ? baseline.repositories : [];
const byRepo = new Map(repositories.map((repo) => [repo.repo, repo]));
const maintenance = baseline.maintenanceBaseline?.lioncom || {};
const knownLocalDiffs = Array.isArray(baseline.knownLocalDiffs) ? baseline.knownLocalDiffs : [];
const executionContract = baseline.executionContract || {};
const executionContractDocPath = path.join(repoRoot, String(executionContract.contractDocPath || ''));
const roleRegistryDocPath = path.join(repoRoot, String(executionContract.roleRegistryDocPath || ''));

const requiredRepos = [
  'BCRAdmin/materialbedarf-rechner.de',
  'BCRAdmin/Kindergeld',
  'BCRAdmin/LIONCOM',
  'BCRAdmin/microtool-starter-kit',
  'BCRAdmin/company-dossier-lab',
  'BCRAdmin/deterministic-research-core',
  'BCRAdmin/Vivi-os-v1',
];

const requiredChecksByRepo = new Map([
  ['BCRAdmin/materialbedarf-rechner.de', ['lint-and-build', 'playwright', 'check:measurement']],
  ['BCRAdmin/Kindergeld', ['lint-and-build', 'playwright', 'check:trust']],
  ['BCRAdmin/LIONCOM', ['mission-control-board']],
  ['BCRAdmin/microtool-starter-kit', ['starter-kit', 'check:opportunity-gate']],
  ['BCRAdmin/company-dossier-lab', ['python-core', 'room16-app', 'manual-review-workbench']],
  ['BCRAdmin/deterministic-research-core', ['deterministic-core', 'outcome-tracking-v1']],
]);

const expectedSnapshotShas = new Map([
  ['BCRAdmin/materialbedarf-rechner.de', 'd75f6b6'],
  ['BCRAdmin/Kindergeld', 'bedcf0d'],
  ['BCRAdmin/LIONCOM', '93af75c'],
  ['BCRAdmin/microtool-starter-kit', '40d5630'],
  ['BCRAdmin/company-dossier-lab', '54666f4'],
  ['BCRAdmin/deterministic-research-core', '22e103b'],
]);

const requiredPortfolioStreams = [
  'materialbedarf.measurement',
  'elterngeld.trust',
  'membership.launchReadiness',
  'room16.review',
  'deterministic.outcomes',
  'microtool.opportunities',
  'github.planBlocked',
  'generatedStatePolicy',
];

const requiredPortfolioCards = [
  'Utility Revenue/Funnel',
  'Trust/Rule Coverage',
  'Membership Readiness',
  'Review Queue',
  'Outcome Horizons',
  'Opportunity Backlog',
  'Maintenance/Governance',
];

const requiredReviewLabels = [
  'Credential-Free Readiness',
  'Data Maturity Check',
  'Post-Update GSC Maturity Check',
  '7d Smoke',
  '14d First Read',
  '28d Decision Review',
  '14d GSC/Trust Read',
  '28d Trust/Content Decision',
  'Weekly Review Queue',
  '5D Outcome Horizon',
  '10D Outcome Horizon',
  '20D Outcome Horizon',
  '60D Outcome Horizon',
  'Opportunity Backlog Review',
  'Generated-State Check',
  'Audit Check',
];

const requiredGovernanceSubjects = [
  'Vega',
  'Vega 0',
  'Vivi',
  'Room16',
  'Deterministic-Core',
  'Utility-Webseiten',
  'Microtool-Starter-Kit',
  'LIONCOM',
  'Operator-Go-Prozesse',
];

const requiredTruthHierarchy = [
  'operator_go_or_hold',
  'github_ci_after_push',
  'local_verifiers_and_domain_gates',
  'lioncom_control_tower',
  'vega0_canonical_integration',
  'project_and_role_registry_docs',
  'handoff_chat_queue_runtime_files',
];

const requiredNoGoScope = [
  'dependency_upgrades',
  'package_lock_changes',
  'runtime_or_generated_commits',
  'dashboard_data_golden_baseline_status_json_commit',
  'vivi_os_v1_changes',
  'public_or_production_go',
  'financial_advice_go',
  'provider_credential_payment_actions',
  'room16_gate_changes',
  'deterministic_core_gate_changes',
  'external_github_or_provider_api_actions',
];

requireCondition(baseline.schemaVersion === 1, 'portfolio baseline schema version', `schema=${baseline.schemaVersion || 'missing'}`);
requireCondition(baseline.controlTowerVersion === 'v2', 'portfolio control tower version', `version=${baseline.controlTowerVersion || 'missing'}`);
requireCondition(Boolean(baseline.capturedAt), 'portfolio baseline capturedAt gesetzt', baseline.capturedAt || 'missing');
requireCondition(/maintenance-final|control-tower-v2/i.test(String(baseline.source || '')), 'portfolio source beschreibt maintenance final und v2', baseline.source || 'missing');
requireCondition(repositories.length === 7, 'portfolio baseline listet sieben repos', `${repositories.length} repos`);

for (const repoName of requiredRepos) {
  requireCondition(byRepo.has(repoName), `repo vorhanden: ${repoName}`, byRepo.has(repoName) ? 'vorhanden' : 'missing');
}

for (const [repoName, expectedSha] of expectedSnapshotShas.entries()) {
  const repo = byRepo.get(repoName);
  requireCondition(repo?.lastKnownSha === expectedSha, `snapshot-sha fuer ${repoName}`, `expected=${expectedSha} actual=${repo?.lastKnownSha || 'missing'}`);
}

for (const [repoName, requiredChecks] of requiredChecksByRepo.entries()) {
  const repo = byRepo.get(repoName);
  const checks = new Set(repo?.requiredChecks || []);
  const missing = requiredChecks.filter((check) => !checks.has(check));
  requireCondition(missing.length === 0, `required checks fuer ${repoName}`, missing.length ? missing.join(', ') : requiredChecks.join(', '));
}

const activeRepos = repositories.filter((repo) => repo.lifecycle === 'active');
requireCondition(activeRepos.length === 6, 'sechs aktive repos', `${activeRepos.length} aktiv`);
requireCondition(activeRepos.every((repo) => repo.dependabotStatus === 'active'), 'dependabot fuer aktive repos aktiv', activeRepos.filter((repo) => repo.dependabotStatus !== 'active').map((repo) => repo.repo).join(', ') || 'alle aktiv');
requireCondition(activeRepos.every((repo) => repo.branchProtectionStatus === 'blocked_plan_or_public_required'), 'branch protection ehrlich blockiert', activeRepos.filter((repo) => repo.branchProtectionStatus !== 'blocked_plan_or_public_required').map((repo) => repo.repo).join(', ') || 'Plan/API-Block dokumentiert');
requireCondition(activeRepos.every((repo) => repo.secretScanningStatus === 'unavailable_private_repo'), 'secret scanning ehrlich nicht verfuegbar', activeRepos.filter((repo) => repo.secretScanningStatus !== 'unavailable_private_repo').map((repo) => repo.repo).join(', ') || 'GitHub-Block dokumentiert');
requireCondition(activeRepos.every((repo) => repo.publicGate === 'operator_gated'), 'keine public-production gates automatisch offen', activeRepos.filter((repo) => repo.publicGate !== 'operator_gated').map((repo) => repo.repo).join(', ') || 'alle operator-gated');
requireCondition(baseline.portfolioPolicy?.productionPublicGo === 'operator_gate', 'portfolio policy blockt production/public auto-go', baseline.portfolioPolicy?.productionPublicGo || 'missing');
requireCondition(baseline.portfolioPolicy?.financialAdviceGo === 'operator_gate', 'portfolio policy blockt financial-advice auto-go', baseline.portfolioPolicy?.financialAdviceGo || 'missing');
requireCondition(baseline.portfolioPolicy?.dependencyUpgrades === 'blocked_without_explicit_operator_go', 'portfolio policy blockt dependency upgrades', baseline.portfolioPolicy?.dependencyUpgrades || 'missing');
requireCondition(baseline.portfolioPolicy?.generatedRuntimeState === 'do_not_commit', 'portfolio policy blockt generated runtime commits', baseline.portfolioPolicy?.generatedRuntimeState || 'missing');

requireCondition(executionContract.id === 'bcradmin-portfolio-execution-contract', 'execution contract id gesetzt', executionContract.id || 'missing');
requireCondition(executionContract.status === 'canonical', 'execution contract ist kanonisch', executionContract.status || 'missing');
requireCondition(executionContract.version === '2026-05-18.v1', 'execution contract version', executionContract.version || 'missing');
requireCondition(executionContract.verifier === 'npm run verify:portfolio-status', 'execution contract verweist auf portfolio verifier', executionContract.verifier || 'missing');
requireCondition(/sole source of truth/i.test(String(executionContract.handoffRule || '')), 'handoff ist keine alleinige wahrheit', executionContract.handoffRule || 'missing');
for (const subject of requiredGovernanceSubjects) {
  requireCondition(executionContract.governanceSubjects?.includes(subject), `contract subject: ${subject}`, executionContract.governanceSubjects?.join(', ') || 'missing');
}
for (const hierarchyItem of requiredTruthHierarchy) {
  requireCondition(executionContract.truthHierarchy?.includes(hierarchyItem), `truth hierarchy enthaelt ${hierarchyItem}`, executionContract.truthHierarchy?.join(', ') || 'missing');
}
for (const noGo of requiredNoGoScope) {
  requireCondition(executionContract.noGoScope?.includes(noGo), `no-go scope enthaelt ${noGo}`, executionContract.noGoScope?.join(', ') || 'missing');
}

requireCondition(fs.existsSync(executionContractDocPath), 'execution contract doc existiert', executionContract.contractDocPath || 'missing');
requireCondition(fs.existsSync(roleRegistryDocPath), 'role registry doc existiert', executionContract.roleRegistryDocPath || 'missing');
if (fs.existsSync(executionContractDocPath)) {
  const contractDoc = readText(executionContractDocPath);
  requireCondition(contractDoc.includes('BCRAdmin Portfolio Execution Contract'), 'execution contract doc titel', executionContract.contractDocPath);
  requireCondition(contractDoc.includes('Truth-Hierarchy'), 'execution contract doc beschreibt truth hierarchy', executionContract.contractDocPath);
  requireCondition(contractDoc.includes('Vega 0'), 'execution contract doc umfasst Vega 0', executionContract.contractDocPath);
  requireCondition(contractDoc.includes('Room16') && contractDoc.includes('Deterministic Research Core'), 'execution contract doc umfasst portfolio lanes', executionContract.contractDocPath);
  requireCondition(contractDoc.includes('Eine Handoff-Datei') && contractDoc.includes('nie alleinige Wahrheit'), 'execution contract doc blockt handoff-only truth', executionContract.contractDocPath);
  requireCondition(contractDoc.includes('Wenn dieser Verifier rot ist, stoppt der Lauf'), 'execution contract doc stoppt bei rotem verifier', executionContract.contractDocPath);
}
if (fs.existsSync(roleRegistryDocPath)) {
  const roleRegistryDoc = readText(roleRegistryDocPath);
  for (const subject of ['Operator', 'Vega', 'Vega 0', 'Vivi', 'LIONCOM Control Tower', 'Room16', 'Deterministic Research Core', 'Utility-Webseiten', 'Microtool Starter Kit']) {
    requireCondition(roleRegistryDoc.includes(subject), `role registry beschreibt ${subject}`, executionContract.roleRegistryDocPath);
  }
  requireCondition(roleRegistryDoc.includes('Rote Verifier stoppen Commit und Push'), 'role registry blockt push bei rotem verifier', executionContract.roleRegistryDocPath);
  requireCondition(roleRegistryDoc.includes('Runtime-, Generated-') && roleRegistryDoc.includes('nicht committen'), 'role registry blockt generated commits', executionContract.roleRegistryDocPath);
}

requireCondition(fs.existsSync(promptRegistryDocPath), 'vega prompt registry doc existiert', promptRegistryDocPath);
if (fs.existsSync(promptRegistryDocPath)) {
  const promptRegistryDoc = readText(promptRegistryDocPath);
  for (const prompt of ['Vega 0', 'Vega 1', 'Vega 2', 'Vega 3', 'Vega 4', 'Vega 5', 'Vega 6']) {
    requireCondition(promptRegistryDoc.includes(prompt), `prompt registry beschreibt ${prompt}`, promptRegistryDocPath);
  }
  for (const streamId of requiredPortfolioStreams) {
    requireCondition(promptRegistryDoc.includes(streamId), `prompt registry enthaelt stream ${streamId}`, promptRegistryDocPath);
  }
  requireCondition(/kein Stream setzt automatisch `productionGo`/i.test(promptRegistryDoc), 'prompt registry blockt auto productionGo', promptRegistryDocPath);
  requireCondition(/Research-Streams setzen nicht automatisch `publicReady`/i.test(promptRegistryDoc), 'prompt registry blockt research auto publicReady', promptRegistryDocPath);
}

requireCondition(fs.existsSync(operatorReadinessDocPath), 'operator readiness pass doc existiert', operatorReadinessDocPath);
requireCondition(fs.existsSync(operatorReadinessJsonPath), 'operator readiness pass json existiert', operatorReadinessJsonPath);
if (fs.existsSync(operatorReadinessJsonPath)) {
  const operatorReadiness = readJson(operatorReadinessJsonPath);
  requireCondition(operatorReadiness.status === 'completed', 'operator readiness status completed', operatorReadiness.status || 'missing');
  requireCondition(operatorReadiness.credentialsOpened === false, 'operator readiness oeffnet keine credentials', JSON.stringify(operatorReadiness.credentialsOpened));
  requireCondition(operatorReadiness.productionGo === false, 'operator readiness oeffnet production nicht', JSON.stringify(operatorReadiness.productionGo));
  requireCondition(operatorReadiness.publicReady === false, 'operator readiness oeffnet public nicht', JSON.stringify(operatorReadiness.publicReady));
  requireCondition(operatorReadiness.utilityDataMaturity?.verdict === 'not_mature', 'utility datenreife ist nicht reif', operatorReadiness.utilityDataMaturity?.verdict || 'missing');
}

const packageDiff = commandText('git', ['diff', '--name-only', '--', 'mission-control-board/package.json', 'mission-control-board/package-lock.json'], repoRoot);
requireCondition(!packageDiff, 'keine package-/lockfile-aenderung im arbeitsdiff', packageDiff || 'clean');

const viviLegacy = byRepo.get('BCRAdmin/Vivi-os-v1');
requireCondition(viviLegacy?.lifecycle === 'archived', 'vivi-os-v1 bleibt archiviert', JSON.stringify({ lifecycle: viviLegacy?.lifecycle, nextAction: viviLegacy?.nextAction }));
requireCondition(
  /read-only|legacy|nicht anfassen/i.test(String(viviLegacy?.nextAction || '')),
  'vivi-os-v1 next action ist no-touch',
  viviLegacy?.nextAction || 'missing',
);
requireCondition(baseline.portfolioPolicy?.viviOsV1 === 'archived_read_only_legacy_no_touch', 'vivi-os-v1 policy ist no-touch', baseline.portfolioPolicy?.viviOsV1 || 'missing');

const lioncom = byRepo.get('BCRAdmin/LIONCOM');
requireCondition(lioncom?.risk === 'yellow', 'lioncom risiko gelb', `risk=${lioncom?.risk || 'missing'}`);
requireCondition(maintenance.maintenanceCommit === '41ef821', 'lioncom maintenance commit bleibt electron-39 baseline', `maintenance=${maintenance.maintenanceCommit || 'missing'}`);
requireCondition(maintenance.portfolioControlTowerV1Commit === '93af75c', 'lioncom portfolio tower v1 commit bleibt baseline', `portfolioV1=${maintenance.portfolioControlTowerV1Commit || 'missing'}`);
requireCondition(lioncom?.lastKnownSha === maintenance.portfolioControlTowerV1Commit, 'lioncom snapshot-sha entspricht portfolio-v1 baseline', `repo=${lioncom?.lastKnownSha || 'missing'} portfolioV1=${maintenance.portfolioControlTowerV1Commit || 'missing'}`);
requireCondition(maintenance.next === '15.5.18', 'lioncom maintenance next version', `next=${maintenance.next || 'missing'}`);
requireCondition(maintenance.react === '19.2.6', 'lioncom maintenance react version', `react=${maintenance.react || 'missing'}`);
requireCondition(maintenance.electron === '39.8.10', 'lioncom maintenance electron version', `electron=${maintenance.electron || 'missing'}`);
requireCondition(maintenance.electronBuilder === '26.8.1', 'lioncom maintenance electron-builder version', `electronBuilder=${maintenance.electronBuilder || 'missing'}`);
requireCondition(maintenance.braceExpansion === '5.0.6', 'lioncom maintenance brace-expansion security version', `braceExpansion=${maintenance.braceExpansion || 'missing'}`);
requireCondition(maintenance.nodeGithubActions === '24', 'lioncom actions node baseline', `node=${maintenance.nodeGithubActions || 'missing'}`);
requireCondition(maintenance.runtimeBuildId === 'OuFrDueeo4aN4umXaAhjV', 'lioncom runtime build-id dokumentiert', `buildId=${maintenance.runtimeBuildId || 'missing'}`);
requireCondition(maintenance.dependencyPolicy === 'no_dependency_changes_after_maintenance_baseline', 'lioncom dependency policy eingefroren', maintenance.dependencyPolicy || 'missing');

requireCondition(packageJson.dependencies?.next === maintenance.next, 'package next bleibt auf maintenance baseline', packageJson.dependencies?.next || 'missing');
requireCondition(lockVersion(packageLock, 'next') === maintenance.next, 'lockfile next bleibt auf maintenance baseline', lockVersion(packageLock, 'next') || 'missing');
requireCondition(lockVersion(packageLock, 'react') === maintenance.react, 'lockfile react bleibt auf maintenance baseline', lockVersion(packageLock, 'react') || 'missing');
requireCondition(lockVersion(packageLock, 'react-dom') === maintenance.react, 'lockfile react-dom bleibt auf maintenance baseline', lockVersion(packageLock, 'react-dom') || 'missing');
requireCondition(packageJson.devDependencies?.electron === maintenance.electron, 'package electron bleibt auf maintenance baseline', packageJson.devDependencies?.electron || 'missing');
requireCondition(lockVersion(packageLock, 'electron') === maintenance.electron, 'lockfile electron bleibt auf maintenance baseline', lockVersion(packageLock, 'electron') || 'missing');
requireCondition(lockVersion(packageLock, 'electron-builder') === maintenance.electronBuilder, 'lockfile electron-builder bleibt 26.x baseline', lockVersion(packageLock, 'electron-builder') || 'missing');
requireCondition(packageJson.overrides?.['@xmldom/xmldom'] === '0.8.13', 'xmldom override bleibt aktiv', packageJson.overrides?.['@xmldom/xmldom'] || 'missing');
requireCondition(packageJson.overrides?.['ip-address'] === '10.1.1', 'ip-address override bleibt aktiv', packageJson.overrides?.['ip-address'] || 'missing');
requireCondition(packageJson.overrides?.['minimatch@10.2.5']?.['brace-expansion'] === maintenance.braceExpansion, 'brace-expansion override bleibt parent-spezifisch aktiv', JSON.stringify(packageJson.overrides?.['minimatch@10.2.5'] || null));
requireCondition(lockVersion(packageLock, '@xmldom/xmldom') === '0.8.13', 'lockfile xmldom security fix', lockVersion(packageLock, '@xmldom/xmldom') || 'missing');
requireCondition(lockVersion(packageLock, 'ip-address') === '10.1.1', 'lockfile ip-address security fix', lockVersion(packageLock, 'ip-address') || 'missing');
requireCondition(lockVersion(packageLock, 'brace-expansion') === maintenance.braceExpansion, 'lockfile brace-expansion security fix', lockVersion(packageLock, 'brace-expansion') || 'missing');

const lioncomDiff = knownLocalDiffs.find((diff) => diff.repo === 'BCRAdmin/LIONCOM' && diff.path === 'dashboard/data/golden_baseline_status.json');
const viviChatSessionsDiff = knownLocalDiffs.find((diff) => diff.repo === 'BCRAdmin/LIONCOM' && diff.path === 'VIVI_CHAT_SESSIONS.json');
const viviChatThreadDiff = knownLocalDiffs.find((diff) => diff.repo === 'BCRAdmin/LIONCOM' && diff.path === 'VIVI_CHAT_THREAD.md');
requireCondition(lioncomDiff?.classification === 'generated_baseline_status' && lioncomDiff?.policy === 'do_not_commit', 'bekannter lioncom generated diff klassifiziert', JSON.stringify(lioncomDiff || null));
requireCondition(viviChatSessionsDiff?.classification === 'generated_vivi_chat_rail' && viviChatSessionsDiff?.policy === 'do_not_commit', 'vivi chat sessions rail klassifiziert', JSON.stringify(viviChatSessionsDiff || null));
requireCondition(viviChatThreadDiff?.classification === 'generated_vivi_chat_rail' && viviChatThreadDiff?.policy === 'do_not_commit', 'vivi chat thread rail klassifiziert', JSON.stringify(viviChatThreadDiff || null));
requireCondition(knownLocalDiffs.every((diff) => diff.policy !== 'commit'), 'known local diffs sind nicht commitbar', knownLocalDiffs.map((diff) => `${diff.repo}:${diff.path}:${diff.policy}`).join(', '));

for (const repo of repositories) {
  if (repo.repo === 'BCRAdmin/Vivi-os-v1') {
    continue;
  }
  const localPath = repo.repo === 'BCRAdmin/LIONCOM' ? repoRoot : repo.localPath;
  if (!localPath || !fs.existsSync(path.join(localPath, '.git'))) {
    pass(`lokaler git-snapshot optional: ${repo.repo}`, 'lokaler Pfad in dieser Umgebung nicht verfuegbar');
    continue;
  }
  const currentBranch = commandText('git', ['branch', '--show-current'], localPath);
  if (currentBranch) {
    requireCondition(currentBranch === repo.branch, `lokaler branch fuer ${repo.repo}`, `expected=${repo.branch} actual=${currentBranch}`);
  } else {
    pass(`lokaler branch fuer ${repo.repo}`, 'detached checkout, branch-check uebersprungen');
  }
  const snapshotReachable = commandOk('git', ['merge-base', '--is-ancestor', repo.lastKnownSha, 'HEAD'], localPath);
  requireCondition(snapshotReachable, `snapshot-sha in lokaler historie: ${repo.repo}`, `sha=${repo.lastKnownSha}`);
}

const sourceFiles = {
  types: readText(typesPath),
  liveData: readText(liveDataPath),
  portfolioLib: readText(portfolioLibPath),
  portfolioMetrics: readText(portfolioMetricsPath),
  reviewCalendar: readText(reviewCalendarPath),
  page: readText(pagePath),
  membershipVerifierPage: readText(membershipVerifierPagePath),
  sidebar: readText(sidebarPath),
  gitignore: readText(gitignorePath),
  closeoutDoc: fs.existsSync(closeoutDocPath) ? readText(closeoutDocPath) : '',
  promptRegistryDoc: fs.existsSync(promptRegistryDocPath) ? readText(promptRegistryDocPath) : '',
  operatorReadinessDoc: fs.existsSync(operatorReadinessDocPath) ? readText(operatorReadinessDocPath) : '',
};

requireCondition(sourceFiles.types.includes('portfolioRepositories: PortfolioRepositoryStatus[]'), 'api type enthaelt portfolioRepositories', 'ControlPlaneLiveData erweitert');
requireCondition(sourceFiles.types.includes('PortfolioExecutionContract'), 'api type enthaelt portfolioExecutionContract', 'Execution Contract typisiert');
requireCondition(sourceFiles.types.includes('PortfolioStreamMetric'), 'api type enthaelt PortfolioStreamMetric', 'Portfolio metrics typisiert');
requireCondition(sourceFiles.types.includes('portfolioMetrics: PortfolioStreamMetric[]'), 'api type enthaelt portfolioMetrics', 'ControlPlaneLiveData erweitert');
requireCondition(sourceFiles.types.includes('PortfolioReviewCalendarItem'), 'api type enthaelt PortfolioReviewCalendarItem', 'Review Calendar typisiert');
requireCondition(sourceFiles.types.includes('portfolioReviewCalendar: PortfolioReviewCalendarItem[]'), 'api type enthaelt portfolioReviewCalendar', 'ControlPlaneLiveData erweitert');
requireCondition(sourceFiles.types.includes('vivi_vega_handoff_inbox'), 'api type enthaelt Vivi -> Vega Handoff Inbox', 'PlanningQualitySurface erweitert');
requireCondition(sourceFiles.liveData.includes('loadPortfolioRepositories'), 'live-data laedt portfolio baseline', 'loadPortfolioRepositories gefunden');
requireCondition(sourceFiles.liveData.includes('loadPortfolioExecutionContract'), 'live-data laedt execution contract', 'loadPortfolioExecutionContract gefunden');
requireCondition(sourceFiles.liveData.includes('loadPortfolioMetrics'), 'live-data laedt portfolio metrics', 'loadPortfolioMetrics gefunden');
requireCondition(sourceFiles.liveData.includes('loadPortfolioReviewCalendar'), 'live-data laedt review calendar', 'loadPortfolioReviewCalendar gefunden');
requireCondition(sourceFiles.portfolioLib.includes('loadPortfolioExecutionContract'), 'portfolio lib exportiert execution contract', 'Loader gefunden');
requireCondition(sourceFiles.portfolioMetrics.includes('requiredPortfolioStreamIds'), 'portfolio metrics exportiert stream registry', 'requiredPortfolioStreamIds gefunden');
requireCondition(!/productionGo:\s*true/.test(sourceFiles.portfolioMetrics), 'kein portfolio stream setzt productionGo=true', 'alle productionGo=false');
requireCondition(sourceFiles.portfolioMetrics.includes("generatedStatePolicy: 'do_not_commit'"), 'generated state policy ist no-commit stream', 'do_not_commit gefunden');
requireCondition(sourceFiles.portfolioMetrics.includes("branchProtectionStatus: 'blocked_plan_or_public_required'"), 'metrics dokumentieren branch protection plan-block', 'blocked_plan_or_public_required gefunden');
requireCondition(sourceFiles.portfolioMetrics.includes("secretScanningStatus: 'unavailable_private_repo'"), 'metrics dokumentieren secret scanning unavailable', 'unavailable_private_repo gefunden');
requireCondition(sourceFiles.page.includes('Vivi -&gt; Vega Inbox'), 'portfolio ui zeigt Vivi -> Vega Inbox', 'Inbox-Karte gefunden');
requireCondition(sourceFiles.page.includes('vivi_vega_handoff_inbox'), 'portfolio ui liest PIG Handoff Inbox', 'PIG-Feld gefunden');
requireCondition(sourceFiles.page.includes('Operator-Gate'), 'portfolio ui zeigt Operator-Gate-Zaehler', 'Gate-Zaehler gefunden');
for (const streamId of requiredPortfolioStreams) {
  const block = streamSourceBlock(sourceFiles.portfolioMetrics, streamId);
  requireCondition(Boolean(block), `portfolio metrics stream vorhanden: ${streamId}`, block ? 'vorhanden' : 'missing');
  requireCondition(block.includes('productionGo: false'), `stream ${streamId} hat kein auto productionGo`, block ? 'productionGo=false' : 'missing');
  requireCondition(block.includes('publicReady: false'), `stream ${streamId} hat kein auto publicReady`, block ? 'publicReady=false' : 'missing');
}
const membershipReadinessBlock = streamSourceBlock(sourceFiles.portfolioMetrics, 'membership.launchReadiness');
requireCondition(membershipReadinessBlock.includes('Launch-Readiness ohne Credentials') || membershipReadinessBlock.includes('Credential-Free'), 'membership stream ist credential-free', membershipReadinessBlock || 'missing');
for (const gate of ['no provider credentials', 'no mail send', 'no stripe checkout', 'no external launch']) {
  requireCondition(membershipReadinessBlock.includes(gate), `membership stream gate ${gate}`, membershipReadinessBlock || 'missing');
}
for (const streamId of ['room16.review', 'deterministic.outcomes']) {
  const block = streamSourceBlock(sourceFiles.portfolioMetrics, streamId);
  requireCondition(block.includes('researchStream: true') && block.includes('publicReady: false'), `research stream ${streamId} bleibt nicht publicReady`, block || 'missing');
}
requireCondition(fs.existsSync(reviewCalendarPath), 'review calendar schema existiert', reviewCalendarPath);
requireCondition(sourceFiles.reviewCalendar.includes('portfolioReviewCalendar'), 'review calendar exportiert kalender', reviewCalendarPath);
requireCondition(sourceFiles.reviewCalendar.includes('loadPortfolioReviewCalendar'), 'review calendar exportiert loader', reviewCalendarPath);
for (const streamId of requiredPortfolioStreams) {
  const blocks = reviewCalendarBlocks(sourceFiles.reviewCalendar, streamId);
  requireCondition(blocks.length > 0, `review calendar hat termine fuer ${streamId}`, blocks.length ? `${blocks.length} Termin(e)` : 'missing');
  requireCondition(blocks.every((block) => /dueDate: '\d{4}-\d{2}-\d{2}'/.test(block)), `review calendar ${streamId} hat datierte reviews`, blocks.length ? 'dueDate gesetzt' : 'missing');
  requireCondition(allBlocksInclude(blocks, 'productionGo: false'), `review calendar ${streamId} oeffnet production nicht`, blocks.length ? 'productionGo=false' : 'missing');
  requireCondition(allBlocksInclude(blocks, 'publicReady: false'), `review calendar ${streamId} oeffnet public nicht`, blocks.length ? 'publicReady=false' : 'missing');
}
for (const label of requiredReviewLabels) {
  requireCondition(sourceFiles.reviewCalendar.includes(`reviewLabel: '${label}'`), `review calendar enthaelt ${label}`, reviewCalendarPath);
}
const materialbedarfDataMaturity = reviewCalendarBlocks(sourceFiles.reviewCalendar, 'materialbedarf.measurement').find((block) => block.includes("id: 'materialbedarf-data-maturity-2026-05-21'")) || '';
const elterngeldDataMaturity = reviewCalendarBlocks(sourceFiles.reviewCalendar, 'elterngeld.trust').find((block) => block.includes("id: 'elterngeld-data-maturity-2026-05-21'")) || '';
requireCondition(materialbedarfDataMaturity.includes("status: 'waiting_for_data'") && materialbedarfDataMaturity.includes('2026-05-25') && materialbedarfDataMaturity.includes('2026-06-01'), 'materialbedarf datenreife wartet auf fuehrende fenster', materialbedarfDataMaturity || 'missing');
requireCondition(elterngeldDataMaturity.includes("status: 'waiting_for_data'") && elterngeldDataMaturity.includes('2026-05-15'), 'elterngeld datenreife wartet auf post-update gsc', elterngeldDataMaturity || 'missing');
for (const streamId of ['room16.review', 'deterministic.outcomes']) {
  const blocks = reviewCalendarBlocks(sourceFiles.reviewCalendar, streamId);
  requireCondition(allBlocksInclude(blocks, 'researchAutoPublish: false'), `research calendar ${streamId} hat kein public auto publish`, blocks.length ? 'researchAutoPublish=false' : 'missing');
}
requireCondition(allBlocksInclude(reviewCalendarBlocks(sourceFiles.reviewCalendar, 'materialbedarf.measurement'), 'affiliateAutoGo: false'), 'materialbedarf calendar hat kein affiliate auto go', 'affiliateAutoGo=false');
requireCondition(allBlocksInclude(reviewCalendarBlocks(sourceFiles.reviewCalendar, 'elterngeld.trust'), 'trustBypass: false'), 'elterngeld calendar hat keinen trust bypass', 'trustBypass=false');
requireCondition(sourceFiles.reviewCalendar.includes('Generated-State Check') && sourceFiles.reviewCalendar.includes('Audit Check'), 'maintenance calendar enthaelt generated-state und audit check', reviewCalendarPath);
requireCondition(sourceFiles.page.includes('PORTFOLIO CONTROL TOWER'), 'portfolio ui sichtbar', 'Seitentitel gefunden');
requireCondition(sourceFiles.page.includes('Portfolio Control Tower V2'), 'portfolio ui zeigt v2-schicht', 'V2 Titel gefunden');
requireCondition(sourceFiles.page.includes('Review Calendar'), 'portfolio ui zeigt review calendar', 'Review Calendar gefunden');
requireCondition(sourceFiles.page.includes('expectedData') && sourceFiles.page.includes('decisionGate') && sourceFiles.page.includes('operatorGate') && sourceFiles.page.includes('noDataStatus'), 'portfolio ui rendert review daten und gates', 'expectedData/decisionGate/operatorGate/noDataStatus gefunden');
for (const cardTitle of requiredPortfolioCards) {
  requireCondition(sourceFiles.page.includes(cardTitle), `portfolio ui zeigt card ${cardTitle}`, 'Card gefunden');
}
requireCondition(sourceFiles.page.includes("group === 'membership'"), 'portfolio ui stylt membership review group', pagePath);
requireCondition(sourceFiles.page.includes('stream.id'), 'portfolio ui rendert stream ids aus metrics', 'stream.id gefunden');
requireCondition(sourceFiles.page.includes('EXECUTION CONTRACT'), 'portfolio ui verlinkt execution contract', 'Execution Contract Panel gefunden');
requireCondition(sourceFiles.page.includes('Truth-Hierarchy'), 'portfolio ui zeigt truth hierarchy', 'Truth-Hierarchy gefunden');
requireCondition(sourceFiles.page.includes('Snapshot-SHA'), 'portfolio ui kennzeichnet snapshot-sha', 'Snapshot-SHA gefunden');
requireCondition(sourceFiles.page.includes('Electron 39.8.10'), 'portfolio ui zeigt maintenance electron baseline', 'Electron 39.8.10 gefunden');
requireCondition(sourceFiles.sidebar.includes("id: 'portfolio'"), 'sidebar hat portfolio navigation', 'Navitem gefunden');
requireCondition(sourceFiles.gitignore.includes('/VIVI_CHAT_SESSIONS.json') && sourceFiles.gitignore.includes('/VIVI_CHAT_THREAD.md'), 'gitignore schuetzt lokale vivi chat rails', 'Vivi chat rails ignoriert');
requireCondition(sourceFiles.closeoutDoc.includes('LIONCOM Maintenance Final') && sourceFiles.closeoutDoc.includes('Portfolio Control Tower V1'), 'maintenance closeout doc vorhanden', closeoutDocPath);
requireCondition(sourceFiles.promptRegistryDoc.includes('Vega Prompt Registry 2026-05-18'), 'prompt registry doc titel', promptRegistryDocPath);
for (const token of ['Launch-Readiness ohne Credentials', 'Provider', 'Mail', 'Stripe', 'Zahlungsfluss', 'Production', 'node scripts/verify_operator_readiness_pass.cjs']) {
  requireCondition(sourceFiles.membershipVerifierPage.includes(token), `membership verifier page enthaelt ${token}`, membershipVerifierPagePath);
}
for (const token of ['Status: completed', 'Credentials opened: false', 'Verdict: not_mature', 'Production go: false']) {
  requireCondition(sourceFiles.operatorReadinessDoc.includes(token), `operator readiness doc enthaelt ${token}`, operatorReadinessDocPath);
}

for (const check of checks) {
  const prefix = check.status === 'pass' ? 'PASS' : 'FAIL';
  console.log(`${prefix}: ${check.name}${check.detail ? ` - ${check.detail}` : ''}`);
}

if (failures.length > 0) {
  console.error(`Portfolio status verifier failed with ${failures.length} failure(s).`);
  process.exit(1);
}

console.log('Portfolio status verifier passed.');
