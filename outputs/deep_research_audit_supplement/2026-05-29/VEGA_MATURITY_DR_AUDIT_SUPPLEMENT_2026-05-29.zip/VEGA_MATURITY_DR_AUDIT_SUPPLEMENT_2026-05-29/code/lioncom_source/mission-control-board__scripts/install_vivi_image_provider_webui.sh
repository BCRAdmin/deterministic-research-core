#!/usr/bin/env bash
set -euo pipefail

support_root="${HOME}/Library/Application Support/LIONCOM"
provider_root="${VIVI_IMAGE_PROVIDER_ROOT:-${support_root}/local-image-provider}"
webui_dir="${provider_root}/stable-diffusion-webui"
model_dir="${webui_dir}/models/Stable-diffusion"
min_free_gb="${VIVI_IMAGE_PROVIDER_MIN_FREE_GB:-25}"

free_gb="$(df -g "${HOME}" | awk 'NR==2 { print $4 }')"
if [[ -z "${free_gb}" || "${free_gb}" -lt "${min_free_gb}" ]]; then
  echo "Nicht genug freier Speicher fuer eine sichere lokale Bildprovider-Installation."
  echo "Frei: ${free_gb:-unbekannt} GB; Minimum: ${min_free_gb} GB."
  echo "Erst Speicher freimachen, dann erneut: npm run vivi:image:install-provider"
  exit 2
fi

if ! command -v brew >/dev/null 2>&1; then
  echo "Homebrew fehlt. Installiere Homebrew zuerst von https://brew.sh und starte dieses Kommando erneut."
  exit 2
fi

for package in cmake protobuf rust python@3.10 git wget; do
  if ! brew list --versions "${package}" >/dev/null 2>&1; then
    brew install "${package}"
  fi
done

mkdir -p "${provider_root}"
if [[ ! -d "${webui_dir}/.git" ]]; then
  git clone https://github.com/AUTOMATIC1111/stable-diffusion-webui.git "${webui_dir}"
fi

mkdir -p "${model_dir}"
cat > "${webui_dir}/webui-user.sh" <<'EOF'
export python_cmd="${python_cmd:-/opt/homebrew/bin/python3.10}"
export PYTORCH_ENABLE_MPS_FALLBACK="${PYTORCH_ENABLE_MPS_FALLBACK:-1}"
export COMMANDLINE_ARGS="${COMMANDLINE_ARGS:---api --server-name 127.0.0.1 --port 7860 --skip-torch-cuda-test --upcast-sampling --no-half-vae --use-cpu interrogate}"
EOF

echo "Stable Diffusion WebUI ist vorbereitet: ${webui_dir}"
echo "Modellordner: ${model_dir}"
echo "Lege mindestens ein .safetensors- oder .ckpt-Modell dort ab."
echo "Start danach: npm run vivi:image:start-provider"
