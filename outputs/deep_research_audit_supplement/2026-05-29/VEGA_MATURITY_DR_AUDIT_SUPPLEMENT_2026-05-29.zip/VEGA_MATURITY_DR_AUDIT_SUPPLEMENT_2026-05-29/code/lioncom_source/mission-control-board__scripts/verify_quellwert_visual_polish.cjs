#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const { loadCatalogModule } = require('./verify_quellwert_public_catalog_contract.cjs');

const forbiddenVisibleTokens = [
  'Buy',
  'Sell',
  'Hold',
  'Overweight',
  'Underweight',
  'Accumulate',
  'Strong Buy',
  'Tactical Trim',
  'Tactical Underweight',
  'Position Sizing',
  'Stop Loss',
  'Kaufen',
  'Verkaufen',
  'Übergewichten',
  'Untergewichten',
  'Checkout',
  'Waitlist',
  'Founder',
  'Membership',
  'Trading',
  'Siemens AG',
  'Finstamm',
];

const viewports = {
  desktop1366: { name: 'desktop-1366', width: 1366, height: 1600, isMobile: false },
  desktop1120: { name: 'desktop-1120', width: 1120, height: 1600, isMobile: false },
  desktop1024: { name: 'desktop-1024', width: 1024, height: 1600, isMobile: false },
  desktop1728: { name: 'desktop-1728', width: 1728, height: 1600, isMobile: false },
  tablet768: { name: 'tablet-768', width: 768, height: 1600, isMobile: false },
  mobile390First: { name: 'mobile-first-390', width: 390, height: 844, isMobile: true },
  mobile390: { name: 'mobile-390', width: 390, height: 1400, isMobile: true },
  mobile430: { name: 'mobile-430', width: 430, height: 1400, isMobile: true },
};

function resolveBaseUrl() {
  if (process.env.MEMBERSHIP_BASE_URL) return process.env.MEMBERSHIP_BASE_URL;
  if (process.env.LIONCOM_BASE_URL) return process.env.LIONCOM_BASE_URL;

  try {
    return execFileSync(process.execPath, [path.join(__dirname, 'resolve_desktop_server_url.mjs')], {
      encoding: 'utf8',
    }).trim();
  } catch {
    return 'http://127.0.0.1:4107';
  }
}

function loadPlaywright() {
  const candidates = [
    'playwright',
    '/Users/BjornRosinger/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright',
  ];

  for (const candidate of candidates) {
    try {
      return require(candidate);
    } catch {
      // Try the next known runtime path.
    }
  }

  throw new Error('Playwright is not available in local node_modules or bundled Codex runtime.');
}

function add(results, check, pass, detail) {
  results.push({ check, pass, detail });
}

function safeName(input) {
  return input.replace(/[^a-z0-9.-]+/gi, '-').replace(/^-+|-+$/g, '');
}

function buildRoutePlan() {
  const catalog = loadCatalogModule();
  const publicRoutes = catalog.getPublicAnalyses().map((analysis) => ({
    kind: 'detail',
    pathname: `/membership/analysen/${analysis.slug}`,
    label: analysis.ticker,
    viewports: [viewports.desktop1366, viewports.tablet768, viewports.mobile390],
  }));

  return [
    {
      kind: 'landing',
      pathname: '/membership',
      label: 'landing',
      viewports: [
        viewports.desktop1120,
        viewports.desktop1366,
        viewports.desktop1728,
        viewports.desktop1024,
        viewports.mobile390First,
        viewports.mobile390,
        viewports.mobile430,
      ],
    },
    {
      kind: 'index',
      pathname: '/membership/analysen',
      label: 'analysen',
      viewports: [viewports.desktop1366, viewports.tablet768, viewports.mobile390],
    },
    {
      kind: 'methodik',
      pathname: '/membership/methodik',
      label: 'methodik',
      viewports: [viewports.desktop1366, viewports.tablet768, viewports.mobile390],
    },
    {
      kind: 'archiv',
      pathname: '/membership/archiv',
      label: 'archiv',
      viewports: [viewports.desktop1366, viewports.tablet768, viewports.mobile390],
    },
    {
      kind: 'verifier',
      pathname: '/membership/verifier',
      label: 'verifier',
      viewports: [viewports.desktop1366, viewports.tablet768, viewports.mobile390],
    },
    {
      kind: 'legal',
      pathname: '/membership/impressum',
      label: 'impressum',
      viewports: [viewports.desktop1366, viewports.mobile390],
    },
    {
      kind: 'legal',
      pathname: '/membership/datenschutz',
      label: 'datenschutz',
      viewports: [viewports.desktop1366, viewports.mobile390],
    },
    {
      kind: 'legal',
      pathname: '/membership/kontakt',
      label: 'kontakt',
      viewports: [viewports.desktop1366, viewports.mobile390],
    },
    ...publicRoutes,
  ];
}

async function collectMetrics(page, kind) {
  return page.evaluate((routeKind) => {
    const box = (selector) => {
      const element = document.querySelector(selector);
      if (!element) return null;
      const rect = element.getBoundingClientRect();
      return {
        x: rect.x,
        y: rect.y,
        width: rect.width,
        height: rect.height,
        right: rect.right,
        bottom: rect.bottom,
      };
    };

    const visibleOverflow = Array.from(document.body.querySelectorAll('*'))
      .filter((element) => {
        if (element.closest('.qw-skip-link, .qwp-skip-link')) return false;
        const style = window.getComputedStyle(element);
        if (style.display === 'none' || style.visibility === 'hidden') return false;
        const rect = element.getBoundingClientRect();
        if (rect.width <= 0 || rect.height <= 0) return false;
        return rect.left < -1 || rect.right > window.innerWidth + 1;
      })
      .slice(0, 8)
      .map((element) => {
        const rect = element.getBoundingClientRect();
        return {
          tag: element.tagName.toLowerCase(),
          className: typeof element.className === 'string' ? element.className : '',
          left: rect.left,
          right: rect.right,
          width: rect.width,
        };
      });

    const archiveLabels = Array.from(
      document.querySelectorAll('.qwp-archive-row:not(.qwp-archive-head) > [data-label]'),
    ).map((element) => ({
      label: element.getAttribute('data-label') || '',
      before: window.getComputedStyle(element, '::before').content,
    }));

    const styleValue = (selector, prop) => {
      const element = document.querySelector(selector);
      if (!element) return null;
      return window.getComputedStyle(element).getPropertyValue(prop);
    };

    return {
      routeKind,
      title: document.title,
      bodyText: document.body.innerText,
      innerWidth: window.innerWidth,
      scrollWidth: document.documentElement.scrollWidth,
      bodyScrollWidth: document.body.scrollWidth,
      scrollHeight: document.documentElement.scrollHeight,
      header: box('.qw-header, .qwp-header'),
      footer: box('.qw-footer, .qwp-footer'),
      landingHero: box('.qw-hero'),
      principles: box('.qw-principle-board'),
      analysis: box('.qw-analysis-card'),
      heroBackgroundImage: styleValue('.qw-hero', 'background-image'),
      heroReferenceHotspots: box('.qw-hero-reference-hotspots'),
      nativeMonolith: box('.qw-monolith'),
      nativeMonolithDisplay: styleValue('.qw-monolith', 'display'),
      landingDisclaimerExists: Boolean(document.querySelector('.qw-page-shell > .qwp-disclaimer')),
      skip: box('.qw-skip-link, .qwp-skip-link'),
      paperHero: box('.qwp-hero'),
      articleHero: box('.qwp-article-hero'),
      gatePanel: box('.qwp-gate-panel'),
      toc: box('.qwp-toc'),
      archiveLabels,
      visibleOverflow,
      navText: Array.from(document.querySelectorAll('.qw-nav a, .qwp-header nav a')).map((link) =>
        link.textContent.trim(),
      ),
    };
  }, kind);
}

async function main() {
  const baseUrl = resolveBaseUrl();
  const outRoot = path.join(
    process.cwd(),
    '.runtime',
    'quellwert-visual-polish',
    new Date().toISOString().replace(/[:.]/g, '-'),
  );
  fs.mkdirSync(outRoot, { recursive: true });

  const { chromium } = loadPlaywright();
  const chromePath = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
  const launchOptions = fs.existsSync(chromePath) ? { executablePath: chromePath } : {};
  const browser = await chromium.launch({ headless: true, ...launchOptions });
  const results = [];
  const routePlan = buildRoutePlan();

  try {
    for (const route of routePlan) {
      for (const viewport of route.viewports) {
        const page = await browser.newPage({
          viewport: { width: viewport.width, height: viewport.height },
          isMobile: viewport.isMobile,
        });
        const response = await page.goto(`${baseUrl}${route.pathname}`, {
          waitUntil: 'networkidle',
          timeout: 15000,
        });
        await page.waitForTimeout(250);

        const screenshotPath = path.join(
          outRoot,
          `${safeName(route.label)}-${viewport.name}.png`,
        );
        await page.screenshot({ path: screenshotPath, fullPage: true });

        const metrics = await collectMetrics(page, route.kind);
        const context = `${route.pathname} @ ${viewport.name}`;

        add(results, `${context} status 200`, response?.status() === 200, `status=${response?.status()}`);
        add(results, `${context} document has no horizontal overflow`, metrics.scrollWidth === metrics.innerWidth, `scrollWidth=${metrics.scrollWidth}; innerWidth=${metrics.innerWidth}`);
        add(results, `${context} body has no horizontal overflow`, metrics.bodyScrollWidth === metrics.innerWidth, `bodyScrollWidth=${metrics.bodyScrollWidth}; innerWidth=${metrics.innerWidth}`);
        add(results, `${context} no visible element spills horizontally`, metrics.visibleOverflow.length === 0, JSON.stringify(metrics.visibleOverflow));
        add(results, `${context} header visible`, Boolean(metrics.header && metrics.header.height > 20), JSON.stringify(metrics.header));
        add(results, `${context} footer visible`, Boolean(metrics.footer && metrics.footer.height > 20), JSON.stringify(metrics.footer));
        add(results, `${context} footer is inside rendered page`, Boolean(metrics.footer && metrics.footer.bottom <= metrics.scrollHeight + 1), `footerBottom=${metrics.footer?.bottom}; scrollHeight=${metrics.scrollHeight}`);

        for (const token of forbiddenVisibleTokens) {
          add(results, `${context} forbidden visible token absent: ${token}`, !metrics.bodyText.includes(token), token);
        }

        if (route.kind === 'landing') {
          add(results, `${context} landing has no extra disclaimer section`, !metrics.landingDisclaimerExists, `exists=${metrics.landingDisclaimerExists}`);
          add(results, `${context} skip link hidden until focus`, Boolean(metrics.skip && metrics.skip.bottom < 0), JSON.stringify(metrics.skip));
          add(results, `${context} principles meet analysis card`, Boolean(metrics.principles && metrics.analysis && Math.abs(metrics.principles.bottom - metrics.analysis.y) < 1), `principlesBottom=${metrics.principles?.bottom}; analysisY=${metrics.analysis?.y}`);
          add(results, `${context} landing primary nav compact`, metrics.navText.join('|') === 'Analysen|Methodik|Archiv|Lesen ↗', metrics.navText.join('|'));
          if (!viewport.isMobile) {
            add(results, `${context} desktop hero uses accepted mockup slice`, Boolean(metrics.heroBackgroundImage && metrics.heroBackgroundImage.includes('hero-full.png')), metrics.heroBackgroundImage);
            add(results, `${context} native monolith layer disabled on desktop`, metrics.nativeMonolithDisplay === 'none' || !metrics.nativeMonolith || metrics.nativeMonolith.width === 0, `display=${metrics.nativeMonolithDisplay}; box=${JSON.stringify(metrics.nativeMonolith)}`);
            add(results, `${context} hero floor meets principles band`, Boolean(metrics.landingHero && metrics.principles && Math.abs(metrics.landingHero.bottom - metrics.principles.y) < 1), `heroBottom=${metrics.landingHero?.bottom}; principlesY=${metrics.principles?.y}`);
            add(results, `${context} landing has no preview side gutters`, Boolean(
                metrics.landingHero &&
                metrics.principles &&
                metrics.analysis &&
                metrics.footer &&
                metrics.landingHero.x <= 1 &&
                metrics.principles.x <= 1 &&
                metrics.analysis.x <= 1 &&
                metrics.footer.x <= 1 &&
                metrics.landingHero.width >= metrics.innerWidth - 1 &&
                metrics.principles.width >= metrics.innerWidth - 1 &&
                metrics.analysis.width >= metrics.innerWidth - 1 &&
                metrics.footer.width >= metrics.innerWidth - 1
            ), `innerWidth=${metrics.innerWidth}; hero=${JSON.stringify(metrics.landingHero)}; principles=${JSON.stringify(metrics.principles)}; analysis=${JSON.stringify(metrics.analysis)}; footer=${JSON.stringify(metrics.footer)}`);
            add(results, `${context} principles align to analysis width`, Boolean(metrics.principles && metrics.analysis && Math.abs(metrics.principles.width - metrics.analysis.width) < 1 && Math.abs(metrics.principles.x - metrics.analysis.x) < 1), `principles=${JSON.stringify(metrics.principles)}; analysis=${JSON.stringify(metrics.analysis)}`);
            add(results, `${context} footer aligns to landing stack axis`, Boolean(metrics.footer && metrics.landingHero && Math.abs(metrics.footer.width - metrics.landingHero.width) < 1 && Math.abs(metrics.footer.x - metrics.landingHero.x) < 1), `footer=${JSON.stringify(metrics.footer)}; hero=${JSON.stringify(metrics.landingHero)}`);
            add(results, `${context} hero hotspots present`, Boolean(metrics.heroReferenceHotspots && metrics.heroReferenceHotspots.height > 100), JSON.stringify(metrics.heroReferenceHotspots));
          }
          if (viewport.isMobile) {
            add(results, `${context} mobile landing nav stays one row`, Boolean(metrics.header && metrics.header.height <= 120), `headerHeight=${metrics.header?.height}`);
          }
        } else if (route.kind === 'detail') {
          add(results, `${context} article hero visible`, Boolean(metrics.articleHero && metrics.articleHero.height > 120), JSON.stringify(metrics.articleHero));
        } else {
          add(results, `${context} paper hero visible`, Boolean(metrics.paperHero && metrics.paperHero.height > 80), JSON.stringify(metrics.paperHero));
        }

        if (route.kind === 'detail') {
          add(results, `${context} detail gate panel visible`, Boolean(metrics.gatePanel && metrics.gatePanel.height > 80), JSON.stringify(metrics.gatePanel));
          add(results, `${context} detail table of contents visible`, Boolean(metrics.toc && metrics.toc.height > 40), JSON.stringify(metrics.toc));
        }

        if (route.kind === 'archiv' && viewport.isMobile) {
          const labeled = metrics.archiveLabels.filter((item) => item.label && item.before && item.before !== 'none');
          add(results, `${context} mobile archive rows expose labels`, labeled.length >= 15, `labels=${labeled.length}`);
        }

        await page.close();
      }
    }
  } finally {
    try {
      await browser.close();
    } catch {
      // Playwright/Chrome can abort in sandboxed environments; treat close failures as non-fatal.
    }
  }

  const failed = results.filter((result) => !result.pass);
  const report = {
    baseUrl,
    outRoot,
    verdict: failed.length === 0 ? 'pass' : 'fail',
    checkedAt: new Date().toISOString(),
    results,
  };

  fs.writeFileSync(path.join(outRoot, 'report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));

  if (failed.length > 0) {
    process.exit(1);
  }
}

function shouldSkipOnPlaywrightFailure(error) {
  const message = String(error?.message || error || '');
  return (
    message.includes('Target page, context or browser has been closed') ||
    message.includes('Playwright is not available') ||
    message.includes('SIGABRT') ||
    message.includes('EPERM')
  );
}

function writeSkipReport(baseUrl, outRoot, error) {
  const report = {
    baseUrl,
    outRoot,
    verdict: 'skip',
    checkedAt: new Date().toISOString(),
    notes: [
      'Playwright/Chrome screenshot QA is not reliable in this environment (sandbox restrictions or browser abort).',
      'This verifier is treated as SKIP; rely on other Quellwert verifiers plus manual browser QA in the full local runtime workspace.',
    ],
    error: {
      name: error?.name || 'Error',
      message: String(error?.message || error || ''),
    },
  };

  try {
    fs.writeFileSync(path.join(outRoot, 'report.json'), JSON.stringify(report, null, 2));
  } catch {
    // Ignore write failures; we still print the report below.
  }

  console.log(JSON.stringify(report, null, 2));
}

main().catch((error) => {
  if (!shouldSkipOnPlaywrightFailure(error)) {
    console.error(error);
    process.exit(1);
  }

  const baseUrl = resolveBaseUrl();
  const outRoot = path.join(
    process.cwd(),
    '.runtime',
    'quellwert-visual-polish',
    new Date().toISOString().replace(/[:.]/g, '-'),
  );

  try {
    fs.mkdirSync(outRoot, { recursive: true });
  } catch {
    // Ignore; writeSkipReport can still print JSON.
  }

  writeSkipReport(baseUrl, outRoot, error);
  process.exit(0);
});
