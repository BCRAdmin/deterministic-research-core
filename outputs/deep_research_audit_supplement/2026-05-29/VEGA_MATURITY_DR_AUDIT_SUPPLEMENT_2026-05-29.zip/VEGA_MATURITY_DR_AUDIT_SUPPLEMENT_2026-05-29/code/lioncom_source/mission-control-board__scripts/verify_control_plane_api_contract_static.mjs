import fs from "node:fs";
import path from "node:path";

const appRoot = process.cwd();
const packageJson = JSON.parse(fs.readFileSync(path.join(appRoot, "package.json"), "utf8"));
const verifierPath = path.join(appRoot, "scripts", "verify_control_plane_v2_local.mjs");
const releaseVerifierPath = path.join(appRoot, "scripts", "verify_control_plane_v2_release.mjs");
const verifier = fs.readFileSync(verifierPath, "utf8");
const releaseVerifier = fs.readFileSync(releaseVerifierPath, "utf8");

const requiredScripts = [
  "verify:control-plane-v2",
  "verify:control-plane-v2:mutating",
  "verify:control-plane-v2:visual",
  "verify:control-plane-v2:release",
  "verify:release-safe",
  "verify:portfolio-status",
];

const requiredVerifierTokens = [
  "/api/control-plane-v2",
  "/api/control-plane-v2/automations",
  "/api/control-plane-v2/flight-pack",
  "protectedStop.status === 409",
  "dispatches tragen lane-metadaten",
  "flight-pack latest-json entspricht api-snapshot",
  "root default zeigt control-plane-v2",
];

const requiredReleaseTokens = [
  "verify:control-plane-v2:visual",
  "vivi-session-health",
  "vivi-night-watchdog",
  "codex-loop-guards",
];

const failures = [];
for (const scriptName of requiredScripts) {
  if (!packageJson.scripts?.[scriptName]) {
    failures.push(`missing package script: ${scriptName}`);
  }
}
for (const token of requiredVerifierTokens) {
  if (!verifier.includes(token)) {
    failures.push(`control-plane local verifier missing token: ${token}`);
  }
}
for (const token of requiredReleaseTokens) {
  if (!releaseVerifier.includes(token)) {
    failures.push(`control-plane release verifier missing token: ${token}`);
  }
}

if (failures.length > 0) {
  console.error("Control-plane static API contract failed:");
  for (const failure of failures) console.error(`- ${failure}`);
  process.exit(1);
}

console.log("Control-plane static API contract passed.");
