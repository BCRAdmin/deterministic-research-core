#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const ts = require('typescript');

const forbiddenPublicTextTokens = [
  'Buy',
  'Sell',
  'Hold',
  'Overweight',
  'Underweight',
  'Accumulate',
  'Strong Buy',
  'Tactical Trim',
  'Tactical Underweight',
  'Position Sizing',
  'Stop Loss',
  'Kaufen',
  'Verkaufen',
  'Übergewichten',
  'Untergewichten',
  'Checkout',
  'Waitlist',
  'Founder',
  'Membership',
];

const asciiUmlautTokens = [
  'oeffentlich',
  'Oeffentlich',
  'fuer',
  'Fuer',
  'waere',
  'Waere',
  'koennte',
  'Koennte',
  'groesser',
  'groesster',
  'zurueck',
  'ueber',
  'Ueber',
];

function loadCatalogModule() {
  const catalogPath = path.join(__dirname, '..', 'lib', 'quellwert', 'analysisCatalog.ts');
  const source = fs.readFileSync(catalogPath, 'utf8');
  const output = ts.transpileModule(source, {
    compilerOptions: {
      esModuleInterop: true,
      module: ts.ModuleKind.CommonJS,
      target: ts.ScriptTarget.ES2020,
    },
    fileName: catalogPath,
  }).outputText;
  const localModule = { exports: {} };
  const execute = new Function('exports', 'require', 'module', '__filename', '__dirname', output);

  execute(localModule.exports, require, localModule, catalogPath, path.dirname(catalogPath));

  return localModule.exports;
}

function publicTextFor(analysis) {
  return [
    analysis.title,
    analysis.subtitle,
    analysis.summary,
    analysis.thesis,
    analysis.nonAdvice?.label,
    ...(analysis.articleBody || []),
    ...(analysis.kpis || []),
    ...(analysis.watchpoints || []),
    ...(analysis.risks || []),
  ]
    .filter(Boolean)
    .join('\n');
}

function add(results, check, pass, detail) {
  results.push({ check, pass, detail });
}

function runPublicCatalogContractChecks() {
  const results = [];
  const catalog = loadCatalogModule();
  const analyses = catalog.quellwertAnalyses || [];
  const publicAnalyses = catalog.getPublicAnalyses();
  const hiddenAnalyses = catalog.getInternalReviewAnalyses();
  const seenSlugs = new Set();
  const gatePath = path.join(__dirname, '..', 'data', 'quellwert', 'googl-public-ready-gate.v1.json');
  const gate = JSON.parse(fs.readFileSync(gatePath, 'utf8'));

  add(results, 'catalog exports at least one analysis', analyses.length > 0, `count=${analyses.length}`);
  add(results, 'catalog has public analyses', publicAnalyses.length > 0, `count=${publicAnalyses.length}`);
  add(results, 'catalog has hidden review analyses', hiddenAnalyses.length > 0, `count=${hiddenAnalyses.length}`);

  for (const analysis of analyses) {
    const slugKey = `catalog slug unique: ${analysis.slug}`;
    add(results, slugKey, !seenSlugs.has(analysis.slug), analysis.slug);
    seenSlugs.add(analysis.slug);

    add(
      results,
      `catalog required identity fields: ${analysis.slug}`,
      Boolean(analysis.slug && analysis.ticker && analysis.company && analysis.title),
      `${analysis.ticker || 'missing ticker'} / ${analysis.company || 'missing company'}`,
    );
  }

  for (const analysis of publicAnalyses) {
    const text = publicTextFor(analysis);
    const gateSummary = catalog.getAnalysisGateSummary(analysis);

    add(
      results,
      `public catalog contract status: ${analysis.slug}`,
      analysis.publicationStatus === 'pilot_ready' && analysis.visibility === 'public',
      `${analysis.publicationStatus}/${analysis.visibility}`,
    );
    add(
      results,
      `public catalog contract score: ${analysis.slug}`,
      Number.isFinite(analysis.qualityScore) && analysis.qualityScore >= 85,
      `qualityScore=${analysis.qualityScore}`,
    );
    add(
      results,
      `public catalog contract source count: ${analysis.slug}`,
      Number.isInteger(analysis.sourceCount) && analysis.sourceCount > 0,
      `sourceCount=${analysis.sourceCount}`,
    );
    add(
      results,
      `public catalog contract evidence exists: ${analysis.slug}`,
      Array.isArray(analysis.evidence) && analysis.evidence.length > 0,
      `evidence=${analysis.evidence?.length || 0}`,
    );
    add(
      results,
      `public catalog contract artifacts exist: ${analysis.slug}`,
      Array.isArray(analysis.localArtifacts) && analysis.localArtifacts.length > 0,
      `localArtifacts=${analysis.localArtifacts?.length || 0}`,
    );
    add(
      results,
      `public catalog article depth: ${analysis.slug}`,
      Array.isArray(analysis.articleBody) &&
        analysis.articleBody.length >= 2 &&
        analysis.articleBody.every((paragraph) => paragraph.length >= 140),
      `articleBody=${analysis.articleBody?.length || 0}`,
    );
    add(
      results,
      `public catalog contract non-advice metadata: ${analysis.slug}`,
      Boolean(
        analysis.asOfDate &&
          analysis.sourceBatch &&
          analysis.reportId &&
          analysis.nonAdvice?.status === 'visible' &&
          analysis.nonAdvice?.label?.includes('keine Anlageberatung'),
      ),
      `${analysis.asOfDate || 'missing date'} / ${analysis.sourceBatch || 'missing batch'} / ${
        analysis.reportId || 'missing report'
      } / ${analysis.nonAdvice?.label || 'missing non-advice label'}`,
    );
    add(
      results,
      `public catalog contract gate summary: ${analysis.slug}`,
      Boolean(gateSummary.reviewLabel && gateSummary.sourceLabel && gateSummary.externalLabel),
      `${gateSummary.reviewLabel}; ${gateSummary.externalLabel}`,
    );

    for (const token of forbiddenPublicTextTokens) {
      add(
        results,
        `public catalog forbidden token absent in ${analysis.slug}: ${token}`,
        !text.includes(token),
        token,
      );
    }

    for (const token of asciiUmlautTokens) {
      add(
        results,
        `public catalog ASCII umlaut token absent in ${analysis.slug}: ${token}`,
        !text.includes(token),
        token,
      );
    }

    if (analysis.displayStatus === 'Public-Ready-Kandidat') {
      add(
        results,
        `public-ready candidate has gate object: ${analysis.slug}`,
        Boolean(analysis.gate),
        analysis.gate?.id || 'missing gate',
      );
      add(
        results,
        `public-ready candidate gate matches registry: ${analysis.slug}`,
        Boolean(analysis.gate) &&
          analysis.gate.id === gate.gateId &&
          analysis.ticker === gate.ticker &&
          analysis.sourceBatch === gate.sourceBatch &&
          analysis.reportId === gate.reportId,
        `${analysis.gate?.id || 'missing gate'} / ${gate.gateId || 'missing gate registry'}`,
      );
      add(
        results,
        `public-ready candidate analysis gate keeps operator approval required: ${analysis.slug}`,
        analysis.gate?.operatorGoRequired === true,
        `operatorGoRequired=${analysis.gate?.operatorGoRequired}`,
      );
      add(
        results,
        `public-ready candidate remains externally gated: ${analysis.slug}`,
        gate.publicPreviewReady === true &&
          gate.externalPublicationReady === false &&
          gate.operatorGoRequired === true,
        `publicPreviewReady=${gate.publicPreviewReady}; externalPublicationReady=${gate.externalPublicationReady}; operatorGoRequired=${gate.operatorGoRequired}`,
      );
      add(
        results,
        `public-ready candidate keeps source registry delta visible: ${analysis.slug}`,
        gate.checks?.some(
          (check) => check.id === 'source_registry_delta_review' && check.status === 'needs_review',
        ),
        analysis.gate?.id || 'missing gate',
      );
    }
  }

  for (const analysis of hiddenAnalyses) {
    add(
      results,
      `hidden catalog contract status: ${analysis.slug}`,
      analysis.visibility === 'hidden' && analysis.publicationStatus === 'manual_review',
      `${analysis.publicationStatus}/${analysis.visibility}`,
    );
    add(
      results,
      `hidden catalog has no public evidence payload: ${analysis.slug}`,
      analysis.evidence.length === 0 && analysis.localArtifacts.length === 0,
      `evidence=${analysis.evidence.length}; localArtifacts=${analysis.localArtifacts.length}`,
    );
  }

  return results;
}

function main() {
  const results = runPublicCatalogContractChecks();
  const failed = results.filter((result) => !result.pass);
  const report = {
    verdict: failed.length === 0 ? 'pass' : 'fail',
    checkedAt: new Date().toISOString(),
    results,
  };

  console.log(JSON.stringify(report, null, 2));

  if (failed.length > 0) {
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}

module.exports = {
  loadCatalogModule,
  runPublicCatalogContractChecks,
};
