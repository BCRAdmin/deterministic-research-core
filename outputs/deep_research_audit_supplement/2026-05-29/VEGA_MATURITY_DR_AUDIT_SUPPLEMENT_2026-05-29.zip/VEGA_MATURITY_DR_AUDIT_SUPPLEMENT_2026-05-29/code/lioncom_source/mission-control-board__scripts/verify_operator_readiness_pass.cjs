#!/usr/bin/env node

const fs = require('node:fs');
const path = require('node:path');

const appRoot = path.resolve(__dirname, '..');
const checks = [];
const failures = [];

const files = {
  metrics: path.join(appRoot, 'lib', 'portfolio', 'portfolio-metrics.ts'),
  calendar: path.join(appRoot, 'lib', 'portfolio', 'review-calendar.ts'),
  types: path.join(appRoot, 'lib', 'types.ts'),
  page: path.join(appRoot, 'components', 'portfolio-control-tower-page.tsx'),
  membershipVerifier: path.join(appRoot, 'app', 'membership', 'verifier', 'page.tsx'),
  portfolioVerifier: path.join(appRoot, 'scripts', 'verify_portfolio_status.mjs'),
  promptRegistry: path.join(appRoot, 'docs', 'VEGA_PROMPT_REGISTRY_2026-05-18.md'),
  docMd: path.join(appRoot, 'docs', 'operator-readiness-pass-2026-05-21.md'),
  docJson: path.join(appRoot, 'docs', 'operator-readiness-pass-2026-05-21.json'),
};

function read(filePath) {
  return fs.readFileSync(filePath, 'utf8');
}

function pass(name, detail = '') {
  checks.push({ name, status: 'PASS', detail });
}

function fail(name, detail = '') {
  checks.push({ name, status: 'FAIL', detail });
  failures.push({ name, detail });
}

function requireCondition(condition, name, detail = '') {
  if (condition) pass(name, detail);
  else fail(name, detail);
}

function sourceBlock(source, marker) {
  const start = source.indexOf(marker);
  if (start === -1) return '';
  const blockStart = source.lastIndexOf('\n  {', start);
  const next = source.indexOf('\n  {', start + marker.length);
  const end = next === -1 ? source.length : next;
  return source.slice(blockStart === -1 ? start : blockStart, end);
}

for (const [label, filePath] of Object.entries(files)) {
  requireCondition(fs.existsSync(filePath), `${label} exists`, filePath);
}

const metrics = read(files.metrics);
const calendar = read(files.calendar);
const types = read(files.types);
const page = read(files.page);
const membershipVerifier = read(files.membershipVerifier);
const portfolioVerifier = read(files.portfolioVerifier);
const promptRegistry = read(files.promptRegistry);
const docMd = read(files.docMd);
const report = JSON.parse(read(files.docJson));
const membershipMetric = sourceBlock(metrics, "id: 'membership.launchReadiness'");
const membershipReview = sourceBlock(calendar, "id: 'membership-launch-readiness-no-credentials'");
const materialbedarfReview = sourceBlock(calendar, "id: 'materialbedarf-data-maturity-2026-05-21'");
const elterngeldReview = sourceBlock(calendar, "id: 'elterngeld-data-maturity-2026-05-21'");

requireCondition(types.includes("'membership-readiness'"), 'types include membership metric card');
requireCondition(types.includes("'membership.launchReadiness'"), 'types include membership stream');
requireCondition(types.includes("'membership'"), 'types include membership review group');

requireCondition(Boolean(membershipMetric), 'membership.launchReadiness metric registered');
requireCondition(membershipMetric.includes("cardId: 'membership-readiness'"), 'membership metric uses readiness card');
requireCondition(/Launch-Readiness ohne Credentials|without credentials|Credential-Free/i.test(membershipMetric), 'membership metric is credential-free');
requireCondition(membershipMetric.includes('productionGo: false'), 'membership metric keeps production closed');
requireCondition(membershipMetric.includes('publicReady: false'), 'membership metric keeps public closed');
for (const gate of ['no provider credentials', 'no mail send', 'no stripe checkout', 'no external launch']) {
  requireCondition(membershipMetric.includes(gate), `membership metric gate: ${gate}`);
}

requireCondition(page.includes('Membership Readiness'), 'portfolio UI shows membership readiness card');
requireCondition(page.includes("'membership-readiness'"), 'portfolio UI registers membership-readiness card id');
requireCondition(page.includes("group === 'membership'"), 'portfolio UI styles membership review group');

for (const [label, block] of [
  ['membership credential-free review', membershipReview],
  ['materialbedarf data maturity review', materialbedarfReview],
  ['elterngeld post-update review', elterngeldReview],
]) {
  requireCondition(Boolean(block), `${label} exists`);
  requireCondition(block.includes('productionGo: false'), `${label} keeps production closed`);
  requireCondition(block.includes('publicReady: false'), `${label} keeps public closed`);
  requireCondition(block.includes('researchAutoPublish: false'), `${label} keeps research publish closed`);
  requireCondition(block.includes('affiliateAutoGo: false'), `${label} keeps affiliate closed`);
  requireCondition(block.includes('trustBypass: false'), `${label} keeps trust bypass closed`);
}
requireCondition(materialbedarfReview.includes("status: 'waiting_for_data'"), 'materialbedarf data maturity waits for data');
requireCondition(elterngeldReview.includes("status: 'waiting_for_data'"), 'elterngeld data maturity waits for data');
requireCondition(materialbedarfReview.includes('2026-05-25') && materialbedarfReview.includes('2026-06-01'), 'materialbedarf next maturity windows recorded');
requireCondition(elterngeldReview.includes('2026-05-15'), 'elterngeld post-update cut recorded');

for (const token of ['Launch-Readiness ohne Credentials', 'Provider', 'Mail', 'Stripe', 'Zahlungsfluss', 'Production', 'node scripts/verify_operator_readiness_pass.cjs']) {
  requireCondition(membershipVerifier.includes(token), `membership verifier includes ${token}`);
}

for (const token of ['membership.launchReadiness', 'Membership Readiness', 'Credential-Free Readiness', 'Data Maturity Check', 'Post-Update GSC Maturity Check', 'operator-readiness-pass-2026-05-21']) {
  requireCondition(portfolioVerifier.includes(token), `portfolio verifier requires ${token}`);
}

requireCondition(promptRegistry.includes('membership.launchReadiness'), 'prompt registry includes membership stream');
requireCondition(promptRegistry.includes('Credential-Free Launch Readiness'), 'prompt registry names credential-free readiness');

for (const token of ['Status: completed', 'Credentials opened: false', 'Verdict: not_mature', 'Provider credentials: closed', 'Production go: false']) {
  requireCondition(docMd.includes(token), `readiness doc includes ${token}`);
}

requireCondition(report.status === 'completed', 'report status completed', report.status);
requireCondition(report.credentialsOpened === false, 'report credentials remain closed', String(report.credentialsOpened));
requireCondition(report.productionGo === false, 'report production remains closed', String(report.productionGo));
requireCondition(report.publicReady === false, 'report public remains closed', String(report.publicReady));
requireCondition(report.membership?.streamId === 'membership.launchReadiness', 'report membership stream id', report.membership?.streamId);
requireCondition(report.utilityDataMaturity?.verdict === 'not_mature', 'utility maturity verdict not mature', report.utilityDataMaturity?.verdict);
requireCondition(report.utilityDataMaturity?.materialbedarf?.technicalLiveChecks === 'green', 'materialbedarf technical checks recorded');
requireCondition(report.utilityDataMaturity?.materialbedarf?.matureDecisionData === false, 'materialbedarf decision data not mature');
requireCondition(report.utilityDataMaturity?.elterngeld?.postUpdateWindowAvailable === false, 'elterngeld post-update window missing');

for (const check of checks) {
  console.log(`${check.status}: ${check.name}${check.detail ? ` - ${check.detail}` : ''}`);
}

if (failures.length > 0) {
  console.error(`Operator readiness verifier failed with ${failures.length} failure(s).`);
  process.exit(1);
}

console.log('Operator readiness verifier passed.');
