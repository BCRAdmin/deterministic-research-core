#!/usr/bin/env node

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const supportDir = path.join(os.homedir(), 'Library', 'Application Support', 'LIONCOM');
const workspaceRoot = process.env.VIVI_WORKSPACE_ROOT
  || process.env.LIONCOM_WORKSPACE_ROOT
  || path.join(supportDir, 'runtime-workspace');
const appRoot = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const settingsPath = path.join(supportDir, 'settings.json');
const overridePath = path.join(workspaceRoot, '.runtime', 'vivi-model-override.json');
const loopStatusPath = path.join(workspaceRoot, '.runtime', 'local-duo-loop-status.json');
const statusPath = path.join(workspaceRoot, '.runtime', 'vivi-model-route-status.json');
const canary = process.argv.includes('--canary');
const failures = [];
const warnings = [];
const checks = [];

function readJson(filePath, fallback = null) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return fallback;
  }
}

function add(status, name, detail) {
  checks.push({ status, name, detail });
  if (status === 'fail') failures.push({ name, detail });
  if (status === 'warn') warnings.push({ name, detail });
}

async function fetchJson(url, init = {}) {
  const response = await fetch(url, {
    ...init,
    headers: {
      'content-type': 'application/json',
      ...(init.headers || {}),
    },
    signal: AbortSignal.timeout(Number(process.env.VIVI_MODEL_ROUTE_TIMEOUT_MS || 20_000)),
  });
  const text = await response.text();
  let body = null;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    throw new Error(`${url} returned non-JSON: ${text.slice(0, 500)}`);
  }
  if (!response.ok) {
    throw new Error(`${url} HTTP ${response.status}: ${JSON.stringify(body).slice(0, 800)}`);
  }
  return body;
}

function probeBridge() {
  const bridge = path.join(workspaceRoot, 'scripts', 'local_route_bridge.cjs');
  if (!fs.existsSync(bridge)) {
    add('fail', 'local_route_bridge vorhanden', bridge);
    return;
  }
  const result = spawnSync(process.execPath, [bridge, 'autonomy', 'GET'], {
    cwd: workspaceRoot,
    encoding: 'utf8',
    timeout: 20_000,
    maxBuffer: 1024 * 1024 * 4,
  });
  add(result.status === 0 ? 'pass' : 'fail', 'local_route_bridge autonomy GET', result.status === 0 ? 'ok' : `${result.status}: ${result.stderr || result.stdout}`);
}

async function verifyLmStudioRoute(requestedModel) {
  const base = (process.env.LMSTUDIO_BASE_URL || process.env.OPENAI_BASE_URL || 'http://127.0.0.1:1234/v1').replace(/\/$/, '');
  const models = await fetchJson(`${base}/models`);
  const modelIds = Array.isArray(models?.data) ? models.data.map((item) => item?.id).filter(Boolean) : [];
  add(modelIds.includes(requestedModel) || modelIds.length > 0 ? 'pass' : 'fail', 'lmstudio model endpoint', modelIds.join(', ') || 'keine Modelle');

  if (!canary) return;
  const response = await fetchJson(`${base}/responses`, {
    method: 'POST',
    body: JSON.stringify({
      model: requestedModel,
      input: 'Antworte exakt mit: LIONCOM_VIVI_CANARY_OK',
      stream: false,
      temperature: 0,
    }),
  });
  const text = String(response?.output_text || response?.output?.[0]?.content?.[0]?.text || '').trim();
  add(text.includes('LIONCOM_VIVI_CANARY_OK') ? 'pass' : 'fail', 'lmstudio generation canary', text.slice(0, 240) || 'leer');
}

async function verifyOllamaRoute(requestedModel) {
  const base = (process.env.OLLAMA_HOST || 'http://127.0.0.1:11434').replace(/\/$/, '');
  const tags = await fetchJson(`${base}/api/tags`);
  const modelNames = Array.isArray(tags?.models) ? tags.models.map((item) => item?.name).filter(Boolean) : [];
  const modelVisible = modelNames.includes(requestedModel) || requestedModel.endsWith(':cloud');
  add(modelVisible ? 'pass' : 'warn', 'ollama model sichtbar', modelNames.slice(0, 12).join(', ') || 'keine lokalen Tags');

  if (!canary) return;
  const response = await fetchJson(`${base}/api/generate`, {
    method: 'POST',
    body: JSON.stringify({
      model: requestedModel,
      prompt: 'Antworte exakt mit: LIONCOM_VIVI_CANARY_OK',
      stream: false,
      think: false,
      keep_alive: '10m',
      options: { temperature: 0 },
    }),
  });
  const text = String(response?.response || '').trim();
  add(text.includes('LIONCOM_VIVI_CANARY_OK') ? 'pass' : 'fail', 'ollama generation canary', text.slice(0, 240) || 'leer');
}

async function main() {
  const settings = readJson(settingsPath, {});
  const override = readJson(overridePath, {});
  const loopStatus = readJson(loopStatusPath, {});
  const provider = override?.providerPreset || settings?.viviProviderPreset || loopStatus?.requestedProvider || 'unknown';
  const requestedModel = override?.requestedModel || settings?.viviRequestedModel || loopStatus?.requestedModel || 'unknown';
  const effectiveProvider = loopStatus?.effectiveProvider || loopStatus?.requestedProvider || provider;
  const effectiveModel = loopStatus?.effectiveModel || loopStatus?.requestedModel || requestedModel;

  add(provider !== 'unknown' ? 'pass' : 'fail', 'requested provider bekannt', String(provider));
  add(requestedModel !== 'unknown' ? 'pass' : 'fail', 'requested model bekannt', String(requestedModel));
  add(effectiveProvider ? 'pass' : 'fail', 'effective provider bekannt', String(effectiveProvider || 'missing'));
  add(effectiveModel ? 'pass' : 'fail', 'effective model bekannt', String(effectiveModel || 'missing'));
  if (provider !== effectiveProvider && loopStatus?.modelState === 'active') {
    add('warn', 'provider override vs effective', `requested=${provider}; effective=${effectiveProvider}`);
  }
  if (requestedModel !== effectiveModel && loopStatus?.modelState === 'active') {
    add('warn', 'model override vs effective', `requested=${requestedModel}; effective=${effectiveModel}`);
  }

  probeBridge();

  try {
    if (effectiveProvider === 'lmstudio' || provider === 'lmstudio') {
      await verifyLmStudioRoute(effectiveModel || requestedModel);
    } else if (effectiveProvider === 'ollama' || provider === 'ollama') {
      await verifyOllamaRoute(effectiveModel || requestedModel);
    } else {
      add('warn', 'provider route probe', `kein lokaler Probe fuer provider=${effectiveProvider || provider}`);
    }
  } catch (error) {
    add(canary ? 'fail' : 'warn', 'provider endpoint probe', error instanceof Error ? error.message : String(error));
  }

  const status = {
    checkedAt: new Date().toISOString(),
    ok: failures.length === 0,
    mode: canary ? 'generation-canary' : 'route-probe',
    appRoot,
    workspaceRoot,
    requested: { provider, model: requestedModel },
    effective: { provider: effectiveProvider, model: effectiveModel },
    loopState: loopStatus?.state || 'unknown',
    checks,
    warnings,
    failures,
  };
  fs.mkdirSync(path.dirname(statusPath), { recursive: true });
  fs.writeFileSync(statusPath, `${JSON.stringify(status, null, 2)}\n`);
  console.log(JSON.stringify(status, null, 2));
  process.exitCode = status.ok ? 0 : 1;
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error));
  process.exit(1);
});
