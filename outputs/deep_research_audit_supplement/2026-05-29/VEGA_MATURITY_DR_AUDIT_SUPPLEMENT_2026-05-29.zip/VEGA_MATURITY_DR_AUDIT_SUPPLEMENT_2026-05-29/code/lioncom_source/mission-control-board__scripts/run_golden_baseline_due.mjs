#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const LIONCOM_ROOT = path.resolve(APP_ROOT, '..');
const OUT_DIR = path.join(APP_ROOT, '.runtime', 'golden-baseline');
const LOCK_DIR = path.join(OUT_DIR, 'due.lock');
const DASHBOARD_DATA_DIR = path.join(LIONCOM_ROOT, 'dashboard', 'data');
const RUNTIME_DASHBOARD_DATA_DIR = path.join(
  process.env.HOME || '',
  'Library',
  'Application Support',
  'LIONCOM',
  'runtime-workspace',
  'dashboard',
  'data',
);
const STATUS_FILE = path.join(DASHBOARD_DATA_DIR, 'golden_baseline_status.json');
const AUTOMATION_FILE_NAME = 'golden_baseline_automation_status.json';
const INTERVAL_HOURS = Number(process.env.LIONCOM_GOLDEN_BASELINE_INTERVAL_HOURS || 12);
const FORCE = process.argv.includes('--force');
const DRY_RUN = process.argv.includes('--dry-run');
const FAST = process.argv.includes('--fast') || process.env.LIONCOM_GOLDEN_BASELINE_DUE_MODE === 'fast';
const SKIP_NETWORK = process.argv.includes('--skip-network') || process.env.LIONCOM_GOLDEN_BASELINE_DUE_MODE === 'local';

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function readJson(filePath) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return null;
  }
}

function writeAutomationStatus(status) {
  const payload = JSON.stringify({
    label: 'com.lioncom.golden-baseline',
    checkedAt: new Date().toISOString(),
    intervalHours: INTERVAL_HOURS,
    dueScript: 'npm run baseline:golden:due',
    ...status,
  }, null, 2);

  for (const dir of [DASHBOARD_DATA_DIR, RUNTIME_DASHBOARD_DATA_DIR]) {
    if (!dir) continue;
    ensureDir(dir);
    fs.writeFileSync(path.join(dir, AUTOMATION_FILE_NAME), payload, 'utf8');
  }
}

function ageHours(iso) {
  const time = new Date(iso || 0).getTime();
  if (!Number.isFinite(time) || time <= 0) return Infinity;
  return (Date.now() - time) / 3_600_000;
}

function dueReason(status) {
  if (!status?.generatedAt) return 'missing_status';
  if (status.verdict !== 'pass') return 'last_run_not_green';
  if (ageHours(status.generatedAt) >= INTERVAL_HOURS) return 'interval_elapsed';
  return '';
}

function acquireLock() {
  ensureDir(OUT_DIR);
  try {
    fs.mkdirSync(LOCK_DIR);
    fs.writeFileSync(path.join(LOCK_DIR, 'pid'), String(process.pid), 'utf8');
    fs.writeFileSync(path.join(LOCK_DIR, 'createdAt'), new Date().toISOString(), 'utf8');
    return true;
  } catch {
    return false;
  }
}

function releaseLock() {
  fs.rmSync(LOCK_DIR, { recursive: true, force: true });
}

const currentStatus = readJson(STATUS_FILE);
const reason = FORCE ? 'forced' : dueReason(currentStatus);
const nextDueAt = currentStatus?.nextDueAt || (
  currentStatus?.generatedAt
    ? new Date(new Date(currentStatus.generatedAt).getTime() + INTERVAL_HOURS * 3_600_000).toISOString()
    : new Date().toISOString()
);

if (!reason) {
  writeAutomationStatus({
    action: 'skipped',
    reason: 'fresh',
    nextDueAt,
    lastBaselineGeneratedAt: currentStatus?.generatedAt || null,
    lastBaselineVerdict: currentStatus?.verdict || 'unknown',
  });
  console.log(JSON.stringify({ action: 'skipped', reason: 'fresh', nextDueAt }, null, 2));
  process.exit(0);
}

if (DRY_RUN) {
  writeAutomationStatus({
    action: 'dry-run',
    reason,
    nextDueAt,
    lastBaselineGeneratedAt: currentStatus?.generatedAt || null,
    lastBaselineVerdict: currentStatus?.verdict || 'unknown',
  });
  console.log(JSON.stringify({ action: 'dry-run', reason, nextDueAt }, null, 2));
  process.exit(0);
}

if (!acquireLock()) {
  writeAutomationStatus({
    action: 'locked',
    reason: 'another_golden_baseline_due_runner_is_active',
    nextDueAt,
    lastBaselineGeneratedAt: currentStatus?.generatedAt || null,
    lastBaselineVerdict: currentStatus?.verdict || 'unknown',
  });
  console.log(JSON.stringify({ action: 'locked', reason: 'already_running' }, null, 2));
  process.exit(0);
}

try {
  const startedAt = new Date().toISOString();
  writeAutomationStatus({
    action: 'running',
    reason,
    startedAt,
    nextDueAt,
    mode: FAST ? 'fast' : SKIP_NETWORK ? 'full-local' : 'full-with-readonly-network',
  });

  const args = [path.join(APP_ROOT, 'scripts', 'run_golden_baseline.mjs')];
  if (FAST) args.push('--fast');
  if (SKIP_NETWORK) args.push('--skip-network');
  const result = spawnSync(process.execPath, args, {
    cwd: APP_ROOT,
    env: process.env,
    encoding: 'utf8',
    timeout: Number(process.env.LIONCOM_GOLDEN_BASELINE_DUE_TIMEOUT_MS || 900_000),
    maxBuffer: 1024 * 1024 * 30,
  });
  const completedAt = new Date().toISOString();
  const latestStatus = readJson(STATUS_FILE);
  const ok = result.status === 0 && latestStatus?.verdict === 'pass';

  writeAutomationStatus({
    action: ok ? 'ran-pass' : 'ran-fail',
    reason,
    startedAt,
    completedAt,
    exitCode: result.status,
    error: result.error?.message || null,
    stdoutTail: String(result.stdout || '').slice(-3000),
    stderrTail: String(result.stderr || '').slice(-3000),
    latestBaselineGeneratedAt: latestStatus?.generatedAt || null,
    latestBaselineVerdict: latestStatus?.verdict || 'unknown',
    nextDueAt: latestStatus?.nextDueAt || nextDueAt,
  });

  console.log(JSON.stringify({
    action: ok ? 'ran-pass' : 'ran-fail',
    reason,
    exitCode: result.status,
    latestBaselineVerdict: latestStatus?.verdict || 'unknown',
  }, null, 2));
  if (!ok) process.exitCode = result.status || 1;
} finally {
  releaseLock();
}
