import fs from 'fs/promises';
import os from 'os';
import path from 'path';

const args = process.argv.slice(2);

function readFlag(name) {
  const match = args.find((arg) => arg.startsWith(`--${name}=`));
  return match ? match.slice(name.length + 3).trim() : '';
}

const providerPreset = (readFlag('provider') || 'ollama').trim();
const requestedModel = readFlag('model');
const scope = (readFlag('scope') || 'runtime').trim();
const clear = args.includes('--clear');

const supportDir = path.join(os.homedir(), 'Library', 'Application Support', 'LIONCOM');
const settingsPath = path.join(supportDir, 'settings.json');
const runtimeOverridePath = path.join(supportDir, 'runtime-workspace', '.runtime', 'vivi-model-override.json');

function normalizeProvider(value) {
  return value === 'chatgpt' || value === 'lmstudio' || value === 'openrouter' ? value : 'ollama';
}

async function readJson(filePath, fallback) {
  try {
    return JSON.parse(await fs.readFile(filePath, 'utf8'));
  } catch {
    return fallback;
  }
}

async function writeJson(filePath, value) {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
}

async function main() {
  if (clear) {
    await fs.rm(runtimeOverridePath, { force: true });
    console.log(JSON.stringify({ ok: true, cleared: true, runtimeOverridePath }, null, 2));
    return;
  }

  if (!requestedModel) {
    throw new Error('Missing --model=<name>');
  }

  const normalizedProvider = normalizeProvider(providerPreset);
  const now = new Date().toISOString();
  const payload = {
    providerPreset: normalizedProvider,
    requestedModel,
    updatedAt: now,
    source: 'manual-override',
  };

  if (scope === 'runtime' || scope === 'both') {
    await writeJson(runtimeOverridePath, payload);
  }

  if (scope === 'settings' || scope === 'both') {
    const settings = await readJson(settingsPath, {});
    await writeJson(settingsPath, {
      ...settings,
      viviProviderPreset: normalizedProvider,
      viviRequestedModel: requestedModel,
    });
  }

  console.log(JSON.stringify({
    ok: true,
    providerPreset: normalizedProvider,
    requestedModel,
    scope,
    runtimeOverridePath,
    settingsPath,
  }, null, 2));
}

await main();
