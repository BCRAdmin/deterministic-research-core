#!/usr/bin/env node

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const appRoot = path.resolve(scriptDir, '..');
const lioncomRoot = path.resolve(appRoot, '..');
const materializerScript = path.join(lioncomRoot, 'scripts/materialize_vivi_report_next_task.py');
const failures = [];
const checks = [];

function record(name, ok, detail) {
  checks.push({ name, ok, detail });
  if (!ok) failures.push({ name, detail });
}

function makeWorkspace(reportText = '', queueText = '# Vivi Command Queue\n\n') {
  const workspaceRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lioncom-materializer-contract-'));
  fs.writeFileSync(path.join(workspaceRoot, 'VIVI_REPORTS.md'), reportText, 'utf8');
  fs.writeFileSync(path.join(workspaceRoot, 'VIVI_COMMAND_QUEUE.md'), queueText, 'utf8');
  return workspaceRoot;
}

function runMaterializer(workspaceRoot, claimId, commandRef, title) {
  const result = spawnSync('python3', [
    materializerScript,
    '--workspace-root', workspaceRoot,
    '--claim-id', claimId,
    '--command-ref', commandRef,
    '--title', title,
  ], {
    cwd: lioncomRoot,
    encoding: 'utf8',
    maxBuffer: 1024 * 1024,
  });
  return {
    exitCode: result.status,
    stdout: result.stdout.trim(),
    stderr: result.stderr.trim(),
    queue: fs.readFileSync(path.join(workspaceRoot, 'VIVI_COMMAND_QUEUE.md'), 'utf8'),
  };
}

function isoHoursAgo(hours) {
  return new Date(Date.now() - hours * 60 * 60 * 1000).toISOString().replace(/\.\d{3}Z$/, 'Z');
}

function reportFixture({ claimId, commandRef, title, nextAction }) {
  return `
## REPORT — ${title}
- Claim: ${claimId}
- Command Ref: ${commandRef}
- State: REPORT
- Project Lane: lioncom-core
- Source Gate: not_applicable
- Summary: Fixture report for materializer contract.

### Next Safe Local Action
${nextAction.trim()}
`;
}

function runNoReportFixture() {
  const workspaceRoot = makeWorkspace('');
  const result = runMaterializer(workspaceRoot, 'VIVI-CLAIM-MAT-NONE', 'LIONCOM-NIGHT-MAT-NONE', 'No Report');
  record('kein Report erzeugt keine Queue-Arbeit', result.exitCode === 0 && result.stdout === 'materializer=no-report', JSON.stringify({
    stdout: result.stdout,
    queueLength: result.queue.length,
  }));
}

function runNonActionableFixture() {
  const claimId = 'VIVI-CLAIM-MAT-META';
  const commandRef = 'LIONCOM-NIGHT-20260515-MATERIALIZER-META';
  const title = 'Materializer Meta Followup';
  const workspaceRoot = makeWorkspace(reportFixture({
    claimId,
    commandRef,
    title,
    nextAction: `
- Title: Read the Context Packet
- Priority: high
- Reason: Read the Context Packet if accessible and await explicit instruction.
`,
  }));
  const result = runMaterializer(workspaceRoot, claimId, commandRef, title);
  record('Meta-Followup wird nicht materialisiert', result.exitCode === 0 && result.stdout.includes('materializer=skipped-non-actionable') && !result.queue.includes('Materialized From Claim'), JSON.stringify({
    stdout: result.stdout,
    queue: result.queue,
  }));
}

function runActionableFixture() {
  const claimId = 'VIVI-CLAIM-MAT-ACTION';
  const commandRef = 'LIONCOM-NIGHT-20260515-MATERIALIZER-ACTION';
  const title = 'Materializer Actionable Followup';
  const workspaceRoot = makeWorkspace(reportFixture({
    claimId,
    commandRef,
    title,
    nextAction: `
- Title: V2 Button Contract Verifier erweitern
- Priority: high
- Reason: Implementiere einen weiteren konkreten Button-Contract und verifiziere ihn mit Visual-QA.
- Context: Control Plane V2 Operator Surface.
`,
  }));
  const first = runMaterializer(workspaceRoot, claimId, commandRef, title);
  const second = runMaterializer(workspaceRoot, claimId, commandRef, title);
  const queuedOnce = first.exitCode === 0
    && first.stdout.includes('materializer=queued')
    && first.queue.includes('V2 Button Contract Verifier erweitern')
    && first.queue.includes('- Source: Vivi Report Materializer')
    && first.queue.includes('- Project Lane: lioncom-core')
    && first.queue.includes('- Resource Class: heavy-local-llm')
    && first.queue.includes('- Parallel Policy: global-heavy-singleton')
    && first.queue.includes(`- Materialized From Claim: ${claimId}`);
  const deduped = second.exitCode === 0
    && second.stdout === 'materializer=already-materialized'
    && (second.queue.match(/Materialized From Claim:/g) || []).length === 1;
  record('konkreter Followup wird genau einmal materialisiert', queuedOnce && deduped, JSON.stringify({
    first: first.stdout,
    second: second.stdout,
    materializedMarkers: (second.queue.match(/Materialized From Claim:/g) || []).length,
  }));
}

function runRecentTitleDedupeFixture() {
  const claimId = 'VIVI-CLAIM-MAT-ACTION-2';
  const commandRef = 'LIONCOM-NIGHT-20260515-MATERIALIZER-ACTION-2';
  const title = 'Materializer Recent Title Dedupe';
  const existingQueue = [
    '# Vivi Command Queue',
    '',
    '### LIONCOM-MAT-20260515000100-V2-BUTTON-CONTRACT-VERIFIER-ERWEITERN',
    `- Added: ${isoHoursAgo(1)}`,
    '- Source: Vivi Report Materializer',
    '- Status: queued',
    '- Priority: high',
    '- Title: V2 Button Contract Verifier erweitern',
    '- Materialized From Claim: VIVI-CLAIM-OLDER',
    '- Materialized From Command Ref: LIONCOM-NIGHT-OLDER',
    '',
  ].join('\n');
  const workspaceRoot = makeWorkspace(reportFixture({
    claimId,
    commandRef,
    title,
    nextAction: `
- Title: V2 Button Contract Verifier erweitern
- Priority: high
- Reason: Implementiere denselben Button-Contract nicht erneut, wenn er bereits frisch materialisiert wurde.
`,
  }), existingQueue);
  const result = runMaterializer(workspaceRoot, claimId, commandRef, title);
  record('frischer gleicher Titel wird nicht erneut materialisiert', result.exitCode === 0 && result.stdout.includes('materializer=already-materialized-title') && (result.queue.match(/Materialized From Claim:/g) || []).length === 1, JSON.stringify({
    stdout: result.stdout,
    materializedMarkers: (result.queue.match(/Materialized From Claim:/g) || []).length,
  }));
}

runNoReportFixture();
runNonActionableFixture();
runActionableFixture();
runRecentTitleDedupeFixture();

const result = {
  ok: failures.length === 0,
  checkedAt: new Date().toISOString(),
  checks,
  failures,
};

console.log(JSON.stringify(result, null, 2));
if (failures.length > 0) process.exit(1);
