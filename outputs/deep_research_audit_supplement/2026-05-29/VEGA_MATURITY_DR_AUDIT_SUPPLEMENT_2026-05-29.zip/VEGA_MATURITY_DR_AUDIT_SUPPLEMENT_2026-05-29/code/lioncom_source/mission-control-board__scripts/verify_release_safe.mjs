import { execFileSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const appRoot = process.cwd();
const repoRoot = path.resolve(appRoot, "..");
const packageJson = JSON.parse(fs.readFileSync(path.join(appRoot, "package.json"), "utf8"));
const serverFile = fs.readFileSync(path.join(appRoot, "server.cjs"), "utf8");
const strict = process.argv.includes("--strict");
const failures = [];
const warnings = [];

const scriptClasses = [
  { name: "dev", pattern: /^(dev|start|start:standalone)$/ },
  { name: "build", pattern: /^(build|build:raw|desktop:prepare-standalone|desktop:sync-live|desktop:verify-v2|desktop:icon|desktop:dist)$/ },
  { name: "safe_verify", pattern: /^(operator-go:health|vivi:model-route|vivi:model-canary|vivi:night-health|vivi:flight-local|vivi:session-health|vivi:skill-registry|vivi:capability-router|vivi:skill-runtime|vivi:quality-gate-contract|vivi:materializer-contract|vivi:image:preflight|vivi:image:provider-check|verify:.*|baseline:golden:local|baseline:golden:due:dry|operator-go:run-due:dry|clean:dry|clean:retention:dry)$/ },
  { name: "mutating_local", pattern: /^(baseline:golden|baseline:golden:fast|baseline:golden:due|operator-go:run-due|vivi:night-run|vivi:night-watchdog|vivi:night-repair|vivi:image:generate|repair:.*|clean:runtime|clean:logs|clean:retention:safe|control-plane-v2:flight-pack|website-delivery:once)$/ },
  { name: "operator_install", pattern: /^(baseline:golden:install-agent|vivi:night-watchdog:install-agent|vivi:model-override|vivi:image:install-provider|vivi:image:start-provider)$/ },
];

for (const scriptName of Object.keys(packageJson.scripts || {})) {
  const scriptClass = scriptClasses.find((candidate) => candidate.pattern.test(scriptName));
  if (!scriptClass) {
    failures.push(`Unclassified npm script: ${scriptName}`);
  }
}

if (!serverFile.includes("process.env.HOSTNAME || '127.0.0.1'")) {
  failures.push("server.cjs must default HOSTNAME to 127.0.0.1.");
}

if (/process\.env\.HOSTNAME\s*\|\|\s*['"]0\.0\.0\.0['"]/.test(serverFile)) {
  failures.push("server.cjs must not default HOSTNAME to 0.0.0.0.");
}

const trackedEnvFiles = execGit(["ls-files", ".env", ".env.*", "**/.env", "**/.env.*"])
  .split("\n")
  .map((line) => line.trim())
  .filter(Boolean)
  .filter((filePath) => !filePath.endsWith(".env.example"));

if (trackedEnvFiles.length > 0) {
  failures.push(`Tracked env files are not release-safe: ${trackedEnvFiles.join(", ")}`);
}

const status = execGit(["status", "--short"]);
if (status.trim()) {
  const message = "Working tree is dirty; commit or intentionally checkpoint before release.";
  if (strict) {
    failures.push(message);
  } else {
    warnings.push(message);
  }
}

if (packageJson.build?.asar === false) {
  warnings.push("Electron build currently has asar=false; keep this documented until release hardening changes it.");
}

for (const warning of warnings) {
  console.warn(`WARN: ${warning}`);
}

if (failures.length > 0) {
  for (const failure of failures) {
    console.error(`FAIL: ${failure}`);
  }
  process.exit(1);
}

console.log("Release-safety baseline passed.");

function execGit(args) {
  return execFileSync("git", ["-C", repoRoot, ...args], {
    encoding: "utf8",
    stdio: ["ignore", "pipe", "ignore"],
  });
}
