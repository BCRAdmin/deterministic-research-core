#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const appRoot = path.resolve(scriptDir, '..');
const baseUrl = (process.env.LIONCOM_BASE_URL || 'http://127.0.0.1:4107').replace(/\/$/, '');

async function requestJson(pathname, init = {}) {
  const response = await fetch(`${baseUrl}${pathname}`, {
    method: init.method || 'GET',
    cache: 'no-store',
    signal: AbortSignal.timeout(Number(process.env.LIONCOM_FLIGHT_PACK_TIMEOUT_MS || 20_000)),
    headers: {
      'content-type': 'application/json',
      ...(init.headers || {}),
    },
    body: init.body,
  });
  const text = await response.text();
  let body = null;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    throw new Error(`${pathname} returned non-JSON: ${text.slice(0, 600)}`);
  }
  if (!response.ok) {
    throw new Error(`${pathname} failed HTTP ${response.status}: ${JSON.stringify(body).slice(0, 800)}`);
  }
  return body;
}

async function main() {
  const result = await requestJson('/api/control-plane-v2/flight-pack', { method: 'POST' });
  const pack = result?.pack;
  if (!result?.ok || !pack?.files?.json || !pack?.files?.markdown) {
    throw new Error(`Flight-Pack creation returned incomplete payload: ${JSON.stringify(result).slice(0, 1000)}`);
  }

  for (const filePath of [pack.files.json, pack.files.markdown]) {
    if (!fs.existsSync(filePath)) {
      throw new Error(`Flight-Pack file missing after creation: ${filePath}`);
    }
  }

  console.log(JSON.stringify({
    ok: true,
    baseUrl,
    releaseReady: pack.status.releaseReady,
    source: pack.status.source,
    qualityGate: pack.status.qualityGateLabel,
    json: pack.files.json,
    markdown: pack.files.markdown,
    appRoot,
  }, null, 2));
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error));
  process.exit(1);
});
