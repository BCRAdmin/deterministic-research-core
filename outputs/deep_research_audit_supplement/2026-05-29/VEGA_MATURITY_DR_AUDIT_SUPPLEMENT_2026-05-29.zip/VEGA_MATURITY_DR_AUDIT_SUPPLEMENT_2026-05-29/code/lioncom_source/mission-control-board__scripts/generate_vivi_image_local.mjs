#!/usr/bin/env node

const baseUrl = (process.env.LIONCOM_BASE_URL || 'http://127.0.0.1:4107').replace(/\/$/, '');

function readFlag(name) {
  const index = process.argv.indexOf(`--${name}`);
  if (index >= 0 && process.argv[index + 1]) return process.argv[index + 1];
  const prefix = `--${name}=`;
  const match = process.argv.find((arg) => arg.startsWith(prefix));
  return match ? match.slice(prefix.length) : '';
}

function numberFlag(name, fallback) {
  const value = Number(readFlag(name));
  return Number.isFinite(value) && value > 0 ? value : fallback;
}

async function fetchJson(pathname, init = {}) {
  const response = await fetch(`${baseUrl}${pathname}`, {
    ...init,
    headers: {
      Accept: 'application/json',
      ...(init.headers || {}),
    },
  });
  const text = await response.text();
  let body = null;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    body = { raw: text.slice(0, 1000) };
  }
  return { response, body };
}

async function main() {
  const prompt = readFlag('prompt') || process.argv.slice(2).filter((arg) => !arg.startsWith('--')).join(' ').trim();
  if (!prompt) {
    console.error('Bitte Prompt angeben: npm run vivi:image:generate -- --prompt "..."');
    process.exit(2);
  }

  const payload = {
    prompt,
    width: numberFlag('width', 768),
    height: numberFlag('height', 768),
    steps: numberFlag('steps', 18),
    cfgScale: numberFlag('cfg-scale', 6),
  };

  const { response, body } = await fetchJson('/api/vivi-skills/run', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      skillId: 'image.generate.local',
      source: 'vivi_image_cli',
      requestedBy: 'operator',
      operatorMessage: prompt,
      payload,
    }),
  });

  if (!response.ok) {
    console.error(`Vivi Skill API Fehler: HTTP ${response.status}`);
    console.error(JSON.stringify(body, null, 2));
    process.exit(1);
  }

  const run = body?.run;
  console.log(`Vivi image run: ${run?.status || 'missing-status'}`);
  console.log(run?.summary || 'Keine Zusammenfassung.');
  if (run?.detail) console.log(run.detail);
  if (Array.isArray(run?.artifacts)) {
    for (const artifact of run.artifacts) {
      console.log(`- ${artifact.label}: ${artifact.value}`);
    }
  }
  if (run?.status !== 'completed') {
    console.log('Provider pruefen: npm run vivi:image:preflight');
    process.exitCode = 2;
  }
}

main().catch((error) => {
  console.error(error instanceof Error ? error.stack || error.message : String(error));
  process.exit(1);
});
