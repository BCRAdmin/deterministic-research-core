#!/usr/bin/env node

const baseUrl = (process.env.LIONCOM_BASE_URL || 'http://127.0.0.1:4107').replace(/\/$/, '');
const requiredSkills = [
  'lioncom.status.read',
  'vivi.model.route',
  'image.generate.provider-check',
  'image.generate.local',
  'repo.inspect.readonly',
  'browser.qa.inspect',
  'media.youtube.transcript',
  'vivi.dispatch.create',
  'vega.handoff.create',
  'vivi.memory.capture',
  'vivi.skill.propose',
  'vivi.skill-hub.local',
  'vivi.skill-hub.remote-dry-run',
];
const checks = [];

function add(name, ok, detail = '') {
  checks.push({ name, ok, detail });
  console.log(`${ok ? 'PASS' : 'FAIL'} ${name}${detail ? ` - ${detail}` : ''}`);
}

async function fetchJson(pathname, init = {}) {
  try {
    const response = await fetch(`${baseUrl}${pathname}`, {
      ...init,
      headers: { Accept: 'application/json', ...(init.headers || {}) },
    });
    const text = await response.text();
    let body = null;
    try {
      body = text ? JSON.parse(text) : null;
    } catch {
      body = { raw: text.slice(0, 500) };
    }
    return { status: response.status, ok: response.ok, body };
  } catch (error) {
    return { status: 0, ok: false, body: { error: error instanceof Error ? error.message : String(error) } };
  }
}

async function main() {
  const snapshot = await fetchJson('/api/vivi-skills');
  const skills = Array.isArray(snapshot.body?.skills) ? snapshot.body.skills : [];
  const ids = new Set(skills.map((skill) => skill.id));
  add('skill registry api erreichbar', snapshot.status === 200, `HTTP ${snapshot.status}`);
  add('skill registry hat hub block', Boolean(snapshot.body?.hub && Array.isArray(snapshot.body.hub.entries)), `${snapshot.body?.hub?.entries?.length ?? 'missing'} entries`);
  add('skill registry hat proposals block', Array.isArray(snapshot.body?.latestProposals), `${snapshot.body?.latestProposals?.length ?? 'missing'} proposals`);
  add('remote install bleibt gesperrt', snapshot.body?.hub?.remoteInstallAllowed === false, `allowed=${snapshot.body?.hub?.remoteInstallAllowed}`);
  add('skill counts enthalten proposals', Number.isFinite(Number(snapshot.body?.counts?.proposals)), `proposals=${snapshot.body?.counts?.proposals}`);

  for (const skillId of requiredSkills) {
    add(`manifest vorhanden: ${skillId}`, ids.has(skillId), skillId);
  }

  const hub = await fetchJson('/api/vivi-skills/hub');
  add('skill hub endpoint erreichbar', hub.status === 200 && Array.isArray(hub.body?.hub?.entries), `HTTP ${hub.status}`);

  const proposal = await fetchJson('/api/vivi-skills/propose', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      capability: 'document.create',
      operatorMessage: 'Verifier: fehlenden Dokument-Skill als sicheren Vega-Auftrag vorschlagen.',
      reason: 'Registry-Verifier prueft Proposal-Pfad.',
    }),
  });
  add('skill proposal api erstellt vega-vorschlag', proposal.status === 200 && proposal.body?.proposal?.requestedCapability === 'document.create', proposal.body?.proposal?.id || `HTTP ${proposal.status}`);

  const failed = checks.filter((check) => !check.ok);
  console.log(JSON.stringify({ ok: failed.length === 0, checkedAt: new Date().toISOString(), baseUrl, checks: checks.length, failures: failed }, null, 2));
  if (failed.length > 0) process.exit(1);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
