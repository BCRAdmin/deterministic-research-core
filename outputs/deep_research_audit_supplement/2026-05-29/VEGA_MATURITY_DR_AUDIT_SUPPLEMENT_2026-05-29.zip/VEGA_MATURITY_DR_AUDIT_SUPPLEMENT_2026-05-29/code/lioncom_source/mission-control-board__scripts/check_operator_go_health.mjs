import fs from 'fs/promises';
import path from 'path';
import { spawnSync } from 'child_process';

function resolveDefaultRuntimeRoot() {
  if (process.env.LIONCOM_RUNTIME_ROOT?.trim()) return process.env.LIONCOM_RUNTIME_ROOT.trim();
  if (process.env.HOME?.trim()) return path.join(process.env.HOME.trim(), 'Library/Application Support/LIONCOM/runtime-workspace');
  return '/Users/BjornRosinger/Library/Application Support/LIONCOM/runtime-workspace';
}

function resolveFallbackRuntimeRoot() {
  return path.join(process.cwd(), '.runtime', 'runtime-workspace');
}

let runtimeRoot = resolveDefaultRuntimeRoot();
let runtimeStatePath = path.join(runtimeRoot, '.recovery', 'operator-go-state.json');
let runtimeHealthPath = path.join(runtimeRoot, '.recovery', 'operator-go-health.json');

function setRuntimeRoot(nextRoot) {
  runtimeRoot = nextRoot;
  runtimeStatePath = path.join(runtimeRoot, '.recovery', 'operator-go-state.json');
  runtimeHealthPath = path.join(runtimeRoot, '.recovery', 'operator-go-health.json');
}

const operatorGoProjects = [
  {
    id: 'materialbedarf',
    manifestPath: '/Users/BjornRosinger/Dreamfactory/utility webseite/materialbedarf-rechner.de/ops/OPERATOR_GO_MANIFEST.json',
    deployScriptPath: '/Users/BjornRosinger/Dreamfactory/utility webseite/materialbedarf-rechner.de/ops/deploy-cloudflare-pages.sh',
    authScriptPath: '/Users/BjornRosinger/Dreamfactory/utility webseite/materialbedarf-rechner.de/ops/check-cloudflare-auth.sh',
  },
  {
    id: 'elterngeld',
    manifestPath: '/Users/BjornRosinger/Dreamfactory/utility webseite/mein-elterngeldrechner.de/docs/OPERATOR_GO_MANIFEST.json',
    deployScriptPath: '/Users/BjornRosinger/Dreamfactory/utility webseite/mein-elterngeldrechner.de/ops/deploy-cloudflare-pages.sh',
    tokenOnlyAuth: [REDACTED]
  },
];

async function ensureJsonFile(filePath, fallback) {
  try {
    const raw = await fs.readFile(filePath, 'utf8');
    return JSON.parse(raw);
  } catch (error) {
    try {
      await fs.mkdir(path.dirname(filePath), { recursive: true });
      await fs.writeFile(filePath, JSON.stringify(fallback, null, 2), 'utf8');
      return fallback;
    } catch (writeError) {
      if (writeError && typeof writeError === 'object' && 'code' in writeError && writeError.code === 'EPERM') {
        const fallbackRoot = resolveFallbackRuntimeRoot();
        if (runtimeRoot !== fallbackRoot) {
          setRuntimeRoot(fallbackRoot);
          const fallbackPath = path.join(runtimeRoot, '.recovery', path.basename(filePath));
          await fs.mkdir(path.dirname(fallbackPath), { recursive: true });
          await fs.writeFile(fallbackPath, JSON.stringify(fallback, null, 2), 'utf8');
          return fallback;
        }
      }
      throw writeError;
    }
  }
}

async function pathExists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

function runCommand(command, commandArgs, options = {}) {
  const result = spawnSync(command, commandArgs, {
    cwd: options.cwd,
    env: { ...process.env, ...options.env },
    encoding: 'utf8',
    maxBuffer: 1024 * 1024 * 10,
    timeout: options.timeoutMs || 45000,
  });

  const timedOut = result.error?.code === 'ETIMEDOUT';
  return {
    ok: !timedOut && result.status === 0,
    stdout: result.stdout?.trim() || '',
    stderr: timedOut ? `Command timed out after ${options.timeoutMs || 45000}ms: ${command} ${commandArgs.join(' ')}` : result.stderr?.trim() || '',
    code: result.status ?? 1,
  };
}

async function hasCloudflareToken() {
  if (process.env.CLOUDFLARE_API_TOKEN?.trim()) return true;
  if (!process.env.HOME) return false;
  return pathExists(path.join(process.env.HOME, '.cloudflare_api_token'));
}

async function loadProjectManifestItems(project) {
  const manifest = await ensureJsonFile(project.manifestPath, { items: [] });
  const items = Array.isArray(manifest.items) ? manifest.items : [];

  return items.map((item) => ({
    ...item,
    projectId: item.projectId || manifest.project?.id || project.id,
  }));
}

async function loadAllManifestItems(projects) {
  const items = new Map();

  for (const project of projects) {
    for (const item of await loadProjectManifestItems(project)) {
      items.set(item.id, item);
    }
  }

  return items;
}

async function checkProjectPreflight(project) {
  const manifestOk = await pathExists(project.manifestPath);
  const deployScriptOk = await pathExists(project.deployScriptPath);

  if (!manifestOk || !deployScriptOk) {
    return {
      projectId: project.id,
      ok: false,
      message: [
        manifestOk ? null : `Manifest fehlt: ${project.manifestPath}`,
        deployScriptOk ? null : `Deploy-Skript fehlt: ${project.deployScriptPath}`,
      ].filter(Boolean).join(' / '),
    };
  }

  if (project.authScriptPath) {
    const authScriptOk = await pathExists(project.authScriptPath);
    if (!authScriptOk) {
      return {
        projectId: project.id,
        ok: false,
        message: `Auth-Skript fehlt: ${project.authScriptPath}`,
      };
    }

    const authCheck = runCommand('bash', [project.authScriptPath], {
      cwd: path.dirname(project.authScriptPath),
      timeoutMs: 60000,
    });

    return {
      projectId: project.id,
      ok: authCheck.ok,
      message: authCheck.stderr || authCheck.stdout || (authCheck.ok ? 'Auth ok' : 'Auth failed'),
    };
  }

  if (project.tokenOnlyAuth) {
    const tokenOk = await hasCloudflareToken();
    return {
      projectId: project.id,
      ok: tokenOk,
      message: tokenOk
        ? 'Cloudflare-Token vorhanden; Deploy-Skript prüft Wrangler beim Lauf.'
        : 'Cloudflare-Token fehlt. Erwartet wird ~/.cloudflare_api_token oder CLOUDFLARE_API_TOKEN.',
    };
  }

  return {
    projectId: project.id,
    ok: true,
    message: 'Kein separater Auth-Check konfiguriert.',
  };
}

async function main() {
  const now = new Date().toISOString();
  const state = await ensureJsonFile(runtimeStatePath, { items: {} });
  const manifestItems = await loadAllManifestItems(operatorGoProjects);

  const approvedItems = Object.entries(state.items || {})
    .filter(([, itemState]) => itemState.reviewState === 'approved' && itemState.scheduledFor && !itemState.publishedAt)
    .map(([itemId, itemState]) => {
      const manifestItem = manifestItems.get(itemId);
      return {
        id: itemId,
        title: manifestItem?.title || itemId,
        projectId: manifestItem?.projectId || 'unknown',
        scheduledFor: itemState.scheduledFor,
      };
    })
    .sort((left, right) => left.scheduledFor.localeCompare(right.scheduledFor));

  const nextDue = approvedItems[0] || null;
  const projectChecks = approvedItems.length > 0
    ? await Promise.all(operatorGoProjects.map(checkProjectPreflight))
    : [];
  const blockingChecks = projectChecks.filter((check) => !check.ok);
  const ok = blockingChecks.length === 0;

  const health = {
    ok,
    checkedAt: now,
    summary: ok
      ? `Operator-Go-Preflight ok. Nächster Batch: ${nextDue ? `${nextDue.title} um ${nextDue.scheduledFor}` : 'kein freigegebener Slot'}.`
      : `Operator-Go-Preflight blockiert. ${blockingChecks.map((check) => `${check.projectId}: ${check.message}`).join(' | ')}`,
    nextDueItemId: nextDue?.id,
    nextDueAt: nextDue?.scheduledFor,
    authOk: ok,
    authMessage: projectChecks.length > 0
      ? projectChecks.map((check) => `${check.projectId}: ${check.message}`).join('\n\n')
      : 'Kein freigegebener Slot; Auth-Preflight übersprungen.',
    projectChecks,
  };

  await fs.mkdir(path.dirname(runtimeHealthPath), { recursive: true });
  await fs.writeFile(runtimeHealthPath, JSON.stringify(health, null, 2), 'utf8');
  console.log(JSON.stringify(health, null, 2));
  process.exitCode = ok ? 0 : 1;
}

await main();
