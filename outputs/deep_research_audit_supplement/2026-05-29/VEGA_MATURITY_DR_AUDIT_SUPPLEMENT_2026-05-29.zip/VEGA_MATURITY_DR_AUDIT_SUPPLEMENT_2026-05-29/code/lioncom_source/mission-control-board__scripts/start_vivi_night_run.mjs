#!/usr/bin/env node

import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

const BASE_URL = (process.env.LIONCOM_BASE_URL || 'http://127.0.0.1:4107').replace(/\/$/, '');
const supportDir = path.join(os.homedir(), 'Library', 'Application Support', 'LIONCOM');
const settingsPath = path.join(supportDir, 'settings.json');
const runtimeOverridePath = path.join(supportDir, 'runtime-workspace', '.runtime', 'vivi-model-override.json');

function nowBerlin() {
  return new Intl.DateTimeFormat('de-DE', {
    dateStyle: 'medium',
    timeStyle: 'short',
    timeZone: 'Europe/Berlin',
  }).format(new Date());
}

function buildNightRunPrompt() {
  return [
    'Vivi Night-Run vom Operator autorisiert.',
    '',
    'Ziel:',
    '- LIONCOM Control Plane V2 und Vivi-Arbeitsraum lokal stabil halten.',
    '- Offene Vivi-Claims, Backlog, Roadmap und Audit-Hinweise in kleinen sicheren Schritten abarbeiten.',
    '- Wenn keine claimbare Arbeit vorhanden ist: lokale Rails erneut analysieren, eine konkrete Roadmap ableiten und genau den naechsten sicheren lokalen Schritt refillen.',
    '',
    'Prioritaet:',
    '1. V2/Vivi lokale Bedienbarkeit: neue Sessions, Chatwechsel, alte Sessions entfernen, Auto-Start-Kontext, Provider-Wahrheit.',
    '2. Keine UI-Grossumbauten; nur gezielte Fixes, Funktionalitaet, Datenwahrheit, Texte und sichtbare Bedienbarkeit schaerfen.',
    '3. Vega/Codex-Arbeit nur als Tech-Cell-Verifikation, Reparatur oder Build-/Diff-/Test-Check nutzen.',
    '',
    'Operator-Gates:',
    '- Keine externen Sends, Deploys, Zahlungen, Credential-Aenderungen, Loeschaktionen ausserhalb klarer lokaler Sessionlisten ohne Operator-Freigabe.',
    '- Keine Produktionsveraenderung ohne explizites Go.',
    '- Bei Unsicherheit kurze lesbare Rueckfrage oder Audit-Hinweis, kein JSON-Dump.',
    '',
    'Erwartetes Ergebnis pro Lauf:',
    '- Eine konkrete Verbesserung, ein verifizierter Report oder ein sauberer naechster Claim.',
    '- Alle dauerhaften Learnings in die passenden Human-Overview-/Runtime-Rails schreiben.',
    '- Wenn der Loop idle ist, den Grund ehrlich nennen und den naechsten sicheren lokalen Refill vorbereiten.',
  ].join('\n');
}

async function readJson(filePath, fallback) {
  try {
    return JSON.parse(await fs.readFile(filePath, 'utf8'));
  } catch {
    return fallback;
  }
}

function normalizeProvider(value) {
  if (value === 'chatgpt' || value === 'lmstudio' || value === 'ollama' || value === 'openrouter') return value;
  return 'ollama';
}

function providerModeFor(providerPreset) {
  return providerPreset === 'chatgpt' || providerPreset === 'openrouter' ? 'cloud' : 'local';
}

function defaultModelFor(providerPreset) {
  if (providerPreset === 'chatgpt') return 'gpt-5.4';
  if (providerPreset === 'openrouter') return 'openai/gpt-5.4';
  if (providerPreset === 'lmstudio') return 'qwen3.5-vivi:9b';
  return 'deepseek-v4-pro:cloud';
}

async function resolveViviRuntime() {
  const [settings, override] = await Promise.all([
    readJson(settingsPath, {}),
    readJson(runtimeOverridePath, {}),
  ]);
  const providerPreset = normalizeProvider(
    process.env.VIVI_NIGHT_RUN_PROVIDER
      || override.providerPreset
      || settings.viviProviderPreset
      || 'ollama',
  );
  const requestedModel = (
    process.env.VIVI_NIGHT_RUN_MODEL
      || override.requestedModel
      || settings.viviRequestedModel
      || defaultModelFor(providerPreset)
  ).trim();

  return {
    providerMode: providerModeFor(providerPreset),
    providerPreset,
    requestedModel,
    source: process.env.VIVI_NIGHT_RUN_MODEL || process.env.VIVI_NIGHT_RUN_PROVIDER
      ? 'env'
      : override.requestedModel || override.providerPreset
        ? 'runtime-override'
        : settings.viviRequestedModel || settings.viviProviderPreset
          ? 'settings'
          : 'default',
  };
}

async function requestJson(path, init) {
  const response = await fetch(`${BASE_URL}${path}`, {
    headers: { 'content-type': 'application/json', ...(init?.headers || {}) },
    ...init,
  });
  const text = await response.text();
  let body;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    body = { raw: text };
  }

  if (!response.ok) {
    throw new Error(`${init?.method || 'GET'} ${path} failed (${response.status}): ${JSON.stringify(body).slice(0, 800)}`);
  }

  return body;
}

async function main() {
  const health = await requestJson('/api/health');
  const runtime = await resolveViviRuntime();
  const title = `Vivi Night-Run ${nowBerlin()}`;
  const topic = 'LIONCOM V2 stabilisieren, Vivi lokal betreiben und offene Claims fortlaufend abarbeiten.';

  const created = await requestJson('/api/vivi-chat', {
    method: 'POST',
    body: JSON.stringify({
      action: 'create-session',
      title,
      topic,
      providerMode: runtime.providerMode,
      providerPreset: runtime.providerPreset,
      requestedModel: runtime.requestedModel,
      applyToRuntime: true,
    }),
  });
  const sessionId = created.snapshot?.activeSessionId || created.snapshot?.sessions?.[0]?.id;
  if (!sessionId) {
    throw new Error('Vivi session was created but no activeSessionId was returned.');
  }

  const queued = await requestJson('/api/vivi-chat', {
    method: 'POST',
    body: JSON.stringify({
      action: 'send-message',
      sessionId,
      message: buildNightRunPrompt(),
      source: 'Vega Night-Run Supervisor',
      providerMode: runtime.providerMode,
      providerPreset: runtime.providerPreset,
      requestedModel: runtime.requestedModel,
      applyToRuntime: true,
    }),
  });

  const started = await requestJson('/api/vivi-chat', {
    method: 'POST',
    body: JSON.stringify({
      action: 'start-local-vivi',
      sessionId,
    }),
  });

  const audit = await requestJson('/api/control-plane-v2/audit');
  const snapshot = queued.snapshot || started.snapshot || created.snapshot;
  const activeSession = snapshot?.sessions?.find((session) => session.id === sessionId) || snapshot?.sessions?.[0];

  console.log(JSON.stringify({
    ok: true,
    baseUrl: BASE_URL,
    health: health.status || health.overall || 'ok',
    session: {
      id: sessionId,
      title: activeSession?.title || title,
      status: activeSession?.status,
      latestActivity: activeSession?.latestActivity,
      reference: activeSession?.lastReference,
    },
    runtime,
    start: started.start,
    audit: {
      overall: audit.overall,
      score: audit.score,
      nextActions: audit.nextActions || [],
    },
  }, null, 2));
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
});
