import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const appRoot = path.resolve(process.cwd());
const supportRoot = path.join(os.homedir(), 'Library', 'Application Support', 'LIONCOM');
const runtimeRoot = path.join(supportRoot, 'runtime-workspace');
const runtimeAppRoot = path.join(runtimeRoot, 'mission-control-board');
const installedAppRoot = '/Applications/LIONCOM.app/Contents/Resources/app';
const distAppRoot = path.join(appRoot, 'dist-desktop', 'mac-arm64', 'LIONCOM.app', 'Contents', 'Resources', 'app');
const dmgPath = path.join(appRoot, 'dist-desktop', 'LIONCOM-0.2.0-mac.dmg');
const requiredWorkspaceMarkers = ['mission-control-board', 'VIVI_CONTROL_LOOP.md', 'WORK_INTAKE.md', 'COMMUNICATION_MESH.md'];

const checks = [];

function add(name, ok, detail = '') {
  checks.push({ name, ok: Boolean(ok), detail });
}

function readText(filePath) {
  return fs.readFileSync(filePath, 'utf8');
}

function readJson(filePath) {
  return JSON.parse(readText(filePath));
}

function exists(filePath) {
  return fs.existsSync(filePath);
}

function buildId(root) {
  const filePath = path.join(root, '.next', 'BUILD_ID');
  return exists(filePath) ? readText(filePath).trim() : '';
}

function hasRequiredNext(root) {
  const required = [
    '.next/BUILD_ID',
    '.next/required-server-files.json',
    '.next/server/next-font-manifest.json',
    '.next/server/app',
    '.next/static',
  ];
  const missing = required.filter((item) => !exists(path.join(root, item)));
  return { ok: missing.length === 0, missing };
}

async function fetchJson(url) {
  try {
    const response = await fetch(url, { headers: { accept: 'application/json' } });
    const text = await response.text();
    return { status: response.status, body: text ? JSON.parse(text) : null };
  } catch (error) {
    return { status: 0, error: error instanceof Error ? error.message : String(error), body: null };
  }
}

async function fetchText(url, options = {}) {
  try {
    const response = await fetch(url, { headers: { accept: 'text/html' }, ...options });
    return { status: response.status, body: await response.text(), location: response.headers.get('location') || '' };
  } catch (error) {
    return { status: 0, body: '', location: '', error: error instanceof Error ? error.message : String(error) };
  }
}

const sourceBuildId = buildId(appRoot);
const installedBuildId = buildId(installedAppRoot);
const runtimeBuildId = buildId(runtimeAppRoot);
const distBuildId = buildId(distAppRoot);

add('source build id vorhanden', Boolean(sourceBuildId), sourceBuildId || 'missing');
add('installed app build id synchron', Boolean(sourceBuildId) && installedBuildId === sourceBuildId, `installed=${installedBuildId || 'missing'} source=${sourceBuildId || 'missing'}`);
add('runtime app build id synchron', Boolean(sourceBuildId) && runtimeBuildId === sourceBuildId, `runtime=${runtimeBuildId || 'missing'} source=${sourceBuildId || 'missing'}`);
add('dist app build id synchron', Boolean(sourceBuildId) && distBuildId === sourceBuildId, `dist=${distBuildId || 'missing'} source=${sourceBuildId || 'missing'}`);

for (const [label, root] of [
  ['installed', installedAppRoot],
  ['runtime', runtimeAppRoot],
  ['dist', distAppRoot],
]) {
  const state = hasRequiredNext(root);
  add(`${label} next artefakte komplett`, state.ok, state.ok ? root : `missing=${state.missing.join(', ')}`);
}

const desktopMain = readText(path.join(appRoot, 'desktop', 'main.cjs'));
const appCss = readText(path.join(appRoot, 'app', 'globals.css'));
const topStatusBar = readText(path.join(appRoot, 'components', 'top-status-bar.tsx'));
const sidebarNav = readText(path.join(appRoot, 'components', 'sidebar-nav.tsx'));
add('desktop oeffnet control-plane-v2 direkt', desktopMain.includes("DEFAULT_CONTROL_PLANE_PATH = '/control-plane-v2'") && desktopMain.includes('${DEFAULT_CONTROL_PLANE_PATH}'), 'native loadURL uses V2 route');
add('desktop default workspace ist runtime-workspace', desktopMain.includes("'runtime-workspace'") && !desktopMain.includes("'Documents', 'New project', 'LIONCOM'"), 'default workspace checked');
add('v2 native drag-zone in topbar aktiv', topStatusBar.includes('control-plane-v2-window-drag') && appCss.includes('.control-plane-v2-window-drag') && appCss.includes('-webkit-app-region: drag'), 'topbar can move the native window');
add('v2 sidebar freie flaechen sind drag-zone', sidebarNav.includes('control-plane-v2-window-drag'), 'sidebar chrome can move the native window');
add('v2 interaktive controls bleiben klickbar', appCss.includes(".control-plane-v2 [role='button']") && appCss.includes('-webkit-app-region: no-drag'), 'buttons, inputs and links are excluded from drag');

const settingsPath = path.join(supportRoot, 'settings.json');
const settings = exists(settingsPath) ? readJson(settingsPath) : {};
add('desktop settings workspace ist runtime-workspace', settings.workspaceRoot === runtimeRoot, settings.workspaceRoot || 'missing');

const missingMarkers = requiredWorkspaceMarkers.filter((marker) => !exists(path.join(runtimeRoot, marker)));
add('runtime workspace marker vollstaendig', missingMarkers.length === 0, missingMarkers.length ? `missing=${missingMarkers.join(', ')}` : runtimeRoot);

const sourcePackage = readJson(path.join(appRoot, 'package.json'));
const installedPackage = exists(path.join(installedAppRoot, 'package.json')) ? readJson(path.join(installedAppRoot, 'package.json')) : {};
const distPackage = exists(path.join(distAppRoot, 'package.json')) ? readJson(path.join(distAppRoot, 'package.json')) : {};
add('installed package version synchron', installedPackage.version === sourcePackage.version, `installed=${installedPackage.version || 'missing'} source=${sourcePackage.version}`);
add('dist package version synchron', distPackage.version === sourcePackage.version, `dist=${distPackage.version || 'missing'} source=${sourcePackage.version}`);

const dmgExists = exists(dmgPath);
const dmgSize = dmgExists ? fs.statSync(dmgPath).size : 0;
add('desktop dmg vorhanden', dmgExists && dmgSize > 1_000_000, dmgExists ? `${dmgPath} (${Math.round(dmgSize / 1024 / 1024)} MB)` : 'missing');

const dashboard = await fetchText('http://127.0.0.1:4107/control-plane-v2');
add('control-plane-v2 live erreichbar', dashboard.status === 200 && dashboard.body.includes('LIONCOM CONTROL PLANE'), `HTTP ${dashboard.status}`);

const root = await fetchText('http://127.0.0.1:4107/', { redirect: 'manual' });
add('root bleibt v2 redirect', root.status >= 300 && root.status < 400 && root.location.includes('/control-plane-v2'), `HTTP ${root.status} location=${root.location || 'missing'}`);

const snapshot = await fetchJson('http://127.0.0.1:4107/api/control-plane-v2');
add('control-plane-v2 api live', snapshot.status === 200 && snapshot.body?.source === 'live', `HTTP ${snapshot.status} source=${snapshot.body?.source || snapshot.error || 'missing'}`);
const operatorLoopStatus = snapshot.body?.operatorLoopStatus || {};
const hasVisibleClaim = Boolean(operatorLoopStatus.claimId && operatorLoopStatus.taskTitle && operatorLoopStatus.taskReference);
const hasReadyNoClaimState = operatorLoopStatus.state === 'ready'
  && operatorLoopStatus.title === 'Vivi bereit'
  && Boolean(operatorLoopStatus.nextAction);
add(
  'operator-loop status sichtbar',
  hasVisibleClaim || hasReadyNoClaimState,
  hasVisibleClaim
    ? `${operatorLoopStatus.taskTitle} / ${operatorLoopStatus.taskReference}`
    : `${operatorLoopStatus.state || 'missing'} / ${operatorLoopStatus.title || 'missing'}`,
);

const failures = checks.filter((check) => !check.ok);
const result = {
  ok: failures.length === 0,
  checkedAt: new Date().toISOString(),
  sourceBuildId,
  installedAppRoot,
  runtimeAppRoot,
  distAppRoot,
  dmgPath,
  checks,
  failures,
};

console.log(JSON.stringify(result, null, 2));
if (failures.length > 0) process.exit(1);
