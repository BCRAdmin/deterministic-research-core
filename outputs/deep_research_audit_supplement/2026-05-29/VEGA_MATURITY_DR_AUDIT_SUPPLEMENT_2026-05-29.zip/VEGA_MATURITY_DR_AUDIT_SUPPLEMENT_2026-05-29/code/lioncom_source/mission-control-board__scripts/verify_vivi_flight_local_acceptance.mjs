#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const baseUrl = (process.env.LIONCOM_BASE_URL || 'http://127.0.0.1:4107').replace(/\/$/, '');
const workspaceRoot = process.env.LIONCOM_WORKSPACE_ROOT
  || process.env.VIVI_WORKSPACE_ROOT
  || path.join(process.env.HOME || '/Users/BjornRosinger', 'Library/Application Support/LIONCOM/runtime-workspace');

const checks = [];
const created = new Set();
const cleanupTokens = new Set(['Vivi Flight Local Acceptance', 'Flight Local Acceptance']);

function add(name, ok, detail = '') {
  checks.push({ name, ok, detail });
  console.log(`${ok ? 'PASS' : 'FAIL'} ${name}${detail ? ` - ${detail}` : ''}`);
}

function fail(name, detail = '') {
  add(name, false, detail);
}

async function fetchJson(pathname, init = {}) {
  try {
    const response = await fetch(`${baseUrl}${pathname}`, {
      ...init,
      cache: 'no-store',
      headers: {
        Accept: 'application/json',
        ...(init.body ? { 'Content-Type': 'application/json' } : {}),
        ...(init.headers || {}),
      },
      signal: AbortSignal.timeout(140_000),
    });
    const text = await response.text();
    let body = null;
    try {
      body = text ? JSON.parse(text) : null;
    } catch {
      body = { raw: text.slice(0, 500) };
    }
    return { status: response.status, ok: response.ok, body };
  } catch (error) {
    return { status: 0, ok: false, body: { error: error instanceof Error ? error.message : String(error) } };
  }
}

async function post(pathname, payload) {
  return fetchJson(pathname, {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

function readText(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch {
    return '';
  }
}

function sessions(snapshot) {
  return Array.isArray(snapshot?.sessions) ? snapshot.sessions : [];
}

function messages(snapshot) {
  return Array.isArray(snapshot?.messages) ? snapshot.messages : [];
}

function findSessionByTitle(snapshot, title) {
  return sessions(snapshot).find((session) => session?.title === title);
}

function findSession(snapshot, sessionId) {
  return sessions(snapshot).find((session) => session?.id === sessionId);
}

function latestMessageFor(snapshot, sessionId, role) {
  return [...messages(snapshot)].reverse().find((message) => message?.sessionId === sessionId && message?.role === role);
}

function archiveContains(sessionId, action) {
  const archivePath = path.join(workspaceRoot, 'VIVI_CHAT_SESSIONS_ARCHIVE.json');
  try {
    const archive = JSON.parse(fs.readFileSync(archivePath, 'utf8'));
    return Array.isArray(archive) && archive.some((entry) => {
      const archivedId = entry?.session?.id || entry?.id;
      return archivedId === sessionId && (!action || entry?.action === action);
    });
  } catch {
    return false;
  }
}

function removeVerifierBlocks(filePath) {
  const text = readText(filePath);
  if (!text) return;
  const firstBlockIndex = text.search(/^###\s+/m);
  if (firstBlockIndex < 0) return;
  const header = text.slice(0, firstBlockIndex);
  const blocks = text.slice(firstBlockIndex).split(/(?=^###\s+)/m);
  const filtered = blocks.filter((block) => {
    for (const token of cleanupTokens) {
      if (token && block.includes(token)) return false;
    }
    return true;
  });
  if (filtered.length !== blocks.length) {
    fs.writeFileSync(filePath, `${header}${filtered.join('')}`.replace(/\n*$/, '\n\n'), 'utf8');
  }
}

async function cleanup() {
  for (const sessionId of Array.from(created)) {
    const snapshot = await fetchJson('/api/vivi-chat');
    if (!findSession(snapshot.body, sessionId)) {
      created.delete(sessionId);
      continue;
    }
    await post('/api/vivi-chat/archive', {
      sessionId,
      reason: 'Vivi Flight Local Acceptance Cleanup',
    });
    created.delete(sessionId);
  }
  removeVerifierBlocks(path.join(workspaceRoot, 'VIVI_COMMAND_QUEUE.md'));
  removeVerifierBlocks(path.join(workspaceRoot, 'WORK_INTAKE.md'));
  removeVerifierBlocks(path.join(workspaceRoot, 'VIVI_CHAT_THREAD.md'));
  removeVerifierBlocks(path.join(workspaceRoot, 'CODEX_INBOX.md'));
}

function verifyCatalog(catalog) {
  const providers = Array.isArray(catalog?.providers) ? catalog.providers : [];
  const models = Array.isArray(catalog?.models) ? catalog.models : [];
  const providerStatus = Array.isArray(catalog?.providerStatus) ? catalog.providerStatus : [];
  const providerKeys = new Set(providers.map((provider) => `${provider.mode}:${provider.value}`));
  const statusKeys = new Set(providerStatus.map((status) => status.key));
  const localModels = models.filter((model) => model.mode === 'local');
  const cloudModels = models.filter((model) => model.mode === 'cloud');
  const openRouterModels = models.filter((model) => model.provider === 'openrouter' && model.mode === 'cloud');

  add('modellkatalog liefert provider-status', providerStatus.length >= providers.length, `${providerStatus.length}/${providers.length}`);
  add('lokale provider getrennt sichtbar', providerKeys.has('local:lmstudio') && providerKeys.has('local:ollama'), Array.from(providerKeys).join(', '));
  add('cloud-provider getrennt sichtbar', providerKeys.has('cloud:ollama') && providerKeys.has('cloud:chatgpt') && providerKeys.has('cloud:openrouter'), Array.from(providerKeys).join(', '));
  add('provider-status deckt alle provider ab', providers.every((provider) => statusKeys.has(`${provider.mode}:${provider.value}`)), Array.from(statusKeys).join(', '));
  add('lokale modelle bleiben lokal', localModels.every((model) => model.mode === 'local' && !String(model.id || '').endsWith(':cloud')), `${localModels.length} lokale Modelle`);
  add('cloud-modelle bleiben cloud', cloudModels.every((model) => model.mode === 'cloud'), `${cloudModels.length} Cloud-Modelle`);
  add('chatgpt katalog enthält gpt-5.4', models.some((model) => model.provider === 'chatgpt' && model.id === 'gpt-5.4'), models.filter((model) => model.provider === 'chatgpt').map((model) => model.id).join(', '));
  add('chatgpt katalog enthält fallback-modell', models.some((model) => model.provider === 'chatgpt' && model.id === 'gpt-5.4-mini'), models.filter((model) => model.provider === 'chatgpt').map((model) => model.id).join(', '));
  add('openrouter modelle ohne alias-mischung', openRouterModels.every((model) => !String(model.id || '').startsWith('~')), openRouterModels.slice(0, 8).map((model) => model.id).join(', '));
  add('openrouter hat kuratierte schnellwahl', openRouterModels.slice(0, 8).some((model) => /gpt|deepseek|kimi/i.test(model.id)), openRouterModels.slice(0, 8).map((model) => model.id).join(', '));
}

async function main() {
  const health = await fetchJson('/api/health');
  add('lokale app health erreichbar', health.status === 200 && (health.body?.overall === 'healthy' || health.body?.status === 'ok'), `HTTP ${health.status}`);

  const catalog = await fetchJson('/api/vivi-model-catalog');
  add('modellkatalog erreichbar', catalog.status === 200, `HTTP ${catalog.status}`);
  if (catalog.status === 200) verifyCatalog(catalog.body);

  const flightPack = spawnSync(process.execPath, ['scripts/create_control_plane_v2_flight_pack.mjs'], {
    cwd: process.cwd(),
    encoding: 'utf8',
    timeout: 120_000,
    maxBuffer: 1024 * 1024 * 5,
  });
  add('flight-pack erzeugbar', flightPack.status === 0, (flightPack.stdout || flightPack.stderr || '').slice(-500));

  const emptyTitle = `Vivi Flight Local Acceptance Empty ${Date.now()}`;
  const empty = await post('/api/vivi-chat', {
    action: 'create-session',
    title: emptyTitle,
    topic: 'Flight Local Acceptance: leere Session entfernen.',
    providerMode: 'local',
    providerPreset: 'lmstudio',
    requestedModel: 'qwen3.5-vivi:9b',
  });
  const emptySessionId = findSessionByTitle(empty.body?.snapshot, emptyTitle)?.id;
  if (emptySessionId) {
    created.add(emptySessionId);
    cleanupTokens.add(emptySessionId);
  }
  add('leere vivi-session anlegen', empty.status === 200 && Boolean(emptySessionId), emptySessionId || `HTTP ${empty.status}`);
  const removeEmpty = await post('/api/vivi-chat/remove', {
    sessionId: emptySessionId,
    confirmEmpty: true,
    reason: 'Vivi Flight Local Acceptance entfernt leere Session.',
  });
  add('leere session entfernen', removeEmpty.status === 200 && !findSession(removeEmpty.body?.snapshot, emptySessionId), `HTTP ${removeEmpty.status}`);
  add('entfernte leere session archiviert', Boolean(emptySessionId) && archiveContains(emptySessionId, 'removed-empty'), emptySessionId || 'missing');
  if (emptySessionId) created.delete(emptySessionId);

  const mainTitle = `Vivi Flight Local Acceptance ${Date.now()}`;
  const create = await post('/api/vivi-chat', {
    action: 'create-session',
    title: mainTitle,
    topic: 'Flight Local Acceptance: Chat, Task, Skills, Start und Archiv.',
    providerMode: 'local',
    providerPreset: 'lmstudio',
    requestedModel: 'qwen3.5-vivi:9b',
  });
  const sessionId = findSessionByTitle(create.body?.snapshot, mainTitle)?.id;
  if (sessionId) {
    created.add(sessionId);
    cleanupTokens.add(sessionId);
  }
  add('flight session anlegen', create.status === 200 && Boolean(sessionId), sessionId || `HTTP ${create.status}`);
  add('flight session boot-kontext sichtbar', Boolean(latestMessageFor(create.body?.snapshot, sessionId, 'system')?.message?.includes('Vivi Auto-Start-Kontext')), sessionId || 'missing');

  const direct = await post('/api/vivi-chat', {
    action: 'send-message',
    sessionId,
    message: 'test',
    source: 'Vivi Flight Local Acceptance',
    autoStart: false,
  });
  const directSession = findSession(direct.body?.snapshot, sessionId);
  const directRef = directSession?.lastReference || '';
  const queueAfterDirect = readText(path.join(workspaceRoot, 'VIVI_COMMAND_QUEUE.md'));
  const intakeAfterDirect = readText(path.join(workspaceRoot, 'WORK_INTAKE.md'));
  add('kurzer chat bleibt direktchat', direct.status === 200 && !direct.body?.skillRun, `HTTP ${direct.status}`);
  add('kurzer chat erzeugt vivi-antwort', Boolean(latestMessageFor(direct.body?.snapshot, sessionId, 'vivi')?.message), latestMessageFor(direct.body?.snapshot, sessionId, 'vivi')?.summary || 'missing');
  add('kurzer chat landet nicht in queue', directRef && !queueAfterDirect.includes(directRef) && !intakeAfterDirect.includes(directRef), directRef || 'missing');

  const task = await post('/api/vivi-chat', {
    action: 'send-message',
    sessionId,
    message: 'Bitte plane eine lokale Offline-Abnahme für Vivi und halte den nächsten sicheren Schritt sichtbar.',
    source: 'Vivi Flight Local Acceptance',
    autoStart: false,
  });
  const taskSession = findSession(task.body?.snapshot, sessionId);
  const taskRef = taskSession?.lastReference || '';
  const queueAfterTask = readText(path.join(workspaceRoot, 'VIVI_COMMAND_QUEUE.md'));
  const intakeAfterTask = readText(path.join(workspaceRoot, 'WORK_INTAKE.md'));
  add('taskartige nachricht bleibt sichtbar', task.status === 200 && Boolean(latestMessageFor(task.body?.snapshot, sessionId, 'operator')?.message), `HTTP ${task.status}`);
  add('taskartige nachricht erzeugt lokale rails', taskRef && queueAfterTask.includes(taskRef) && intakeAfterTask.includes(taskRef), taskRef || 'missing');

  const proposal = await post('/api/vivi-chat', {
    action: 'send-message',
    sessionId,
    message: 'Erstelle mir ein Präsentationsdeck über LIONCOM V2 für die Reise.',
    source: 'Vivi Flight Local Acceptance',
    autoStart: false,
  });
  add('fehlende deck-faehigkeit wird skill-vorschlag', proposal.status === 200 && proposal.body?.skillRun?.skillId === 'vivi.skill.propose', proposal.body?.skillRun?.skillId || `HTTP ${proposal.status}`);

  const handoff = await post('/api/vivi-chat', {
    action: 'send-message',
    sessionId,
    message: 'Fixe einen Bug im Repository und prüfe danach die Tests.',
    source: 'Vivi Flight Local Acceptance',
    autoStart: false,
  });
  add('codewunsch wird vega-uebergabe', handoff.status === 200 && handoff.body?.skillRun?.skillId === 'vega.handoff.create', handoff.body?.skillRun?.skillId || `HTTP ${handoff.status}`);

  const start = await post('/api/vivi-chat', {
    action: 'start-local-vivi',
    sessionId,
  });
  add('vivi start aus flight session', start.status === 200 && start.body?.ok === true, start.body?.start?.detail || `HTTP ${start.status}`);
  add('vivi start im chat sichtbar', Boolean(latestMessageFor(start.body?.snapshot, sessionId, 'vivi')?.message?.includes('Vivi-Start ist angekommen')), latestMessageFor(start.body?.snapshot, sessionId, 'vivi')?.summary || 'missing');

  const removeNonEmpty = await post('/api/vivi-chat/remove', {
    sessionId,
    confirmEmpty: true,
    reason: 'Flight Acceptance erwartet 409, weil Inhalt existiert.',
  });
  add('nicht-leere session nicht loeschbar', removeNonEmpty.status === 409, `HTTP ${removeNonEmpty.status}`);

  const archive = await post('/api/vivi-chat/archive', {
    sessionId,
    reason: 'Vivi Flight Local Acceptance archiviert Testsession.',
  });
  add('flight session archivieren', archive.status === 200 && !findSession(archive.body?.snapshot, sessionId), `HTTP ${archive.status}`);
  add('flight session im archiv', Boolean(sessionId) && archiveContains(sessionId, 'archived'), sessionId || 'missing');
  if (sessionId) created.delete(sessionId);
}

try {
  await main();
} finally {
  await cleanup();
}

const failures = checks.filter((check) => !check.ok);
console.log(JSON.stringify({
  ok: failures.length === 0,
  checkedAt: new Date().toISOString(),
  baseUrl,
  workspaceRoot,
  checks: checks.length,
  failures,
}, null, 2));

if (failures.length > 0) process.exit(1);
