#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const appRoot = path.resolve(scriptDir, '..');
const lioncomRoot = path.resolve(appRoot, '..');
const workspaceRoot = process.env.LIONCOM_WORKSPACE_ROOT
  || process.env.VIVI_WORKSPACE_ROOT
  || path.join(process.env.HOME || '/Users/BjornRosinger', 'Library/Application Support/LIONCOM/runtime-workspace');
const runtimeDir = path.join(workspaceRoot, '.runtime');
const statusPath = path.join(runtimeDir, 'vivi-night-watchdog-status.json');
const flightPackLatestJson = path.join(runtimeDir, 'control-plane-v2-flight-pack', 'latest.json');
const args = new Set(process.argv.slice(2));
const repairEnabled = args.has('--repair') || args.has('--force-repair');
const forceRepair = args.has('--force-repair');
const uid = typeof process.getuid === 'function' ? process.getuid() : 501;
const flightPackRefreshAfterMinutes = Number(process.env.LIONCOM_FLIGHT_PACK_REFRESH_MINUTES || 120);

function tail(value, max = 2000) {
  return String(value || '').slice(-max);
}

function run(command, commandArgs, options = {}) {
  const startedAt = Date.now();
  const result = spawnSync(command, commandArgs, {
    cwd: options.cwd || appRoot,
    env: { ...process.env, ...(options.env || {}) },
    encoding: 'utf8',
    timeout: options.timeoutMs || 120_000,
    maxBuffer: 1024 * 1024 * 12,
  });

  return {
    command: [command, ...commandArgs].join(' '),
    cwd: options.cwd || appRoot,
    ok: result.status === 0 && !result.error,
    exitCode: result.status,
    elapsedMs: Date.now() - startedAt,
    stdoutTail: tail(result.stdout),
    stderrTail: tail(result.stderr),
    error: result.error?.message || null,
  };
}

function parseJsonOutput(output) {
  const text = String(output || '').trim();
  if (!text) return null;
  try {
    return JSON.parse(text);
  } catch {
    const firstBrace = text.indexOf('{');
    const lastBrace = text.lastIndexOf('}');
    if (firstBrace >= 0 && lastBrace > firstBrace) {
      try {
        return JSON.parse(text.slice(firstBrace, lastBrace + 1));
      } catch {
        return null;
      }
    }
  }
  return null;
}

function runHealth() {
  const startedAt = Date.now();
  const result = spawnSync(process.execPath, [path.join(scriptDir, 'check_vivi_night_run_health.mjs')], {
    cwd: appRoot,
    env: { ...process.env },
    encoding: 'utf8',
    timeout: 120_000,
    maxBuffer: 1024 * 1024 * 12,
  });
  const step = {
    command: `${process.execPath} ${path.join(scriptDir, 'check_vivi_night_run_health.mjs')}`,
    cwd: appRoot,
    ok: result.status === 0 && !result.error,
    exitCode: result.status,
    elapsedMs: Date.now() - startedAt,
    stdoutTail: tail(result.stdout),
    stderrTail: tail(result.stderr),
    error: result.error?.message || null,
  };
  const summary = parseJsonOutput(result.stdout) || parseJsonOutput(result.stderr);
  return { step, summary };
}

function failureNames(summary) {
  return Array.isArray(summary?.failures)
    ? summary.failures.map((failure) => String(failure?.name || '').toLowerCase())
    : [];
}

function readJson(filePath) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return null;
  }
}

function ageMinutes(value) {
  if (!value) return Number.POSITIVE_INFINITY;
  const time = Date.parse(value);
  if (!Number.isFinite(time)) return Number.POSITIVE_INFINITY;
  return Math.max(0, (Date.now() - time) / 60_000);
}

function maybeRefreshFlightPack() {
  const snapshot = readJson(flightPackLatestJson);
  const age = ageMinutes(snapshot?.createdAt);
  if (age < flightPackRefreshAfterMinutes) {
    return null;
  }
  const reason = snapshot?.createdAt
    ? `Flight-Pack ${age.toFixed(1)} min alt`
    : 'Flight-Pack fehlt oder hat keine createdAt-Metadaten';
  return {
    id: 'refresh-flight-pack',
    label: `${reason}; Offline-Pack vorsorglich aktualisieren`,
    result: run(process.execPath, [path.join(scriptDir, 'create_control_plane_v2_flight_pack.mjs')], { timeoutMs: 120_000 }),
  };
}

function needsControlPlaneRestart(names) {
  return names.some((name) => (
    name.includes('control-plane-v2 api')
    || name.includes('v2 nutzt live daten')
    || name.includes('control plane')
  ));
}

function needsDuoAgentRepair(names) {
  return names.some((name) => (
    name.includes('local duo loop heartbeat')
    || name.includes('launchagent local-duo-loop')
    || name.includes('runner-kopien synchron')
    || name.includes('runtime-sync schuetzt')
    || name.includes('vivi quality ledger')
    || name.includes('vivi projektspur')
    || name.includes('vivi modellroute')
  ));
}

function needsStaleRefillRepair(names) {
  return names.some((name) => (
    name.includes('alte autonome refill-queue')
    || name.includes('stale refill')
    || name.includes('materialisierte followups')
  ));
}

function needsWatchdogAgentRepair(names) {
  return names.some((name) => name.includes('launchagent vivi-night-watchdog'));
}

function needsFlightPackRepair(names) {
  return names.some((name) => name.includes('flight-pack'));
}

function sleep(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}

function writeStatus(payload) {
  fs.mkdirSync(runtimeDir, { recursive: true });
  fs.writeFileSync(statusPath, `${JSON.stringify(payload, null, 2)}\n`, 'utf8');
}

function repairNightRun(firstHealth) {
  const names = failureNames(firstHealth);
  const actions = [];

  if (needsFlightPackRepair(names) || forceRepair) {
    actions.push({
      id: 'refresh-flight-pack-contract',
      label: 'Flight-Pack nach aktuellem Contract neu erzeugen',
      result: run(process.execPath, [path.join(scriptDir, 'create_control_plane_v2_flight_pack.mjs')], { timeoutMs: 120_000 }),
    });
    sleep(1000);
  }

  if (needsControlPlaneRestart(names) || forceRepair) {
    actions.push({
      id: 'restart-control-plane',
      label: 'Lokale Control Plane neu starten',
      result: run('launchctl', ['kickstart', '-k', `gui/${uid}/com.lioncom.local-control-plane`], { timeoutMs: 60_000 }),
    });
    sleep(2500);
  }

  if (needsDuoAgentRepair(names) || forceRepair) {
    actions.push({
      id: 'install-local-duo-loop-agent',
      label: 'Duo-Loop LaunchAgent synchronisieren und neu starten',
      result: run('bash', ['../scripts/install_local_duo_loop_agent.sh'], { cwd: appRoot, timeoutMs: 180_000 }),
    });
    sleep(3500);
  }

  if (needsStaleRefillRepair(names) || forceRepair) {
    actions.push({
      id: 'reconcile-stale-refill-queue',
      label: 'Alte autonome Refill-Spuren sicher parken',
      result: run(process.execPath, [path.join(scriptDir, 'reconcile_stale_autonomous_refill_queue.mjs')], { timeoutMs: 120_000 }),
    });
    sleep(1000);
  }

  if ((needsWatchdogAgentRepair(names) || forceRepair) && process.env.XPC_SERVICE_NAME !== 'com.lioncom.vivi-night-watchdog') {
    actions.push({
      id: 'kickstart-vivi-night-watchdog',
      label: 'Vivi-Night-Watchdog LaunchAgent neu anstupsen',
      result: run('launchctl', ['kickstart', '-k', `gui/${uid}/com.lioncom.vivi-night-watchdog`], { timeoutMs: 60_000 }),
    });
    sleep(3500);
  }

  if (!needsDuoAgentRepair(names) && !forceRepair) {
    actions.push({
      id: 'kickstart-local-duo-loop',
      label: 'Duo-Loop sicherheitshalber anstupsen',
      result: run('launchctl', ['kickstart', '-k', `gui/${uid}/com.lioncom.local-duo-loop`], { timeoutMs: 60_000 }),
    });
    sleep(1500);
  }

  return actions;
}

function compactHealth(summary) {
  if (!summary) return { ok: false, failures: [{ name: 'health-json', detail: 'Health output konnte nicht gelesen werden.' }] };
  return {
    ok: Boolean(summary.ok),
    checkedAt: summary.checkedAt,
    failures: summary.failures || [],
    warnings: summary.warnings || [],
    checks: Array.isArray(summary.checks)
      ? summary.checks.map((check) => ({ name: check.name, status: check.status, detail: check.detail }))
      : [],
  };
}

function main() {
  const preflightActions = [];
  if (repairEnabled) {
    const flightPackRefresh = maybeRefreshFlightPack();
    if (flightPackRefresh) preflightActions.push(flightPackRefresh);
  }

  const first = runHealth();
  const firstHealth = compactHealth(first.summary);
  const actions = [...preflightActions];

  if ((!firstHealth.ok || forceRepair) && repairEnabled) {
    actions.push(...repairNightRun(firstHealth));
  }

  const second = actions.length > 0 ? runHealth() : null;
  let finalHealth = compactHealth(second?.summary || first.summary);
  const unrepaired = !firstHealth.ok && !repairEnabled;
  let ok = finalHealth.ok && !unrepaired;
  let payload = {
    ok,
    checkedAt: new Date().toISOString(),
    mode: repairEnabled ? 'repair' : 'check',
    statusPath,
    workspaceRoot,
    firstHealth,
    actions,
    finalHealth,
    recommendation: ok
      ? 'Nachtlauf-Rail ist arbeitsfaehig.'
      : repairEnabled
        ? 'Watchdog-Reparatur konnte den Nachtlauf noch nicht freigeben; Vega muss die Failure-Liste pruefen.'
        : 'Mit --repair erneut ausfuehren, wenn die Watchdog-Rail aktiv reparieren soll.',
  };

  if (ok && repairEnabled) {
    writeStatus(payload);
    const finalFlightPackRefresh = {
      id: 'refresh-flight-pack-after-green-status',
      label: 'Flight-Pack nach gruenem Watchdog-Status final aktualisieren',
      result: run(process.execPath, [path.join(scriptDir, 'create_control_plane_v2_flight_pack.mjs')], { timeoutMs: 120_000 }),
    };
    actions.push(finalFlightPackRefresh);
    const third = runHealth();
    finalHealth = compactHealth(third.summary);
    ok = finalHealth.ok && finalFlightPackRefresh.result.ok;
    payload = {
      ...payload,
      ok,
      checkedAt: new Date().toISOString(),
      actions,
      finalHealth,
      recommendation: ok
        ? 'Nachtlauf-Rail ist arbeitsfaehig.'
        : 'Watchdog-Reparatur konnte den finalen Flight-Pack noch nicht freigeben; Vega muss die Failure-Liste pruefen.',
    };
  }

  writeStatus(payload);
  console.log(JSON.stringify(payload, null, 2));
  if (!ok) process.exitCode = 1;
}

main();
