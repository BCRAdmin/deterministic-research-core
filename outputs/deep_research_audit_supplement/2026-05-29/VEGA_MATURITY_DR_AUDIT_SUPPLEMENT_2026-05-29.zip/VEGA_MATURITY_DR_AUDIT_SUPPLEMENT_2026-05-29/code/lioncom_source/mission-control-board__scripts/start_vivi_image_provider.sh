#!/usr/bin/env bash
set -euo pipefail

support_root="${HOME}/Library/Application Support/LIONCOM"
provider_root="${VIVI_IMAGE_PROVIDER_ROOT:-${support_root}/local-image-provider}"
webui_dir="${provider_root}/stable-diffusion-webui"
model_dir="${webui_dir}/models/Stable-diffusion"

if [[ ! -x "${webui_dir}/webui.sh" && ! -f "${webui_dir}/webui.sh" ]]; then
  echo "Stable Diffusion WebUI ist noch nicht installiert."
  echo "Vorbereiten: npm run vivi:image:install-provider"
  exit 2
fi

mkdir -p "${model_dir}"
model_count="$(find "${model_dir}" -maxdepth 1 -type f \( -name '*.safetensors' -o -name '*.ckpt' \) 2>/dev/null | wc -l | tr -d ' ')"
if [[ "${model_count}" = "0" ]]; then
  echo "Kein lokales Modell gefunden."
  echo "Modellordner: ${model_dir}"
  echo "Lege ein .safetensors- oder .ckpt-Modell dort ab und starte erneut."
  exit 2
fi

cat > "${webui_dir}/webui-user.sh" <<'EOF'
export python_cmd="${python_cmd:-/opt/homebrew/bin/python3.10}"
export PYTORCH_ENABLE_MPS_FALLBACK="${PYTORCH_ENABLE_MPS_FALLBACK:-1}"
export COMMANDLINE_ARGS="${COMMANDLINE_ARGS:---api --server-name 127.0.0.1 --port 7860 --skip-torch-cuda-test --upcast-sampling --no-half-vae --use-cpu interrogate}"
EOF

cd "${webui_dir}"
exec bash ./webui.sh
