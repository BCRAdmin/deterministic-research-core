#!/usr/bin/env node

import { execFileSync } from 'node:child_process';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

const HOME = os.homedir();
const SUPPORT_ROOT = path.join(HOME, 'Library', 'Application Support', 'LIONCOM');
const RUNTIME_ROOT = process.env.LIONCOM_RUNTIME_ROOT || path.join(SUPPORT_ROOT, 'runtime-workspace');
const PROVIDER_ROOT = process.env.VIVI_IMAGE_PROVIDER_ROOT || path.join(SUPPORT_ROOT, 'local-image-provider');
const WEBUI_DIR = path.join(PROVIDER_ROOT, 'stable-diffusion-webui');
const MODEL_DIR = path.join(WEBUI_DIR, 'models', 'Stable-diffusion');
const STATUS_DIR = path.join(RUNTIME_ROOT, '.runtime', 'vivi-skills', 'image-provider');
const STATUS_JSON = path.join(STATUS_DIR, 'local-image-provider-status.json');
const STATUS_MD = path.join(STATUS_DIR, 'LOCAL_IMAGE_PROVIDER_STATUS.md');
const RECOMMENDED_FULL_INSTALL_GB = Number(process.env.VIVI_IMAGE_PROVIDER_RECOMMENDED_FREE_GB || 35);
const MINIMUM_NO_MODEL_GB = Number(process.env.VIVI_IMAGE_PROVIDER_MIN_FREE_GB || 25);

const jsonMode = process.argv.includes('--json');
const strictMode = process.argv.includes('--strict');

function run(command, args = []) {
  try {
    return execFileSync(command, args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim();
  } catch {
    return '';
  }
}

async function exists(filePath) {
  try {
    await fs.access(filePath);
    return true;
  } catch {
    return false;
  }
}

function commandPath(name) {
  const value = run('/usr/bin/env', ['bash', '-lc', `command -v ${shellQuote(name)} || true`]);
  return value || null;
}

function shellQuote(value) {
  return `'${String(value).replace(/'/g, "'\\''")}'`;
}

function brewPackageVersion(name) {
  const brew = commandPath('brew');
  if (!brew) return null;
  const value = run(brew, ['list', '--versions', name]);
  return value || null;
}

function dfFreeBytes(target) {
  const output = run('/bin/df', ['-Pk', target]);
  const line = output.split('\n')[1];
  if (!line) return null;
  const parts = line.trim().split(/\s+/);
  const availableKb = Number(parts[3]);
  return Number.isFinite(availableKb) ? availableKb * 1024 : null;
}

async function listModels() {
  try {
    const entries = await fs.readdir(MODEL_DIR, { withFileTypes: true });
    return entries
      .filter((entry) => entry.isFile() && /\.(safetensors|ckpt)$/i.test(entry.name))
      .map((entry) => entry.name)
      .sort();
  } catch {
    return [];
  }
}

async function probe(url) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 1200);
  try {
    const response = await fetch(url, { signal: controller.signal });
    const text = await response.text();
    return {
      ok: response.ok,
      status: response.status,
      detail: response.ok ? `HTTP ${response.status}` : `HTTP ${response.status}: ${text.slice(0, 160)}`,
    };
  } catch (error) {
    return {
      ok: false,
      status: 0,
      detail: error instanceof Error ? error.message : String(error),
    };
  } finally {
    clearTimeout(timeout);
  }
}

function deriveStatus(snapshot) {
  if (snapshot.provider.stableDiffusionApi.ok) return 'ready';
  if (snapshot.provider.installed && snapshot.provider.models.length > 0) return 'needs_start';
  if (snapshot.provider.installed) return 'needs_model';
  if (snapshot.disk.freeGb >= MINIMUM_NO_MODEL_GB) return 'needs_install';
  return 'needs_free_space';
}

function nextActionsFor(status) {
  if (status === 'ready') {
    return [
      'Vivi kann image.generate.local jetzt nutzen.',
      'Direkt erzeugen: npm run vivi:image:generate -- --prompt "dein Bildprompt"',
    ];
  }
  if (status === 'needs_start') {
    return [
      'Lokalen Provider starten: npm run vivi:image:start-provider',
      'Danach pruefen: npm run vivi:image:provider-check',
    ];
  }
  if (status === 'needs_model') {
    return [
      `Mindestens ein .safetensors- oder .ckpt-Modell nach ${MODEL_DIR} legen.`,
      'Danach starten: npm run vivi:image:start-provider',
    ];
  }
  if (status === 'needs_install') {
    return [
      'Provider installieren: npm run vivi:image:install-provider',
      'Modell in den Stable-diffusion-Ordner legen, dann Provider starten.',
    ];
  }
  return [
    `Erst Speicher freimachen. Empfohlen fuer Full-Install plus Modell: ${RECOMMENDED_FULL_INSTALL_GB} GB frei; Minimum ohne Modell: ${MINIMUM_NO_MODEL_GB} GB frei.`,
    'Danach erneut pruefen: npm run vivi:image:preflight',
  ];
}

function renderMarkdown(snapshot) {
  return [
    '# Vivi Lokaler Bildprovider Status',
    '',
    `- Erstellt: ${snapshot.createdAt}`,
    `- Status: ${snapshot.status}`,
    `- Freier Speicher: ${snapshot.disk.freeGb.toFixed(1)} GB`,
    `- Provider-Pfad: ${snapshot.provider.webuiDir}`,
    `- Modell-Pfad: ${snapshot.provider.modelDir}`,
    `- Stable Diffusion API: ${snapshot.provider.stableDiffusionApi.ok ? 'erreichbar' : 'nicht erreichbar'} (${snapshot.provider.stableDiffusionApi.detail})`,
    `- ComfyUI API: ${snapshot.provider.comfyApi.ok ? 'erreichbar' : 'nicht erreichbar'} (${snapshot.provider.comfyApi.detail})`,
    `- WebUI installiert: ${snapshot.provider.installed ? 'ja' : 'nein'}`,
    `- Modelle gefunden: ${snapshot.provider.models.length ? snapshot.provider.models.join(', ') : 'keine'}`,
    '',
    '## Naechste Aktionen',
    '',
    ...snapshot.nextActions.map((action) => `- ${action}`),
    '',
    '## Kommandos',
    '',
    '- `npm run vivi:image:preflight`',
    '- `npm run vivi:image:install-provider`',
    '- `npm run vivi:image:start-provider`',
    '- `npm run vivi:image:provider-check`',
    '- `npm run vivi:image:generate -- --prompt "..."`',
    '',
  ].join('\n');
}

async function main() {
  await fs.mkdir(STATUS_DIR, { recursive: true });
  await fs.mkdir(PROVIDER_ROOT, { recursive: true });
  const freeBytes = dfFreeBytes(HOME);
  const stableDiffusionApi = await probe('http://127.0.0.1:7860/sdapi/v1/options');
  const comfyApi = await probe('http://127.0.0.1:8188/system_stats');
  const models = await listModels();
  const installed = await exists(path.join(WEBUI_DIR, 'webui.sh'));
  const snapshot = {
    createdAt: new Date().toISOString(),
    runtimeRoot: RUNTIME_ROOT,
    disk: {
      checkedPath: HOME,
      freeBytes,
      freeGb: freeBytes ? freeBytes / 1024 / 1024 / 1024 : 0,
      recommendedFullInstallGb: RECOMMENDED_FULL_INSTALL_GB,
      minimumNoModelGb: MINIMUM_NO_MODEL_GB,
    },
    tools: {
      brew: commandPath('brew'),
      git: commandPath('git'),
      curl: commandPath('curl'),
      python310: commandPath('python3.10') || '/opt/homebrew/bin/python3.10',
      python310Installed: Boolean(commandPath('python3.10') || brewPackageVersion('python@3.10')),
      cmake: Boolean(commandPath('cmake') || brewPackageVersion('cmake')),
      protobuf: Boolean(brewPackageVersion('protobuf')),
      rust: Boolean(commandPath('rustc') || brewPackageVersion('rust')),
      wget: Boolean(commandPath('wget') || brewPackageVersion('wget')),
    },
    provider: {
      providerRoot: PROVIDER_ROOT,
      webuiDir: WEBUI_DIR,
      modelDir: MODEL_DIR,
      installed,
      models,
      stableDiffusionApi,
      comfyApi,
    },
    commands: {
      preflight: 'npm run vivi:image:preflight',
      installProvider: 'npm run vivi:image:install-provider',
      startProvider: 'npm run vivi:image:start-provider',
      providerCheck: 'npm run vivi:image:provider-check',
      generate: 'npm run vivi:image:generate -- --prompt "..."',
    },
  };
  snapshot.status = deriveStatus(snapshot);
  snapshot.nextActions = nextActionsFor(snapshot.status);

  await fs.writeFile(STATUS_JSON, `${JSON.stringify(snapshot, null, 2)}\n`, 'utf8');
  await fs.writeFile(STATUS_MD, renderMarkdown(snapshot), 'utf8');

  if (jsonMode) {
    console.log(JSON.stringify(snapshot, null, 2));
  } else {
    console.log(`Vivi image provider status: ${snapshot.status}`);
    console.log(`Free disk: ${snapshot.disk.freeGb.toFixed(1)} GB`);
    console.log(`Status report: ${STATUS_MD}`);
    for (const action of snapshot.nextActions) console.log(`- ${action}`);
  }

  if (strictMode && snapshot.status !== 'ready') {
    process.exitCode = 2;
  }
}

main().catch((error) => {
  console.error(error instanceof Error ? error.stack || error.message : String(error));
  process.exit(1);
});
