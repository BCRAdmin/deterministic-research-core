#!/usr/bin/env node

const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const {
  loadCatalogModule,
  runPublicCatalogContractChecks,
} = require('./verify_quellwert_public_catalog_contract.cjs');

function resolveBaseUrl() {
  if (process.env.MEMBERSHIP_BASE_URL) return process.env.MEMBERSHIP_BASE_URL;
  if (process.env.LIONCOM_BASE_URL) return process.env.LIONCOM_BASE_URL;

  try {
    return execFileSync(process.execPath, [path.join(__dirname, 'resolve_desktop_server_url.mjs')], {
      encoding: 'utf8',
    }).trim();
  } catch {
    return 'http://127.0.0.1:4107';
  }
}

const baseUrl = resolveBaseUrl();
const catalog = loadCatalogModule();
const publicAnalyses = catalog.getPublicAnalyses();
const hiddenAnalyses = catalog.getInternalReviewAnalyses();

const publicAnalysisRoutes = publicAnalyses.map((analysis) => `/membership/analysen/${analysis.slug}`);

const detailRouteChecks = publicAnalyses.map((analysis) => {
  const required = [
      'Quellwert-These',
      'Einordnung',
      'Kernzahlen',
      'Prüfpunkte',
      'Risiken',
      'Evidence',
      'Research-Agent-Batch',
      'keine Anlageberatung',
      'SEC CompanyFacts',
      analysis.displayStatus,
    ];

  if (analysis.gate) {
    required.push(
      'Public-Ready Gate v1',
      'Primärquelle dokumentiert',
      analysis.gate.officialSourceLabel,
      'Registry-Delta',
      'Review offen',
      'Operator-Go erforderlich',
    );
  } else {
    required.push(
      'Pilot-Entwurf',
      'Pilot-Gate offen',
      'Nicht extern freigegeben',
    );
  }

  return {
    pathname: `/membership/analysen/${analysis.slug}`,
    required,
  };
});

const pageChecks = [
  {
    pathname: '/membership',
    required: [
      'Quellwert',
      'Unternehmen lesen. Klarer denken.',
      'Öffentliche Research-Notizen zu Unternehmen.',
      'Alphabet',
      'Beispielanalyse lesen',
      'Quellen',
      'Methode',
      'Risiken',
      'Über Quellwert',
    ],
  },
  {
    pathname: '/membership/analysen',
    required: [
      'Research-Agent-Piloten',
      'Alphabet',
      'Snowflake',
      'Microsoft',
      'Pilot-Entwurf',
      'Lokales Evidence-Paket',
      'Quellenprüfung offen',
      'Operator-Go erforderlich',
      'Nicht extern freigegeben',
      'Analyse öffnen',
    ],
  },
  {
    pathname: '/membership/methodik',
    required: [
      'Quellen zuerst. Interpretation danach.',
      'Datenpaket',
      'Evidence',
      'Reconciliation',
      'Public-Preview-Gate',
      'Aktueller Gate-Stand',
      'Preview ist nicht gleich externe Veröffentlichung.',
      'Non-Advice-Grenze',
      'Operator-Go erforderlich',
      'keine Anlageberatung',
    ],
  },
  {
    pathname: '/membership/archiv',
    required: [
      'Was sichtbar ist, hat ein Gate passiert.',
      'Öffnen',
      'Gate-Status',
      'Interner Review',
      'zurückgestellt',
      ...publicAnalyses.map((analysis) => analysis.shortName),
      ...publicAnalyses.map((analysis) => catalog.getAnalysisGateSummary(analysis).externalLabel),
    ],
  },
  {
    pathname: '/membership/verifier',
    required: [
      'Was Quellwert lokal prüft.',
      'Public-Catalog-Contract',
      'Quellwert-Preview-Verifier',
      'Visual-Polish-Check',
      'Beispiel-Detailseiten',
      'keine externe Veröffentlichung',
      ...(publicAnalysisRoutes.length > 0 ? publicAnalysisRoutes.slice(0, 3) : []),
    ],
  },
  {
    pathname: '/membership/impressum',
    required: [
      'Betreiberangaben vor externer Veröffentlichung.',
      'Operator-Gate',
      'nicht als rechtlich finale Angabe',
    ],
  },
  {
    pathname: '/membership/datenschutz',
    required: [
      'Datenschutzhinweis vor externer Veröffentlichung.',
      'keine Konten',
      'Operator-Gate',
    ],
  },
  {
    pathname: '/membership/kontakt',
    required: [
      'Kontaktweg vor externer Veröffentlichung.',
      'ohne externe Kommunikation',
      'Operator-Gate',
    ],
  },
  ...detailRouteChecks,
];

const forbiddenHtmlTokens = [
  'membership-hold-page',
  'Membership Finanzplattform ist im Hold, nicht im Launch.',
  'Kostenloser Webseiten-MVP',
  'Analysen veroeffentlichen. Traffic lernen.',
  'Publikationsfluss',
  'Vom Artikel ins Archiv',
  'Finstamm',
  'Membership-Funktionen',
  'Source Gate',
  'Quelle geprüft:',
  'E-Mail Automation',
  'PDF / Report',
  'Roadmap Closure',
  'Naechster Produktpfad',
  'Founder-Deal',
  'Founder-Angebot',
  'Jetzt kaufen',
  'Checkout starten',
  'Checkout',
  'Waitlist',
  'Geldfluss',
  'dry_run_file_only',
  'partial_extraction_pending_review',
  'Siemens AG',
  'Oeffentliche',
  'oeffentlich',
  'zugaenglich',
  'Ausschliesslich',
  'Ueber Quellwert',
  'Ausgewaehlte',
  'Geschaeft',
  'Maerkte',
  'groessten',
  'quellengestuetzte',
  'Buy',
  'Sell',
  'Hold',
  'Overweight',
  'Underweight',
  'Accumulate',
  'Strong Buy',
  'Tactical Trim',
  'Tactical Underweight',
  'Position Sizing',
  'Stop Loss',
  'Kaufen',
  'Verkaufen',
  'Übergewichten',
  'Untergewichten',
];

const forbiddenPublicTokens = hiddenAnalyses
  .flatMap((analysis) => [
    analysis.slug,
    analysis.company,
    analysis.shortName,
    analysis.reportId,
    analysis.ticker && analysis.ticker.length >= 3 ? analysis.ticker : null,
  ])
  .filter(Boolean);

const hiddenRoutes = hiddenAnalyses.map((analysis) => `/membership/analysen/${analysis.slug}`);

const requiredAssets = [
  {
    pathname: '/membership/quellwert-monolith.svg',
    label: 'quellwert monolith asset',
    contentType: 'image/svg+xml',
    maxBytes: 12000,
  },
  {
    pathname: '/membership/reference/header-full.png',
    label: 'quellwert desktop header reference',
    contentType: 'image/png',
    width: 1120,
    height: 85,
    maxBytes: 220000,
  },
  {
    pathname: '/membership/reference/hero-full.png',
    label: 'quellwert desktop hero reference',
    contentType: 'image/png',
    width: 1120,
    height: 662,
    maxBytes: 1250000,
  },
  {
    pathname: '/membership/reference/hero-floor.png',
    label: 'quellwert hero floor reference',
    contentType: 'image/png',
    width: 1122,
    height: 125,
    maxBytes: 260000,
  },
  {
    pathname: '/membership/reference/hero-stage.png',
    label: 'quellwert mobile hero-stage reference',
    contentType: 'image/png',
    width: 575,
    height: 620,
    maxBytes: 650000,
  },
  {
    pathname: '/membership/reference/principles-board.png',
    label: 'quellwert principles-board reference',
    contentType: 'image/png',
    width: 1029,
    height: 169,
    maxBytes: 330000,
  },
  {
    pathname: '/membership/reference/analysis-card.png',
    label: 'quellwert analysis-card reference',
    contentType: 'image/png',
    width: 1029,
    height: 365,
    maxBytes: 720000,
  },
  {
    pathname: '/membership/reference/footer.png',
    label: 'quellwert footer reference',
    contentType: 'image/png',
    width: 1120,
    height: 89,
    maxBytes: 240000,
  },
];

async function fetchText(pathname) {
  const response = await fetch(`${baseUrl}${pathname}`, {
    redirect: 'manual',
    signal: AbortSignal.timeout(8000),
  });

  return {
    body: await response.text(),
    status: response.status,
    contentType: response.headers.get('content-type') || '',
  };
}

function resolveLocalText(pathname) {
  const normalized = pathname.split('?')[0] || pathname;
  const projectRoot = path.join(__dirname, '..');

  const pageMap = {
    '/membership': 'app/membership/page.tsx',
    '/membership/analysen': 'app/membership/analysen/page.tsx',
    '/membership/methodik': 'app/membership/methodik/page.tsx',
    '/membership/archiv': 'app/membership/archiv/page.tsx',
    '/membership/verifier': 'app/membership/verifier/page.tsx',
    '/membership/impressum': 'app/membership/impressum/page.tsx',
    '/membership/datenschutz': 'app/membership/datenschutz/page.tsx',
    '/membership/kontakt': 'app/membership/kontakt/page.tsx',
  };

  if (pageMap[normalized]) {
    return fs.readFileSync(path.join(projectRoot, pageMap[normalized]), 'utf8');
  }

  if (normalized.startsWith('/membership/analysen/')) {
    return fs.readFileSync(
      path.join(projectRoot, 'app/membership/analysen/[slug]/page.tsx'),
      'utf8',
    );
  }

  const publicPath = path.join(projectRoot, 'public', normalized);
  if (fs.existsSync(publicPath) && fs.statSync(publicPath).isFile()) {
    return fs.readFileSync(publicPath, 'utf8');
  }

  return '';
}

function resolveLocalAsset(pathname) {
  const normalized = pathname.split('?')[0] || pathname;
  const projectRoot = path.join(__dirname, '..');
  const assetPath = path.join(projectRoot, 'public', normalized);

  if (!fs.existsSync(assetPath)) {
    return { status: 404, contentType: '', body: '' };
  }

  const buffer = fs.readFileSync(assetPath);
  const ext = path.extname(assetPath).toLowerCase();
  const contentType = ext === '.svg' ? 'image/svg+xml' : ext === '.png' ? 'image/png' : '';

  return {
    status: 200,
    contentType,
    body: buffer.toString('utf8'),
  };
}

function getLocalAssetMetadata(pathname) {
  const normalized = pathname.split('?')[0] || pathname;
  const projectRoot = path.join(__dirname, '..');
  const assetPath = path.join(projectRoot, 'public', normalized);

  if (!fs.existsSync(assetPath)) {
    return { exists: false, bytes: 0 };
  }

  const buffer = fs.readFileSync(assetPath);
  const metadata = {
    exists: true,
    bytes: buffer.byteLength,
  };

  if (buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) {
    metadata.width = buffer.readUInt32BE(16);
    metadata.height = buffer.readUInt32BE(20);
  }

  return metadata;
}

function pushLocalAssetMetadataChecks(results, requiredAsset, suffix = '') {
  const metadata = getLocalAssetMetadata(requiredAsset.pathname);
  const labelSuffix = suffix ? ` ${suffix}` : '';

  if (requiredAsset.width || requiredAsset.height) {
    results.push({
      check: `${requiredAsset.label} dimensions${labelSuffix}`,
      pass: metadata.width === requiredAsset.width && metadata.height === requiredAsset.height,
      detail: `width=${metadata.width}; height=${metadata.height}`,
    });
  }

  if (requiredAsset.maxBytes) {
    results.push({
      check: `${requiredAsset.label} size budget${labelSuffix}`,
      pass: metadata.exists && metadata.bytes <= requiredAsset.maxBytes,
      detail: `bytes=${metadata.bytes}; maxBytes=${requiredAsset.maxBytes}`,
    });
  }
}

async function main() {
  const results = [];
  const fetchedPages = new Map();
  const gatePath = path.join(__dirname, '..', 'data', 'quellwert', 'googl-public-ready-gate.v1.json');
  let offline = false;

  for (const result of runPublicCatalogContractChecks()) {
    results.push({
      ...result,
      check: `public catalog contract: ${result.check}`,
    });
  }

  let gate = null;
  try {
    gate = JSON.parse(fs.readFileSync(gatePath, 'utf8'));
  } catch (error) {
    results.push({
      check: 'GOOGL public-ready gate file parses',
      pass: false,
      detail: String(error),
    });
  }

  if (gate) {
    results.push({
      check: 'GOOGL public-ready gate marks public preview ready',
      pass: gate.publicPreviewReady === true,
      detail: `publicPreviewReady=${gate.publicPreviewReady}`,
    });
    results.push({
      check: 'GOOGL public-ready gate keeps external publish gated',
      pass: gate.externalPublicationReady === false && gate.operatorGoRequired === true,
      detail: `externalPublicationReady=${gate.externalPublicationReady}; operatorGoRequired=${gate.operatorGoRequired}`,
    });
    results.push({
      check: 'GOOGL public-ready gate includes official source check',
      pass: JSON.stringify(gate).includes('official_earnings_release_checked'),
      detail: gate.gateId || 'missing gate id',
    });
    results.push({
      check: 'GOOGL public-ready gate keeps source registry delta open',
      pass: gate.checks?.some(
        (check) => check.id === 'source_registry_delta_review' && check.status === 'needs_review',
      ),
      detail: gate.gateId || 'missing gate id',
    });
  }

  try {
    await fetchText('/membership');
  } catch (error) {
    const code = error?.cause?.code || error?.code;
    if (code === 'EPERM') {
      offline = true;
      results.push({
        check: 'preview verifier runs in offline mode when localhost is blocked',
        pass: true,
        detail: `connect blocked (${code}); running file-based checks only`,
      });
    } else {
      throw error;
    }
  }

  if (offline) {
    for (const check of pageChecks) {
      const body = resolveLocalText(check.pathname);
      results.push({
        check: `${check.pathname} local source present`,
        pass: body.length > 0,
        detail: check.pathname,
      });

      for (const token of forbiddenHtmlTokens) {
        results.push({
          check: `${check.pathname} forbidden token absent (local): ${token}`,
          pass: !body.includes(token),
          detail: token,
        });
      }
    }

    for (const requiredAsset of requiredAssets) {
      const asset = resolveLocalAsset(requiredAsset.pathname);
      results.push({
        check: `${requiredAsset.label} exists (local)`,
        pass: asset.status === 200,
        detail: requiredAsset.pathname,
      });
      results.push({
        check: `${requiredAsset.label} type (local)`,
        pass: asset.contentType.includes(requiredAsset.contentType),
        detail: `content-type=${asset.contentType}`,
      });
      pushLocalAssetMetadataChecks(results, requiredAsset, '(local)');
    }

    const failed = results.filter((result) => !result.pass);
    const report = {
      baseUrl,
      offline,
      verdict: failed.length === 0 ? 'pass' : 'fail',
      checkedAt: new Date().toISOString(),
      results,
    };

    console.log(JSON.stringify(report, null, 2));

    if (failed.length > 0) {
      process.exitCode = 1;
    }

    return;
  }

  for (const check of pageChecks) {
    const page = await fetchText(check.pathname);
    fetchedPages.set(check.pathname, page);

    results.push({
      check: `${check.pathname} status`,
      pass: page.status === 200,
      detail: `status=${page.status}`,
    });

    results.push({
      check: `${check.pathname} content-type`,
      pass: page.contentType.includes('text/html'),
      detail: `content-type=${page.contentType}`,
    });

    for (const token of check.required) {
      results.push({
        check: `${check.pathname} required token: ${token}`,
        pass: page.body.includes(token),
        detail: token,
      });
    }

    for (const token of forbiddenHtmlTokens) {
      results.push({
        check: `${check.pathname} forbidden token absent: ${token}`,
        pass: !page.body.includes(token),
        detail: token,
      });
    }
  }

  const publicBodies = ['/membership', '/membership/analysen', '/membership/archiv']
    .map((pathname) => fetchedPages.get(pathname)?.body || '')
    .join('\n');

  for (const token of forbiddenPublicTokens) {
    results.push({
      check: `public index surfaces hide review-only token: ${token}`,
      pass: !publicBodies.includes(token),
      detail: token,
    });
  }

  const analysisIndex = fetchedPages.get('/membership/analysen')?.body || '';
  for (const route of publicAnalysisRoutes) {
    results.push({
      check: `analysis index links ${route}`,
      pass: analysisIndex.includes(route),
      detail: route,
    });
  }

  for (const route of hiddenRoutes) {
    const page = await fetchText(route);
    results.push({
      check: `hidden route blocked: ${route}`,
      pass: page.status === 404,
      detail: `status=${page.status}`,
    });
  }

  for (const requiredAsset of requiredAssets) {
    const asset = await fetchText(requiredAsset.pathname);
    results.push({
      check: `${requiredAsset.label} status`,
      pass: asset.status === 200,
      detail: `status=${asset.status}`,
    });
    results.push({
      check: `${requiredAsset.label} type`,
      pass: asset.contentType.includes(requiredAsset.contentType),
      detail: `content-type=${asset.contentType}`,
    });
    pushLocalAssetMetadataChecks(results, requiredAsset);
  }

  const failed = results.filter((result) => !result.pass);
  const report = {
    baseUrl,
    verdict: failed.length === 0 ? 'pass' : 'fail',
    checkedAt: new Date().toISOString(),
    results,
  };

  console.log(JSON.stringify(report, null, 2));

  if (failed.length > 0) {
    process.exitCode = 1;
  }
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
