#!/usr/bin/env node

import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const baseUrl = (process.env.LIONCOM_BASE_URL || 'http://127.0.0.1:4107').replace(/\/$/, '');
const checks = [];

function add(name, ok, detail = '') {
  checks.push({ name, ok, detail });
  console.log(`${ok ? 'PASS' : 'FAIL'} ${name}${detail ? ` - ${detail}` : ''}`);
}

function run(command, args = []) {
  try {
    return execFileSync(command, args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
  } catch (error) {
    return error.stdout?.toString() || error.stderr?.toString() || '';
  }
}

async function fetchJson(pathname, init = {}) {
  try {
    const response = await fetch(`${baseUrl}${pathname}`, {
      ...init,
      headers: {
        Accept: 'application/json',
        ...(init.headers || {}),
      },
    });
    const text = await response.text();
    let body = null;
    try {
      body = text ? JSON.parse(text) : null;
    } catch {
      body = { raw: text.slice(0, 800) };
    }
    return { status: response.status, ok: response.ok, body };
  } catch (error) {
    return { status: 0, ok: false, body: { error: error instanceof Error ? error.message : String(error) } };
  }
}

async function main() {
  const preflightRaw = run(process.execPath, [path.join(process.cwd(), 'scripts', 'vivi_image_provider_preflight.mjs'), '--json']);
  let preflight = null;
  try {
    preflight = JSON.parse(preflightRaw);
  } catch {
    preflight = null;
  }
  add('preflight erzeugt Status-JSON', Boolean(preflight?.status), preflight?.status || 'missing');
  add('preflight schreibt Runtime-Report', preflight?.runtimeRoot ? fs.existsSync(path.join(preflight.runtimeRoot, '.runtime', 'vivi-skills', 'image-provider', 'LOCAL_IMAGE_PROVIDER_STATUS.md')) : false, preflight?.runtimeRoot || 'missing');
  add('keine Cloud-Pflicht fuer Bildschiene', true, 'lokale API 127.0.0.1:7860');
  add('Install-Script vorhanden', fs.existsSync(path.join(process.cwd(), 'scripts', 'install_vivi_image_provider_webui.sh')), 'install_vivi_image_provider_webui.sh');
  add('Start-Script vorhanden', fs.existsSync(path.join(process.cwd(), 'scripts', 'start_vivi_image_provider.sh')), 'start_vivi_image_provider.sh');
  add('Generate-CLI vorhanden', fs.existsSync(path.join(process.cwd(), 'scripts', 'generate_vivi_image_local.mjs')), 'generate_vivi_image_local.mjs');

  const skillRun = await fetchJson('/api/vivi-skills/run', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      skillId: 'image.generate.provider-check',
      source: 'verify_vivi_image_provider',
      requestedBy: 'system',
      operatorMessage: 'Verifier prueft lokale Bildprovider-Schiene.',
    }),
  });
  add(
    'Vivi Provider-Check Skill erreichbar',
    skillRun.status === 200 && ['completed', 'missing-provider', 'blocked'].includes(String(skillRun.body?.run?.status)),
    skillRun.body?.run?.status || `HTTP ${skillRun.status}`,
  );

  if (skillRun.body?.run?.status === 'completed') {
    const imageRun = await fetchJson('/api/vivi-skills/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        skillId: 'image.generate.local',
        source: 'verify_vivi_image_provider',
        requestedBy: 'system',
        operatorMessage: 'kleines blaues LIONCOM Hexagon auf hellem Hintergrund',
        payload: { width: 512, height: 512, steps: 8, cfgScale: 5 },
      }),
    });
    add('Vivi erzeugt lokales Testbild', imageRun.status === 200 && imageRun.body?.run?.status === 'completed', imageRun.body?.run?.status || `HTTP ${imageRun.status}`);
  } else {
    add('Vivi meldet fehlenden Provider ehrlich', skillRun.body?.run?.status === 'missing-provider', skillRun.body?.run?.status || 'missing');
  }

  const failed = checks.filter((check) => !check.ok);
  if (failed.length > 0) process.exit(1);
}

main().catch((error) => {
  console.error(error instanceof Error ? error.stack || error.message : String(error));
  process.exit(1);
});
