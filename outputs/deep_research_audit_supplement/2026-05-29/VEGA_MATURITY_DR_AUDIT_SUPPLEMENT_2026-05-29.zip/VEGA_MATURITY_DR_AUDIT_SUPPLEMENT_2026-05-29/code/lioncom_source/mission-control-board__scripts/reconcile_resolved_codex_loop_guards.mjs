#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const appRoot = path.resolve(scriptDir, '..');
const lioncomRoot = path.resolve(appRoot, '..');
const workspaceRoot = process.env.VIVI_WORKSPACE_ROOT
  || process.env.LIONCOM_WORKSPACE_ROOT
  || '/Users/BjornRosinger/Library/Application Support/LIONCOM/runtime-workspace';
const inboxPath = path.join(workspaceRoot, 'CODEX_INBOX.md');
const now = new Date().toISOString();
const verifyOnly = process.argv.includes('--verify');

const knownFixes = {
  missing_source_gate: {
    label: 'Source-Gate für interne LIONCOM-Reports',
    evidence: [
      { file: path.join(lioncomRoot, 'scripts/vivi_report_quality_gate.py'), includes: ['source_gate_inferred_internal', 'is_internal_lioncom_report'] },
      { file: path.join(lioncomRoot, 'mission-control-board/scripts/verify_vivi_report_quality_gate_contract.mjs'), includes: ['Source Gate: not_applicable'] },
    ],
    resolution: 'Interne LIONCOM-Runner-Reports ohne externe Quellen werden im Quality Gate als not_applicable behandelt; echte source-heavy Reports bleiben hart geprüft.',
  },
  idle_language_without_closure_evidence: {
    label: 'Idle-/Warteformulierungen mit deterministischer Korrektur',
    evidence: [
      { file: path.join(lioncomRoot, 'scripts/run_local_duo_loop.sh'), includes: ['append_vivi_idle_closure_correction_report', 'idle_closure_autocorrect', 'awaiting next instruction'] },
      { file: path.join(lioncomRoot, 'scripts/vivi_report_quality_gate.py'), includes: ['idle_language_without_closure_evidence', 'claim remains active', 'await new operator input'] },
      { file: path.join(lioncomRoot, 'mission-control-board/scripts/check_vivi_night_run_health.mjs'), includes: ['runner idle-closure autocorrect aktiv'] },
    ],
    resolution: 'Der Runner blockiert passives Await-/Claim-bleibt-aktiv-Wording und schreibt bei rein sprachlichem Idle-Closure-Fail einen deterministischen Korrektur-Report.',
  },
  generic_global_lane: {
    label: 'Konkrete LIONCOM-Lane-Metadaten',
    evidence: [
      { file: path.join(lioncomRoot, 'scripts/materialize_vivi_report_next_task.py'), includes: ['- Project Lane: lioncom-core', '- Resource Class: heavy-local-llm', '- Parallel Policy: global-heavy-singleton'] },
      { file: path.join(lioncomRoot, 'scripts/run_local_duo_loop.sh'), includes: ['Report-Metadaten-Lock', 'Project Lane', 'Resource Class', 'Parallel Policy'] },
      { file: path.join(lioncomRoot, 'mission-control-board/scripts/verify_control_plane_v2_local.mjs'), includes: ['control-plane-v2 dispatches tragen lane-metadaten'] },
    ],
    resolution: 'Materializer, Runner-Prompt und V2-Verifier erzwingen konkrete lioncom-core Lane-, Resource- und Parallel-Policy-Metadaten statt generischer global-Lane.',
  },
  stale_model_truth_after_route_probe: {
    label: 'Modellwahrheit nach frischem Route-Probe',
    evidence: [
      { file: path.join(lioncomRoot, 'scripts/run_local_duo_loop.sh'), includes: ['fresh vivi-model-route probe matches effective local provider/model', 'Model-Verifikation-Lock'] },
      { file: path.join(lioncomRoot, 'scripts/vivi_report_quality_gate.py'), includes: ['stale_model_truth_after_route_probe', 'model_route_probe_matches_runtime'] },
      { file: path.join(lioncomRoot, 'mission-control-board/scripts/check_vivi_night_run_health.mjs'), includes: ['runner modellwahrheit nutzt route-probe', 'vqg modellwahrheit hard-gate aktiv'] },
    ],
    resolution: 'Frische Vivi-Model-Route-Probes führen die Modellwahrheit; Reports dürfen diese nicht mehr auf requested/needs_vega_review zurückstufen.',
  },
  report_block_missing: {
    label: 'REPORT-Block-Recovery und Dedupe',
    evidence: [
      { file: path.join(lioncomRoot, 'scripts/run_local_duo_loop.sh'), includes: ['recover_current_report_from_log_if_needed', 'persist_last_message_report_if_needed', 'report-recovered-after-stall', 'skipped duplicate last-message REPORT'] },
      { file: path.join(lioncomRoot, 'mission-control-board/scripts/check_vivi_night_run_health.mjs'), includes: ['runner report-recovery rail aktiv', 'runner report-dedupe rail aktiv'] },
    ],
    resolution: 'Der Runner rekonstruiert den letzten sichtbaren REPORT aus Last-Message/Logs, persistiert ihn deterministisch in VIVI_REPORTS.md und dedupliziert identische Abschlussberichte.',
  },
  contradictory_raw_http_truth: {
    label: 'Raw-HTTP und Local-Route-Bridge getrennt bewertet',
    evidence: [
      { file: path.join(lioncomRoot, 'scripts/run_local_duo_loop.sh'), includes: ['Control-Plane-Truth-Lock', 'raw_http_probe: not_run; effective_transport: local_route_bridge ok', 'Quality-Gate-Notes-Lock'] },
      { file: path.join(lioncomRoot, 'scripts/vivi_report_quality_gate.py'), includes: ['contradictory_raw_http_truth', 'raw_http_not_leading', 'raw_marked_non_leading'] },
      { file: path.join(lioncomRoot, 'mission-control-board/scripts/verify_vivi_report_quality_gate_contract.mjs'), includes: ['Raw HTTP rot mit Bridge-Separation besteht', 'Raw HTTP rot ohne Bridge-Separation wird blockiert'] },
    ],
    resolution: 'Reports müssen Raw-HTTP-Probes und den effektiven local_route_bridge-Transport trennen; rote Raw-HTTP-Probes sind nur ok, wenn Bridge-ok/non-leading explizit belegt ist.',
  },
};

function readText(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch {
    return '';
  }
}

function evidencePasses(spec) {
  const failures = [];
  for (const requirement of spec.evidence) {
    const text = readText(requirement.file);
    for (const needle of requirement.includes) {
      if (!text.includes(needle)) {
        failures.push(`${path.relative(lioncomRoot, requirement.file)} fehlt "${needle}"`);
      }
    }
  }
  return {
    ok: failures.length === 0,
    failures,
  };
}

function parseRail(content) {
  const marker = content.search(/^###\s+/m);
  const header = marker >= 0 ? content.slice(0, marker) : content;
  const body = marker >= 0 ? content.slice(marker) : '';
  const blocks = body
    .split(/^###\s+/m)
    .map((section) => section.trim())
    .filter(Boolean)
    .map((section) => {
      const [headline, ...lines] = section.split('\n');
      const fields = {};
      for (const line of lines) {
        const match = line.trim().match(/^\-\s*([^:]+):\s*(.*)$/);
        if (match) fields[match[1].trim()] = match[2].trim();
      }
      return {
        id: headline.trim(),
        lines,
        fields,
        raw: section,
      };
    });
  return { header, blocks };
}

function serializeRail(header, blocks) {
  const normalizedHeader = header.endsWith('\n\n') ? header : header.endsWith('\n') ? `${header}\n` : `${header}\n\n`;
  return `${normalizedHeader}${blocks.map((block) => `### ${block.id}\n${block.lines.join('\n').trimEnd()}`).join('\n\n')}\n`;
}

function normalized(value) {
  return String(value || '').trim().toLowerCase();
}

function terminalStatus(value) {
  return ['closed', 'answered', 'reported', 'done'].includes(normalized(value));
}

function updateField(lines, field, value) {
  const prefix = `- ${field}:`;
  const next = [...lines];
  const index = next.findIndex((line) => line.trim().startsWith(prefix));
  if (index >= 0) {
    next[index] = `${prefix} ${value}`;
    return next;
  }
  const rawIndex = next.findIndex((line) => line.trim().startsWith('- Raw Request:'));
  const insertAt = rawIndex >= 0 ? rawIndex : next.length;
  next.splice(insertAt, 0, `${prefix} ${value}`);
  return next;
}

function signaturesForBlock(block) {
  const text = [block.fields.Title, block.fields.Summary, block.fields.Context, block.raw].join('\n');
  const match = text.match(/Signature:\s*([a-zA-Z0-9_|-]+)/);
  if (match) {
    return match[1].split('|').map((entry) => entry.trim()).filter(Boolean);
  }
  return Object.keys(knownFixes).filter((signature) => text.includes(signature));
}

function isResolvedLoopGuard(block) {
  if (terminalStatus(block.fields.Status)) return false;
  const title = block.fields.Title || block.id;
  if (!/^VQG Loop Guard:/i.test(title)) return false;
  const signatures = signaturesForBlock(block);
  if (signatures.length === 0) return false;
  if (!signatures.every((signature) => knownFixes[signature])) return false;
  return signatures.every((signature) => evidencePasses(knownFixes[signature]).ok);
}

function resolutionFor(signatures) {
  return signatures
    .map((signature) => `${knownFixes[signature].label}: ${knownFixes[signature].resolution}`)
    .join(' ');
}

function evidenceFor(signatures) {
  return signatures
    .flatMap((signature) => knownFixes[signature].evidence.map((entry) => path.relative(lioncomRoot, entry.file)))
    .filter((entry, index, all) => all.indexOf(entry) === index)
    .join(', ');
}

function reconcile() {
  if (!fs.existsSync(inboxPath)) {
    return { ok: true, workspaceRoot, verifyOnly, changed: 0, unresolvedKnownLoopGuards: [], closed: [] };
  }

  const content = fs.readFileSync(inboxPath, 'utf8');
  const parsed = parseRail(content);
  const closed = [];
  const unresolvedKnownLoopGuards = [];

  const blocks = parsed.blocks.map((block) => {
    if (terminalStatus(block.fields.Status) || !/^VQG Loop Guard:/i.test(block.fields.Title || block.id)) return block;

    const signatures = signaturesForBlock(block);
    const missingEvidence = signatures
      .filter((signature) => knownFixes[signature])
      .flatMap((signature) => evidencePasses(knownFixes[signature]).failures);

    if (!isResolvedLoopGuard(block)) {
      unresolvedKnownLoopGuards.push({
        id: block.id,
        status: block.fields.Status || 'unknown',
        title: block.fields.Title || block.id,
        signatures,
        reason: missingEvidence.length ? missingEvidence.join('; ') : 'unbekannte oder nicht belegte Signatur',
      });
      return block;
    }

    let lines = updateField(block.lines, 'Status', 'closed');
    lines = updateField(lines, 'Closed At', now);
    lines = updateField(lines, 'Resolution', resolutionFor(signatures));
    lines = updateField(lines, 'Evidence', evidenceFor(signatures));
    closed.push({ id: block.id, signatures });
    return { ...block, lines };
  });

  if (!verifyOnly && closed.length > 0) {
    fs.writeFileSync(inboxPath, serializeRail(parsed.header, blocks), 'utf8');
  }

  return {
    ok: unresolvedKnownLoopGuards.length === 0,
    workspaceRoot,
    verifyOnly,
    checkedAt: now,
    changed: verifyOnly ? 0 : closed.length,
    wouldClose: verifyOnly ? closed : [],
    closed: verifyOnly ? [] : closed,
    unresolvedKnownLoopGuards,
  };
}

const result = reconcile();
console.log(JSON.stringify(result, null, 2));
if (!result.ok) process.exit(1);
