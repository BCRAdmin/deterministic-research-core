import fs from 'fs/promises';
import os from 'os';
import path from 'path';

const supportDir = path.join(os.homedir(), 'Library', 'Application Support', 'LIONCOM');
const desktopStatusPath = path.join(supportDir, 'desktop-status.json');

function normalizePort(value) {
  const port = Number(value);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    return null;
  }
  return port;
}

async function main() {
  const explicitUrl = process.env.LIONCOM_BASE_URL?.trim() || process.env.MEMBERSHIP_BASE_URL?.trim();
  if (explicitUrl) {
    console.log(explicitUrl);
    return;
  }

  try {
    const status = JSON.parse(await fs.readFile(desktopStatusPath, 'utf8'));
    const port = normalizePort(status?.serverPort);
    if (port) {
      console.log(`http://127.0.0.1:${port}`);
      return;
    }
  } catch {}

  console.log('http://127.0.0.1:4107');
}

await main();
