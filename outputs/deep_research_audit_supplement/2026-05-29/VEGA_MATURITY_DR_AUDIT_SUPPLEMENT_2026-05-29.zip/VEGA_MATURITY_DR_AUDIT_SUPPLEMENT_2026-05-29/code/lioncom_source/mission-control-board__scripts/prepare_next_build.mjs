#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const appRoot = path.resolve(scriptDir, '..');
const nextDir = path.join(appRoot, '.next');

const criticalPackages = [
  'next',
  'react',
  'react-dom',
  'scheduler',
];

function exists(filePath) {
  try {
    fs.accessSync(filePath, fs.constants.R_OK);
    return true;
  } catch {
    return false;
  }
}

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function sleepSync(ms) {
  const durationMs = Number(ms);
  if (!Number.isFinite(durationMs) || durationMs <= 0) return;

  const buffer = new SharedArrayBuffer(4);
  const view = new Int32Array(buffer);
  Atomics.wait(view, 0, 0, durationMs);
}

function isRetryableRmError(error) {
  if (!error || typeof error !== 'object') return false;
  const code = 'code' in error ? error.code : undefined;
  return code === 'ENOTEMPTY' || code === 'EBUSY' || code === 'EPERM';
}

function rmSyncWithRetries(targetPath, options) {
  const retryDelaysMs = [15, 35, 75, 150, 300];
  let lastError = null;

  for (let attempt = 0; attempt <= retryDelaysMs.length; attempt += 1) {
    try {
      fs.rmSync(targetPath, options);
      return;
    } catch (error) {
      lastError = error;
      if (!isRetryableRmError(error) || attempt >= retryDelaysMs.length) break;
      sleepSync(retryDelaysMs[attempt]);
    }
  }

  const details = lastError instanceof Error ? lastError.message : String(lastError);
  throw new Error(
    [
      'Next-Build-Preflight fehlgeschlagen: `.next` konnte nicht bereinigt werden.',
      `Ziel: ${targetPath}`,
      `Fehler: ${details}`,
      '',
      'Hinweis: Das kann passieren, wenn ein laufender Next/Node-Prozess Dateien sperrt oder das Dateisystem transient busy ist.',
      'Fix: laufende Prozesse beenden (z.B. `npm run dev` / `npm run start:standalone`), dann erneut `npm run build` ausfuehren.',
    ].join('\n'),
  );
}

function packageMainFile(packageName) {
  const packageDir = path.join(appRoot, 'node_modules', packageName);
  const packageJsonPath = path.join(packageDir, 'package.json');

  if (!exists(packageJsonPath)) {
    throw new Error(`Dependency fehlt: ${packageJsonPath}`);
  }

  const packageJson = readJson(packageJsonPath);
  const main = typeof packageJson.main === 'string' && packageJson.main.trim()
    ? packageJson.main
    : 'index.js';
  return path.join(packageDir, main);
}

function cleanStandaloneOutput() {
  const standaloneDir = path.join(nextDir, 'standalone');
  const traceFile = path.join(nextDir, 'trace');

  rmSyncWithRetries(standaloneDir, { recursive: true, force: true });
  rmSyncWithRetries(traceFile, { force: true });
  fs.mkdirSync(nextDir, { recursive: true });
}

function verifyCriticalDependencies() {
  const missing = [];

  for (const packageName of criticalPackages) {
    try {
      const mainFile = packageMainFile(packageName);
      if (!exists(mainFile)) missing.push(mainFile);
    } catch (error) {
      missing.push(error instanceof Error ? error.message : String(error));
    }
  }

  const schedulerIndex = path.join(appRoot, 'node_modules', 'scheduler', 'index.js');
  if (!exists(schedulerIndex)) missing.push(schedulerIndex);

  if (missing.length > 0) {
    throw new Error([
      'Next-Build-Preflight fehlgeschlagen. Kritische Standalone-Dependencies fehlen:',
      ...missing.map((item) => `- ${item}`),
      '',
      'Fix: im mission-control-board erneut `npm install` ausfuehren und Build wiederholen.',
    ].join('\n'));
  }
}

function writePreflightMarker() {
  const marker = {
    generatedAt: new Date().toISOString(),
    cleaned: [
      '.next/standalone',
      '.next/trace',
    ],
    verifiedPackages: criticalPackages,
  };
  fs.writeFileSync(path.join(nextDir, 'build-preflight.json'), JSON.stringify(marker, null, 2), 'utf8');
}

try {
  cleanStandaloneOutput();
  verifyCriticalDependencies();
  writePreflightMarker();
  console.log('[next-build-preflight] standalone output cleaned; critical dependencies verified.');
} catch (error) {
  console.error(error instanceof Error ? error.message : String(error));
  process.exitCode = 1;
}
