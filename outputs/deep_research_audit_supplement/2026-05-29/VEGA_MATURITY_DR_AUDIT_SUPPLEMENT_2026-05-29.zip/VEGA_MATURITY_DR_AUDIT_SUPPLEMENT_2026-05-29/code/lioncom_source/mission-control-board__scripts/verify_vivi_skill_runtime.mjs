#!/usr/bin/env node

const baseUrl = (process.env.LIONCOM_BASE_URL || 'http://127.0.0.1:4107').replace(/\/$/, '');
const requiredSkills = [
  'lioncom.status.read',
  'vivi.model.route',
  'image.generate.provider-check',
  'image.generate.local',
  'repo.inspect.readonly',
  'browser.qa.inspect',
  'media.youtube.transcript',
  'vivi.dispatch.create',
  'vega.handoff.create',
  'vivi.memory.capture',
  'vivi.skill.propose',
  'vivi.skill-hub.local',
  'vivi.skill-hub.remote-dry-run',
];

const checks = [];

function add(name, ok, detail = '') {
  checks.push({ name, ok, detail });
  const marker = ok ? 'PASS' : 'FAIL';
  console.log(`${marker} ${name}${detail ? ` - ${detail}` : ''}`);
}

async function fetchJson(pathname, init = {}) {
  try {
    const response = await fetch(`${baseUrl}${pathname}`, {
      ...init,
      headers: {
        Accept: 'application/json',
        ...(init.headers || {}),
      },
    });
    const text = await response.text();
    let body = null;
    try {
      body = text ? JSON.parse(text) : null;
    } catch {
      body = { raw: text.slice(0, 500) };
    }
    return { status: response.status, ok: response.ok, body };
  } catch (error) {
    return { status: 0, ok: false, body: { error: error instanceof Error ? error.message : String(error) } };
  }
}

async function main() {
  const snapshot = await fetchJson('/api/vivi-skills');
  add('vivi skill api erreichbar', snapshot.status === 200, `HTTP ${snapshot.status}`);
  const skills = Array.isArray(snapshot.body?.skills) ? snapshot.body.skills : [];
  add('skill snapshot enthaelt katalog', skills.length >= requiredSkills.length, `${skills.length} skills`);
  add('skill snapshot zaehlt aktive skills', Number(snapshot.body?.counts?.enabled) > 0, `enabled=${snapshot.body?.counts?.enabled ?? 'missing'}`);

  for (const skillId of requiredSkills) {
    add(`skill manifest vorhanden: ${skillId}`, skills.some((skill) => skill.id === skillId), skillId);
  }

  const detail = await fetchJson('/api/vivi-skills/image.generate.local');
  add('skill detail endpoint liefert manifest', detail.status === 200 && detail.body?.id === 'image.generate.local', `HTTP ${detail.status}`);

  const mediaDetail = await fetchJson('/api/vivi-skills/media.youtube.transcript');
  add('youtube media skill detail endpoint liefert manifest', mediaDetail.status === 200 && mediaDetail.body?.id === 'media.youtube.transcript', `HTTP ${mediaDetail.status}`);

  const statusRun = await fetchJson('/api/vivi-skills/run', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      skillId: 'lioncom.status.read',
      source: 'verify_vivi_skill_runtime',
      requestedBy: 'system',
      operatorMessage: 'Verifier liest lokalen LIONCOM Status.',
    }),
  });
  add('status skill run erfolgreich', statusRun.status === 200 && statusRun.body?.run?.skillId === 'lioncom.status.read' && statusRun.body?.run?.status !== 'failed', statusRun.body?.run?.status || `HTTP ${statusRun.status}`);
  add('status skill run schreibt run id', typeof statusRun.body?.run?.id === 'string' && statusRun.body.run.id.startsWith('VSKILLRUN-'), statusRun.body?.run?.id || 'missing');

  const imageRun = await fetchJson('/api/vivi-skills/run', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      skillId: 'image.generate.provider-check',
      source: 'verify_vivi_skill_runtime',
      requestedBy: 'system',
      operatorMessage: 'Verifier prüft Bildprovider ohne externen Send.',
    }),
  });
  add(
    'image provider skill liefert ehrlichen status',
    imageRun.status === 200 && ['completed', 'missing-provider', 'blocked'].includes(String(imageRun.body?.run?.status)),
    imageRun.body?.run?.status || `HTTP ${imageRun.status}`,
  );

  const localImageRun = await fetchJson('/api/vivi-skills/run', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      skillId: 'image.generate.local',
      source: 'verify_vivi_skill_runtime',
      requestedBy: 'system',
      operatorMessage: 'erstelle ein kleines cyanfarbenes LIONCOM Hexagon als Verifier-Bild',
    }),
  });
  add(
    'local image skill erzeugt artefakt oder meldet provider',
    localImageRun.status === 200 && ['completed', 'missing-provider', 'blocked', 'failed'].includes(String(localImageRun.body?.run?.status)),
    localImageRun.body?.run?.status || `HTTP ${localImageRun.status}`,
  );

  const hubRun = await fetchJson('/api/vivi-skills/run', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      skillId: 'vivi.skill-hub.local',
      source: 'verify_vivi_skill_runtime',
      requestedBy: 'system',
      operatorMessage: 'Verifier liest lokalen Skill-Hub.',
    }),
  });
  add('skill hub run erfolgreich', hubRun.status === 200 && hubRun.body?.run?.skillId === 'vivi.skill-hub.local' && hubRun.body?.run?.status !== 'failed', hubRun.body?.run?.status || `HTTP ${hubRun.status}`);

  const mediaRun = await fetchJson('/api/vivi-skills/run', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      skillId: 'media.youtube.transcript',
      source: 'verify_vivi_skill_runtime',
      requestedBy: 'system',
      operatorMessage: 'Verifier prüft YouTube-Media-Ingest ohne konkrete URL.',
    }),
  });
  add(
    'youtube media skill liefert ehrlichen url-bedarf',
    mediaRun.status === 200 && mediaRun.body?.run?.skillId === 'media.youtube.transcript' && mediaRun.body?.run?.status === 'proposal',
    mediaRun.body?.run?.status || `HTTP ${mediaRun.status}`,
  );

  const proposal = await fetchJson('/api/vivi-skills/propose', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      capability: 'presentation.create',
      operatorMessage: 'Verifier prueft Missing-Skill-Proposal fuer Praesentation.',
    }),
  });
  add('skill proposal api funktioniert', proposal.status === 200 && proposal.body?.proposal?.requestedCapability === 'presentation.create', proposal.body?.proposal?.id || `HTTP ${proposal.status}`);

  const hub = await fetchJson('/api/vivi-skills/hub');
  add('skill hub api funktioniert', hub.status === 200 && Array.isArray(hub.body?.hub?.entries), `HTTP ${hub.status}`);

  const browserSkill = skills.find((skill) => skill.id === 'browser.qa.inspect');
  const disable = await fetchJson('/api/vivi-skills/disable', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ skillId: 'browser.qa.inspect' }),
  });
  add('skill disable endpoint funktioniert', disable.status === 200 && disable.body?.snapshot?.skills?.some((skill) => skill.id === 'browser.qa.inspect' && skill.enabled === false), `HTTP ${disable.status}`);
  const restore = await fetchJson(browserSkill?.enabled === false ? '/api/vivi-skills/disable' : '/api/vivi-skills/enable', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ skillId: 'browser.qa.inspect' }),
  });
  add('skill toggle stellt ursprungszustand her', restore.status === 200, `HTTP ${restore.status}`);

  const createSession = await fetchJson('/api/vivi-chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action: 'create-session',
      title: 'Verifier Vivi Skill Runtime',
      topic: 'Kurzlebige Prüfung für Capability Router und Skill-Lauf',
      providerMode: 'local',
      providerPreset: 'lmstudio',
      requestedModel: 'qwen3.5-vivi:9b',
    }),
  });
  const sessionId = createSession.body?.snapshot?.sessions?.find?.((session) => session?.title === 'Verifier Vivi Skill Runtime')?.id;
  add('vivi verifier session angelegt', createSession.status === 200 && typeof sessionId === 'string', sessionId || `HTTP ${createSession.status}`);

  if (sessionId) {
    const sendImage = await fetchJson('/api/vivi-chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'send-message',
        sessionId,
        message: 'erstelle mir ein bild von einem cyanfarbenen LIONCOM hexagon',
        source: 'verify_vivi_skill_runtime',
        autoStart: false,
      }),
    });
    add(
      'vivi chat routet bildwunsch auf skill',
      sendImage.status === 200 && sendImage.body?.skillRun?.skillId === 'image.generate.local',
      sendImage.body?.skillRun?.skillId || `HTTP ${sendImage.status}`,
    );

    const sendPresentation = await fetchJson('/api/vivi-chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'send-message',
        sessionId,
        message: 'erstelle mir eine Präsentation über den LIONCOM Skill Hub',
        source: 'verify_vivi_skill_runtime',
        autoStart: false,
      }),
    });
    add(
      'vivi chat routet fehlenden skill auf proposal',
      sendPresentation.status === 200 && sendPresentation.body?.skillRun?.skillId === 'vivi.skill.propose',
      sendPresentation.body?.skillRun?.skillId || `HTTP ${sendPresentation.status}`,
    );

    const archive = await fetchJson('/api/vivi-chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'archive-session',
        sessionId,
        reason: 'Kurzlebige Skill-Runtime-Verifier-Session nach erfolgreicher Prüfung archiviert.',
      }),
    });
    add('vivi verifier session archiviert', archive.status === 200, `HTTP ${archive.status}`);
  }

  const failed = checks.filter((check) => !check.ok);
  console.log(JSON.stringify({
    ok: failed.length === 0,
    checkedAt: new Date().toISOString(),
    baseUrl,
    checks: checks.length,
    failures: failed,
  }, null, 2));
  if (failed.length > 0) process.exit(1);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
