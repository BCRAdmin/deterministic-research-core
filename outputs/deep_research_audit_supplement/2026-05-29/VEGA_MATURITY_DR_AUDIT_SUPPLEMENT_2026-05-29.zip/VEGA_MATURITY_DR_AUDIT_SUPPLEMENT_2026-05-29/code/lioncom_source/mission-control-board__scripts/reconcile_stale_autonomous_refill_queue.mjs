#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';

const workspaceRoot = process.env.VIVI_WORKSPACE_ROOT
  || process.env.LIONCOM_WORKSPACE_ROOT
  || '/Users/BjornRosinger/Library/Application Support/LIONCOM/runtime-workspace';
const verifyOnly = process.argv.includes('--verify');
const now = new Date().toISOString();
const maxOpenAgeMs = Number(process.env.LIONCOM_STALE_REFILL_QUEUE_HOURS || 24) * 60 * 60 * 1000;
const queuePath = path.join(workspaceRoot, 'VIVI_COMMAND_QUEUE.md');
const claimsPath = path.join(workspaceRoot, 'TASK_CLAIMS.md');
const openStatuses = new Set(['accepted', 'analyzing', 'claimed', 'executing', 'new', 'pending', 'queued', 'recovering', 'verifying', 'working']);

function readText(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch {
    return '';
  }
}

function parseRail(content) {
  const marker = content.search(/^###\s+/m);
  const header = marker >= 0 ? content.slice(0, marker) : content;
  const body = marker >= 0 ? content.slice(marker) : '';
  const blocks = body
    .split(/^###\s+/m)
    .map((section) => section.trim())
    .filter(Boolean)
    .map((section) => {
      const [headline, ...lines] = section.split('\n');
      const fields = {};
      for (const line of lines) {
        const match = line.trim().match(/^\-\s*([^:]+):\s*(.*)$/);
        if (match) fields[match[1].trim()] = match[2].trim();
      }
      return { id: headline.trim(), lines, fields, raw: section };
    });
  return { header, blocks };
}

function serializeRail(header, blocks) {
  const normalizedHeader = header.endsWith('\n\n') ? header : header.endsWith('\n') ? `${header}\n` : `${header}\n\n`;
  return `${normalizedHeader}${blocks.map((block) => `### ${block.id}\n${block.lines.join('\n').trimEnd()}`).join('\n\n')}\n`;
}

function normalized(value) {
  return String(value || '').trim().replace(/\s+/g, ' ').toLowerCase();
}

function addedTime(block) {
  const parsed = Date.parse(block.fields.Added || '');
  return Number.isFinite(parsed) ? parsed : 0;
}

function updateField(lines, field, value) {
  const prefix = `- ${field}:`;
  const next = [...lines];
  const index = next.findIndex((line) => line.trim().startsWith(prefix));
  if (index >= 0) {
    next[index] = `${prefix} ${value}`;
    return next;
  }
  const rawIndex = next.findIndex((line) => line.trim().startsWith('- Raw Request:'));
  const insertAt = rawIndex >= 0 ? rawIndex : next.length;
  next.splice(insertAt, 0, `${prefix} ${value}`);
  return next;
}

function fieldsFromLines(lines) {
  const fields = {};
  for (const line of lines) {
    const match = line.trim().match(/^\-\s*([^:]+):\s*(.*)$/);
    if (match) fields[match[1].trim()] = match[2].trim();
  }
  return fields;
}

function parseActiveTaskIds(content) {
  const ids = new Set();
  for (const block of parseRail(content).blocks) {
    const state = normalized(block.fields.State);
    const stale = normalized(block.fields.Stale);
    if ((state === 'working' || state === 'claimed') && stale !== 'yes') {
      const taskId = block.fields['Task ID'];
      if (taskId) ids.add(taskId);
    }
  }
  return ids;
}

function staleAutonomousRefill(block, activeTaskIds) {
  if (normalized(block.fields.Source) !== 'autonomous refill engine') return false;
  if (!openStatuses.has(normalized(block.fields.Status))) return false;
  if (activeTaskIds.has(block.id)) return false;

  const added = addedTime(block);
  if (!added) return false;
  return Date.now() - added > maxOpenAgeMs;
}

function reconcile() {
  if (!fs.existsSync(queuePath)) {
    return { ok: true, workspaceRoot, verifyOnly, checkedAt: now, changed: 0, parked: [], unresolved: [], path: queuePath };
  }

  const parsed = parseRail(readText(queuePath));
  const activeTaskIds = parseActiveTaskIds(readText(claimsPath));
  const parked = [];
  const blocks = parsed.blocks.map((block) => {
    if (!staleAutonomousRefill(block, activeTaskIds)) return block;

    let lines = updateField(block.lines, 'Status', 'parked');
    lines = updateField(lines, 'Parked At', now);
    lines = updateField(
      lines,
      'Resolution',
      'Alter autonomer Refill-Block ohne aktive Claim wurde geparkt, damit der aktuelle Nachtlauf nicht durch historische executing/recovering-Spuren verunreinigt wird.',
    );
    lines = updateField(
      lines,
      'Evidence',
      'TASK_CLAIMS.md enthaelt keine aktive Claim fuer diesen Task; aktuelle Autonomie-Route arbeitet ueber frische Claims und Release-/Night-Health-Gates.',
    );
    parked.push({
      id: block.id,
      title: block.fields.Title || block.id,
      previousStatus: block.fields.Status || 'unknown',
      added: block.fields.Added || 'unknown',
    });
    if (verifyOnly) return block;
    return { ...block, lines, fields: fieldsFromLines(lines) };
  });

  if (!verifyOnly && parked.length > 0) {
    fs.writeFileSync(queuePath, serializeRail(parsed.header, blocks), 'utf8');
  }

  const unresolved = blocks
    .filter((block) => staleAutonomousRefill(block, activeTaskIds))
    .map((block) => ({
      id: block.id,
      title: block.fields.Title || block.id,
      status: block.fields.Status || 'unknown',
      added: block.fields.Added || 'unknown',
    }));

  return {
    ok: unresolved.length === 0,
    workspaceRoot,
    verifyOnly,
    checkedAt: now,
    staleAfterHours: maxOpenAgeMs / 60 / 60 / 1000,
    changed: verifyOnly ? 0 : parked.length,
    parked: verifyOnly ? [] : parked,
    wouldPark: verifyOnly ? parked : [],
    unresolved,
  };
}

const result = reconcile();
console.log(JSON.stringify(result, null, 2));
if (!result.ok) process.exit(1);
