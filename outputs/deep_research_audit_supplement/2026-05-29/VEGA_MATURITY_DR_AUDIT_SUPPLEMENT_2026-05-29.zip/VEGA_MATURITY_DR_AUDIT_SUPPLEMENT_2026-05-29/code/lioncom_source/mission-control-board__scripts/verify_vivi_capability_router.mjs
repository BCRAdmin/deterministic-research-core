#!/usr/bin/env node

const baseUrl = (process.env.LIONCOM_BASE_URL || 'http://127.0.0.1:4107').replace(/\/$/, '');
const checks = [];

function add(name, ok, detail = '') {
  checks.push({ name, ok, detail });
  console.log(`${ok ? 'PASS' : 'FAIL'} ${name}${detail ? ` - ${detail}` : ''}`);
}

async function fetchJson(pathname, init = {}) {
  try {
    const response = await fetch(`${baseUrl}${pathname}`, {
      ...init,
      headers: { Accept: 'application/json', ...(init.headers || {}) },
    });
    const text = await response.text();
    let body = null;
    try {
      body = text ? JSON.parse(text) : null;
    } catch {
      body = { raw: text.slice(0, 500) };
    }
    return { status: response.status, ok: response.ok, body };
  } catch (error) {
    return { status: 0, ok: false, body: { error: error instanceof Error ? error.message : String(error) } };
  }
}

async function send(sessionId, message) {
  return fetchJson('/api/vivi-chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action: 'send-message',
      sessionId,
      message,
      source: 'verify_vivi_capability_router',
      autoStart: false,
    }),
  });
}

async function main() {
  const createSession = await fetchJson('/api/vivi-chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action: 'create-session',
      title: 'Verifier Vivi Capability Router',
      topic: 'Kurzlebige Prüfung für direkte Chats, Skills, Missing-Skills und Gates',
      providerMode: 'local',
      providerPreset: 'lmstudio',
      requestedModel: 'qwen3.5-vivi:9b',
    }),
  });
  const sessionId = createSession.body?.snapshot?.sessions?.find?.((session) => session?.title === 'Verifier Vivi Capability Router')?.id;
  add('router verifier session angelegt', createSession.status === 200 && typeof sessionId === 'string', sessionId || `HTTP ${createSession.status}`);

  if (!sessionId) {
    finish();
    return;
  }

  const image = await send(sessionId, 'erstelle mir ein bild von einem cyanfarbenen LIONCOM Hexagon');
  add('bildwunsch routet auf lokale bildgenerierung', image.status === 200 && image.body?.skillRun?.skillId === 'image.generate.local', image.body?.skillRun?.skillId || `HTTP ${image.status}`);
  add('bildwunsch liefert ehrlichen status', ['completed', 'missing-provider', 'blocked', 'failed'].includes(String(image.body?.skillRun?.status)), image.body?.skillRun?.status || 'missing');

  const youtube = await send(sessionId, 'fasse ein YouTube-Video zusammen, ich reiche die URL gleich nach');
  add('youtube-wunsch routet auf media ingest', youtube.status === 200 && youtube.body?.skillRun?.skillId === 'media.youtube.transcript', youtube.body?.skillRun?.skillId || `HTTP ${youtube.status}`);
  add('youtube-wunsch ohne url bleibt ehrlicher proposal-status', youtube.body?.skillRun?.status === 'proposal', youtube.body?.skillRun?.status || 'missing');

  const code = await send(sessionId, 'fixe den Bug im Repository und prüfe die Tests');
  add('codewunsch routet auf vega handoff', code.status === 200 && code.body?.skillRun?.skillId === 'vega.handoff.create', code.body?.skillRun?.skillId || `HTTP ${code.status}`);

  const missing = await send(sessionId, 'erstelle mir eine Präsentation über LIONCOM V2 als Deck');
  add('fehlende faehigkeit wird proposal', missing.status === 200 && missing.body?.skillRun?.skillId === 'vivi.skill.propose', missing.body?.skillRun?.skillId || `HTTP ${missing.status}`);
  add('proposal meldet presentation capability', String(missing.body?.skillRun?.detail || '').includes('presentation.create'), missing.body?.skillRun?.detail?.slice?.(0, 180) || 'missing detail');

  const gated = await send(sessionId, 'deploye das sofort live in production');
  const gatedMessages = gated.body?.snapshot?.messages || [];
  const hasGateReply = Array.isArray(gatedMessages)
    && gatedMessages.some((message) => message.sessionId === sessionId && String(message.summary || '').includes('Operator-Gate'));
  add('geschuetzte aktion erzeugt operator gate', gated.status === 200 && hasGateReply && !gated.body?.skillRun, `HTTP ${gated.status}`);

  const direct = await send(sessionId, 'test');
  const directMessages = direct.body?.snapshot?.messages || [];
  const hasOperatorTest = Array.isArray(directMessages)
    && directMessages.some((message) => message.sessionId === sessionId && message.role === 'operator' && String(message.message || '').trim() === 'test');
  add('kurze chatnachricht bleibt chat und kein auftrag', direct.status === 200 && hasOperatorTest && !direct.body?.skillRun, `HTTP ${direct.status}`);

  const archive = await fetchJson('/api/vivi-chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action: 'archive-session',
      sessionId,
      reason: 'Kurzlebige Capability-Router-Verifier-Session archiviert.',
    }),
  });
  add('router verifier session archiviert', archive.status === 200, `HTTP ${archive.status}`);

  const parallelSuffix = Date.now();
  const titleA = `Verifier Vivi Parallel A ${parallelSuffix}`;
  const titleB = `Verifier Vivi Parallel B ${parallelSuffix}`;
  const [parallelA, parallelB] = await Promise.all([
    fetchJson('/api/vivi-chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'create-session',
        title: titleA,
        topic: 'Parallel-Mutationsprüfung A',
        providerMode: 'local',
        providerPreset: 'lmstudio',
        requestedModel: 'qwen3.5-vivi:9b',
      }),
    }),
    fetchJson('/api/vivi-chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'create-session',
        title: titleB,
        topic: 'Parallel-Mutationsprüfung B',
        providerMode: 'local',
        providerPreset: 'lmstudio',
        requestedModel: 'qwen3.5-vivi:9b',
      }),
    }),
  ]);
  const idA = findSessionId([parallelA, parallelB], titleA);
  const idB = findSessionId([parallelA, parallelB], titleB);
  add('parallel verifier sessions angelegt', parallelA.status === 200 && parallelB.status === 200 && Boolean(idA && idB), `${idA || 'missing'} / ${idB || 'missing'}`);

  if (idA && idB) {
    const [gateA, gateB] = await Promise.all([
      send(idA, 'deploye das sofort live in production'),
      send(idB, 'deploye das sofort live in production'),
    ]);
    add('parallel session A bleibt erreichbar', gateA.status === 200, `HTTP ${gateA.status}`);
    add('parallel session B bleibt erreichbar', gateB.status === 200, `HTTP ${gateB.status}`);

    const [archiveA, archiveB] = await Promise.all([
      fetchJson('/api/vivi-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'archive-session',
          sessionId: idA,
          reason: 'Kurzlebige Parallel-Verifier-Session A archiviert.',
        }),
      }),
      fetchJson('/api/vivi-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'archive-session',
          sessionId: idB,
          reason: 'Kurzlebige Parallel-Verifier-Session B archiviert.',
        }),
      }),
    ]);
    add('parallel verifier sessions archiviert', archiveA.status === 200 && archiveB.status === 200, `A ${archiveA.status} / B ${archiveB.status}`);
  }

  finish();
}

function findSessionId(responses, title) {
  for (const response of responses) {
    const session = response.body?.snapshot?.sessions?.find?.((entry) => entry?.title === title);
    if (typeof session?.id === 'string') return session.id;
  }
  return '';
}

function finish() {
  const failed = checks.filter((check) => !check.ok);
  console.log(JSON.stringify({ ok: failed.length === 0, checkedAt: new Date().toISOString(), baseUrl, checks: checks.length, failures: failed }, null, 2));
  if (failed.length > 0) process.exit(1);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
