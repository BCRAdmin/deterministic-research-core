import fs from 'fs/promises';
import path from 'path';
import { spawnSync } from 'child_process';

const args = new Set(process.argv.slice(2));
const dryRun = args.has('--dry-run');
const atArg = process.argv.slice(2).find((arg) => arg.startsWith('--at='));
const simulatedNow = atArg ? new Date(atArg.slice('--at='.length)) : null;

function resolveDefaultRuntimeRoot() {
  if (process.env.LIONCOM_RUNTIME_ROOT?.trim()) return process.env.LIONCOM_RUNTIME_ROOT.trim();
  if (process.env.HOME?.trim()) return path.join(process.env.HOME.trim(), 'Library/Application Support/LIONCOM/runtime-workspace');
  return '/Users/BjornRosinger/Library/Application Support/LIONCOM/runtime-workspace';
}

function resolveFallbackRuntimeRoot() {
  return path.join(process.cwd(), '.runtime', 'runtime-workspace');
}

let runtimeRoot = resolveDefaultRuntimeRoot();
let runtimeStatePath = path.join(runtimeRoot, '.recovery', 'operator-go-state.json');
let runtimeLogPath = path.join(runtimeRoot, '.recovery', 'operator-go-publish-log.jsonl');
let runtimeHealthPath = path.join(runtimeRoot, '.recovery', 'operator-go-health.json');
let runtimeLockPath = path.join(runtimeRoot, '.recovery', 'operator-go-run.lock');

function setRuntimeRoot(nextRoot) {
  runtimeRoot = nextRoot;
  runtimeStatePath = path.join(runtimeRoot, '.recovery', 'operator-go-state.json');
  runtimeLogPath = path.join(runtimeRoot, '.recovery', 'operator-go-publish-log.jsonl');
  runtimeHealthPath = path.join(runtimeRoot, '.recovery', 'operator-go-health.json');
  runtimeLockPath = path.join(runtimeRoot, '.recovery', 'operator-go-run.lock');
}

const operatorGoProjects = [
  {
    id: 'materialbedarf',
    manifestPath: '/Users/BjornRosinger/Dreamfactory/utility webseite/materialbedarf-rechner.de/ops/OPERATOR_GO_MANIFEST.json',
    releaseStatePath: '/Users/BjornRosinger/Dreamfactory/utility webseite/materialbedarf-rechner.de/app/src/data/content-release-state.json',
    deployScriptPath: '/Users/BjornRosinger/Dreamfactory/utility webseite/materialbedarf-rechner.de/ops/deploy-cloudflare-pages.sh',
    executionLogPath: '/Users/BjornRosinger/Dreamfactory/utility webseite/materialbedarf-rechner.de/ops/EXECUTION_LOG.md',
    publishMode: 'release-state',
    deployEnv: { DEPLOY_MODE: 'live' },
  },
  {
    id: 'elterngeld',
    manifestPath: '/Users/BjornRosinger/Dreamfactory/utility webseite/mein-elterngeldrechner.de/docs/OPERATOR_GO_MANIFEST.json',
    deployScriptPath: '/Users/BjornRosinger/Dreamfactory/utility webseite/mein-elterngeldrechner.de/ops/deploy-cloudflare-pages.sh',
    executionLogPath: '/Users/BjornRosinger/Dreamfactory/utility webseite/mein-elterngeldrechner.de/ops/EXECUTION_LOG.md',
    publishMode: 'full-static-export',
    deployEnv: {
      DEPLOY_MODE: 'live',
      DEPLOY_BRANCH: process.env.CLOUDFLARE_ELTERNGELD_DEPLOY_BRANCH || process.env.CLOUDFLARE_PRODUCTION_BRANCH || 'main',
      CLOUDFLARE_PAGES_PROJECT: process.env.CLOUDFLARE_ELTERNGELD_PAGES_PROJECT || 'kindergeld',
    },
  },
];

function normalizeRoutePath(route) {
  const [pathname] = String(route || '').split(/[?#]/, 1);
  if (!pathname) return '/';
  const withLeadingSlash = pathname.startsWith('/') ? pathname : `/${pathname}`;
  return withLeadingSlash.endsWith('/') ? withLeadingSlash : `${withLeadingSlash}/`;
}

function isoNow() {
  return (simulatedNow && !Number.isNaN(simulatedNow.getTime()) ? simulatedNow : new Date()).toISOString();
}

function dueCutoffMs() {
  return simulatedNow && !Number.isNaN(simulatedNow.getTime()) ? simulatedNow.getTime() : Date.now();
}

async function ensureJsonFile(filePath, fallback) {
  try {
    const raw = await fs.readFile(filePath, 'utf8');
    return JSON.parse(raw);
  } catch {
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    await fs.writeFile(filePath, JSON.stringify(fallback, null, 2), 'utf8');
    return fallback;
  }
}

async function appendRuntimeLog(entry) {
  await fs.mkdir(path.dirname(runtimeLogPath), { recursive: true });
  await fs.appendFile(runtimeLogPath, `${JSON.stringify(entry)}\n`, 'utf8');
}

async function writeHealth(entry) {
  await fs.mkdir(path.dirname(runtimeHealthPath), { recursive: true });
  await fs.writeFile(runtimeHealthPath, JSON.stringify(entry, null, 2), 'utf8');
}

function getNextScheduledItem(state, manifestItems, nowIso) {
  const nowMs = Date.parse(nowIso);
  return Object.entries(state.items || {})
    .filter(([, itemState]) => itemState.reviewState === 'approved' && itemState.scheduledFor && !itemState.publishedAt)
    .map(([itemId, itemState]) => ({
      id: itemId,
      title: manifestItems.get(itemId)?.title || itemId,
      scheduledFor: itemState.scheduledFor,
    }))
    .filter((item) => Date.parse(item.scheduledFor) > nowMs)
    .sort((left, right) => left.scheduledFor.localeCompare(right.scheduledFor))[0] || null;
}

async function acquireLock() {
  try {
    await fs.mkdir(path.dirname(runtimeLockPath), { recursive: true });
    const handle = await fs.open(runtimeLockPath, 'wx');
    await handle.writeFile(JSON.stringify({ pid: process.pid, createdAt: new Date().toISOString() }, null, 2), 'utf8');
    return handle;
  } catch (error) {
    if (error && typeof error === 'object' && 'code' in error && error.code === 'EPERM') {
      const fallbackRoot = resolveFallbackRuntimeRoot();
      if (runtimeRoot !== fallbackRoot) {
        setRuntimeRoot(fallbackRoot);
        await fs.mkdir(path.dirname(runtimeLockPath), { recursive: true });
        const handle = await fs.open(runtimeLockPath, 'wx');
        await handle.writeFile(JSON.stringify({ pid: process.pid, createdAt: new Date().toISOString() }, null, 2), 'utf8');
        return handle;
      }
    }
    if (error && typeof error === 'object' && 'code' in error && error.code === 'EEXIST') {
      return null;
    }
    throw error;
  }
}

async function releaseLock(handle) {
  if (!handle) return;
  try {
    await handle.close();
  } catch {}
  try {
    await fs.unlink(runtimeLockPath);
  } catch {}
}

async function appendProjectExecutionLog(project, dueItems, deployedRoutes, now, mode) {
  if (!project.executionLogPath) return;

  const heading = `- ${now.slice(0, 16).replace('T', ' ')} Operator-Go-Pipeline ${mode}: ${dueItems.map((item) => `\`${item.title}\``).join(', ')}`;
  const detail = deployedRoutes.length
    ? `  - Veröffentlicht/geöffnet: ${deployedRoutes.map((route) => `\`${route}\``).join(', ')}\n`
    : '  - Kein einzelner Content-Pfad, voller statischer Website-Deploy im geplanten Batch.\n';

  await fs.mkdir(path.dirname(project.executionLogPath), { recursive: true });
  await fs.appendFile(project.executionLogPath, `\n${heading}\n${detail}`, 'utf8');
}

async function loadManifestItems(project) {
  const manifest = await ensureJsonFile(project.manifestPath, { items: [] });
  const items = Array.isArray(manifest.items) ? manifest.items : [];
  return new Map(
    items.map((item) => [
      item.id,
      {
        ...item,
        projectId: item.projectId || manifest.project?.id || project.id,
      },
    ]),
  );
}

async function loadAllManifestItems(projects) {
  const manifestItems = new Map();

  for (const project of projects) {
    const projectItems = await loadManifestItems(project);
    for (const [itemId, item] of projectItems) {
      manifestItems.set(itemId, item);
    }
  }

  return manifestItems;
}

function getDueItems(state, manifestItems) {
  const cutoffMs = dueCutoffMs();

  return Object.entries(state.items || {})
    .filter(([, itemState]) => itemState.reviewState === 'approved' && itemState.scheduledFor && !itemState.publishedAt)
    .filter(([, itemState]) => Date.parse(itemState.scheduledFor) <= cutoffMs)
    .map(([itemId, itemState]) => ({
      ...(manifestItems.get(itemId) || { id: itemId, title: itemId, projectId: 'unknown' }),
      _state: itemState,
    }));
}

function groupByProject(items) {
  const groups = new Map();

  for (const item of items) {
    const current = groups.get(item.projectId) || [];
    current.push(item);
    groups.set(item.projectId, current);
  }

  return groups;
}

function runCommand(command, commandArgs, options = {}) {
  const result = spawnSync(command, commandArgs, {
    cwd: options.cwd,
    env: { ...process.env, ...options.env },
    encoding: 'utf8',
    maxBuffer: 1024 * 1024 * 20,
  });

  if (result.status !== 0) {
    const stderr = result.stderr?.trim();
    const stdout = result.stdout?.trim();
    throw new Error(stderr || stdout || `${command} failed with code ${result.status}`);
  }

  return {
    stdout: result.stdout?.trim() || '',
    stderr: result.stderr?.trim() || '',
  };
}

async function publishMaterialbedarf(project, dueItems, now) {
  const releaseState = await ensureJsonFile(project.releaseStatePath, {
    managedRoutes: [],
    publishedRoutes: [],
  });
  const previousState = JSON.stringify(releaseState, null, 2);
  const dueRoutes = Array.from(new Set(
    dueItems
      .map((item) => item.expectedLivePath)
      .filter(Boolean)
      .map((route) => normalizeRoutePath(route)),
  ));

  const publishedRoutes = new Set((releaseState.publishedRoutes || []).map(normalizeRoutePath));
  for (const route of dueRoutes) {
    publishedRoutes.add(route);
  }

  const nextState = {
    managedRoutes: Array.from(new Set((releaseState.managedRoutes || []).map(normalizeRoutePath))).sort(),
    publishedRoutes: Array.from(publishedRoutes).sort(),
  };

  if (dryRun) {
    return {
      success: true,
      dueRoutes,
      mode: 'dry-run',
      deploySummary: 'Dry run only; no deploy executed.',
      releaseStateChanged: nextState,
    };
  }

  await fs.writeFile(project.releaseStatePath, JSON.stringify(nextState, null, 2), 'utf8');

  try {
    const deployResult = runCommand('bash', [project.deployScriptPath], {
      cwd: path.dirname(project.deployScriptPath),
      env: project.deployEnv,
    });

    await appendProjectExecutionLog(project, dueItems, dueRoutes, now, 'live');

    return {
      success: true,
      dueRoutes,
      mode: 'live',
      deploySummary: deployResult.stdout.split('\n').slice(-6).join('\n').trim(),
    };
  } catch (error) {
    await fs.writeFile(project.releaseStatePath, previousState, 'utf8');
    throw error;
  }
}

async function publishFullStaticProject(project, dueItems, now) {
  const dueRoutes = Array.from(new Set(
    dueItems
      .map((item) => item.expectedLivePath)
      .filter(Boolean)
      .map((route) => normalizeRoutePath(route)),
  ));

  if (dryRun) {
    return {
      success: true,
      dueRoutes,
      mode: 'dry-run',
      deploySummary: 'Dry run only; no build or deploy executed.',
    };
  }

  const deployResult = runCommand('bash', [project.deployScriptPath], {
    cwd: path.dirname(project.deployScriptPath),
    env: project.deployEnv,
  });

  await appendProjectExecutionLog(project, dueItems, dueRoutes, now, 'live');

  return {
    success: true,
    dueRoutes,
    mode: 'live',
    deploySummary: deployResult.stdout.split('\n').slice(-8).join('\n').trim(),
  };
}

async function publishProject(project, dueItems, now) {
  if (project.publishMode === 'release-state') {
    return publishMaterialbedarf(project, dueItems, now);
  }

  if (project.publishMode === 'full-static-export') {
    return publishFullStaticProject(project, dueItems, now);
  }

  throw new Error(`No Operator-Go publisher configured for project '${project.id}'.`);
}

function markItemsPublished(state, items, now) {
  for (const item of items) {
    state.items[item.id] = {
      ...state.items[item.id],
      publishedAt: dryRun ? state.items[item.id].publishedAt : now,
      lastPipelineError: undefined,
      lastPipelineRunAt: now,
      updatedAt: now,
    };
  }
}

function markItemsFailed(state, items, now, error) {
  const message = error instanceof Error ? error.message : String(error);

  for (const item of items) {
    state.items[item.id] = {
      ...state.items[item.id],
      lastPipelineError: message,
      lastPipelineRunAt: now,
      updatedAt: now,
    };
  }
}

async function main() {
  const now = isoNow();
  const lockHandle = await acquireLock();

  if (!lockHandle) {
    const result = { ok: true, mode: dryRun ? 'dry-run' : 'live', processed: 0, message: 'Another operator-go run is already active.' };
    if (!dryRun) {
      await appendRuntimeLog({ timestamp: now, ...result });
      await writeHealth({
        ok: true,
        checkedAt: now,
        summary: 'Ein anderer Operator-Go-Lauf ist bereits aktiv.',
        nextDueItemId: null,
        nextDueAt: null,
        authOk: true,
        authMessage: 'Lock-Datei aktiv; Doppellauf wurde verhindert.',
      });
    }
    console.log(JSON.stringify(result, null, 2));
    return;
  }

  try {
    const state = await ensureJsonFile(runtimeStatePath, { items: {} });
    const manifestItems = await loadAllManifestItems(operatorGoProjects);
    const dueItems = getDueItems(state, manifestItems);

    if (!dueItems.length) {
      const result = { ok: true, mode: dryRun ? 'dry-run' : 'live', processed: 0, message: 'No due approved items.' };
      const nextScheduled = getNextScheduledItem(state, manifestItems, now);
      if (!dryRun) {
        await appendRuntimeLog({ timestamp: now, ...result });
        await writeHealth({
          ok: true,
          checkedAt: now,
          summary: nextScheduled
            ? `Kein fälliger Slot. Nächster Batch: ${nextScheduled.title} um ${nextScheduled.scheduledFor}.`
            : 'Kein fälliger Operator-Go-Slot.',
          nextDueItemId: nextScheduled?.id || null,
          nextDueAt: nextScheduled?.scheduledFor || null,
          authOk: true,
          authMessage: 'Kein fälliger Slot, daher kein Deploy ausgeführt.',
        });
      }
      console.log(JSON.stringify(result, null, 2));
      return;
    }

    const processedItems = [];
    const publishResults = [];
    const groups = groupByProject(dueItems);

    try {
      for (const [projectId, projectItems] of groups) {
        const project = operatorGoProjects.find((candidate) => candidate.id === projectId);
        if (!project) throw new Error(`No Operator-Go project configured for '${projectId}'.`);

        const publishResult = await publishProject(project, projectItems, now);
        publishResults.push({ projectId, ...publishResult });
        processedItems.push(...projectItems);
      }

      markItemsPublished(state, processedItems, now);

      if (!dryRun) {
        await fs.writeFile(runtimeStatePath, JSON.stringify(state, null, 2), 'utf8');
      }

      const result = {
        ok: true,
        mode: dryRun ? 'dry-run' : 'live',
        processed: processedItems.length,
        itemIds: processedItems.map((item) => item.id),
        dueRoutes: publishResults.flatMap((resultItem) => resultItem.dueRoutes),
        projects: publishResults,
      };
      const nextScheduled = getNextScheduledItem(state, manifestItems, now);
      if (!dryRun) {
        await appendRuntimeLog({ timestamp: now, ...result });
        await writeHealth({
          ok: true,
          checkedAt: now,
          summary: `Mittagslauf erfolgreich: ${processedItems.map((item) => item.title).join(', ')}`,
          nextDueItemId: nextScheduled?.id || null,
          nextDueAt: nextScheduled?.scheduledFor || null,
          authOk: true,
          authMessage: publishResults.map((resultItem) => `${resultItem.projectId}: ${resultItem.deploySummary}`).join('\n\n'),
        });
      }
      console.log(JSON.stringify(result, null, 2));
    } catch (error) {
      const processedIds = new Set(processedItems.map((item) => item.id));
      const failedItems = dueItems.filter((item) => !processedIds.has(item.id));

      markItemsPublished(state, processedItems, now);
      markItemsFailed(state, failedItems, now, error);

      if (!dryRun) {
        await fs.writeFile(runtimeStatePath, JSON.stringify(state, null, 2), 'utf8');
      }

      const result = {
        ok: false,
        mode: dryRun ? 'dry-run' : 'live',
        processed: processedItems.length,
        failed: failedItems.length,
        itemIds: dueItems.map((item) => item.id),
        error: error instanceof Error ? error.message : String(error),
      };
      if (!dryRun) {
        await appendRuntimeLog({ timestamp: now, ...result });
        await writeHealth({
          ok: false,
          checkedAt: now,
          summary: `Mittagslauf fehlgeschlagen: ${error instanceof Error ? error.message : String(error)}`,
          nextDueItemId: failedItems[0]?.id || null,
          nextDueAt: failedItems[0]?._state?.scheduledFor || null,
          authOk: false,
          authMessage: error instanceof Error ? error.message : String(error),
        });
      }
      console.error(JSON.stringify(result, null, 2));
      process.exitCode = 1;
    }
  } finally {
    await releaseLock(lockHandle);
  }
}

await main();
