#!/usr/bin/env node

const { execFileSync } = require('child_process');
const path = require('path');
const { loadCatalogModule } = require('./verify_quellwert_public_catalog_contract.cjs');

function resolveBaseUrl() {
  if (process.env.MEMBERSHIP_BASE_URL) return process.env.MEMBERSHIP_BASE_URL;
  if (process.env.LIONCOM_BASE_URL) return process.env.LIONCOM_BASE_URL;

  try {
    return execFileSync(process.execPath, [path.join(__dirname, 'resolve_desktop_server_url.mjs')], {
      encoding: 'utf8',
    }).trim();
  } catch {
    return 'http://127.0.0.1:4107';
  }
}

function add(results, check, pass, detail) {
  results.push({ check, pass, detail });
}

async function getText(url) {
  const response = await fetch(url, { signal: AbortSignal.timeout(8000) });
  return {
    status: response.status,
    contentType: response.headers.get('content-type') || '',
    text: await response.text(),
  };
}

function extractTitle(html) {
  return html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]?.trim() || '';
}

function extractHtmlLang(html) {
  return html.match(/<html[^>]+lang=["']([^"']+)["'][^>]*>/i)?.[1]?.trim() || '';
}

function extractViewport(html) {
  return (
    html.match(/<meta[^>]+name=["']viewport["'][^>]+content=["']([^"']+)["'][^>]*>/i)?.[1]?.trim() ||
    html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+name=["']viewport["'][^>]*>/i)?.[1]?.trim() ||
    ''
  );
}

function extractDescription(html) {
  return (
    html.match(/<meta[^>]+name=["']description["'][^>]+content=["']([^"']+)["'][^>]*>/i)?.[1]?.trim() ||
    html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+name=["']description["'][^>]*>/i)?.[1]?.trim() ||
    ''
  );
}

async function main() {
  const baseUrl = resolveBaseUrl().replace(/\/+$/, '');
  const catalog = loadCatalogModule();
  const publicAnalyses = catalog.getPublicAnalyses();
  const hiddenAnalyses = catalog.getInternalReviewAnalyses();
  const results = [];

  try {
    await getText(`${baseUrl}/membership`);
  } catch (error) {
    const code = error?.cause?.code || error?.code;
    if (code === 'EPERM') {
      const report = {
        baseUrl,
        verdict: 'skip',
        checkedAt: new Date().toISOString(),
        results: [
          {
            check: 'softlaunch readiness verifier skips when localhost is blocked by sandbox',
            pass: true,
            detail: `connect blocked (${code}); requires a running local server`,
          },
        ],
      };

      console.log(JSON.stringify(report, null, 2));
      return;
    }

    throw error;
  }

  const publicRoutes = [
    {
      path: '/membership',
      title: 'Quellwert',
      descriptionToken: [REDACTED]
      requiredText: ['Unternehmen lesen. Klarer denken.', 'Öffentliche Research-Notizen'],
    },
    {
      path: '/membership/analysen',
      title: 'Analysen | Quellwert',
      descriptionToken: [REDACTED]
      requiredText: ['Research-Agent-Piloten', 'Operator-Go erforderlich'],
    },
    {
      path: '/membership/methodik',
      title: 'Methodik | Quellwert',
      descriptionToken: [REDACTED]
      requiredText: ['Non-Advice-Grenze', 'Operator-Go erforderlich'],
    },
    {
      path: '/membership/archiv',
      title: 'Archiv | Quellwert',
      descriptionToken: [REDACTED]
      requiredText: ['Gate-Status', 'Nicht extern freigegeben'],
    },
    {
      path: '/membership/impressum',
      title: 'Impressum | Quellwert',
      descriptionToken: [REDACTED]
      requiredText: ['nicht als rechtlich finale Angabe'],
    },
    {
      path: '/membership/datenschutz',
      title: 'Datenschutz | Quellwert',
      descriptionToken: [REDACTED]
      requiredText: ['keine Konten', 'Operator-Gate'],
    },
    {
      path: '/membership/kontakt',
      title: 'Kontakt | Quellwert',
      descriptionToken: [REDACTED]
      requiredText: ['ohne externe Kommunikation'],
    },
    ...publicAnalyses.map((analysis) => ({
      path: `/membership/analysen/${analysis.slug}`,
      title: `${analysis.shortName} | Quellwert`,
      descriptionToken: [REDACTED]
      requiredText: ['keine Anlageberatung', analysis.displayStatus],
    })),
  ];

  for (const route of publicRoutes) {
    const url = `${baseUrl}${route.path}`;
    const { status, contentType, text } = await getText(url);
    const title = extractTitle(text);
    const htmlLang = extractHtmlLang(text);
    const viewport = extractViewport(text);
    const description = extractDescription(text);

    add(results, `${route.path} status 200`, status === 200, `status=${status}`);
    add(results, `${route.path} html content type`, contentType.includes('text/html'), contentType);
    add(results, `${route.path} html lang is de`, htmlLang.toLowerCase().startsWith('de'), htmlLang);
    add(
      results,
      `${route.path} viewport meta present`,
      viewport.length > 0 && viewport.includes('width=device-width'),
      viewport
    );
    add(results, `${route.path} title is Quellwert-specific`, title.includes(route.title) && !title.includes('LIONCOM // Vivi OS'), title);
    add(results, `${route.path} meta description present`, description.length >= 60 && description.includes(route.descriptionToken), description);

    for (const token of route.requiredText) {
      add(results, `${route.path} required launch text: ${token}`, text.includes(token), token);
    }
  }

  for (const analysis of hiddenAnalyses) {
    const pathName = `/membership/analysen/${analysis.slug}`;
    const { status } = await getText(`${baseUrl}${pathName}`);
    add(results, `${pathName} remains hidden`, status === 404, `status=${status}`);
  }

  const robots = await getText(`${baseUrl}/robots.txt`);
  add(results, '/robots.txt status 200', robots.status === 200, `status=${robots.status}`);
  add(results, '/robots.txt text content', robots.contentType.includes('text/plain'), robots.contentType);
  if (process.env.QUELLWERT_PUBLIC_INDEXING === 'true') {
    add(results, '/robots.txt public indexing explicitly enabled', robots.text.includes('Allow: /membership'), robots.text);
    add(results, '/robots.txt blocks private app surfaces', robots.text.includes('Disallow: /api/') && robots.text.includes('Disallow: /control-plane-v2'), robots.text);
  } else {
    add(results, '/robots.txt blocks indexing until operator enables it', robots.text.includes('Disallow: /'), robots.text);
  }

  const sitemap = await getText(`${baseUrl}/sitemap.xml`);
  add(results, '/sitemap.xml status 200', sitemap.status === 200, `status=${sitemap.status}`);
  add(results, '/sitemap.xml xml content', sitemap.contentType.includes('xml'), sitemap.contentType);
  for (const route of publicRoutes) {
    add(results, `/sitemap.xml includes ${route.path}`, sitemap.text.includes(`${baseUrl}${route.path}`), route.path);
  }
  for (const analysis of hiddenAnalyses) {
    add(results, `/sitemap.xml excludes hidden ${analysis.slug}`, !sitemap.text.includes(analysis.slug), analysis.slug);
  }
  add(results, '/sitemap.xml excludes private app surfaces', !sitemap.text.includes('/api/') && !sitemap.text.includes('/control-plane-v2'), 'private surfaces');

  const failed = results.filter((result) => !result.pass);
  const report = {
    baseUrl,
    verdict: failed.length === 0 ? 'pass' : 'fail',
    checkedAt: new Date().toISOString(),
    results,
  };

  console.log(JSON.stringify(report, null, 2));
  if (failed.length) process.exit(1);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
