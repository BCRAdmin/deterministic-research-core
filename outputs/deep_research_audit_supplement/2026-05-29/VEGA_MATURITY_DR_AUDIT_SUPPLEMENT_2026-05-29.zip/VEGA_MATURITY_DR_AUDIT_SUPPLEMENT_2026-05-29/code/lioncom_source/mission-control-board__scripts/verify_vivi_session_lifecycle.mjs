#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';

const baseUrl = (process.env.LIONCOM_BASE_URL || 'http://127.0.0.1:4107').replace(/\/$/, '');
const workspaceRoot = process.env.LIONCOM_WORKSPACE_ROOT
  || process.env.VIVI_WORKSPACE_ROOT
  || path.join(process.env.HOME || '/Users/BjornRosinger', 'Library/Application Support/LIONCOM/runtime-workspace');

const checks = [];
const created = new Set();
const cleanupTokens = new Set(['Vivi Session Health Verifier', 'V2 Session Health']);

function record(status, name, detail = '') {
  checks.push({ status, name, detail });
}

function pass(name, detail = '') {
  record('pass', name, detail);
}

function fail(name, detail = '') {
  record('fail', name, detail);
}

async function fetchJson(pathname, init = {}) {
  try {
    const response = await fetch(`${baseUrl}${pathname}`, {
      ...init,
      headers: {
        'Content-Type': 'application/json',
        ...(init.headers || {}),
      },
      cache: 'no-store',
      signal: AbortSignal.timeout(120_000),
    });
    const text = await response.text();
    let body = null;
    try {
      body = text ? JSON.parse(text) : null;
    } catch {
      body = { raw: text.slice(0, 500) };
    }
    return { ok: response.ok, status: response.status, body };
  } catch (error) {
    return { ok: false, status: 0, body: null, error: error instanceof Error ? error.message : String(error) };
  }
}

async function post(pathname, payload) {
  return fetchJson(pathname, {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function waitForViviChatApi() {
  let latest = { ok: false, status: 0, body: null, error: 'not checked' };
  for (let attempt = 0; attempt < 24; attempt += 1) {
    latest = await fetchJson('/api/vivi-chat');
    if (latest.status === 200 && Array.isArray(latest.body?.sessions) && Array.isArray(latest.body?.messages)) {
      return latest;
    }
    await sleep(attempt < 6 ? 500 : 1000);
  }
  return latest;
}

function requireCheck(condition, name, detail = '') {
  if (condition) {
    pass(name, detail);
  } else {
    fail(name, detail);
  }
}

function sessions(snapshot) {
  return Array.isArray(snapshot?.sessions) ? snapshot.sessions : [];
}

function messages(snapshot) {
  return Array.isArray(snapshot?.messages) ? snapshot.messages : [];
}

function findSession(snapshot, sessionId) {
  return sessions(snapshot).find((session) => session?.id === sessionId);
}

function findSessionByTitle(snapshot, title) {
  return sessions(snapshot).find((session) => session?.title === title);
}

function latestMessageFor(snapshot, sessionId, role) {
  return [...messages(snapshot)].reverse().find((message) => message?.sessionId === sessionId && message?.role === role);
}

function readText(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch {
    return '';
  }
}

function archiveContains(sessionId) {
  const archivePath = path.join(workspaceRoot, 'VIVI_CHAT_SESSIONS_ARCHIVE.json');
  try {
    const archive = JSON.parse(fs.readFileSync(archivePath, 'utf8'));
    return Array.isArray(archive) && archive.some((entry) => entry?.session?.id === sessionId || entry?.id === sessionId);
  } catch {
    return false;
  }
}

function removeVerifierBlocks(filePath) {
  const text = readText(filePath);
  if (!text) return;

  const firstBlockIndex = text.search(/^###\s+/m);
  if (firstBlockIndex < 0) return;

  const header = text.slice(0, firstBlockIndex);
  const body = text.slice(firstBlockIndex);
  const blocks = body.split(/(?=^###\s+)/m);
  const filtered = blocks.filter((block) => {
    for (const token of cleanupTokens) {
      if (token && block.includes(token)) return false;
    }
    return true;
  });

  if (filtered.length !== blocks.length) {
    fs.writeFileSync(filePath, `${header}${filtered.join('')}`.replace(/\n*$/, '\n\n'), 'utf8');
  }
}

async function cleanup() {
  for (const sessionId of Array.from(created)) {
    const snapshot = await fetchJson('/api/vivi-chat');
    if (!findSession(snapshot.body, sessionId)) {
      created.delete(sessionId);
      continue;
    }
    await post('/api/vivi-chat/archive', {
      sessionId,
      reason: 'Vivi Session Health Cleanup',
    });
    created.delete(sessionId);
  }
  removeVerifierBlocks(path.join(workspaceRoot, 'VIVI_COMMAND_QUEUE.md'));
  removeVerifierBlocks(path.join(workspaceRoot, 'WORK_INTAKE.md'));
  removeVerifierBlocks(path.join(workspaceRoot, 'VIVI_CHAT_THREAD.md'));
}

async function main() {
  const before = await waitForViviChatApi();
  requireCheck(before.status === 200, 'vivi-chat api erreichbar', `HTTP ${before.status}`);
  requireCheck(Array.isArray(before.body?.sessions), 'session-liste lesbar', `${sessions(before.body).length} Sessions`);
  requireCheck(Array.isArray(before.body?.messages), 'message-liste lesbar', `${messages(before.body).length} Messages`);

  const titleA = `Verifier Session A ${Date.now()}`;
  const createA = await post('/api/vivi-chat', {
    action: 'create-session',
    title: titleA,
    topic: 'V2 Session Health: Wechsel, Chat und Archiv pruefen.',
    providerMode: 'local',
    providerPreset: 'lmstudio',
    requestedModel: 'qwen3.5-vivi:9b',
  });
  const sessionA = findSessionByTitle(createA.body?.snapshot, titleA)?.id;
  if (sessionA) {
    created.add(sessionA);
    cleanupTokens.add(sessionA);
  }
  requireCheck(createA.status === 200 && Boolean(sessionA), 'session A erstellen', sessionA || `HTTP ${createA.status}`);
  requireCheck(findSession(createA.body?.snapshot, sessionA)?.providerPreset === 'lmstudio', 'session A provider gesetzt', findSession(createA.body?.snapshot, sessionA)?.providerPreset || 'missing');
  requireCheck(latestMessageFor(createA.body?.snapshot, sessionA, 'system')?.message?.includes('Vivi Auto-Start-Kontext'), 'session A boot-kontext automatisch geschrieben', sessionA || 'missing');

  const titleB = `Verifier Session B ${Date.now()}`;
  const createB = await post('/api/vivi-chat', {
    action: 'create-session',
    title: titleB,
    topic: 'V2 Session Health: Start und Entfernen leerer Session pruefen.',
    providerMode: 'local',
    providerPreset: 'lmstudio',
    requestedModel: 'qwen3.5-vivi:9b',
  });
  const sessionB = findSessionByTitle(createB.body?.snapshot, titleB)?.id;
  if (sessionB) {
    created.add(sessionB);
    cleanupTokens.add(sessionB);
  }
  requireCheck(createB.status === 200 && Boolean(sessionB), 'session B erstellen', sessionB || `HTTP ${createB.status}`);
  requireCheck(createB.body?.snapshot?.activeSessionId === sessionB, 'aktive session springt auf neueste Session', createB.body?.snapshot?.activeSessionId || 'missing');

  const switchToA = await post('/api/vivi-chat', {
    action: 'update-session',
    sessionId: sessionA,
    title: titleA,
    topic: 'V2 Session Health: gewechselte aktive Session.',
    providerMode: 'local',
    providerPreset: 'lmstudio',
    requestedModel: 'qwen3.5-vivi:9b',
    applyToRuntime: true,
  });
  requireCheck(switchToA.status === 200, 'session wechseln/update ausfuehrbar', `HTTP ${switchToA.status}`);
  requireCheck(switchToA.body?.snapshot?.activeSessionId === sessionA, 'sessionwechsel macht Zielsession aktiv', switchToA.body?.snapshot?.activeSessionId || 'missing');

  const operatorMessage = 'Bitte pruefe kurz, ob dieser Testchat als operatorfreundlicher Vivi-Chat im richtigen Workspace landet. Keine externen Sends.';
  const send = await post('/api/vivi-chat', {
    action: 'send-message',
    sessionId: sessionA,
    message: operatorMessage,
    autoStart: true,
    source: 'Vivi Session Health Verifier',
  });
  requireCheck(send.status === 200, 'operator-nachricht senden', `HTTP ${send.status}`);
  const afterSendSession = findSession(send.body?.snapshot, sessionA);
  if (afterSendSession?.lastReference) cleanupTokens.add(afterSendSession.lastReference);
  requireCheck(afterSendSession?.status === 'waiting' || afterSendSession?.status === 'reported', 'operator-nachricht setzt session auf chat-status', afterSendSession?.status || 'missing');
  requireCheck(Boolean(afterSendSession?.lastReference), 'operator-nachricht erzeugt command-ref', afterSendSession?.lastReference || 'missing');
  requireCheck(latestMessageFor(send.body?.snapshot, sessionA, 'operator')?.message?.includes('Testchat'), 'operator-nachricht im chat sichtbar', sessionA || 'missing');
  requireCheck(
    Boolean(latestMessageFor(send.body?.snapshot, sessionA, 'vivi')?.message),
    'operator-nachricht erzeugt sichtbare vivi-antwort',
    latestMessageFor(send.body?.snapshot, sessionA, 'vivi')?.summary || 'missing',
  );

  const commandQueue = readText(path.join(workspaceRoot, 'VIVI_COMMAND_QUEUE.md'));
  const workIntake = readText(path.join(workspaceRoot, 'WORK_INTAKE.md'));
  requireCheck(commandQueue.includes(afterSendSession?.lastReference || ''), 'chat command-ref in vivi queue', afterSendSession?.lastReference || 'missing');
  requireCheck(workIntake.includes(afterSendSession?.lastReference || ''), 'chat command-ref in work intake', afterSendSession?.lastReference || 'missing');
  requireCheck(commandQueue.includes('Auto Boot Context'), 'chat queue enthaelt auto-boot-kontext', 'Auto Boot Context');
  requireCheck(commandQueue.includes('- Project Lane: lioncom-core'), 'chat queue enthaelt project lane', 'lioncom-core');
  requireCheck(workIntake.includes('- Project Lane: lioncom-core'), 'chat intake enthaelt project lane', 'lioncom-core');

  const removeNonEmpty = await post('/api/vivi-chat/remove', {
    sessionId: sessionA,
    confirmEmpty: true,
    reason: 'Verifier erwartet 409, weil Operator-Inhalt vorhanden ist.',
  });
  requireCheck(removeNonEmpty.status === 409, 'nicht-leere session wird nicht hart entfernt', `HTTP ${removeNonEmpty.status}`);

  const startB = await post('/api/vivi-chat', {
    action: 'start-local-vivi',
    sessionId: sessionB,
  });
  requireCheck(startB.status === 200 && startB.body?.ok === true, 'lokaler vivi-start aus session funktioniert', startB.body?.start?.detail || `HTTP ${startB.status}`);
  requireCheck(
    latestMessageFor(startB.body?.snapshot, sessionB, 'vivi')?.message?.includes('Vivi-Start ist angekommen'),
    'lokaler vivi-start ist im chat sichtbar',
    latestMessageFor(startB.body?.snapshot, sessionB, 'vivi')?.summary || 'missing',
  );

  const removeStartedB = await post('/api/vivi-chat/remove', {
    sessionId: sessionB,
    confirmEmpty: true,
    reason: 'Verifier erwartet 409, weil Start-Bestaetigung Vivi-Inhalt ist.',
  });
  requireCheck(removeStartedB.status === 409, 'gestartete session wird nicht hart entfernt', `HTTP ${removeStartedB.status}`);

  const archiveB = await post('/api/vivi-chat/archive', {
    sessionId: sessionB,
    reason: 'Vivi Session Health archivierte Start-Testsession.',
  });
  requireCheck(archiveB.status === 200, 'gestartete session archivieren', `HTTP ${archiveB.status}`);
  requireCheck(!findSession(archiveB.body?.snapshot, sessionB), 'archivierte start-session nicht mehr aktiv', sessionB || 'missing');
  requireCheck(archiveContains(sessionB), 'archivierte start-session im archiv protokolliert', sessionB || 'missing');
  created.delete(sessionB);

  const archiveA = await post('/api/vivi-chat/archive', {
    sessionId: sessionA,
    reason: 'Vivi Session Health archivierte nicht-leere Testsession.',
  });
  requireCheck(archiveA.status === 200, 'nicht-leere session archivieren', `HTTP ${archiveA.status}`);
  requireCheck(!findSession(archiveA.body?.snapshot, sessionA), 'archivierte session nicht mehr aktiv', sessionA || 'missing');
  requireCheck(archiveContains(sessionA), 'archivierte session im archiv protokolliert', sessionA || 'missing');
  created.delete(sessionA);
}

try {
  await main();
} finally {
  await cleanup();
}

const failures = checks.filter((check) => check.status === 'fail');
console.log(JSON.stringify({
  ok: failures.length === 0,
  checkedAt: new Date().toISOString(),
  baseUrl,
  workspaceRoot,
  checks,
  failures,
}, null, 2));

if (failures.length > 0) process.exit(1);
