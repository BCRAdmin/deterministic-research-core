#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const appRoot = path.resolve(scriptDir, '..');
const lioncomRoot = path.resolve(appRoot, '..');

const checks = [];
const failures = [];

function readText(relativePath) {
  return fs.readFileSync(path.join(appRoot, relativePath), 'utf8');
}

function readLioncomText(relativePath) {
  return fs.readFileSync(path.join(lioncomRoot, relativePath), 'utf8');
}

function add(name, ok, detail = '') {
  checks.push({ name, status: ok ? 'pass' : 'fail', detail });
  if (!ok) failures.push({ name, detail });
}

function includesAll(label, text, required) {
  const missing = required.filter((item) => !text.includes(item));
  add(label, missing.length === 0, missing.length ? `missing=${missing.join(', ')}` : `${required.length} Pflichtanker`);
}

function excludesAll(label, text, forbidden) {
  const found = forbidden.filter((item) => text.includes(item));
  add(label, found.length === 0, found.length ? `found=${found.join(', ')}` : `${forbidden.length} alte Primärlabels blockiert`);
}

function excludesPatterns(label, text, forbidden) {
  const found = forbidden.filter(({ pattern }) => pattern.test(text)).map(({ label: itemLabel }) => itemLabel);
  add(label, found.length === 0, found.length ? `found=${found.join(', ')}` : `${forbidden.length} alte sichtbare Primärlabels blockiert`);
}

const plan = readLioncomText('DASHBOARD_FINISH_PLAN.md');
const overview = readText('components/overview-page.tsx');
const visualVerifier = readText('scripts/verify_control_plane_v2_visual.mjs');
const alertTable = readText('components/alert-table.tsx');
const telemetryPage = readText('components/telemetry-page.tsx');
const liveData = readText('lib/control-plane-v2/live-data.ts');
const types = readText('lib/types.ts');
const mockData = readText('lib/mock-data.ts');

includesAll('dashboard zielbild: plananker vorhanden', plan, [
  '13,3-Zoll-MacBook-Pro-Display',
  '1920x1080-Display',
  'Live-Signale, lokale Fallback-Signale und echte Remote-Wahrheit',
  'P0-A Live-Wahrheit glasklar machen',
  'P1-A Metric Menus',
  'P3-B Abnahme',
]);

includesAll('overview: wahrheitsquellen sichtbar getrennt', overview, [
  'OperationsControlDeck',
  'Operations-Deck',
  'Ein-Screen-Lage',
  'signal',
  'baseline',
  'loop',
  'audit',
  'Direkte Vivi-Runtime',
  'Lokaler Duo-Loop',
  'Remote-Bridge',
  'Lokale Wahrheit',
  'Lokaler Fallback',
  'Remote wartet',
  'Aktivierung braucht Operator-Go',
]);

includesAll('visual verifier: dashboard truth anchors', visualVerifier, [
  'DIREKTE VIVI-RUNTIME',
  'LOKALER DUO-LOOP',
  'REMOTE-BRIDGE',
  'LOKALE WAHRHEIT|LOKALER FALLBACK',
  'ALARMWEGE',
  'NÄCHSTER SICHERER SCHRITT',
  'KENNZAHLEN-WEGE',
]);

includesAll('alert paths: operator action contract sichtbar', alertTable, [
  'Alarmwege',
  'Analysepfad',
  'Reparaturpfad',
  'Nacht-Fix',
  'Operator-Gate',
  'Nächster sicherer Schritt',
]);

includesAll('alert paths: typed data contract vorhanden', types, [
  'AlertActionPath',
  'actionPath?: AlertActionPath',
  'recommendation?: string',
  'nextStep?: string',
  'group?: string',
]);

includesAll('alert paths: live data derives safe next step', liveData, [
  'deriveAlertActionPath',
  'GitHub / Auth / Sync',
  'Auth-, Token- oder Remote-Schritte erst nach Operator-Go',
  'Bridge / Remote',
  'Reparaturpfad',
  'Nacht-Fix',
  'Analysepfad',
]);

includesAll('alert paths: fallback data carries contract', mockData, [
  'actionPath',
  'recommendation',
  'nextStep',
  'Analysepfad',
  'Reparaturpfad',
]);

includesAll('metric paths: p1-a kennzahlenwege vorhanden', telemetryPage, [
  'MetricPathPanel',
  'Kennzahlen-Wege',
  'Live-Telemetrie',
  'Gesundheitsmesh',
  'Automationsschiene',
  'Risikowert',
  'Missionsstatus',
  'Builder-Last',
  'Unteransicht öffnen',
  'Nächster Schritt',
]);

includesAll('builder workshop: p1-b werkstatt sichtbar', telemetryPage, [
  'BuilderWorkshopPanel',
  'Builder-Werkstatt',
  'Eingang',
  'Bauen',
  'Warteschlange',
  'Reparatur',
  'Prüfung',
  'Mission',
  'Sicht öffnen',
  'setSelectedView',
]);

includesAll('sprache: p2-a deutsche Primärlabels sichtbar', `${overview}\n${telemetryPage}\n${readText('components/activity-feed.tsx')}\n${readText('components/operator-guidance-card.tsx')}`, [
  'Goldene Baseline',
  'Ein-Screen-Lage',
  'Nächste Fälligkeitsprüfung',
  'Schritte',
  'Automationsplaner',
  'Sync / Brücke',
  'Vega-Technikzelle',
  'Aktivitätsstrom',
  'Strom anzeigen',
  'Neuen Einsatz erstellen',
]);

excludesPatterns('sprache: p2-a alte Primärlabels entfernt', `${overview}\n${telemetryPage}\n${readText('components/activity-feed.tsx')}\n${readText('components/operator-guidance-card.tsx')}`, [
  { label: 'Golden Baseline', pattern: />Golden Baseline<|['"`]Golden Baseline(?: pruefen\.)?['"`]/ },
  { label: 'One-Screen', pattern: />One-Screen<|['"`]One-Screen['"`]/ },
  { label: 'Nächster Due-Check', pattern: />Nächster Due-Check<|['"`]Nächster Due-Check['"`]/ },
  { label: 'Steps', pattern: />Steps<|label="Steps"|label: 'Steps'|label: "Steps"/ },
  { label: 'Automation-Scheduler', pattern: />Automation-Scheduler<|['"`]Automation-Scheduler['"`]/ },
  { label: 'Sync / Bridge', pattern: />Sync \/ Bridge<|['"`]Sync \/ Bridge['"`]/ },
  { label: 'Vega Tech Cell', pattern: /Vega Tech Cell/ },
  { label: 'Aktivitäts-Feed', pattern: />Aktivitäts-Feed<|['"`]Aktivitäts-Feed['"`]/ },
  { label: 'Feed anzeigen', pattern: />Feed anzeigen<|['"`]Feed anzeigen['"`]/ },
  { label: 'Neuen Dispatch erstellen', pattern: />Neuen Dispatch erstellen<|['"`]Neuen Dispatch erstellen['"`]/ },
]);

includesAll('portfolio ui: operator text sanitizer vorhanden', readText('components/portfolio-control-tower-page.tsx'), [
  'operatorVisibleText',
  'Fresh-Session-Übergabe',
  'Übergabe',
  'operatorVisibleText(card.job_card_id)',
]);

for (const width of ['1440', '1720', '1920']) {
  add(`visual verifier: ${width}px viewport`, visualVerifier.includes(width), `${width}px`);
}

add(
  'dashboard verifier: direkt ausführbar',
  fs.existsSync(path.join(appRoot, 'scripts', 'verify_dashboard_finish_contract.mjs')),
  'node scripts/verify_dashboard_finish_contract.mjs',
);

add(
  'no english handoff leak in portfolio labels',
  !/Fresh Session Handoff|Kein Handoff geladen|Handoff-, Chat/.test(readText('components/portfolio-control-tower-page.tsx').split('function operatorVisibleText')[0]),
  'Fresh-Session-Übergabe / Übergabe statt Handoff',
);

const result = {
  ok: failures.length === 0,
  checks,
  failures,
};

console.log(JSON.stringify(result, null, 2));

if (failures.length > 0) {
  process.exitCode = 1;
}
