#!/usr/bin/env node

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const appRoot = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const lioncomRoot = path.resolve(appRoot, '..');
const workspaceRoot = process.env.VIVI_WORKSPACE_ROOT
  || process.env.LIONCOM_WORKSPACE_ROOT
  || path.join(os.homedir(), 'Library/Application Support/LIONCOM/runtime-workspace');

const checks = [];

function read(filePath) {
  return fs.existsSync(filePath) ? fs.readFileSync(filePath, 'utf8') : '';
}

function add(ok, name, detail) {
  checks.push({ status: ok ? 'pass' : 'fail', name, detail });
}

function includesAll(text, tokens) {
  return tokens.every((token) => text.includes(token));
}

const claimTypes = read(path.join(appRoot, 'lib/control-room/types.ts'));
const paths = read(path.join(appRoot, 'lib/constants/paths.ts'));
const autonomyService = read(path.join(appRoot, 'lib/services/autonomyService.ts'));
const runner = read(path.join(lioncomRoot, 'scripts/run_local_duo_loop.sh'));

add(
  includesAll(claimTypes, [
    'modelRouteSnapshotAtClaimStart',
    "source: 'autonomy-claim'",
    'routeProbeOk?: boolean | null',
    'loopStatusPath: string',
  ]),
  'AutonomyClaim exposes claim-start model route snapshot',
  'lib/control-room/types.ts',
);

add(
  paths.includes('VIVI_MODEL_ROUTE_STATUS'),
  'runtime path exposes vivi model route status',
  'lib/constants/paths.ts',
);

add(
  includesAll(autonomyService, [
    'buildModelRouteSnapshotAtClaimStart',
    'PATHS.VIVI_MODEL_ROUTE_STATUS',
    'modelRouteSnapshotAtClaimStart',
    'routeProbeCheckedAt',
  ]),
  'claim creation captures route snapshot before dispatch',
  'lib/services/autonomyService.ts',
);

add(
  includesAll(autonomyService, [
    'Model Route Snapshot At Claim Start',
    'JSON.stringify(claim.modelRouteSnapshotAtClaimStart)',
  ]),
  'task claim ledger renders snapshot',
  'TASK_CLAIMS.md render contract',
);

add(
  includesAll(runner, [
    'CLAIM_MODEL_ROUTE_SNAPSHOT_JSON',
    '.claim.modelRouteSnapshotAtClaimStart // null',
    'Claim-Start Model Route Snapshot',
    'claimModelRouteSnapshotAtClaimStart',
  ]),
  'local duo loop propagates snapshot into heartbeat and prompt',
  'scripts/run_local_duo_loop.sh',
);

const runtimeStatusPath = path.join(workspaceRoot, '.runtime/local-duo-loop-status.json');
const routeStatusPath = path.join(workspaceRoot, '.runtime/vivi-model-route-status.json');
add(
  fs.existsSync(runtimeStatusPath),
  'runtime loop status path is known',
  runtimeStatusPath,
);
add(
  fs.existsSync(routeStatusPath),
  'route probe status path is known',
  routeStatusPath,
);

const failures = checks.filter((check) => check.status === 'fail');
const result = {
  checkedAt: new Date().toISOString(),
  ok: failures.length === 0,
  appRoot,
  lioncomRoot,
  workspaceRoot,
  checks,
  failures,
};

console.log(JSON.stringify(result, null, 2));
process.exitCode = result.ok ? 0 : 1;
