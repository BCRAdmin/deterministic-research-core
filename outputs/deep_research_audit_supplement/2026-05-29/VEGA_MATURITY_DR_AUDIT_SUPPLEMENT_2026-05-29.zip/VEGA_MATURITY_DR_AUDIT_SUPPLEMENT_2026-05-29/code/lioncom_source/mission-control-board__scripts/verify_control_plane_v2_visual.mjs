#!/usr/bin/env node

import { createRequire } from 'node:module';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const appRoot = path.resolve(scriptDir, '..');
const failures = [];
const warnings = [];
const checks = [];
const VISUAL_VERIFY_TIMEOUT_MS = Number(process.env.LIONCOM_V2_VISUAL_TIMEOUT_MS || 180_000);

const rawLeakPatterns = [
  /Acknowledge or close/i,
  /Structured Codex packets/i,
  /No immediate intervention/i,
  /could not claim/i,
  /outside the allowed/i,
  /same as vega/i,
  /other infos/i,
  /raw json/i,
  /Quick Actions/i,
  /Operator Guidance/i,
  /System Status/i,
  /Operation Posture/i,
  /Threat Level/i,
  /Primary Operations Agent/i,
  /\bCode Tasks\b/i,
  /\bVerification Queue\b/i,
  /\bHandoff\b/i,
  /\bHEALTHY\b/i,
  /\bREQUESTED\b/i,
  /undefined/i,
  /\bnull\b/i,
];

const operatorInfoForbiddenPatterns = [
  /\/api\/control-plane-v2/i,
  /\bJSON\b/i,
  /raw json/i,
  /internal report/i,
  /stack trace/i,
  /bug window/i,
  /json payload/i,
  /keine fremde demo/i,
];

const viewPlan = [
  {
    id: 'overview',
    nav: /ÜBERSICHT/i,
    mustContain: [/LAGEBILD/i, /VIVI LOOP & GATE/i, /TELEMETRIE & KONTROLLE/i, /OPERATIONS-DECK/i, /EIN-SCREEN-LAGE/i, /LIVE-DATENVERBINDUNG/i, /DIREKTE VIVI-RUNTIME/i, /LOKALER DUO-LOOP/i, /REMOTE-BRIDGE/i, /LOKALE WAHRHEIT|LOKALER FALLBACK/i],
  },
  {
    id: 'vivi',
    nav: /VIVI COMMAND/i,
    mustContain: [/VIVI COMMAND/i, /VIVI-ARBEITSRAUM|PRIMÄRER OPERATIONS-AGENT|OPERATOR\s*→\s*VIVI/i, /Agent-Einstellungen|Vivi-Entscheidungspunkte/i, /VIVI LOOP & GATE|AUTOMATIONSZUSTAND/i],
  },
  {
    id: 'vega',
    nav: /VEGA TECH CELL/i,
    mustContain: [/VEGA TECH CELL/i, /OPERATOR\s*→\s*VEGA/i, /CODE-AUFGABEN|TECHNISCHE AUFGABEN/i, /REPOSITORY\s+INTEGRITÄT|VEGA LIVE-STATUS|CODE-METRIKEN/i],
  },
  {
    id: 'portfolio',
    nav: /PORTFOLIO/i,
    mustContain: [/PORTFOLIO CONTROL TOWER/i, /PORTFOLIO CONTROL TOWER V2/i, /UTILITY REVENUE\/FUNNEL/i, /TRUST\/RULE COVERAGE/i, /REVIEW QUEUE/i, /OUTCOME HORIZONS/i, /OPPORTUNITY BACKLOG/i, /MAINTENANCE\/GOVERNANCE/i, /PORTFOLIO-BASELINE/i, /EXECUTION CONTRACT/i, /TRUTH-HIERARCHY/i, /GITHUB-GATES/i, /VIVI-OS-V1/i, /OpenJarvis Component Adapter/i, /Pattern-Harvest/i],
  },
  {
    id: 'dispatch',
    nav: /DISPATCH(?:\s+BRIDGE|-BRÜCKE)|ROUTING\s*&\s*ÜBERGABEN/i,
    mustContain: [/DISPATCH-BRÜCKE/i, /DISPATCH(?:\s+COMPOSER|-ERSTELLER)/i, /ROUTING-REGELN/i, /ÜBERGABE/i],
  },
  {
    id: 'missions',
    nav: /MISSIONEN/i,
    mustContain: [/MISSION CONTROL/i, /MISSIONSTABELLE/i, /MISSIONSDETAIL|NÄCHSTE AKTION/i],
  },
  {
    id: 'telemetry',
    nav: /TELEMETRIE/i,
    mustContain: [/TELEMETRIE/i, /SYSTEMSIGNALE/i, /Quelle:/i, /KENNZAHLEN-WEGE/i, /BUILDER-WERKSTATT/i, /ALARMWEGE/i, /NÄCHSTER SICHERER SCHRITT/i],
  },
  {
    id: 'backlog',
    nav: /RÜCKSTAU|WARTESCHLANGEN\s*&\s*EINGANG/i,
    mustContain: [/RÜCKSTAU/i, /WARTESCHLANGEN|TRIAGE/i, /EMPFOHLENER AGENT|EMPFOHLEN/i],
  },
  {
    id: 'audit',
    nav: /AUDIT|PROTOKOLL/i,
    mustContain: [/AUDIT/i, /PROTOKOLL|LOG/i, /TRACE/i],
  },
];

function viewById(id) {
  const view = viewPlan.find((candidate) => candidate.id === id);
  if (!view) throw new Error(`Missing visual verifier view: ${id}`);
  return view;
}

function resolveBaseUrl() {
  if (process.env.LIONCOM_BASE_URL) return process.env.LIONCOM_BASE_URL.replace(/\/$/, '');

  try {
    return execFileSync(process.execPath, [path.join(scriptDir, 'resolve_desktop_server_url.mjs')], {
      encoding: 'utf8',
      cwd: appRoot,
    }).trim().replace(/\/$/, '');
  } catch {
    return 'http://127.0.0.1:4107';
  }
}

function loadPlaywright() {
  const candidates = [
    'playwright',
    '/Users/BjornRosinger/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright',
  ];

  for (const candidate of candidates) {
    try {
      return require(candidate);
    } catch {
      // Try next known runtime.
    }
  }

  throw new Error('Playwright ist weder lokal noch im gebuendelten Codex-Runtime-Pfad verfuegbar.');
}

function resolveChromePath() {
  const candidates = [
    process.env.PLAYWRIGHT_CHROME_PATH,
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/Applications/Chromium.app/Contents/MacOS/Chromium',
  ].filter(Boolean);

  return candidates.find((candidate) => fs.existsSync(candidate)) || null;
}

function addCheck(name, status, detail = '') {
  checks.push({ name, status, detail });
  if (status === 'fail') failures.push({ name, detail });
  if (status === 'warn') warnings.push({ name, detail });
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function fail(name, detail) {
  addCheck(name, 'fail', detail);
}

function pass(name, detail = '') {
  addCheck(name, 'pass', detail);
}

function warn(name, detail = '') {
  addCheck(name, 'warn', detail);
}

async function getPageMetrics(page) {
  return page.evaluate(() => {
    const visibleOverflow = Array.from(document.body.querySelectorAll('*'))
      .filter((element) => {
        const style = window.getComputedStyle(element);
        if (style.display === 'none' || style.visibility === 'hidden') return false;
        if (style.position === 'fixed') return false;
        const rect = element.getBoundingClientRect();
        if (rect.width <= 0 || rect.height <= 0) return false;
        return rect.left < -2 || rect.right > window.innerWidth + 2;
      })
      .slice(0, 10)
      .map((element) => {
        const rect = element.getBoundingClientRect();
        return {
          tag: element.tagName.toLowerCase(),
          className: typeof element.className === 'string' ? element.className.slice(0, 120) : '',
          left: Math.round(rect.left),
          right: Math.round(rect.right),
          width: Math.round(rect.width),
        };
      });

    const oversizedEmptyPanels = Array.from(document.querySelectorAll('.hud-panel, [class*="rounded-2xl"]'))
      .map((element) => {
        const rect = element.getBoundingClientRect();
        const text = (element.textContent || '').replace(/\s+/g, ' ').trim();
        return { height: rect.height, width: rect.width, textLength: text.length, text: text.slice(0, 80) };
      })
      .filter((item) => item.height > 320 && item.textLength < 80)
      .slice(0, 5);

    return {
      bodyText: document.body.innerText,
      scrollWidth: document.documentElement.scrollWidth,
      clientWidth: document.documentElement.clientWidth,
      scrollHeight: document.documentElement.scrollHeight,
      visibleOverflow,
      oversizedEmptyPanels,
      frameworkOverlay: Array.from(document.querySelectorAll('[data-nextjs-dialog-overlay], [data-nextjs-dialog], nextjs-portal'))
        .some((element) => {
          const rect = element.getBoundingClientRect();
          const style = window.getComputedStyle(element);
          const hasVisibleArea = rect.width > 8 && rect.height > 8;
          const hasOverlayText = (element.textContent || '').trim().length > 0;
          return hasVisibleArea && hasOverlayText && style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0';
        }),
    };
  });
}

async function clickSidebar(page, pattern) {
  await closeOperatorInfoDialog(page);
  const button = page.locator('button').filter({ hasText: pattern }).first();
  await button.click({ timeout: 10_000 });
  await page.waitForTimeout(300);
}

async function verifyView(page, view) {
  await clickSidebar(page, view.nav);
  const metrics = await getPageMetrics(page);

  pass(`${view.id}: seite erreichbar`, `${metrics.clientWidth}px viewport`);

  for (const pattern of view.mustContain) {
    if (pattern.test(metrics.bodyText)) {
      pass(`${view.id}: erwarteter inhalt`, pattern.source);
    } else {
      fail(`${view.id}: erwarteter inhalt fehlt`, pattern.source);
    }
  }

  if (metrics.frameworkOverlay) {
    fail(`${view.id}: framework overlay`, 'Next.js/React Overlay sichtbar');
  } else {
    pass(`${view.id}: kein framework overlay`);
  }

  const overflow = metrics.scrollWidth - metrics.clientWidth;
  if (overflow > 12 || metrics.visibleOverflow.length > 0) {
    fail(`${view.id}: kein horizontaler overflow`, JSON.stringify({ overflow, visibleOverflow: metrics.visibleOverflow }));
  } else {
    pass(`${view.id}: kein horizontaler overflow`, String(Math.max(0, overflow)));
  }

  if (metrics.oversizedEmptyPanels.length > 0) {
    warn(`${view.id}: grosse leere panel pruefen`, JSON.stringify(metrics.oversizedEmptyPanels));
  } else {
    pass(`${view.id}: keine grossen leeren panel`);
  }

  const leaks = rawLeakPatterns.filter((pattern) => pattern.test(metrics.bodyText)).map((pattern) => pattern.source);
  if (leaks.length > 0) {
    fail(`${view.id}: keine rohtext-leaks`, leaks.join(', '));
  } else {
    pass(`${view.id}: keine rohtext-leaks`);
  }
}

async function verifyOperatorDialog(page) {
  await clickSidebar(page, /ÜBERSICHT/i);
  const action = page.locator('button').filter({ hasText: /Zu Vivi Command/i }).first();
  await action.click({ timeout: 10_000 });
  await page.waitForTimeout(250);
  const metrics = await getPageMetrics(page);

  if (/VIVI COMMAND/i.test(metrics.bodyText)) {
    pass('cta navigation: zu vivi command funktioniert');
  } else {
    fail('cta navigation: zu vivi command funktioniert', 'Vivi Ansicht nach CTA nicht sichtbar');
  }

  const infoButton = page.locator('button').filter({ hasText: /Alle Anfragen anzeigen|Details anzeigen|Jetzt prüfen/i }).first();
  if (await infoButton.count()) {
    await infoButton.click({ timeout: 10_000 });
    await page.waitForTimeout(250);
    const dialogText = await page.locator('body').innerText();
    if (/Operator Info|Baseline startet|Missionseingang|Details/i.test(dialogText)) {
      pass('operator aktion: button liefert sichtbare reaktion');
    } else {
      warn('operator aktion: button reaktion unklar', 'kein Dialog/Status erkannt');
    }
    await closeOperatorInfoDialog(page);
  } else {
    warn('operator aktion: kein pruefbarer infobutton gefunden');
  }
}

async function verifyLegacyQueryNotice(page, baseUrl) {
  await page.goto(`${baseUrl}/control-plane-v2?saved=vivi-command&legacyTab=command`, { waitUntil: 'networkidle', timeout: 20_000 });
  await page.waitForTimeout(300);
  const bodyText = await page.locator('body').innerText();

  if (/Operator Info/i.test(bodyText) && /Vivi-Auftrag wurde gespeichert/i.test(bodyText) && /Control Plane V2/i.test(bodyText)) {
    pass('legacy query notice: gespeicherter eingang erklaert');
  } else {
    fail('legacy query notice: gespeicherter eingang erklaert', bodyText.slice(0, 500));
  }

  if (/raw json|internal report|stack trace|bug window|json payload/i.test(bodyText)) {
    fail('legacy query notice: keine debug-sprache', 'Debug-/Rohtext im Operator-Hinweis sichtbar');
  } else {
    pass('legacy query notice: keine debug-sprache');
  }

  await closeOperatorInfoDialog(page);
}

function verifyVegaChatRouteContract() {
  const consolePath = path.join(appRoot, 'components', 'vega-chat-console.tsx');
  const routePath = path.join(appRoot, 'app', 'api', 'vega-chat', 'route.ts');
  const consoleSource = fs.readFileSync(consolePath, 'utf8');
  const routeSource = fs.readFileSync(routePath, 'utf8');
  if (
    consoleSource.includes("fetch('/api/vega-chat'")
    && consoleSource.includes('Neue Vega-Session')
    && routeSource.includes("PATHS.CODEX_CHAT_THREAD")
    && routeSource.includes("'- Status: chat'")
  ) {
    pass('vega chat route: livechat statt dispatch', 'Vega nutzt /api/vega-chat und CODEX_CHAT_THREAD');
  } else {
    fail('vega chat route: livechat statt dispatch', 'Vega-Chat braucht eigene Session-API und darf nicht ueber Dispatch als Auftrag laufen');
  }
}

async function verifyVegaChatSessionUi(page) {
  await clickSidebar(page, /VEGA TECH CELL/i);
  await closeOperatorInfoDialog(page);
  const bodyText = await page.locator('body').innerText();
  const required = [/Livechat-Sessions/i, /Neue Vega-Session/i, /Vega-Sessions/i, /getrennt von Dispatch-Aufträgen/i];
  const missing = required.filter((pattern) => !pattern.test(bodyText)).map((pattern) => pattern.source);
  if (missing.length === 0) {
    pass('vega chat sessions: eigene operatorflaeche sichtbar', 'Vega-Livechat ist sessionbasiert');
  } else {
    fail('vega chat sessions: eigene operatorflaeche sichtbar', `missing=${missing.join(', ')}`);
  }
}

async function closeOperatorInfoDialog(page) {
  for (let attempt = 0; attempt < 10; attempt += 1) {
    const dialog = page.locator('[role="dialog"][aria-modal="true"]').first();
    if (!(await dialog.count())) return;
    const closeButton = dialog.locator('button[aria-label="Info schließen"]').first();
    if (await closeButton.count()) {
      await closeButton.click({ timeout: 5_000, force: true });
    }
    await page.waitForTimeout(220);
  }
}

async function waitForActionButtonReady(page, button) {
  for (let attempt = 0; attempt < 24; attempt += 1) {
    await closeOperatorInfoDialog(page);
    if ((await button.count()) && (await button.isEnabled())) return true;
    await page.waitForTimeout(250);
  }
  return false;
}

async function clickButtonAndExpectOperatorInfo(page, view, labelPattern, expectedPattern = /Operator Info/i) {
  await clickSidebar(page, view.nav);
  await closeOperatorInfoDialog(page);

  const button = page.locator('main button').filter({ hasText: labelPattern }).first();
  if (!(await button.count())) {
    fail(`button contract ${view.id}: ${labelPattern.source}`, 'Button nicht sichtbar');
    return;
  }

  const ready = await waitForActionButtonReady(page, button);
  if (!ready) {
    fail(`button contract ${view.id}: ${labelPattern.source}`, 'Button blieb nach vorheriger Aktion deaktiviert');
    return;
  }

  await button.click({ timeout: 10_000 });
  await page.waitForTimeout(180);
  const bodyText = await page.locator('body').innerText();

  if (expectedPattern.test(bodyText)) {
    pass(`button contract ${view.id}: ${labelPattern.source}`, 'Operator-Info sichtbar');
  } else {
    fail(`button contract ${view.id}: ${labelPattern.source}`, 'Kein operatorfreundlicher Dialog/Status nach Klick');
  }

  await verifyOperatorInfoBodyReadable(page, `button contract ${view.id}: ${labelPattern.source}`);

  await closeOperatorInfoDialog(page);
  await page.waitForTimeout(450);
  await closeOperatorInfoDialog(page);
}

async function clickAriaButtonAndExpectOperatorInfo(page, view, ariaLabel, expectedPattern = /Operator Info/i) {
  await clickSidebar(page, view.nav);
  await closeOperatorInfoDialog(page);

  const button = page.locator(`main button[aria-label="${ariaLabel}"]`).first();
  if (!(await button.count())) {
    fail(`button contract ${view.id}: ${ariaLabel}`, 'Button nicht sichtbar');
    return;
  }

  await button.click({ timeout: 10_000 });
  await page.waitForTimeout(180);
  const bodyText = await page.locator('body').innerText();

  if (expectedPattern.test(bodyText)) {
    pass(`button contract ${view.id}: ${ariaLabel}`, 'Operator-Info sichtbar');
  } else {
    fail(`button contract ${view.id}: ${ariaLabel}`, 'Kein operatorfreundlicher Dialog/Status nach Klick');
  }

  await verifyOperatorInfoBodyReadable(page, `button contract ${view.id}: ${ariaLabel}`);

  await closeOperatorInfoDialog(page);
}

async function verifyOperatorInfoBodyReadable(page, label) {
  const body = page.locator('.operator-info-body').first();
  if (!(await body.count())) {
    fail(`${label}: operator-info textflaeche sichtbar`, 'Body fehlt');
    return;
  }
  const bodyText = (await body.innerText()).trim();
  const style = await body.evaluate((element) => {
    const computed = window.getComputedStyle(element);
    const paragraph = element.querySelector('p');
    const paragraphComputed = paragraph ? window.getComputedStyle(paragraph) : computed;
    return {
      color: paragraphComputed.color,
      backgroundColor: computed.backgroundColor,
      textLength: element.textContent?.trim().length || 0,
    };
  });
  if (bodyText.length > 24 && !/rgba?\(127,\s*154,\s*170/i.test(style.color)) {
    const forbidden = operatorInfoForbiddenPatterns.find((pattern) => pattern.test(bodyText));
    if (forbidden) {
      fail(`${label}: operator-info operatorfreundlich`, `verbotenes Muster: ${forbidden.source}`);
    } else {
      pass(`${label}: operator-info text lesbar`, `${style.textLength} Zeichen`);
    }
  } else {
    fail(`${label}: operator-info text lesbar`, `textLength=${style.textLength} color=${style.color} background=${style.backgroundColor}`);
  }
}

async function verifyButtonContracts(page) {
  const contracts = [
    { view: viewById('vivi'), label: /Alle Anfragen anzeigen/i },
    { view: viewById('vivi'), label: /Agent-Einstellungen/i },
    { view: viewById('vega'), label: /Queue-Details anzeigen/i },
    { view: viewById('vega'), label: /Ändern/i },
    { view: viewById('vega'), label: /Diff anzeigen/i },
    { view: viewById('vega'), label: /Alle Untersuchungen anzeigen/i },
    { view: viewById('vega'), label: /Werkzeugübersicht öffnen/i },
    { view: viewById('backlog'), label: /An Vivi routen/i },
    { view: viewById('backlog'), label: /An Vega routen/i },
    { view: viewById('backlog'), label: /Erledigt/i },
    { view: viewById('backlog'), label: /Blocker/i },
    { view: viewById('backlog'), label: /Auto-Aufräumvorschläge/i },
    { view: viewById('audit'), label: /Audit exportieren/i },
    { view: viewById('audit'), label: /Trace öffnen/i },
  ];

  for (const contract of contracts) {
    await clickButtonAndExpectOperatorInfo(page, contract.view, contract.label);
  }
  await verifyAutomationConsole(page);
  await verifyVegaChatSessionUi(page);

  await clickSidebar(page, /TELEMETRIE/i);
  for (const label of [/Mesh aktualisieren/i, /Live-Drilldown öffnen/i, /Systemexport/i, /Health-Check starten/i]) {
    await clickButtonAndExpectOperatorInfo(page, viewById('telemetry'), label);
  }
}

async function verifyAutomationConsole(page) {
  await clickSidebar(page, /VIVI COMMAND/i);
  await closeOperatorInfoDialog(page);
  const button = page.locator('main button').filter({ hasText: /Automation-Einstellungen/i }).first();
  if (!(await button.count())) {
    fail('automation console: einstellungen sichtbar', 'Button nicht sichtbar');
    return;
  }
  await button.click({ timeout: 10_000 });
  await page.waitForTimeout(900);
  const bodyText = await page.locator('body').innerText();
  const required = [/Automation-Konsole/i, /Start/i, /Stop/i, /Entfernen/i, /Neu anlegen/i];
  const missing = required.filter((pattern) => !pattern.test(bodyText)).map((pattern) => pattern.source);
  if (missing.length === 0) {
    pass('automation console: start stop neu entfernen sichtbar', 'lokale LaunchAgent-Konsole');
  } else {
    fail('automation console: start stop neu entfernen sichtbar', `missing=${missing.join(', ')}`);
  }
}

async function verifyRuntimeModeIsolation(page) {
  await clickSidebar(page, /VIVI COMMAND/i);
  await closeOperatorInfoDialog(page);
  const viviCloud = page.locator('main button[aria-label="Vivi Cloud-Fallback anzeigen"]').first();
  if (!(await viviCloud.count())) {
    fail('runtime isolation: vivi cloud button sichtbar', 'Vivi Runtime-Umschalter nicht gefunden');
    return;
  }
  await viviCloud.click({ timeout: 10_000 });
  await page.waitForTimeout(180);
  const afterViviClick = await page.locator('body').innerText();
  if (/Der andere Agent wird dadurch nicht umgestellt|startet keinen externen Lauf/i.test(afterViviClick)) {
    pass('runtime isolation: vivi wechsel erklaert agent-scope');
  } else {
    fail('runtime isolation: vivi wechsel erklaert agent-scope', 'Operator-Hinweis nennt Agent-Isolation nicht');
  }
  await closeOperatorInfoDialog(page);

  await clickSidebar(page, /VEGA TECH CELL/i);
  const vegaLocal = page.locator('main button[aria-label="Vega lokales LLM anzeigen"]').first();
  const vegaCloud = page.locator('main button[aria-label="Vega Cloud-Fallback anzeigen"]').first();
  if (!(await vegaLocal.count()) || !(await vegaCloud.count())) {
    fail('runtime isolation: vega runtime buttons sichtbar', 'Vega Runtime-Umschalter nicht gefunden');
    return;
  }
  const localPressed = await vegaLocal.getAttribute('aria-pressed');
  const cloudPressed = await vegaCloud.getAttribute('aria-pressed');
  if (localPressed === 'true' && cloudPressed === 'false') {
    pass('runtime isolation: vivi schaltet vega nicht um');
  } else {
    fail('runtime isolation: vivi schaltet vega nicht um', `vega local=${localPressed} cloud=${cloudPressed}`);
  }
}

async function verifyVegaVerificationQueueReadability(page) {
  await clickSidebar(page, /VEGA TECH CELL/i);
  await closeOperatorInfoDialog(page);
  const rows = page.locator('[data-vega-verification-row="readable-card"]');
  const rowCount = await rows.count();
  if (rowCount < 3) {
    fail('vega pruef-queue: lesbare kartenzeilen', `nur ${rowCount} lesbare Zeilen gefunden`);
    return;
  }

  const metrics = await rows.evaluateAll((elements) => elements.slice(0, 6).map((element) => {
    const rect = element.getBoundingClientRect();
    const text = (element.textContent || '').replace(/\s+/g, ' ').trim();
    const visibleOverflowChildren = Array.from(element.querySelectorAll('*')).filter((child) => {
      const childRect = child.getBoundingClientRect();
      return childRect.width > 0 && childRect.height > 0 && childRect.right > rect.right + 1;
    }).length;
    return {
      width: Math.round(rect.width),
      height: Math.round(rect.height),
      textLength: text.length,
      visibleOverflowChildren,
    };
  }));
  const badRows = metrics.filter((row) => row.height < 68 || row.textLength < 28 || row.visibleOverflowChildren > 0);
  if (badRows.length > 0) {
    fail('vega pruef-queue: lesbare kartenzeilen', JSON.stringify(badRows));
  } else {
    pass('vega pruef-queue: lesbare kartenzeilen', `${rowCount} Zeilen`);
  }
}

async function verifyResponsiveDesktopViewports(page) {
  const viewportWidths = [1440, 1720, 1920];
  const views = [
    viewPlan[0],
    viewPlan[1],
    viewPlan[2],
    viewPlan[3],
    viewPlan[4],
    viewPlan[5],
    viewPlan[6],
    viewPlan[7],
  ];

  for (const width of viewportWidths) {
    await page.setViewportSize({ width, height: 875 });
    await page.waitForTimeout(250);

    for (const view of views) {
      await clickSidebar(page, view.nav);
      const metrics = await getPageMetrics(page);
      const overflow = metrics.scrollWidth - metrics.clientWidth;
      const label = `${view.id} ${width}px`;

      if (metrics.frameworkOverlay) {
        fail(`responsive ${label}: kein framework overlay`, 'Next.js/React Overlay sichtbar');
      } else {
        pass(`responsive ${label}: kein framework overlay`);
      }

      if (overflow > 12 || metrics.visibleOverflow.length > 0) {
        fail(`responsive ${label}: kein horizontaler overflow`, JSON.stringify({ overflow, visibleOverflow: metrics.visibleOverflow }));
      } else {
        pass(`responsive ${label}: kein horizontaler overflow`, String(Math.max(0, overflow)));
      }

      if (metrics.oversizedEmptyPanels.length > 0) {
        warn(`responsive ${label}: grosse leere panel pruefen`, JSON.stringify(metrics.oversizedEmptyPanels));
      } else {
        pass(`responsive ${label}: keine grossen leeren panel`);
      }
    }
  }

  await page.setViewportSize({ width: 1920, height: 875 });
}

async function verifyOverviewFinishComposition(page) {
  const finishViewports = [
    { width: 1440, maxScrollDebt: 1250 },
    { width: 1720, maxScrollDebt: 1150 },
    { width: 1920, maxScrollDebt: 1100 },
  ];
  const requiredFirstViewportAnchors = [
    'LAGEBILD',
    'Vivi',
    'Vega',
    'Operations-Deck',
    'Live-Datenverbindung',
    'Direkte Vivi-Runtime',
    'Lokaler Duo-Loop',
    'Remote-Bridge',
  ];

  for (const { width, maxScrollDebt } of finishViewports) {
    await page.setViewportSize({ width, height: 875 });
    await clickSidebar(page, /ÜBERSICHT/i);
    await page.evaluate(() => {
      const main = document.querySelector('main');
      if (main) main.scrollTop = 0;
    });
    await page.waitForTimeout(250);

    const finishMetrics = await page.evaluate((anchors) => {
      const main = document.querySelector('main');
      const mainRect = main.getBoundingClientRect();
      const visibleAnchors = {};

      for (const anchor of anchors) {
        const walker = document.createTreeWalker(main, NodeFilter.SHOW_TEXT);
        let node = walker.nextNode();
        let found = false;

        while (node) {
          if ((node.nodeValue || '').includes(anchor)) {
            const element = node.parentElement;
            const rect = element?.getBoundingClientRect();
            if (
              rect
              && rect.width > 0
              && rect.height > 0
              && rect.top >= mainRect.top
              && rect.top < mainRect.bottom
              && rect.left >= mainRect.left
              && rect.left < mainRect.right
            ) {
              found = true;
              break;
            }
          }
          node = walker.nextNode();
        }

        visibleAnchors[anchor] = found;
      }

      const thinTallPanels = Array.from(main.querySelectorAll('.hud-panel, [class*="rounded-2xl"]'))
        .map((element) => {
          const rect = element.getBoundingClientRect();
          const text = (element.textContent || '').replace(/\s+/g, ' ').trim();
          return {
            top: rect.top,
            height: rect.height,
            width: rect.width,
            textLength: text.length,
            text: text.slice(0, 80),
          };
        })
        .filter((panel) => panel.top >= mainRect.top && panel.top < mainRect.bottom && panel.height > 460 && panel.textLength < 140 && panel.width > 260)
        .slice(0, 5);

      return {
        mainScrollDebt: main.scrollHeight - main.clientHeight,
        visibleAnchors,
        thinTallPanels,
      };
    }, requiredFirstViewportAnchors);

    const missingAnchors = requiredFirstViewportAnchors.filter((anchor) => !finishMetrics.visibleAnchors[anchor]);
    if (missingAnchors.length > 0) {
      fail(`p3 overview finish ${width}px: vertrauensanker im ersten viewport`, `missing=${missingAnchors.join(', ')}`);
    } else {
      pass(`p3 overview finish ${width}px: vertrauensanker im ersten viewport`, requiredFirstViewportAnchors.join(', '));
    }

    if (finishMetrics.mainScrollDebt > maxScrollDebt) {
      fail(`p3 overview finish ${width}px: scrolllast begrenzt`, `scrollDebt=${finishMetrics.mainScrollDebt} max=${maxScrollDebt}`);
    } else {
      pass(`p3 overview finish ${width}px: scrolllast begrenzt`, `scrollDebt=${finishMetrics.mainScrollDebt}`);
    }

    if (finishMetrics.thinTallPanels.length > 0) {
      warn(`p3 overview finish ${width}px: hohe schwache panels pruefen`, JSON.stringify(finishMetrics.thinTallPanels));
    } else {
      pass(`p3 overview finish ${width}px: keine hohen schwachen panels`);
    }
  }

  await page.setViewportSize({ width: 1920, height: 875 });
}

async function main() {
  const baseUrl = resolveBaseUrl();
  const { chromium } = loadPlaywright();
  const executablePath = resolveChromePath();
  if (!executablePath) {
    throw new Error('Kein lokaler Chrome/Chromium gefunden. Setze PLAYWRIGHT_CHROME_PATH fuer die V2-Visual-QA.');
  }

  const browser = await chromium.launch({ executablePath, headless: true });
  const context = await browser.newContext({ viewport: { width: 1920, height: 875 }, deviceScaleFactor: 1 });
  const page = await context.newPage();
  const failedResponses = [];
  const consoleIssues = [];

  page.on('response', (response) => {
    const url = response.url();
    if (response.status() >= 400 && !url.includes('/favicon.ico')) {
      failedResponses.push({ status: response.status(), url });
    }
  });
  page.on('console', (message) => {
    if (['error', 'warning'].includes(message.type()) && !/favicon/i.test(message.text())) {
      consoleIssues.push({ type: message.type(), text: message.text().slice(0, 240) });
    }
  });

  try {
    await page.goto(`${baseUrl}/control-plane-v2`, { waitUntil: 'networkidle', timeout: 20_000 });
    const title = await page.title();
    if (/LIONCOM/i.test(title)) pass('page identity: titel', title);
    else warn('page identity: titel ungewoehnlich', title);

    for (const view of viewPlan) {
      await verifyView(page, view);
    }

    verifyVegaChatRouteContract();
    await verifyLegacyQueryNotice(page, baseUrl);
    await verifyOperatorDialog(page);
    await verifyButtonContracts(page);
    await verifyRuntimeModeIsolation(page);
    await verifyVegaVerificationQueueReadability(page);
    await verifyResponsiveDesktopViewports(page);
    await verifyOverviewFinishComposition(page);

    if (failedResponses.length > 0) {
      fail('http responses: keine 4xx/5xx assets', JSON.stringify(failedResponses.slice(0, 8)));
    } else {
      pass('http responses: keine 4xx/5xx assets');
    }

    const relevantConsoleIssues = consoleIssues.filter((issue) => !/Failed to load resource/i.test(issue.text));
    if (relevantConsoleIssues.length > 0) {
      fail('console health: keine relevanten errors/warnings', JSON.stringify(relevantConsoleIssues.slice(0, 8)));
    } else {
      pass('console health: sauber');
    }
  } finally {
    await Promise.race([browser.close(), sleep(5_000)]);
  }

  const result = {
    ok: failures.length === 0,
    baseUrl,
    checks,
    warnings,
    failures,
  };
  console.log(JSON.stringify(result, null, 2));
  if (!result.ok) process.exitCode = 1;
}

function runWithTimeout(task) {
  const timeout = setTimeout(() => {
    console.error(JSON.stringify({
      ok: false,
      error: 'visual verifier timeout',
      timeoutMs: VISUAL_VERIFY_TIMEOUT_MS,
      checksCompleted: checks.length,
    }, null, 2));
    process.exit(1);
  }, VISUAL_VERIFY_TIMEOUT_MS);

  return task.finally(() => clearTimeout(timeout));
}

runWithTimeout(main()).catch((error) => {
  console.error(error instanceof Error ? error.stack || error.message : String(error));
  process.exitCode = 1;
});
