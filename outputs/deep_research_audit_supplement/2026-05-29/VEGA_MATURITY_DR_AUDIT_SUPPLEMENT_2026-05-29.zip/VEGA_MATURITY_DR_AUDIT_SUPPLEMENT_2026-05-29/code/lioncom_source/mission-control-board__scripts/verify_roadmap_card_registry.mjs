#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';

const appRoot = process.cwd();
const failures = [];

const requiredFiles = [
  'app/api/roadmap-cards/route.ts',
  'app/api/roadmap-cards/[cardId]/route.ts',
  'app/api/roadmap-cards/[cardId]/enqueue/route.ts',
  'components/control-room/RoadmapCardRegistry.tsx',
  'lib/services/controlPlaneDispatchService.ts',
  'lib/services/roadmapCardService.ts',
  'lib/types/roadmap-cards.ts',
  'scripts/verify_roadmap_card_registry.mjs',
];

for (const file of requiredFiles) {
  if (!fs.existsSync(path.join(appRoot, file))) {
    failures.push(`missing file: ${file}`);
  }
}

const pathsSource = read('lib/constants/paths.ts');
requireToken(pathsSource, 'ROADMAP_CARDS', 'PATHS.ROADMAP_CARDS missing');
requireToken(pathsSource, "'.runtime', 'roadmap-cards', 'cards.json'", 'ROADMAP_CARDS must point to .runtime/roadmap-cards/cards.json');

const typesSource = read('lib/types/roadmap-cards.ts');
for (const status of ['parked', 'review_due', 'queued', 'done', 'blocked']) {
  requireToken(typesSource, status, `roadmap status missing: ${status}`);
}
for (const field of [
  'id',
  'title',
  'summary',
  'sourcePath',
  'status',
  'priority',
  'gate',
  'risk',
  'targetMode',
  'taskType',
  'runtime',
  'reviewAt',
  'nextStep',
  'createdAt',
  'updatedAt',
  'dispatchRef',
  'note',
]) {
  requireToken(typesSource, field, `roadmap card field missing from types: ${field}`);
}

const roadService = read('lib/services/roadmapCardService.ts');
requireToken(roadService, 'roadmap-20260528-clawhub-audit-gate', 'seed id missing');
requireToken(roadService, 'ClawHub Audit Gate & Vivi Media Adapter', 'seed title missing');
requireToken(roadService, '2026-06-02T07:00:00.000Z', 'seed reviewAt missing');
requireToken(roadService, 'PATHS.ROADMAP_CARDS', 'roadmap service must use ROADMAP_CARDS path');
requireToken(roadService, 'dispatchControlPlaneTask', 'roadmap enqueue must reuse dispatch service');
forbidToken(roadService, 'operator-go-manifest', 'roadmap service must not write operator-go-manifest.json');
forbidToken(roadService, 'OPERATOR_GO_MANIFEST', 'roadmap service must not write Operator-Go manifests');

const dispatchRoute = read('app/api/control-plane-v2/dispatch/route.ts');
requireToken(dispatchRoute, 'dispatchControlPlaneTask', 'control-plane dispatch route must use extracted dispatch service');

const dispatchService = read('lib/services/controlPlaneDispatchService.ts');
requireToken(dispatchService, 'appendRailBlock', 'dispatch service must own rail writes');
requireToken(dispatchService, 'syncAllControlPlanes', 'dispatch service must keep existing control-plane sync');
requireToken(dispatchService, 'startLocalDuoLoop', 'dispatch service must preserve Vivi start behavior');
requireToken(dispatchService, 'LIONCOM Control Plane V2 Dispatch Bridge', 'default dispatch source label changed unexpectedly');

const shellSource = read('components/control-room/ControlRoomShell.tsx');
requireToken(shellSource, 'RoadmapCardRegistry', 'ControlRoomShell must import/render RoadmapCardRegistry');
requireToken(shellSource, 'operatorDecisionCount', 'Operator-Go badge must combine counts');
requireToken(shellSource, 'roadmapDueCount', 'roadmap due count missing from shell');
const registryIndex = shellSource.indexOf('<RoadmapCardRegistry');
const inboxIndex = shellSource.indexOf('<OperatorGoInbox');
if (registryIndex === -1 || inboxIndex === -1 || registryIndex > inboxIndex) {
  failures.push('RoadmapCardRegistry must render above OperatorGoInbox');
}

const registrySource = read('components/control-room/RoadmapCardRegistry.tsx');
for (const token of ['/api/roadmap-cards', 'In Pipeline legen', 'Parken', 'Erledigt', 'Operator-Go-Publisher: getrennt']) {
  requireToken(registrySource, token, `RoadmapCardRegistry missing token: ${token}`);
}

const operatorManifestPath = path.join(appRoot, '.recovery', 'operator-go-manifest.json');
if (fs.existsSync(operatorManifestPath)) {
  const manifest = fs.readFileSync(operatorManifestPath, 'utf8');
  for (const token of ['roadmap-20260528-clawhub-audit-gate', 'ROADMAP_CARDS', 'roadmap-cards', 'ClawHub Audit Gate']) {
    if (manifest.includes(token)) {
      failures.push(`operator-go-manifest.json contains roadmap-card token: ${token}`);
    }
  }
}

const runDue = read('scripts/run_operator_go_due.mjs');
const health = read('scripts/check_operator_go_health.mjs');
for (const [label, source] of [['run_operator_go_due.mjs', runDue], ['check_operator_go_health.mjs', health]]) {
  for (const token of ['ROADMAP_CARDS', 'roadmap-cards', 'Roadmap Card Registry', 'ClawHub Audit Gate']) {
    if (source.includes(token)) {
      failures.push(`${label} contains roadmap-card publisher token: ${token}`);
    }
  }
}

if (failures.length > 0) {
  console.error('Roadmap Card Registry verifier failed:');
  for (const failure of failures) console.error(`- ${failure}`);
  process.exit(1);
}

console.log('Roadmap Card Registry verifier passed.');

function read(relativePath) {
  const filePath = path.join(appRoot, relativePath);
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch {
    failures.push(`missing readable file: ${relativePath}`);
    return '';
  }
}

function requireToken(source, token, message) {
  if (!source.includes(token)) failures.push(message);
}

function forbidToken(source, token, message) {
  if (source.includes(token)) failures.push(message);
}
