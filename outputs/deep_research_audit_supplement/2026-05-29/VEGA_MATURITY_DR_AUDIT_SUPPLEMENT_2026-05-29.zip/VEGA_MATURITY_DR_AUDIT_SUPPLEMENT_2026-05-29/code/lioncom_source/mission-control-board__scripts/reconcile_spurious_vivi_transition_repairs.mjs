#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';

const workspaceRoot = process.env.VIVI_WORKSPACE_ROOT
  || process.env.LIONCOM_WORKSPACE_ROOT
  || '/Users/BjornRosinger/Library/Application Support/LIONCOM/runtime-workspace';

const now = new Date().toISOString();

const railSpecs = [
  {
    name: 'REPAIR_QUEUE.md',
    path: path.join(workspaceRoot, 'REPAIR_QUEUE.md'),
    terminalStatus: 'closed',
  },
  {
    name: 'CODEX_INBOX.md',
    path: path.join(workspaceRoot, 'CODEX_INBOX.md'),
    terminalStatus: 'closed',
  },
];

function parseRail(content) {
  const marker = content.search(/^###\s+/m);
  const header = marker >= 0 ? content.slice(0, marker) : content;
  const body = marker >= 0 ? content.slice(marker) : '';
  const blocks = body
    .split(/^###\s+/m)
    .map((section) => section.trim())
    .filter(Boolean)
    .map((section) => {
      const [headline, ...lines] = section.split('\n');
      const fields = {};
      for (const line of lines) {
        const match = line.trim().match(/^\-\s*([^:]+):\s*(.*)$/);
        if (match) fields[match[1].trim()] = match[2].trim();
      }
      return {
        id: headline.trim(),
        lines,
        fields,
        raw: section,
      };
    });

  return { header, blocks };
}

function serializeRail(header, blocks) {
  const cleanHeader = header.endsWith('\n\n') ? header : header.endsWith('\n') ? `${header}\n` : `${header}\n\n`;
  return `${cleanHeader}${blocks.map((block) => `### ${block.id}\n${block.lines.join('\n').trimEnd()}`).join('\n\n')}\n`;
}

function normalized(value) {
  return String(value || '').trim().toLowerCase();
}

function isTerminalStatus(status) {
  return ['closed', 'answered', 'reported', 'done'].includes(normalized(status));
}

function isSpuriousTransitionBlock(block) {
  if (isTerminalStatus(block.fields.Status)) return false;

  const haystack = normalized([
    block.fields.Source,
    block.fields.Title,
    block.fields.Summary,
    block.fields.Problem,
    block.fields.Context,
    block.fields['Routing Note'],
    block.raw,
  ].join(' '));

  if (!haystack.includes('invalid vivi state transition detected')) return false;
  if (!haystack.includes('outside the allowed vivi operating flow')) return false;
  if (haystack.includes('vivi entered freeze') || haystack.includes('state: freeze')) return false;

  return true;
}

function updateField(lines, field, value) {
  const prefix = `- ${field}:`;
  const next = [...lines];
  const index = next.findIndex((line) => line.trim().startsWith(prefix));
  if (index >= 0) {
    next[index] = `${prefix} ${value}`;
    return next;
  }
  next.push(`${prefix} ${value}`);
  return next;
}

function reconcileRail(spec) {
  if (!fs.existsSync(spec.path)) {
    return { rail: spec.name, changed: 0, path: spec.path };
  }

  const content = fs.readFileSync(spec.path, 'utf8');
  const parsed = parseRail(content);
  let changed = 0;

  const blocks = parsed.blocks.map((block) => {
    if (!isSpuriousTransitionBlock(block)) return block;

    let lines = updateField(block.lines, 'Status', spec.terminalStatus);
    lines = updateField(lines, 'Closed At', now);
    lines = updateField(
      lines,
      'Resolution',
      'Spurious Vivi pass-boundary state-transition repair. The V2 bridge now accepts iterative pass transitions and keeps real FREEZE/blocker signals actionable.',
    );
    changed += 1;
    return { ...block, lines };
  });

  if (changed > 0) {
    fs.writeFileSync(spec.path, serializeRail(parsed.header, blocks), 'utf8');
  }

  return { rail: spec.name, changed, path: spec.path };
}

const results = railSpecs.map(reconcileRail);
console.log(JSON.stringify({
  ok: true,
  workspaceRoot,
  reconciledAt: now,
  results,
}, null, 2));
