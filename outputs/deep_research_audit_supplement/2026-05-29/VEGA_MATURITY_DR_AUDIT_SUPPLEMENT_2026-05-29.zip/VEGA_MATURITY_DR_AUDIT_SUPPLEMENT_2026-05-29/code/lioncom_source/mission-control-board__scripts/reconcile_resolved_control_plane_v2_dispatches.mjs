#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const appRoot = path.resolve(scriptDir, '..');
const lioncomRoot = path.resolve(appRoot, '..');
const workspaceRoot = process.env.VIVI_WORKSPACE_ROOT
  || process.env.LIONCOM_WORKSPACE_ROOT
  || '/Users/BjornRosinger/Library/Application Support/LIONCOM/runtime-workspace';
const verifyOnly = process.argv.includes('--verify');
const now = new Date().toISOString();

const railSpecs = [
  { name: 'VIVI_COMMAND_QUEUE.md', terminalStatus: 'reported' },
  { name: 'WORK_INTAKE.md', terminalStatus: 'reported' },
  { name: 'CODEX_INBOX.md', terminalStatus: 'closed' },
  { name: 'REPAIR_QUEUE.md', terminalStatus: 'reported' },
];

const resolvedV2Dispatches = [
  {
    reference: 'DISPATCH-20260513003016881-N61S',
    label: 'Night Mode Robustness Buildout',
    titleNeedles: ['Night Mode Robustness Buildout', 'LIONCOM V2 lokale Arbeitsapp'],
    resolution: 'V2-Nachtmodus-Robustheit ist durch aktuelle lokale Release-Gates, Watchdog, Session-Health, Flight Pack, API- und Visual-Verifier abgedeckt.',
  },
  {
    reference: 'DISPATCH-20260513010411690-ZTF6',
    label: 'V2 Local-Ready Hardening',
    titleNeedles: ['V2 Local-Ready Hardening', 'Offline-Arbeitskontinuität', 'Vivi Sessions'],
    resolution: 'V2 Local-Ready-Haertung ist durch Session-Lifecycle-Health, lokale Autonomy-Readiness, Flight Pack und Release-Gate belegt.',
  },
];

const releaseEvidence = [
  { file: path.join(appRoot, 'scripts/verify_control_plane_v2_release.mjs'), includes: ['vivi-session-health', 'vivi-night-watchdog', 'codex-loop-guards', 'verify:control-plane-v2:visual'] },
  { file: path.join(appRoot, 'scripts/check_vivi_night_run_health.mjs'), includes: ['flight-pack offline operatorbericht vorhanden', 'runner idle-closure autocorrect aktiv'] },
  { file: path.join(appRoot, 'scripts/verify_vivi_session_lifecycle.mjs'), includes: ['session wechseln/update ausfuehrbar', 'nicht-leere session wird nicht hart entfernt'] },
  { file: path.join(workspaceRoot, '.runtime/control-plane-v2-flight-pack/latest.md'), includes: ['## Vivi Lokal Arbeiten', '## Offline-Kurzablauf', 'VIVI_CHAT_SESSIONS.json'] },
];

function readText(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf8');
  } catch {
    return '';
  }
}

function releaseEvidencePasses() {
  const failures = [];
  for (const requirement of releaseEvidence) {
    const text = readText(requirement.file);
    for (const needle of requirement.includes) {
      if (!text.includes(needle)) {
        failures.push(`${path.relative(lioncomRoot, requirement.file)} fehlt "${needle}"`);
      }
    }
  }
  return { ok: failures.length === 0, failures };
}

function parseRail(content) {
  const marker = content.search(/^###\s+/m);
  const header = marker >= 0 ? content.slice(0, marker) : content;
  const body = marker >= 0 ? content.slice(marker) : '';
  const blocks = body
    .split(/^###\s+/m)
    .map((section) => section.trim())
    .filter(Boolean)
    .map((section) => {
      const [headline, ...lines] = section.split('\n');
      const fields = {};
      for (const line of lines) {
        const match = line.trim().match(/^\-\s*([^:]+):\s*(.*)$/);
        if (match) fields[match[1].trim()] = match[2].trim();
      }
      return { id: headline.trim(), lines, fields, raw: section };
    });
  return { header, blocks };
}

function serializeRail(header, blocks) {
  const normalizedHeader = header.endsWith('\n\n') ? header : header.endsWith('\n') ? `${header}\n` : `${header}\n\n`;
  return `${normalizedHeader}${blocks.map((block) => `### ${block.id}\n${block.lines.join('\n').trimEnd()}`).join('\n\n')}\n`;
}

function normalized(value) {
  return String(value || '').trim().toLowerCase();
}

function isTerminalStatus(status) {
  return ['closed', 'answered', 'reported', 'done', 'archived', 'parked', 'released', 'resolved'].includes(normalized(status));
}

function updateField(lines, field, value) {
  const prefix = `- ${field}:`;
  const next = [...lines];
  const index = next.findIndex((line) => line.trim().startsWith(prefix));
  if (index >= 0) {
    next[index] = `${prefix} ${value}`;
    return next;
  }
  const rawIndex = next.findIndex((line) => line.trim().startsWith('- Raw Request:'));
  const insertAt = rawIndex >= 0 ? rawIndex : next.length;
  next.splice(insertAt, 0, `${prefix} ${value}`);
  return next;
}

function matchResolvedDispatch(block) {
  const text = [block.id, block.fields.Reference, block.fields.Title, block.fields.Summary, block.raw].join('\n');
  return resolvedV2Dispatches.find((dispatch) => {
    if (text.includes(dispatch.reference)) return true;
    return dispatch.titleNeedles.every((needle) => text.includes(needle));
  });
}

function reconcileRail(spec, evidence) {
  const filePath = path.join(workspaceRoot, spec.name);
  if (!fs.existsSync(filePath)) {
    return { rail: spec.name, changed: 0, unresolved: [], closed: [] };
  }

  const parsed = parseRail(fs.readFileSync(filePath, 'utf8'));
  const closed = [];
  const unresolved = [];
  const blocks = parsed.blocks.map((block) => {
    const dispatch = matchResolvedDispatch(block);
    if (!dispatch || isTerminalStatus(block.fields.Status)) return block;

    if (!evidence.ok) {
      unresolved.push({
        rail: spec.name,
        id: block.id,
        reference: block.fields.Reference || dispatch.reference,
        title: block.fields.Title || block.id,
        reason: evidence.failures.join('; '),
      });
      return block;
    }

    let lines = updateField(block.lines, 'Status', spec.terminalStatus);
    lines = updateField(lines, 'Closed At', now);
    lines = updateField(lines, 'Resolution', dispatch.resolution);
    lines = updateField(lines, 'Evidence', 'verify_control_plane_v2_release.mjs, check_vivi_night_run_health.mjs, verify_vivi_session_lifecycle.mjs, latest Flight Pack');
    closed.push({
      rail: spec.name,
      id: block.id,
      reference: block.fields.Reference || dispatch.reference,
      status: spec.terminalStatus,
    });
    return { ...block, lines };
  });

  if (!verifyOnly && closed.length > 0) {
    fs.writeFileSync(filePath, serializeRail(parsed.header, blocks), 'utf8');
  }

  return { rail: spec.name, changed: verifyOnly ? 0 : closed.length, unresolved, closed: verifyOnly ? [] : closed, wouldClose: verifyOnly ? closed : [] };
}

const evidence = releaseEvidencePasses();
const results = railSpecs.map((spec) => reconcileRail(spec, evidence));
const unresolved = results.flatMap((result) => result.unresolved);
const result = {
  ok: evidence.ok && unresolved.length === 0,
  workspaceRoot,
  verifyOnly,
  checkedAt: now,
  evidenceOk: evidence.ok,
  evidenceFailures: evidence.failures,
  changed: results.reduce((sum, entry) => sum + entry.changed, 0),
  closed: results.flatMap((entry) => entry.closed),
  wouldClose: results.flatMap((entry) => entry.wouldClose || []),
  unresolved,
};

console.log(JSON.stringify(result, null, 2));
if (!result.ok) process.exit(1);
