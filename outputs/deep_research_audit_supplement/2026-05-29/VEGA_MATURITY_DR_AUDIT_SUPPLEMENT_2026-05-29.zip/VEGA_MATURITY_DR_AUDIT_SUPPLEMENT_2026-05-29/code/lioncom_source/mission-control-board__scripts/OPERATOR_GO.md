# Operator-Go runner (mission-control-board)

## Commands

- Run due publishes: `npm run operator-go:run-due`
- Check health: `npm run operator-go:health` (if configured in `package.json`)

## Runtime workspace

By default the scripts store state/log/health under:

- `$HOME/Library/Application Support/LIONCOM/runtime-workspace/.recovery/`

Override with:

- `LIONCOM_RUNTIME_ROOT=/absolute/path/to/runtime-workspace`

If the default runtime location is not writable (e.g. sandboxed runs), the scripts automatically fall back to:

- `<repo>/.runtime/runtime-workspace/.recovery/`
