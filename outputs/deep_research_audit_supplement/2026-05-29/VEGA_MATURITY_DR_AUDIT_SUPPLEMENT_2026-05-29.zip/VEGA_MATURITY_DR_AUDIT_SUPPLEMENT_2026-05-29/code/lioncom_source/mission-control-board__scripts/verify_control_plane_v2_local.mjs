#!/usr/bin/env node

import { execFileSync } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const sourceWorkspaceRoot = path.resolve(root, '..');
const defaultWorkspaceRoot = fs.existsSync(path.join(sourceWorkspaceRoot, 'VIVI_CONTROL_LOOP.md'))
  ? sourceWorkspaceRoot
  : '/Users/BjornRosinger/Library/Application Support/LIONCOM/runtime-workspace';
const workspaceRoot = process.env.VIVI_WORKSPACE_ROOT
  || process.env.LIONCOM_WORKSPACE_ROOT
  || defaultWorkspaceRoot;
const portfolioBaselinePath = path.join(root, 'data', 'portfolio-control-tower-baseline.json');
const lioncomShaFallback = '93af75c';
const mutating = process.argv.includes('--mutating');
const failures = [];
const warnings = [];
const checks = [];

function resolveBaseUrl() {
  if (process.env.LIONCOM_BASE_URL) return process.env.LIONCOM_BASE_URL.replace(/\/$/, '');

  try {
    return execFileSync(process.execPath, [path.join(__dirname, 'resolve_desktop_server_url.mjs')], {
      encoding: 'utf8',
      cwd: root,
    }).trim().replace(/\/$/, '');
  } catch {
    return 'http://127.0.0.1:4107';
  }
}

const baseUrl = resolveBaseUrl();

function pass(name, detail = '') {
  checks.push({ name, status: 'pass', detail });
}

function warn(name, detail) {
  warnings.push({ name, detail });
  checks.push({ name, status: 'warn', detail });
}

function fail(name, detail) {
  failures.push({ name, detail });
  checks.push({ name, status: 'fail', detail });
}

function requireCondition(condition, name, detail) {
  if (condition) pass(name, detail);
  else fail(name, detail);
}

function expectedLioncomPortfolioSha() {
  try {
    const baseline = JSON.parse(fs.readFileSync(portfolioBaselinePath, 'utf8'));
    const repositories = Array.isArray(baseline.repositories) ? baseline.repositories : [];
    const lioncom = repositories.find((repo) => repo?.repo === 'BCRAdmin/LIONCOM');

    if (typeof lioncom?.lastKnownSha === 'string' && lioncom.lastKnownSha.trim()) {
      return {
        sha: lioncom.lastKnownSha.trim(),
        source: 'portfolio-control-tower-baseline.json',
      };
    }

    warn(
      'portfolio baseline lioncom sha fallback verwendet',
      'BCRAdmin/LIONCOM lastKnownSha fehlt in portfolio-control-tower-baseline.json',
    );
  } catch (error) {
    warn(
      'portfolio baseline lioncom sha fallback verwendet',
      `portfolio-control-tower-baseline.json nicht lesbar: ${error?.message || String(error)}`,
    );
  }

  return {
    sha: lioncomShaFallback,
    source: 'fallback: last green portfolio baseline 2026-05-18',
  };
}

async function fetchText(pathname, init = {}) {
  const response = await fetch(`${baseUrl}${pathname}`, {
    redirect: 'manual',
    signal: AbortSignal.timeout(10_000),
    ...init,
    headers: {
      ...(init.headers || {}),
    },
  });

  return {
    status: response.status,
    headers: response.headers,
    body: await response.text(),
  };
}

async function fetchDirectText(url, init = {}) {
  const response = await fetch(url, {
    redirect: 'manual',
    signal: AbortSignal.timeout(10_000),
    ...init,
    headers: {
      ...(init.headers || {}),
    },
  });

  return {
    status: response.status,
    headers: response.headers,
    body: await response.text(),
  };
}

async function fetchJson(pathname, init = {}) {
  const response = await fetch(`${baseUrl}${pathname}`, {
    redirect: 'manual',
    signal: AbortSignal.timeout(10_000),
    ...init,
    headers: {
      'content-type': 'application/json',
      ...(init.headers || {}),
    },
  });
  const text = await response.text();
  let body = null;

  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    fail(`${pathname} json parse`, `Antwort ist kein JSON: ${text.slice(0, 220)}`);
  }

  return {
    status: response.status,
    body,
  };
}

async function verifyHealth() {
  const health = await fetchJson('/api/health');
  requireCondition(health.status === 200, 'health endpoint erreichbar', `HTTP ${health.status}`);
  requireCondition(
    health.body?.overall === 'healthy' || health.body?.overall === 'warning' || health.body?.status === 'ok',
    'health endpoint gruen',
    `overall=${health.body?.overall || health.body?.status || 'unknown'}`,
  );
}

async function verifyControlPlaneData() {
  const snapshot = await fetchJson('/api/control-plane-v2');
  requireCondition(snapshot.status === 200, 'control-plane-v2 api erreichbar', `HTTP ${snapshot.status}`);
  const data = snapshot.body;

  requireCondition(data?.source === 'live', 'control-plane-v2 nutzt live daten', `source=${data?.source || 'missing'}`);
  requireCondition(Boolean(data?.generatedAt), 'control-plane-v2 snapshot timestamp vorhanden', data?.generatedAt || 'missing');
  requireCondition(Number.isFinite(data?.globalStatus?.queueDepth), 'queue depth numerisch', String(data?.globalStatus?.queueDepth));
  requireCondition(Array.isArray(data?.missions) && data.missions.length > 0, 'missionen aus live snapshot vorhanden', `${data?.missions?.length || 0} items`);
  requireCondition(Array.isArray(data?.dispatchEvents), 'dispatch events array vorhanden', `${data?.dispatchEvents?.length || 0} items`);
  requireCondition(Array.isArray(data?.activitySignals), 'activity signals array vorhanden', `${data?.activitySignals?.length || 0} items`);

  const vegaRuntime = (data?.runtimeProfiles || []).find((profile) => profile?.agentId === 'vega');
  requireCondition(
    Boolean(vegaRuntime?.model) && !/^(BERICHT|REPORTING|ATTENTION|ACHTUNG|STABIL|READY|BEREIT)$/i.test(String(vegaRuntime?.model || '').trim()),
    'vega runtime modell ist kein status-label',
    `${vegaRuntime?.provider || 'missing'} / ${vegaRuntime?.model || 'missing'}`,
  );
  const rawRuntimeLabels = (data?.runtimeProfiles || [])
    .filter((profile) => /\b(REQUESTED|HEALTHY|ATTENTION|READY)\b/.test(JSON.stringify({
      status: profile?.status,
      model: profile?.model,
      provider: profile?.provider,
    })))
    .map((profile) => `${profile?.agentId || 'unknown'}:${profile?.status || 'missing'}`);
  requireCondition(
    rawRuntimeLabels.length === 0,
    'runtime-profile statuslabels sind deutsch/operatorlesbar',
    rawRuntimeLabels.join(', ') || 'sauber',
  );

  const staleSmoke = data?.dispatchEvents?.some((event) => String(event.title || '').includes('V2 Dispatch Smoke Test'));
  requireCondition(!staleSmoke, 'keine alten dispatch-smoke-test-eintraege sichtbar', staleSmoke ? 'stale smoke event sichtbar' : 'bereinigt');

  if (data?.globalStatus?.posture !== 'STABIL') {
    warn('systemhaltung nicht stabil', `posture=${data?.globalStatus?.posture}; das kann echte Arbeit anzeigen, ist aber kein Verifier-Fail.`);
  }

  verifyLiveOperatorLanguage(data);
  verifyMissionSurface(data);
  verifyTelemetryProvenance(data);
  verifyOperatorLoopGateSurface(data);
  verifyGoldenBaselineGate(data);
  verifyPortfolioBaselineGate(data);
}

async function verifyAutomationControlSurface() {
  const automations = await fetchJson('/api/control-plane-v2/automations');
  requireCondition(automations.status === 200 && automations.body?.ok === true, 'automation-konsole api erreichbar', `HTTP ${automations.status}`);
  const items = automations.body?.automations || [];
  const templates = automations.body?.templates || [];
  const localDuo = items.find((item) => item?.label === 'com.lioncom.local-duo-loop');
  const controlPlane = items.find((item) => item?.label === 'com.lioncom.local-control-plane');
  requireCondition(Array.isArray(items) && items.length > 0, 'automation-konsole listet launchagents', `${items.length} Eintraege`);
  requireCondition(Boolean(localDuo?.canStop || localDuo?.canStart), 'automation-konsole kann vivi-loop bedienen', localDuo ? `${localDuo.status}` : 'missing');
  requireCondition(controlPlane?.protected === true && controlPlane?.canStop === false && controlPlane?.canArchive === false, 'automation-konsole schuetzt control-plane-kernprozess', controlPlane ? `${controlPlane.status}` : 'missing');
  requireCondition(templates.some((template) => template?.id === 'flight-pack'), 'automation-konsole kann neue sichere automationen anlegen', templates.map((template) => template?.id).join(', '));

  if (mutating) {
    const protectedStop = await fetchJson('/api/control-plane-v2/automations', {
      method: 'POST',
      body: JSON.stringify({ action: 'stop', label: 'com.lioncom.local-control-plane' }),
    });
    requireCondition(protectedStop.status === 409 && protectedStop.body?.ok === false, 'automation-konsole blockiert kernprozess-stop', `HTTP ${protectedStop.status}`);
  }
}

async function verifyFlightPackOperatorContract() {
  const response = await fetchJson('/api/control-plane-v2/flight-pack');
  requireCondition(response.status === 200 && response.body?.ok === true, 'flight-pack api erreichbar', `HTTP ${response.status}`);

  const pack = response.body?.pack;
  const endpoints = pack?.diagnosticEndpoints || {};
  const jsonPath = pack?.files?.json;
  const markdownPath = pack?.files?.markdown;
  const flightPackWorkspaceRoot = typeof pack?.workspaceRoot === 'string' && pack.workspaceRoot.trim()
    ? pack.workspaceRoot
    : workspaceRoot;
  const latestJsonPath = path.join(flightPackWorkspaceRoot, '.runtime', 'control-plane-v2-flight-pack', 'latest.json');
  const latestMarkdownPath = path.join(flightPackWorkspaceRoot, '.runtime', 'control-plane-v2-flight-pack', 'latest.md');
  const createdAtMs = Date.parse(pack?.createdAt || '');
  const ageMinutes = Number.isFinite(createdAtMs) ? (Date.now() - createdAtMs) / 60_000 : Number.POSITIVE_INFINITY;
  let latestSnapshot = null;
  if (fs.existsSync(latestJsonPath)) {
    try {
      latestSnapshot = JSON.parse(fs.readFileSync(latestJsonPath, 'utf8'));
    } catch {
      latestSnapshot = null;
    }
  }
  const latestMarkdown = fs.existsSync(latestMarkdownPath) ? fs.readFileSync(latestMarkdownPath, 'utf8') : '';

  requireCondition(pack?.schemaVersion === 1, 'flight-pack schema version stabil', `schema=${pack?.schemaVersion || 'missing'}`);
  requireCondition(pack?.status?.source === 'live', 'flight-pack nutzt live daten', `source=${pack?.status?.source || 'missing'}`);
  requireCondition(Boolean(jsonPath && markdownPath), 'flight-pack artefaktpfade sichtbar', `${jsonPath || 'missing'} / ${markdownPath || 'missing'}`);
  requireCondition(
    Boolean(jsonPath && markdownPath && fs.existsSync(jsonPath) && fs.existsSync(markdownPath)),
    'flight-pack artefakte existieren lokal',
    `${jsonPath || 'missing'} / ${markdownPath || 'missing'}`,
  );
  requireCondition(
    Boolean(fs.existsSync(latestJsonPath) && fs.existsSync(latestMarkdownPath)),
    'flight-pack latest-artefakte existieren lokal',
    `${latestJsonPath} / ${latestMarkdownPath}`,
  );
  requireCondition(
    Boolean(latestSnapshot?.createdAt && latestSnapshot.createdAt === pack?.createdAt),
    'flight-pack latest-json entspricht api-snapshot',
    `${latestSnapshot?.createdAt || 'missing'} / ${pack?.createdAt || 'missing'}`,
  );
  requireCondition(
    Boolean(pack?.createdAt && latestMarkdown.includes(pack.createdAt)),
    'flight-pack latest-markdown zeigt snapshot-zeit',
    pack?.createdAt || 'missing',
  );
  requireCondition(
    [
      '## Lokale Diagnose-Endpunkte',
      endpoints.controlPlaneV2,
      endpoints.autonomy,
      endpoints.health,
      endpoints.flightPack,
    ].every((token) => typeof token === 'string' && latestMarkdown.includes(token)),
    'flight-pack latest-markdown zeigt diagnose-endpunkte',
    'lokale Diagnose-Links im Operatorbericht',
  );
  requireCondition(
    ageMinutes <= 30,
    'flight-pack snapshot frisch fuer offline-betrieb',
    Number.isFinite(ageMinutes) ? `${ageMinutes.toFixed(1)} min` : 'createdAt fehlt',
  );
  requireCondition(
    endpoints.controlPlaneV2 === `${baseUrl}/api/control-plane-v2`
    && endpoints.autonomy === `${baseUrl}/api/autonomy`
    && endpoints.health === `${baseUrl}/api/health`
    && endpoints.flightPack === `${baseUrl}/api/control-plane-v2/flight-pack`,
    'flight-pack diagnose-endpunkte operatorlesbar',
    JSON.stringify(endpoints),
  );
  requireCondition(
    Boolean(pack?.rails?.viviNightWatchdogWrapper?.exists && pack?.rails?.viviNightWatchdogLaunchAgent?.exists),
    'flight-pack watchdog-installation maschinenlesbar',
    JSON.stringify({
      wrapper: pack?.rails?.viviNightWatchdogWrapper?.exists,
      launchAgent: pack?.rails?.viviNightWatchdogLaunchAgent?.exists,
    }),
  );
}

function verifyLiveOperatorLanguage(data) {
  const text = JSON.stringify({
    operatorLoopStatus: data?.operatorLoopStatus,
    agents: data?.agents,
    agentSummaries: data?.agentSummaries,
    missions: data?.missions,
    dispatchEvents: data?.dispatchEvents,
    handoffQueue: data?.handoffQueue,
    queueItems: data?.queueItems,
    chatMessages: data?.chatMessages,
    workspaces: data?.workspaces,
    intakeRows: data?.intakeRows,
    telemetrySignals: data?.telemetrySignals,
    alerts: data?.alerts,
    backlogItems: data?.backlogItems,
    auditEvents: data?.auditEvents,
    activitySignals: data?.activitySignals,
    automationTasks: data?.automationTasks,
    runtimeProfiles: data?.runtimeProfiles,
    repoSnapshots: data?.repoSnapshots,
    portfolioRepositories: data?.portfolioRepositories,
  });
  const blockedPatterns = [
    /is currently leased to/i,
    /No immediate intervention/i,
    /Acknowledge or close/i,
    /Structured Codex packets/i,
    /Structured Vega packets/i,
    /\b(Vega|Codex)-Pakete are\b/i,
    /\bare wartend\b/i,
    /\bwaiting to be\b/i,
    /\bare waiting\b/i,
    /The (Vega|Codex)(-| )?Schiene is aging/i,
    /The (Vega|Codex) rail is aging/i,
    /Codex has replied recently/i,
    /Vega has replied recently/i,
    /Repair rail has priority/i,
    /No current (Vega|Codex) packet/i,
    /No watcher intervention/i,
    /outside the allowed Vivi operating flow/i,
    /could not claim the next Vivi mission/i,
    /Observed via crontab/i,
    /event-driven/i,
    /on demand/i,
    /Inbound mobile commands are flowing/i,
    /Outbound packets are being staged/i,
    /Critical issues can be escalated/i,
    /Repair packets are queued/i,
    /The local Duo Loop is operational/i,
    /\bVivi is (aktivly|actively) working on\b/i,
    /Backlog floor was empty/i,
    /Project Lane/i,
    /Resource Class/i,
    /Parallel Policy/i,
    /Next Claim/i,
    /Synthesize Backlog/i,
    /Vivi sharpens the local/i,
    /Vivi turns the aktuell V2 state/i,
    /Vivi checks whether the latest V2 Flight Pack/i,
    /Vivi checks whether the V2 night watchdog/i,
    /Vivi verifies new-session/i,
    /Vivi rehearses the real local operator workflow/i,
    /Vivi keeps the local night-run alive/i,
    /Vivi converts recent UI comments/i,
    /Remote read\/write verification succeeded/i,
    /Freeze and collaboration sync are ready/i,
    /Queue pressure is building/i,
    /Vega board rail needs attention/i,
    /Desktop package still runs with asar disabled/i,
    /Inbound mobile Aufträge are flowing/i,
    /\b(packet\(s\) on the rail|outbound relay remains armed)\b/i,
    /\brepair-queue\b/i,
    /\breported\b/i,
    /V2 Night Run Block/i,
    /V2 Local-bereit Hardening/i,
    /\bRepair Rail\b/i,
    /^-\s*(Title|Priority|Reason|Result|Evidence|Cleanup|Handoff):/im,
    /^-\s*Workspace Root:/im,
    /\bpass\/fail result\b/i,
    /\bas acceptance evidence\b/i,
    /\buse the [^.\n]+? for\b/i,
    /\bwith Priorität\b/i,
    /raw_http_probe: not_run/i,
    /effective_transport: local_route_bridge ok/i,
    /VQG auto-correction applied/i,
    /Raw HTTP probes are not required/i,
    /Raw HTTP Probes sind grün/i,
    /The local bridge is confirmed operational/i,
    /\*\*System Health\*\*/i,
    /\*\*Operator Mode\*\*/i,
    /\*\*Session Lifecycle\*\*/i,
    /\boverall: healthy\b/i,
    /\boperational\b/i,
    /\bis außerhalb\b/i,
    /"type":"CODEX"/i,
    /Vega verifier livechat/i,
    /Backlog Synthesis From Signals/i,
    /V2 Night Watchdog Repair Drill/i,
    /Vivi Dauerloop Continuity Sweep/i,
    /Operator Workflow Rehearsal/i,
    /Vivi Session Lifecycle Verification/i,
    /Vivi Session Lifecycle Verifikation/i,
    /V2 Flight Pack Offline Readiness/i,
    /Local-Ready-Prüfung/i,
    /Productive Refill/i,
    /Roadmap Scan/i,
    /Memory (und|and) Report Ingest Sweep/i,
    /VQG Loop Guard/i,
    /Local Operations Playbook Refinement/i,
    /Synthesis From Signals/i,
    /Continuity Sweep/i,
  ];
  const leaks = blockedPatterns.filter((pattern) => pattern.test(text)).map((pattern) => pattern.source);
  requireCondition(leaks.length === 0, 'live-daten operatorfreundlich lokalisiert', leaks.length ? leaks.join(', ') : 'keine bekannten Rohtext-Leaks');

  const vegaVerificationMetric = (data?.agents || [])
    .find((agent) => agent?.id === 'vega')
    ?.metrics?.find((metric) => metric?.id === 'vega-verification');
  const vegaVerificationValue = Number(vegaVerificationMetric?.value);
  const vegaVerificationDetail = String(vegaVerificationMetric?.detail || '');
  requireCondition(
    !/wart|queued|waiting/i.test(vegaVerificationDetail) || vegaVerificationValue > 0,
    'vega-verifikationsmetrik widerspricht wartenden paketen nicht',
    `${vegaVerificationMetric?.value ?? 'missing'} · ${vegaVerificationDetail.slice(0, 160)}`,
  );
}

function verifyMissionSurface(data) {
  const missions = Array.isArray(data?.missions) ? data.missions : [];
  const activeClaims = Number(data?.globalStatus?.activeClaims || 0);
  if (activeClaims > 0) {
    const hasActiveMission = missions.some((mission) => mission.status === 'active' && String(mission.id || '').includes('CLAIM'));
    requireCondition(hasActiveMission, 'aktive claims erscheinen in missionen zuerst', hasActiveMission ? `${activeClaims} aktive Claims sichtbar` : JSON.stringify(missions.slice(0, 2)));
  } else {
    pass('aktive claims erscheinen in missionen zuerst', 'keine aktive Claim vorhanden');
  }

  const doneWithRuntimeBlocker = missions.filter((mission) =>
    mission.status === 'done'
      && /ungueltiger|ungültiger|runtime-blocker|outside the allowed/i.test(String(mission.nextStep || '')),
  );
  requireCondition(
    doneWithRuntimeBlocker.length === 0,
    'abgeschlossene missionen zeigen keine alten runtime-blocker als naechste aktion',
    doneWithRuntimeBlocker.map((mission) => mission.id).join(', ') || 'sauber',
  );

  const doneWithNonCompleteProgress = missions.filter((mission) => mission.status === 'done' && Number(mission.progress) !== 100);
  requireCondition(
    doneWithNonCompleteProgress.length === 0,
    'erledigte missionen zeigen 100 prozent fortschritt',
    doneWithNonCompleteProgress.map((mission) => `${mission.id}:${mission.progress}`).join(', ') || 'sauber',
  );

  const placeholderMissions = missions.filter((mission) =>
    /control plane idle|kontrollebene idle|no waiting task|board synchronized/i.test(`${mission.id} ${mission.title} ${mission.nextStep}`),
  );
  requireCondition(
    placeholderMissions.length === 0,
    'missionen zeigen keine legacy-platzhalter',
    placeholderMissions.map((mission) => `${mission.id}:${mission.title}`).join(', ') || 'sauber',
  );

  const progressComparableMissions = missions.filter((mission) => mission.status !== 'done');
  const visibleProgressValues = progressComparableMissions
    .map((mission) => Number(mission.progress))
    .filter((value) => Number.isFinite(value));
  const uniqueProgressValues = new Set(visibleProgressValues);
  requireCondition(
    visibleProgressValues.length <= 1 || uniqueProgressValues.size > 1,
    'missionsfortschritt ist nicht pauschal identisch',
    visibleProgressValues.length ? Array.from(uniqueProgressValues).join(', ') : 'nur abgeschlossene missionen',
  );
}

function verifyTelemetryProvenance(data) {
  const signals = Array.isArray(data?.telemetrySignals) ? data.telemetrySignals : [];
  requireCondition(signals.length > 0, 'telemetrie-signale vorhanden', `${signals.length} Signale`);

  const missingTitles = signals.filter((signal) => !String(signal?.title || '').trim()).map((signal) => signal?.id || 'unknown');
  requireCondition(
    missingTitles.length === 0,
    'telemetrie-signale haben sichtbare titel',
    missingTitles.join(', ') || 'sauber',
  );

  const missingSources = signals
    .filter((signal) => !/^Quelle:\s+\S+/i.test(String(signal?.sourceLabel || '')))
    .map((signal) => signal?.id || signal?.title || 'unknown');
  requireCondition(
    missingSources.length === 0,
    'telemetrie-signale nennen operatorlesbare quellen',
    missingSources.join(', ') || 'sauber',
  );

  const ambiguousTelemetryText = JSON.stringify(signals);
  const ambiguousPatterns = [
    /same as vega/i,
    /other infos/i,
    /unknown source/i,
    /null/i,
  ];
  const ambiguousHits = ambiguousPatterns.filter((pattern) => pattern.test(ambiguousTelemetryText)).map((pattern) => pattern.source);
  requireCondition(
    ambiguousHits.length === 0,
    'telemetrie verwechselt globale und agenten-spezifische daten nicht',
    ambiguousHits.join(', ') || 'sauber',
  );
}

function verifyOperatorLoopGateSurface(data) {
  const status = data?.operatorLoopStatus;
  requireCondition(Boolean(status?.title && status?.summary), 'operator loop status sichtbar', status?.title || 'missing');

  const gate = status?.qualityGate;
  const rawGatePath = path.join(workspaceRoot, '.runtime/vivi-report-quality-gate-status.json');
  if (fs.existsSync(rawGatePath)) {
    const rawGate = JSON.parse(fs.readFileSync(rawGatePath, 'utf8'));
    const activeClaimCount = Number(data?.globalStatus?.activeClaims || 0);
    if (rawGate?.ok === false && rawGate?.claimId && activeClaimCount === 0) {
      requireCondition(
        gate?.ok !== false && !gate?.failureId,
        'stale quality gate blockiert ready-zustand nicht',
        `rawGate=${rawGate.claimId}; activeClaims=0; surface=${gate?.label || 'none'}`,
      );
    }
    if (rawGate?.ok === false && rawGate?.claimId && status?.claimId && rawGate.claimId !== status.claimId) {
      requireCondition(
        gate?.ok !== false && !gate?.failureId,
        'stale quality gate faerbt aktive claim nicht',
        `rawGate=${rawGate.claimId}; active=${status.claimId}; surface=${gate?.label || 'none'}`,
      );
    }
  }

  if (gate?.ok === false && gate.failureId === 'missing_source_gate') {
    fail(
      'interne vivi-claims blockieren nicht mehr nur wegen source-gate-zeile',
      `${status?.claimId || 'unknown'}: ${gate.failureDetail || 'missing detail'}`,
    );
  } else {
    pass(
      'interne vivi-claims blockieren nicht mehr nur wegen source-gate-zeile',
      gate?.failureId ? `aktueller Gate-Hinweis: ${gate.failureId}` : 'kein Source-Gate-False-Block',
    );
  }
}

function verifyGoldenBaselineGate(data) {
  const baseline = data?.goldenBaseline;
  requireCondition(Boolean(baseline), 'golden baseline gate sichtbar', baseline ? 'vorhanden' : 'missing');
  if (!baseline) return;

  requireCondition(
    ['pass', 'fail', 'unknown'].includes(String(baseline.verdict || '')),
    'golden baseline verdict ist maschinenlesbar',
    String(baseline.verdict || 'missing'),
  );
  requireCondition(
    ['fresh', 'stale', 'critical', 'failed', 'unknown'].includes(String(baseline.freshness || '')),
    'golden baseline freshness ist maschinenlesbar',
    String(baseline.freshness || 'missing'),
  );
  requireCondition(
    Array.isArray(baseline.failedSteps),
    'golden baseline failed steps sind array',
    `${baseline.failedSteps?.length || 0} failed`,
  );
  requireCondition(
    typeof baseline.nextAction === 'string' && baseline.nextAction.trim().length > 0,
    'golden baseline nennt naechste operator-aktion',
    baseline.nextAction || 'missing',
  );
  requireCondition(
    Number(baseline.schedule?.intervalHours || 0) > 0 && Boolean(baseline.schedule?.dueScript),
    'golden baseline schedule contract vorhanden',
    JSON.stringify(baseline.schedule || {}),
  );
  if (baseline.generatedAt && baseline.verdict === 'pass') {
    requireCondition(
      baseline.freshness !== 'critical',
      'golden baseline pass ist nicht kritisch veraltet',
      `freshness=${baseline.freshness}; generatedAt=${baseline.generatedAt}`,
    );
  }
}

function verifyPortfolioBaselineGate(data) {
  const repositories = Array.isArray(data?.portfolioRepositories) ? data.portfolioRepositories : [];
  requireCondition(repositories.length === 7, 'portfolio baseline listet sieben repos', `${repositories.length} Repos`);
  if (repositories.length === 0) return;

  const byRepo = new Map(repositories.map((repo) => [repo?.repo, repo]));
  const requiredRepos = [
    'BCRAdmin/materialbedarf-rechner.de',
    'BCRAdmin/Kindergeld',
    'BCRAdmin/LIONCOM',
    'BCRAdmin/microtool-starter-kit',
    'BCRAdmin/company-dossier-lab',
    'BCRAdmin/deterministic-research-core',
    'BCRAdmin/Vivi-os-v1',
  ];
  const missingRepos = requiredRepos.filter((repo) => !byRepo.has(repo));
  requireCondition(missingRepos.length === 0, 'portfolio baseline enthaelt alle bcradmin-repos', missingRepos.join(', ') || 'alle vorhanden');

  const viviLegacy = byRepo.get('BCRAdmin/Vivi-os-v1');
  requireCondition(viviLegacy?.lifecycle === 'archived', 'vivi-os-v1 als archiviert markiert', JSON.stringify(viviLegacy || {}));
  requireCondition(
    /read-only|legacy|nicht anfassen/i.test(String(viviLegacy?.nextAction || '')),
    'vivi-os-v1 bleibt no-touch',
    viviLegacy?.nextAction || 'missing',
  );

  const activeRepos = repositories.filter((repo) => repo?.lifecycle === 'active');
  const openPublicGates = activeRepos.filter((repo) => repo?.publicGate !== 'operator_gated');
  requireCondition(
    openPublicGates.length === 0,
    'portfolio oeffnet keine public-production gates automatisch',
    openPublicGates.map((repo) => repo.repo).join(', ') || 'alle operator-gated',
  );

  const missingSecurityTruth = activeRepos.filter((repo) =>
    repo?.dependabotStatus !== 'active'
      || repo?.branchProtectionStatus !== 'blocked_plan_or_public_required'
      || repo?.secretScanningStatus !== 'unavailable_private_repo',
  );
  requireCondition(
    missingSecurityTruth.length === 0,
    'portfolio security-status entspricht github-operator-lage',
    missingSecurityTruth.map((repo) => repo.repo).join(', ') || 'Dependabot aktiv, Branch-/Secret-Gates ehrlich blockiert',
  );

  const lioncom = byRepo.get('BCRAdmin/LIONCOM');
  const expectedLioncom = expectedLioncomPortfolioSha();
  requireCondition(
    lioncom?.risk === 'yellow' && lioncom?.lastKnownSha === expectedLioncom.sha,
    'lioncom portfolio-status bleibt gelb mit bekanntem sha',
    `risk=${lioncom?.risk || 'missing'}; sha=${lioncom?.lastKnownSha || 'missing'}; expected=${expectedLioncom.sha}; source=${expectedLioncom.source}`,
  );
}

async function verifyHtmlSurfaces() {
  const rootSurface = await fetchText('/');
  const rootLocation = rootSurface.headers.get('location') || '';
  requireCondition(
    rootSurface.status >= 300 && rootSurface.status < 400 && rootLocation.includes('/control-plane-v2'),
    'root default zeigt control-plane-v2',
    `HTTP ${rootSurface.status} -> ${rootLocation || 'missing location'}`,
  );

  const apiHtml = await fetchText('/api/control-plane-v2', {
    headers: { accept: 'text/html' },
  });
  requireCondition(apiHtml.status === 200, 'control-plane-v2 html summary erreichbar', `HTTP ${apiHtml.status}`);
  requireCondition(apiHtml.body.includes('LIONCOM Control Plane V2'), 'api html summary operatorlesbar', 'Titel gefunden');
  requireCondition(apiHtml.body.includes('Control Plane V2 öffnen'), 'api html summary verweist auf dashboard', 'CTA gefunden');
  requireCondition(!apiHtml.body.includes('{&quot;') && !apiHtml.body.includes('{"generatedAt"'), 'api html summary kein raw-json dump', 'operatorfreundliches HTML');

  const apiDocumentHtml = await fetchText('/api/control-plane-v2', {
    headers: {
      accept: '*/*',
      'sec-fetch-dest': 'document',
      'sec-fetch-mode': 'navigate',
    },
  });
  requireCondition(apiDocumentHtml.status === 200, 'api dokument-navigation erreichbar', `HTTP ${apiDocumentHtml.status}`);
  requireCondition(
    apiDocumentHtml.headers.get('content-type')?.includes('text/html'),
    'api dokument-navigation zeigt operator-html',
    apiDocumentHtml.headers.get('content-type') || 'missing content-type',
  );
  requireCondition(
    apiDocumentHtml.body.includes('Control Plane V2 öffnen') && !apiDocumentHtml.body.includes('{"generatedAt"'),
    'api dokument-navigation kein raw-json dump',
    'operatorfreundliches HTML',
  );

  const dashboard = await fetchText('/control-plane-v2');
  requireCondition(dashboard.status === 200, 'control-plane-v2 dashboard erreichbar', `HTTP ${dashboard.status}`);
  requireCondition(dashboard.body.includes('LIONCOM CONTROL PLANE'), 'dashboard shell titel vorhanden', 'LIONCOM CONTROL PLANE');
  requireCondition(dashboard.body.includes('Übersicht') && dashboard.body.includes('Vivi Command') && dashboard.body.includes('Vega Tech Cell'), 'dashboard sidebar deutsch und vollstaendig', 'Sidebar-Kernitems gefunden');

  const scriptPaths = Array.from(dashboard.body.matchAll(/\bsrc="([^"]*\/_next\/static\/[^"]+\.js)"/g))
    .map((match) => match[1])
    .filter(Boolean);
  const uniqueScriptUrls = Array.from(new Set(scriptPaths.map((scriptPath) => new URL(scriptPath, baseUrl).toString())));
  requireCondition(uniqueScriptUrls.length > 0, 'dashboard next-static scripts gefunden', `${uniqueScriptUrls.length} scripts`);

  const appRouteScriptUrls = uniqueScriptUrls.filter((scriptUrl) => scriptUrl.includes('/_next/static/chunks/app/control-plane-v2/'));
  requireCondition(appRouteScriptUrls.length > 0, 'control-plane-v2 route chunk referenziert', `${appRouteScriptUrls.length} route chunks`);

  for (const scriptUrl of uniqueScriptUrls) {
    const asset = await fetchDirectText(scriptUrl);
    requireCondition(asset.status === 200, 'dashboard next-static asset erreichbar', `${scriptUrl.replace(baseUrl, '')} -> HTTP ${asset.status}`);
  }
}

async function verifyViviChat({ runMutatingSmoke }) {
  const before = await fetchJson('/api/vivi-chat');
  requireCondition(before.status === 200, 'vivi-chat api erreichbar', `HTTP ${before.status}`);
  requireCondition(Array.isArray(before.body?.sessions), 'vivi sessions array vorhanden', `${before.body?.sessions?.length || 0} sessions`);
  requireCondition(Array.isArray(before.body?.messages), 'vivi messages array vorhanden', `${before.body?.messages?.length || 0} messages`);

  const sessionIds = new Set((before.body?.sessions || []).map((session) => session.id));
  if (before.body?.activeSessionId) {
    requireCondition(sessionIds.has(before.body.activeSessionId), 'aktive vivi-session referenziert existierende session', before.body.activeSessionId);
  }

  verifyViviSessionState(before.body);

  if (!runMutatingSmoke) {
    pass('vivi session lifecycle smoke uebersprungen', 'Nutze --mutating fuer create/remove smoke.');
    return;
  }

  const create = await fetchJson('/api/vivi-chat', {
    method: 'POST',
    body: JSON.stringify({
      action: 'create-session',
      title: 'Verifier Temp Session',
      topic: 'Kurzlebiger lokaler V2-Verifier-Smoke. Wird sofort wieder entfernt.',
      providerMode: 'cloud',
      providerPreset: 'ollama',
      requestedModel: 'deepseek-v4-pro:cloud',
    }),
  });
  const createdSessionId = create.body?.snapshot?.activeSessionId;
  requireCondition(create.status === 200 && Boolean(createdSessionId), 'vivi session create smoke', createdSessionId || `HTTP ${create.status}`);
  const createdSession = (create.body?.snapshot?.sessions || []).find((session) => session.id === createdSessionId);
  requireCondition(
    createdSession?.providerPreset === 'ollama' && createdSession?.requestedModel === 'deepseek-v4-pro:cloud',
    'vivi session create uebernimmt provider und modell',
    `${createdSession?.providerPreset || 'missing'}/${createdSession?.requestedModel || 'missing'}`,
  );

  if (createdSessionId) {
    const remove = await fetchJson('/api/vivi-chat/remove', {
      method: 'POST',
      body: JSON.stringify({
        sessionId: createdSessionId,
        confirmEmpty: true,
        reason: 'V2 verifier cleanup',
      }),
    });
    requireCondition(remove.status === 200, 'vivi leere session entfernen smoke', `HTTP ${remove.status}`);

    const after = await fetchJson('/api/vivi-chat');
    const stillPresent = (after.body?.sessions || []).some((session) => session.id === createdSessionId);
    requireCondition(!stillPresent, 'vivi verifier-temp-session bereinigt', stillPresent ? createdSessionId : 'bereinigt');
  }

  const archiveCreate = await fetchJson('/api/vivi-chat', {
    method: 'POST',
    body: JSON.stringify({
      action: 'create-session',
      title: 'Verifier Archive Temp Session',
      topic: 'Kurzlebiger lokaler V2-Archiv-Smoke. Wird sofort archiviert.',
      providerMode: 'cloud',
      providerPreset: 'ollama',
      requestedModel: 'deepseek-v4-pro:cloud',
    }),
  });
  const archiveSessionId = archiveCreate.body?.snapshot?.activeSessionId;
  requireCondition(archiveCreate.status === 200 && Boolean(archiveSessionId), 'vivi session archive-create smoke', archiveSessionId || `HTTP ${archiveCreate.status}`);

  if (archiveSessionId) {
    const archive = await fetchJson('/api/vivi-chat/archive', {
      method: 'POST',
      body: JSON.stringify({
        sessionId: archiveSessionId,
        reason: 'V2 verifier archive cleanup',
      }),
    });
    requireCondition(archive.status === 200, 'vivi session archivieren smoke', `HTTP ${archive.status}`);

    const afterArchive = await fetchJson('/api/vivi-chat');
    const stillActive = (afterArchive.body?.sessions || []).some((session) => session.id === archiveSessionId);
    requireCondition(!stillActive, 'vivi archivierte temp-session nicht aktiv', stillActive ? archiveSessionId : 'archiviert');

    const archivePath = path.join(workspaceRoot, 'VIVI_CHAT_SESSIONS_ARCHIVE.json');
    if (fs.existsSync(archivePath)) {
      const archiveEntries = JSON.parse(fs.readFileSync(archivePath, 'utf8'));
      const archivedEntryFound = Array.isArray(archiveEntries)
        && archiveEntries.some((entry) => entry?.session?.id === archiveSessionId || entry?.id === archiveSessionId);
      requireCondition(archivedEntryFound, 'vivi temp-session im archiv protokolliert', archivedEntryFound ? archiveSessionId : 'missing archive entry');
    } else {
      fail('vivi session archivdatei vorhanden', archivePath);
    }
  }
}

async function verifyVegaChat({ runMutatingSmoke }) {
  const before = await fetchJson('/api/vega-chat');
  requireCondition(before.status === 200, 'vega-chat api erreichbar', `HTTP ${before.status}`);
  requireCondition(Array.isArray(before.body?.sessions), 'vega sessions array vorhanden', `${before.body?.sessions?.length || 0} sessions`);
  requireCondition(Array.isArray(before.body?.messages), 'vega messages array vorhanden', `${before.body?.messages?.length || 0} messages`);

  const sessionIds = new Set((before.body?.sessions || []).map((session) => session.id));
  if (before.body?.activeSessionId) {
    requireCondition(sessionIds.has(before.body.activeSessionId), 'aktive vega-session referenziert existierende session', before.body.activeSessionId);
  }

  if (!runMutatingSmoke) {
    pass('vega session lifecycle smoke uebersprungen', 'Nutze --mutating fuer create/send/archive smoke.');
    return;
  }

  const controlBefore = await fetchJson('/api/control-plane-v2');
  const dispatchCountBefore = controlBefore.body?.dispatchEvents?.length ?? -1;
  const stamp = new Date().toISOString();
  const create = await fetchJson('/api/vega-chat', {
    method: 'POST',
    body: JSON.stringify({
      action: 'create-session',
      title: 'Verifier Vega Temp Session',
      topic: 'Kurzlebiger lokaler V2-Vega-Smoke. Wird sofort archiviert.',
    }),
  });
  const createdSessionId = create.body?.snapshot?.activeSessionId;
  requireCondition(create.status === 200 && Boolean(createdSessionId), 'vega session create smoke', createdSessionId || `HTTP ${create.status}`);

  if (createdSessionId) {
    const message = `Vega verifier livechat ${stamp}`;
    const send = await fetchJson('/api/vega-chat', {
      method: 'POST',
      body: JSON.stringify({
        action: 'send-message',
        sessionId: createdSessionId,
        message,
      }),
    });
    const sessionMessages = (send.body?.snapshot?.messages || [])
      .filter((entry) => entry.sessionId === createdSessionId && String(entry.message || '').includes(message));
    requireCondition(send.status === 200 && sessionMessages.length === 1, 'vega livechat send smoke', `${sessionMessages.length} passende Messages`);

    const controlAfter = await fetchJson('/api/control-plane-v2');
    const dispatchCountAfter = controlAfter.body?.dispatchEvents?.length ?? -1;
    requireCondition(
      dispatchCountBefore === dispatchCountAfter,
      'vega livechat erzeugt keinen dispatch',
      `before=${dispatchCountBefore} after=${dispatchCountAfter}`,
    );

    const archive = await fetchJson('/api/vega-chat', {
      method: 'POST',
      body: JSON.stringify({
        action: 'archive-session',
        sessionId: createdSessionId,
        reason: 'V2 verifier archive cleanup',
      }),
    });
    requireCondition(archive.status === 200, 'vega session archivieren smoke', `HTTP ${archive.status}`);
  }
}

async function verifyViviModelCatalog() {
  const catalog = await fetchJson('/api/vivi-model-catalog');
  requireCondition(catalog.status === 200, 'vivi modellkatalog api erreichbar', `HTTP ${catalog.status}`);
  const providers = Array.isArray(catalog.body?.providers) ? catalog.body.providers : [];
  const models = Array.isArray(catalog.body?.models) ? catalog.body.models : [];
  const providerStatus = Array.isArray(catalog.body?.providerStatus) ? catalog.body.providerStatus : [];
  const providerKeys = new Set(providers.map((provider) => `${provider.mode}:${provider.value}`));
  const statusKeys = new Set(providerStatus.map((status) => status.key));
  requireCondition(providerKeys.has('local:lmstudio'), 'modellkatalog lm studio lokal', `${models.filter((model) => model.provider === 'lmstudio' && model.mode === 'local').length} modelle`);
  requireCondition(providerKeys.has('local:ollama'), 'modellkatalog ollama lokal', `${models.filter((model) => model.provider === 'ollama' && model.mode === 'local').length} modelle`);
  requireCondition(providerKeys.has('cloud:ollama'), 'modellkatalog ollama cloud', `${models.filter((model) => model.provider === 'ollama' && model.mode === 'cloud').length} modelle`);
  requireCondition(providerKeys.has('cloud:chatgpt'), 'modellkatalog chatgpt cloud', `${models.filter((model) => model.provider === 'chatgpt' && model.mode === 'cloud').length} modelle`);
  requireCondition(providerKeys.has('cloud:openrouter'), 'modellkatalog openrouter cloud', `${models.filter((model) => model.provider === 'openrouter' && model.mode === 'cloud').length} modelle`);
  requireCondition(providerStatus.length >= providers.length, 'modellkatalog provider-status sichtbar', `${providerStatus.length}/${providers.length}`);
  requireCondition(providers.every((provider) => statusKeys.has(`${provider.mode}:${provider.value}`)), 'modellkatalog provider-status vollstaendig', Array.from(statusKeys).join(', '));
  requireCondition(
    models.some((model) => model.provider === 'chatgpt' && model.mode === 'cloud' && model.id === 'gpt-5.4'),
    'modellkatalog enthaelt gpt-5.4 bei chatgpt',
    models.filter((model) => model.provider === 'chatgpt').map((model) => model.id).join(', '),
  );
  requireCondition(
    models.some((model) => model.provider === 'chatgpt' && model.mode === 'cloud' && model.id === 'gpt-5.4-mini'),
    'modellkatalog enthaelt gpt-5.4-mini fallback',
    models.filter((model) => model.provider === 'chatgpt').map((model) => model.id).join(', '),
  );
  requireCondition(
    models.some((model) => model.provider === 'ollama' && model.mode === 'cloud' && /:cloud$/.test(model.id)),
    'modellkatalog trennt ollama cloud-modelle',
    models.filter((model) => model.provider === 'ollama' && model.mode === 'cloud').slice(0, 8).map((model) => model.id).join(', '),
  );
  requireCondition(
    models.filter((model) => model.provider === 'openrouter' && model.mode === 'cloud').every((model) => !String(model.id || '').startsWith('~')),
    'modellkatalog openrouter ohne alias-mischung',
    models.filter((model) => model.provider === 'openrouter' && model.mode === 'cloud').slice(0, 8).map((model) => model.id).join(', '),
  );
}

function verifyViviSessionState(snapshot) {
  const sessions = Array.isArray(snapshot?.sessions) ? snapshot.sessions : [];
  const messages = Array.isArray(snapshot?.messages) ? snapshot.messages : [];
  const staleEmptySessions = [];
  const maskedWaitingSessions = [];

  for (const session of sessions) {
    const sessionMessages = messages.filter((message) => message.sessionId === session.id);
    const workMessages = sessionMessages.filter((message) => message.role === 'operator' || message.role === 'vivi');
    const lastOperator = [...sessionMessages].reverse().find((message) => message.role === 'operator');
    const lastVivi = [...sessionMessages].reverse().find((message) => message.role === 'vivi');
    const hasRecoveredWorkPointer = Boolean(String(session.lastReference || '').trim() || String(session.lastMessagePreview || '').trim());
    if (workMessages.length === 0 && !hasRecoveredWorkPointer && isOlderThan(session.createdAt || session.updatedAt, 24 * 60 * 60 * 1000)) {
      staleEmptySessions.push(session.id);
    }
    if (lastOperator && (!lastVivi || Date.parse(lastVivi.addedAt) < Date.parse(lastOperator.addedAt)) && session.status !== 'waiting' && session.status !== 'attention') {
      maskedWaitingSessions.push(session.id);
    }
  }

  requireCondition(
    staleEmptySessions.length === 0,
    'keine alten leeren vivi-sessions aktiv',
    staleEmptySessions.join(', ') || 'sauber',
  );
  requireCondition(
    maskedWaitingSessions.length === 0,
    'vivi-session status maskiert keine offene operator-nachricht',
    maskedWaitingSessions.join(', ') || 'sauber',
  );
}

function isOlderThan(value, maxAgeMs) {
  const time = Date.parse(value || '');
  return Number.isFinite(time) && Date.now() - time > maxAgeMs;
}

function fileHash(filePath) {
  if (!fs.existsSync(filePath)) return null;
  return crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex');
}

function verifyFilesMatch(name, expectedPath, actualPath) {
  const expectedHash = fileHash(expectedPath);
  const actualHash = fileHash(actualPath);
  requireCondition(Boolean(expectedHash), `${name} source vorhanden`, expectedPath);
  requireCondition(Boolean(actualHash), `${name} ziel vorhanden`, actualPath);
  if (expectedHash && actualHash) {
    requireCondition(expectedHash === actualHash, `${name} synchron`, actualHash === expectedHash ? actualPath : `${expectedPath} != ${actualPath}`);
  }
}

async function verifyDispatchValidation() {
  const invalid = await fetchJson('/api/control-plane-v2/dispatch', {
    method: 'POST',
    body: JSON.stringify({
      title: '',
      description: '',
      taskType: 'Mission',
      targetMode: 'Vivi zuerst',
      priority: 'normal',
      runtime: 'Cloud',
    }),
  });

  requireCondition(invalid.status === 400, 'dispatch leerpayload blockiert ohne rail-mutation', `HTTP ${invalid.status}`);
  requireCondition(
    String(invalid.body?.error || '').includes('mindestens'),
    'dispatch leerpayload operatorfreundliche fehlermeldung',
    invalid.body?.error || 'missing error',
  );
}

function verifyLocalRunnerStatus() {
  const statusPath = path.join(workspaceRoot, '.runtime/local-duo-loop-status.json');
  if (!fs.existsSync(statusPath)) {
    warn('local duo loop status fehlt', statusPath);
    return;
  }

  const status = JSON.parse(fs.readFileSync(statusPath, 'utf8'));
  pass('local duo loop status lesbar', `${status.state || 'unknown'} @ ${status.updatedAt || 'unknown'}`);
  requireCondition(Boolean(status.requestedProvider && status.requestedModel), 'vivi requested provider/model sichtbar', `${status.requestedProvider || 'missing'}/${status.requestedModel || 'missing'}`);
  requireCondition(Boolean(status.effectiveProvider && status.effectiveModel), 'vivi effective provider/model sichtbar', `${status.effectiveProvider || 'missing'}/${status.effectiveModel || 'missing'}`);

  const v2NightModePath = path.join(workspaceRoot, '.runtime/lioncom-v2-night-mode-active.json');
  if (fs.existsSync(v2NightModePath) && status.lastClaimId) {
    requireCondition(
      status.projectLane === 'lioncom-core',
      'v2 nachtmodus runner-lane ist lioncom-core',
      `projectLane=${status.projectLane || 'missing'} claim=${status.lastClaimId}`,
    );
  } else {
    pass('v2 nachtmodus runner-lane ist lioncom-core', 'kein aktiver V2-Nachtmodus-Claim im Runnerstatus');
  }

  const lioncomRoot = path.resolve(root, '..');
  const sourceRunner = path.join(lioncomRoot, 'scripts/run_local_duo_loop.sh');
  const runtimeRunner = path.join(workspaceRoot, 'scripts/run_local_duo_loop.sh');
  const automationRunner = path.join(process.env.HOME || '/Users/BjornRosinger', 'Library/Application Support/LIONCOM/automation/run_local_duo_loop.sh');
  verifyFilesMatch('local duo loop runtime-runner', sourceRunner, runtimeRunner);
  verifyFilesMatch('local duo loop launchagent-runner', sourceRunner, automationRunner);

  const sourceInstaller = path.join(lioncomRoot, 'scripts/install_local_duo_loop_agent.sh');
  const runtimeInstaller = path.join(workspaceRoot, 'scripts/install_local_duo_loop_agent.sh');
  verifyFilesMatch('local duo loop installer', sourceInstaller, runtimeInstaller);

  const syncScript = path.join(lioncomRoot, 'scripts/sync_runtime_workspace.sh');
  const syncScriptText = fs.existsSync(syncScript) ? fs.readFileSync(syncScript, 'utf8') : '';
  requireCondition(
    syncScriptText.includes("'VIVI_REPORT_QUALITY.md'") || syncScriptText.includes('"VIVI_REPORT_QUALITY.md"'),
    'runtime sync schuetzt vivi report quality ledger',
    syncScript || 'missing sync script',
  );
}

async function verifyV2NightModeContinuity() {
  const modePath = path.join(workspaceRoot, '.runtime/lioncom-v2-night-mode-active.json');
  if (!fs.existsSync(modePath)) {
    pass('v2 nachtmodus drift-guard inaktiv', 'kein aktiver V2-Nachtmodus-Marker');
    return;
  }
  const modeStatus = JSON.parse(fs.readFileSync(modePath, 'utf8'));
  if (modeStatus?.active === false) {
    pass('v2 nachtmodus drift-guard in standby', modeStatus.standbyReason || modeStatus.nextAction || 'kein aktiver Nachtmodus-Claim');
    return;
  }

  const runnerStatusPath = path.join(workspaceRoot, '.runtime/local-duo-loop-status.json');
  if (fs.existsSync(runnerStatusPath)) {
    const runnerStatus = JSON.parse(fs.readFileSync(runnerStatusPath, 'utf8'));
    requireCondition(
      runnerStatus.state !== 'idle',
      'v2 nachtmodus loop nicht idle',
      `${runnerStatus.state || 'unknown'}: ${runnerStatus.detail || 'no detail'}`,
    );
  }

  const autonomy = await fetchJson('/api/autonomy');
  requireCondition(autonomy.status === 200, 'v2 nachtmodus autonomy erreichbar', `HTTP ${autonomy.status}`);
  const activeViviClaim = (autonomy.body?.activeClaims || []).find((claim) => claim.agent === 'vivi');
  requireCondition(Boolean(activeViviClaim), 'v2 nachtmodus vivi claim aktiv', activeViviClaim?.id || 'keine aktive Vivi-Claim');

  if (activeViviClaim) {
    const haystack = [
      activeViviClaim.title,
      activeViviClaim.reference,
      activeViviClaim.taskId,
      activeViviClaim.sourceRail,
      activeViviClaim.reason,
    ].join(' ').toLowerCase();
    const wrongLane = /fin-platform|membership|quellwert|room16|utility/.test(haystack);
    requireCondition(!wrongLane, 'v2 nachtmodus kein fremd-lane-claim', wrongLane ? haystack : activeViviClaim.title);
  }
}

async function verifyAutonomyOperatorSurface() {
  const autonomy = await fetchJson('/api/autonomy');
  const controlPlane = await fetchJson('/api/control-plane-v2');
  requireCondition(autonomy.status === 200, 'autonomy endpoint erreichbar', `HTTP ${autonomy.status}`);
  requireCondition(controlPlane.status === 200, 'control-plane-v2 operator surface erreichbar', `HTTP ${controlPlane.status}`);

  const activeClaims = Array.isArray(autonomy.body?.activeClaims) ? autonomy.body.activeClaims : [];
  const activeViviClaim = activeClaims.find((claim) => claim?.agent === 'vivi');
  const operatorLoop = controlPlane.body?.operatorLoopStatus;
  if (activeViviClaim) {
    requireCondition(
      operatorLoop?.claimId === activeViviClaim.id,
      'aktive vivi-claim in operator-loop surface sichtbar',
      `autonomy=${activeViviClaim.id || 'missing'} surface=${operatorLoop?.claimId || 'missing'}`,
    );
    requireCondition(
      Boolean(operatorLoop?.taskTitle && operatorLoop?.taskReference),
      'aktive vivi-claim zeigt titel und referenz',
      `${operatorLoop?.taskTitle || 'missing title'} / ${operatorLoop?.taskReference || 'missing reference'}`,
    );
  } else {
    pass('aktive vivi-claim in operator-loop surface sichtbar', 'keine aktive Vivi-Claim');
    pass('aktive vivi-claim zeigt titel und referenz', 'keine aktive Vivi-Claim');
  }

  const selectedTasks = [
    autonomy.body?.viviLoop?.selectedTask,
    autonomy.body?.codexLoop?.selectedTask,
  ].filter(Boolean);
  const operatorSurface = JSON.stringify({
    summary: autonomy.body?.summary,
    operatorFreedom: autonomy.body?.operatorFreedom,
    notes: autonomy.body?.notes,
    viviLoop: {
      state: autonomy.body?.viviLoop?.state,
      summary: autonomy.body?.viviLoop?.summary,
      selectedTask: autonomy.body?.viviLoop?.selectedTask,
      instructions: autonomy.body?.viviLoop?.instructions,
    },
    codexLoop: {
      state: autonomy.body?.codexLoop?.state,
      summary: autonomy.body?.codexLoop?.summary,
      selectedTask: autonomy.body?.codexLoop?.selectedTask,
      instructions: autonomy.body?.codexLoop?.instructions,
    },
    activeClaims,
  });

  const blockedPatterns = [
    /Action:\s*Read the Context Packet/i,
    /Read the Context Packet if accessible/i,
    /proceed with bounded audit of/i,
    /No further immediate action required/i,
    /No artifacts generated/i,
    /Task acknowledged and processed/i,
    /Await explicit instruction/i,
    /awaiting next instruction/i,
    /Vega Chat:\s*test/i,
  ];
  const leaks = blockedPatterns.filter((pattern) => pattern.test(operatorSurface)).map((pattern) => pattern.source);
  requireCondition(
    leaks.length === 0,
    'autonomy operator-surface ohne meta-task-leaks',
    leaks.length ? leaks.join(', ') : 'aktive Tasks und Hinweise sauber',
  );

  const poorActiveTitles = [...activeClaims, ...selectedTasks].filter((entry) => {
    const title = String(entry?.title || '');
    return /^Action:/i.test(title) || /Context Packet|bounded audit/i.test(title);
  });
  requireCondition(
    poorActiveTitles.length === 0,
    'aktive autonomy tasks sind konkrete arbeit',
    poorActiveTitles.map((entry) => entry.title).join(', ') || 'sauber',
  );
}

function parseRailBlocks(content) {
  return content
    .split(/^###\s+/m)
    .map((section) => section.trim())
    .filter(Boolean)
    .flatMap((section) => {
      const [headline, ...lines] = section.split('\n');
      const id = headline?.trim();
      if (!id || id.startsWith('#')) return [];

      const fields = {};
      for (const line of lines) {
        const match = line.trim().match(/^\-\s*([^:]+):\s*(.*)$/);
        if (match) fields[match[1].trim()] = match[2].trim();
      }

      return [{ id, fields, body: lines.join('\n') }];
    });
}

function isTerminalRailStatus(status) {
  return ['closed', 'answered', 'reported', 'done'].includes(String(status || '').trim().toLowerCase());
}

function countOpenSpuriousTransitionBlocks(filePath) {
  if (!fs.existsSync(filePath)) return 0;
  return parseRailBlocks(fs.readFileSync(filePath, 'utf8')).filter((block) => {
    if (isTerminalRailStatus(block.fields.Status)) return false;
    const haystack = [
      block.fields.Source,
      block.fields.Title,
      block.fields.Summary,
      block.fields.Problem,
      block.fields.Context,
      block.body,
    ].join(' ').toLowerCase();
    return haystack.includes('invalid vivi state transition detected')
      && haystack.includes('outside the allowed vivi operating flow');
  }).length;
}

function verifyViviTransitionHygiene() {
  const repairCount = countOpenSpuriousTransitionBlocks(path.join(workspaceRoot, 'REPAIR_QUEUE.md'));
  const codexCount = countOpenSpuriousTransitionBlocks(path.join(workspaceRoot, 'CODEX_INBOX.md'));

  requireCondition(
    repairCount === 0,
    'keine offenen spurious vivi-state-transition repairs',
    `${repairCount} offene Repair-Pakete`,
  );
  requireCondition(
    codexCount === 0,
    'keine offenen spurious vivi-state-transition codex-escalations',
    `${codexCount} offene Codex-Pakete`,
  );
}

function verifyControlPlaneDispatchLaneMetadata() {
  const dispatchRails = [
    'VIVI_COMMAND_QUEUE.md',
    'WORK_INTAKE.md',
    'CODEX_INBOX.md',
    'REPAIR_QUEUE.md',
  ];
  const openDispatchBlocks = dispatchRails.flatMap((fileName) => {
    const filePath = path.join(workspaceRoot, fileName);
    if (!fs.existsSync(filePath)) return [];
    return parseRailBlocks(fs.readFileSync(filePath, 'utf8'))
      .filter((block) => block.fields.Source === 'LIONCOM Control Plane V2 Dispatch Bridge')
      .filter((block) => !isTerminalRailStatus(block.fields.Status))
      .map((block) => ({ ...block, fileName }));
  });

  const missingMetadata = openDispatchBlocks.filter((block) => (
    block.fields['Project Lane'] !== 'lioncom-core'
    || !block.fields['Resource Class']
    || !block.fields['Parallel Policy']
  ));

  requireCondition(
    missingMetadata.length === 0,
    'control-plane-v2 dispatches tragen lane-metadaten',
    missingMetadata.length
      ? missingMetadata.map((block) => `${block.fileName}:${block.id}`).slice(0, 6).join(', ')
      : `${openDispatchBlocks.length} offene Dispatch-Blöcke sauber`,
  );
}

function verifyLegacyPostRedirectsTargetV2() {
  const routeFiles = [
    path.join(root, 'app/api/intake/route.ts'),
    path.join(root, 'app/api/telegram/route.ts'),
  ];
  const legacyRedirects = routeFiles.filter((filePath) => {
    if (!fs.existsSync(filePath)) return false;
    return /new URL\(`?\/\?tab=/.test(fs.readFileSync(filePath, 'utf8'));
  });

  requireCondition(
    legacyRedirects.length === 0,
    'legacy post-redirects springen auf control-plane-v2',
    legacyRedirects.length ? legacyRedirects.map((filePath) => path.relative(root, filePath)).join(', ') : 'keine /?tab Rueckspruenge',
  );
}

function verifyLegacyLocalPreviewUrlsTargetV2() {
  const files = [
    path.join(root, 'lib/services/operatorGoStateService.ts'),
  ];
  const legacyPreviewUrls = files.filter((filePath) => {
    if (!fs.existsSync(filePath)) return false;
    const source = fs.readFileSync(filePath, 'utf8');
    return /127\.0\.0\.1:4107\/\?tab=|localhost:4107\/\?tab=|['"`]\/\?tab=/.test(source);
  });

  requireCondition(
    legacyPreviewUrls.length === 0,
    'lokale preview-links springen auf control-plane-v2',
    legacyPreviewUrls.length
      ? legacyPreviewUrls.map((filePath) => path.relative(root, filePath)).join(', ')
      : 'keine alten /?tab Preview-Links',
  );
}

async function main() {
  await verifyHealth();
  await verifyControlPlaneData();
  await verifyAutomationControlSurface();
  await verifyFlightPackOperatorContract();
  await verifyHtmlSurfaces();
  await verifyViviModelCatalog();
  await verifyViviChat({ runMutatingSmoke: mutating });
  await verifyVegaChat({ runMutatingSmoke: mutating });
  await verifyDispatchValidation();
  verifyLocalRunnerStatus();
  await verifyV2NightModeContinuity();
  await verifyAutonomyOperatorSurface();
  verifyViviTransitionHygiene();
  verifyControlPlaneDispatchLaneMetadata();
  verifyLegacyPostRedirectsTargetV2();
  verifyLegacyLocalPreviewUrlsTargetV2();

  const summary = {
    ok: failures.length === 0,
    baseUrl,
    mutating,
    checks: checks.length,
    failures,
    warnings,
  };

  console.log(JSON.stringify(summary, null, 2));

  if (failures.length > 0) {
    process.exit(1);
  }
}

main().catch((error) => {
  console.error(error instanceof Error ? error.stack || error.message : error);
  process.exit(1);
});
