#!/usr/bin/env node

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const appRoot = path.resolve(scriptDir, '..');
const lioncomRoot = path.resolve(appRoot, '..');
const gateScript = path.join(lioncomRoot, 'scripts/vivi_report_quality_gate.py');
const failures = [];
const checks = [];

function record(name, ok, detail) {
  checks.push({ name, ok, detail });
  if (!ok) failures.push({ name, detail });
}

function writeJson(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
}

function writeWorkspace(workspaceRoot, reportBlock, options = {}) {
  fs.mkdirSync(workspaceRoot, { recursive: true });
  writeJson(path.join(workspaceRoot, '.runtime/local-duo-loop-status.json'), {
    effectiveProvider: 'lmstudio',
    effectiveModel: 'qwen3.5-vivi:9b',
  });
  writeJson(path.join(workspaceRoot, '.runtime/vivi-model-route-status.json'), {
    ok: true,
    effective: {
      provider: 'lmstudio',
      model: 'qwen3.5-vivi:9b',
    },
  });
  fs.writeFileSync(path.join(workspaceRoot, 'VIVI_REPORT_QUALITY.md'), options.qualityText || '', 'utf8');
  fs.writeFileSync(path.join(workspaceRoot, 'VIVI_REPORTS.md'), `${reportBlock.trim()}\n`, 'utf8');
  fs.writeFileSync(path.join(workspaceRoot, 'VIVI_COMMAND_QUEUE.md'), [
    '# Vivi Command Queue',
    '',
    `### ${options.commandRef}`,
    `- Title: ${options.title}`,
    '- Project Lane: lioncom-core',
    '- Status: claimed',
    '',
  ].join('\n'), 'utf8');
}

function runGate(workspaceRoot, claimId, commandRef, title) {
  const result = spawnSync('python3', [
    gateScript,
    '--workspace-root', workspaceRoot,
    '--claim-id', claimId,
    '--command-ref', commandRef,
    '--title', title,
  ], {
    cwd: lioncomRoot,
    encoding: 'utf8',
    maxBuffer: 1024 * 1024,
  });
  const statusPath = path.join(workspaceRoot, '.runtime/vivi-report-quality-gate-status.json');
  const status = fs.existsSync(statusPath)
    ? JSON.parse(fs.readFileSync(statusPath, 'utf8'))
    : null;
  return {
    exitCode: result.status,
    stdout: result.stdout,
    stderr: result.stderr,
    status,
  };
}

function reportFixture({ claimId, commandRef, title, body, modelVerification = 'fresh route probe matches effective local provider/model' }) {
  return `
## REPORT — ${title}
- Claim: ${claimId}
- Command Ref: ${commandRef}
- State: REPORT
- Project Lane: lioncom-core
- Model Verification: ${modelVerification}
- Source Gate: not_applicable
- Summary: ${body}
- Evidence: /api/health healthy, local_route_bridge verified, control plane inspected.
- Next Safe Local Action: Verify the next bounded LIONCOM rail and continue with concrete evidence.
`;
}

function runFixture(name, fixture, expectation) {
  const workspaceRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'lioncom-vqg-contract-'));
  writeWorkspace(workspaceRoot, fixture.report, {
    commandRef: fixture.commandRef,
    title: fixture.title,
    qualityText: fixture.qualityText,
  });
  const result = runGate(workspaceRoot, fixture.claimId, fixture.commandRef, fixture.title);
  const failureIds = (result.status?.failures || []).map((failure) => failure.id);
  const okMatches = expectation.ok ? result.exitCode === 0 && result.status?.ok === true : result.exitCode !== 0 && result.status?.ok === false;
  const requiredFailuresMatch = (expectation.failureIds || []).every((id) => failureIds.includes(id));
  record(name, okMatches && requiredFailuresMatch, JSON.stringify({
    exitCode: result.exitCode,
    ok: result.status?.ok,
    failureIds,
    stderr: result.stderr.trim().slice(0, 300),
  }));
}

const goodClaim = 'VIVI-CLAIM-CONTRACT-GOOD';
const goodRef = 'LIONCOM-NIGHT-20260515-VQG-CONTRACT-GOOD';
const goodTitle = 'VQG Contract Good Report';

runFixture('guter LIONCOM-Report besteht', {
  claimId: goodClaim,
  commandRef: goodRef,
  title: goodTitle,
  report: reportFixture({
    claimId: goodClaim,
    commandRef: goodRef,
    title: goodTitle,
    body: 'Concrete LIONCOM work completed with current runtime evidence and an actionable next task.',
  }),
}, { ok: true });

const idleClaim = 'VIVI-CLAIM-CONTRACT-IDLE';
const idleRef = 'LIONCOM-NIGHT-20260515-VQG-CONTRACT-IDLE';
const idleTitle = 'VQG Contract Idle Phrase';

runFixture('await-input/claim-active Abschluss wird blockiert', {
  claimId: idleClaim,
  commandRef: idleRef,
  title: idleTitle,
  report: reportFixture({
    claimId: idleClaim,
    commandRef: idleRef,
    title: idleTitle,
    body: 'Work is stable. Existing claim remains active and awaiting new operator input.',
  }),
}, { ok: false, failureIds: ['idle_language_without_closure_evidence'] });

const closureClaim = 'VIVI-CLAIM-CONTRACT-CLOSURE';
const closureRef = 'LIONCOM-NIGHT-20260515-VQG-CONTRACT-CLOSURE';
const closureTitle = 'VQG Contract Closure Evidence';

runFixture('echte no_safe_useful_work_remaining Closure darf passieren', {
  claimId: closureClaim,
  commandRef: closureRef,
  title: closureTitle,
  report: reportFixture({
    claimId: closureClaim,
    commandRef: closureRef,
    title: closureTitle,
    body: 'no_safe_useful_work_remaining after current rails, release gate, live runtime and backlog were verified; claim remains active only until runner completion closes it.',
  }),
}, { ok: true });

const modelClaim = 'VIVI-CLAIM-CONTRACT-MODEL';
const modelRef = 'LIONCOM-NIGHT-20260515-VQG-CONTRACT-MODEL';
const modelTitle = 'VQG Contract Model Truth';

runFixture('stale requested Modellwahrheit wird blockiert', {
  claimId: modelClaim,
  commandRef: modelRef,
  title: modelTitle,
  report: reportFixture({
    claimId: modelClaim,
    commandRef: modelRef,
    title: modelTitle,
    modelVerification: 'requested model only; needs_vega_review',
    body: 'Control plane checked, but model truth was downgraded to requested despite a fresh route probe.',
  }),
}, { ok: false, failureIds: ['stale_model_truth_after_route_probe'] });

const sourceHeadingClaim = 'VIVI-CLAIM-CONTRACT-SOURCE-HEADING';
const sourceHeadingRef = 'DISPATCH-20260520-SOURCE-HEADING';
const sourceHeadingTitle = 'VQG Contract Source Heading Only';

runFixture('Source-Gate nur als Heading wird blockiert', {
  claimId: sourceHeadingClaim,
  commandRef: sourceHeadingRef,
  title: sourceHeadingTitle,
  report: `
## REPORT — ${sourceHeadingTitle}
- Claim: ${sourceHeadingClaim}
- Command Ref: ${sourceHeadingRef}
- State: REPORT
- Project Lane: lioncom-core
- Model Verification: fresh route probe matches effective local provider/model
- Summary: External source-heavy skill research was attempted.

### Source Gate
- source_not_verified for external URLs.
`,
}, { ok: false, failureIds: ['missing_source_gate'] });

const sourceFieldClaim = 'VIVI-CLAIM-CONTRACT-SOURCE-FIELD';
const sourceFieldRef = 'DISPATCH-20260520-SOURCE-FIELD';
const sourceFieldTitle = 'VQG Contract Source Field';

runFixture('Source-heavy Report mit Source-Gate-Feld besteht', {
  claimId: sourceFieldClaim,
  commandRef: sourceFieldRef,
  title: sourceFieldTitle,
  report: `
## REPORT — ${sourceFieldTitle}
- Claim: ${sourceFieldClaim}
- Command Ref: ${sourceFieldRef}
- State: REPORT
- Project Lane: lioncom-core
- Model Verification: fresh route probe matches effective local provider/model
- Source Gate: source_not_verified for all external URLs; operator_review_required before installation.
- Summary: External skill research stayed bounded because sources could not be verified.
- Next Safe Local Action: Route source verification to Vega before any install.
`,
}, { ok: true });

const rawBridgeClaim = 'VIVI-CLAIM-CONTRACT-RAW-BRIDGE';
const rawBridgeRef = 'LIONCOM-NIGHT-20260520-RAW-BRIDGE';
const rawBridgeTitle = 'VQG Contract Raw Bridge Separation';

runFixture('Raw HTTP rot mit Bridge-Separation besteht', {
  claimId: rawBridgeClaim,
  commandRef: rawBridgeRef,
  title: rawBridgeTitle,
  report: `
## REPORT — ${rawBridgeTitle}
- Claim: ${rawBridgeClaim}
- Command Ref: ${rawBridgeRef}
- State: REPORT
- Project Lane: lioncom-core
- Model Verification: fresh route probe matches effective local provider/model
- Source Gate: not_applicable
- Summary: /api/health healthy through the effective control-plane path; raw HTTP 4107/3007 connection refused is non-leading.
- Evidence: local_route_bridge verified ok; raw_http_probe: not leading because effective_transport is local_route_bridge.
- Next Safe Local Action: Keep using the bridge-backed control-plane verifier and avoid raw HTTP as leading health truth.
`,
}, { ok: true });

const rawConflictClaim = 'VIVI-CLAIM-CONTRACT-RAW-CONFLICT';
const rawConflictRef = 'LIONCOM-NIGHT-20260520-RAW-CONFLICT';
const rawConflictTitle = 'VQG Contract Raw Conflict';

runFixture('Raw HTTP rot ohne Bridge-Separation wird blockiert', {
  claimId: rawConflictClaim,
  commandRef: rawConflictRef,
  title: rawConflictTitle,
  report: `
## REPORT — ${rawConflictTitle}
- Claim: ${rawConflictClaim}
- Command Ref: ${rawConflictRef}
- State: REPORT
- Project Lane: lioncom-core
- Model Verification: fresh route probe matches effective local provider/model
- Source Gate: not_applicable
- Summary: /api/health healthy. Raw HTTP 4107 unreachable.
- Evidence: Control plane inspected.
- Next Safe Local Action: Re-run the control-plane health check.
`,
}, { ok: false, failureIds: ['contradictory_raw_http_truth'] });

const result = {
  ok: failures.length === 0,
  checkedAt: new Date().toISOString(),
  checks,
  failures,
};

console.log(JSON.stringify(result, null, 2));
if (failures.length > 0) process.exit(1);
