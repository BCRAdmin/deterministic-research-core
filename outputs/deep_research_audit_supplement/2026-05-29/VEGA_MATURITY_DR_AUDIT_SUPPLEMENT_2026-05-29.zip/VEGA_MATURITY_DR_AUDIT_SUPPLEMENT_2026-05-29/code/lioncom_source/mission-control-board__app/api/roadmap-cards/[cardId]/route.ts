import { NextRequest, NextResponse } from 'next/server';

import {
  isRoadmapCardNotFoundError,
  isRoadmapCardValidationError,
  updateRoadmapCard,
} from '@/lib/services/roadmapCardService';
import type { RoadmapCardUpdateInput } from '@/lib/types/roadmap-cards';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function PATCH(
  request: NextRequest,
  context: { params: Promise<{ cardId: string }> },
) {
  let payload: RoadmapCardUpdateInput;

  try {
    payload = await request.json() as RoadmapCardUpdateInput;
  } catch {
    return NextResponse.json({ error: 'Ungültiger Roadmap-Karten-Payload.' }, { status: 400 });
  }

  try {
    const { cardId } = await context.params;
    const result = await updateRoadmapCard(decodeURIComponent(cardId), payload);
    return NextResponse.json({ ok: true, ...result }, {
      headers: {
        'Cache-Control': 'no-store',
      },
    });
  } catch (error) {
    if (isRoadmapCardNotFoundError(error)) {
      return NextResponse.json({ error: error.message }, { status: 404 });
    }
    if (isRoadmapCardValidationError(error)) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    return NextResponse.json({ error: 'Roadmap-Karte konnte nicht aktualisiert werden.' }, { status: 500 });
  }
}
