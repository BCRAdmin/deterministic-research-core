import type { MetadataRoute } from 'next';

function getSiteUrl() {
  return (
    process.env.QUELLWERT_SITE_URL ||
    process.env.NEXT_PUBLIC_SITE_URL ||
    'http://127.0.0.1:4107'
  ).replace(/\/+$/, '');
}

export default function robots(): MetadataRoute.Robots {
  const siteUrl = getSiteUrl();
  const publicIndexingEnabled = process.env.QUELLWERT_PUBLIC_INDEXING === 'true';

  if (!publicIndexingEnabled) {
    return {
      rules: {
        userAgent: '*',
        disallow: '/',
      },
      sitemap: `${siteUrl}/sitemap.xml`,
    };
  }

  return {
    rules: {
      userAgent: '*',
      allow: [
        '/membership',
        '/membership/analysen',
        '/membership/methodik',
        '/membership/archiv',
        '/membership/impressum',
        '/membership/datenschutz',
        '/membership/kontakt',
      ],
      disallow: ['/api/', '/control-plane-v2', '/mockups'],
    },
    sitemap: `${siteUrl}/sitemap.xml`,
  };
}
