import { NextRequest, NextResponse } from 'next/server';

import {
  createRoadmapCard,
  getRoadmapCardsSnapshot,
  isRoadmapCardValidationError,
} from '@/lib/services/roadmapCardService';
import type { RoadmapCardCreateInput } from '@/lib/types/roadmap-cards';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function GET() {
  try {
    return NextResponse.json(await getRoadmapCardsSnapshot(), {
      headers: {
        'Cache-Control': 'no-store',
      },
    });
  } catch {
    return NextResponse.json({ error: 'Roadmap-Karten konnten nicht geladen werden.' }, { status: 503 });
  }
}

export async function POST(request: NextRequest) {
  let payload: RoadmapCardCreateInput;

  try {
    payload = await request.json() as RoadmapCardCreateInput;
  } catch {
    return NextResponse.json({ error: 'Ungültiger Roadmap-Karten-Payload.' }, { status: 400 });
  }

  try {
    const result = await createRoadmapCard(payload);
    return NextResponse.json({ ok: true, ...result }, {
      headers: {
        'Cache-Control': 'no-store',
      },
    });
  } catch (error) {
    if (isRoadmapCardValidationError(error)) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    return NextResponse.json({ error: 'Roadmap-Karte konnte nicht angelegt werden.' }, { status: 500 });
  }
}
