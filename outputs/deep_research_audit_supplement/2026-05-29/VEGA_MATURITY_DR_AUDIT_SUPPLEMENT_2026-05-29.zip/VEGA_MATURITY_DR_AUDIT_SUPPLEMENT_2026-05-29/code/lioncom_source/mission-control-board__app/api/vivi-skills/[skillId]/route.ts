import { NextResponse } from 'next/server';

import { getViviSkill } from '@/lib/vivi-skills/registry';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function GET(_request: Request, context: { params: Promise<{ skillId: string }> }) {
  try {
    const { skillId } = await context.params;
    const skill = await getViviSkill(decodeURIComponent(skillId));
    if (!skill) {
      return NextResponse.json({ error: 'Vivi-Skill nicht gefunden.' }, { status: 404 });
    }
    return NextResponse.json(skill);
  } catch {
    return NextResponse.json({ error: 'Vivi-Skill konnte nicht geladen werden.' }, { status: 503 });
  }
}
