import { QuellwertPaperHeader } from '@/components/quellwert/quellwert-paper-header';
import { QuellwertPaperFooter } from '@/components/quellwert/quellwert-paper-footer';
import { getFeaturedAnalysis, getPublicAnalyses } from '@/lib/quellwert/analysisCatalog';
import type { Metadata } from 'next';

const checks = [
  {
    title: 'Public-Catalog-Contract',
    text: 'Prüft, dass nur Public-Preview-Kandidaten geroutet sind und dass verbotene Verkaufs-, Produktzugangs- oder Handlungssprache auf Public-Seiten nicht vorkommt.',
    command: 'npm run verify:quellwert-public-catalog-contract',
  },
  {
    title: 'Quellwert-Preview-Verifier',
    text: 'Validiert lokale Assets, Gate-Summarys, Routing-Status (inkl. 404 für zurückgestellte Kandidaten) und Copy-Guardrails für die Quellwert-Surface.',
    command: 'LIONCOM_BASE_URL=http://127.0.0.1:4107 npm run verify:quellwert-membership-preview',
  },
  {
    title: 'Launch-Readiness ohne Credentials',
    text: 'Öffnet nur die lokale Readiness-Prüfung. Provider, Mail, Stripe, Zahlungsfluss, externe Sends, Public und Production bleiben geschlossen.',
    command: 'node scripts/verify_operator_readiness_pass.cjs',
  },
  {
    title: 'Visual-Polish-Check',
    text: 'Erzeugt Desktop- und Mobile-Screenshots, prüft Überlauf, Stack-Geometrie, Footer-Sichtbarkeit und mobile Archivkarten.',
    command: 'npm run verify:quellwert-visual-polish',
  },
];

const operatorRunbook = [
  {
    title: 'Build',
    text: 'Baut die Next-App, damit Routing und Assets in einem reproduzierbaren Zustand sind.',
    command: 'npm run build',
  },
  {
    title: 'Desktop Sync (Live)',
    text: 'Synchronisiert die Preview in den lokalen Runtime-Workspace (nur lokale Dateioperation; kein Deploy).',
    command: 'npm run desktop:sync-live',
  },
  {
    title: 'Control Plane Restart',
    text: 'Startet die lokale Control Plane neu. In eingeschränkten Sandbox-Kontexten kann dieser Schritt mit EPERM blockiert sein.',
    command: 'launchctl kickstart -k gui/$(id -u)/com.lioncom.local-control-plane',
  },
  {
    title: 'Preview Verifier',
    text: 'Prüft Assets, Routing und Copy-Guardrails gegen die lokale Base-URL.',
    command: 'LIONCOM_BASE_URL=http://127.0.0.1:4107 npm run verify:quellwert-membership-preview',
  },
];

const browserQaRoutes = [
  { label: 'Start', href: '/membership' },
  { label: 'Analysen', href: '/membership/analysen' },
  { label: 'Archiv', href: '/membership/archiv' },
  { label: 'Methodik', href: '/membership/methodik' },
  { label: 'Verifier', href: '/membership/verifier' },
  { label: 'Impressum', href: '/membership/impressum' },
  { label: 'Datenschutz', href: '/membership/datenschutz' },
  { label: 'Kontakt', href: '/membership/kontakt' },
];

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export const metadata: Metadata = {
  title: 'Verifier | Quellwert',
  description:
    'Dokumentiert lokale Checks für Routing, Copy-Guardrails, Gate-Konsistenz, Assets und Screenshot-Artefakte. Transparenz- und QA-Instrument, keine externe Veröffentlichung.',
};

export default function QuellwertVerifierPage() {
  const featured = getFeaturedAnalysis();
  const publicAnalyses = getPublicAnalyses();
  const publicDetailRoutes = [featured, ...publicAnalyses]
    .filter(Boolean)
    .reduce<typeof publicAnalyses>((acc, analysis) => {
      if (!acc.find((item) => item.slug === analysis.slug)) acc.push(analysis);
      return acc;
    }, [])
    .slice(0, 3)
    .map((analysis) => ({
      label: `Analyse: ${analysis.shortName} (${analysis.ticker})`,
      href: `/membership/analysen/${analysis.slug}`,
    }));

  return (
    <main className="qw-page qwp-page" id="qwp-main" tabIndex={-1} lang="de">
      <QuellwertPaperHeader current="verifier" />
      <div id="qwp-content" tabIndex={-1} role="region" aria-label="Inhalt">
        <section className="qwp-hero qwp-narrow">
          <p className="qwp-kicker">Verifier</p>
          <h1>Was Quellwert lokal prüft.</h1>
          <p>
            Diese Seite dokumentiert die lokalen Checks, die die Research-Surface absichern:
            Routing, Copy-Guardrails, Gate-Konsistenz, Assets und Screenshot-Artefakte.
            Sie ist ein Transparenz- und QA-Instrument, keine externe Veröffentlichung.
          </p>
        </section>

        <section className="qwp-narrow" aria-label="Schnellzugriff">
          <nav className="qwp-toc" aria-labelledby="qwp-quick-title">
            <p className="qwp-kicker" id="qwp-quick-title">
              Schnellzugriff
            </p>
            <ul>
              <li>
                <a href="/membership">Start</a>
              </li>
              <li>
                <a href="/membership/analysen">Analysen</a>
              </li>
              <li>
                <a href="/membership/methodik">Methodik</a>
              </li>
              <li>
                <a href="/membership/archiv">Archiv</a>
              </li>
              <li>
                <a aria-current="page" href="/membership/verifier">
                  Verifier
                </a>
              </li>
            </ul>
          </nav>
        </section>

        <section className="qwp-method-grid" aria-label="Quellwert Verifier Checks">
          {checks.map((check, index) => (
            <article key={check.title}>
              <span>{String(index + 1).padStart(2, '0')}</span>
              <h2>{check.title}</h2>
              <p>{check.text}</p>
              <p>
                <strong>Command:</strong> <code>{check.command}</code>
              </p>
            </article>
          ))}
        </section>

        <section className="qwp-method-grid" aria-label="Operator Runbook">
          {operatorRunbook.map((step, index) => (
            <article key={step.title}>
              <span>{String(index + 1).padStart(2, '0')}</span>
              <h2>{step.title}</h2>
              <p>{step.text}</p>
              <p>
                <strong>Command:</strong> <code>{step.command}</code>
              </p>
            </article>
          ))}
        </section>

        <section className="qwp-disclaimer qwp-narrow" aria-label="Browser QA">
          <h2>Browser QA (Desktop & Mobile)</h2>
          <p>
            Zusätzlich zu den Verifier-Checks braucht die lokale Preview eine kurze Sichtprüfung
            in Desktop und Mobile (Navigation, Überläufe, Link-Ziele, Lesbarkeit). Diese Liste ist
            bewusst klein und bleibt auf die Public-Research-Surface begrenzt.
          </p>
          <ul className="qwp-check-list" aria-label="QA Routen">
            {browserQaRoutes.map((route) => (
              <li key={route.href}>
                <a className="qwp-link" href={route.href}>
                  {route.label}
                </a>
              </li>
            ))}
          </ul>
          <h3>Beispiel-Detailseiten</h3>
          {publicDetailRoutes.length > 0 ? (
            <ul className="qwp-check-list" aria-label="QA Detailseiten">
              {publicDetailRoutes.map((route) => (
                <li key={route.href}>
                  <a
                    className="qwp-link"
                    href={route.href}
                    aria-label={`Detailseite öffnen: ${route.label}`}
                  >
                    {route.label}
                  </a>
                </li>
              ))}
            </ul>
          ) : (
            <p>
              Aktuell sind keine Public-Detailseiten im Katalog geroutet. Wenn das unerwartet ist,
              zuerst den Public-Catalog-Contract und den Preview-Verifier prüfen.
            </p>
          )}
        </section>

        <section className="qwp-disclaimer qwp-narrow" aria-label="Hinweis">
          <h2>Wichtiger Hinweis</h2>
          <p>
            Die Verifier-Checks helfen, lokale Public-Preview-Entwürfe sauber zu halten. Ein grüner
            Check ist kein Operator-Go für externe Publikation. Quellwert bleibt keine Anlageberatung,
            keine persönliche Empfehlung und keine Aufforderung zu einer Transaktion.
          </p>
        </section>

        <QuellwertPaperFooter />
      </div>
    </main>
  );
}
