import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function POST(request: NextRequest) {
  let payload: Record<string, unknown>;
  try {
    payload = await request.json() as Record<string, unknown>;
  } catch {
    return NextResponse.json({ error: 'Ungültige JSON-Daten.' }, { status: 400 });
  }

  const response = await fetch(new URL('/api/vivi-chat', request.url), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      ...payload,
      action: 'archive-session',
    }),
  });

  return NextResponse.json(await response.json(), { status: response.status });
}
