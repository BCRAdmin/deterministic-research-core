// Tasks API - Liefert Task-Queue
// Read-only, keine Secrets

import { parseTaskQueue } from '@/lib/parsers/taskQueueParser';
import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const tasks = await parseTaskQueue();
    return NextResponse.json(tasks);
  } catch {
    return NextResponse.json(
      { error: 'Tasks nicht verfügbar' },
      { status: 503 }
    );
  }
}
