import { NextRequest, NextResponse } from 'next/server';

import {
  getOperatorGoSnapshot,
  requestOperatorGoChanges,
  resetOperatorGoItem,
  scheduleOperatorGoItem,
  saveOperatorGoNote,
  setOperatorGoApproval,
} from '@/lib/services/operatorGoStateService';

export const dynamic = 'force-dynamic';

interface OperatorGoPayload {
  action?: 'approve' | 'request_changes' | 'save_note' | 'reset' | 'schedule';
  itemId?: string;
  note?: string;
  scheduledFor?: string;
}

export async function GET() {
  try {
    return NextResponse.json(await getOperatorGoSnapshot());
  } catch {
    return NextResponse.json({ error: 'Operator Go Inbox unavailable' }, { status: 503 });
  }
}

export async function POST(request: NextRequest) {
  let payload: OperatorGoPayload;
  try {
    payload = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload' }, { status: 400 });
  }

  if (!payload.itemId?.trim()) {
    return NextResponse.json({ error: 'Missing itemId' }, { status: 400 });
  }

  try {
    if (payload.action === 'approve') {
      return NextResponse.json({ ok: true, snapshot: await setOperatorGoApproval(payload.itemId) });
    }

    if (payload.action === 'request_changes') {
      return NextResponse.json({ ok: true, snapshot: await requestOperatorGoChanges(payload.itemId, payload.note) });
    }

    if (payload.action === 'save_note') {
      return NextResponse.json({ ok: true, snapshot: await saveOperatorGoNote(payload.itemId, payload.note ?? '') });
    }

    if (payload.action === 'reset') {
      return NextResponse.json({ ok: true, snapshot: await resetOperatorGoItem(payload.itemId) });
    }

    if (payload.action === 'schedule') {
      if (!payload.scheduledFor?.trim()) {
        return NextResponse.json({ error: 'Missing scheduledFor' }, { status: 400 });
      }
      return NextResponse.json({ ok: true, snapshot: await scheduleOperatorGoItem(payload.itemId, payload.scheduledFor) });
    }

    return NextResponse.json({ error: 'Unsupported action' }, { status: 400 });
  } catch {
    return NextResponse.json({ error: 'Failed to update operator go item' }, { status: 500 });
  }
}
