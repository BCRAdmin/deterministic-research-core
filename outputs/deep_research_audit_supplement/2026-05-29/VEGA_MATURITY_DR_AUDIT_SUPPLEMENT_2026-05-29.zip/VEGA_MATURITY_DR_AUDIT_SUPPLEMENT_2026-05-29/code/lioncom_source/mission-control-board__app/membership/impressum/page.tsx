import { QuellwertPaperFooter } from '@/components/quellwert/quellwert-paper-footer';
import { QuellwertPaperHeader } from '@/components/quellwert/quellwert-paper-header';
import { QuellwertLegalSubnav } from '@/components/quellwert/quellwert-legal-subnav';
import type { Metadata } from 'next';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export const metadata: Metadata = {
  title: 'Impressum | Quellwert (Preview)',
  description:
    'Lokale Quellwert-Preview: Betreiberangaben bleiben Operator-Gate vor externer Veröffentlichung.',
};

export default function QuellwertImpressumPage() {
  return (
    <main className="qw-page qwp-page" id="qwp-main" tabIndex={-1} lang="de">
      <QuellwertPaperHeader />
      <div id="qwp-content" tabIndex={-1} role="region" aria-label="Inhalt">
        <section className="qwp-hero qwp-narrow">
          <p className="qwp-kicker">Impressum</p>
          <h1>Betreiberangaben vor externer Veröffentlichung.</h1>
          <p>
            Diese lokale Quellwert-Preview enthält noch keine final freigegebenen
            Betreiberangaben. Vor einer externen Veröffentlichung werden Impressum,
            Datenschutz und Kontaktweg durch den Operator geprüft und final gesetzt.
          </p>
          <QuellwertLegalSubnav current="impressum" />
        </section>

        <section className="qwp-disclaimer qwp-narrow" aria-label="Operator-Gate">
          <h2>Operator-Gate</h2>
          <p>
            Diese Route ist bewusst erreichbar, aber nicht als rechtlich finale Angabe
            markiert. Sie verhindert tote Footerlinks in der lokalen Preview und hält
            die finale Freigabe sichtbar getrennt.
          </p>
        </section>

        <QuellwertPaperFooter />
      </div>
    </main>
  );
}
