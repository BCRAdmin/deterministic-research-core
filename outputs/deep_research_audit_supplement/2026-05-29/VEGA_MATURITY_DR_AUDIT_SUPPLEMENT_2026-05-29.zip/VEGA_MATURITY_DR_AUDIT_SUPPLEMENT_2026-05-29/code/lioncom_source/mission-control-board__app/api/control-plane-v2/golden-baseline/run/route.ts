import { spawn } from 'node:child_process';
import path from 'node:path';

import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

interface GoldenBaselineRunPayload {
  mode?: 'due' | 'fast' | 'local' | 'full';
  force?: boolean;
}

export async function POST(request: NextRequest) {
  let payload: GoldenBaselineRunPayload = {};
  try {
    payload = await request.json() as GoldenBaselineRunPayload;
  } catch {
    payload = {};
  }

  const mode = payload.mode || 'due';
  const args = [path.join(process.cwd(), 'scripts', 'run_golden_baseline_due.mjs')];
  if (payload.force) args.push('--force');
  if (mode === 'fast') args.push('--fast');
  if (mode === 'local') args.push('--skip-network');

  try {
    const child = spawn(process.execPath, args, {
      cwd: process.cwd(),
      detached: true,
      stdio: 'ignore',
      env: process.env,
    });
    child.unref();
    return NextResponse.json({
      ok: true,
      action: 'started',
      mode,
      force: Boolean(payload.force),
      pid: child.pid,
    }, { status: 202 });
  } catch {
    return NextResponse.json({ error: 'Golden Baseline konnte nicht gestartet werden.' }, { status: 500 });
  }
}
