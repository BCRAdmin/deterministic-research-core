import { AppShell } from '@/components/app-shell';
import { loadControlPlaneV2Data } from '@/lib/control-plane-v2/live-data';

export const dynamic = 'force-dynamic';

export default async function ControlPlaneV2Page() {
  const initialLiveData = await loadControlPlaneV2Data();

  return <AppShell initialLiveData={initialLiveData} />;
}
