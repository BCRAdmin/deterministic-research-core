import { notFound } from 'next/navigation';
import {
  getAnalysisGateSummary,
  getAdjacentPublicAnalyses,
  getPublicAnalyses,
  getPublicAnalysisBySlug,
} from '@/lib/quellwert/analysisCatalog';
import { QuellwertPaperFooter } from '@/components/quellwert/quellwert-paper-footer';
import { QuellwertPaperHeader } from '@/components/quellwert/quellwert-paper-header';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

type EvidenceSource = {
  label: string;
  sourceId: string;
  sourceType: string;
  href?: string;
};

function toDomId(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

function getArtifactDescription(filename: string) {
  switch (filename) {
    case 'publish_report.md':
      return 'Lesbarer Quellwert-Entwurf (lokal).';
    case 'publish_report_quality_score.json':
      return 'Maschinenlesbarer Qualitäts-Score für den Entwurf.';
    case 'report_manifest.json':
      return 'Manifest des Research-Agent-Laufs (Inputs/Outputs/Versionen).';
    case 'source_registry.json':
      return 'Quellenregister inkl. Evidence-IDs und Registry-Delta-Hinweisen.';
    case 'evidence_ledger.json':
      return 'Evidence-Ledger (Claim → Evidence) für harte Zahlen/Claims.';
    case 'reconciliation_report.md':
      return 'Reconciliation-Report (Perioden/Units/Restatements/Source-Konflikte).';
    case 'canonical_financials.json':
      return 'Kanonische Finanzdaten nach Reconciliation (lokal).';
    default:
      return 'Lokales Artefakt im Public-Preview-Paket.';
  }
}

function getEvidenceCategory(sourceType: string) {
  switch (sourceType) {
    case 'earnings_release':
      return 'primary';
    case 'sec_filing':
      return 'sec';
    case 'research_agent_bundle':
      return 'bundle';
    default:
      return 'other';
  }
}

function getEvidenceCategoryMeta(category: ReturnType<typeof getEvidenceCategory>) {
  switch (category) {
    case 'primary':
      return {
        kicker: 'Primärquelle',
        description: 'Offizielle IR- oder Earnings-Quelle als Anker für zentrale Claims.',
      };
    case 'sec':
      return {
        kicker: 'SEC-Daten',
        description: 'Maschinenlesbare XBRL-/CompanyFacts-Daten als Reconciliation-Basis.',
      };
    case 'bundle':
      return {
        kicker: 'Lokales Evidence-Paket',
        description: 'Interne Artefakte aus dem Research-Agent-Batch; bewusst nicht extern verlinkt.',
      };
    default:
      return {
        kicker: 'Weitere Evidence',
        description: 'Zusätzliche Quellen oder Artefakte im selben Transparenzrahmen.',
      };
  }
}

function getEvidenceSourceTypeLabel(sourceType: string) {
  switch (sourceType) {
    case 'earnings_release':
      return 'Earnings Release';
    case 'sec_filing':
      return 'SEC Filing';
    case 'research_agent_bundle':
      return 'Bundle-Artefakt';
    default:
      return 'Evidence';
  }
}

type PageProps = {
  params: Promise<{
    slug: string;
  }>;
};

export function generateStaticParams() {
  return getPublicAnalyses().map((analysis) => ({ slug: analysis.slug }));
}

export async function generateMetadata({ params }: PageProps) {
  const { slug } = await params;
  const analysis = getPublicAnalysisBySlug(slug);

  if (!analysis) {
    return {
      title: 'Analyse | Quellwert',
      description:
        'Öffentliche Quellwert-Analyse als lokale Preview. Quellenbasiert und ohne Handlungsanweisung.',
    };
  }

  return {
    title: `${analysis.shortName} | Quellwert`,
    description: analysis.subtitle,
  };
}

export default async function QuellwertAnalysisDetailPage({ params }: PageProps) {
  const { slug } = await params;
  const analysis = getPublicAnalysisBySlug(slug);

  if (!analysis) {
    notFound();
  }

  const adjacent = getAdjacentPublicAnalyses(analysis.slug);
  const gateSummary = getAnalysisGateSummary(analysis);
  const evidenceByCategory = analysis.evidence.reduce<Record<string, EvidenceSource[]>>(
    (acc, source) => {
      const category = getEvidenceCategory(source.sourceType);
      if (!acc[category]) acc[category] = [];
      acc[category].push(source);
      return acc;
    },
    {},
  );

  return (
    <main className="qw-page qwp-page qwp-article-page" id="qwp-main" tabIndex={-1} lang="de">
      <QuellwertPaperHeader current="analysen" />
      <div id="qwp-content" tabIndex={-1} role="region" aria-label="Inhalt">
        <article className="qwp-article">
          <header className="qwp-article-hero">
            <div className="qwp-article-back-row" aria-label="Seiten-Navigation">
              <a className="qwp-link qwp-article-back" href="/membership/analysen">
                <span aria-hidden="true">←</span> Zur Analysen-Übersicht
              </a>
              <a className="qwp-link qwp-article-back-secondary" href="/membership/archiv">
                Zum Archiv
              </a>
              <a className="qwp-link qwp-article-back-secondary" href="/membership/methodik">
                Zur Methodik
              </a>
            </div>
            <p className="qwp-kicker">{analysis.sector}</p>
            <h1>{analysis.title}</h1>
            <p>{analysis.subtitle}</p>
            <dl className="qwp-fact-strip" aria-label="Analyse-Metadaten">
              <div>
                <dt>Ticker</dt>
                <dd>{analysis.ticker}</dd>
              </div>
              <div>
                <dt>Stand</dt>
                <dd>{analysis.asOfDate}</dd>
              </div>
              <div>
                <dt>Qualität</dt>
                <dd>{analysis.qualityScore}/100</dd>
              </div>
              <div>
                <dt>Status</dt>
                <dd>{analysis.displayStatus}</dd>
              </div>
            </dl>
            <nav className="qwp-toc" aria-labelledby="qwp-toc-title">
              <p className="qwp-kicker" id="qwp-toc-title">
                Inhalt
              </p>
              <ul>
                <li>
                  <a href="#qwp-these">Quellwert-These</a>
                </li>
                <li>
                  <a href="#qwp-einordnung">Einordnung</a>
                </li>
                <li>
                  <a href="#qwp-kernzahlen">Kernzahlen</a>
                </li>
                <li>
                  <a href="#qwp-pruefpunkte">Prüfpunkte</a>
                </li>
                <li>
                  <a href="#qwp-risiken">Risiken</a>
                </li>
                <li>
                  <a href="#qwp-evidence">Quellen &amp; Evidence</a>
                </li>
                {analysis.localArtifacts.length > 0 ? (
                  <li>
                    <a href="#qwp-artefakte">Artefakte</a>
                  </li>
                ) : null}
                <li>
                  <a href="#qwp-gate">Gate-Status</a>
                </li>
                <li>
                  <a href="#qwp-hinweis">Hinweis</a>
                </li>
              </ul>
            </nav>
          </header>

        <section className="qwp-article-section" id="qwp-these" aria-labelledby="qwp-these-title">
          <h2 id="qwp-these-title">Quellwert-These</h2>
          <p>{analysis.thesis}</p>
        </section>

        <section
          className="qwp-article-section"
          id="qwp-einordnung"
          aria-labelledby="qwp-einordnung-title"
        >
          <h2 id="qwp-einordnung-title">Einordnung</h2>
          {(analysis.articleBody || []).map((paragraph) => (
            <p key={paragraph}>{paragraph}</p>
          ))}
        </section>

        <section
          className="qwp-article-section"
          id="qwp-kernzahlen"
          aria-labelledby="qwp-kernzahlen-title"
        >
          <h2 id="qwp-kernzahlen-title">Kernzahlen</h2>
          <ul className="qwp-check-list">
            {analysis.kpis.map((kpi) => (
              <li key={kpi}>{kpi}</li>
            ))}
          </ul>
        </section>

        <section
          className="qwp-article-section qwp-two-column"
          id="qwp-pruefpunkte"
          aria-labelledby="qwp-pruefpunkte-title"
        >
          <div>
            <h2 id="qwp-pruefpunkte-title">Prüfpunkte</h2>
            <ul className="qwp-check-list">
              {analysis.watchpoints.map((watchpoint) => (
                <li key={watchpoint}>{watchpoint}</li>
              ))}
            </ul>
          </div>
          <section
            className="qwp-anchor-target"
            id="qwp-risiken"
            aria-labelledby="qwp-risiken-title"
          >
            <h2 id="qwp-risiken-title">Risiken</h2>
            <ul className="qwp-check-list qwp-risk-list">
              {analysis.risks.map((risk) => (
                <li key={risk}>{risk}</li>
              ))}
            </ul>
          </section>
        </section>

        <section className="qwp-article-section" id="qwp-evidence" aria-labelledby="qwp-evidence-title">
          <h2 id="qwp-evidence-title">Quellen &amp; Evidence</h2>
          <p>
            Der Artikel ist ein lokaler Public-Preview-Entwurf aus dem Research-Agent-Batch{' '}
            <code>{analysis.sourceBatch}</code>. Er nutzt maschinenlesbare Artefakte,
            einen Quellenkatalog und ein separates Qualitätsprotokoll. Vor externer
            Veröffentlichung bleibt ein menschlicher Review Pflicht.
          </p>
          <div className="qwp-evidence-groups">
            {(['primary', 'sec', 'bundle', 'other'] as const)
              .filter((category) => (evidenceByCategory[category] || []).length > 0)
              .map((category) => {
                const meta = getEvidenceCategoryMeta(category);
                const sources = evidenceByCategory[category] || [];
                const groupTitleId = `qwp-evidence-group-${category}-title`;
                const groupDescId = `qwp-evidence-group-${category}-desc`;

                return (
                  <section
                    className="qwp-evidence-group"
                    aria-labelledby={groupTitleId}
                    aria-describedby={groupDescId}
                    key={category}
                  >
                    <header className="qwp-evidence-group-header">
                      <h3 className="qwp-kicker" id={groupTitleId}>
                        {meta.kicker}
                      </h3>
                      <p className="qwp-evidence-group-description" id={groupDescId}>
                        {meta.description}
                      </p>
                    </header>
                    <div className="qwp-evidence-list" role="list">
                      {sources.map((source) => {
                        const entryId = toDomId(`${category}-${source.sourceId}`);
                        const titleId = `qwp-evidence-${entryId}-title`;
                        const metaId = `qwp-evidence-${entryId}-meta`;

                        return (
                          <article
                            aria-describedby={metaId}
                            aria-labelledby={titleId}
                            key={source.sourceId}
                            role="listitem"
                          >
                            <span title={source.sourceType}>
                              {getEvidenceSourceTypeLabel(source.sourceType)}
                            </span>
                            <h4 id={titleId}>{source.label}</h4>
                            <p id={metaId}>
                              <code>{source.sourceId}</code>
                            </p>
                          {source.href ? (
                            <a
                              href={source.href}
                              rel="noopener noreferrer"
                              target="_blank"
                              aria-label={`Quelle öffnen: ${source.label}`}
                            >
                              Quelle öffnen <span aria-hidden="true">↗</span>
                            </a>
                          ) : (
                            <p className="qwp-evidence-note">Intern (nicht öffentlich verlinkt)</p>
                          )}
                          </article>
                        );
                      })}
                    </div>
                  </section>
                );
              })}
          </div>
        </section>

        {analysis.localArtifacts.length > 0 ? (
          <section
            className="qwp-article-section qwp-artifacts"
            id="qwp-artefakte"
            aria-labelledby="qwp-artefakte-title"
          >
            <h2 id="qwp-artefakte-title">Lokale Artefakte</h2>
            <p>
              Diese Dateien gehören zum lokalen Public-Preview-Paket des Artikels.
              Sie erhöhen die Nachvollziehbarkeit (Evidence/Registry/Reconciliation),
              sind aber nicht als externe Publikation zu verstehen.
            </p>
            <ul className="qwp-artifact-list" aria-label="Artefaktliste">
              {analysis.localArtifacts.map((artifact) => (
                <li key={artifact}>
                  <code>{artifact}</code>
                  <span>{getArtifactDescription(artifact)}</span>
                </li>
              ))}
            </ul>
          </section>
        ) : null}

        <section className="qwp-gate-panel" id="qwp-gate" aria-label="Public-Ready Gate">
          {analysis.gate ? (
            <>
              <div>
                <p className="qwp-kicker">Public-Ready Gate v1</p>
                <h2>{analysis.displayStatus}</h2>
                <p>
                  Primärquelle dokumentiert:{' '}
                  <a href={analysis.gate.officialSourceHref} rel="noopener noreferrer" target="_blank">
                    {analysis.gate.officialSourceLabel}
                  </a>
                  . Das Registry-Delta zwischen lokalem Bundle und IR-Release bleibt bis
                  zum finalen Operator-Go als Review offen sichtbar.
                </p>
              </div>
              <dl>
                <div>
                  <dt>Quellenprüfung</dt>
                  <dd>
                    {analysis.gate.sourceReview === 'pass'
                      ? 'Quellenprüfung bestätigt'
                      : 'Review offen'}
                  </dd>
                </div>
                <div>
                  <dt>Non-Advice</dt>
                  <dd>{analysis.gate.nonAdvice === 'pass' ? 'sichtbar abgegrenzt' : 'offen'}</dd>
                </div>
                <div>
                  <dt>Externe Veröffentlichung</dt>
                  <dd>
                    {analysis.gate.operatorGoRequired
                      ? 'Operator-Go erforderlich'
                      : 'Operator-Go dokumentiert'}
                  </dd>
                </div>
              </dl>
            </>
          ) : (
            <>
              <div>
                <p className="qwp-kicker">Public-Preview-Gate</p>
                <h2>{gateSummary.reviewLabel}</h2>
                <p>
                  Dieser Artikel bleibt ein lokaler Pilot-Entwurf. Die Preview zeigt
                  Quellenpakete und Kernzahlen, aber keine externe Veröffentlichung ohne
                  zusätzlichen Review.
                </p>
              </div>
              <dl>
                <div>
                  <dt>Quellenbasis</dt>
                  <dd>{gateSummary.sourceLabel}</dd>
                </div>
                <div>
                  <dt>Status</dt>
                  <dd>{analysis.displayStatus}</dd>
                </div>
                <div>
                  <dt>Externe Veröffentlichung</dt>
                  <dd>{gateSummary.externalLabel}</dd>
                </div>
              </dl>
            </>
          )}
        </section>

        <section className="qwp-disclaimer" id="qwp-hinweis" aria-label="Hinweis">
          <h2>Wichtiger Hinweis</h2>
          <p>
            Quellwert veröffentlicht Research-Notizen zur Methodik, Quellenlage und
            Unternehmensqualität. Diese Seite ist keine Anlageberatung, keine
            persönliche Empfehlung und keine Aufforderung zu einer Transaktion.
          </p>
        </section>

        {(adjacent.prev || adjacent.next) && (
          <nav className="qwp-article-nav" aria-label="Weitere Analysen">
            {adjacent.prev ? (
              <a
                className="qwp-link qwp-article-nav-prev"
                href={`/membership/analysen/${adjacent.prev.slug}`}
                aria-label={`Vorherige Analyse öffnen: ${adjacent.prev.shortName} (${adjacent.prev.ticker})`}
              >
                <span className="qwp-kicker">Vorherige Analyse</span>
                <span>{adjacent.prev.shortName}</span>
              </a>
            ) : (
              <div />
            )}
            {adjacent.next ? (
              <a
                className="qwp-link qwp-article-nav-next"
                href={`/membership/analysen/${adjacent.next.slug}`}
                aria-label={`Nächste Analyse öffnen: ${adjacent.next.shortName} (${adjacent.next.ticker})`}
              >
                <span className="qwp-kicker">Nächste Analyse</span>
                <span>{adjacent.next.shortName}</span>
              </a>
            ) : (
              <div />
            )}
          </nav>
        )}
        </article>

        <QuellwertPaperFooter />
      </div>
    </main>
  );
}
