import { NextResponse } from 'next/server';

import { loadSystemAudit } from '@/lib/control-plane-v2/system-audit';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function GET() {
  try {
    return NextResponse.json(await loadSystemAudit(), {
      headers: {
        'Cache-Control': 'no-store',
      },
    });
  } catch {
    return NextResponse.json({ error: 'System audit unavailable' }, { status: 503 });
  }
}
