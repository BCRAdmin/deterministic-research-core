// Backups API - Liefert Backup-Status
// Read-only, keine Secrets

import { isGitRepo, hasRemote, getLastCommit, getCurrentBranch } from '@/lib/services/gitService';
import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const [isRepo, hasRem, commit, branch] = await Promise.all([
      isGitRepo(),
      hasRemote(),
      getLastCommit(),
      getCurrentBranch()
    ]);

    return NextResponse.json({
      isRepo,
      hasRemote: hasRem,
      lastCommit: commit?.hash,
      branch,
      status: isRepo && hasRem ? 'healthy' : isRepo ? 'warning' : 'error'
    });
  } catch {
    return NextResponse.json(
      { error: 'Backup-Status nicht verfügbar' },
      { status: 503 }
    );
  }
}
