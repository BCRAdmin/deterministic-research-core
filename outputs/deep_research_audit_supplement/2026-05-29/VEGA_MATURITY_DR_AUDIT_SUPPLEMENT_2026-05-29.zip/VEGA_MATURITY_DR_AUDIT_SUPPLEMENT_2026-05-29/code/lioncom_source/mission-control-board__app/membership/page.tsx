import { getFeaturedAnalysis } from '@/lib/quellwert/analysisCatalog';
import type { Metadata } from 'next';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export const metadata: Metadata = {
  title: 'Quellwert | Research-Preview',
  description:
    'Öffentliche Research-Notizen zu Unternehmen: quellenbasiert, nachvollziehbar und mit klarer Methodik. Lokale Preview, kein Operator-Go für externe Veröffentlichung.',
};

export default function QuellwertWebsitePreviewPage() {
  const featured = getFeaturedAnalysis();
  const featuredHref = `/membership/analysen/${featured.slug}`;
  const featuredLabel = `Beispielanalyse lesen: ${featured.shortName} (${featured.ticker})`;

  return (
    <main className="qw-page" id="qw-main" tabIndex={-1} lang="de">
      <a className="qw-skip-link" href="#top">
        Zum Inhalt springen
      </a>
      <div className="qw-page-shell">
        <header className="qw-header" aria-label="Hauptnavigation">
          <a
            className="qw-brand"
            href="/membership"
            aria-label="Quellwert Startseite"
            aria-current="page"
          >
            <span className="qw-brand-mark" aria-hidden="true">
              <svg viewBox="0 0 32 32" role="presentation">
                <path d="M6 2.5h8v27H6zM18 2.5h8v27h-8z" />
                <path d="M10 5.5v21M22 5.5v21M6 8h8M18 24h8M14 15h4" />
              </svg>
            </span>
            <span className="qw-brand-word">Quellwert</span>
          </a>

          <nav className="qw-nav" aria-label="Quellwert Navigation">
            <a href="/membership/analysen">Analysen</a>
            <a href="/membership/methodik">Methodik</a>
            <a href="/membership/archiv">Archiv</a>
            <a href="/membership/verifier">Verifier</a>
            <a className="qw-read-link" href={featuredHref} aria-label={featuredLabel}>
              Lesen <span aria-hidden="true">↗</span>
            </a>
          </nav>
        </header>

        <section
          id="top"
          className="qw-hero"
          aria-labelledby="qw-hero-title"
          tabIndex={-1}
        >
          <div className="qw-hero-copy">
            <h1 id="qw-hero-title">Unternehmen lesen. Klarer denken.</h1>
            <span className="qw-accent" aria-hidden="true" />
            <p>
              Öffentliche Research-Notizen zu Unternehmen. Quellenbasiert,
              nachvollziehbar und mit klarem Blick auf Methode und Risiken.
            </p>
            <div className="qw-hero-actions">
              <a
                className="qw-button qw-button-primary"
                href={featuredHref}
                aria-label={featuredLabel}
              >
                Beispielanalyse lesen <span aria-hidden="true">→</span>
              </a>
              <a className="qw-button qw-button-secondary" href="/membership/methodik">
                Methodik ansehen
              </a>
            </div>
          </div>

          <div className="qw-hero-stage" aria-label="Quellwert Research-System Vorschau">
            <article className="qw-hero-card qw-hero-card-left top">
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M6 3h9l3 3v15H6z" />
                <path d="M15 3v4h4M9 11h6M9 15h6M9 19h4" />
              </svg>
              <strong>Quellenlage</strong>
              <span>
                Evidence-Paket
                <br />
                öffentlich prüfbar
              </span>
            </article>
            <article className="qw-hero-card qw-hero-card-left bottom">
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M5 5h14v15H5zM8 3v4M16 3v4M5 10h14" />
              </svg>
              <strong>Stand</strong>
              <span>
                {featured.asOfDate}
                <br />
                Pilot-Basis
              </span>
            </article>

            <img
              className="qw-monolith"
              src="/membership/quellwert-monolith.svg"
              alt="Dunkles Quellwert Research-Objekt mit transparentem Quellenpaneel"
            />

            <article className="qw-hero-card qw-hero-card-right top">
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M12 3l8 15H4zM12 7v5M12 15h.01" />
              </svg>
              <strong>Methode</strong>
              <span>
                Research-Agent
                <br />
                plus Review-Gate
              </span>
            </article>
            <article className="qw-hero-card qw-hero-card-right bottom">
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M12 3l10 18H2zM12 9v5M12 17h.01" />
              </svg>
              <strong>Risiken</strong>
              <span>
                Unsicherheit
                <br />
                explizit benannt
              </span>
            </article>
          </div>

          <div className="qw-hero-reference-hotspots" aria-label="Hero Schnellzugriff">
            <a className="qw-hero-reference-link qw-hero-reference-primary" href={featuredHref}>
              Beispielanalyse lesen
            </a>
            <a className="qw-hero-reference-link qw-hero-reference-secondary" href="/membership/methodik">
              Methodik ansehen
            </a>
          </div>
        </section>

        <section className="qw-principle-board" aria-label="Quellwert Prinzipien">
          <article>
            <svg viewBox="0 0 32 32" aria-hidden="true">
              <path d="M6 4h12l5 5v19H6zM18 4v6h6M10 14h10M10 19h10M10 24h7" />
            </svg>
            <h2>Quellen</h2>
            <p>Ausschließlich öffentliche, verifizierbare Quellen.</p>
            <a href="/membership/methodik" aria-label="Quellen ansehen">
              →
            </a>
          </article>
          <article>
            <svg viewBox="0 0 32 32" aria-hidden="true">
              <path d="M16 2l6 8 8 6-8 6-6 8-6-8-8-6 8-6zM16 2v28M2 16h28M10 10l12 12M22 10 10 22" />
            </svg>
            <h2>Methode</h2>
            <p>Nachvollziehbarer Analyseprozess statt Black Box.</p>
            <a href="/membership/methodik" aria-label="Methode ansehen">
              →
            </a>
          </article>
          <article>
            <svg viewBox="0 0 32 32" aria-hidden="true">
              <path d="M16 3l14 25H2zM16 11v8M16 23h.01" />
            </svg>
            <h2>Risiken</h2>
            <p>Unsicherheit wird benannt, nicht kaschiert.</p>
            <a href="/membership/methodik" aria-label="Risiken ansehen">
              →
            </a>
          </article>
        </section>

        <section id="analysen" className="qw-analysis-card" aria-labelledby="qw-analysis-title">
          <div className="qw-analysis-media">
            <span>
              {featured.sector}
              <br />
              {featured.ticker}
            </span>
            <span className="qw-media-square" aria-hidden="true" />
            <img
              src="/membership/siemens-building.svg"
              alt="Abstrahiertes Analysebild für die ausgewählte Quellwert-Notiz"
            />
          </div>

          <article className="qw-analysis-copy">
            <p className="qw-analysis-label">Ausgewählte Analyse</p>
            <span className="qw-small-accent" aria-hidden="true" />
            <h2 id="qw-analysis-title">{featured.shortName}</h2>
            <ul className="qw-analysis-meta" aria-label="Analyse-Metadaten">
              <li>
                <svg viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M5 5h14v15H5zM8 3v4M16 3v4M5 10h14" />
                </svg>
                <strong>Stand:</strong> {featured.asOfDate}
              </li>
              <li>
                <svg viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M12 4c4 0 7 1.2 7 2.8S16 9.6 12 9.6 5 8.4 5 6.8 8 4 12 4Z" />
                  <path d="M5 7v4c0 1.6 3 2.8 7 2.8s7-1.2 7-2.8V7M5 11v4c0 1.6 3 2.8 7 2.8s7-1.2 7-2.8v-4" />
                </svg>
                {featured.sourceCount} Quellenpakete
              </li>
              <li>
                <svg viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 7v5l3 2" />
                </svg>
                Lesedauer: {featured.readingMinutes} Min.
              </li>
            </ul>
            <p>{featured.summary}</p>
            <a className="qw-text-link" href={featuredHref} aria-label={featuredLabel}>
              Analyse lesen <span aria-hidden="true">→</span>
            </a>
          </article>
        </section>
      </div>

      <footer className="qw-footer">
        <div className="qw-footer-brand">
          <span className="qw-brand-mark" aria-hidden="true">
            <svg viewBox="0 0 32 32" role="presentation">
              <path d="M6 2.5h8v27H6zM18 2.5h8v27h-8z" />
              <path d="M10 5.5v21M22 5.5v21M6 8h8M18 24h8M14 15h4" />
            </svg>
          </span>
          <span className="qw-brand-word">Quellwert</span>
        </div>
        <p>Öffentliche Research-Notizen zu Unternehmen.</p>
        <nav aria-label="Footer Navigation">
          <a href="/membership/methodik">Über Quellwert</a>
          <a href="/membership/impressum">Impressum</a>
          <a href="/membership/datenschutz">Datenschutz</a>
          <a href="/membership/kontakt">Kontakt</a>
          <a href="/membership/verifier">Verifier</a>
        </nav>
      </footer>
    </main>
  );
}
