import { NextResponse } from 'next/server';

import {
  createControlPlaneV2FlightPack,
  readLatestControlPlaneV2FlightPack,
} from '@/lib/control-plane-v2/flight-pack';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function GET() {
  const pack = await readLatestControlPlaneV2FlightPack();
  return NextResponse.json({
    ok: Boolean(pack),
    pack,
  }, {
    headers: {
      'Cache-Control': 'no-store',
    },
  });
}

export async function POST(request: Request) {
  const pack = await createControlPlaneV2FlightPack(new URL(request.url).origin);
  return NextResponse.json({
    ok: true,
    pack,
  }, {
    headers: {
      'Cache-Control': 'no-store',
    },
  });
}
