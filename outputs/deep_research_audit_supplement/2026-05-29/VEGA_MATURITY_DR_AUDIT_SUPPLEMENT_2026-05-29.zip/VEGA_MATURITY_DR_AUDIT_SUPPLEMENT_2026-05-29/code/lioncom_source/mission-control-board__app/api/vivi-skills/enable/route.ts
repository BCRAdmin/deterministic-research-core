import { NextResponse } from 'next/server';

import { setViviSkillEnabled } from '@/lib/vivi-skills/registry';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function POST(request: Request) {
  const skillId = await readSkillId(request);
  if (!skillId) return NextResponse.json({ error: 'Skill-ID fehlt.' }, { status: 400 });

  try {
    return NextResponse.json({ ok: true, snapshot: await setViviSkillEnabled(skillId, true) });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error && error.message === 'skill-not-found' ? 'Vivi-Skill nicht gefunden.' : 'Vivi-Skill konnte nicht aktiviert werden.' },
      { status: error instanceof Error && error.message === 'skill-not-found' ? 404 : 500 },
    );
  }
}

async function readSkillId(request: Request): Promise<string> {
  try {
    const body = await request.json() as { skillId?: unknown };
    return typeof body.skillId === 'string' ? body.skillId.trim() : '';
  } catch {
    return '';
  }
}
