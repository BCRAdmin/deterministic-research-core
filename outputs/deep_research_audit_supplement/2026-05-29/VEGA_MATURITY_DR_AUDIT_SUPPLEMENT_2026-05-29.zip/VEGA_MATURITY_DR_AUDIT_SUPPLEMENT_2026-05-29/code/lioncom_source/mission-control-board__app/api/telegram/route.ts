import { NextRequest, NextResponse } from 'next/server';

import { syncAllControlPlanes } from '@/lib/services/controlPlaneSyncService';
import { getTelegramRelayStatus, ingestTelegramUpdate, pollTelegramBridge } from '@/lib/services/telegramBridgeService';
import { loadTelegramCredentials } from '@/lib/services/telegramService';

export const dynamic = 'force-dynamic';

function redirectTo(request: NextRequest, tab: string, saved: string) {
  const target = new URL('/control-plane-v2', request.url);
  target.searchParams.set('saved', saved);
  if (tab) target.searchParams.set('legacyTab', tab);
  return NextResponse.redirect(target, 303);
}

export async function GET(request: NextRequest) {
  const mode = request.nextUrl.searchParams.get('mode')?.trim();

  if (mode === 'poll') {
    try {
      const result = await pollTelegramBridge();
      await syncAllControlPlanes();
      return NextResponse.json(result, { status: result.ok ? 200 : 503 });
    } catch {
      return NextResponse.json({ error: 'Telegram poll failed' }, { status: 500 });
    }
  }

  try {
    const relay = await getTelegramRelayStatus();
    return NextResponse.json({ ok: true, relay });
  } catch {
    return NextResponse.json({ error: 'Telegram bridge snapshot unavailable' }, { status: 503 });
  }
}

export async function POST(request: NextRequest) {
  const contentType = request.headers.get('content-type') || '';

  if (contentType.includes('application/x-www-form-urlencoded') || contentType.includes('multipart/form-data')) {
    const formData = await request.formData();
    const mode = String(formData.get('mode') || '').trim();
    const redirectTab = String(formData.get('redirectTab') || 'comms').trim() || 'comms';

    if (mode === 'poll') {
      try {
        const result = await pollTelegramBridge();
        await syncAllControlPlanes();
        return redirectTo(request, redirectTab, result.ok ? 'telegram-poll' : 'telegram-poll-failed');
      } catch {
        return redirectTo(request, redirectTab, 'telegram-poll-failed');
      }
    }

    return NextResponse.json({ error: 'Unsupported Telegram form mode' }, { status: 400 });
  }

  const credentials = await loadTelegramCredentials();
  if (credentials.webhookSecret) {
    const providedSecret = request.headers.get('x-telegram-bot-api-secret-token')?.trim();
    if (providedSecret !== credentials.webhookSecret) {
      return NextResponse.json({ error: 'Unauthorized Telegram bridge request' }, { status: 401 });
    }
  }

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload' }, { status: 400 });
  }

  if (payload && typeof payload === 'object' && 'mode' in (payload as Record<string, unknown>) && (payload as { mode?: string }).mode === 'poll') {
    try {
      const result = await pollTelegramBridge();
      await syncAllControlPlanes();
      return NextResponse.json(result, { status: result.ok ? 200 : 503 });
    } catch {
      return NextResponse.json({ error: 'Telegram poll failed' }, { status: 500 });
    }
  }

  try {
    const result = await ingestTelegramUpdate(payload as never);
    await syncAllControlPlanes();
    return NextResponse.json(result);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to ingest Telegram update' },
      { status: 400 },
    );
  }
}
