import { NextResponse } from 'next/server';

import { loadControlPlaneV2Data } from '@/lib/control-plane-v2/live-data';
import type { ControlPlaneLiveData } from '@/lib/types';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  const data = await loadControlPlaneV2Data();
  const accept = request.headers.get('accept') || '';
  const fetchDest = request.headers.get('sec-fetch-dest') || '';
  const fetchMode = request.headers.get('sec-fetch-mode') || '';
  const url = new URL(request.url);
  const explicitJson = url.searchParams.get('format') === 'json' || accept.includes('application/json');
  const documentNavigation = fetchDest === 'document' || fetchMode === 'navigate';
  const wantsHtml = url.searchParams.get('view') === 'operator' || accept.includes('text/html') || (documentNavigation && !explicitJson);

  if (wantsHtml) {
    return new NextResponse(renderOperatorSummary(data), {
      headers: {
        'Cache-Control': 'no-store',
        'Content-Type': 'text/html; charset=utf-8',
      },
    });
  }

  return NextResponse.json(data, {
    headers: {
      'Cache-Control': 'no-store',
    },
  });
}

function renderOperatorSummary(data: ControlPlaneLiveData): string {
  const updatedAt = new Intl.DateTimeFormat('de-DE', {
    dateStyle: 'medium',
    timeStyle: 'medium',
  }).format(new Date(data.generatedAt));
  const latestMissions = data.missions.slice(0, 5);
  const latestSignals = data.activitySignals.slice(0, 5);

  return `<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>LIONCOM Control Plane V2 API</title>
  <style>
    :root {
      color-scheme: dark;
      --bg: #050b12;
      --surface: #07131f;
      --elevated: #0b1b2a;
      --border: rgba(98, 196, 255, 0.24);
      --text: #d9f4ff;
      --muted: #7f9aaa;
      --vivi: #67f5c0;
      --vega: #55b7ff;
      --warning: #f7c566;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      min-height: 100vh;
      background:
        radial-gradient(circle at 20% 10%, rgba(85, 183, 255, 0.16), transparent 30rem),
        radial-gradient(circle at 80% 20%, rgba(103, 245, 192, 0.10), transparent 28rem),
        var(--bg);
      color: var(--text);
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    }
    main { width: min(1180px, calc(100vw - 32px)); margin: 0 auto; padding: 32px 0; }
    .hero, .card {
      border: 1px solid var(--border);
      background: linear-gradient(180deg, rgba(11, 27, 42, 0.92), rgba(7, 19, 31, 0.84));
      border-radius: 20px;
      box-shadow: inset 0 1px 0 rgba(217, 244, 255, 0.06), 0 18px 80px rgba(0, 0, 0, 0.28);
    }
    .hero { padding: 28px; }
    .grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 12px; margin-top: 16px; }
    .two { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 12px; margin-top: 12px; }
    .card { padding: 18px; }
    .label { color: var(--muted); font-size: 11px; letter-spacing: 0.16em; text-transform: uppercase; }
    h1 { margin: 0; font-size: 28px; letter-spacing: 0.12em; text-transform: uppercase; }
    h2 { margin: 0 0 14px; color: var(--vega); font-size: 13px; letter-spacing: 0.18em; text-transform: uppercase; }
    p { color: var(--muted); line-height: 1.65; }
    .value { margin-top: 8px; font-size: 24px; font-weight: 700; }
    .good { color: var(--vivi); }
    .blue { color: var(--vega); }
    .warn { color: var(--warning); }
    a {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-height: 42px;
      padding: 0 18px;
      border: 1px solid rgba(85, 183, 255, 0.45);
      border-radius: 14px;
      background: rgba(85, 183, 255, 0.14);
      color: var(--text);
      text-decoration: none;
    }
    ul { margin: 0; padding: 0; list-style: none; }
    li { border-top: 1px solid rgba(98, 196, 255, 0.12); padding: 12px 0; }
    li:first-child { border-top: 0; padding-top: 0; }
    .muted { color: var(--muted); }
    @media (max-width: 820px) { .grid, .two { grid-template-columns: 1fr; } }
  </style>
</head>
<body>
  <main>
    <section class="hero">
      <div class="label">Live-API-Endpunkt</div>
      <h1>LIONCOM Control Plane V2</h1>
      <p>Dieser Endpunkt liefert Live-Daten für die V2-Oberfläche. Für die eigentliche Operator-Ansicht bitte das Dashboard öffnen.</p>
      <a href="/control-plane-v2">Control Plane V2 öffnen</a>
    </section>
    <section class="grid">
      <div class="card"><div class="label">Quelle</div><div class="value ${data.source === 'live' ? 'good' : 'warn'}">${escapeHtml(data.source.toUpperCase())}</div></div>
      <div class="card"><div class="label">Systemhaltung</div><div class="value ${data.globalStatus.posture === 'STABIL' ? 'good' : 'warn'}">${escapeHtml(data.globalStatus.posture)}</div></div>
      <div class="card"><div class="label">Offene Queue</div><div class="value blue">${data.globalStatus.queueDepth}</div></div>
      <div class="card"><div class="label">Snapshot</div><div class="value">${escapeHtml(updatedAt)}</div></div>
    </section>
    <section class="two">
      <div class="card">
        <h2>Aktuelle Missionen</h2>
        <ul>${latestMissions.map((mission) => `<li><strong>${escapeHtml(mission.title)}</strong><br><span class="muted">${escapeHtml(mission.ownerAgentId.toUpperCase())} · ${escapeHtml(mission.status)} · ${escapeHtml(mission.priority)}</span></li>`).join('')}</ul>
      </div>
      <div class="card">
        <h2>Aktuelle Signale</h2>
        <ul>${latestSignals.map((signal) => `<li><strong>${escapeHtml(signal.label)}</strong><br><span class="muted">${escapeHtml(signal.time)} · ${escapeHtml(signal.actor)} · ${escapeHtml(signal.detail)}</span></li>`).join('')}</ul>
      </div>
    </section>
  </main>
</body>
</html>`;
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
