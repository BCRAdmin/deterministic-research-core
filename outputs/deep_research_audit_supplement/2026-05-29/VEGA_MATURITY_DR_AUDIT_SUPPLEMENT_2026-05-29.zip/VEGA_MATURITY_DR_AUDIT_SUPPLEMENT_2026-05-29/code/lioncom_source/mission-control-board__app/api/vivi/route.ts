import { NextRequest, NextResponse } from 'next/server';

import { ensureRemoteBridgeConfig, syncRemoteBridgeStatus } from '@/lib/services/bridgeStatusService';
import { loadBridgeSecretStatus } from '@/lib/services/bridgeSecretService';
import { ingestViviSignal, readViviBridgeSnapshot, type ViviSignalPayload } from '@/lib/services/viviBridgeService';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const [snapshot, bridgeConfig, bridgeSecrets] = await Promise.all([
      readViviBridgeSnapshot(),
      ensureRemoteBridgeConfig(),
      loadBridgeSecretStatus(),
    ]);
    const bridgeStatus = await syncRemoteBridgeStatus(snapshot.runtime);
    return NextResponse.json({
      ...snapshot,
      bridge: {
        config: bridgeConfig,
        status: bridgeStatus,
      },
      contract: {
        endpoint: '/api/vivi',
        authRequired: bridgeConfig.authMode === 'bearer' && bridgeSecrets.authReady,
        publicIngestUrl: bridgeSecrets.publicIngestUrl || bridgeStatus.ingestUrl,
        activation: {
          publicIngestReady: bridgeStatus.publicIngestReady,
          authReady: bridgeStatus.authReady,
          secretSource: [REDACTED]
        },
        acceptedEvents: ['heartbeat', 'transition', 'report', 'handoff', 'verify', 'recovery'],
      },
    });
  } catch {
    return NextResponse.json(
      { error: 'Vivi bridge snapshot unavailable' },
      { status: 503 },
    );
  }
}

export async function POST(request: NextRequest) {
  const bridgeSecrets = await loadBridgeSecretStatus();
  const configuredToken = bridgeSecrets.bridgeToken?.trim();
  if (configuredToken) {
    const bearer = request.headers.get('authorization')?.replace(/^Bearer\s+/i, '').trim();
    const headerToken = request.headers.get('x-lioncom-token')?.trim();
    if (bearer !== configuredToken && headerToken !== configuredToken) {
      return NextResponse.json(
        { error: 'Unauthorized bridge signal' },
        { status: 401 },
      );
    }
  }

  let payload: ViviSignalPayload;

  try {
    payload = (await request.json()) as ViviSignalPayload;
  } catch {
    return NextResponse.json(
      { error: 'Invalid JSON payload' },
      { status: 400 },
    );
  }

  if (!payload.event && !payload.state && !payload.phase && !payload.currentAction) {
    return NextResponse.json(
      { error: 'Bridge payload must include at least an event, state, phase or currentAction.' },
      { status: 400 },
    );
  }

  if (payload.progress !== undefined && (typeof payload.progress !== 'number' || Number.isNaN(payload.progress))) {
    return NextResponse.json(
      { error: 'Progress must be numeric when supplied.' },
      { status: 400 },
    );
  }

  try {
    const result = await ingestViviSignal(payload);
    return NextResponse.json({
      ok: true,
      runtime: result.runtime,
      state: result.state,
      reportEntry: result.reportEntry,
    });
  } catch {
    return NextResponse.json(
      { error: 'Failed to ingest Vivi signal' },
      { status: 500 },
    );
  }
}
