import { NextRequest, NextResponse } from 'next/server';

import {
  dispatchControlPlaneTask,
  isControlPlaneDispatchValidationError,
  type ControlPlaneDispatchPayload,
} from '@/lib/services/controlPlaneDispatchService';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function POST(request: NextRequest) {
  let payload: ControlPlaneDispatchPayload;

  try {
    payload = await request.json() as ControlPlaneDispatchPayload;
  } catch {
    return NextResponse.json({ error: 'Ungültiger Dispatch-Payload.' }, { status: 400 });
  }

  try {
    const result = await dispatchControlPlaneTask(payload);
    return NextResponse.json(result, {
      headers: {
        'Cache-Control': 'no-store',
      },
    });
  } catch (error) {
    if (isControlPlaneDispatchValidationError(error)) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    return NextResponse.json({ error: 'Dispatch konnte nicht geschrieben werden.' }, { status: 500 });
  }
}
