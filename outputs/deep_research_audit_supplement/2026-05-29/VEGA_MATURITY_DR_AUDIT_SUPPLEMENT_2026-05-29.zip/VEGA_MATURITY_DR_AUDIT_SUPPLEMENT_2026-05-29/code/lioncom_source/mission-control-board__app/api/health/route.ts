// Health API - Liefert Gesundheits-Status
// Read-only, keine Secrets

import { getSystemHealth } from '@/lib/services/healthService';
import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const health = await getSystemHealth();
    return NextResponse.json(health);
  } catch {
    return NextResponse.json(
      { error: 'Health-Check nicht verfügbar' },
      { status: 503 }
    );
  }
}
