import { getPublicAnalyses } from '@/lib/quellwert/analysisCatalog';
import type { MetadataRoute } from 'next';

function getSiteUrl() {
  return (
    process.env.QUELLWERT_SITE_URL ||
    process.env.NEXT_PUBLIC_SITE_URL ||
    'http://127.0.0.1:4107'
  ).replace(/\/+$/, '');
}

export default function sitemap(): MetadataRoute.Sitemap {
  const siteUrl = getSiteUrl();
  const lastModified = new Date('2026-05-15T00:00:00.000Z');
  const staticRoutes = [
    { path: '/membership', priority: 1 },
    { path: '/membership/analysen', priority: 0.82 },
    { path: '/membership/methodik', priority: 0.78 },
    { path: '/membership/archiv', priority: 0.62 },
    { path: '/membership/impressum', priority: 0.3 },
    { path: '/membership/datenschutz', priority: 0.3 },
    { path: '/membership/kontakt', priority: 0.3 },
  ];

  return [
    ...staticRoutes.map((route) => ({
      url: `${siteUrl}${route.path}`,
      lastModified,
      changeFrequency: 'weekly' as const,
      priority: route.priority,
    })),
    ...getPublicAnalyses().map((analysis) => ({
      url: `${siteUrl}/membership/analysen/${analysis.slug}`,
      lastModified: new Date(`${analysis.asOfDate}T00:00:00.000Z`),
      changeFrequency: 'monthly' as const,
      priority: analysis.displayStatus === 'Public-Ready-Kandidat' ? 0.74 : 0.62,
    })),
  ];
}
