import { NextResponse } from 'next/server';

import {
  createViviProviderStatus,
  createFallbackViviModelCatalog,
  mergeModelOptions,
  type ViviModelOption,
} from '@/lib/vivi-model-catalog';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

const FETCH_TIMEOUT_MS = 2500;

interface OpenAiModelList {
  data?: Array<{ id?: string }>;
}

interface OllamaTags {
  models?: Array<{ name?: string; model?: string }>;
}

export async function GET() {
  const warnings: string[] = [];
  const fallback = createFallbackViviModelCatalog();
  const [lmStudioModels, ollamaModels, openRouterModels] = await Promise.all([
    fetchLmStudioModels(warnings),
    fetchOllamaModels(warnings),
    fetchOpenRouterModels(warnings),
  ]);

  const models = mergeModelOptions(lmStudioModels, ollamaModels, openRouterModels, fallback.models);

  return NextResponse.json({
    ...fallback,
    generatedAt: new Date().toISOString(),
    models,
    providerStatus: createViviProviderStatus(models, warnings),
    warnings,
  });
}

async function fetchLmStudioModels(warnings: string[]): Promise<ViviModelOption[]> {
  const endpoint = process.env.LIONCOM_LMSTUDIO_MODELS_URL || 'http://127.0.0.1:1234/v1/models';
  try {
    const data = await fetchJson<OpenAiModelList>(endpoint);
    return (data.data || [])
      .map((model) => model.id?.trim())
      .filter((id): id is string => Boolean(id))
      .map((id) => ({
        id,
        label: id,
        provider: 'lmstudio',
        mode: 'local',
        source: 'live',
      }));
  } catch {
    warnings.push('LM-Studio-Modellliste nicht erreichbar; Fallback-Katalog aktiv.');
    return [];
  }
}

async function fetchOllamaModels(warnings: string[]): Promise<ViviModelOption[]> {
  const endpoint = process.env.LIONCOM_OLLAMA_TAGS_URL || 'http://127.0.0.1:11434/api/tags';
  try {
    const data = await fetchJson<OllamaTags>(endpoint);
    return (data.models || [])
      .map((model) => (model.name || model.model || '').trim())
      .filter((id): id is string => Boolean(id))
      .map((id) => ({
        id,
        label: id,
        provider: 'ollama',
        mode: id.endsWith(':cloud') ? 'cloud' : 'local',
        source: 'live',
      }));
  } catch {
    warnings.push('Ollama-Modellliste nicht erreichbar; Fallback-Katalog aktiv.');
    return [];
  }
}

async function fetchOpenRouterModels(warnings: string[]): Promise<ViviModelOption[]> {
  const endpoint = process.env.LIONCOM_OPENROUTER_MODELS_URL || 'https://openrouter.ai/api/v1/models';
  try {
    const data = await fetchJson<OpenAiModelList>(endpoint);
    return (data.data || [])
      .map((model) => model.id?.trim())
      .filter((id): id is string => Boolean(id))
      .filter((id) => !id.startsWith('~'))
      .filter((id) => /gpt|deepseek|kimi|qwen|claude|gemini|llama/i.test(id))
      .slice(0, 120)
      .map((id) => ({
        id,
        label: id,
        provider: 'openrouter',
        mode: 'cloud',
        source: 'live',
      }));
  } catch {
    warnings.push('OpenRouter-Modellliste nicht erreichbar; Fallback-Katalog aktiv.');
    return [];
  }
}

async function fetchJson<T>(url: string): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  try {
    const response = await fetch(url, {
      cache: 'no-store',
      signal: controller.signal,
      headers: { Accept: 'application/json' },
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.json() as T;
  } finally {
    clearTimeout(timer);
  }
}
