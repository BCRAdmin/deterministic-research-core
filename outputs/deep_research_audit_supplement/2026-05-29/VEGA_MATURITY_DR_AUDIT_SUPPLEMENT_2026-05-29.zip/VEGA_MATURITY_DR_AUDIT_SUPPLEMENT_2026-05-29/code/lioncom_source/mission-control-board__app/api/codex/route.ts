import { NextRequest, NextResponse } from 'next/server';

import { appendCodexChatEntry, claimCodexWork, closeCodexWork, markCodexInboxHandled, readCodexChatThread, reconcileCodexChat } from '@/lib/services/codexBoardService';
import { syncAllControlPlanes } from '@/lib/services/controlPlaneSyncService';
import { readRailContent } from '@/lib/services/structuredRailService';
import { PATHS } from '@/lib/constants/paths';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const thread = await readCodexChatThread();
    const [runtimeContent, reportsContent] = await Promise.all([
      readRailContent(PATHS.CODEX_RUNTIME),
      readRailContent(PATHS.CODEX_REPORTS),
    ]);
    return NextResponse.json({
      thread,
      pending: thread.filter((entry) => entry.role === 'operator' && entry.status === 'new').length,
      runtime: runtimeContent ? JSON.parse(runtimeContent) : null,
      reports: reportsContent || null,
    });
  } catch {
    return NextResponse.json(
      { error: 'Codex chat thread unavailable' },
      { status: 503 },
    );
  }
}

export async function POST(request: NextRequest) {
  let payload: {
    role?: 'operator' | 'codex' | 'system';
    message?: string;
    summary?: string;
    status?: string;
    source?: string;
    reference?: string;
    replyToId?: string;
    action?: 'reply' | 'claim' | 'close';
  };

  try {
    payload = (await request.json()) as typeof payload;
  } catch {
    return NextResponse.json(
      { error: 'Invalid JSON payload' },
      { status: 400 },
    );
  }

  const action = payload.action || 'reply';

  if (action === 'claim') {
    if (!payload.reference && !payload.replyToId) {
      return NextResponse.json(
        { error: 'Claim requires a reference or reply target' },
        { status: 400 },
      );
    }

    try {
      await claimCodexWork(payload.reference, payload.replyToId);
      const entry = payload.message?.trim()
        ? await appendCodexChatEntry({
            role: payload.role || 'codex',
            message: payload.message,
            summary: payload.summary,
            status: 'claimed',
            source: payload.source,
            reference: payload.reference || payload.replyToId,
          })
        : null;
      await syncAllControlPlanes();
      return NextResponse.json({ ok: true, action, entry });
    } catch {
      return NextResponse.json(
        { error: 'Failed to claim Codex work' },
        { status: 500 },
      );
    }
  }

  if (action === 'close') {
    if (!payload.reference && !payload.replyToId) {
      return NextResponse.json(
        { error: 'Close requires a reference or reply target' },
        { status: 400 },
      );
    }

    try {
      const entry = payload.message?.trim()
        ? await appendCodexChatEntry({
            role: payload.role || 'codex',
            message: payload.message,
            summary: payload.summary,
            status: payload.status || 'closed',
            source: payload.source,
            reference: payload.reference || payload.replyToId,
          })
        : null;

      await closeCodexWork(payload.reference, payload.replyToId);
      await syncAllControlPlanes();
      return NextResponse.json({ ok: true, action, entry });
    } catch {
      return NextResponse.json(
        { error: 'Failed to close Codex work' },
        { status: 500 },
      );
    }
  }

  if (!payload.message?.trim()) {
    return NextResponse.json(
      { error: 'Message is required' },
      { status: 400 },
    );
  }

  try {
    const entry = await appendCodexChatEntry({
      role: payload.role || 'codex',
      message: payload.message,
      summary: payload.summary,
      status: payload.status,
      source: payload.source,
      reference: payload.reference,
    });

    if ((payload.role || 'codex') === 'codex') {
      await claimCodexWork(payload.reference, payload.replyToId);
      await reconcileCodexChat(payload.reference, payload.replyToId);
      await markCodexInboxHandled(payload.reference || payload.replyToId);
    }

    await syncAllControlPlanes();

    return NextResponse.json({ ok: true, entry });
  } catch {
    return NextResponse.json(
      { error: 'Failed to append Codex chat entry' },
      { status: 500 },
    );
  }
}
