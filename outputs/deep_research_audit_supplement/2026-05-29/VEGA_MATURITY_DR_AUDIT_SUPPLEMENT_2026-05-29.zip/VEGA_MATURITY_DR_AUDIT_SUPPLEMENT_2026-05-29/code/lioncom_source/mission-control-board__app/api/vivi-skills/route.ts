import { NextResponse } from 'next/server';

import { loadViviSkillSnapshot } from '@/lib/vivi-skills/registry';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function GET() {
  try {
    return NextResponse.json(await loadViviSkillSnapshot());
  } catch {
    return NextResponse.json({ error: 'Vivi-Skills konnten nicht geladen werden.' }, { status: 503 });
  }
}
