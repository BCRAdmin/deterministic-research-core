// Learnings API - Liefert Learnings
// Read-only, keine Secrets

import { mapLearnings } from '@/lib/mappers/learningMapper';
import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const learnings = await mapLearnings();
    return NextResponse.json(learnings);
  } catch {
    return NextResponse.json(
      { error: 'Learnings nicht verfügbar' },
      { status: 503 }
    );
  }
}
