import { NextResponse } from 'next/server';

import { runViviSkill } from '@/lib/vivi-skills/runtime';
import type { ViviSkillRunInput } from '@/lib/vivi-skills/types';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function POST(request: Request) {
  let payload: Partial<ViviSkillRunInput>;
  try {
    payload = await request.json() as Partial<ViviSkillRunInput>;
  } catch {
    return NextResponse.json({ error: 'Ungültige JSON-Daten.' }, { status: 400 });
  }

  if (!payload.skillId || typeof payload.skillId !== 'string') {
    return NextResponse.json({ error: 'Skill-ID fehlt.' }, { status: 400 });
  }

  try {
    const run = await runViviSkill({
      skillId: payload.skillId,
      sessionId: typeof payload.sessionId === 'string' ? payload.sessionId : undefined,
      messageId: typeof payload.messageId === 'string' ? payload.messageId : undefined,
      commandRef: typeof payload.commandRef === 'string' ? payload.commandRef : undefined,
      operatorMessage: typeof payload.operatorMessage === 'string' ? payload.operatorMessage : undefined,
      source: typeof payload.source === 'string' ? payload.source : 'Vivi Skill API',
      requestedBy: payload.requestedBy || 'operator',
      operatorGateApproved: Boolean(payload.operatorGateApproved),
      payload: normalizePayload(payload.payload),
    });
    return NextResponse.json({ ok: run.status !== 'failed', run });
  } catch {
    return NextResponse.json({ error: 'Vivi-Skill konnte nicht ausgeführt werden.' }, { status: 500 });
  }
}

function normalizePayload(value: unknown): ViviSkillRunInput['payload'] {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return undefined;
  const normalized: Record<string, string | number | boolean | null> = {};
  for (const [key, entry] of Object.entries(value)) {
    if (typeof entry === 'string' || typeof entry === 'number' || typeof entry === 'boolean' || entry === null) {
      normalized[key] = entry;
    }
  }
  return normalized;
}
