import {
  getAnalysisGateSummary,
  getInternalReviewAnalyses,
  getPublicAnalyses,
} from '@/lib/quellwert/analysisCatalog';
import { QuellwertPaperFooter } from '@/components/quellwert/quellwert-paper-footer';
import { QuellwertPaperHeader } from '@/components/quellwert/quellwert-paper-header';
import type { Metadata } from 'next';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export const metadata: Metadata = {
  title: 'Archiv | Quellwert',
  description:
    'Archiv der sichtbaren Public-Preview-Kandidaten. Zurückgestellte Review-Fälle bleiben unsichtbar, bis Quellenstatus und Zahlenlogik sauber genug sind.',
};

export default function QuellwertArchivPage() {
  const publicAnalyses = getPublicAnalyses();
  const reviewCount = getInternalReviewAnalyses().length;

  return (
    <main className="qw-page qwp-page" id="qwp-main" tabIndex={-1} lang="de">
      <QuellwertPaperHeader current="archiv" />
      <div id="qwp-content" tabIndex={-1} role="region" aria-label="Inhalt">
        <section className="qwp-hero qwp-narrow">
          <p className="qwp-kicker">Archiv</p>
          <h1>Was sichtbar ist, hat ein Gate passiert.</h1>
          <p>
            Das Archiv unterscheidet öffentliche Pilot-Entwürfe von internen
            Review-Fällen. Zurückgestellte Kandidaten bleiben unsichtbar, bis
            Quellenstatus, Zahlenlogik und Review sauber genug sind.
          </p>
        </section>

        <section className="qwp-narrow" aria-label="Schnellzugriff">
          <nav className="qwp-toc" aria-labelledby="qwp-quick-title">
            <p className="qwp-kicker" id="qwp-quick-title">
              Schnellzugriff
            </p>
            <ul>
              <li>
                <a href="/membership">Start</a>
              </li>
              <li>
                <a href="/membership/analysen">Analysen</a>
              </li>
              <li>
                <a href="/membership/methodik">Methodik</a>
              </li>
              <li>
                <a aria-current="page" href="/membership/archiv">
                  Archiv
                </a>
              </li>
              <li>
                <a href="/membership/verifier">Verifier</a>
              </li>
            </ul>
          </nav>
        </section>

        <section
          className="qwp-archive-table"
          aria-label="Quellwert Archiv"
          role="table"
        >
          <div role="rowgroup">
            <div className="qwp-archive-row qwp-archive-head" role="row">
              <span role="columnheader">Unternehmen</span>
              <span role="columnheader">Stand</span>
              <span role="columnheader">Status</span>
              <span role="columnheader">Gate-Status</span>
              <span role="columnheader">Öffnen</span>
            </div>
          </div>
          <div role="rowgroup">
            {publicAnalyses.map((analysis) => {
              const gate = getAnalysisGateSummary(analysis);

              return (
                <div className="qwp-archive-row" key={analysis.slug} role="row">
                  <span data-label="Unternehmen" role="rowheader">
                    <strong>{analysis.shortName}</strong>
                    <small>{analysis.ticker}</small>
                  </span>
                  <span data-label="Stand" role="cell">
                    {analysis.asOfDate}
                  </span>
                  <span data-label="Status" role="cell">
                    {analysis.displayStatus}
                  </span>
                  <span
                    className="qwp-archive-gate"
                    data-label="Gate-Status"
                    role="cell"
                  >
                    <span>{gate.reviewLabel}</span>
                    <small>{gate.externalLabel}</small>
                  </span>
                  <span data-label="Öffnen" role="cell">
                    <a
                      href={`/membership/analysen/${analysis.slug}`}
                      aria-label={`Analyse öffnen: ${analysis.shortName} (${analysis.ticker})`}
                    >
                      Lesen
                    </a>
                  </span>
                </div>
              );
            })}
          </div>
        </section>

        <section className="qwp-disclaimer qwp-narrow" aria-label="Interner Review">
          <h2>Interner Review</h2>
          <p>
            {reviewCount} Kandidaten sind aktuell zurückgestellt und nicht öffentlich
            geroutet. Diese Trennung ist Absicht: Quellwert soll Vertrauen über
            Nachvollziehbarkeit aufbauen, nicht über Masse.
          </p>
        </section>

        <QuellwertPaperFooter />
      </div>
    </main>
  );
}
