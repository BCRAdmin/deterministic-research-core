import { QuellwertPaperFooter } from '@/components/quellwert/quellwert-paper-footer';
import { QuellwertPaperHeader } from '@/components/quellwert/quellwert-paper-header';

export default function QuellwertNotFound() {
  return (
    <main className="qw-page qwp-page" id="qwp-main" tabIndex={-1} lang="de">
      <QuellwertPaperHeader />
      <div id="qwp-content" tabIndex={-1} role="region" aria-label="Inhalt">
        <section className="qwp-hero qwp-narrow">
          <p className="qwp-kicker">Nicht veröffentlicht</p>
          <h1>Diese Analyse ist nicht öffentlich freigegeben.</h1>
          <p>
            Die angefragte Route existiert in der lokalen Quellwert-Preview nicht
            oder bleibt im internen Review. Öffentliche Seiten benötigen Quellenstatus,
            Non-Advice-Grenze und Operator-Go.
          </p>
          <div className="qwp-hero-actions">
            <a className="qwp-button qwp-button-primary" href="/membership/analysen">
              Zu den Analysen
            </a>
            <a className="qwp-button qwp-button-secondary" href="/membership/methodik">
              Methodik ansehen
            </a>
          </div>
        </section>

        <section className="qwp-disclaimer qwp-narrow" aria-label="Operator-Gate">
          <h2>Operator-Gate</h2>
          <p>
            Zurückgestellte Analysen werden nicht still angezeigt. Das verhindert,
            dass internes Material ohne Quellenprüfung, Non-Advice-Grenze oder
            externe Freigabe auf der öffentlichen Oberfläche landet.
          </p>
        </section>

        <QuellwertPaperFooter />
      </div>
    </main>
  );
}
