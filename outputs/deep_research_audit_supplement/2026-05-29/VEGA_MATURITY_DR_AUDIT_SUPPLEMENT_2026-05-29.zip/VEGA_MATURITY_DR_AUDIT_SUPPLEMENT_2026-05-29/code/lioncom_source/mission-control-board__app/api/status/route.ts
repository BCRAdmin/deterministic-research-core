// Status API - Liefert System-Status
// Read-only, keine Secrets

import { mapStatus } from '@/lib/mappers/statusMapper';
import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const status = await mapStatus();
    return NextResponse.json(status);
  } catch {
    return NextResponse.json(
      { error: 'Status nicht verfügbar' },
      { status: 503 }
    );
  }
}
