import { promises as fs } from 'fs';

import { NextRequest, NextResponse } from 'next/server';

import { PATHS } from '@/lib/constants/paths';
import { appendCodexChatEntry } from '@/lib/services/codexBoardService';
import { syncAllControlPlanes } from '@/lib/services/controlPlaneSyncService';
import { analyzeOperatorIntent } from '@/lib/services/operatorIntentService';
import { renderAttachmentLines, storeUploadedAttachments } from '@/lib/services/attachmentService';
import { sendTelegramBridgeMessage } from '@/lib/services/telegramService';

const SUPPORTED_KINDS = new Set([
  'brain-dump',
  'work-intake',
  'telegram-packet',
  'codex-chat',
  'codex-command',
  'vivi-command',
  'repair-request',
]);

function slugTimestamp(prefix: string): string {
  const now = new Date();
  const stamp = now.toISOString().replace(/[-:TZ]/g, '').replace('.', '').slice(0, 17);
  const entropy = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `${prefix}-${stamp}-${entropy}`;
}

function clean(value: FormDataEntryValue | null): string {
  return typeof value === 'string' ? value.trim() : '';
}

function summarize(value: string, fallback: string): string {
  const compact = value.replace(/\s+/g, ' ').trim();
  if (!compact) return fallback;
  return compact.slice(0, 180);
}

function quoteBlock(value: string): string {
  return value
    .split('\n')
    .map((line) => `> ${line}`)
    .join('\n');
}

function renderInterpretationLines(input: {
  sourceRail: 'work-intake' | 'brain-dump' | 'repair-queue' | 'vivi-command' | 'codex-command' | 'codex-chat';
  title?: string;
  summary?: string;
  rawText?: string;
  context?: string;
  desiredOutcome?: string;
  priority?: string;
}): string {
  const analysis = analyzeOperatorIntent(input);
  return [
    `- Intent: ${analysis.intent}`,
    `- Project Fit: ${analysis.projectFit}`,
    `- Research Mode: ${analysis.researchMode}`,
    `- Operator Mode: ${analysis.operatorMode}`,
    `- Priority Hint: ${analysis.priorityHint}`,
    `- Example Handling: ${analysis.exampleHandling}`,
    `- Interpretation Hint: ${analysis.interpretationHint}`,
    analysis.researchPrompt ? `- Research Prompt: ${analysis.researchPrompt}` : null,
    `- Routing Note: ${analysis.routingNote}`,
  ].filter(Boolean).join('\n');
}

async function ensureFile(filePath: string, header: string): Promise<void> {
  try {
    await fs.access(filePath);
  } catch {
    await fs.writeFile(filePath, header, 'utf-8');
  }
}

async function appendBlock(filePath: string, header: string, block: string): Promise<void> {
  await ensureFile(filePath, header);
  await fs.appendFile(filePath, block, 'utf-8');
}

function redirectTo(request: NextRequest, tab: string, saved: string) {
  const target = new URL('/control-plane-v2', request.url);
  target.searchParams.set('saved', saved);
  if (tab) target.searchParams.set('legacyTab', tab);
  return NextResponse.redirect(target, 303);
}

export async function POST(request: NextRequest) {
  const formData = await request.formData();
  const kind = clean(formData.get('kind'));
  const redirectTab = clean(formData.get('redirectTab')) || 'command';

  if (!SUPPORTED_KINDS.has(kind)) {
    return NextResponse.json({ error: 'Unsupported intake kind' }, { status: 400 });
  }

  const now = new Date().toISOString();

  if (kind === 'brain-dump') {
    const rawInput = clean(formData.get('rawInput'));
    if (!rawInput) {
      return NextResponse.json({ error: 'Missing raw input' }, { status: 400 });
    }

    const context = clean(formData.get('context'));
    const category = clean(formData.get('category')) || 'raw-idea';
    const entryId = slugTimestamp('IDEA');
    const summary = summarize(rawInput, 'Captured idea');
    const attachments = await storeUploadedAttachments({
      scope: 'brain-dump',
      entryId,
      files: formData.getAll('attachments'),
    });
    const interpretation = renderInterpretationLines({
      sourceRail: 'brain-dump',
      summary,
      rawText: rawInput,
      context,
    });

    await appendBlock(
      PATHS.BRAIN_DUMP,
      '# Brain Dump\n\nAppend-only memory rail for raw ideas, sparks and half-formed requests from Control Room.\n\n',
      `### ${entryId}\n- Added: ${now}\n- Source: Mission Control App\n- Status: raw\n- Category: ${category}\n- Summary: ${summary}\n- Context: ${context || 'None supplied'}\n${renderAttachmentLines(attachments)}${interpretation}\n- Raw Input:\n${quoteBlock(rawInput)}\n\n`,
    );

    await syncAllControlPlanes();
    return redirectTo(request, redirectTab, 'brain-dump');
  }

  if (kind === 'work-intake') {
    const title = clean(formData.get('title'));
    const rawRequest = clean(formData.get('rawRequest'));
    const desiredOutcome = clean(formData.get('desiredOutcome'));
    const urgency = clean(formData.get('urgency')) || 'normal';
    const category = clean(formData.get('category')) || 'work-order';

    if (!title || !rawRequest) {
      return NextResponse.json({ error: 'Missing title or raw request' }, { status: 400 });
    }

    const entryId = slugTimestamp('WRK');
    const summary = summarize(rawRequest, title);
    const attachments = await storeUploadedAttachments({
      scope: 'work-intake',
      entryId,
      files: formData.getAll('attachments'),
    });
    const interpretation = renderInterpretationLines({
      sourceRail: 'work-intake',
      title,
      summary,
      rawText: rawRequest,
      desiredOutcome,
      priority: urgency,
    });

    await appendBlock(
      PATHS.WORK_INTAKE,
      '# Work Intake\n\nControlled queue for requests that Vivi should interpret, split into work blocks and turn into concrete subtasks.\n\n',
      `### ${entryId}\n- Added: ${now}\n- Source: Mission Control App\n- Status: new\n- Urgency: ${urgency}\n- Category: ${category}\n- Title: ${title}\n- Desired Outcome: ${desiredOutcome || 'Not supplied yet'}\n- Summary: ${summary}\n${renderAttachmentLines(attachments)}${interpretation}\n- Raw Request:\n${quoteBlock(rawRequest)}\n\n`,
    );

    await syncAllControlPlanes();
    return redirectTo(request, redirectTab, 'work-intake');
  }

  if (kind === 'telegram-packet') {
    const title = clean(formData.get('title'));
    const message = clean(formData.get('message'));
    const priority = clean(formData.get('priority')) || 'normal';

    if (!title || !message) {
      return NextResponse.json({ error: 'Missing telegram title or message' }, { status: 400 });
    }

    const entryId = slugTimestamp('TG');
    const summary = summarize(message, title);
    const attachments = await storeUploadedAttachments({
      scope: 'telegram-packet',
      entryId,
      files: formData.getAll('attachments'),
    });
    const delivery = await sendTelegramBridgeMessage({ title, message, priority, attachments });

    await appendBlock(
      PATHS.TELEGRAM_OUTBOX,
      '# Telegram Outbox\n\nOutbound relay packets from LIONCOM for mobile use, alerts and remote operator updates.\n\n',
      `### ${entryId}\n- Added: ${now}\n- Source: Mission Control App\n- Status: ${delivery.status}\n- Priority: ${priority}\n- Title: ${title}\n- Target: Telegram\n- Delivery: ${delivery.status}\n- Summary: ${summary}\n- Delivery Detail: ${delivery.detail}\n${renderAttachmentLines(attachments)}- Message:\n${quoteBlock(message)}\n\n`,
    );

    await syncAllControlPlanes();
    return redirectTo(request, redirectTab, 'telegram-packet');
  }

  if (kind === 'codex-chat') {
    const message = clean(formData.get('message'));
    const reference = clean(formData.get('reference'));
    const context = clean(formData.get('context'));
    const category = clean(formData.get('category')) || 'live-sync';

    if (!message) {
      return NextResponse.json({ error: 'Missing Codex board message' }, { status: 400 });
    }

    const summary = summarize(message, 'Codex board message');
    const interpretation = renderInterpretationLines({
      sourceRail: 'codex-chat',
      summary,
      rawText: message,
      context,
    });
    const chatEntry = await appendCodexChatEntry({
      role: 'operator',
      status: 'new',
      message,
      summary,
      reference,
      source: 'Mission Control App',
    });

    await appendBlock(
      PATHS.CODEX_INBOX,
      '# Codex Inbox\n\nLocal command packets prepared for Codex-side implementation, review or debugging work.\n\n',
      `### ${slugTimestamp('CDX')}\n- Added: ${now}\n- Source: Mission Control App\n- Status: queued\n- Priority: normal\n- Category: ${category}\n- Title: Board chat from operator\n- Context: ${context || 'Board-first Codex chat'}\n- Reference: ${reference || chatEntry.id}\n- Summary: ${summary}\n${interpretation}\n- Raw Request:\n${quoteBlock(message)}\n\n`,
    );

    await syncAllControlPlanes();
    return redirectTo(request, redirectTab, 'codex-chat');
  }

  if (kind === 'codex-command') {
    const title = clean(formData.get('title'));
    const rawRequest = clean(formData.get('rawRequest'));
    const context = clean(formData.get('context'));
    const priority = clean(formData.get('priority')) || 'normal';
    const operatorComment = clean(formData.get('operatorComment'));
    const reference = clean(formData.get('reference'));
    const category = clean(formData.get('category')) || 'implementation';

    if (!title || !rawRequest) {
      return NextResponse.json({ error: 'Missing codex title or request' }, { status: 400 });
    }

    const entryId = slugTimestamp('CDX');
    const summary = summarize(rawRequest, title);
    const interpretation = renderInterpretationLines({
      sourceRail: 'codex-command',
      title,
      summary,
      rawText: rawRequest,
      context,
      priority,
    });

    await appendBlock(
      PATHS.CODEX_INBOX,
      '# Codex Inbox\n\nLocal command packets prepared for Codex-side implementation, review or debugging work.\n\n',
      `### ${entryId}\n- Added: ${now}\n- Source: Mission Control App\n- Status: queued\n- Priority: ${priority}\n- Category: ${category}\n- Title: ${title}\n- Context: ${context || 'General LIONCOM command'}\n- Reference: ${reference || 'None supplied'}\n- Summary: ${summary}\n${interpretation}\n${operatorComment ? `- Operator Comment: ${operatorComment}\n` : ''}- Raw Request:\n${quoteBlock(rawRequest)}\n\n`,
    );

    await syncAllControlPlanes();
    return redirectTo(request, redirectTab, 'codex-command');
  }

  if (kind === 'vivi-command') {
    const title = clean(formData.get('title'));
    const rawRequest = clean(formData.get('rawRequest'));
    const context = clean(formData.get('context'));
    const desiredOutcome = clean(formData.get('desiredOutcome'));
    const priority = clean(formData.get('priority')) || 'normal';
    const operatorComment = clean(formData.get('operatorComment'));
    const reference = clean(formData.get('reference'));
    const category = clean(formData.get('category')) || 'execution';

    if (!title || !rawRequest) {
      return NextResponse.json({ error: 'Missing Vivi title or request' }, { status: 400 });
    }

    const entryId = slugTimestamp('VIVI');
    const summary = summarize(rawRequest, title);
    const combinedContext = `${context ? `Context: ${context}\n` : ''}${operatorComment ? `Operator Comment: ${operatorComment}\n` : ''}${reference ? `Reference: ${reference}` : ''}`.trim();
    const interpretation = renderInterpretationLines({
      sourceRail: 'vivi-command',
      title,
      summary,
      rawText: `${rawRequest}\n${combinedContext}`.trim(),
      context,
      desiredOutcome,
      priority,
    });

    await appendBlock(
      PATHS.VIVI_COMMAND_QUEUE,
      '# Vivi Command Queue\n\nDirect operator and Codex-to-Vivi command packets staged by LIONCOM.\n\n',
      `### ${entryId}\n- Added: ${now}\n- Source: Mission Control App\n- Status: queued\n- Priority: ${priority}\n- Category: ${category}\n- Title: ${title}\n- Target: Vivi\n- Context: ${context || 'Direct LIONCOM mission command'}\n- Reference: ${reference || 'None supplied'}\n- Delivery: local-queue\n- Summary: ${summary}\n- Desired Outcome: ${desiredOutcome || 'Interpret, decompose, execute safely and report back with clear status.'}\n${interpretation}\n${operatorComment ? `- Operator Comment: ${operatorComment}\n` : ''}- Raw Request:\n${quoteBlock(rawRequest)}\n\n`,
    );

    await appendBlock(
      PATHS.WORK_INTAKE,
      '# Work Intake\n\nControlled queue for requests that Vivi should interpret, split into work blocks and turn into concrete subtasks.\n\n',
      `### ${entryId}\n- Added: ${now}\n- Source: Mission Control App\n- Status: new\n- Urgency: ${priority}\n- Category: ${category}\n- Title: ${title}\n- Desired Outcome: ${desiredOutcome || 'Interpret, decompose, execute safely and report back with clear status.'}\n- Summary: ${summary}\n${interpretation}\n- Raw Request:\n${quoteBlock(`${rawRequest}${context ? `\n\nContext: ${context}` : ''}${operatorComment ? `\n\nOperator Comment: ${operatorComment}` : ''}${reference ? `\n\nReference: ${reference}` : ''}`)}\n\n`,
    );

    await syncAllControlPlanes();
    return redirectTo(request, redirectTab, 'vivi-command');
  }

  const title = clean(formData.get('title'));
  const problem = clean(formData.get('problem'));
  const source = clean(formData.get('source'));
  const recommendation = clean(formData.get('recommendation'));
  const severity = clean(formData.get('severity')) || 'critical';
  const mode = clean(formData.get('mode')) || 'rescue';

  if (!title || !problem) {
    return NextResponse.json({ error: 'Missing repair title or problem' }, { status: 400 });
  }

  const entryId = slugTimestamp('FIX');
  const summary = summarize(problem, title);
  const interpretation = renderInterpretationLines({
    sourceRail: 'repair-queue',
    title,
    summary,
    rawText: problem,
    context: source,
    priority: severity,
  });

  await appendBlock(
    PATHS.REPAIR_QUEUE,
    '# Repair Queue\n\nOperational repair and rescue packets generated by LIONCOM when visibility, runtime safety or core rails need attention.\n\n',
    `### ${entryId}\n- Added: ${now}\n- Source: Mission Control App\n- Status: queued\n- Severity: ${severity}\n- Mode: ${mode}\n- Title: ${title}\n- Summary: ${summary}\n- Target: Vivi\n- Recommendation: ${recommendation || 'Analyze root cause, restore safe operation, then report status clearly.'}\n${interpretation}\n- Problem:\n${quoteBlock(problem)}\n- Detected From: ${source || 'LIONCOM alert deck'}\n\n`,
  );

  await appendBlock(
    PATHS.WORK_INTAKE,
    '# Work Intake\n\nControlled queue for requests that Vivi should interpret, split into work blocks and turn into concrete subtasks.\n\n',
    `### ${entryId}\n- Added: ${now}\n- Source: Mission Control App\n- Status: new\n- Urgency: ${severity === 'critical' ? 'critical' : 'high'}\n- Title: ${title}\n- Desired Outcome: Restore safe visibility or operation and report what changed.\n- Summary: ${summary}\n${interpretation}\n- Raw Request:\n${quoteBlock(`${problem}\n\nRecommendation: ${recommendation || 'Analyze, fix, verify.'}\nSource: ${source || 'LIONCOM alert deck'}\nMode: ${mode}`)}\n\n`,
  );

  await syncAllControlPlanes();
  return redirectTo(request, redirectTab, 'repair-request');
}
