export default function NotFound() {
  return (
    <main style={{ padding: 24, fontFamily: 'ui-sans-serif, system-ui' }}>
      <h1 style={{ margin: 0, fontSize: 20, fontWeight: 600 }}>Seite nicht gefunden</h1>
      <p style={{ marginTop: 12, color: 'rgba(0,0,0,0.72)', maxWidth: 640 }}>
        Diese Route existiert in dieser lokalen Preview nicht (oder wurde zurückgestellt).
      </p>
      <ul style={{ marginTop: 16, paddingLeft: 18 }}>
        <li>
          <a href="/">Zur Startseite</a>
        </li>
        <li>
          <a href="/membership">Zur Quellwert-Preview</a>
        </li>
      </ul>
    </main>
  );
}
