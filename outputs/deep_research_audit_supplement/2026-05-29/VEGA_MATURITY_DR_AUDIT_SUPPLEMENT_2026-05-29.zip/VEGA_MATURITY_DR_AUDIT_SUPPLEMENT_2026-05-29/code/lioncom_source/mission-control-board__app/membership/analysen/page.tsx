import { getAnalysisGateSummary, getPublicAnalyses } from '@/lib/quellwert/analysisCatalog';
import { QuellwertPaperFooter } from '@/components/quellwert/quellwert-paper-footer';
import { QuellwertPaperHeader } from '@/components/quellwert/quellwert-paper-header';
import type { Metadata } from 'next';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export const metadata: Metadata = {
  title: 'Analysen | Quellwert',
  description:
    'Öffentliche Pilot-Entwürfe mit Quellenlogik und Gate-Status. Research-Notizen, keine Anlageberatung und keine Handlungsanweisung.',
};

export default function QuellwertAnalysenPage() {
  const analyses = getPublicAnalyses();

  return (
    <main className="qw-page qwp-page" id="qwp-main" tabIndex={-1} lang="de">
      <QuellwertPaperHeader current="analysen" />
      <div id="qwp-content" tabIndex={-1} role="region" aria-label="Inhalt">
        <section className="qwp-hero qwp-narrow">
          <p className="qwp-kicker">Analysen</p>
          <h1>Research-Agent-Piloten mit öffentlicher Quellenlogik.</h1>
          <p>
            Diese Oberfläche zeigt nur Kandidaten, die im lokalen Pilot-v1-Paket
            ein Public-Preview-Gate erreicht haben. Jeder Artikel bleibt eine
            Research-Notiz, keine Anlageberatung und keine Handlungsanweisung.
          </p>
        </section>

        <section className="qwp-narrow" aria-label="Schnellzugriff">
          <nav className="qwp-toc" aria-labelledby="qwp-quick-title">
            <p className="qwp-kicker" id="qwp-quick-title">
              Schnellzugriff
            </p>
            <ul>
              <li>
                <a href="/membership">Start</a>
              </li>
              <li>
                <a aria-current="page" href="/membership/analysen">
                  Analysen
                </a>
              </li>
              <li>
                <a href="/membership/methodik">Methodik</a>
              </li>
              <li>
                <a href="/membership/archiv">Archiv</a>
              </li>
              <li>
                <a href="/membership/verifier">Verifier</a>
              </li>
            </ul>
          </nav>
        </section>

        <section className="qwp-analysis-grid" aria-label="Öffentliche Analyse-Entwürfe">
          {analyses.map((analysis) => {
            const gate = getAnalysisGateSummary(analysis);

            return (
              <article className="qwp-analysis-tile" key={analysis.slug}>
                <div className="qwp-tile-meta">
                  <span>{analysis.ticker}</span>
                  <span>{analysis.asOfDate}</span>
                </div>
                <h2>{analysis.title}</h2>
                <p>{analysis.subtitle}</p>
                <dl>
                  <div>
                    <dt>Qualität</dt>
                    <dd>{analysis.qualityScore}/100</dd>
                  </div>
                  <div>
                    <dt>Status</dt>
                    <dd>{analysis.displayStatus}</dd>
                  </div>
                  <div>
                    <dt>Quellen</dt>
                    <dd>{analysis.sourceCount} Pakete</dd>
                  </div>
                </dl>
                <div className="qwp-tile-gate" aria-label={`${analysis.ticker} Gate-Status`}>
                  <span>{gate.sourceLabel}</span>
                  <span>{gate.reviewLabel}</span>
                  <span>{gate.externalLabel}</span>
                </div>
                <a
                  className="qwp-link"
                  href={`/membership/analysen/${analysis.slug}`}
                  aria-label={`Analyse öffnen: ${analysis.shortName} (${analysis.ticker})`}
                >
                  Analyse öffnen <span aria-hidden="true">→</span>
                </a>
              </article>
            );
          })}
        </section>

        <QuellwertPaperFooter />
      </div>
    </main>
  );
}
