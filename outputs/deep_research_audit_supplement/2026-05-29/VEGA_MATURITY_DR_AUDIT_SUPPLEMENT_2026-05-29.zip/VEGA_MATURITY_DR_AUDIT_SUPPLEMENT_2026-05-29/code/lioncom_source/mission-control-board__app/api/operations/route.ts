// Operations API - Liefert Operations-Status
// Read-only, keine Secrets

import { mapOperations } from '@/lib/mappers/operationsMapper';
import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const operations = await mapOperations();
    return NextResponse.json(operations);
  } catch {
    return NextResponse.json(
      { error: 'Operations-Status nicht verfügbar' },
      { status: 503 }
    );
  }
}
