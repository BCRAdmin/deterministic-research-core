import { NextRequest, NextResponse } from 'next/server';

import { claimNextAutonomyTask, completeAutonomyClaim, escalateAutonomyClaimToCodex, heartbeatAutonomyClaim, releaseAutonomyClaim, syncAutonomyState } from '@/lib/services/autonomyService';
import { syncAllControlPlanes } from '@/lib/services/controlPlaneSyncService';
import { readViviBridgeSnapshot } from '@/lib/services/viviBridgeService';

export const dynamic = 'force-dynamic';

async function getContext() {
  const vivi = await readViviBridgeSnapshot();
  const controlSync = await syncAllControlPlanes({
    viviRuntime: vivi.runtime,
    viviState: vivi.state,
  });

  return {
    viviRuntime: vivi.runtime,
    viviState: vivi.state,
    remoteBridge: controlSync.remoteBridge,
    githubSync: controlSync.githubSync,
    codexRuntime: controlSync.codexRuntime,
    workEngine: controlSync.workEngine,
  };
}

export async function GET() {
  try {
    const context = await getContext();
    const state = await syncAutonomyState(context);
    return NextResponse.json(state);
  } catch {
    return NextResponse.json({ error: 'Autonomy state unavailable' }, { status: 503 });
  }
}

export async function POST(request: NextRequest) {
  let payload: {
    action?: 'sync' | 'claim-next' | 'heartbeat' | 'complete' | 'release' | 'escalate';
    agent?: 'vivi' | 'codex';
    claimId?: string;
    note?: string;
    outcome?: string;
    summary?: string;
    packet?: string;
    title?: string;
  };

  try {
    payload = (await request.json()) as typeof payload;
  } catch {
    return NextResponse.json({ error: 'Invalid JSON payload' }, { status: 400 });
  }

  const action = payload.action || 'sync';

  try {
    const context = await getContext();

    if (action === 'sync') {
      const state = await syncAutonomyState(context);
      return NextResponse.json({ ok: true, action, state });
    }

    if (action === 'claim-next') {
      if (!payload.agent) {
        return NextResponse.json({ error: 'agent is required for claim-next' }, { status: 400 });
      }
      const result = await claimNextAutonomyTask({ ...context, agent: payload.agent });
      return NextResponse.json({ ok: true, action, ...result });
    }

    if (action === 'heartbeat') {
      if (!payload.agent || !payload.claimId) {
        return NextResponse.json({ error: 'agent and claimId are required for heartbeat' }, { status: 400 });
      }
      const state = await heartbeatAutonomyClaim({
        ...context,
        agent: payload.agent,
        claimId: payload.claimId,
        note: payload.note,
      });
      return NextResponse.json({ ok: true, action, state });
    }

    if (action === 'complete') {
      if (!payload.agent || !payload.claimId) {
        return NextResponse.json({ error: 'agent and claimId are required for complete' }, { status: 400 });
      }
      const state = await completeAutonomyClaim({
        ...context,
        agent: payload.agent,
        claimId: payload.claimId,
        outcome: payload.outcome,
        note: payload.note,
      });
      return NextResponse.json({ ok: true, action, state });
    }

    if (action === 'release') {
      if (!payload.agent || !payload.claimId) {
        return NextResponse.json({ error: 'agent and claimId are required for release' }, { status: 400 });
      }
      const state = await releaseAutonomyClaim({
        ...context,
        agent: payload.agent,
        claimId: payload.claimId,
        reason: payload.note,
      });
      return NextResponse.json({ ok: true, action, state });
    }

    if (action === 'escalate') {
      if (!payload.claimId || !payload.summary?.trim() || !payload.packet?.trim()) {
        return NextResponse.json({ error: 'claimId, summary and packet are required for escalate' }, { status: 400 });
      }
      const state = await escalateAutonomyClaimToCodex({
        ...context,
        claimId: payload.claimId,
        summary: payload.summary,
        packet: payload.packet,
        title: payload.title,
      });
      return NextResponse.json({ ok: true, action, state });
    }

    return NextResponse.json({ error: 'Unsupported autonomy action' }, { status: 400 });
  } catch {
    return NextResponse.json({ error: 'Autonomy action failed' }, { status: 500 });
  }
}
