import { spawn } from 'child_process';
import { promises as fs } from 'fs';
import path from 'path';

import { NextRequest, NextResponse } from 'next/server';

import { PATHS, WORKSPACE_ROOT } from '@/lib/constants/paths';
import { syncAllControlPlanes } from '@/lib/services/controlPlaneSyncService';
import { readDesktopSettings, saveDesktopSettings } from '@/lib/services/desktopSettingsService';
import { startLocalDuoLoop, type LocalViviStartResult } from '@/lib/services/localViviRunnerService';
import { appendRailBlock, ensureRailFile, parseRailBlocks, readRailContent } from '@/lib/services/structuredRailService';
import {
  normalizeViviProviderMode,
  normalizeViviProviderPreset,
  normalizeViviRequestedModel,
  type ViviProviderMode,
  type ViviProviderPreset,
} from '@/lib/vivi-model-catalog';
import { routeViviCapability } from '@/lib/vivi-skills/capability-router';
import { runViviSkill } from '@/lib/vivi-skills/runtime';
import type { CapabilityRouteDecision, ViviSkillRun } from '@/lib/vivi-skills/types';

type ViviChatRole = 'operator' | 'vivi' | 'system';
type ViviChatStatus = 'idle' | 'waiting' | 'reported' | 'attention';
type ViviChatAction = 'archive-session' | 'create-session' | 'delete-session' | 'remove-session' | 'start-local-vivi' | 'send-message' | 'update-session';

interface ViviChatSession {
  id: string;
  title: string;
  topic: string;
  createdAt: string;
  updatedAt: string;
  providerMode: ViviProviderMode;
  providerPreset: ViviProviderPreset;
  requestedModel: string;
  lastMessagePreview: string;
  lastReference: string;
  status: ViviChatStatus;
  latestActivity: string;
}

interface ViviChatMessage {
  id: string;
  sessionId: string;
  addedAt: string;
  role: ViviChatRole;
  status: string;
  summary: string;
  message: string;
  source?: string;
  reference?: string;
  providerMode: ViviProviderMode;
  providerPreset: ViviProviderPreset;
  requestedModel?: string;
  derivedFrom: 'chat-thread' | 'vivi-report';
}

interface ViviReportBlock {
  id: string;
  addedAt: string;
  state: string;
  title: string;
  commandRef?: string;
  summary: string;
  outcome?: string;
  nextStep?: string;
  operatorAction?: string;
}

interface ViviChatPayload {
  action?: string;
  sessionId?: string;
  title?: string;
  topic?: string;
  message?: string;
  reason?: string;
  source?: string;
  providerMode?: string;
  providerPreset?: string;
  requestedModel?: string;
  applyToRuntime?: boolean;
  autoStart?: boolean;
  confirmEmpty?: boolean;
}

interface ArchivedViviChatSession {
  archivedAt: string;
  action: 'archived' | 'removed-empty' | 'legacy-hidden';
  reason: string;
  session: ViviChatSession;
}

interface RecoveredSessionSeed {
  id: string;
  title: string;
  topic: string;
  createdAt: string;
  updatedAt: string;
  providerMode: ViviProviderMode;
  providerPreset: ViviProviderPreset;
  requestedModel: string;
  lastMessagePreview: string;
  lastReference: string;
  status: ViviChatStatus;
  latestActivity: string;
}

interface SentViviMessage {
  commandRef: string;
  message: string;
  queuedAsTask: boolean;
  route: CapabilityRouteDecision;
  session: ViviChatSession;
  snapshot: Awaited<ReturnType<typeof buildSnapshot>>;
  summary: string;
}

interface DirectViviReply {
  ok: boolean;
  message: string;
  provider: string;
  model: string;
  detail: string;
}

const VIVI_CHAT_THREAD_HEADER = '# Vivi Chat Thread\n\nAppend-only board-first conversation rail between operator and Vivi.\n\n';
const VIVI_COMMAND_QUEUE_HEADER = '# Vivi Command Queue\n\nDirect operator and Codex-to-Vivi command packets staged by LIONCOM.\n\n';
const WORK_INTAKE_HEADER = '# Work Intake\n\nControlled queue for requests that Vivi should interpret, split into work blocks and turn into concrete subtasks.\n\n';
const ANALYSIS_CHAT_ARCHIVE_DIR = path.join(PATHS.ROOM16_REPORTS_DIR, '_LION Vivi Analysis Chats');
const VIVI_CHAT_SESSIONS_ARCHIVE = path.join(WORKSPACE_ROOT, 'VIVI_CHAT_SESSIONS_ARCHIVE.json');
const MAX_SESSIONS = 60;
const MAX_TITLE_LENGTH = 96;
const MAX_TOPIC_LENGTH = 280;
const MAX_MESSAGE_LENGTH = 8000;
const MAX_MODEL_LENGTH = 120;
const STALE_WAITING_MS = 8 * 60 * 60 * 1000;
const DIRECT_CHAT_HISTORY_LIMIT = 10;
const DIRECT_CHAT_TIMEOUT_MS = 20_000;
const CODEX_CHAT_TIMEOUT_MS = 75_000;
let viviChatMutationQueue: Promise<void> = Promise.resolve();

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function GET() {
  try {
    return NextResponse.json(await buildSnapshot());
  } catch {
    return NextResponse.json({ error: 'Vivi chat unavailable' }, { status: 503 });
  }
}

export async function POST(request: NextRequest) {
  let payload: ViviChatPayload;
  try {
    payload = await request.json();
  } catch {
    return NextResponse.json({ error: 'Ungültige JSON-Daten.' }, { status: 400 });
  }

  return withViviChatMutationLock(() => handleViviChatPost(payload));
}

async function handleViviChatPost(payload: ViviChatPayload) {
  try {
    const action = normalizeAction(payload.action);
    if (payload.action && !action) {
      return NextResponse.json({ error: 'Unbekannte Vivi-Chat-Aktion.' }, { status: 400 });
    }

    if (payload.action === 'create-session') {
      return NextResponse.json({ ok: true, snapshot: await createSession(payload) });
    }

    if (payload.action === 'update-session') {
      if (!payload.sessionId?.trim()) {
        return NextResponse.json({ error: 'Session-ID fehlt.' }, { status: 400 });
      }

      return NextResponse.json({ ok: true, snapshot: await updateSession(payload) });
    }

    if (payload.action === 'archive-session') {
      if (!payload.sessionId?.trim()) {
        return NextResponse.json({ error: 'Session-ID fehlt.' }, { status: 400 });
      }

      return NextResponse.json({ ok: true, snapshot: await archiveSession(payload.sessionId, payload.reason) });
    }

    if (payload.action === 'remove-session') {
      if (!payload.sessionId?.trim()) {
        return NextResponse.json({ error: 'Session-ID fehlt.' }, { status: 400 });
      }

      return NextResponse.json({ ok: true, snapshot: await removeEmptySession(payload.sessionId, Boolean(payload.confirmEmpty), payload.reason) });
    }

    if (payload.action === 'delete-session') {
      if (!payload.sessionId?.trim()) {
        return NextResponse.json({ error: 'Session-ID fehlt.' }, { status: 400 });
      }

      return NextResponse.json({ ok: true, snapshot: await deleteSession(payload.sessionId, payload.reason) });
    }

    if (payload.action === 'start-local-vivi') {
      const result = await startLocalVivi(payload.sessionId);
      return NextResponse.json({ ok: result.ok, start: result, snapshot: await buildSnapshot() });
    }

    if (action && action !== 'send-message') {
      return NextResponse.json({ error: 'Für diese Vivi-Aktion fehlt noch eine sichere Ausführung.' }, { status: 400 });
    }

    if (!payload.sessionId?.trim() || !cleanMessage(payload.message)) {
      return NextResponse.json({ error: 'Session oder Nachricht fehlt.' }, { status: 400 });
    }

    const sent = await sendMessage(payload);
    if (sent.route.kind === 'use_skill' && sent.route.skillId) {
      const run = await runViviSkill({
        skillId: sent.route.skillId,
        sessionId: sent.session.id,
        commandRef: sent.commandRef,
        operatorMessage: sent.message,
        source: 'Vivi Chat Capability Router',
        requestedBy: 'operator',
      });
      await appendViviSkillRunReply(sent, run);
      return NextResponse.json({ ok: run.status !== 'failed', snapshot: await buildSnapshot(), skillRun: run });
    }

    if (sent.route.kind === 'handoff_vega') {
      const run = await runViviSkill({
        skillId: sent.route.skillId || 'vega.handoff.create',
        sessionId: sent.session.id,
        commandRef: sent.commandRef,
        operatorMessage: sent.message,
        source: 'Vivi Chat Capability Router',
        requestedBy: 'operator',
      });
      await appendViviSkillRunReply(sent, run);
      return NextResponse.json({ ok: run.status !== 'failed', snapshot: await buildSnapshot(), skillRun: run });
    }

    if (sent.route.kind === 'missing_skill') {
      const run = await runViviSkill({
        skillId: sent.route.skillId || 'vivi.skill.propose',
        sessionId: sent.session.id,
        commandRef: sent.commandRef,
        operatorMessage: sent.message,
        source: 'Vivi Chat Capability Router',
        requestedBy: 'operator',
        payload: {
          capability: sent.route.capability,
          reason: sent.route.operatorMessage,
        },
      });
      await appendViviSkillRunReply(sent, run);
      return NextResponse.json({ ok: run.status !== 'failed', snapshot: await buildSnapshot(), skillRun: run });
    }

    if (sent.route.kind === 'operator_gate') {
      await appendViviRouteGateReply(sent);
      return NextResponse.json({ ok: true, snapshot: await buildSnapshot() });
    }

    const directReply = await generateDirectViviReply(sent);
    await appendViviDirectReply(sent, directReply);
    const start = payload.autoStart === false || directReply.ok || !sent.queuedAsTask || !sent.route.shouldStartViviLoop ? undefined : await startLocalViviLoop();
    if (payload.autoStart !== false && !directReply.ok && sent.queuedAsTask) {
      await appendViviDeliveryNotice(sent, start);
    }
    return NextResponse.json({ ok: true, snapshot: await buildSnapshotAfterOptionalStart(await buildSnapshot(), start), start });
  } catch (error) {
    if (error instanceof Error && error.message === 'session-not-found') {
      return NextResponse.json({ error: 'Session wurde nicht gefunden.' }, { status: 404 });
    }

    if (error instanceof Error && error.message === 'message-required') {
      return NextResponse.json({ error: 'Nachricht fehlt.' }, { status: 400 });
    }

    if (error instanceof Error && error.message === 'session-not-empty') {
      return NextResponse.json({
        error: 'Diese Session hat bereits Operator- oder Vivi-Inhalt. Bitte archivieren statt entfernen.',
      }, { status: 409 });
    }

    return NextResponse.json({ error: 'Vivi-Chat konnte nicht aktualisiert werden.' }, { status: 500 });
  }
}

async function withViviChatMutationLock<T>(operation: () => Promise<T>): Promise<T> {
  const run = viviChatMutationQueue.then(operation, operation);
  viviChatMutationQueue = run.then(
    () => undefined,
    () => undefined,
  );
  return run;
}

async function buildSnapshot() {
  const [sessions, chatThread, reportThread] = await Promise.all([
    readSessions(),
    readRailContent(PATHS.VIVI_CHAT_THREAD),
    readRailContent(PATHS.VIVI_REPORTS),
  ]);
  const chatMessages = parseRailBlocks(chatThread)
    .map(parseChatMessageBlock)
    .filter((entry): entry is ViviChatMessage => Boolean(entry))
    .sort((left, right) => compareDatesAsc(left.addedAt, right.addedAt));
  const stitchedReports = stitchReportsIntoChat(chatMessages, parseViviReportBlocks(reportThread));
  const messages = [...chatMessages, ...stitchedReports]
    .sort((left, right) => compareDatesAsc(left.addedAt, right.addedAt) || left.id.localeCompare(right.id));
  const hydratedSessions = sessions
    .map((session) => hydrateSession(session, messages))
    .sort((left, right) => compareDatesAsc(right.updatedAt, left.updatedAt) || left.title.localeCompare(right.title));

  return {
    sessions: hydratedSessions,
    messages,
    activeSessionId: hydratedSessions[0]?.id,
  };
}

async function createSession(payload: ViviChatPayload) {
  const now = new Date().toISOString();
  const settings = await readDesktopSettings();
  const providerPreset = normalizeProviderPreset(payload.providerPreset || settings.viviProviderPreset);
  const providerMode = normalizeProviderMode(payload.providerMode, providerPreset);
  const requestedModel = normalizeRequestedModel(providerPreset, payload.requestedModel ?? settings.viviRequestedModel, providerMode);
  const session: ViviChatSession = {
    id: slugTimestamp('VIVISESSION', now),
    title: clean(payload.title, MAX_TITLE_LENGTH) || 'Neuer Vivi-Chat',
    topic: clean(payload.topic, MAX_TOPIC_LENGTH) || 'Allgemeiner Vivi-Dialog',
    createdAt: now,
    updatedAt: now,
    providerMode,
    providerPreset,
    requestedModel,
    lastMessagePreview: '',
    lastReference: '',
    status: 'idle',
    latestActivity: 'Noch keine Nachricht gesendet.',
  };
  const sessions = await readSessions();

  await writeSessions([session, ...sessions].slice(0, MAX_SESSIONS));
  await appendSystemMessage(session, buildViviBootContext(session), 'boot-context');
  await writeRuntimeWish(session);
  await syncAllControlPlanes();
  return buildSnapshot();
}

async function updateSession(payload: ViviChatPayload) {
  const sessions = await readSessions();
  const existing = sessions.find((session) => session.id === payload.sessionId);
  if (!existing) throw new Error('session-not-found');

  const updated = patchSession(existing, payload);
  await writeSessions(sessions.map((session) => session.id === existing.id ? updated : session));

  if (payload.applyToRuntime) {
    await writeRuntimeWish(updated);
  }

  await syncAllControlPlanes();
  return buildSnapshot();
}

async function archiveSession(sessionId: string, reason?: string) {
  const sessions = await readSessions();
  const existing = sessions.find((session) => session.id === sessionId);
  if (!existing) throw new Error('session-not-found');

  const archiveReason = clean(reason, 240) || 'Operator hat die Session aus der aktiven Vivi-Liste archiviert.';
  await appendSystemMessage(existing, [
    `Session "${existing.title}" wurde archiviert.`,
    `Grund: ${archiveReason}`,
    'Der append-only Rail-Verlauf bleibt im Workspace erhalten; die Session wird nur aus der aktiven V2-Liste ausgeblendet.',
  ].join('\n'), 'session-archived');
  await appendArchivedSession(existing, 'archived', archiveReason);
  await writeSessions(sessions.filter((session) => session.id !== existing.id));
  await syncAllControlPlanes();
  return buildSnapshot();
}

async function removeEmptySession(sessionId: string, confirmEmpty: boolean, reason?: string) {
  const sessions = await readSessions();
  const existing = sessions.find((session) => session.id === sessionId);
  if (!existing) throw new Error('session-not-found');

  const hasWorkContent = await sessionHasOperatorOrViviContent(existing);
  if (!confirmEmpty || hasWorkContent) {
    throw new Error('session-not-empty');
  }

  const archiveReason = clean(reason, 240) || 'Leere Test-/Arbeits-Session aus der aktiven Vivi-Liste entfernt.';
  await appendSystemMessage(existing, [
    `Leere Session "${existing.title}" wurde entfernt.`,
    `Grund: ${archiveReason}`,
    'Es wurden keine Operator- oder Vivi-Nachrichten gefunden; der System-Hinweis bleibt im Rail nachvollziehbar.',
  ].join('\n'), 'session-removed-empty');
  await appendArchivedSession(existing, 'removed-empty', archiveReason);
  await writeSessions(sessions.filter((session) => session.id !== existing.id));
  await syncAllControlPlanes();
  return buildSnapshot();
}

async function deleteSession(sessionId: string, reason?: string) {
  return archiveSession(sessionId, reason || 'Legacy delete-session wurde als sichere Archivierung behandelt.');
}

async function startLocalVivi(sessionId?: string): Promise<LocalViviStartResult> {
  const sessions = await readSessions();
  const session = sessionId ? sessions.find((entry) => entry.id === sessionId) : sessions[0];
  if (!session) {
    return { ok: false, mode: 'unavailable', detail: 'Keine Vivi-Session vorhanden. Lege zuerst einen Vivi-Chat an.' };
  }

  await appendSystemMessage(session, [
    'Lokaler Vivi-Start wurde vom Operator angefordert.',
    '',
    buildViviBootContext(session),
  ].join('\n'), 'local-start');

  const launchResult = await startLocalViviLoop();
  await appendViviStartNotice(session, launchResult);
  await syncAllControlPlanes();
  return launchResult;
}

async function startLocalViviLoop(): Promise<LocalViviStartResult> {
  return startLocalDuoLoop();
}

async function buildSnapshotAfterOptionalStart(snapshot: Awaited<ReturnType<typeof buildSnapshot>>, start?: LocalViviStartResult) {
  if (!start) return snapshot;
  await syncAllControlPlanes();
  return buildSnapshot();
}

async function sendMessage(payload: ViviChatPayload): Promise<SentViviMessage> {
  const sessions = await readSessions();
  const existing = sessions.find((session) => session.id === payload.sessionId);
  if (!existing) throw new Error('session-not-found');

  const message = cleanMessage(payload.message);
  if (!message) throw new Error('message-required');

  const session = patchSession(existing, payload);
  const now = new Date().toISOString();
  const commandRef = slugTimestamp('VCHATCMD', now);
  const messageId = slugTimestamp('VCHAT', now);
  const summary = summarize(message, session.title);
  const source = clean(payload.source) || 'Mission Control App';
  const topic = session.topic || 'Vivi chat session';
  const requestedModel = session.requestedModel || normalizeRequestedModel(session.providerPreset, undefined, session.providerMode);
  const route = routeViviCapability({ message, sessionTitle: session.title, sessionTopic: session.topic });
  const queuedAsTask = route.queueAsTask;
  const chatBlock = [
    `### ${messageId}`,
    `- Added: ${now}`,
    `- Session Id: ${session.id}`,
    `- Session Title: ${session.title}`,
    '- Role: operator',
    '- Status: queued',
    `- Source: ${source}`,
    `- Provider Mode: ${session.providerMode}`,
    `- Provider Preset: ${session.providerPreset}`,
    `- Requested Model: ${requestedModel}`,
    `- Reference: ${commandRef}`,
    `- Capability Route: ${route.kind}`,
    `- Capability: ${route.capability}`,
    `- Target Agent: ${route.targetAgent}`,
    route.skillId ? `- Skill Id: ${route.skillId}` : null,
    `- Summary: ${summary}`,
    '- Message:',
    ...quoteLines(message),
    '',
  ].join('\n');
  const queueBlock = queuedAsTask ? [
    `### ${commandRef}`,
    `- Added: ${now}`,
    '- Source: Mission Control App',
    '- Status: queued',
    '- Priority: normal',
    '- Category: chat-session',
    '- Project Lane: lioncom-core',
    '- Resource Class: heavy-local-llm',
    '- Parallel Policy: global-heavy-singleton',
    `- Title: ${session.title}`,
    '- Target: Vivi',
    `- Context: ${topic}`,
    `- Session Id: ${session.id}`,
    '- Delivery: local-queue',
    `- Reference: ${commandRef}`,
    `- Summary: ${summary}`,
    '- Desired Outcome: Antwort im Vivi-Chat oder sichtbarer naechster Schritt fuer dieses Thema.',
    `- Provider Mode: ${session.providerMode}`,
    `- Provider Preset: ${session.providerPreset}`,
    `- Requested Model: ${requestedModel}`,
    '- Auto Boot Context:',
    ...quoteLines(buildViviBootContext(session)),
    '- Raw Request:',
    ...quoteLines(message),
    '',
  ].join('\n') : '';
  const intakeBlock = queuedAsTask ? [
    `### ${commandRef}`,
    `- Added: ${now}`,
    '- Source: Mission Control App',
    '- Status: new',
    '- Urgency: normal',
    '- Category: chat-session',
    '- Project Lane: lioncom-core',
    '- Resource Class: heavy-local-llm',
    '- Parallel Policy: global-heavy-singleton',
    `- Title: ${session.title}`,
    '- Desired Outcome: Antwort im Vivi-Chat oder sichtbarer naechster Schritt fuer dieses Thema.',
    `- Summary: ${summary}`,
    `- Session Id: ${session.id}`,
    `- Provider Mode: ${session.providerMode}`,
    `- Provider Preset: ${session.providerPreset}`,
    `- Requested Model: ${requestedModel}`,
    '- Raw Request:',
    ...quoteLines([
      message,
      '',
      `Topic: ${topic}`,
      `Session Id: ${session.id}`,
      `Provider Mode: ${session.providerMode}`,
      `Provider Preset: ${session.providerPreset}`,
      `Requested Model: ${requestedModel}`,
      '',
      buildViviBootContext(session),
    ].join('\n')),
    '',
  ].join('\n') : '';
  const persistedSession = {
    ...session,
    updatedAt: now,
    lastMessagePreview: summary,
    lastReference: commandRef,
    status: 'waiting' as const,
    latestActivity: 'Wartet auf Vivi.',
  };

  const writes = [appendRailBlock(PATHS.VIVI_CHAT_THREAD, VIVI_CHAT_THREAD_HEADER, `${chatBlock}\n`)];
  if (queuedAsTask) {
    writes.push(
      appendRailBlock(PATHS.VIVI_COMMAND_QUEUE, VIVI_COMMAND_QUEUE_HEADER, `${queueBlock}\n`),
      appendRailBlock(PATHS.WORK_INTAKE, WORK_INTAKE_HEADER, `${intakeBlock}\n`),
    );
  }
  await Promise.all(writes);
  await persistAnalysisChatArchive({
    commandRef,
    message,
    messageId,
    now,
    requestedModel,
    session,
    source,
    summary,
    topic,
  });
  await writeSessions(sessions.map((item) => item.id === existing.id ? persistedSession : item));
  await writeRuntimeWish(persistedSession);
  await syncAllControlPlanes();
  return {
    commandRef,
    message,
    queuedAsTask,
    route,
    session: persistedSession,
    snapshot: await buildSnapshot(),
    summary,
  };
}

async function appendSystemMessage(session: ViviChatSession, message: string, status: string) {
  const now = new Date().toISOString();
  const messageId = slugTimestamp('VCHATSYS', now);
  const block = [
    `### ${messageId}`,
    `- Added: ${now}`,
    `- Session Id: ${session.id}`,
    `- Session Title: ${session.title}`,
    '- Role: system',
    `- Status: ${status}`,
    '- Source: LIONCOM Control Plane V2',
    `- Provider Mode: ${session.providerMode}`,
    `- Provider Preset: ${session.providerPreset}`,
    `- Requested Model: ${session.requestedModel}`,
    `- Reference: ${session.id}`,
    '- Summary: Automatischer Vivi-Kontext',
    '- Message:',
    ...quoteLines(message),
    '',
  ].join('\n');

  await appendRailBlock(PATHS.VIVI_CHAT_THREAD, VIVI_CHAT_THREAD_HEADER, `${block}\n`);
}

async function appendViviDeliveryNotice(sent: SentViviMessage, start?: LocalViviStartResult) {
  const startLine = start
    ? start.ok
      ? `Lokaler Startstatus: ${start.detail || 'Vivi-Runner ist aktiv oder wurde gestartet.'}`
      : `Start braucht Aufmerksamkeit: ${start.detail || 'Der lokale Vivi-Runner konnte nicht eindeutig gestartet werden.'}`
    : 'Lokaler Startstatus: nicht automatisch angefordert.';
  await appendViviMessage(sent.session, {
    message: [
      'Ich bin da. Deine Nachricht ist in dieser Vivi-Session angekommen und wurde lokal in die Vivi-Queue gelegt.',
      startLine,
      'Wenn bereits ein Vivi-Lauf aktiv ist, bleibt diese Session sichtbar und die Nachricht wird ueber dieselbe Referenz weiterverarbeitet.',
      `Referenz: ${sent.commandRef}`,
    ].join('\n'),
    reference: sent.commandRef,
    status: start && !start.ok ? 'action-needed' : 'waiting',
    summary: `Vivi hat deine Nachricht angenommen: ${sent.summary}`,
  });
}

async function appendViviDirectReply(sent: SentViviMessage, reply: DirectViviReply) {
  await appendViviMessage(sent.session, {
    message: reply.message,
    reference: sent.commandRef,
    status: reply.ok ? 'reported' : 'action-needed',
    summary: reply.ok
      ? `Vivi antwortet direkt (${reply.model})`
      : `Vivi konnte nicht direkt antworten (${reply.provider})`,
  });
}

async function appendViviSkillRunReply(sent: SentViviMessage, run: ViviSkillRun) {
  const statusLine = run.status === 'completed'
    ? 'Skill-Lauf abgeschlossen.'
    : run.status === 'missing-provider'
      ? 'Skill-Lauf erkannt, aber ein Provider fehlt.'
      : run.status === 'blocked'
        ? 'Skill-Lauf blockiert.'
        : run.status === 'proposal'
          ? 'Skill-Vorschlag vorbereitet.'
          : 'Skill-Lauf braucht Vega-Prüfung.';
  const artifacts = run.artifacts.length
    ? [
        '',
        'Artefakte:',
        ...run.artifacts.slice(0, 4).map((artifact) => `- ${artifact.label}: ${artifact.value}`),
      ]
    : [];
  await appendViviMessage(sent.session, {
    message: [
      statusLine,
      '',
      run.summary,
      run.detail,
      '',
      `Nächster Schritt: ${run.nextAction}`,
      `Skill-Run: ${run.id}`,
      ...artifacts,
    ].join('\n'),
    reference: run.id,
    status: run.status === 'failed' || run.status === 'blocked' || run.status === 'missing-provider' ? 'action-needed' : 'reported',
    summary: `Vivi Skill: ${run.summary}`,
  });
}

async function appendViviRouteGateReply(sent: SentViviMessage) {
  await appendViviMessage(sent.session, {
    message: [
      'Ich habe deine Nachricht verstanden, aber diese Aktion liegt hinter einem Operator-Gate.',
      '',
      sent.route.gateReason || 'Geschützte Aktionen brauchen eine bewusste Freigabe.',
      '',
      'Ich kann den Kontext vorbereiten und die nächsten sicheren Schritte beschreiben, führe aber keine externen Sends, Credential-/Auth-Änderungen, Geldbewegungen, Löschungen, Production-Deploys oder unbekannten Remote-Code ohne Go aus.',
      `Referenz: ${sent.commandRef}`,
    ].join('\n'),
    reference: sent.commandRef,
    status: 'action-needed',
    summary: 'Operator-Gate erforderlich',
  });
}

async function appendViviStartNotice(session: ViviChatSession, start: LocalViviStartResult) {
  const pending = await latestUnansweredOperatorMessage(session.id);
  await appendViviMessage(session, {
    message: [
      start.ok
        ? 'Vivi-Start ist angekommen. Ich pruefe diese Session lokal und halte die Antwort im Chat sichtbar.'
        : 'Vivi-Start wurde angefragt, aber der lokale Runner braucht Aufmerksamkeit.',
      start.detail ? `Status: ${start.detail}` : null,
      pending
        ? `Offene Operator-Nachricht: ${pending.summary || summarize(pending.message, session.title)}`
        : 'Aktuell liegt keine unbeantwortete Operator-Nachricht in dieser Session.',
      'Du musst nicht erneut senden; neue Nachrichten bleiben in genau dieser Session gebuendelt.',
    ].filter(Boolean).join('\n'),
    reference: pending?.reference || session.lastReference || session.id,
    status: start.ok ? 'waiting' : 'action-needed',
    summary: start.ok ? 'Vivi-Start bestaetigt' : 'Vivi-Start braucht Aufmerksamkeit',
  });
}

async function generateDirectViviReply(sent: SentViviMessage): Promise<DirectViviReply> {
  const model = sent.session.requestedModel || normalizeRequestedModel(sent.session.providerPreset, undefined, sent.session.providerMode);
  const provider = sent.session.providerPreset;
  const messages = await buildDirectViviMessages(sent);

  try {
    if (provider === 'lmstudio') {
      return await callLmStudioResponses({
        endpoint: process.env.LIONCOM_LMSTUDIO_RESPONSES_URL || process.env.OPENAI_RESPONSES_URL || 'http://127.0.0.1:1234/v1/responses',
        messages,
        model,
        provider: 'lmstudio',
      });
    }

    if (provider === 'ollama') {
      return await callOllamaChat({
        endpoint: process.env.LIONCOM_OLLAMA_CHAT_URL || 'http://127.0.0.1:11434/api/chat',
        messages,
        model,
        provider: sent.session.providerMode === 'cloud' ? 'ollama-cloud' : 'ollama',
      });
    }

    if (provider === 'openrouter') {
      const apiKey = process.env.OPENROUTER_API_KEY || process.env.LIONCOM_OPENROUTER_API_KEY;
      if (!apiKey) throw new Error('OpenRouter API-Key fehlt.');
      return await callOpenAiCompatibleChat({
        endpoint: process.env.LIONCOM_OPENROUTER_CHAT_URL || 'https://openrouter.ai/api/v1/chat/completions',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'HTTP-Referer': 'http://127.0.0.1:4107',
          'X-Title': 'LIONCOM Vivi Chat',
        },
        messages,
        model,
        provider: 'openrouter',
      });
    }

    if (provider === 'chatgpt') {
      const chatGptReply = await tryCodexViviChatFallback(sent, 'ChatGPT Cloud nutzt den lokalen Codex-Providerpfad.', model);
      if (chatGptReply.ok) return {
        ...chatGptReply,
        provider: 'chatgpt-codex',
      };

      return {
        ok: false,
        provider,
        model,
        detail: chatGptReply.detail,
        message: [
          'Ich habe deine Nachricht erhalten, aber der ChatGPT-Providerpfad konnte gerade keine direkte Vivi-Antwort erzeugen.',
          `Provider/Modell: ${provider}/${model}`,
          `Grund: ${chatGptReply.detail}`,
          'Stelle Vivi auf LM Studio lokal oder Ollama lokal, falls du offline weiterarbeiten willst.',
        ].join('\n'),
      };
    }

    return {
      ok: false,
      provider,
      model,
      detail: 'ChatGPT/Codex-Cloud ist fuer den lokalen Vivi-Chat noch nicht direkt verdrahtet.',
      message: [
        'Ich habe deine Nachricht erhalten, kann in diesem Provider-Modus aber noch keine direkte lokale Vivi-Antwort erzeugen.',
        'Bitte stelle Vivi vorerst auf LM Studio lokal oder Ollama/Ollama Cloud, damit ich im Chat wirklich antworten kann.',
      ].join('\n'),
    };
  } catch (error) {
    const detail = error instanceof Error ? error.message : String(error);
    const codexFallback = await tryCodexViviChatFallback(sent, detail);
    if (codexFallback.ok) return codexFallback;

    return {
      ok: false,
      provider,
      model,
      detail,
      message: [
        'Ich habe deine Nachricht erhalten, aber die direkte Vivi-Antwort konnte das gewaehlte Modell gerade nicht erreichen.',
        `Provider/Modell: ${provider}/${model}`,
        `Grund: ${detail}`,
        'Ich lege den Kontext sichtbar in dieser Session ab und starte den lokalen Vivi-Loop als Fallback.',
      ].join('\n'),
    };
  }
}

async function tryCodexViviChatFallback(sent: SentViviMessage, localFailure: string, preferredModel?: string): Promise<DirectViviReply> {
  if (process.env.LIONCOM_VIVI_ENABLE_CODEX_CHAT_FALLBACK === 'false') {
    return {
      ok: false,
      provider: 'chatgpt-fallback-disabled',
      model: 'disabled',
      detail: 'Codex-Fallback ist per Env deaktiviert.',
      message: '',
    };
  }

  const codexPath = process.env.LIONCOM_CODEX_BIN || '/Applications/Codex.app/Contents/Resources/codex';
  const model = preferredModel || process.env.LIONCOM_VIVI_CODEX_CHAT_MODEL || 'gpt-5.4-mini';
  const prompt = [
    buildDirectViviSystemPrompt(sent.session),
    '',
    'Lokaler Modellpfad war gerade nicht verfuegbar:',
    localFailure,
    '',
    'Antworte jetzt als Vivi direkt auf die letzte Operator-Nachricht. Keine JSON-Ausgabe, kein Report, keine internen Logs.',
    '',
    `Operator: ${sent.message}`,
  ].join('\n');

  try {
    const output = await runCodexExec(codexPath, model, prompt);
    const message = clean(extractCodexFinalAnswer(output), MAX_MESSAGE_LENGTH);
    if (!message) throw new Error('Codex-Fallback lieferte keine lesbare finale Antwort.');
    return {
      ok: true,
      provider: 'chatgpt-codex-fallback',
      model,
      detail: `local_failed=${localFailure}`,
      message,
    };
  } catch (error) {
    return {
      ok: false,
      provider: 'chatgpt-codex-fallback',
      model,
      detail: error instanceof Error ? error.message : String(error),
      message: '',
    };
  }
}

function runCodexExec(codexPath: string, model: string, prompt: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const child = spawn(codexPath, [
      'exec',
      '--ephemeral',
      '--skip-git-repo-check',
      '--sandbox',
      'read-only',
      '-m',
      model,
      '-',
    ], {
      cwd: WORKSPACE_ROOT,
      env: {
        ...process.env,
        VIVI_WORKSPACE_ROOT: WORKSPACE_ROOT,
        LIONCOM_WORKSPACE_ROOT: WORKSPACE_ROOT,
      },
      stdio: ['pipe', 'pipe', 'pipe'],
    });
    const chunks: string[] = [];
    const timer = setTimeout(() => {
      child.kill('SIGTERM');
      reject(new Error('Codex-Fallback Timeout.'));
    }, CODEX_CHAT_TIMEOUT_MS);

    child.stdout.on('data', (chunk) => chunks.push(String(chunk)));
    child.stderr.on('data', (chunk) => chunks.push(String(chunk)));
    child.on('error', (error) => {
      clearTimeout(timer);
      reject(error);
    });
    child.on('close', (code) => {
      clearTimeout(timer);
      const output = chunks.join('\n');
      if (code === 0) {
        resolve(output);
      } else {
        reject(new Error(`Codex-Fallback Exit ${code ?? 'unknown'}: ${output.slice(-1200)}`));
      }
    });
    child.stdin.end(prompt);
  });
}

function extractCodexFinalAnswer(output: string): string {
  const lines = output
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .filter((line) => !line.match(/^\d{4}-\d{2}-\d{2}T/))
    .filter((line) => !line.startsWith('OpenAI Codex '))
    .filter((line) => !line.startsWith('--------'))
    .filter((line) => !line.startsWith('workdir:'))
    .filter((line) => !line.startsWith('model:'))
    .filter((line) => !line.startsWith('provider:'))
    .filter((line) => !line.startsWith('approval:'))
    .filter((line) => !line.startsWith('sandbox:'))
    .filter((line) => !line.startsWith('reasoning '))
    .filter((line) => !line.startsWith('session id:'))
    .filter((line) => line !== 'user')
    .filter((line) => line !== 'codex')
    .filter((line) => line !== 'tokens used')
    .filter((line) => !line.match(/^[0-9]+(\.[0-9]+)?$/));
  return lines[lines.length - 1] || '';
}

async function buildDirectViviMessages(sent: SentViviMessage): Promise<Array<{ role: 'assistant' | 'system' | 'user'; content: string }>> {
  const content = await readRailContent(PATHS.VIVI_CHAT_THREAD);
  const history = parseRailBlocks(content)
    .map(parseChatMessageBlock)
    .filter((message): message is ViviChatMessage => Boolean(message && message.sessionId === sent.session.id))
    .filter((message) => message.role === 'operator' || message.role === 'vivi')
    .filter((message) => message.reference !== sent.commandRef)
    .sort((left, right) => compareDatesAsc(left.addedAt, right.addedAt))
    .slice(-DIRECT_CHAT_HISTORY_LIMIT)
    .map((message) => ({
      role: message.role === 'operator' ? 'user' as const : 'assistant' as const,
      content: message.message,
    }));

  return [
    {
      role: 'system',
      content: buildDirectViviSystemPrompt(sent.session),
    },
    ...history,
    {
      role: 'user',
      content: sent.message,
    },
  ];
}

function buildDirectViviSystemPrompt(session: ViviChatSession): string {
  return [
    'Du bist Vivi im LIONCOM Control Plane Chat.',
    'Sprich direkt mit Bjorn auf Deutsch, kurz, warm, praktisch und operatorfreundlich.',
    'Du bist die primaere operative Agentin: du hilfst schnell, strukturierst Aufgaben, erklaerst Lage, bereitest naechste Schritte vor und sagst klar, wenn Vega/Codex als Tech-Zelle pruefen oder bauen soll.',
    'Du darfst keine externen Sends, Credentials/Auth-Aenderungen, Geldbewegungen, Loeschaktionen, Production-Deploys oder irreversible Zusagen freigeben.',
    'Wenn der Operator nur plaudert oder eine kurze Frage stellt, antworte normal im Chat und erzeuge keinen Arbeitsauftrag in deiner Antwort.',
    'Wenn der Operator eine Aufgabe gibt, antworte mit Verstaendnis, naechstem sicheren Schritt und was du lokal/ueber Vega veranlassen wuerdest.',
    'Erfinde keine abgeschlossenen Aktionen. Wenn du Tools oder Dateien nicht selbst geprueft hast, sage das klar.',
    `Aktive Session: ${session.title}`,
    `Thema: ${session.topic || 'Allgemeiner Vivi-Dialog'}`,
    `Provider-Modus: ${session.providerPreset}/${session.providerMode}, Modell: ${session.requestedModel}`,
  ].join('\n');
}

async function callLmStudioResponses(input: {
  endpoint: string;
  messages: Array<{ role: 'assistant' | 'system' | 'user'; content: string }>;
  model: string;
  provider: string;
}): Promise<DirectViviReply> {
  const data = await fetchJsonWithTimeout<{
    output_text?: string;
    output?: Array<{ content?: Array<{ text?: string }> }>;
  }>(input.endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    body: JSON.stringify({
      model: input.model,
      input: input.messages.map((message) => `${message.role.toUpperCase()}:\n${message.content}`).join('\n\n'),
      stream: false,
      temperature: 0.4,
    }),
  });
  const message = clean(String(data.output_text || data.output?.[0]?.content?.[0]?.text || ''), MAX_MESSAGE_LENGTH);
  if (!message) throw new Error('Modell lieferte eine leere Antwort.');
  return {
    ok: true,
    detail: 'direct-chat-ok',
    message,
    model: input.model,
    provider: input.provider,
  };
}

async function callOpenAiCompatibleChat(input: {
  endpoint: string;
  headers: Record<string, string>;
  messages: Array<{ role: 'assistant' | 'system' | 'user'; content: string }>;
  model: string;
  provider: string;
}): Promise<DirectViviReply> {
  const data = await fetchJsonWithTimeout<{
    choices?: Array<{ message?: { content?: string } }>;
    output_text?: string;
  }>(input.endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
      ...input.headers,
    },
    body: JSON.stringify({
      model: input.model,
      messages: input.messages,
      stream: false,
      temperature: 0.4,
    }),
  });
  const message = clean(String(data.choices?.[0]?.message?.content || data.output_text || ''), MAX_MESSAGE_LENGTH);
  if (!message) throw new Error('Modell lieferte eine leere Antwort.');
  return {
    ok: true,
    detail: 'direct-chat-ok',
    message,
    model: input.model,
    provider: input.provider,
  };
}

async function callOllamaChat(input: {
  endpoint: string;
  messages: Array<{ role: 'assistant' | 'system' | 'user'; content: string }>;
  model: string;
  provider: string;
}): Promise<DirectViviReply> {
  const data = await fetchJsonWithTimeout<{ message?: { content?: string }; response?: string }>(input.endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    body: JSON.stringify({
      model: input.model,
      messages: input.messages,
      stream: false,
      think: false,
      keep_alive: '10m',
      options: { temperature: 0.4 },
    }),
  });
  const message = clean(String(data.message?.content || data.response || ''), MAX_MESSAGE_LENGTH);
  if (!message) throw new Error('Modell lieferte eine leere Antwort.');
  return {
    ok: true,
    detail: 'direct-chat-ok',
    message,
    model: input.model,
    provider: input.provider,
  };
}

async function fetchJsonWithTimeout<T>(url: string, init: RequestInit): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), DIRECT_CHAT_TIMEOUT_MS);
  try {
    const response = await fetch(url, {
      ...init,
      cache: 'no-store',
      signal: controller.signal,
    });
    const text = await response.text();
    let data: unknown = null;
    try {
      data = text ? JSON.parse(text) : null;
    } catch {
      throw new Error(`Nicht-JSON-Antwort: ${text.slice(0, 220)}`);
    }
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${JSON.stringify(data).slice(0, 320)}`);
    }
    return data as T;
  } finally {
    clearTimeout(timer);
  }
}

async function appendViviMessage(
  session: ViviChatSession,
  input: { message: string; reference: string; status: string; summary: string },
) {
  const now = new Date().toISOString();
  const messageId = slugTimestamp('VCHATVIVI', now);
  const block = [
    `### ${messageId}`,
    `- Added: ${now}`,
    `- Session Id: ${session.id}`,
    `- Session Title: ${session.title}`,
    '- Role: vivi',
    `- Status: ${input.status}`,
    '- Source: LIONCOM Control Plane V2',
    `- Provider Mode: ${session.providerMode}`,
    `- Provider Preset: ${session.providerPreset}`,
    `- Requested Model: ${session.requestedModel}`,
    `- Reference: ${input.reference}`,
    `- Summary: ${clean(input.summary, 220)}`,
    '- Message:',
    ...quoteLines(input.message),
    '',
  ].join('\n');

  const persistedSession: ViviChatSession = {
    ...session,
    updatedAt: now,
    lastMessagePreview: clean(input.summary, 180),
    lastReference: input.reference,
    status: input.status === 'action-needed' ? 'attention' : input.status === 'reported' ? 'reported' : 'waiting',
    latestActivity: input.status === 'action-needed'
      ? 'Vivi braucht Aufmerksamkeit.'
      : input.status === 'reported'
        ? 'Vivi hat im Chat geantwortet.'
        : 'Vivi hat die Nachricht angenommen.',
  };
  const sessions = await readSessions();
  await appendRailBlock(PATHS.VIVI_CHAT_THREAD, VIVI_CHAT_THREAD_HEADER, `${block}\n`);
  await writeSessions(sessions.map((item) => item.id === session.id ? persistedSession : item));
}

async function latestUnansweredOperatorMessage(sessionId: string): Promise<ViviChatMessage | null> {
  const content = await readRailContent(PATHS.VIVI_CHAT_THREAD);
  const sessionMessages = parseRailBlocks(content)
    .map(parseChatMessageBlock)
    .filter((message): message is ViviChatMessage => Boolean(message && message.sessionId === sessionId))
    .sort((left, right) => compareDatesAsc(left.addedAt, right.addedAt));
  const latestOperator = [...sessionMessages].reverse().find((message) => message.role === 'operator');
  if (!latestOperator) return null;

  const latestVivi = [...sessionMessages].reverse().find((message) => message.role === 'vivi');
  if (latestVivi && compareDatesAsc(latestVivi.addedAt, latestOperator.addedAt) >= 0) return null;
  return latestOperator;
}

async function appendArchivedSession(session: ViviChatSession, action: ArchivedViviChatSession['action'], reason: string) {
  let archive: ArchivedViviChatSession[] = [];

  try {
    const parsed = JSON.parse(await fs.readFile(VIVI_CHAT_SESSIONS_ARCHIVE, 'utf-8')) as unknown;
    if (Array.isArray(parsed)) {
      archive = parsed
        .filter((entry): entry is ArchivedViviChatSession => Boolean(entry) && typeof entry === 'object' && 'session' in entry)
        .slice(0, 500);
    }
  } catch {
    archive = [];
  }

  const record: ArchivedViviChatSession = {
    archivedAt: new Date().toISOString(),
    action,
    reason,
    session,
  };

  await fs.mkdir(path.dirname(VIVI_CHAT_SESSIONS_ARCHIVE), { recursive: true });
  await fs.writeFile(VIVI_CHAT_SESSIONS_ARCHIVE, `${JSON.stringify([record, ...archive].slice(0, 500), null, 2)}\n`, 'utf-8');
}

async function sessionHasOperatorOrViviContent(session: ViviChatSession): Promise<boolean> {
  const syntheticRecoveredPointer = session.lastReference.trim() === session.id
    && session.lastMessagePreview.trim().toLowerCase().startsWith('aus vivi_reports wiederhergestellt');
  if (!syntheticRecoveredPointer && (session.lastReference.trim() || session.lastMessagePreview.trim())) return true;

  const chatThread = await readRailContent(PATHS.VIVI_CHAT_THREAD);
  return parseRailBlocks(chatThread)
    .map(parseChatMessageBlock)
    .some((message) => message?.sessionId === session.id && (message.role === 'operator' || message.role === 'vivi'));
}

function buildViviBootContext(session: Pick<ViviChatSession, 'id' | 'providerMode' | 'providerPreset' | 'requestedModel' | 'title' | 'topic'>): string {
  return [
    'Vivi Auto-Start-Kontext:',
    `- Session: ${session.title} (${session.id})`,
    `- Thema: ${session.topic || 'Allgemeiner Vivi-Dialog'}`,
    `- Workspace Root: ${WORKSPACE_ROOT}`,
    `- Wunschpfad: ${session.providerPreset}/${session.providerMode}, Modellwunsch ${session.requestedModel || 'nicht gesetzt'}`,
    '- Pflichtstart: zuerst VEGA_START_HERE, Latest Session Context, Person - Vivi und die passende Projektnote lesen.',
    '- Lokale Arbeitswahrheit: VIVI_COMMAND_QUEUE.md, WORK_INTAKE.md, VIVI_RUNTIME.json, VIVI_STATE.json, TASK_CLAIMS.md und .runtime/local-duo-loop-status.json prüfen.',
    '- Arbeitsmodus: eine sichere Claim nach der anderen, kleine Schritte, Operator-Gates für externe Sends, Credentials, Geld, Löschen und Production.',
    '- Ergebnis: Antwort im selben Vivi-Chat oder sichtbarer nächster Schritt mit Command Ref.',
  ].join('\n');
}

async function persistAnalysisChatArchive(input: {
  commandRef: string;
  message: string;
  messageId: string;
  now: string;
  requestedModel: string;
  session: ViviChatSession;
  source: string;
  summary: string;
  topic: string;
}) {
  const combined = [
    input.session.title,
    input.topic,
    input.summary,
    input.message,
  ].join('\n');

  if (!looksLikeAnalysisRequest(combined)) return;

  try {
    await fs.mkdir(ANALYSIS_CHAT_ARCHIVE_DIR, { recursive: true });
    const date = input.now.slice(0, 10);
    const titleSlug = fileSlug(input.session.title || input.topic || 'vivi-analysis-chat');
    const target = path.join(ANALYSIS_CHAT_ARCHIVE_DIR, `${date}-${titleSlug}-${input.commandRef}.md`);
    const body = [
      `# LION Vivi Analyseauftrag - ${input.session.title}`,
      '',
      `- Archived: ${input.now}`,
      `- Session Id: ${input.session.id}`,
      `- Session Title: ${input.session.title}`,
      `- Topic: ${input.topic}`,
      `- Source: ${input.source}`,
      `- Reference: ${input.commandRef}`,
      `- Message Id: ${input.messageId}`,
      `- Provider Preset: ${input.session.providerPreset}`,
      `- Requested Model: ${input.requestedModel}`,
      `- Summary: ${input.summary}`,
      '',
      '## Operator Request',
      '',
      input.message,
      '',
      '## Ablageregel',
      '',
      'Dieser Chat wurde automatisch abgelegt, weil er wie ein Analyse-/Report-/Room-16-Auftrag aussieht. Finale Room-16-PDFs gehoeren pro Unternehmen in die Nachbarordner dieses Leseregals.',
      '',
    ].join('\n');
    await fs.writeFile(target, body, 'utf-8');
  } catch {
    // Chat delivery must not fail just because the human reading shelf is unavailable.
  }
}

function looksLikeAnalysisRequest(value: string): boolean {
  const normalized = value.toLowerCase();
  return [
    'room 16',
    'room16',
    'quellwert',
    'analyse',
    'analysiere',
    'aktie',
    'aktien',
    'ticker',
    'unternehmen',
    'dossier',
    'report',
    'pdf',
  ].some((token) => normalized.includes(token));
}

function isOperatorTaskRequest(value: string): boolean {
  const normalized = value.toLowerCase();
  if (normalized.length > 700) return true;
  if (/[.!?]\s+[a-zäöüß0-9]/i.test(value) && normalized.length > 220) return true;
  return [
    'analysiere',
    'analyse',
    'audit',
    'baue',
    'bau ',
    'berechne',
    'berichte',
    'deploy',
    'erstelle',
    'erzeuge',
    'fix',
    'fixe',
    'implementiere',
    'lies ',
    'mach ',
    'plane',
    'pruefe',
    'prüfe',
    'recherchiere',
    'schreibe',
    'starte',
    'suche',
    'teste',
    'ueberpruefe',
    'überprüfe',
    'verifiziere',
  ].some((token) => normalized.includes(token));
}

async function readSessions(): Promise<ViviChatSession[]> {
  await ensureChatFiles();

  try {
    const raw = JSON.parse(await fs.readFile(PATHS.VIVI_CHAT_SESSIONS, 'utf-8')) as unknown;
    if (!Array.isArray(raw)) return [];
    const sessions = raw.map(sanitizeSession).filter((session): session is ViviChatSession => Boolean(session));
    return sessions.length > 0 ? sessions : await recoverSessionsFromRails();
  } catch {
    return recoverSessionsFromRails();
  }
}

async function writeSessions(sessions: ViviChatSession[]) {
  await fs.mkdir(path.dirname(PATHS.VIVI_CHAT_SESSIONS), { recursive: true });
  await fs.writeFile(PATHS.VIVI_CHAT_SESSIONS, `${JSON.stringify(sessions, null, 2)}\n`, 'utf-8');
}

async function recoverSessionsFromRails(): Promise<ViviChatSession[]> {
  const [commandQueue, workIntake, reports, chatThread] = await Promise.all([
    readRailContent(PATHS.VIVI_COMMAND_QUEUE),
    readRailContent(PATHS.WORK_INTAKE),
    readRailContent(PATHS.VIVI_REPORTS),
    readRailContent(PATHS.VIVI_CHAT_THREAD),
  ]);
  const seeds = new Map<string, RecoveredSessionSeed>();

  for (const content of [commandQueue, workIntake]) {
    for (const block of parseRailBlocks(content ?? '')) {
      const sessionId = clean(block.fields['Session Id'], 120);
      if (!sessionId.startsWith('VIVISESSION-')) continue;

      const providerPreset = normalizeProviderPreset(block.fields['Provider Preset']);
      const providerMode = normalizeProviderMode(block.fields['Provider Mode'], providerPreset);
      const existing = seeds.get(sessionId);
      const addedAt = parseDateOrNow(block.fields.Added);
      const inferred = inferSessionFromReports(reports, sessionId);
      const title = clean(block.fields['Session Title'] || block.fields.Title, MAX_TITLE_LENGTH)
        || inferred.title
        || existing?.title
        || 'Wiederhergestellte Vivi-Session';
      const topic = clean(block.fields.Context, MAX_TOPIC_LENGTH)
        || existing?.topic
        || 'Aus lokalen Vivi-Rails wiederhergestellte Session.';
      const updatedAt = latestDate(existing?.updatedAt, addedAt);
      seeds.set(sessionId, {
        id: sessionId,
        title,
        topic,
        createdAt: existing?.createdAt && compareDatesAsc(existing.createdAt, addedAt) <= 0 ? existing.createdAt : addedAt,
        updatedAt,
        providerMode,
        providerPreset,
        requestedModel: normalizeRequestedModel(providerPreset, block.fields['Requested Model'] || existing?.requestedModel, providerMode),
        lastMessagePreview: clean(block.fields.Summary, 180) || existing?.lastMessagePreview || 'Aus Queue/Intake wiederhergestellt.',
        lastReference: clean(block.fields.Reference, 120) || existing?.lastReference || block.id,
        status: inferred.status || existing?.status || 'waiting',
        latestActivity: inferred.latestActivity || existing?.latestActivity || 'Session aus Queue/Intake wiederhergestellt.',
      });
    }
  }

  if (reports) {
    for (const inferred of inferSessionsListedInReports(reports)) {
      const existing = seeds.get(inferred.id);
      if (existing) {
        seeds.set(inferred.id, {
          ...existing,
          title: existing.title || inferred.title,
          status: inferred.status || existing.status,
          latestActivity: inferred.latestActivity || existing.latestActivity,
        });
        continue;
      }

      seeds.set(inferred.id, inferred);
    }
  }

  const recovered = Array.from(seeds.values())
    .filter((seed) => shouldRecoverSession(reports, seed.id))
    .map((seed): ViviChatSession => ({
      id: seed.id,
      title: seed.title,
      topic: seed.topic,
      createdAt: seed.createdAt,
      updatedAt: seed.updatedAt,
      providerMode: seed.providerMode,
      providerPreset: seed.providerPreset,
      requestedModel: seed.requestedModel,
      lastMessagePreview: seed.lastMessagePreview,
      lastReference: seed.lastReference,
      status: seed.status,
      latestActivity: seed.latestActivity,
    }))
    .sort((left, right) => compareDatesAsc(right.updatedAt, left.updatedAt));

  if (recovered.length === 0) return [];

  await writeSessions(recovered.slice(0, MAX_SESSIONS));

  if (!chatThread?.includes('session-recovered')) {
    await Promise.all(recovered.slice(0, 8).map((session) => appendSystemMessage(session, [
      'Diese Vivi-Session wurde automatisch aus lokalen Rails wiederhergestellt.',
      `Quelle: ${session.lastReference || 'VIVI_COMMAND_QUEUE / WORK_INTAKE / VIVI_REPORTS'}`,
      `Status vor Wiederherstellung: ${session.status}`,
      'Hinweis: Der ursprüngliche Chat-Thread war nicht aktiv registriert; Queue-, Intake- und Report-Spuren bleiben erhalten.',
      '',
      buildViviBootContext(session),
    ].join('\n'), `session-recovered-${session.status}`)));
  }

  return recovered;
}

function inferSessionFromReports(reports: string | null, sessionId: string): Partial<Pick<RecoveredSessionSeed, 'latestActivity' | 'status' | 'title'>> {
  if (!reports) return {};
  const escapedSessionId = escapeRegExp(sessionId);
  const lines = reports.split(/\r?\n/).filter((line) => line.includes(sessionId));
  const status = inferSessionStatus(lines.join('\n'));
  const title = lines
    .map((line) => line.match(new RegExp(`${escapedSessionId}(?:\\*\\*)?\\s*[—-]\\s*([^|\\n]+)`))?.[1]?.trim())
    .find(Boolean);

  return {
    title: title ? clean(title, MAX_TITLE_LENGTH) : undefined,
    status,
    latestActivity: status === 'attention'
      ? 'Aus Reports wiederhergestellt: Operator-Prüfung erforderlich.'
      : status === 'waiting'
        ? 'Aus Reports wiederhergestellt: wartet auf Vivi oder Operator-Entscheidung.'
        : status === 'reported'
          ? 'Aus Reports wiederhergestellt: Vivi hatte berichtet.'
          : undefined,
  };
}

function inferSessionsListedInReports(reports: string): RecoveredSessionSeed[] {
  const now = new Date().toISOString();
  const seen = new Map<string, RecoveredSessionSeed>();
  const sessionPattern = /(VIVISESSION-\d{17}-[A-Z0-9]{4})/g;

  for (const line of reports.split(/\r?\n/)) {
    if (!isRecoverableReportSessionLine(line)) continue;
    const ids = Array.from(line.matchAll(sessionPattern)).map((match) => match[1]);
    for (const id of ids) {
      if (seen.has(id)) continue;
      const status = inferSessionStatus(line) || 'idle';
      const title = bestReportTitle(reports, id)
        || line.match(new RegExp(`${escapeRegExp(id)}(?:\\*\\*)?\\s*[—-]\\s*([^|\\n]+)`))?.[1]?.trim();
      seen.set(id, {
        id,
        title: clean(title, MAX_TITLE_LENGTH) || 'Wiederhergestellte Vivi-Session',
        topic: 'Aus Vivi-Reports wiederhergestellte Session.',
        createdAt: now,
        updatedAt: now,
        providerMode: 'local',
        providerPreset: 'lmstudio',
        requestedModel: 'qwen3.5-vivi:9b',
        lastMessagePreview: 'Aus VIVI_REPORTS wiederhergestellt.',
        lastReference: id,
        status,
        latestActivity: status === 'idle'
          ? 'Aus Reports wiederhergestellt; kein aktiver Chat-Inhalt gefunden.'
          : 'Aus Reports wiederhergestellt; bitte im Vivi-Arbeitsraum prüfen.',
      });
    }
  }

  return Array.from(seen.values());
}

function shouldRecoverSession(reports: string | null, sessionId: string): boolean {
  if (!reports) return true;
  if (hasTerminalSessionEvidence(reports, sessionId) && !hasActiveSessionEvidence(reports, sessionId)) return false;
  return true;
}

function isRecoverableReportSessionLine(line: string): boolean {
  const normalized = line.toLowerCase();
  if (!normalized.includes('vivisession-')) return false;
  if (normalized.includes('removed-empty') || normalized.includes('archived')) return false;
  return normalized.includes('aktive sessions')
    || normalized.includes('active sessions')
    || normalized.includes('vivi chat sessions')
    || normalized.includes('operator-gate')
    || normalized.includes('operator-review')
    || normalized.includes('operator soll');
}

function hasTerminalSessionEvidence(reports: string, sessionId: string): boolean {
  return reports
    .split(/\r?\n/)
    .filter((line) => line.includes(sessionId))
    .some((line) => {
      const normalized = line.toLowerCase();
      return normalized.includes('removed-empty')
        || normalized.includes('action: `archived`')
        || normalized.includes('→ action: `archived`')
        || normalized.includes('archiviert')
        || normalized.includes('removed');
    });
}

function hasActiveSessionEvidence(reports: string, sessionId: string): boolean {
  return reports
    .split(/\r?\n/)
    .filter((line) => line.includes(sessionId))
    .some((line) => {
      const normalized = line.toLowerCase();
      return normalized.includes('aktive sessions')
        || normalized.includes('active sessions')
        || normalized.includes('vivi chat sessions');
    });
}

function bestReportTitle(reports: string, sessionId: string): string | undefined {
  const titlePattern = new RegExp(`${escapeRegExp(sessionId)}(?:\\*\\*)?\\s*[—-]\\s*([^|\\n]+)`);
  return reports
    .split(/\r?\n/)
    .filter((line) => line.includes(sessionId))
    .map((line) => line.match(titlePattern)?.[1]?.trim())
    .find((title): title is string => Boolean(title && !title.toLowerCase().startsWith('status:')));
}

function inferSessionStatus(value: string): ViviChatStatus | undefined {
  const normalized = value.toLowerCase();
  if (normalized.includes('attention') || normalized.includes('operator-gate') || normalized.includes('stale')) return 'attention';
  if (normalized.includes('waiting') || normalized.includes('wartet')) return 'waiting';
  if (normalized.includes('reported') || normalized.includes('bericht')) return 'reported';
  if (normalized.includes('idle') || normalized.includes('leer')) return 'idle';
  return undefined;
}

async function ensureChatFiles() {
  try {
    await fs.access(PATHS.VIVI_CHAT_SESSIONS);
  } catch {
    await fs.mkdir(path.dirname(PATHS.VIVI_CHAT_SESSIONS), { recursive: true });
    await fs.writeFile(PATHS.VIVI_CHAT_SESSIONS, '[]\n', 'utf-8');
  }

  await ensureRailFile(PATHS.VIVI_CHAT_THREAD, VIVI_CHAT_THREAD_HEADER);
}

async function writeRuntimeWish(session: Pick<ViviChatSession, 'providerMode' | 'providerPreset' | 'requestedModel'>) {
  await saveDesktopSettings({
    viviProviderPreset: session.providerPreset,
    viviRequestedModel: normalizeRequestedModel(session.providerPreset, session.requestedModel, session.providerMode),
  });
}

function patchSession(session: ViviChatSession, payload: ViviChatPayload): ViviChatSession {
  const providerPreset = normalizeProviderPreset(payload.providerPreset || session.providerPreset);
  const providerMode = normalizeProviderMode(payload.providerMode || session.providerMode, providerPreset);
  const requestedModel = normalizeRequestedModel(providerPreset, payload.requestedModel ?? session.requestedModel, providerMode);

  return {
    ...session,
    title: clean(payload.title, MAX_TITLE_LENGTH) || session.title,
    topic: clean(payload.topic, MAX_TOPIC_LENGTH) || session.topic,
    updatedAt: new Date().toISOString(),
    providerMode,
    providerPreset,
    requestedModel,
  };
}

function sanitizeSession(value: unknown): ViviChatSession | null {
  if (!value || typeof value !== 'object') return null;
  const raw = value as Partial<ViviChatSession>;
  const id = typeof raw.id === 'string' ? raw.id.trim() : '';
  const createdAt = typeof raw.createdAt === 'string' ? raw.createdAt : new Date().toISOString();
  const updatedAt = typeof raw.updatedAt === 'string' ? raw.updatedAt : createdAt;
  if (!id) return null;

  const providerPreset = normalizeProviderPreset(raw.providerPreset);
  const providerMode = normalizeProviderMode(raw.providerMode, providerPreset);

  return {
    id,
    title: typeof raw.title === 'string' && raw.title.trim() ? clean(raw.title, MAX_TITLE_LENGTH) : 'Vivi-Chat',
    topic: typeof raw.topic === 'string' ? clean(raw.topic, MAX_TOPIC_LENGTH) : '',
    createdAt,
    updatedAt,
    providerMode,
    providerPreset,
    requestedModel: normalizeRequestedModel(providerPreset, typeof raw.requestedModel === 'string' ? raw.requestedModel : '', providerMode),
    lastMessagePreview: typeof raw.lastMessagePreview === 'string' ? raw.lastMessagePreview : '',
    lastReference: typeof raw.lastReference === 'string' ? raw.lastReference : '',
    status: normalizeSessionStatus(raw.status),
    latestActivity: typeof raw.latestActivity === 'string' ? raw.latestActivity : '',
  };
}

function parseChatMessageBlock(block: ReturnType<typeof parseRailBlocks>[number]): ViviChatMessage | null {
  const providerPreset = normalizeProviderPreset(block.fields['Provider Preset']);
  const providerMode = normalizeProviderMode(block.fields['Provider Mode'], providerPreset);
  const message = extractPayload(block.lines, 'Message');
  const summary = block.fields.Summary || summarize(message, block.id);

  return {
    id: block.id,
    sessionId: block.fields['Session Id'] || 'unknown',
    addedAt: block.fields.Added || 'unknown',
    role: normalizeRole(block.fields.Role),
    status: block.fields.Status || 'unknown',
    summary,
    message: message || summary || block.id,
    source: block.fields.Source,
    reference: block.fields.Reference,
    providerMode,
    providerPreset,
    requestedModel: block.fields['Requested Model'],
    derivedFrom: 'chat-thread',
  };
}

function parseViviReportBlocks(content: string | null): ViviReportBlock[] {
  if (!content) return [];

  const structuredReports = parseRailBlocks(content)
    .map((block) => ({
      id: block.id,
      addedAt: block.fields.Added || 'unknown',
      state: block.fields.State || 'unknown',
      title: block.fields.Title || block.id,
      commandRef: block.fields['Command Ref'],
      summary: block.fields.Summary || block.id,
      outcome: block.fields.Outcome,
      nextStep: block.fields['Next Step'],
      operatorAction: block.fields['Operator Action'],
    }))
    .filter((report) => report.commandRef);
  const reportSections = content.split(/^## REPORT\s+[—-]\s+/m).slice(1).map((section) => {
    const lines = section.trimEnd().split('\n');
    const title = lines[0]?.trim() || 'Vivi Report';
    const fields = collectFields(lines);
    return {
      id: fields.Claim || fields['Command Ref'] || title,
      addedAt: fields.Added || fields.Updated || 'unknown',
      state: fields.State || 'REPORT',
      title,
      commandRef: fields['Command Ref'],
      summary: extractReportSection(lines, 'Summary') || title,
      outcome: extractReportSection(lines, 'Outcome'),
      nextStep: extractReportSection(lines, 'Next Step'),
      operatorAction: extractReportSection(lines, 'Operator Action'),
    };
  }).filter((report) => report.commandRef);

  const seen = new Set<string>();
  return [...structuredReports, ...reportSections].filter((report) => {
    const key = `${report.id}:${report.commandRef}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).sort((left, right) => compareDatesAsc(left.addedAt, right.addedAt));
}

function stitchReportsIntoChat(messages: ViviChatMessage[], reports: ViviReportBlock[]): ViviChatMessage[] {
  const byReference = new Map<string, ViviChatMessage>();
  for (const message of messages) {
    if (message.reference) byReference.set(message.reference, message);
  }

  return reports.flatMap((report) => {
    const sourceMessage = report.commandRef ? byReference.get(report.commandRef) : undefined;
    if (!sourceMessage) return [];

    const messageParts = [
      report.summary,
      report.outcome && !report.outcome.toLowerCase().startsWith('no explicit') ? `Outcome: ${report.outcome}` : null,
      report.nextStep && !report.nextStep.toLowerCase().startsWith('no next') ? `Naechster Schritt: ${report.nextStep}` : null,
      report.operatorAction && !report.operatorAction.toLowerCase().startsWith('no operator') ? `Operator: ${report.operatorAction}` : null,
    ].filter(Boolean);

    return [{
      id: `report-${report.id}`,
      sessionId: sourceMessage.sessionId,
      addedAt: report.addedAt,
      role: 'vivi' as const,
      status: report.operatorAction ? 'action-needed' : 'reported',
      summary: report.title,
      message: messageParts.join('\n\n'),
      source: 'VIVI_REPORTS.md',
      reference: report.commandRef,
      providerMode: sourceMessage.providerMode,
      providerPreset: sourceMessage.providerPreset,
      requestedModel: sourceMessage.requestedModel,
      derivedFrom: 'vivi-report' as const,
    }];
  });
}

function hydrateSession(session: ViviChatSession, messages: ViviChatMessage[]): ViviChatSession {
  const sessionMessages = messages.filter((message) => message.sessionId === session.id);
  const lastMessage = sessionMessages[sessionMessages.length - 1];
  const lastOperatorMessage = [...sessionMessages].reverse().find((message) => message.role === 'operator');
  const lastViviMessage = [...sessionMessages].reverse().find((message) => message.role === 'vivi');
  const recoveredStatus = lastMessage?.role === 'system' ? parseRecoveredStatus(lastMessage.status) : null;
  const unresolvedOperatorMessage = Boolean(
    lastOperatorMessage
      && (!lastViviMessage || compareDatesAsc(lastViviMessage.addedAt, lastOperatorMessage.addedAt) < 0),
  );
  const staleWaiting = Boolean(lastOperatorMessage && isOlderThan(lastOperatorMessage.addedAt, STALE_WAITING_MS));

  if (!lastMessage) {
    return {
      ...session,
      status: 'idle',
      latestActivity: session.latestActivity || 'Noch keine Nachricht in diesem Chat.',
    };
  }

  return {
    ...session,
    updatedAt: latestDate(session.updatedAt, lastMessage.addedAt || session.updatedAt),
    lastMessagePreview: lastMessage.summary || session.lastMessagePreview,
    lastReference: lastMessage.reference || session.lastReference,
    status: unresolvedOperatorMessage
      ? staleWaiting ? 'attention' : 'waiting'
      : recoveredStatus
        ? recoveredStatus
      : lastMessage.role === 'system'
        ? lastMessage.status === 'local-start' ? 'waiting' : 'idle'
        : lastMessage.status === 'action-needed'
          ? 'attention'
          : lastMessage.status === 'waiting'
            ? 'waiting'
            : 'reported',
    latestActivity: unresolvedOperatorMessage
      ? staleWaiting
        ? `Wartet seit ${relativeAge(lastOperatorMessage?.addedAt || lastMessage.addedAt)} auf Vivi.`
        : 'Wartet auf Vivi-Antwort.'
      : recoveredStatus
        ? recoveredStatus === 'attention'
          ? 'Wiederhergestellt; Operator-Prüfung erforderlich.'
          : recoveredStatus === 'waiting'
            ? 'Wiederhergestellt; wartet auf Vivi oder Operator-Entscheidung.'
            : recoveredStatus === 'reported'
              ? 'Wiederhergestellt; Vivi hatte berichtet.'
              : 'Wiederhergestellt; kein aktiver Chat-Inhalt gefunden.'
      : lastMessage.role === 'system'
        ? lastMessage.status === 'local-start' ? 'Lokaler Vivi-Start angefordert.' : 'Startkontext liegt bereit.'
        : lastMessage.status === 'action-needed'
          ? 'Vivi hat einen Rückschritt für dich markiert.'
          : lastMessage.status === 'waiting'
            ? 'Vivi hat die Nachricht angenommen und arbeitet lokal weiter.'
          : 'Vivi hat zuletzt geantwortet.',
  };
}

function parseRecoveredStatus(value: string): ViviChatStatus | null {
  const match = value.match(/^session-recovered-(idle|waiting|reported|attention)$/);
  return match ? normalizeSessionStatus(match[1]) : null;
}

function collectFields(lines: string[]): Record<string, string> {
  const fields: Record<string, string> = {};
  for (const line of lines) {
    const match = line.trim().match(/^\-\s*([^:]+):\s*(.*)$/);
    if (match) {
      fields[match[1].trim()] = match[2].trim();
    }
  }

  return fields;
}

function extractReportSection(lines: string[], heading: string): string | undefined {
  const start = lines.findIndex((line) => line.trim().toLowerCase() === `### ${heading}`.toLowerCase());
  if (start < 0) return undefined;
  const collected: string[] = [];

  for (const line of lines.slice(start + 1)) {
    if (line.startsWith('### ')) break;
    const trimmed = line.trim();
    if (!trimmed) continue;
    collected.push(trimmed.replace(/^\-\s*/, ''));
  }

  return collected.join('\n').trim() || undefined;
}

function extractPayload(lines: string[], marker: string): string {
  const collected: string[] = [];
  let active = false;

  for (const line of lines) {
    const trimmed = line.trim();

    if (!active && trimmed.startsWith(`- ${marker}:`)) {
      active = true;
      const inlineValue = trimmed.replace(new RegExp(`^- ${marker}:\\s*`), '').trim();
      if (inlineValue) collected.push(inlineValue);
      continue;
    }

    if (!active) continue;
    if (trimmed === '>') {
      collected.push('');
      continue;
    }
    if (trimmed.startsWith('> ')) {
      collected.push(trimmed.slice(2));
      continue;
    }
    if (!trimmed) continue;
    if (trimmed.startsWith('- ')) break;
    collected.push(trimmed);
  }

  return collected.join('\n').trim();
}

function normalizeProviderPreset(value?: string): ViviProviderPreset {
  return normalizeViviProviderPreset(value);
}

function normalizeProviderMode(value: string | undefined, providerPreset: ViviProviderPreset): ViviProviderMode {
  return normalizeViviProviderMode(value, providerPreset);
}

function normalizeRequestedModel(providerPreset: ViviProviderPreset, value?: string, providerMode?: ViviProviderMode): string {
  return clean(normalizeViviRequestedModel(providerPreset, value, providerMode), MAX_MODEL_LENGTH);
}

function normalizeAction(value?: string): ViviChatAction | null {
  if (!value) return 'send-message';
  if (
    value === 'archive-session'
    || value === 'create-session'
    || value === 'update-session'
    || value === 'delete-session'
    || value === 'remove-session'
    || value === 'start-local-vivi'
    || value === 'send-message'
  ) {
    return value;
  }

  return null;
}

function normalizeSessionStatus(value?: string): ViviChatStatus {
  return value === 'waiting' || value === 'reported' || value === 'attention' ? value : 'idle';
}

function normalizeRole(value?: string): ViviChatRole {
  const normalized = value?.trim().toLowerCase();
  if (normalized === 'vivi') return 'vivi';
  if (normalized === 'system') return 'system';
  return 'operator';
}

function slugTimestamp(prefix: string, value = new Date().toISOString()): string {
  const stamp = value.replace(/[-:TZ]/g, '').replace('.', '').slice(0, 17);
  const entropy = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `${prefix}-${stamp}-${entropy}`;
}

function summarize(value: string, fallback: string): string {
  const compact = value.replace(/\s+/g, ' ').trim();
  return compact ? compact.slice(0, 180) : fallback;
}

function fileSlug(value: string): string {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 72) || 'vivi-analysis-chat';
}

function clean(value?: string, maxLength = 500): string {
  return value?.replace(/\u0000/g, '').trim().slice(0, maxLength) || '';
}

function cleanMessage(value?: string): string {
  return clean(value, MAX_MESSAGE_LENGTH);
}

function quoteLines(value: string): string[] {
  return value.split('\n').map((line) => `> ${line}`);
}

function compareDatesAsc(left?: string, right?: string): number {
  const leftTime = left ? Date.parse(left) : NaN;
  const rightTime = right ? Date.parse(right) : NaN;

  if (Number.isNaN(leftTime) && Number.isNaN(rightTime)) return 0;
  if (Number.isNaN(leftTime)) return -1;
  if (Number.isNaN(rightTime)) return 1;
  return leftTime - rightTime;
}

function parseDateOrNow(value?: string): string {
  const parsed = value ? Date.parse(value) : NaN;
  return Number.isNaN(parsed) ? new Date().toISOString() : new Date(parsed).toISOString();
}

function latestDate(left: string | undefined, right: string): string {
  if (!left) return right;
  return compareDatesAsc(left, right) >= 0 ? left : right;
}

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function isOlderThan(value: string, maxAgeMs: number): boolean {
  const time = Date.parse(value);
  return !Number.isNaN(time) && Date.now() - time > maxAgeMs;
}

function relativeAge(value: string): string {
  const time = Date.parse(value);
  if (Number.isNaN(time)) return 'unbekannter Zeit';
  const minutes = Math.max(1, Math.floor((Date.now() - time) / 60_000));
  if (minutes < 90) return `${minutes} Minuten`;
  const hours = Math.floor(minutes / 60);
  if (hours < 48) return `${hours} Stunden`;
  return `${Math.floor(hours / 24)} Tagen`;
}
