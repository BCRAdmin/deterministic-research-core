import {
  getAnalysisGateSummary,
  getInternalReviewAnalyses,
  getPublicAnalyses,
} from '@/lib/quellwert/analysisCatalog';
import { QuellwertPaperFooter } from '@/components/quellwert/quellwert-paper-footer';
import { QuellwertPaperHeader } from '@/components/quellwert/quellwert-paper-header';
import type { Metadata } from 'next';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export const metadata: Metadata = {
  title: 'Methodik | Quellwert',
  description:
    'Quellwert trennt Datenpaket, Evidence, Reconciliation, Redaktion und Public-Preview-Gate. Preview ist nicht gleich externe Veröffentlichung.',
};

const steps = [
  {
    title: 'Datenpaket',
    text: 'Jeder Kandidat startet mit einem klaren Stand, einem Quellenkatalog und reproduzierbaren Artefakten.',
  },
  {
    title: 'Evidence',
    text: 'Harte Finanz- und Bewertungsclaims müssen auf SEC-, IR- oder andere qualifizierte Evidence-IDs zurückführbar sein.',
  },
  {
    title: 'Reconciliation',
    text: 'Perioden, Einheiten, Restatements und Source-Konflikte werden getrennt geprüft, bevor Zahlen in einen Artikel gelangen.',
  },
  {
    title: 'Redaktion',
    text: 'Ein Entwurf wird in klare Prosa übertragen: These, Zahlen, Quellen, Unsicherheiten und Grenzen stehen explizit im Text.',
  },
  {
    title: 'Public-Preview-Gate',
    text: 'Nur lesbare Entwürfe ohne interne Systemsprache, ohne Claim-ID-Lärm und mit Non-Advice-Hinweis werden sichtbar geroutet.',
  },
  {
    title: 'Operator-Go',
    text: 'Externe Veröffentlichung wird nur nach explizitem Operator-Go geprüft. Vorher bleibt alles eine lokale Preview.',
  },
];

export default function QuellwertMethodikPage() {
  const publicAnalyses = getPublicAnalyses();
  const reviewCount = getInternalReviewAnalyses().length;

  return (
    <main className="qw-page qwp-page" id="qwp-main" tabIndex={-1} lang="de">
      <QuellwertPaperHeader current="methodik" />
      <div id="qwp-content" tabIndex={-1} role="region" aria-label="Inhalt">
        <section className="qwp-hero qwp-narrow">
          <p className="qwp-kicker">Methodik</p>
          <h1>Quellen zuerst. Interpretation danach.</h1>
          <p>
            Quellwert trennt maschinenlesbare Faktenpakete, Quellenprüfung,
            redaktionelle Analyse und öffentliche Darstellung. Das schützt vor
            hübschen, aber unprüfbaren Texten. Die Gate-Reihenfolge ist bewusst
            nüchtern: Datenpaket, Evidence, Reconciliation, Redaktion,
            Public-Preview-Gate, Operator-Go.
          </p>
        </section>

        <section className="qwp-narrow" aria-label="Schnellzugriff">
          <nav className="qwp-toc" aria-labelledby="qwp-quick-title">
            <p className="qwp-kicker" id="qwp-quick-title">
              Schnellzugriff
            </p>
            <ul>
              <li>
                <a href="/membership">Start</a>
              </li>
              <li>
                <a href="/membership/analysen">Analysen</a>
              </li>
              <li>
                <a aria-current="page" href="/membership/methodik">
                  Methodik
                </a>
              </li>
              <li>
                <a href="/membership/archiv">Archiv</a>
              </li>
              <li>
                <a href="/membership/verifier">Verifier</a>
              </li>
            </ul>
          </nav>
        </section>

        <section className="qwp-method-grid" aria-label="Quellwert Methodikschritte">
          {steps.map((step, index) => (
            <article key={step.title}>
              <span>{String(index + 1).padStart(2, '0')}</span>
              <h2>{step.title}</h2>
              <p>{step.text}</p>
            </article>
          ))}
        </section>

        <section className="qwp-gate-matrix qwp-narrow" aria-label="Aktueller Gate-Stand">
          <div>
            <p className="qwp-kicker">Aktueller Gate-Stand</p>
            <h2>Preview ist nicht gleich externe Veröffentlichung.</h2>
            <p>
              Quellwert trennt lokale Sichtbarkeit, Quellenprüfung und externe
              Veröffentlichung bewusst. So bleibt ein guter Entwurf sichtbar prüfbar,
              ohne eine Freigabe vorwegzunehmen.
            </p>
            <p>
              Jeder öffentliche Eintrag braucht Stand, Batch, Report-ID,
              Quellenstatus, lokalen Artefaktnachweis und eine sichtbare
              Non-Advice-Grenze.
            </p>
          </div>
          <dl>
            {publicAnalyses.map((analysis) => {
              const gate = getAnalysisGateSummary(analysis);

              return (
                <div key={analysis.slug}>
                  <dt>
                    {analysis.ticker}
                    <span>{analysis.displayStatus}</span>
                  </dt>
                  <dd>
                    {gate.reviewLabel}; {gate.externalLabel}
                  </dd>
                </div>
              );
            })}
            <div>
              <dt>
                Interner Review
                <span>zurückgestellt</span>
              </dt>
              <dd>{reviewCount} Kandidaten bleiben unsichtbar, bis die Quellenlage reicht.</dd>
            </div>
          </dl>
        </section>

        <section className="qwp-disclaimer qwp-narrow" aria-label="Publikationsgrenze">
          <h2>Publikationsgrenze</h2>
          <p>
            Ein hoher interner Score reicht allein nicht. Sichtbare Artikel brauchen
            Quellenstatus, aktuelle Kernzahlen, verständliche Prosa, Review-Hinweis
            und eine klare Grenze: keine Anlageberatung und keine persönliche
            Handlungsanweisung.
          </p>
          <p>
            Die führende, überprüfbare Gate-Wahrheit steht im{' '}
            <a className="qwp-link" href="/membership/verifier">
              Verifier
            </a>
            .
          </p>
        </section>

        <QuellwertPaperFooter />
      </div>
    </main>
  );
}
