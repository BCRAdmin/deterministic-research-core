import { QuellwertPaperFooter } from '@/components/quellwert/quellwert-paper-footer';
import { QuellwertPaperHeader } from '@/components/quellwert/quellwert-paper-header';
import { QuellwertLegalSubnav } from '@/components/quellwert/quellwert-legal-subnav';
import type { Metadata } from 'next';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export const metadata: Metadata = {
  title: 'Kontakt | Quellwert (Preview)',
  description:
    'Lokale Quellwert-Preview: Kontaktweg ist vorbereitet und bleibt Operator-Gate vor externer Veröffentlichung.',
};

export default function QuellwertKontaktPage() {
  return (
    <main className="qw-page qwp-page" id="qwp-main" tabIndex={-1} lang="de">
      <QuellwertPaperHeader />
      <div id="qwp-content" tabIndex={-1} role="region" aria-label="Inhalt">
        <section className="qwp-hero qwp-narrow">
          <p className="qwp-kicker">Kontakt</p>
          <h1>Kontaktweg vor externer Veröffentlichung.</h1>
          <p>
            Diese lokale Preview bereitet den öffentlichen Kontaktweg nur vor.
            Externe Nachrichten, Newsletter, Formulare oder Support-Zusagen werden
            erst nach Operator-Freigabe aktiviert.
          </p>
          <QuellwertLegalSubnav current="kontakt" />
        </section>

        <section className="qwp-disclaimer qwp-narrow" aria-label="Operator-Gate">
          <h2>Operator-Gate</h2>
          <p>
            Der finale Kontaktkanal wird vor einem öffentlichen Start geprüft und
            bewusst gesetzt. Bis dahin bleibt Quellwert eine lokale Research-Preview
            ohne externe Kommunikation.
          </p>
        </section>

        <QuellwertPaperFooter />
      </div>
    </main>
  );
}
