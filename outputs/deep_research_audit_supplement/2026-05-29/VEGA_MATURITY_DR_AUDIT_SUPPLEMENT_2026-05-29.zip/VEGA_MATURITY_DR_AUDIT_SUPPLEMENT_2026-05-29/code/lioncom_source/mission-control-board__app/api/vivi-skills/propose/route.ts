import { NextResponse } from 'next/server';

import { createViviSkillProposal } from '@/lib/vivi-skills/proposals';
import type { ViviSkillCapability } from '@/lib/vivi-skills/types';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function POST(request: Request) {
  let body: { title?: unknown; capability?: unknown; operatorMessage?: unknown; reason?: unknown };
  try {
    body = await request.json() as typeof body;
  } catch {
    return NextResponse.json({ error: 'Ungültige JSON-Daten.' }, { status: 400 });
  }

  const capability = normalizeCapability(typeof body.capability === 'string' ? body.capability : '');
  try {
    const proposal = await createViviSkillProposal({
      title: typeof body.title === 'string' ? body.title : undefined,
      requestedCapability: capability,
      source: 'Vivi Skill Proposal API',
      operatorMessage: typeof body.operatorMessage === 'string' ? body.operatorMessage : undefined,
      reason: typeof body.reason === 'string' ? body.reason : undefined,
    });
    return NextResponse.json({ ok: true, proposal });
  } catch {
    return NextResponse.json({ error: 'Skill-Vorschlag konnte nicht erstellt werden.' }, { status: 500 });
  }
}

function normalizeCapability(value: string): ViviSkillCapability {
  const known: ViviSkillCapability[] = [
    'chat.direct',
    'task.queue',
    'dispatch.route',
    'memory.capture',
    'obsidian.read',
    'obsidian.write_safe',
    'lioncom.status.read',
    'repo.inspect',
    'code.patch',
    'code.test',
    'browser.inspect',
    'web.research',
    'media.transcript',
    'image.generate',
    'image.edit',
    'document.create',
    'presentation.create',
    'spreadsheet.analyze',
    'automation.schedule',
    'telegram.bridge',
    'vega.handoff',
    'skill.hub',
    'skill.propose',
    'skill.remote_dry_run',
  ];
  return known.includes(value as ViviSkillCapability) ? value as ViviSkillCapability : 'skill.propose';
}
