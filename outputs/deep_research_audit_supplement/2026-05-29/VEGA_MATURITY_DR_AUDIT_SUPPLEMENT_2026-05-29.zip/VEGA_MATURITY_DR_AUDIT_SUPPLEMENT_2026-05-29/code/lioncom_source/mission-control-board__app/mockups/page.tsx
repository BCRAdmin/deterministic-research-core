import Link from 'next/link';
import styles from './mockups.module.css';

const topSignals = [
  { label: 'Fokus', value: 'Membership Reentry' },
  { label: 'Blocker', value: '2 offen' },
  { label: 'Vivi', value: 'qwen3.5-vivi:9b' },
  { label: 'Operator Go', value: '1 Slot heute' },
];

const operatorCards = [
  { stage: 'Jetzt', title: 'Finance Writer', meta: 'Aktiv · Heute' },
  { stage: 'Danach', title: 'Activation Acceptance', meta: 'Review · Wartet' },
  { stage: 'Zuletzt', title: 'Scheduler gehärtet', meta: 'Verified · Runtime' },
];

const boardColumns = [
  {
    title: 'Operator',
    items: ['3 Entscheidungen', '1 Publish-Slot', 'keine Dateiwand'],
  },
  {
    title: 'Vivi',
    items: ['Tabs', 'Provider-Wahrheit', '1 Claim = 1 Report'],
  },
  {
    title: 'Projekte',
    items: ['Membership', 'Utility', 'Quellwert'],
  },
];

const systemCards = [
  { label: 'Autonomy', value: 'gruen', meta: 'Loop + Reports' },
  { label: 'Runtime', value: 'lokal', meta: 'LM Studio Proxy' },
  { label: 'Automation', value: '5 / 7', meta: 'hart belegt' },
  { label: 'Memory', value: 'backbone', meta: 'Vega + Obsidian' },
];

export default function LionMockupsPage() {
  return (
    <main className={styles.page}>
      <section className={styles.hero}>
        <div className={styles.heroCopy}>
          <p className={styles.kicker}>LION Mockups</p>
          <h1>Weniger reden. Klarer sehen.</h1>
          <div className={styles.heroActions}>
            <a href="#start" className={styles.primaryAction}>
              Start
            </a>
            <a href="#board" className={styles.secondaryAction}>
              Board
            </a>
            <a href="#system" className={styles.secondaryAction}>
              System
            </a>
          </div>
        </div>

        <aside className={styles.heroMeta}>
          <div className={styles.metaCard}>
            <span>Modus</span>
            <strong>Mockups only</strong>
          </div>
          <div className={styles.metaCard}>
            <span>Live UI</span>
            <strong>unveraendert</strong>
          </div>
          <Link href="/" className={styles.metaLink}>
            Zur echten LION-Oberflaeche
          </Link>
        </aside>
      </section>

      <section id="start" className={styles.surface}>
        <div className={styles.surfaceHeader}>
          <div>
            <p className={styles.sectionEyebrow}>Mockup 01</p>
            <h2>Operator Start</h2>
          </div>
          <small>Reentry zuerst</small>
        </div>

        <div className={styles.signalRow}>
          {topSignals.map((signal) => (
            <article key={signal.label} className={styles.signalCard}>
              <span>{signal.label}</span>
              <strong>{signal.value}</strong>
            </article>
          ))}
        </div>

        <div className={styles.operatorGrid}>
          <section className={styles.mainPanel}>
            <div className={styles.panelHeader}>
              <p>Heute wichtig</p>
              <span>Operator Cut</span>
            </div>

            <div className={styles.cardStack}>
              {operatorCards.map((card) => (
                <article key={card.title} className={styles.minCard}>
                  <span>{card.stage}</span>
                  <strong>{card.title}</strong>
                  <small>{card.meta}</small>
                </article>
              ))}
            </div>
          </section>

          <aside className={styles.sidePanel}>
            <article className={styles.sideCard}>
              <span>Heute</span>
              <strong>3 Entscheidungen</strong>
            </article>
            <article className={styles.sideCard}>
              <span>Vivi</span>
              <strong>kleiner Claim</strong>
            </article>
            <article className={styles.sideCard}>
              <span>Spannung</span>
              <strong>Automation Health</strong>
            </article>
          </aside>
        </div>
      </section>

      <section id="board" className={styles.surface}>
        <div className={styles.surfaceHeader}>
          <div>
            <p className={styles.sectionEyebrow}>Mockup 02</p>
            <h2>Board</h2>
          </div>
          <small>Ruhiger Arbeitsraum</small>
        </div>

        <div className={styles.boardShell}>
          <div className={styles.boardRail}>
            <span>L</span>
            <span>I</span>
            <span>O</span>
            <span>N</span>
          </div>

          <div className={styles.boardBody}>
            <div className={styles.boardTop}>
              <strong>Command Surface</strong>
              <div className={styles.boardBadges}>
                <small>Operator Go</small>
                <small>Vivi Tabs</small>
                <small>Rails</small>
              </div>
            </div>

            <div className={styles.boardGrid}>
              {boardColumns.map((column) => (
                <article key={column.title} className={styles.boardCard}>
                  <span>{column.title}</span>
                  <ul>
                    {column.items.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </ul>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="system" className={styles.surface}>
        <div className={styles.surfaceHeader}>
          <div>
            <p className={styles.sectionEyebrow}>Mockup 03</p>
            <h2>System</h2>
          </div>
          <small>Autonomy + Health</small>
        </div>

        <div className={styles.systemGrid}>
          {systemCards.map((card) => (
            <article key={card.label} className={styles.systemCard}>
              <span>{card.label}</span>
              <strong>{card.value}</strong>
              <small>{card.meta}</small>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}
