import { ControlRoomShell } from '@/components/control-room/ControlRoomShell';
import { loadControlRoomData } from '@/lib/control-room/loadControlRoomData';
import type { TabId } from '@/lib/control-room/types';
import { redirect } from 'next/navigation';

const VALID_TABS: TabId[] = ['command', 'approvals', 'builder', 'research', 'projects', 'agents', 'automations', 'comms', 'codex', 'system'];

function coerceTab(value?: string): TabId {
  if (value && VALID_TABS.includes(value as TabId)) {
    return value as TabId;
  }
  return 'command';
}

function mapNotice(saved?: string): string | undefined {
  if (saved === 'brain-dump') {
    return 'New idea captured. It is stored locally and ready for Vivi to inspect later.';
  }

  if (saved === 'work-intake') {
    return 'New work request captured. It is queued for Vivi to break into blocks and subtasks.';
  }

  if (saved === 'telegram-packet') {
    return 'Telegram packet staged. If local bridge credentials exist, delivery was attempted immediately.';
  }

  if (saved === 'telegram-poll') {
    return 'Telegram mobile bridge polled successfully. Any new mobile packets were routed into LIONCOM and mirrored into the correct rails.';
  }

  if (saved === 'telegram-poll-failed') {
    return 'Telegram poll failed on this machine. The board stays safe, but new mobile packets were not imported this cycle.';
  }

  if (saved === 'codex-command') {
    return 'New Codex packet captured locally. The Codex deck now has a structured request ready for direct control bridging.';
  }

  if (saved === 'codex-chat') {
    return 'New board-first Codex message stored locally. It is visible in the Bridge chat rail and mirrored into the Codex work lane.';
  }

  if (saved === 'vivi-command') {
    return 'Direct Vivi command captured locally. It was mirrored into the Vivi command rail and the builder intake queue.';
  }

  if (saved === 'repair-request') {
    return 'Repair packet dispatched locally. Vivi now has a structured stabilization request in the queue.';
  }

  return undefined;
}

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default async function MissionControlPage({
  searchParams,
}: {
  searchParams?: Promise<{ legacy?: string; tab?: string; saved?: string }>;
}) {
  const query = await searchParams;

  if (query?.legacy !== '1' && process.env.LIONCOM_LEGACY_CONTROL_PLANE !== '1') {
    redirect('/control-plane-v2');
  }

  const data = await loadControlRoomData();

  return (
    <ControlRoomShell
      data={data}
      initialTab={coerceTab(query?.tab)}
      notice={mapNotice(query?.saved)}
    />
  );
}
