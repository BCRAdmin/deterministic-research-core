import { promises as fs } from 'fs';
import path from 'path';
import { NextRequest, NextResponse } from 'next/server';

import { PATHS, WORKSPACE_ROOT } from '@/lib/constants/paths';
import { syncAllControlPlanes } from '@/lib/services/controlPlaneSyncService';
import { appendRailBlock, parseRailBlocks, readRailContent } from '@/lib/services/structuredRailService';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

type VegaSessionStatus = 'idle' | 'active' | 'waiting' | 'archived';
type VegaRole = 'operator' | 'vega' | 'system';

interface VegaChatSession {
  id: string;
  title: string;
  topic: string;
  createdAt: string;
  updatedAt: string;
  status: VegaSessionStatus;
  lastMessagePreview: string;
  lastReference: string;
  latestActivity: string;
}

interface VegaChatMessage {
  id: string;
  sessionId: string;
  addedAt: string;
  role: VegaRole;
  status: string;
  summary: string;
  message: string;
  source?: string;
  reference?: string;
}

interface VegaChatPayload {
  action?: string;
  sessionId?: string;
  title?: string;
  topic?: string;
  message?: string;
  reason?: string;
  confirmEmpty?: boolean;
}

const CODEX_CHAT_HEADER = '# Codex Chat Thread\n\nAppend-only board-first conversation rail between operator and Codex.\n\n';
const MAX_SESSIONS = 48;
const MAX_TITLE_LENGTH = 120;
const MAX_TOPIC_LENGTH = 600;
const MAX_MESSAGE_LENGTH = 8000;

export async function GET() {
  return NextResponse.json(await buildSnapshot(), { headers: { 'Cache-Control': 'no-store' } });
}

export async function POST(request: NextRequest) {
  let payload: VegaChatPayload;

  try {
    payload = await request.json() as VegaChatPayload;
  } catch {
    return NextResponse.json({ error: 'Ungültiger Vega-Chat-Payload.' }, { status: 400 });
  }

  try {
    if (payload.action === 'create-session') {
      return NextResponse.json({ ok: true, snapshot: await createSession(payload) });
    }

    if (payload.action === 'update-session') {
      return NextResponse.json({ ok: true, snapshot: await updateSession(payload) });
    }

    if (payload.action === 'archive-session') {
      if (!payload.sessionId?.trim()) return NextResponse.json({ error: 'Session-ID fehlt.' }, { status: 400 });
      return NextResponse.json({ ok: true, snapshot: await archiveSession(payload.sessionId, payload.reason) });
    }

    if (payload.action === 'remove-session') {
      if (!payload.sessionId?.trim()) return NextResponse.json({ error: 'Session-ID fehlt.' }, { status: 400 });
      return NextResponse.json({ ok: true, snapshot: await removeEmptySession(payload.sessionId, Boolean(payload.confirmEmpty), payload.reason) });
    }

    if (payload.action === 'activate-session') {
      if (!payload.sessionId?.trim()) return NextResponse.json({ error: 'Session-ID fehlt.' }, { status: 400 });
      return NextResponse.json({ ok: true, snapshot: await activateSession(payload.sessionId) });
    }

    if (!payload.sessionId?.trim() || !clean(payload.message, MAX_MESSAGE_LENGTH)) {
      return NextResponse.json({ error: 'Session oder Nachricht fehlt.' }, { status: 400 });
    }

    return NextResponse.json({ ok: true, snapshot: await sendMessage(payload) });
  } catch (error) {
    if (error instanceof Error && error.message === 'session-not-found') {
      return NextResponse.json({ error: 'Session wurde nicht gefunden.' }, { status: 404 });
    }
    if (error instanceof Error && error.message === 'session-not-empty') {
      return NextResponse.json({ error: 'Diese Vega-Session hat bereits Inhalt. Bitte archivieren statt entfernen.' }, { status: 409 });
    }
    return NextResponse.json({ error: 'Vega-Chat konnte nicht aktualisiert werden.' }, { status: 500 });
  }
}

async function buildSnapshot() {
  const [sessions, thread] = await Promise.all([readSessions(), readRailContent(PATHS.CODEX_CHAT_THREAD)]);
  const messages = parseRailBlocks(thread)
    .map(parseVegaMessageBlock)
    .filter((entry): entry is VegaChatMessage => Boolean(entry))
    .sort((left, right) => compareDatesAsc(left.addedAt, right.addedAt) || left.id.localeCompare(right.id));
  const hydratedSessions = sessions
    .map((session) => hydrateSession(session, messages))
    .sort((left, right) => compareDatesAsc(right.updatedAt, left.updatedAt) || left.title.localeCompare(right.title));

  return {
    sessions: hydratedSessions,
    messages,
    activeSessionId: hydratedSessions[0]?.id,
  };
}

async function createSession(payload: VegaChatPayload) {
  const now = new Date().toISOString();
  const session: VegaChatSession = {
    id: slugTimestamp('VEGASESSION', now),
    title: clean(payload.title, MAX_TITLE_LENGTH) || 'Neue Vega-Session',
    topic: clean(payload.topic, MAX_TOPIC_LENGTH) || 'Technische Prüfung, Fehleranalyse oder Codebetrieb',
    createdAt: now,
    updatedAt: now,
    status: 'idle',
    lastMessagePreview: '',
    lastReference: '',
    latestActivity: 'Noch keine Nachricht gesendet.',
  };
  const sessions = await readSessions();
  await writeSessions([session, ...sessions].slice(0, MAX_SESSIONS));
  await appendSystemMessage(session, buildVegaBootContext(session), 'boot-context');
  await syncAllControlPlanes();
  return buildSnapshot();
}

async function updateSession(payload: VegaChatPayload) {
  const sessionId = payload.sessionId?.trim();
  const sessions = await readSessions();
  const existing = sessions.find((session) => session.id === sessionId);
  if (!existing) throw new Error('session-not-found');

  const next: VegaChatSession = {
    ...existing,
    title: clean(payload.title, MAX_TITLE_LENGTH) || existing.title,
    topic: clean(payload.topic, MAX_TOPIC_LENGTH) || existing.topic,
    updatedAt: new Date().toISOString(),
  };
  await writeSessions(sessions.map((session) => session.id === next.id ? next : session));
  await syncAllControlPlanes();
  return buildSnapshot();
}

async function activateSession(sessionId: string) {
  const sessions = await readSessions();
  const existing = sessions.find((session) => session.id === sessionId);
  if (!existing) throw new Error('session-not-found');
  const now = new Date().toISOString();
  const next: VegaChatSession = {
    ...existing,
    updatedAt: now,
    status: 'active',
    latestActivity: 'Vega-Session ist aktiv. Chatnachrichten bleiben in diesem Thread und erzeugen keinen Dispatch.',
  };
  await writeSessions(sessions.map((session) => session.id === sessionId ? next : session));
  await appendSystemMessage(next, 'Vega-Session aktiviert. Nutze diese Session fuer Code-, Debug-, Diff- oder QA-Fragen. Neue Auftraege gehoeren weiter in die Dispatch-Bruecke.', 'session-active');
  await syncAllControlPlanes();
  return buildSnapshot();
}

async function archiveSession(sessionId: string, reason?: string) {
  const sessions = await readSessions();
  const existing = sessions.find((session) => session.id === sessionId);
  if (!existing) throw new Error('session-not-found');
  await appendArchivedSession(existing, reason || 'Vega-Session archiviert.');
  await writeSessions(sessions.filter((session) => session.id !== sessionId));
  await syncAllControlPlanes();
  return buildSnapshot();
}

async function removeEmptySession(sessionId: string, confirmEmpty: boolean, reason?: string) {
  if (!confirmEmpty) throw new Error('session-not-empty');
  const sessions = await readSessions();
  const existing = sessions.find((session) => session.id === sessionId);
  if (!existing) throw new Error('session-not-found');
  if (await sessionHasOperatorOrVegaContent(existing)) throw new Error('session-not-empty');
  await appendArchivedSession(existing, reason || 'Leere Vega-Session entfernt.');
  await writeSessions(sessions.filter((session) => session.id !== sessionId));
  await syncAllControlPlanes();
  return buildSnapshot();
}

async function sendMessage(payload: VegaChatPayload) {
  const sessionId = payload.sessionId?.trim();
  const message = clean(payload.message, MAX_MESSAGE_LENGTH);
  const sessions = await readSessions();
  const existing = sessions.find((session) => session.id === sessionId);
  if (!existing) throw new Error('session-not-found');
  if (!message) throw new Error('message-required');

  const now = new Date().toISOString();
  const messageId = slugTimestamp('VCHAT', now);
  const summary = summarize(message);
  const block = [
    `### ${messageId}`,
    `- Added: ${now}`,
    `- Session Id: ${existing.id}`,
    `- Session Title: ${existing.title}`,
    '- Role: operator',
    '- Status: chat',
    '- Source: LIONCOM Control Plane V2 Vega Live Chat',
    `- Reference: ${existing.id}`,
    `- Summary: ${summary}`,
    '- Message:',
    ...quoteLines(message),
    '',
  ].join('\n');
  const next: VegaChatSession = {
    ...existing,
    updatedAt: now,
    status: 'waiting',
    lastMessagePreview: summary,
    lastReference: messageId,
    latestActivity: 'Operator-Nachricht im Vega-Livechat gespeichert.',
  };

  await appendRailBlock(PATHS.CODEX_CHAT_THREAD, CODEX_CHAT_HEADER, `${block}\n`);
  await writeSessions(sessions.map((session) => session.id === existing.id ? next : session));
  await syncAllControlPlanes();
  return buildSnapshot();
}

async function appendSystemMessage(session: VegaChatSession, message: string, status: string) {
  const now = new Date().toISOString();
  const messageId = slugTimestamp('VCHATSYS', now);
  const block = [
    `### ${messageId}`,
    `- Added: ${now}`,
    `- Session Id: ${session.id}`,
    `- Session Title: ${session.title}`,
    '- Role: system',
    `- Status: ${status}`,
    '- Source: LIONCOM Control Plane V2',
    `- Reference: ${session.id}`,
    '- Summary: Automatischer Vega-Kontext',
    '- Message:',
    ...quoteLines(message),
    '',
  ].join('\n');
  await appendRailBlock(PATHS.CODEX_CHAT_THREAD, CODEX_CHAT_HEADER, `${block}\n`);
}

async function readSessions(): Promise<VegaChatSession[]> {
  try {
    const parsed = JSON.parse(await fs.readFile(PATHS.CODEX_CHAT_SESSIONS, 'utf-8')) as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(isVegaChatSession).filter((session) => session.status !== 'archived').slice(0, MAX_SESSIONS);
  } catch {
    return [];
  }
}

async function writeSessions(sessions: VegaChatSession[]) {
  await fs.mkdir(path.dirname(PATHS.CODEX_CHAT_SESSIONS), { recursive: true });
  await fs.writeFile(PATHS.CODEX_CHAT_SESSIONS, `${JSON.stringify(sessions.slice(0, MAX_SESSIONS), null, 2)}\n`, 'utf-8');
}

async function appendArchivedSession(session: VegaChatSession, reason: string) {
  const archivePath = path.join(WORKSPACE_ROOT, '.runtime', 'vega-chat-sessions-archive.json');
  let archive: Array<{ archivedAt: string; reason: string; session: VegaChatSession }> = [];
  try {
    const parsed = JSON.parse(await fs.readFile(archivePath, 'utf-8')) as unknown;
    if (Array.isArray(parsed)) archive = parsed.filter((entry): entry is { archivedAt: string; reason: string; session: VegaChatSession } => Boolean(entry) && typeof entry === 'object' && 'session' in entry);
  } catch {
    archive = [];
  }
  await fs.mkdir(path.dirname(archivePath), { recursive: true });
  await fs.writeFile(archivePath, `${JSON.stringify([{ archivedAt: new Date().toISOString(), reason, session }, ...archive].slice(0, 500), null, 2)}\n`, 'utf-8');
}

async function sessionHasOperatorOrVegaContent(session: VegaChatSession): Promise<boolean> {
  const thread = await readRailContent(PATHS.CODEX_CHAT_THREAD);
  return parseRailBlocks(thread)
    .map(parseVegaMessageBlock)
    .some((message) => message?.sessionId === session.id && (message.role === 'operator' || message.role === 'vega'));
}

function hydrateSession(session: VegaChatSession, messages: VegaChatMessage[]): VegaChatSession {
  const sessionMessages = messages.filter((message) => message.sessionId === session.id);
  const lastMessage = sessionMessages[sessionMessages.length - 1];
  if (!lastMessage) return session;
  return {
    ...session,
    updatedAt: compareDatesAsc(lastMessage.addedAt, session.updatedAt) > 0 ? lastMessage.addedAt : session.updatedAt,
    lastMessagePreview: lastMessage.summary || summarize(lastMessage.message),
    lastReference: lastMessage.id,
    status: session.status === 'archived' ? 'archived' : lastMessage.role === 'operator' ? 'waiting' : 'active',
    latestActivity: lastMessage.role === 'operator' ? 'Operator-Nachricht wartet im Vega-Livechat.' : lastMessage.summary,
  };
}

function parseVegaMessageBlock(block: ReturnType<typeof parseRailBlocks>[number]): VegaChatMessage | null {
  const sessionId = block.fields['Session Id'];
  if (!sessionId) return null;
  const messageLines: string[] = [];
  let capture = false;

  for (const line of block.lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('- Message:')) {
      capture = true;
      const rest = trimmed.replace(/^- Message:\s*/, '');
      if (rest) messageLines.push(rest);
      continue;
    }
    if (capture && trimmed.startsWith('> ')) {
      messageLines.push(trimmed.slice(2));
    }
  }

  return {
    id: block.id,
    sessionId,
    addedAt: block.fields['Added'] || 'unknown',
    role: normalizeRole(block.fields['Role']),
    status: block.fields['Status'] || 'unknown',
    summary: block.fields['Summary'] || summarize(messageLines.join('\n')),
    message: messageLines.join('\n').trim() || block.fields['Summary'] || block.id,
    source: block.fields['Source'],
    reference: block.fields['Reference'],
  };
}

function isVegaChatSession(value: unknown): value is VegaChatSession {
  if (!value || typeof value !== 'object') return false;
  const candidate = value as Partial<VegaChatSession>;
  return Boolean(candidate.id && candidate.title && candidate.createdAt && candidate.updatedAt);
}

function normalizeRole(value?: string): VegaRole {
  const normalized = value?.trim().toLowerCase();
  if (normalized === 'vega' || normalized === 'codex') return 'vega';
  if (normalized === 'system') return 'system';
  return 'operator';
}

function buildVegaBootContext(session: Pick<VegaChatSession, 'id' | 'title' | 'topic'>): string {
  return [
    'Vega Auto-Start-Kontext:',
    `- Session: ${session.title} (${session.id})`,
    `- Thema: ${session.topic}`,
    `- Workspace Root: ${WORKSPACE_ROOT}`,
    '- Rolle: Vega ist Tech Cell fuer Code, Debugging, Verifikation, Repository-Diffs, Commits, Tests und QA.',
    '- Chat-Regel: Livechat bleibt in dieser Session. Neue operative Auftraege laufen ueber Dispatch-Bruecke oder Code-Aufgaben.',
    '- Trennung: Keine Vivi-Chats oder Vivi-Workspaces in dieser Session anzeigen.',
  ].join('\n');
}

function clean(value: string | undefined, maxLength: number): string {
  return typeof value === 'string' ? value.trim().slice(0, maxLength) : '';
}

function summarize(value: string): string {
  const compact = value.replace(/\s+/g, ' ').trim();
  return compact ? compact.slice(0, 180) : 'Vega Chat';
}

function quoteLines(value: string): string[] {
  return value.split('\n').map((line) => `> ${line}`);
}

function slugTimestamp(prefix: string, iso: string): string {
  const stamp = iso.replace(/[-:TZ]/g, '').replace('.', '').slice(0, 17);
  const entropy = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `${prefix}-${stamp}-${entropy}`;
}

function compareDatesAsc(left: string, right: string): number {
  const leftTime = Date.parse(left);
  const rightTime = Date.parse(right);
  return (Number.isNaN(leftTime) ? 0 : leftTime) - (Number.isNaN(rightTime) ? 0 : rightTime);
}
