import { QuellwertPaperFooter } from '@/components/quellwert/quellwert-paper-footer';
import { QuellwertPaperHeader } from '@/components/quellwert/quellwert-paper-header';
import { QuellwertLegalSubnav } from '@/components/quellwert/quellwert-legal-subnav';
import type { Metadata } from 'next';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export const metadata: Metadata = {
  title: 'Datenschutz | Quellwert (Preview)',
  description:
    'Lokale Quellwert-Preview: Datenschutzhinweis bleibt Operator-Gate vor externer Veröffentlichung.',
};

export default function QuellwertDatenschutzPage() {
  return (
    <main className="qw-page qwp-page" id="qwp-main" tabIndex={-1} lang="de">
      <QuellwertPaperHeader />
      <div id="qwp-content" tabIndex={-1} role="region" aria-label="Inhalt">
        <section className="qwp-hero qwp-narrow">
          <p className="qwp-kicker">Datenschutz</p>
          <h1>Datenschutzhinweis vor externer Veröffentlichung.</h1>
          <p>
            Die lokale Quellwert-Preview speichert auf dieser öffentlichen
            Research-Fläche keine Konten, keine Zahlungen und keine persönlichen
            Analyseprofile. Ein finaler Datenschutzhinweis bleibt Operator-Gate.
          </p>
          <QuellwertLegalSubnav current="datenschutz" />
        </section>

        <section className="qwp-disclaimer qwp-narrow" aria-label="Operator-Gate">
          <h2>Operator-Gate</h2>
          <p>
            Vor externer Veröffentlichung wird diese Seite mit finalen Angaben zu
            Verantwortlichem, Kontaktweg, Hosting, Logdaten und Rechtsgrundlagen
            geprüft. Bis dahin ist sie ein lokaler Preview-Hinweis.
          </p>
        </section>

        <QuellwertPaperFooter />
      </div>
    </main>
  );
}
