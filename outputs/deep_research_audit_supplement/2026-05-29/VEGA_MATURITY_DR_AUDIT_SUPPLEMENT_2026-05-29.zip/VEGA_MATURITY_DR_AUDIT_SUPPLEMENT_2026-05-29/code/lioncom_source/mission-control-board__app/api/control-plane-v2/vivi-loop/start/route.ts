import { NextResponse } from 'next/server';

import { loadControlPlaneV2Data } from '@/lib/control-plane-v2/live-data';
import { startLocalDuoLoop } from '@/lib/services/localViviRunnerService';

export const dynamic = 'force-dynamic';

export async function POST() {
  const start = await startLocalDuoLoop();
  const snapshot = await loadControlPlaneV2Data();

  return NextResponse.json({
    ok: start.ok,
    mode: start.mode,
    detail: start.detail,
    snapshot,
  });
}
