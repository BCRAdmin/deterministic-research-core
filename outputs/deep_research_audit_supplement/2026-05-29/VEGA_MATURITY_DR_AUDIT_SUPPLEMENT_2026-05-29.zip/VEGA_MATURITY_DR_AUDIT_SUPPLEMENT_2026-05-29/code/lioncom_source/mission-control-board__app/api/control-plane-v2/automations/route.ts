import { execFile } from 'node:child_process';
import { promises as fs } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { promisify } from 'node:util';

import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

const execFileAsync = promisify(execFile);
const uid = typeof process.getuid === 'function' ? process.getuid() : 501;
const launchAgentsDir = path.join(os.homedir(), 'Library', 'LaunchAgents');
const disabledDir = path.join(launchAgentsDir, 'LIONCOM.disabled');
const appRoot = process.cwd();
const logsDir = path.join(os.homedir(), 'Library', 'Application Support', 'LIONCOM', 'automation', 'logs');

const protectedLabels = new Set([
  'com.lioncom.local-control-plane',
  'com.lioncom.remote-bridge-ingress',
]);

const allowedPrefixes = ['com.lioncom.'];

type AutomationAction = 'start' | 'stop' | 'archive' | 'create';
type AutomationStatus = 'running' | 'stopped' | 'disabled' | 'archived';
type AutomationTemplate = 'flight-pack' | 'vivi-health' | 'golden-baseline';

interface AutomationPayload {
  action?: AutomationAction;
  label?: string;
  template?: AutomationTemplate;
}

interface AutomationItem {
  id: string;
  label: string;
  name: string;
  status: AutomationStatus;
  schedule: string;
  detail: string;
  protected: boolean;
  canStart: boolean;
  canStop: boolean;
  canArchive: boolean;
}

interface TemplateDefinition {
  id: AutomationTemplate;
  label: string;
  name: string;
  intervalSeconds: number;
  command: string;
  detail: string;
}

const templates: TemplateDefinition[] = [
  {
    id: 'flight-pack',
    label: 'com.lioncom.v2-flight-pack-refresh',
    name: 'V2 Flight-Pack Refresh',
    intervalSeconds: 1800,
    command: `${quote(process.execPath)} ${quote(path.join(appRoot, 'scripts', 'create_control_plane_v2_flight_pack.mjs'))}`,
    detail: 'Erzeugt regelmäßig einen lokalen Offline-/Flugmodus-Snapshot für V2.',
  },
  {
    id: 'vivi-health',
    label: 'com.lioncom.vivi-health-probe',
    name: 'Vivi Health Probe',
    intervalSeconds: 900,
    command: `${quote(process.execPath)} ${quote(path.join(appRoot, 'scripts', 'check_vivi_night_run_health.mjs'))}`,
    detail: 'Prüft Vivi Night Health lokal und schreibt Logs ohne externe Sends.',
  },
  {
    id: 'golden-baseline',
    label: 'com.lioncom.golden-baseline',
    name: 'Golden Baseline',
    intervalSeconds: 3600,
    command: `${quote(process.execPath)} ${quote(path.join(appRoot, 'scripts', 'run_golden_baseline_due.mjs'))}`,
    detail: 'Startet den lokalen Golden-Baseline-Check, wenn er fällig ist.',
  },
];

export async function GET() {
  return NextResponse.json({ ok: true, automations: await listAutomations(), templates });
}

export async function POST(request: NextRequest) {
  let payload: AutomationPayload = {};
  try {
    payload = await request.json() as AutomationPayload;
  } catch {
    return NextResponse.json({ ok: false, message: 'Ungültige Automation-Anfrage.' }, { status: 400 });
  }

  try {
    if (payload.action === 'create') {
      const template = templates.find((item) => item.id === (payload.template ?? 'flight-pack'));
      if (!template) return NextResponse.json({ ok: false, message: 'Unbekannte Automation-Vorlage.' }, { status: 400 });
      await createAutomation(template);
      return NextResponse.json({ ok: true, message: `${template.name} wurde lokal angelegt.`, automations: await listAutomations() });
    }

    const label = normalizeLabel(payload.label);
    if (!label) return NextResponse.json({ ok: false, message: 'Automation-Label fehlt oder ist nicht erlaubt.' }, { status: 400 });
    if (protectedLabels.has(label) && (payload.action === 'stop' || payload.action === 'archive')) {
      return NextResponse.json({
        ok: false,
        message: 'Diese Kern-Automation hält die lokale Oberfläche am Leben und wird nicht aus V2 heraus gestoppt oder archiviert.',
        automations: await listAutomations(),
      }, { status: 409 });
    }

    if (payload.action === 'start') {
      await startAutomation(label);
      return NextResponse.json({ ok: true, message: `${prettyName(label)} wurde gestartet.`, automations: await listAutomations() });
    }

    if (payload.action === 'stop') {
      await stopAutomation(label);
      return NextResponse.json({ ok: true, message: `${prettyName(label)} wurde gestoppt und deaktiviert.`, automations: await listAutomations() });
    }

    if (payload.action === 'archive') {
      await archiveAutomation(label);
      return NextResponse.json({ ok: true, message: `${prettyName(label)} wurde nicht-destruktiv archiviert.`, automations: await listAutomations() });
    }

    return NextResponse.json({ ok: false, message: 'Unbekannte Automation-Aktion.' }, { status: 400 });
  } catch (error) {
    return NextResponse.json({
      ok: false,
      message: error instanceof Error ? error.message : 'Automation-Aktion fehlgeschlagen.',
      automations: await listAutomations().catch(() => []),
    }, { status: 500 });
  }
}

async function listAutomations(): Promise<AutomationItem[]> {
  await fs.mkdir(launchAgentsDir, { recursive: true });
  await fs.mkdir(disabledDir, { recursive: true });
  const entries = await fs.readdir(launchAgentsDir);
  const activeFiles = entries
    .filter((entry) => entry.startsWith('com.lioncom.') && entry.endsWith('.plist'))
    .map((entry) => path.join(launchAgentsDir, entry));
  const archivedFiles = (await fs.readdir(disabledDir).catch(() => []))
    .filter((entry) => entry.startsWith('com.lioncom.') && entry.includes('.plist'))
    .map((entry) => path.join(disabledDir, entry));

  const active = await Promise.all(activeFiles.map((filePath) => readAutomation(filePath, false)));
  const archived = await Promise.all(archivedFiles.map((filePath) => readAutomation(filePath, true)));
  return [...active, ...archived].sort((a, b) => Number(b.status === 'running') - Number(a.status === 'running') || a.name.localeCompare(b.name));
}

async function readAutomation(filePath: string, archived: boolean): Promise<AutomationItem> {
  const xml = await fs.readFile(filePath, 'utf-8');
  const label = extractTagAfterKey(xml, 'Label') || path.basename(filePath).replace(/\.plist(?:\.disabled)?$/, '');
  const running = archived ? false : await isRunning(label);
  const disabled = archived ? true : await isDisabled(label);
  const protectedItem = protectedLabels.has(label);
  const status: AutomationStatus = archived ? 'archived' : running ? 'running' : disabled ? 'disabled' : 'stopped';
  return {
    id: label,
    label,
    name: prettyName(label),
    status,
    schedule: describeSchedule(xml),
    detail: describeProgram(xml),
    protected: protectedItem,
    canStart: !archived && status !== 'running',
    canStop: !protectedItem && status === 'running',
    canArchive: !protectedItem && !archived,
  };
}

async function startAutomation(label: string): Promise<void> {
  const plistPath = path.join(launchAgentsDir, `${label}.plist`);
  await assertFile(plistPath);
  await safeLaunchctl(['enable', `gui/${uid}/${label}`]);
  await safeLaunchctl(['bootstrap', `gui/${uid}`, plistPath]);
  await safeLaunchctl(['kickstart', '-k', `gui/${uid}/${label}`]);
}

async function stopAutomation(label: string): Promise<void> {
  await safeLaunchctl(['bootout', `gui/${uid}/${label}`]);
  await safeLaunchctl(['disable', `gui/${uid}/${label}`]);
}

async function archiveAutomation(label: string): Promise<void> {
  const plistPath = path.join(launchAgentsDir, `${label}.plist`);
  await assertFile(plistPath);
  await stopAutomation(label);
  await fs.mkdir(disabledDir, { recursive: true });
  await fs.rename(plistPath, path.join(disabledDir, `${label}.plist.disabled`));
}

async function createAutomation(template: TemplateDefinition): Promise<void> {
  const plistPath = path.join(launchAgentsDir, `${template.label}.plist`);
  await fs.mkdir(logsDir, { recursive: true });
  await fs.writeFile(plistPath, renderPlist(template), 'utf-8');
  await safeLaunchctl(['disable', `gui/${uid}/${template.label}`]);
}

async function isRunning(label: string): Promise<boolean> {
  try {
    await execFileAsync('launchctl', ['print', `gui/${uid}/${label}`], { timeout: 3000 });
    return true;
  } catch {
    return false;
  }
}

async function isDisabled(label: string): Promise<boolean> {
  try {
    const { stdout } = await execFileAsync('launchctl', ['print-disabled', `gui/${uid}`], { timeout: 3000 });
    const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return new RegExp(`"${escaped}"\\s*=>\\s*true`).test(stdout);
  } catch {
    return false;
  }
}

async function safeLaunchctl(args: string[]): Promise<void> {
  try {
    await execFileAsync('launchctl', args, { timeout: 5000 });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (!/Input\/output error|service already loaded|No such process|Could not find service|service is not loaded|Bootstrap failed/i.test(message)) {
      throw new Error(`launchctl ${args.join(' ')}: ${message}`);
    }
  }
}

async function assertFile(filePath: string): Promise<void> {
  await fs.access(filePath).catch(() => {
    throw new Error(`LaunchAgent nicht gefunden: ${filePath}`);
  });
}

function normalizeLabel(label?: string): string | null {
  const value = label?.trim();
  if (!value || !allowedPrefixes.some((prefix) => value.startsWith(prefix))) return null;
  if (!/^[a-zA-Z0-9_.-]+$/.test(value)) return null;
  return value;
}

function extractTagAfterKey(xml: string, key: string): string | null {
  const match = xml.match(new RegExp(`<key>${key}</key>\\s*<string>([^<]+)</string>`));
  return match ? unescapeXml(match[1]) : null;
}

function describeSchedule(xml: string): string {
  const interval = xml.match(/<key>StartInterval<\/key>\s*<integer>(\d+)<\/integer>/)?.[1];
  if (interval) {
    const seconds = Number(interval);
    if (seconds < 120) return `alle ${seconds}s`;
    if (seconds < 7200) return `alle ${Math.round(seconds / 60)} min`;
    return `alle ${Math.round(seconds / 3600)} h`;
  }
  const hour = xml.match(/<key>Hour<\/key>\s*<integer>(\d+)<\/integer>/)?.[1];
  const minute = xml.match(/<key>Minute<\/key>\s*<integer>(\d+)<\/integer>/)?.[1] ?? '00';
  if (hour) return `täglich ${hour.padStart(2, '0')}:${minute.padStart(2, '0')}`;
  if (xml.includes('<key>KeepAlive</key>')) return 'dauerhaft';
  return 'manuell';
}

function describeProgram(xml: string): string {
  const args = Array.from(xml.matchAll(/<array>[\s\S]*?<string>([^<]+)<\/string>[\s\S]*?<\/array>/g))[0]?.[0] || '';
  const strings = Array.from(args.matchAll(/<string>([^<]+)<\/string>/g)).map((match) => unescapeXml(match[1]));
  if (strings[0] === '/bin/bash' && strings[1] === '-lc' && strings[2]) return compactCommand(strings[2]);
  if (strings[0] === '/bin/bash' && strings[1]) return compactCommand(strings[1]);
  return strings.slice(0, 2).map(compactCommand).join(' ') || 'Lokaler LaunchAgent';
}

function compactCommand(value: string): string {
  return value
    .replace(os.homedir(), '~')
    .replace(appRoot, 'LIONCOM-App')
    .slice(0, 140);
}

function prettyName(label: string): string {
  return label
    .replace(/^com\.lioncom\./, '')
    .replace(/[.-]/g, ' ')
    .replace(/\b\w/g, (char) => char.toUpperCase());
}

function renderPlist(template: TemplateDefinition): string {
  const stdout = path.join(logsDir, `${template.label}.out.log`);
  const stderr = path.join(logsDir, `${template.label}.err.log`);
  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>${escapeXml(template.label)}</string>
  <key>ProgramArguments</key>
  <array>
    <string>/bin/bash</string>
    <string>-lc</string>
    <string>cd ${escapeXml(quote(appRoot))} &amp;&amp; ${escapeXml(template.command)}</string>
  </array>
  <key>WorkingDirectory</key>
  <string>${escapeXml(appRoot)}</string>
  <key>RunAtLoad</key>
  <false/>
  <key>StartInterval</key>
  <integer>${template.intervalSeconds}</integer>
  <key>StandardOutPath</key>
  <string>${escapeXml(stdout)}</string>
  <key>StandardErrorPath</key>
  <string>${escapeXml(stderr)}</string>
</dict>
</plist>
`;
}

function quote(value: string): string {
  return `'${value.replace(/'/g, "'\\''")}'`;
}

function escapeXml(value: string): string {
  return value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function unescapeXml(value: string): string {
  return value.replace(/&quot;/g, '"').replace(/&gt;/g, '>').replace(/&lt;/g, '<').replace(/&amp;/g, '&');
}
