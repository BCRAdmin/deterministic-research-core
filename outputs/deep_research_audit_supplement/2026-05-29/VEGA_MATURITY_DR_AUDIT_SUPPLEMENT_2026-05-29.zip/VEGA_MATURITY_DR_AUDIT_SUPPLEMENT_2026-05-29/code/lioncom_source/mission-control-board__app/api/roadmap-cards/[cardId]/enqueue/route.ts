import { NextResponse } from 'next/server';

import {
  enqueueRoadmapCard,
  isRoadmapCardNotFoundError,
  isRoadmapCardValidationError,
} from '@/lib/services/roadmapCardService';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function POST(
  _request: Request,
  context: { params: Promise<{ cardId: string }> },
) {
  try {
    const { cardId } = await context.params;
    const result = await enqueueRoadmapCard(decodeURIComponent(cardId));
    return NextResponse.json({ ok: true, ...result }, {
      headers: {
        'Cache-Control': 'no-store',
      },
    });
  } catch (error) {
    if (isRoadmapCardNotFoundError(error)) {
      return NextResponse.json({ error: error.message }, { status: 404 });
    }
    if (isRoadmapCardValidationError(error)) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    return NextResponse.json({ error: 'Roadmap-Karte konnte nicht in die Pipeline gelegt werden.' }, { status: 500 });
  }
}
