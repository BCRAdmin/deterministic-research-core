import { NextResponse } from 'next/server';

import { loadViviSkillSnapshot } from '@/lib/vivi-skills/registry';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function GET() {
  try {
    const snapshot = await loadViviSkillSnapshot();
    return NextResponse.json({
      generatedAt: snapshot.generatedAt,
      hub: snapshot.hub,
      latestProposals: snapshot.latestProposals,
      counts: snapshot.counts,
    });
  } catch {
    return NextResponse.json({ error: 'Vivi Skill-Hub konnte nicht geladen werden.' }, { status: 503 });
  }
}
