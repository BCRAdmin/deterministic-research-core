---
title: Multi-Agent Research Build Roadmap
status: implemented_internal_v1
date: 2026-05-21
owner: Vega
scope: internal-first
---

# Multi-Agent Research Build Roadmap

## Kurzentscheidung

Wir bauen keinen MiroFish-Fork und keinen sofortigen LIONCOM-Einbau. Der richtige Weg ist:

1. `vega-multi-agent-research` als lokalen Codex/Vivi-Skill stabilisieren. Status: erledigt.
2. Den Workflow als wiederholbaren Research-/Ideen-/Strategie-Baustein nutzen. Status: erledigt für interne CLI-/Skill-Nutzung.
3. Nach 5-10 echten internen Läufen entscheiden, ob daraus eine getrennte kleine App analog Room16 entsteht. Status: 5 technische Piloten gruen; keine App jetzt.
4. LIONCOM erst anbinden, wenn es einen nachweisbar nützlichen Run-Vertrag, Artefaktstruktur und Operator-Gate gibt. Status: Adapter bewusst nicht gebaut, weil CLI/Skill reicht.
5. Externe Produktisierung nur greenfield/service-first, nicht auf AGPL-MiroFish-Codebasis. Status: bewusst deferred.

## Zielbild

Ein interner Scenario-/Research-Sandbox-Baustein, den Vega und Vivi bei passenden Aufgaben nutzen koennen:

- Quellen oder Kontext rein.
- Enge Debattenfrage rein.
- 3-6 Rollen diskutieren in 1-3 Runden.
- Rohtranskript, Synthese, Claims-to-check, Konflikte und nächste Tests raus.
- Alles bleibt `candidate_only`, bis Vega/Operator es prüft.

Der Mehrwert ist nicht "mehr Agenten = besser", sondern: kontrollierte Perspektivenspannung, sichtbare Widersprueche, besserer Skeptiker-Modus und wiederverwendbare Artefakte.

## Harte Grenzen

- Keine automatische Promotion von Agentenmeinungen in Obsidian, LIONCOM, Room16 oder Public-Artefakte.
- Keine Nutzung als Finanz-, Rechts-, Medizin- oder Public-Entscheider.
- Keine AGPL-Codeuebernahme aus MiroFish ohne Lizenzentscheidung.
- Keine Zep-/Cloud-Memory-Pflicht in V1.
- Keine LIONCOM-Runtime-Änderung, bis der Skill in internen Läufen stabil und nützlich ist.
- Keine Multi-Agenten-Läufe für einfache Faktenfragen, kleine Code-Fixes oder klare Zusammenfassungen.

## Architektur

### Schicht 1: Skill und Runner

Aktueller Stand:

- Skill: `/Users/BjornRosinger/.codex/skills/vega-multi-agent-research/`
- Runner: `/Users/BjornRosinger/.codex/skills/vega-multi-agent-research/scripts/multi_agent_panel.py`
- Repo-Einstiegspunkte: `scripts/ops/context_pack_builder.py` und `scripts/ops/multi_agent_panel.py` als duenne Wrapper auf den lokalen Skill
- Modi: `research`, `ideas`, `website`, `strategy`
- Output: `TRANSCRIPT.md`, `SYNTHESIS.md`, `events.json`, `metadata.json`
- Ergaenzter Output: `CLAIMS_TO_CHECK.md`, `RUN_REPORT.md`, `AUDIT_LOG.json`, `run_config.resolved.json`
- DeepSeek/Ollama-Default: `think:false`
- Validator: gruen mit `Skill is valid!`

Umgesetzt:

- Output-Schema formalisiert.
- Health-Gates geschaerft.
- Konfigurationsdateien für wiederholbare Runs ergänzt.
- Repo-Einstiegspunkte unter `scripts/ops/` ergänzt.
- URL-only Quellen, Datenklassifikation und Audit-Log als QA-Kanten eingebaut.

### Schicht 2: Kontextpaket

Jeder Lauf braucht ein kurzes Kontextpaket:

- belegte Fakten
- Quellenlinks oder lokale Quellenpfade
- Annahmen
- verbotene Claims
- Entscheidungsfrage
- Zielgruppe / Auftragstyp
- gewuenschter Output

Ohne Kontextpaket wird kein "voller" Multi-Agenten-Lauf gestartet. Sonst diskutieren Agenten nur aus Luft.

### Schicht 3: Agentenbibliothek

Standard-Sets:

- `research`: Source Analyst, Skeptic, Operator, Market Lens, User Advocate
- `ideas`: Divergent Builder, Customer Voice, Distribution Lens, Risk Skeptic, Editor
- `website`: Target Buyer, Conversion Lens, Trust Skeptic, Local Buyer, Operator
- `strategy`: Founder, Finance, Legal/Privacy, Customer, Delivery

Ausbau:

- Custom-Agenten per JSON-Datei für spezielle Zielgruppen.
- Wiederverwendbare Sets für Utility-Websites, Room16/Quellwert, Produktideen, lokale Dienstleister, SaaS, Creator/Info-Produkte.
- Agentenprofile kurz halten, damit Rollen nicht zu Theater werden.

### Schicht 4: Moderator und Claim Review

Die Synthese muss immer trennen:

- belegte Fakten
- Agentenannahmen
- echte Konflikte
- Konsens
- Top-Massnahmen
- Claims-to-check
- nächster kleinster Test

Vega/Operator entscheidet, nicht der Moderator.

### Schicht 5: Memory und Handoff

Outputs bleiben lokal im passenden Projektordner. Obsidian bekommt nur dauerhafte Learnings, keine Rohmeinungen.

Promotion-Regel:

- Rohtranskript: nie automatisch in Memory.
- Synthese: nur als Candidate oder Projektartefakt.
- Dauerhafte Regeln: nur nach Vega-Prüfung in `Learnings and Fixes`, Projektnote oder Skill-Routing.
- Produkt-/Launch-Ideen: in `Project Seeds`, wenn sie echten Folgewert haben.

## Build-Phasen

### P0 - Fundament sichern

Status: erledigt.

Erledigt:

- MiroFish als Pattern analysiert.
- Schulz-Reinigungsdienst-Test als Einzelmodell- und Multi-Agentenlauf durchgefuehrt.
- DeepSeek/Ollama-Learning `think:false` gefunden.
- Skill `vega-multi-agent-research` erstellt.
- Runner erstellt.
- `PyYAML` installiert und Skill-Validator repariert.
- Skill in Skill Inventory, Selection Matrix, Research Dossier Loop und Memory verankert.
- Alter Spike-Runner `scripts/ops/scenario_sandbox_debate.py` wurde durch den validierten Skill-Runner ersetzt und aus dem Repo-Workingtree entfernt.
- Raw-Scenario-Outputs unter `outputs/scenario_sandbox/` sind lokale Testevidence und werden nicht versioniert; dauerhafte Learnings stehen im Vault und in dieser Roadmap.
- Verification-Run 2026-05-21 fand und fixte fehlende Git-Versionierung der Repo-Einstiegspunkte `scripts/ops/context_pack_builder.py` und `scripts/ops/multi_agent_panel.py`.

Definition of Done:

- Skill ist validiert.
- Erster Smoke hat `empty_turns=0`, `error_turns=0`.
- Memory sagt nicht mehr, dass der Validator kaputt ist.

### P1 - Runner produktionsnah haerten

Status: erledigt.

Ziel: Der Runner soll auch spaeter ohne Erinnerungsarbeit korrekt laufen.

Aufgaben:

- `run_config.json` oder YAML akzeptieren: Kontextpfad, Frage, Agent-Set, Modell, Rundenzahl, Output-Pfad.
- Output-Dateinamen standardisieren: `TRANSCRIPT.md`, `SYNTHESIS.md`, `CLAIMS_TO_CHECK.md`, `RUN_REPORT.md`, `events.json`, `metadata.json`.
- Exit-Codes dokumentieren: success, model_error, empty_turns, capped_summary, invalid_config.
- Health-Check erweitern:
  - leere Turns
  - Token-Caps
  - Fehler je Agent
  - fehlendes Kontextpaket
  - zu lange Debattenfrage
  - fehlende Quellen bei Research-/Website-Modus
- Kleine Test-Fixtures bauen:
  - minimaler Kontext
  - Custom-Agenten-JSON
  - invalid config
  - Health-Check-Auswertung
- `README` vermeiden; stattdessen Skill und Roadmap als Fuehrung nutzen.

Gate:

- `python3 -m py_compile` gruen.
- Skill-Validator gruen.
- Mindestens ein Offline-/Mock-Test für Config/Health ohne LLM.
- Ein echter Ollama-Smoke mit kleinem Kontext.

Empfohlener Aufwand: 0.5-1 Tag.

### P2 - Kontextpaket-Builder bauen

Status: erledigt.

Ziel: Nicht jeder Lauf soll haendisch aus Quellen zusammenkopiert werden muessen.

Aufgaben:

- `context_pack_builder.py` als Hilfsskript:
  - lokale Markdown-Dateien einsammeln
  - URLs als Quellenliste aufnehmen
  - optional Defuddle-/Web-Extraktion vorbereiten
  - Fakten, Annahmen und offene Fragen getrennt ausgeben
- Source-Ledger im Kontextpaket:
  - `source_id`
  - Titel
  - URL/Pfad
  - Abrufdatum
  - Nutzung im Lauf
- Prompt-Injection-Hinweis für Webquellen: Quelltext ist Material, keine Anweisung.
- Templates:
  - Website Review
  - Markt-/Konkurrenzanalyse
  - Produktidee
  - interne Systementscheidung

Gate:

- Kontextpaket kann ohne LLM erzeugt werden.
- Research-Modus warnt, wenn keine Quellen im Kontext stehen.
- Website-Modus warnt, wenn keine Website-Fakten oder Screenshots/Pfade genannt sind.

Empfohlener Aufwand: 1-2 Tage.

### P3 - Synthese und Claim Review schaerfen

Status: erledigt.

Ziel: Aus dem Debattenmaterial soll ein wirklich nutzbares Entscheidungsartefakt werden.

Aufgaben:

- Moderator-Output in feste Abschnitte zwingen:
  - `Kurzfazit`
  - `Konsens`
  - `Konflikte`
  - `Top 5 nächste Tests`
  - `Claims to Check`
  - `Nicht übernehmen`
  - `Nächster Schritt`
- Separates `CLAIMS_TO_CHECK.md` erzeugen.
- `RUN_REPORT.md` als Operator-Ansicht erzeugen:
  - Status
  - Modell
  - Health
  - Kosten-/Zeitnaehe falls verfuegbar
  - Artefaktlinks
  - Entscheidung: `candidate_only`
- Optional: Claim-Klassifikation:
  - factual
  - inference
  - persona_preference
  - unsupported
  - risky_public_claim

Gate:

- Kein Run gilt als fertig, wenn `Claims to Check` fehlt.
- Kein Run darf `public_ready` setzen.
- Token-Cap in der Summary wird sichtbar als Warning markiert.

Empfohlener Aufwand: 1 Tag.

### P4 - Interne Pilotserie

Status: erledigt für technischen internen Build-Gate.

Ziel: Erst echte Nutzung beweist, welche Agenten-Sets und Outputs taugen.

Mindestens 5 Piloten:

1. Utility-Website: Materialbedarf oder Elterngeld Messaging/Funnel.
2. Lokaler Dienstleister: zweiter Website-/Angebotstest neben Schulz.
3. Produktidee: 48h Launch-/Messaging-Simulation.
4. Room16/Quellwert: nur interne Stakeholder-/Lesbarkeits- oder Review-Queue-Simulation, keine Finanzentscheidung.
5. LIONCOM/Vivi: interne Systementscheidung, z. B. welche Capability als Nutzeroberflaeche sichtbar werden soll.

Pro Pilot speichern:

- Kontextpaket
- Transkript
- Synthese
- Claims-to-check
- Operator-Readout
- kurze Bewertung: besser als Einzelmodell ja/nein/warum

Gate für Weiterbau:

- Mindestens 3 von 5 Piloten liefern klaren Mehrwert gegenueber Einzelmodell.
- Mindestens 2 konkrete Entscheidungen oder bessere Tests entstehen daraus.
- Keine haeufigen Halluzinations-/Claim-Probleme ohne erkennbare Health-Warnung.

Ergebnis 2026-05-21:

- 5/5 technische DeepSeek-Piloten gruen: `exit_code=0`, keine leeren Turns, keine Modellfehler, keine Caps, Claims-to-check vorhanden.
- Pilotserie-Bericht: `outputs/scenario_sandbox/pilot_series_2026-05-21/PILOT_SERIES_REPORT.md`.
- Finaler Validierungslauf: `outputs/scenario_sandbox/final_validation_2026-05-21/deepseek_run/RUN_REPORT.md`.
- Qualitativer Mehrwert: die Piloten erzeugten direkt neue Fixes (`data_classification`, URL-only Guard, Audit-Log, Handoff-QA).

Empfohlener Aufwand: 1-2 Wochen nebenbei.

### P5 - Vivi/Codex Arbeitsintegration

Status: erledigt für lokales Handoff.

Ziel: Vivi und Codex sollen wissen, wann der Skill zu nutzen ist, ohne jedes Mal neu zu diskutieren.

Aufgaben:

- Skill-Routing in Vault weiter schaerfen:
  - Research Dossier Loop
  - Skill Selection Matrix
  - Vivi Skill Inventory
  - ggf. Auftragstyp Routing Decision Tree
- Standardformulierungen für Vivi:
  - "Kontextpaket bauen"
  - "Multi-Agentenlauf nur bei Perspektivenspannung"
  - "Synthese candidate_only"
  - "Claims-to-check vor Empfehlung"
- Handoff-Format definieren:
  - `question`
  - `context_pack_path`
  - `agent_set`
  - `output_dir`
  - `operator_decision_needed`
- Keine automatische Hintergrundautomation. Runs bleiben explizit oder durch klaren Auftrag getriggert.

Gate:

- Vivi/Codex kann in einem neuen Auftrag begruenden, warum Multi-Agenten passend oder unpassend sind.
- Ein Run kann reproduzierbar aus einem Handoff gestartet werden.

Empfohlener Aufwand: 0.5-1 Tag.

### P6 - Separate interne Scenario-Sandbox-App prüfen

Status: bewusst deferred.

Ziel: Nur wenn die Pilotserie zeigt, dass eine UI echten Nutzen bringt.

App ist getrennt von LIONCOM, eher Room16-artig.

Minimaler Funktionsumfang:

- Kontextpaket anlegen.
- Agent-Set waehlen.
- Frage formulieren.
- Run starten.
- Health und Kosten-/Dauerhinweis sehen.
- Transcript und Synthese lesen.
- Claims-to-check abhaken.
- Operator-Entscheidung speichern: discard, keep_candidate, promote_learning, create_task.

Technikoption:

- Kleine lokale Web-App im bestehenden Workspace oder separatem Repo.
- Backend ruft den bestehenden Runner.
- Keine Zep-Pflicht.
- Keine Kundendaten ohne Auth/Retention/Privacy-Policy.

Gate vor Bau:

- Mindestens 5 interne Runs.
- Wiederholter Bedarf nach UI statt CLI.
- Klarer Speicherort für Artefakte.
- Operator will mehrere Runs vergleichen.

Empfohlener Aufwand MVP: 2-4 Tage.

### P7 - Optionaler LIONCOM-Einbau

Status: bewusst deferred.

Ziel: LIONCOM soll den Skill nur sichtbar machen, nicht die Wahrheitsschicht unkontrolliert verändern.

Moeglicher kleiner Einbau:

- Neue Capability Card: `Scenario / Multi-Agent Research`.
- Formular für:
  - Debattenfrage
  - Kontextquelle/Pfad
  - Agent-Set
  - Zielordner
- Run-Status anzeigen:
  - pending
  - running
  - completed_candidate
  - failed_health_check
- Artefaktlinks in Operator Inbox.
- Keine Auto-Promotion in Memory.
- Keine Public-/Production-Freigabe.

Nicht einbauen:

- keine permanente Agenten-Diskussion als Chat-Spielerei
- keine Zep-/Graph-Memory-Abhaengigkeit
- keine automatische Outreach-/Website-/Report-Änderung
- keine Kundendaten ohne Auth/Privacy-Gate

Gate:

- Separate App oder CLI ist stabil.
- Output-Contract und Health-Check sind robust.
- Operator will Runs im Control Plane sehen.
- LIONCOM-Runtime-Sync und Verifier sind definiert.

Empfohlener Aufwand Minimaladapter: 1-2 Tage nach P6.

### P8 - Externe Produktisierung

Status: bewusst deferred.

Ziel: Nur service-first und greenfield.

Moegliches Angebot:

- `48h Launch- & Messaging-Simulation`
- Zielgruppen: Gruender, Agenturen, DACH-KMU, Creator/Info-Produkte
- Output:
  - Zielgruppenreaktionen
  - Einwandmatrix
  - Messaging-Ranking
  - Risiko-/Backlash-Check
  - Copy-Varianten
  - nächster Realtest

Vorgehen:

1. 3 Beispielreports aus internen oder fiktiven Cases bauen.
2. Landing-/PDF-Angebot formulieren.
3. 3-5 bezahlte Piloten verkaufen.
4. Erst danach entscheiden, ob Tool/App/SaaS Sinn ergibt.

Grenzen:

- Kein MiroFish-Code kopieren.
- Keine AGPL-Abhaengigkeit ins Produkt.
- Kein "predict anything".
- Nur directional/candidate_only.
- Keine sensiblen Kundendaten ohne DPA/Retention/Auth.

Gate:

- Mindestens 3 zahlende Piloten.
- Wiederholbares Delivery-Template.
- Klarer Preisanker.
- Recht-/Datenschutz-Scope geklärt.

Empfohlener Aufwand Service-Pilot: 3-7 Tage für Angebot + Beispiele, danach Verkaufstest.

## Erledigte Tasks

1. P1: Runner um Config-Datei und stabilere Health-Gates erweitert.
2. P1: `RUN_REPORT.md` und `CLAIMS_TO_CHECK.md` automatisch erzeugt.
3. P1: Offline-Tests für Config, Custom-Agenten und Health geschrieben.
4. P2: Kontextpaket-Builder und Website-/Research-/Produkt-/System-Templates gebaut.
5. P3: Moderator-Synthese in festen Output-Vertrag gebracht.
6. P3: `AUDIT_LOG.json` ergänzt.
7. P4: fuenf technische interne DeepSeek-Piloten durchgefuehrt.
8. P5: Vivi-Handoff-Template materialisiert.
9. Repo-Einstiegspunkte für Context Builder und Panel Runner erstellt.
10. Entscheidung nach Pilotserie dokumentiert: CLI/Skill reicht jetzt; separate App und LIONCOM-Adapter deferred.

## Wann Wir Stoppen

Stoppen oder parken, wenn:

- die Pilotserie keinen klaren Mehrwert gegenueber Einzelmodell zeigt
- Health-/Claim-Probleme trotz Gates zu hoch bleiben
- der Workflow mehr Meta-Arbeit als Entscheidungshilfe erzeugt
- LIONCOM-Integration nur aus Vollstaendigkeitsdrang entsteht
- keine wiederholbare interne Nachfrage sichtbar ist

## Empfehlung

Interner V1 ist nutzbar. Keine LIONCOM-Integration und keine separate App jetzt. Weiter mit echten Anwendungsfaellen im CLI-/Skill-Modus; erst bei wiederholtem UI-Bedarf oder Operator-Queue-Bedarf eine Scenario-Sandbox-App bauen. Externe Produktisierung bleibt service-first mit Beispielreports und bezahlten Piloten.
