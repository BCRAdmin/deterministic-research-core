# Background Quality Gates Policy

Status: active

Purpose: run quality checks as background gates instead of spawning new agent roles.

## Gates

- `Design Quality Gate`: domain fit, layout density, responsive text fit, component choice and screenshot verification.
- `Motion Quality Gate`: purpose, frequency, reduced-motion behavior, performance and layout stability.
- `Anti-Slop UI Review`: generic AI UI, placeholder copy, decorative card overuse and missing workflow behavior.
- `Readable Report Delivery Standard`: evidence layer, readable DR overview, PDF for document-like reports and post-export verification.

## Related Language Gate

- `Humanizer Copy Lint`: AI-slop language review for non-evidence copy and document-like reports. It is review-only for research, legal, financial, YMYL and operator-truth outputs; it may flag `significance_inflation`, `promotional_language`, `superficial_ing_analysis` and `vague_attribution`, but it must not rewrite facts, evidence, ratings, source meaning, legal/financial claims or uncertainty.

## Rule

These gates are capabilities, not agents. They run inside existing build, review, audit and report flows.

If a gate repeatedly produces standalone job cards, artifacts, verifier results, handoffs and memory updates, it may be evaluated later by the Agentization Decision Gate.
