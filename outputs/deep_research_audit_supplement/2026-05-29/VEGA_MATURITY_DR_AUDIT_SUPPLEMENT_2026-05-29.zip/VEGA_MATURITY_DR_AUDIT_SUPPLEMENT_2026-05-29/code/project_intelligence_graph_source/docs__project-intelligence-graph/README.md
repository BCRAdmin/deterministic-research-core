# Project Intelligence Graph v2 Control Layer

Lokaler Phase-0/1/2-Index und Operator-Control-Layer für DreamFactory/Vega/Vivi.

## Umgesetzt

1. Relationship-Schema: `docs/project-intelligence-graph/RELATIONSHIP_SCHEMA.json`
2. Provenance pro Kante: `source_path`, `source_span`, `source_sha256`
3. Temporal/Superseded-Status: `observed_at`, `valid_from`, `valid_to`, `status`
4. Drift-Report: `outputs/project_intelligence_graph/drift_report.md`
5. Subgraph-View: `outputs/project_intelligence_graph/subgraph-lioncom-room16-quellwert.html`
6. Local Search: `scripts/project_intelligence_graph/pig.py local "..."`
7. Global Search: `scripts/project_intelligence_graph/pig.py global "..."`
8. Hybrid Retrieval: `scripts/project_intelligence_graph/pig.py hybrid "..."`
9. Explain / Context Packs / View Rendering / Selftest
10. Node-Schema, Predicate-Registry und Policy-Regeln
11. Automation Risk Registry
12. Operator Decision Inbox
13. Coverage Manifest
14. Policy & Gate Report
15. Full Check als One-Command-Build
16. Operator Decision State für akzeptierte, delegierte, snoozed oder geschlossene Inbox-Items
17. Operator Brief als einfachste Bedienansicht
18. Hardening Fix Contracts für robuste künftige Änderungen
19. Quality Control Gate mit Vorher/Nachher-Regressionsprüfung
20. Quality Operating System Contracts: Build Contract Template, Job Card Template, Execution History Minimum, Archetype Library V1
21. Roadmap-/Contract-/Archetype-/Job-Card-Quality-Gate inkl. n8n-Template-only-Grenze
22. Planning-Quality-Control-View als Operator-Surface-Vorbereitung
23. Complete-Context-Before-Archival-Gate für Canonical System-/Rule-Noten
24. Long-Run-Completion-Audit für Nightrun-/Autoloop-Abschlussreports
25. Vault-Umlaut-Hygiene-Check für alte `ae/oe/ue`-Schreibweisen in sichtbarer Prosa
26. Skill-/Policy-Regression-Guard-Audit für Auto-Research-, Verbesserungsloop- und Agenten-Entry-Points
27. Systemwide Rule Propagation Registry: prüft, ob neue Operator-Regeln an Skills, Policies, Agenten-Entry-Points und Runtime-Rails angekommen sind
28. Project Invariant Registry: macht projektübergreifende Nicht-ohne-Go-Grenzen, Verifier und Operator-Surfaces maschinenlesbar
29. Agent Entry Point Registry: listet die Startpunkte, an denen systemweite Regeln sichtbar sein müssen
30. Operator Intent Contract: übersetzt breite/müde Operator-Signale in Zielbild, Nicht-Ziele, betroffene Projekte, Gates, Kostenregel, Verifier und nächsten sicheren Block
31. Impact Radius Assessment: mappt Operator-Signale deterministisch auf betroffene Projekte, Regeln, Gates, Verifier und nächste sichere Blöcke
32. German Output Quality Gate: prüft deutsche operator-facing Outputs auf echte Umlaute, sichtbare Reasoning-/KI-/Placeholder-/Render-Leaks und Humanizer-nur-als-Lint-Grenzen
33. Autonomy Governor: prüft lokale Workstreams auf sichere nächste Arbeit, Operator-Gates, Refill-Bedarf und verifizierten Abschluss
34. Fresh Session Readiness Audit: prüft, ob führende Vault-/Agenten-Einstiege Zweck, Status, Synonyme, Grenzen, Evidence, Verifier und nächsten sicheren Schritt enthalten
35. Autonomy Dirt/Backlog Scan: klassifiziert lokale Arbeitsbaum-Dirt-, Backlog-, Verifier- und Gate-Signale über PIG, LIONCOM, Room16, Kanzlei AI Assist und Agent Ops
36. Dirty Ownership Classifier: ordnet Dirty-Einträge in `source_change`, `verifier_or_test`, `operator_doc_or_handoff`, `generated_artifact`, `gated_runtime_or_source_artifact` oder `unknown` ein, ohne Cleanup, Push oder Löschung auszuführen
37. Operator Brief Dirt Surface: zeigt `autonomy_dirt_backlog_scan_status`, `autonomy_dirty_project_count` und `autonomy_dirt_ownership_summary` direkt im Operator Brief
38. Dirty Handoff Cards: erzeugt pro Projekt und Ownership-Kategorie reviewbare Cards mit Datei-Samples, sicheren nächsten Schritten, Verifier-Hinweisen und Gate-Markierung
39. Vivi -> Vega Handoff Inbox: liest Vivi-Reports, Task-Claims, CODEX-Inbox, Command-Queue und Autonomie-State und macht daraus reviewbare Vega-Reaktionskarten mit Verifier-, Lifecycle- und Operator-Gate-Markierung
40. Fresh Data Intake: erkennt neue lokale Projekt-/Runtime-Daten wie Room16-Hardening, Room16-Verifikation, Public-Library-Status, Room16-Review-Gate-Status, Room16-Manual-Review-Packets, LIONCOM-Rails und spätere Kanzlei-/Utility-Datenreife-Artefakte, klassifiziert sie read-only und zeigt nächste sichere Schritte im Operator Brief
41. Vivi Job Card Queue: übersetzt Fresh-Data-Action-Items in providerneutrale Job Cards mit Auftrag, Zielbild, erlaubten/verbotenen Aktionen, Output-Vertrag, Evidence, Verifier, Stop-Regel und Übergabe an Vega/PIG/Operator
42. Vivi Runner MVP: validiert genau eine ready Job Card, führt nur allowlistete lokale PIG-Verifier aus, schreibt Execution History und stoppt bei Operator-Gates oder fehlender Evidence
43. Vivi Safe Project Worker v2: materialisiert Worker-Karten für lokale Projekt-Verifier-, Readiness- und Generated-Artifact-Review-Claims, führt nur Allowlist-Commands aus, schreibt Execution History, Evidence und Supervisor-Urteil, und hält Push/Delete/Publish/Production/Public/Geld/Auth/externe Kommunikation/echte Daten hart operator-gated
44. Endgame Macro Roadmap: trennt Foundation-/Quality-OS-Grün von der unfertigen mehrwöchigen Produkt-Roadmap, damit LIONCOM Cockpit v2, Projektvertikalen und Launch-/Revenue-Vorbereitung als sichere große Restblöcke im Autonomy Governor sichtbar bleiben
45. Project Vertical Rollout: führt Room16, Kanzlei AI Assist, Utility-Websites und Membership als lokale Projekt-Rails mit Verifierstatus, Claim-Typen, Evidence, erlaubter Arbeit und harten Operator-Gates
46. Launch/Revenue Local Preflight: schließt Launch- und Umsatzarbeit als lokales Handoff-Paket mit 100% Preflight, während Public, Production, Geld, Auth/Credentials, Provider und externe Kommunikation geschlossen bleiben
47. Safe Local Commit Hygiene: nach verifiziertem Abschluss kann eine aktive lokale Freigabe reviewed Source-/Verifier-/Operator-Doku-Commits erlauben, während Generated Evidence, gated Artifacts, Push, Delete, Publish, Deploy, Public, Production, Geld, Auth/Credentials und externe Kommunikation weiter getrennte Gates bleiben
48. Model Provider Truth Guard: materialisiert Kimi-K2.6-, Ollama-Cloud-, Vivi-Duo-Loop- und Room16-Modellprofil-Wahrheit scope-gebunden, damit requested/effective/fallback, Cloud-Offload, historische Reports, aktive Projektlaufoptionen und App-spezifische Modellpicker nicht vermischt werden
49. Status Semantics Matrix: trennt Verifier-Erfolg, lokale Artefaktlage, publishbare Ausgabe, offene Operator-Gates und externe Validierung, damit `PASS`, `WARN` und `completed_verified` nicht als Public-/Produktions- oder Audit-Reife missverstanden werden
50. North-Star Decision Kernel: materialisiert B00 aus dem DreamFactory-Endziel-Paket als aktiven lokalen Zielkontrakt mit Pflichtfeldern für Block, Claim-Type, Quellen, Verifier, Rollback und Gate-Assessment, damit neue Arbeit nicht wieder in Microfix-Schleifen driftet; nach verifiziertem B01-Fixture schaltet der Roadmap-State den nächsten sicheren Block auf B02
51. Status Semantics Fixtures: verankert B01 mit einem deterministischen Room16-Stale-Fall, damit ein altes PIG-FAIL plus aktueller Projekt-PASS als `stale_conflict=WARN` und nicht als aktueller Produktfehler behandelt wird
52. Source Registry & Evidence Spine: materialisiert B02 als lokales Quellenrückgrat mit SourceRecord-Schema, EvidenceCapsule-Schema, `source_registry.json`, `evidence_spine.json` und Audit, damit Claims Herkunft, Sensitivität, Frische, Sharing-Status, Zitierregel und Raw-Exclusions tragen
53. Contradiction & Staleness Engine: materialisiert B03 mit Fixtures für stale-vs-current, out-of-scope contamination und local-PASS-vs-launch-WARN, damit widersprüchliche Statusflächen als explizite Entscheidungen statt als verstecktes Grün erscheinen
54. Research Bundle Builder v2: erweitert den sanitisierten Deep-Research-Follow-up-Pack um B02 Source Registry, Evidence Spine und B03 Contradiction Decisions und verifiziert Redaction, Secret-/Leak-Scan, ZIP-Integrität und Pflichtdateien lokal
55. Portable Evidence Capsule: materialisiert B05 als kleine claim-level Beweisoberfläche mit Source-IDs, relativen Evidence-Pfaden, Hashes, Verifiern und geschlossenen Gates, ohne Rohgraphdaten, absolute Ursprungspfade oder externe Weitergabe
56. Deep Research Ingestion: materialisiert B06 als lokale Claim-Routing-Schicht für Deep-Research-Befunde mit Source-IDs, Zielblock, Memory-Route, Verifier und geschlossenen Gates, ohne Rohdaten, Runtime-Aktion oder externe Wirkung
57. Vivi Worker v3: materialisiert B07 als lokalen Claim-Plan und Supervisor-Audit mit erlaubten Claim-Typen, Denylist, Source-/Verifier-Pflicht, Status-Semantik-Split, negativen Failure-Fixtures und geschlossenen Runtime-/External-/Irreversible-Gates
58. LIONCOM Decision Cockpit: materialisiert B08 als lokale Operator-Entscheidungsfläche mit 9 Karten für Mission, Evidenz, Widersprüche, Produkt-Rails, Worker, Gates, Research-Ingestion und Dependency-/License-Inbox; LIONCOM liest die Fläche read-only über `/api/decision-cockpit`
59. Product Rail Matrix: materialisiert B09 als lokale Produkt-Rail-Matrix für Room16, Kanzlei AI Assist, Utility-Websites und Membership/Quellwert mit getrennten Achsen für lokalen Verifier, Artefaktzustand, Launch-Posture, Public, Production, Payment, Auth, externe Validierung und Operator-Gates; LIONCOM liest die Fläche read-only über `/api/product-rail-matrix`
60. Room16 QualityDecision Integration: materialisiert B10 als lokale PIG-Integration aus Room16 QualityDecision-Core, Schema, Tests, App-Wiring, Core-V2-Handoff, B09-Rail-Achsen, Review-Gate, Manual-Review-Paketen und Publish-Readiness; der Audit kann `PASS` sein, während Room16 bewusst `public_ready=0`, `effective_public=0` und `promotion_readiness=blocked` bleibt
61. Kanzlei Synthetic Factory: materialisiert B11 als synthetische, lokal verifizierte Kanzlei-AI-Assist-Nachweisschiene mit Verify-All, Product Readiness, Golden-Case-Inventar, Synthetic-only-Guard und geschlossenen DATEV-/Real-Data-/Cloud-/Auth-/Production-/External-/Final-Tax-Gates
62. Quellwert Data Maturity: materialisiert B12 als lokale Quellwert-/Utility-/Membership-Datenreife-Schicht mit Utility-Data-Maturity, Membership-Preview, Launch-Readiness, B09-Rail-Achsen und B11-Abhängigkeit; ein Audit-`PASS` bedeutet konsistente lokale Evidenz und geschlossene External-Analytics-/Public-/Production-/Payment-/Auth-/Financial-Advice-Gates, nicht Datenreife, Launch oder Monetarisierung
63. License Dependency Governance: materialisiert B13 als Kandidaten- und Dependency-Governance mit Third-Party-Source-Candidates, lokalen Dependency-Manifesten und Bundle-Inclusion-Regeln; ein Audit-`PASS` bedeutet nur prüfbare interne Review-Queue, `legal_conclusion=none` und `redistribution_status=not_cleared`
64. Release Train Activation Readiness: materialisiert B14 als lokale Release-Train- und Aktivierungsbereitschaft mit Room16-, Kanzlei-, Utility/Membership-, LIONCOM-, Research-Sharing- und Commit/Cleanup-Trains; ein Audit-`PASS` bedeutet nur vollständige lokale Gate-/Verifier-/Handoff-Evidence, nicht Aktivierung, Public, Production, Deploy, Payment, Auth, externe Kommunikation oder Redistribution-Clearance
65. Maturity State: materialisiert B15 als kanonische Status-Wahrheit mit getrennten Verifier-, Artefakt-, Domain-, Gate- und External-Layern; `overall_truth=control_plane_pass_maturity_warn_operator_gated` verhindert aggregiertes Grün ohne Warn-/Gate-Kontext
66. Repo Hygiene Reconciliation: materialisiert B16 als `clean_or_intentionally_dirty`-Manifest für Dirty-Slices; es klassifiziert Source, Verifier, generierte Artefakte, gated Runtime/Source und Agent-Ops-Fremdscope, ohne zu löschen, zu committen oder zu pushen
67. Sanitized Evidence Capsule v3: materialisiert B17 als minimales Review-Profil mit Source-ID, relativen Pfaden, SHA-256 und kurzen Claims; absolute Pfade, Secrets, Rohgraph, `pig.py`-Monolith und Full-Check-Monolith bleiben im Minimalprofil draußen
68. Vivi v3.1 Maturity Cards: materialisiert B18 als MissionCard-Schicht mit `evidence_delta`, `stale_after`, `supersedes`, `rollback_note`, `expected_verifier` und Duplicate-No-Delta-Schutz
69. Existing Rails Perfection: materialisiert B19 als je eine nächste sichere Verbesserung und eine No-Go-Zeile für Room16, Kanzlei AI Assist, Quellwert/Utility/Membership und LIONCOM, ohne Scope-Ausweitung oder Gate-Öffnung
70. Roadmap Reconciliation v2: materialisiert B20 als aktuelle Missionswahrheit `B20-B27 maturity_kernel_v2`, unterdrückt historische B02/B03/B14-Next-Steps und markiert OpenJarvis/Jarvis als `foreign_scope_inventory`, das nicht zur DreamFactory-Completion zählt
71. Evidence Budget & Bundle Sanitizer v4: materialisiert B21 mit Profilen `minimal_shareable`, `internal_review` und `local_code_review`, Budgetgrenzen, Monolith-Ausschluss im Minimalprofil und Do-not-forward-Kennzeichnung für lokale Review-Bundles
72. Reversible Dirt Burn-Down: materialisiert B22 als Dirt-/Generated-Artifact-/Commit-Hygiene-Manifest mit Owner, Gate, Expiry, Restore-Regel und frischer Approval-Prüfung, ohne Commit, Push, Hard Delete oder Cleanup auszuführen
73. Operator Brief v4: materialisiert B23 als kompakten B20-B27-Cockpit-Report mit maximal sieben aktuellen Aktionen, sichtbaren Hard Gates und Snapshots für Dirt, Evidence Budget, Vivi v3.2 und Rail-Slice
74. Vivi v3.2 Precision Worker: materialisiert B24 als genau drei kleine lokale Worker-Karten mit einem Evidence-Delta, einem Verifier, engen Allow-/Deny-Grenzen und Duplicate-No-Delta-Guard
75. Existing Rails Quality Slice: materialisiert B25 mit je einem lokalen Artefakt für Room16, Kanzlei AI Assist, Quellwert/Utility/Membership und LIONCOM, jeweils mit Verifier und No-Go-Linie, ohne Room16-Rerun, echte Daten, Public, Production, Payment, Auth oder externe Wirkung
76. Efficiency & Monolith Pressure: materialisiert B26 als Code-Pressure-, Generated-Evidence-Dedup- und PIG-Extraction-Map, damit Monolith-Druck sichtbar wird, ohne riskante Großrefactors auszuführen
77. Sanitized B20-B26 Capsule: materialisiert B27 als minimale, hashbasierte Abschlusskapsel über die B20-B26-Artefakte mit `absolute_user_path_count=0`, `secret_count=0`, ohne `pig.py`, ohne Full-Check-Monolith und ohne externe Weitergabe
78. Bundle Reference Lint: materialisiert B28 als Selbstkonsistenz-Gate für Review-Bundles, damit alle referenzierten Quellen existieren, Hashes stimmen und Archivmitgliedschaft explizit ist
79. Evidence Budget Enforcer: materialisiert B29 als Testbericht über das B21-Budget, damit minimal-shareable Artefakte klein, pfadarm und ohne Monolith-/Raw-Graph-Mitnahme bleiben
80. Markdown Renderer Regression: materialisiert B30 als Report-Renderer-Regression, damit Listen aus Dictionaries nicht mehr als leere `item`-Bullets in Operator-Reports erscheinen
81. Reversible Dirt Burn-Down v2: materialisiert B31 mit Commit-ready-Batches, Quarantine/Restore-Manifest und Residual-Dirt-Gates, ohne Delete, Commit, Push oder Cleanup auszuführen
82. PIG Pressure Relief Slice: materialisiert B32 als kleine Helper-Extraktion nach `scripts/project_intelligence_graph/report_markdown.py`; der Full-Check-Fixpoint erkennt reine Self-Reference-Kaskaden, statt sie als echte Regression zu melden
83. Vivi v3.3 Claim Lifecycle Demo: materialisiert B33 als genau einen lokalen Vivi-Claim von `ready` über Evidence-Delta und Verifier bis `completed_verified_local`
84. Existing Rails Quality Delta v2: materialisiert B34 als je einen lokalen Qualitätsdelta für Room16, Kanzlei AI Assist, Quellwert/Utility/Membership und LIONCOM, ohne Scope-Ausweitung oder Gate-Öffnung
85. B28-B35 Final Verification: materialisiert B35 mit Three-Cycle-Worklog, finaler Verifier Summary, Operator Brief v5 und minimal-shareable B28-B35-Capsule; `final_truth=maturity_kernel_v3_verified_reduced_self_consistent_operator_gated`
86. M15-M22 North-Star Expansion: materialisiert die nächste lokale candidate-only Schicht mit aktuellem Roadmap-Kernel, One-App Daily Cockpit, Decision-/Dirt-Lane, Vivi Safe Work Loop v4, Product Rail Matrix, Evidence Pack Factory v3, Controlled Activation Dry-Runs und Acceptance Dossier; `final_truth=north_star_m15_m22_candidate_only_operator_gated`, `north_star_reached=false`, `pilot_execution_status=not_run_requires_3_to_7_day_local_time_window`
87. Capability Registry: materialisiert `Thin Roles, Thick Rails` als maschinenlesbare Schicht zwischen Skill und Agent mit `Shannon Security Sandbox`, CodeGraph/Codeneedle/Rowboat-Benchmarks, Design-/Motion-/Anti-Slop-Gates, Report-/Repo-Standards und Agentization-Gate
88. Shannon Security Sandbox Contract: hält `Shannon`, `Shanon` und `KeygraphHQ/shannon` als `sandbox_only` mit Scope-, Daten-, Credential-, Docker-/Worker-, AGPL- und Human-Verification-Gates; `runtime_action_executed=false`
89. Fresh Session Context Budget: begrenzt Capability-Aufträge auf maximal vier Kernnoten und erzwingt Overview-Notizen, bevor alte Reports oder große Attachments in frische Sessions geladen werden
90. Background Quality Gates: materialisiert Design-, Motion-, Anti-Slop- und Readable-Report-Prüfungen als Gates mit Checklisten und Verifier-Status, nicht als neue Agentenrollen
91. Capability Telemetry: materialisiert ein belegtes Nutzungs-Ledger mit Wertmetriken, Evidence-Pfaden, Agentization-Gate und LIONCOM-Surface-Werten, damit Capability-Wert sichtbar wird, ohne neue Agentenrollen zu erfinden
92. Agentization Decision Gate: entscheidet deterministisch, ob eine Capability mangels Trigger/Job-Card/Artefakt/Verifier/Handoff/Memory als Capability bleibt oder nach Telemetrie und Lifecycle-Beweis überhaupt Agent-Kandidat werden darf
93. Agent Product Maturity Contract: hält Produktagenten hinter einem zweiten Vertrag mit Operator-Problem, Zielnutzer, Job Cards, Artefakt, Verifier, Handoff, Memory, Safety, Kontextbudget, Operator-Surface, Support und kommerzieller/operativer Rolle
94. Separate Acceptance Runner: bietet einen kleinen projektübergreifenden Profil-Einstieg für wiederholbare Akzeptanz-Audits, ohne `full-check` zu ersetzen oder ein neues Framework zu starten
95. Operator Expectation Autonomy Model: materialisiert Björns Erwartung als Warn-First-Regel, damit Vega/Vivi wiederkehrenden Dirt, Pfadchaos, Scope-Drift, Operator-Korrekturen und Abschlussclaims als Muster-, Root-Cause-, Verifier- und Memory-Frage behandeln

## Quellen

Der Scanner liest lokal:

- Human-Overview-Vault Markdown und Canvas
- Room16/Quellwert Handoff-, Claim-, Lane- und Evidence-Artefakte
- lokale Codex-Automation-Metadaten unter `~/.codex/automations`
- Canonical System-/Rule-Noten für Vollständigkeit vor Ablage/Archivierung
- PIG-Rule-/Invariant-/Entry-Point-Registries für systemweite Regelverteilung
- German-Output-Quality-Registry für projektübergreifende deutsche Reports, Dokumente, E-Mails, Vault-Prosa, Room16-Readouts und Humanizer-Lint-Grenzen
- Autonomy-Governor-Registry für sichere Arbeit, Refill, Operator-Gates und Abschlussdisziplin
- führende Vault- und Agenten-Einstiege für Fresh-Session-Readiness
- lokale Projekt-Arbeitsbäume und bekannte deterministic Verifier für Autonomie-Dirt-/Backlog-Sichtung
- LIONCOM Vivi-/Codex-Handoff-Rails, damit Vivi-Ausgaben nicht nur im Chat oder Board stehen, sondern als Vega-Reaktions-Inbox prüfbar sind
- Fresh-Data-Quellen wie Room16 `.runtime/room16-app/hardening`, `.runtime/room16-app/verification`, `.runtime/room16-app/public-library`, `.runtime/room16-app/review-gate-status`, `.runtime/room16-app/manual-review-packets`, LIONCOM-Runtime-Rails und optionale Kanzlei-/Utility-Output-Pfade
- Status-Semantik-Quellen wie `project_vertical_rollout.json`, `launch_readiness_package.json`, aktuelle Projektverifier und bekannte stale Konfliktartefakte, um lokale Prüfbarkeit von Publish-/External-Readiness zu trennen
- Status-Semantik-Fixtures wie `STATUS_SEMANTICS_FIXTURES.json`, damit stale-vs-current, scoped-vs-global und Gate-geschlossene Fälle reproduzierbar bleiben
- Source-Registry-Quellen wie das Endziel-Roadmap-Pack, B00/B01-PIG-Outputs, Obsidian-Handoff-Notizen, Deep-Research-Pack-Artefakte, aktuelle Projektverifier und explizite Raw-/Secret-/Regulated-Data-Exclusions
- Capability-Registry-Quellen wie `CAPABILITY_REGISTRY_SCHEMA.json`, `CAPABILITY_REGISTRY_POLICY.md`, `capability_registry.json`, `capability_registry_audit.json`, `shannon_security_sandbox_contract.json` und `fresh_session_context_budget.json`, damit Namen, Gates, Sandboxes und Agentization-Status ohne Agenten-Bloat rekonstruierbar bleiben
- Capability-Telemetrie-Quellen wie `CAPABILITY_TELEMETRY_SCHEMA.json`, `CAPABILITY_TELEMETRY_POLICY.md`, `CAPABILITY_USAGE_LEDGER.json` und `capability_registry_telemetry.json`, damit echte Nutzung, Wertbelege und Agent-Kandidaten getrennt sichtbar bleiben
- Agentization-Gate-Quellen wie `AGENTIZATION_DECISION_GATE_SCHEMA.json`, `AGENTIZATION_DECISION_GATE_POLICY.md` und `agentization_decision_gate.json`, damit neue Agentennamen erst nach Telemetrie, Lifecycle-Proof und Operator-Surface-Sichtbarkeit entstehen
- Agent-Product-Contract-Quellen wie `AGENT_PRODUCT_MATURITY_CONTRACT_SCHEMA.json`, `AGENT_PRODUCT_MATURITY_CONTRACT_POLICY.md` und `agent_product_maturity_contract.json`, damit spätere Agent-Produkte nicht ohne Produktreifevertrag, Support-/Rollback-Pfad und Kontextbudget entstehen
- Background-Quality-Gate-Quellen wie `BACKGROUND_QUALITY_GATES_POLICY.md` und `background_quality_gates.json`, damit UI-/Motion-/Anti-Slop-/Report-Qualität im bestehenden Workflow geprüft wird statt als eigene Persona zu starten
- Contradiction-Fixtures wie `CONTRADICTION_FIXTURES.json`, Status-Semantik, Source Registry, Launch Readiness und Operator-Surface-Daten, um stale Konflikte, Scope-Drift und lokale-vs-externe Reife getrennt zu halten
- Research-Bundle-v2-Quellen wie `build_deep_research_followup_pack.py`, `SOURCE_REGISTRY.json`, `REDACTION_REPORT.json`, B02/B03-Artefakte, SHA-256-Manifest und ZIP-Integritätsprüfung
- Portable-Evidence-Quellen wie `source_registry.json`, `evidence_spine.json`, `contradiction_staleness_report.json`, `research_bundle_builder_v2_audit.json`, `full_check_report.json` und die B05-Capsule-Policy, um lokale PASS-Claims kompakt und pfadarm belegbar zu machen
- Deep-Research-Ingestion-Quellen wie `source_registry.json`, `contradiction_staleness_report.json`, `portable_evidence_capsule.json`, `launch_readiness_package.json`, `status_semantics_matrix.json` und die B06-Policy, um Research-Befunde in blockierte, verifierbare Claim-Routen zu übersetzen
- Vivi-Worker-v3-Quellen wie `VIVI_WORKER_V3_SCHEMA.json`, `VIVI_WORKER_V3_POLICY.md`, `deep_research_ingestion.json`, `source_registry.json`, `portable_evidence_capsule.json`, `contradiction_staleness_report.json` und `status_semantics_matrix.json`, damit Vivi nur lokale Claim-Karten mit Quellen, Verifiern, Denylist und Supervisor-Audit planen darf
- LIONCOM-Decision-Cockpit-Quellen wie `lioncom_decision_cockpit.json`, `lioncom_decision_cockpit_audit.json`, `source_registry.json`, `deep_research_ingestion.json`, `vivi_worker_v3_supervisor_audit.json` und die Mirror-Dateien unter `mission-control-board-mirror`, damit Operator-Entscheidungen lokal sichtbar, aber nicht runtime-mutierend werden
- Product-Rail-Matrix-Quellen wie `product_rail_matrix.json`, `product_rail_matrix_audit.json`, `project_vertical_rollout.json`, `launch_readiness_package.json`, `status_semantics_matrix.json`, `source_registry.json` und die Mirror-Dateien unter `mission-control-board-mirror`, damit lokale Produktreife je Rail sichtbar bleibt, ohne Public-, Production-, Payment-, Auth- oder externe Validierungs-Gates zu öffnen
- Room16-QualityDecision-Quellen wie `room16/core/quality_decision.py`, `room16/core/schemas/quality_decision.schema.json`, `tests/test_quality_decision_single_source.py`, `room16-app/server.mjs`, Core-V2-Handoff/Evidence, aktuelle Room16-German-Output-Evidence, Review-Gate-Status, Manual-Review-Pakete und Publish-Readiness, damit QualityDecision-Lifecycle-Wahrheit nicht mit Publish-/Public-Reife verwechselt wird
- Kanzlei-Synthetic-Factory-Quellen wie `kanzlei-ai-assist/scripts/verify/synthetic_factory.py`, `kanzlei-ai-assist/outputs/synthetic_factory/latest-synthetic-factory.json`, `kanzlei-ai-assist/outputs/product_readiness/latest-product-readiness.json`, `kanzlei-ai-assist/outputs/verify_all/latest-verify-all.json`, `kanzlei-ai-assist/docs/validation/SYNTHETIC_FACTORY.md` und `docs/project-intelligence-graph/KANZLEI_SYNTHETIC_FACTORY_POLICY.md`, damit lokale Kanzlei-Evidence synthetisch bleibt und echte Mandantendaten, DATEV, Cloud, Auth, Production, externe Kommunikation und finale Steuerentscheidungen geschlossen bleiben
- Quellwert-Data-Maturity-Quellen wie `outputs/utility_websites/data_maturity/latest-data-maturity-status.json`, `outputs/project_intelligence_graph/utility_membership_launch_readiness.json`, `outputs/project_intelligence_graph/project_vertical_membership_preview_verifier.json`, `product_rail_matrix.json`, `product_rail_matrix_audit.json`, `kanzlei_synthetic_factory_audit.json` und `docs/project-intelligence-graph/QUELLWERT_DATA_MATURITY_POLICY.md`, damit Utility-/Membership-Evidence lokal geprüft wird, ohne externe Analytics, Public, Production, Payment, Auth oder Financial-Advice-Publishing zu öffnen
- License-Dependency-Governance-Quellen wie `09_THIRD_PARTY_SOURCE_CANDIDATES.json`, `source_registry_audit.json`, `research_bundle_builder_v2_audit.json`, `quellwert_data_maturity_audit.json` und lokale Manifeste (`package.json`, `package-lock.json`, `pyproject.toml`, `requirements*.txt`, `uv.lock`), damit Drittquellen und Dependencies als Review-Kandidaten sichtbar werden, ohne Rechtsurteil, Redistribution-Clearance oder externe Veröffentlichung
- Release-Train-Activation-Quellen wie `launch_readiness_package.json`, `product_rail_matrix_audit.json`, `room16_quality_decision_integration_audit.json`, `kanzlei_synthetic_factory_audit.json`, `quellwert_data_maturity_audit.json`, `license_dependency_governance_audit.json`, `operator_brief.json` und `quality_os_operator_surface.json`, damit Aktivierungspfade lokal prüfbar sind, ohne Public, Production, Deploy, Payment, Auth, externe Kommunikation, Room16-Rerun, echte Daten oder irreversible Aktionen zu öffnen
- Model-/Provider-Truth-Quellen wie LIONCOM `.runtime/local-duo-loop-status.json`, `.runtime/vivi-model-route-status.json`, Room16 `src/model-profiles.json` und manuell geprüfte Kimi-/Ollama-Quellen-Snapshots
- North-Star-Quellen wie das lokale `vega_dreamfactory_endziel_roadmap_pack.zip`, die aktuelle Status-Semantik, Operator-Gates und PIG-Hardening-Contracts, um jede neue Arbeit an Block, Zielbeitrag, Evidence und Verifier zu binden
- Maturity-Kernel-v2-Quellen wie `vega_b20_b27_maturity_kernel_pack.zip`, `maturity_state.json`, `repo_hygiene_reconciliation.json`, `sanitized_evidence_capsule_v3.json`, `vivi_maturity_cards.json`, `existing_rails_perfection.json`, aktuelle Full-Check-Schritte, Review-Bundle-Scans und die B20-B27-Schemas, um lokale Reife, Evidence-Budget, Dirt-Hygiene, Operator-Brief, Vivi-v3.2-Karten, Rail-Slices und Monolith-Druck getrennt zu prüfen
- Maturity-Kernel-v3-Quellen wie `vega_b28_b35_true_3h_maturity_run_pack.zip`, `bundle_reference_lint.json`, `evidence_budget_enforcer_test_report.json`, `markdown_renderer_regression_report.json`, `dirt_burndown_v2.json`, `pig_helper_extraction_report.json`, `vivi_v3_3_supervisor_audit.json`, `existing_rails_quality_delta_v2.json`, `final_verification_summary.json`, `operator_brief_v5.json` und `sanitized_b28_b35_capsule.json`, um Bundle-Selbstkonsistenz, Evidence-Budget, Renderer-Qualität, Dirt-Gates, Vivi-Lifecycle, Rail-Deltas und B35-Abschluss getrennt zu prüfen

Er schreibt keine Vault- oder Runtime-Dateien um.

## Befehle

```bash
python3 scripts/project_intelligence_graph/scan_project_intelligence_graph.py
python3 scripts/project_intelligence_graph/scan_project_intelligence_graph.py --validate
python3 scripts/project_intelligence_graph/pig.py global Quellwert
python3 scripts/project_intelligence_graph/pig.py local "Project - Quellwert" --depth 2
python3 scripts/project_intelligence_graph/pig.py hybrid "QualityDecision public_ready" --depth 2
python3 scripts/project_intelligence_graph/pig.py explain "Project Intelligence Graph"
python3 scripts/project_intelligence_graph/pig.py context-pack "QualityDecision public_ready"
python3 scripts/project_intelligence_graph/pig.py risk
python3 scripts/project_intelligence_graph/pig.py decisions
python3 scripts/project_intelligence_graph/pig.py coverage
python3 scripts/project_intelligence_graph/pig.py policy
python3 scripts/project_intelligence_graph/pig.py decisions --set review-operator-go-midday-publisher --state accepted --note "Operator scope confirmed"
python3 scripts/project_intelligence_graph/pig.py render-views
python3 scripts/project_intelligence_graph/pig.py selftest
python3 scripts/project_intelligence_graph/pig.py full-check
python3 scripts/project_intelligence_graph/pig.py source-registry
python3 scripts/project_intelligence_graph/pig.py contradictions
python3 scripts/project_intelligence_graph/pig.py research-bundle-v2
python3 scripts/project_intelligence_graph/pig.py portable-evidence
python3 scripts/project_intelligence_graph/pig.py deep-research-ingest
python3 scripts/project_intelligence_graph/pig.py vivi-worker-v3
python3 scripts/project_intelligence_graph/pig.py decision-cockpit
python3 scripts/project_intelligence_graph/pig.py product-rail-matrix
python3 scripts/project_intelligence_graph/pig.py room16-qualitydecision
python3 scripts/project_intelligence_graph/pig.py kanzlei-synthetic-factory
python3 scripts/project_intelligence_graph/pig.py quellwert-data-maturity
python3 scripts/project_intelligence_graph/pig.py license-dependency-governance
python3 scripts/project_intelligence_graph/pig.py release-train-activation
python3 scripts/project_intelligence_graph/pig.py operator-brief
python3 scripts/project_intelligence_graph/pig.py long-run-audit
python3 scripts/project_intelligence_graph/pig.py vault-hygiene
python3 scripts/project_intelligence_graph/vault_umlaut_safe_autofix.py --write
python3 scripts/project_intelligence_graph/pig.py skill-policy-audit
python3 scripts/project_intelligence_graph/pig.py rule-propagation
python3 scripts/project_intelligence_graph/pig.py project-invariants
python3 scripts/project_intelligence_graph/pig.py agent-entrypoints
python3 scripts/project_intelligence_graph/pig.py operator-intent
python3 scripts/project_intelligence_graph/pig.py operator-intent --signal "Dauerloop Autonomie analysieren bauen fixen"
python3 scripts/project_intelligence_graph/pig.py operator-intent --intent-id "contract-id" --set-status completed_verified --note "verified by quality-gate and full-check"
python3 scripts/project_intelligence_graph/pig.py impact-radius --text "mehr Struktur und projektuebergreifende Verbesserungen"
python3 scripts/project_intelligence_graph/pig.py german-output-quality
python3 scripts/project_intelligence_graph/pig.py autonomy-governor
python3 scripts/project_intelligence_graph/pig.py autonomy-queue
python3 scripts/project_intelligence_graph/pig.py autonomy-queue --set-block intent-to-fix-contract --set-status completed_verified --note "verified"
python3 scripts/project_intelligence_graph/pig.py autonomy-dirt-scan
python3 scripts/project_intelligence_graph/pig.py autonomy-dirt-scan --run-verifiers
python3 scripts/project_intelligence_graph/pig.py vivi-handoff-inbox
python3 scripts/project_intelligence_graph/pig.py vivi-handoff-inbox --set-item ITEM_ID --state verified --note "why" --verifier "command"
python3 scripts/project_intelligence_graph/pig.py fresh-session-readiness
python3 scripts/project_intelligence_graph/pig.py fresh-data
python3 scripts/project_intelligence_graph/pig.py vivi-job-cards
python3 scripts/project_intelligence_graph/pig.py vivi-runner
python3 scripts/project_intelligence_graph/pig.py vivi-supervisor
python3 scripts/project_intelligence_graph/pig.py status-semantics
python3 scripts/project_intelligence_graph/pig.py status-semantics-fixtures
python3 scripts/project_intelligence_graph/pig.py north-star
python3 scripts/project_intelligence_graph/pig.py model-provider-truth
python3 scripts/project_intelligence_graph/pig.py roadmap-reconciliation-v2
python3 scripts/project_intelligence_graph/pig.py evidence-budget
python3 scripts/project_intelligence_graph/pig.py dirt-burndown
python3 scripts/project_intelligence_graph/pig.py operator-brief-v4
python3 scripts/project_intelligence_graph/pig.py operator-brief-v4-audit
python3 scripts/project_intelligence_graph/pig.py vivi-v3-2-cards
python3 scripts/project_intelligence_graph/pig.py vivi-v3-2-supervisor
python3 scripts/project_intelligence_graph/pig.py existing-rails-quality-slice
python3 scripts/project_intelligence_graph/pig.py code-pressure
python3 scripts/project_intelligence_graph/pig.py generated-evidence-dedup
python3 scripts/project_intelligence_graph/pig.py sanitized-b20-b26-capsule
python3 scripts/project_intelligence_graph/pig.py bundle-reference-lint
python3 scripts/project_intelligence_graph/pig.py archive-membership-audit
python3 scripts/project_intelligence_graph/pig.py evidence-budget-enforcer-test
python3 scripts/project_intelligence_graph/pig.py markdown-renderer-regression
python3 scripts/project_intelligence_graph/pig.py dirt-burndown-v2
python3 scripts/project_intelligence_graph/pig.py quarantine-restore-manifest
python3 scripts/project_intelligence_graph/pig.py commit-ready-batches
python3 scripts/project_intelligence_graph/separate_acceptance.py --profile capability-governance
python3 scripts/project_intelligence_graph/pig.py pig-pressure-relief-plan
python3 scripts/project_intelligence_graph/pig.py pig-helper-extraction
python3 scripts/project_intelligence_graph/pig.py vivi-v3-3-lifecycle
python3 scripts/project_intelligence_graph/pig.py vivi-v3-3-supervisor
python3 scripts/project_intelligence_graph/pig.py existing-rails-quality-delta-v2
python3 scripts/project_intelligence_graph/pig.py three-cycle-work-log
python3 scripts/project_intelligence_graph/pig.py final-verification-summary
python3 scripts/project_intelligence_graph/pig.py operator-brief-v5
python3 scripts/project_intelligence_graph/pig.py sanitized-b28-b35-capsule
python3 scripts/project_intelligence_graph/pig.py b28-b35-final-state
python3 scripts/project_intelligence_graph/pig.py north-star-expansion
python3 scripts/project_intelligence_graph/pig.py m15-north-star-roadmap-kernel
python3 scripts/project_intelligence_graph/pig.py m16-one-app-daily-cockpit
python3 scripts/project_intelligence_graph/pig.py m17-decision-execution
python3 scripts/project_intelligence_graph/pig.py m18-vivi-safe-work-loop
python3 scripts/project_intelligence_graph/pig.py m19-product-rail-north-star
python3 scripts/project_intelligence_graph/pig.py m20-evidence-pack-factory-v3
python3 scripts/project_intelligence_graph/pig.py m21-controlled-activation-dry-runs
python3 scripts/project_intelligence_graph/pig.py m22-north-star-acceptance
python3 scripts/project_intelligence_graph/pig.py north-star-final-verification
python3 scripts/project_intelligence_graph/pig.py north-star-final-state
python3 scripts/project_intelligence_graph/pig.py planning-quality
python3 scripts/project_intelligence_graph/pig.py new-fix "short title" --objective "one sentence objective"
python3 scripts/project_intelligence_graph/pig.py validate-fix
python3 scripts/project_intelligence_graph/pig.py quality-baseline --label before-fix
python3 scripts/project_intelligence_graph/pig.py quality-gate --baseline outputs/project_intelligence_graph/quality_baseline.json --improvement "what improved"
```

## Outputs

- `outputs/project_intelligence_graph/nodes.jsonl`
- `outputs/project_intelligence_graph/relationships.jsonl`
- `outputs/project_intelligence_graph/summary.json`
- `outputs/project_intelligence_graph/drift_report.md`
- `outputs/project_intelligence_graph/subgraph-lioncom-room16-quellwert.html`
- `outputs/project_intelligence_graph/views/index.html`
- `outputs/project_intelligence_graph/views/project-lane-claim-evidence.html`
- `outputs/project_intelligence_graph/views/automation-job-cards.html`
- `outputs/project_intelligence_graph/views/promotion-gate-map.html`
- `outputs/project_intelligence_graph/views/report-supersession-timeline.html`
- `outputs/project_intelligence_graph/views/repo-verifier-coverage.html`
- `outputs/project_intelligence_graph/views/automation-risk-registry.html`
- `outputs/project_intelligence_graph/views/operator-decision-inbox.html`
- `outputs/project_intelligence_graph/context_packs/*.md`
- `outputs/project_intelligence_graph/v1_verification_report.md`
- `outputs/project_intelligence_graph/automation_risk_registry.md/json`
- `outputs/project_intelligence_graph/long_run_completion_audit.md/json`
- `outputs/project_intelligence_graph/vault_umlaut_hygiene.md/json`
- `outputs/project_intelligence_graph/skill_policy_regression_guard_audit.md/json`
- `outputs/project_intelligence_graph/rule_propagation_audit.md/json`
- `outputs/project_intelligence_graph/project_invariant_audit.md/json`
- `outputs/project_intelligence_graph/agent_entrypoint_audit.md/json`
- `outputs/project_intelligence_graph/operator_intent_contract_audit.md/json`
- `outputs/project_intelligence_graph/impact_radius_assessment.md/json`
- `outputs/project_intelligence_graph/german_output_quality_gate.md/json`
- `outputs/project_intelligence_graph/autonomy_governor_audit.md/json`
- `outputs/project_intelligence_graph/autonomy_execution_queue.md/json`
- `outputs/project_intelligence_graph/autonomy_dirt_backlog_scan.md/json`
- `outputs/project_intelligence_graph/vivi_vega_handoff_inbox.md/json`
- `outputs/project_intelligence_graph/vivi_vega_handoff_state.json`
- `outputs/project_intelligence_graph/fresh_session_readiness_audit.md/json`
- `outputs/project_intelligence_graph/fresh_data_intake.md/json`
- `outputs/project_intelligence_graph/vivi_job_card_queue.md/json`
- `outputs/project_intelligence_graph/vivi_runner_last_run.md/json`
- `outputs/project_intelligence_graph/vivi_supervisor_audit.md/json`
- `outputs/project_intelligence_graph/vivi_worker_queue.md/json`
- `outputs/project_intelligence_graph/vivi_worker_last_run.md/json`
- `outputs/project_intelligence_graph/vivi_worker_supervisor_audit.md/json`
- `outputs/project_intelligence_graph/status_semantics_matrix.md/json`
- `outputs/project_intelligence_graph/status_semantics_fixture_report.md/json`
- `outputs/project_intelligence_graph/project_north_star.md/json`
- `outputs/project_intelligence_graph/roadmap_state.md/json`
- `outputs/project_intelligence_graph/north_star_decision_kernel.md/json`
- `outputs/project_intelligence_graph/portable_evidence_capsule.md/json`
- `outputs/project_intelligence_graph/portable_evidence_capsule_audit.md/json`
- `outputs/project_intelligence_graph/deep_research_ingestion.md/json`
- `outputs/project_intelligence_graph/deep_research_ingestion_audit.md/json`
- `outputs/project_intelligence_graph/vivi_worker_v3_claim_plan.md/json`
- `outputs/project_intelligence_graph/vivi_worker_v3_supervisor_audit.md/json`
- `outputs/project_intelligence_graph/lioncom_decision_cockpit.md/json`
- `outputs/project_intelligence_graph/lioncom_decision_cockpit_audit.md/json`
- `outputs/project_intelligence_graph/product_rail_matrix.md/json`
- `outputs/project_intelligence_graph/product_rail_matrix_audit.md/json`
- `outputs/project_intelligence_graph/room16_quality_decision_integration.md/json`
- `outputs/project_intelligence_graph/room16_quality_decision_integration_audit.md/json`
- `outputs/project_intelligence_graph/kanzlei_synthetic_factory.md/json`
- `outputs/project_intelligence_graph/kanzlei_synthetic_factory_audit.md/json`
- `outputs/project_intelligence_graph/quellwert_data_maturity.md/json`
- `outputs/project_intelligence_graph/quellwert_data_maturity_audit.md/json`
- `outputs/project_intelligence_graph/license_dependency_governance.md/json`
- `outputs/project_intelligence_graph/license_dependency_governance_audit.md/json`
- `outputs/project_intelligence_graph/release_train_activation_readiness.md/json`
- `outputs/project_intelligence_graph/release_train_activation_audit.md/json`
- `outputs/project_intelligence_graph/maturity_state.md/json`
- `outputs/project_intelligence_graph/repo_hygiene_reconciliation.md/json`
- `outputs/project_intelligence_graph/sanitized_evidence_capsule_v3.md/json`
- `outputs/project_intelligence_graph/vivi_maturity_cards.md/json`
- `outputs/project_intelligence_graph/existing_rails_perfection.md/json`
- `outputs/project_intelligence_graph/roadmap_reconciliation_v2.md/json`
- `outputs/project_intelligence_graph/stale_next_step_guard.md/json`
- `outputs/project_intelligence_graph/foreign_scope_status_split.md/json`
- `outputs/project_intelligence_graph/evidence_budget_report.md/json`
- `outputs/project_intelligence_graph/sanitized_review_bundle_v4.md/json`
- `outputs/project_intelligence_graph/bundle_profile_manifest.md/json`
- `outputs/project_intelligence_graph/dirt_burndown_manifest.md/json`
- `outputs/project_intelligence_graph/stale_generated_artifacts_manifest.md/json`
- `outputs/project_intelligence_graph/commit_hygiene_freshness_report.md/json`
- `outputs/project_intelligence_graph/operator_brief_v4.md/json`
- `outputs/project_intelligence_graph/operator_brief_v4_audit.md/json`
- `outputs/project_intelligence_graph/vivi_v3_2_cards.md/json`
- `outputs/project_intelligence_graph/vivi_v3_2_supervisor_audit.md/json`
- `outputs/project_intelligence_graph/vivi_duplicate_delta_guard.md/json`
- `outputs/project_intelligence_graph/existing_rails_quality_slice_audit.md/json`
- `outputs/project_intelligence_graph/code_pressure_report.md/json`
- `outputs/project_intelligence_graph/generated_evidence_dedup_report.md/json`
- `outputs/project_intelligence_graph/pig_module_extraction_map.md`
- `outputs/project_intelligence_graph/sanitized_b20_b26_capsule.md/json`
- `outputs/project_intelligence_graph/bundle_reference_lint.md/json`
- `outputs/project_intelligence_graph/archive_membership_audit.md/json`
- `outputs/project_intelligence_graph/evidence_budget_enforcer_test_report.md/json`
- `outputs/project_intelligence_graph/markdown_renderer_regression_report.md/json`
- `outputs/project_intelligence_graph/dirt_burndown_v2.md/json`
- `outputs/project_intelligence_graph/quarantine_restore_manifest.md/json`
- `outputs/project_intelligence_graph/commit_ready_batches.md/json`
- `outputs/project_intelligence_graph/pig_pressure_relief_plan.md/json`
- `outputs/project_intelligence_graph/pig_helper_extraction_report.md/json`
- `outputs/project_intelligence_graph/vivi_v3_3_claim_lifecycle_demo.md/json`
- `outputs/project_intelligence_graph/vivi_v3_3_supervisor_audit.md/json`
- `outputs/project_intelligence_graph/existing_rails_quality_delta_v2.md/json`
- `outputs/project_intelligence_graph/three_cycle_work_log.md/json`
- `outputs/project_intelligence_graph/final_verification_summary.md/json`
- `outputs/project_intelligence_graph/operator_brief_v5.md/json`
- `outputs/project_intelligence_graph/sanitized_b28_b35_capsule.md/json`
- `outputs/project_intelligence_graph/b28_b35_final_state.md/json`
- `outputs/project_intelligence_graph/model_provider_truth.md/json`
- `outputs/project_intelligence_graph/operator_decision_inbox.md/json`
- `outputs/project_intelligence_graph/coverage_manifest.md/json`
- `outputs/project_intelligence_graph/policy_gate_report.md/json`
- `outputs/project_intelligence_graph/contract_quality_gate.md/json`
- `outputs/project_intelligence_graph/operator_decision_state.json`
- `outputs/project_intelligence_graph/full_check_report.md/json`
- `outputs/project_intelligence_graph/operator_brief.md/json`
- `outputs/project_intelligence_graph/hardening_fix_contracts/*.md/json`
- `outputs/project_intelligence_graph/hardening_fix_contract_validation.md/json`
- `outputs/project_intelligence_graph/quality_baseline.md/json`
- `outputs/project_intelligence_graph/quality_gate_report.md/json`
- `outputs/project_intelligence_graph/quality_snapshots/*.json`

## PASS-Semantik

Ab v2 ist `PASS` nicht mehr eine einzige Behauptung.

- `implementation_status`: Generator, Schema, JSONL und Grundartefakte sind valide.
- `coverage_status`: zeigt, ob wichtige Source-Klassen noch fehlen oder nur teilweise gescannt sind.
- `operator_risk_status`: zeigt, ob aktive Hochrisiko-Automationen oder mutierende Surfaces sichtbar sind.
- `policy_gate_status`: zeigt, ob dokumentierte Regeln noch nicht in harte Policy-/Gate-Mechanik übersetzt sind.
- `contract_quality_status`: zeigt auch Complete-Context-WARNs für kanonische System-/Regelnoten, wenn ein Anker ohne Synonyme, Grenzen, Evidence oder nächsten Schritt nicht gut genug für spätere Sessions ist.
- `rule_propagation_status`: zeigt, ob systemweite Regeln an alle erwarteten Entry-Points, Skills, Policies und Rails verteilt sind.
- `project_invariant_status`: zeigt, ob betroffene Projekte ihre Operator-Intent-, Gate-, Verifier- und Surface-Invarianten tragen.
- `status_semantics_matrix_status`: zeigt getrennt, ob lokale Verifier erfolgreich waren, ob Outputs publishbar wären, ob Operator-Gates offen sind und ob externe Validierung vorliegt. Ein lokales `PASS` darf dadurch nicht als Public-/Produktionsreife gelesen werden.
- `status_semantics_fixture_status`: zeigt, ob die B01-Regression-Fixture beweist, dass stale Room16-FAIL plus aktueller Projekt-PASS als Warn-Konflikt, nicht als Produktfehler, behandelt wird.
- `operator_intent_contract_status`: zeigt, ob breite Operator-Signale in eine feste Zielbild-/Verifier-/Propagation-Struktur übersetzt werden können.
- `german_output_quality_status`: zeigt, ob deutsche operator-facing Outputs echte Umlaute nutzen, keine sichtbaren Reasoning-/KI-/Placeholder-/Render-Leaks tragen und Humanizer nur als Lint/Review ohne Faktenumschreibung verwendet wird.
- `autonomy_governor_status`: zeigt, ob Autonomie-Workstreams strukturierte Zielbilder, nächste sichere Schritte, Gates, Verifier, Evidence und Memory-Ziele tragen.
- `endgame_roadmap_status`: zeigt Foundation-Completion, Makro-Completion, sichere nächste große Blöcke, Operator-Gates und den Makro-Backlog. Ein grünes Quality-OS-Fundament darf nicht als fertige zweiwöchige Produkt-Roadmap gelesen werden.
- `project_vertical_rollout_status`: trennt Projektwirkung von lokaler Rail-Completion. `rail_contract_status=PASS` bedeutet, dass Verifier, Claim-Surface, Evidence und Gates je Projekt vollständig sind; `project_effect_status=WARN` kann trotzdem korrekt sein, wenn Public, echte Daten oder Datenreife noch gated sind.
- `launch_readiness_status`: trennt lokale Launch-/Revenue-Preflight-Bereitschaft von echter Wirkung. `launch_contract_status=PASS` und `local_preflight_completion_percent=100` öffnen niemals Public, Production, Geld, Auth/Credentials, Provider oder externe Kommunikation.
- `autonomy_dirt_backlog_scan_status`: zeigt, ob relevante lokale Arbeitsbäume, Verifier-Pläne und Gates sichtbar klassifiziert sind. Dirty Trees sind WARN, nicht FAIL; sie müssen vor Commit/Cleanup eingeordnet werden.
- `vivi_vega_handoff_inbox_status`: zeigt, ob Vivi-/Codex-Handoff-Spuren gelesen und als `needs_vega_review`, `needs_operator_gate`, `needs_verifier`, `candidate_only` oder `recorded_history` eingeordnet wurden.
- `fresh_session_readiness_status`: zeigt, ob führende Startnoten ausreichen, damit eine frische Agenten-Session ohne alte Chat-Erinnerung sauber starten kann.
- `fresh_data_intake_status`: zeigt, ob neue lokale Projekt-/Runtime-Daten erkannt wurden und ob daraus nur Evidence, Review-Bedarf, Verifier-Bedarf oder Operator-Gates entstehen.
- `vivi_job_card_queue_status`: zeigt, ob Fresh-Data-Action-Items in sichere Vivi Job Cards übersetzt wurden.
- `vivi_runner_status`: zeigt, ob der lokale read-only Runner eine ready Job Card validiert, gestoppt oder als fehlende Evidence markiert hat. `runtime_action_executed` muss immer `false` bleiben.
- `vivi_supervisor_status`: zeigt, ob Vega/PIG die Runner-Ausgabe als lokale Wahrheit akzeptieren kann oder ob sie wegen übersprungener Projekt-Verifier, fehlender Execution History, Operator-Gates oder Runtime-Mutation nur Kandidat, Review-Item oder FAIL ist.
- `vivi_worker_queue_status`: zeigt, ob Commit-/Cleanup-/Operator-Go-Evidence oder sichere Projekt-Verifier-Claims als Worker-Karten bereitstehen.
- `vivi_worker_status`: zeigt, ob der lokale Artefakt-Worker generierte PIG-Evidence aktualisiert oder der Safe Project Worker v2 einen allowlisteten Projekt-Verifier ausgeführt hat. `runtime_action_executed` muss immer `false` bleiben.
- `vivi_worker_supervisor_status`: zeigt, ob Vega/PIG die Worker-Ausgabe als lokale Evidence akzeptieren kann oder ob Runtime-Mutation, fehlende Execution History, fehlender Projektvertrag oder Gate-Bruch vorliegt.
- `model_provider_truth_status`: zeigt, ob aktuelle Modell-/Provider-Truth-Claims scope-gebunden und prüfbar sind. Kimi K2.6 kann gleichzeitig aktive LIONCOM-Vivi-Route, historische Room16-Report-Evidence und nicht aktive Room16-Neulaufoption sein; `ollama/*:cloud` ist Cloud-Offload, nicht lokales Gewicht auf dem Mac. Eine Anweisung wie `lass Vivi auf XY laufen` gilt nur für Vivi-Sessions/-Worker und verändert nicht Room16 oder andere App-/Session-Modellpicker; Room16 bleibt aktuell manuell auf DeepSeek 4 Pro / DS V4 Cloud, bis Björn Room16 separat ändert.
- `north_star_decision_kernel_status`: zeigt, ob ein aktiver B00-Zielkontrakt existiert. Ein `PASS` bedeutet nur, dass neue lokale Arbeit mit Block-ID, Claim-Type, Source-IDs, erwartetem Verifier, Rollback-Notiz und Gate-Assessment starten muss; es öffnet keine Push-, Publish-, Deploy-, Payment-, Auth-, Real-Data-, Room16-Rerun- oder Public-Gates.
- `portable_evidence_capsule_status`: zeigt, ob B05 lokale PASS-Claims als kleine portable Evidence-Capsule mit Source-IDs, relativen Pfaden, Hashes, Verifiern und geschlossenen Gates belegen kann. Ein `PASS` bedeutet interne Nachweisfähigkeit, nicht externe Weitergabe oder Audit-Freigabe.
- `deep_research_ingestion_status`: zeigt, ob B06 Research-Befunde in lokale Claim-Routen mit Quellen, Zielblöcken, Memory-Routing, Verifiern und geschlossenen Gates übersetzt hat. Ein `PASS` bedeutet priorisierte interne Weiterarbeit, nicht dass ein Deep-Research-Befund selbst endgültige Wahrheit oder externe Freigabe ist.
- `vivi_worker_v3_status`: zeigt, ob B07 Vivi als sicheren lokalen Claim-Plan mit erlaubten Claim-Typen, Source-/Verifier-Pflicht, Status-Semantik-Split und Supervisor-Audit materialisiert hat. Ein `PASS` bedeutet geplante lokale Worker-Fähigkeit, nicht Runtime-Autonomie, Modellpicker-Änderung, Room16-Rerun oder externe Wirkung.
- `lioncom_decision_cockpit_status`: zeigt, ob B08 die lokale Operator-Entscheidungsfläche in PIG und LIONCOM read-only belegen kann. Ein `PASS` bedeutet sichtbare Entscheidungskarten und geschlossene Runtime-/External-/Irreversible-Gates, nicht dass LIONCOM selbst Aktionen auslösen darf.
- `product_rail_matrix_status`: zeigt, ob B09 die Produkt-Rails mit getrennten Reifeachsen und Gate-Ledger anzeigen kann. Ein `PASS` bedeutet lokale Produktreife-Transparenz, nicht Public-, Production-, Payment-, Auth-, externe Validierungs- oder Operator-Go-Freigabe.
- `room16_qualitydecision_status`: zeigt, ob B10 Room16 QualityDecision-, Review-, Manual-Packet-, Publish-Readiness- und German-Output-Evidence konsistent integriert. Ein `PASS` bedeutet Lifecycle-Evidence, nicht Room16-Publish, Public, Member-Zugang, Rerun oder Financial-Advice-Freigabe.
- `kanzlei_synthetic_factory_status`: zeigt, ob B11 Kanzlei AI Assist synthetische Golden-Case-, Verify-All- und Product-Readiness-Evidence lokal zusammenführt. Ein `PASS` bedeutet synthetische lokale Nachweisfähigkeit, nicht echte Mandantendaten, DATEV, Cloud-/Provider-Verarbeitung, Auth/Credentials, Production, externe Kommunikation oder finale Steuerentscheidung.
- `quellwert_data_maturity_status`: zeigt, ob B12 Utility-Datenreife, Membership-Preview, Launch-Readiness, Product-Rail-Achsen und B11-Abhängigkeit lokal konsistent zusammenführt. Ein `PASS` bedeutet lokale Entscheidungs- und Evidence-Reife mit geschlossenen Gates, nicht reife Datenlage, Public/Production, externe Analytics, Payment/Auth, Monetarisierung oder Financial-Advice-Publishing.
- `license_dependency_governance_status`: zeigt, ob B13 Third-Party-/Dependency-Kandidaten und Bundle-Inclusion-Regeln lokal inventarisiert. Ein `PASS` bedeutet Kandidaten-Review-Queue und keine Runtime-/External-/Publish-Aktion; es bedeutet kein Lizenzurteil, keine Redistribution-Clearance und keine externe Freigabe.
- `release_train_activation_status`: zeigt, ob B14 lokale Release-Trains, Aktivierungsblocker, Verifier, Handoffs und Operator-Gates vollständig als Evidence sichtbar macht. Ein `PASS` bedeutet keine Aktivierung: Public, Production, Deploy, Publish, Payment/Geld, Auth/Credentials, externe Kommunikation, echte Daten, Room16-Rerun, Redistribution/Legal-Clearance und irreversible Aktionen bleiben eigene Operator-Gates.
- `maturity_state_status`: zeigt, ob B15 PASS/WARN/GATE/External sauber trennt. Ein `PASS` bedeutet korrigierte Status-Wahrheit, nicht Launch-Reife.
- `repo_hygiene_status`: zeigt, ob B16 alle Dirty-Slices klassifiziert. Ein `PASS` bedeutet clean-or-intentionally-dirty, nicht Commit, Push, Delete oder Cleanup.
- `sanitized_evidence_capsule_status`: zeigt, ob B17 ein minimales, path-cleanes Evidence-Profil erzeugt. Ein `PASS` bedeutet interne Prüfkapselfähigkeit, nicht externe Weitergabe.
- `vivi_maturity_cards_status`: zeigt, ob B18 Vivi-Karten echte Evidenzdeltas und Duplicate-No-Delta-Schutz tragen. Ein `PASS` bedeutet lokale Mission-Reife, nicht unbounded Worker-Autonomie.
- `existing_rails_perfection_status`: zeigt, ob B19 je Rail einen sicheren Hebel und eine No-Go-Zeile definiert. Ein `PASS` bedeutet keine Scope-Ausweitung und keine Gate-Öffnung.
- `roadmap_reconciliation_v2_status`: zeigt, ob B20 historische Next-Steps, aktuelle Mission, Fremdscope und Gate-Kontext ohne Stale-Drift zusammenführt. Ein `PASS` bedeutet aktuelle Operator-Navigation, nicht neue Produktfreigabe.
- `evidence_budget_status`: zeigt, ob B21 Review-Profile und Bundle-Budgets getrennt bleiben. Ein `PASS` für `minimal_shareable` bedeutet pfadarme Evidence, nicht automatische externe Weitergabe.
- `dirt_burndown_status`: zeigt, ob B22 Dirty-/Generated-/Gated-Artefakte klassifiziert und timeboxed sind. Ein `PASS` bedeutet keine unbekannte Dirt-Lage, nicht Delete, Commit, Push oder Cleanup.
- `operator_brief_v4_status`: zeigt, ob B23 eine kompakte, aktuelle Operatorfläche ohne alte Next-Step-Drift erzeugt. Ein `PASS` bedeutet bessere Navigation, nicht Gate-Öffnung.
- `vivi_v3_2_status`: zeigt, ob B24 kleine lokale Vivi-Karten mit genau einem Evidence-Delta und Verifier tragen. Ein `PASS` bedeutet Präzision, nicht zusätzliche Runtime-Autonomie.
- `existing_rails_quality_slice_status`: zeigt, ob B25 je Rail ein lokales Qualitätsartefakt und eine No-Go-Linie ergänzt. Ein `PASS` bedeutet lokale Härtung ohne Room16-Rerun, echte Daten oder externe Wirkung.
- `code_pressure_status`: zeigt, ob B26 Monolith-/Evidence-Druck sichtbar macht. Ein `PASS` bedeutet Planungsbefund und kleine Helper-Kandidaten, nicht Freigabe für riskante Großrefactors.
- `sanitized_b20_b26_capsule_status`: zeigt, ob B27 eine minimale, hashbasierte Abschlusskapsel über B20-B26 erzeugt. Ein `PASS` bedeutet interne Prüfkapselfähigkeit, nicht Weitergabe ohne Operator-Go.
- `bundle_reference_lint_status`: zeigt, ob B28 referenzierte Quellen, Hashes und Archivmitgliedschaft konsistent sind. Ein `PASS` bedeutet keine fehlenden Bundle-Quellen, nicht dass jedes lokale Artefakt shareable ist.
- `evidence_budget_enforcer_status`: zeigt, ob B29 das Evidence-Budget gegen das aktuelle Minimalprofil prüft. Ein `PASS` bedeutet Budgetdisziplin, nicht externe Freigabe.
- `markdown_renderer_regression_status`: zeigt, ob B30 Operator-Reports keine leeren `item`-Bullets aus Dict-Listen rendern. Ein `PASS` bedeutet lesbare Report-Form, nicht inhaltliche Freigabe der enthaltenen Claims.
- `dirt_burndown_v2_status`: zeigt, ob B31 Residual-Dirt, Commit-ready-Batches und Restore-Regeln gated sind. Ein `PASS` bedeutet reversible Hygiene-Planung, nicht Mutation.
- `pig_helper_extraction_status`: zeigt, ob B32 eine kleine, getestete Helper-Extraktion ohne riskanten Orchestrierungs-Split vorgenommen hat. Ein `PASS` bedeutet fokussierte Druckentlastung, nicht vollständige Monolith-Lösung.
- `vivi_v3_3_status`: zeigt, ob B33 genau einen lokalen Vivi-Claim durch Lifecycle und Supervisor bekommt. Ein `PASS` bedeutet `completed_verified_local` für diese Karte, nicht unbounded Worker-Ausführung.
- `existing_rails_quality_delta_v2_status`: zeigt, ob B34 je Rail einen Qualitätsdelta ohne Scope-Ausweitung belegt. Ein `PASS` öffnet keine Public-, Production-, Payment-, Auth-, Room16- oder Real-Data-Gates.
- `b28_b35_final_state_status`: zeigt, ob B35 Worklog, Verifier, Operator Brief v5 und Minimal-Capsule konsistent sind. Ein `PASS` bedeutet `maturity_kernel_v3_verified_reduced_self_consistent_operator_gated`, nicht Launch-, Publish- oder externe Audit-Freigabe.

Ein guter Lauf darf also `implementation_status=PASS` und gleichzeitig `coverage_status=WARN` melden. Das ist gewollt: Es verhindert falsches Grün.

## Operator Decision Lifecycle

`operator_decision_inbox.*` ist ein generierter Befund. Dauerhafte Operator-Entscheidungen leben separat in `operator_decision_state.json`, damit Scanner-Befund und menschliche Freigabe nicht vermischt werden.

Erlaubte States:

- `open`: noch nicht entschieden
- `accepted`: bewusst akzeptiert; zählt nicht mehr als offen
- `snoozed`: später erneut prüfen
- `delegated`: an eine andere Lane oder Person übergeben
- `closed`: erledigt oder nicht mehr relevant

Beispiel:

```bash
python3 scripts/project_intelligence_graph/pig.py decisions --set close-pig-coverage-gaps --state delegated --note "Repo/CI scanner is next implementation lane"
python3 scripts/project_intelligence_graph/pig.py full-check
```

## Robuster Hardening-Ablauf

Für jede künftige Härtung oder Reparatur:

1. `python3 scripts/project_intelligence_graph/pig.py operator-brief`
2. `python3 scripts/project_intelligence_graph/pig.py new-fix "short title" --objective "one sentence objective"`
3. `python3 scripts/project_intelligence_graph/pig.py quality-baseline --label before-fix`
4. Nur im erlaubten Scope ändern.
5. Generierte Reports nur über Scanner/CLI regenerieren.
6. `python3 scripts/project_intelligence_graph/pig.py validate-fix`
7. `python3 scripts/project_intelligence_graph/pig.py quality-gate --baseline outputs/project_intelligence_graph/quality_baseline.json --improvement "what improved"`
8. `python3 scripts/project_intelligence_graph/pig.py full-check`

Details: `docs/project-intelligence-graph/ROBUST_HARDENING_WORKFLOW.md`.

## Quality Control Gate

Das Quality Gate blockiert Änderungen, wenn sie neue Probleme einführen:

- `full_check_status` muss `PASS` bleiben.
- `implementation_status` muss `PASS` bleiben.
- Selftest-Checks dürfen nicht fehlschlagen oder weniger werden.
- aktive R4/R5-Automationen dürfen nicht zunehmen.
- offene P0-Entscheidungen dürfen nicht zunehmen.
- Coverage-Gaps und Policy-Items dürfen nicht zunehmen, außer dies wird explizit als bekannte Warnung erlaubt.
- Der Fix braucht messbare oder deklarierte Improvement-Evidence.

## Systemwide Rule Propagation

Wenn eine neue dauerhafte Regel entsteht, darf sie nicht nur in einer Note oder einem Skill stehen. Sie muss in `docs/project-intelligence-graph/RULE_PROPAGATION_REGISTRY.json` mit diesen Teilen registriert werden:

- `rule_id` und Aliases
- führende Source-Anker
- betroffene Scopes
- erwartete Ziel-Dateien oder Rails
- passende Required Terms
- Verifier-Command
- Acceptance Rule

Danach prüfen:

```bash
python3 scripts/project_intelligence_graph/pig.py rule-propagation
python3 scripts/project_intelligence_graph/pig.py full-check
```

Projektübergreifende Verbesserungen müssen zusätzlich `docs/project-intelligence-graph/PROJECT_INVARIANT_REGISTRY.json` berücksichtigen. Breite Operator-Signale werden mit `OPERATOR_INTENT_CONTRACT_SCHEMA.json` bzw. dem Template unter `quality-operating-system/OPERATOR_INTENT_CONTRACT_TEMPLATE.md` in Zielbild, Nicht-Ziele, Gates, Verifier und nächsten sicheren Block übersetzt. Für echte Autonomie nicht nur das Template lesen, sondern einen lokalen Contract materialisieren:

```bash
python3 scripts/project_intelligence_graph/pig.py operator-intent --signal "Originales Operator-Signal"
```

Das schreibt `outputs/project_intelligence_graph/operator_intent_contracts/*.json/*.md` und `latest_operator_intent_contract.json/md`. Der Scanner prüft danach Schema, Template und materialisierte Contracts im `operator-intent` Audit.

Wenn ein Intent-Block verbraucht ist, Status nicht per Hand im JSON drehen, sondern:

```bash
python3 scripts/project_intelligence_graph/pig.py operator-intent --intent-id "contract-id" --set-status completed_verified --note "Verifier summary"
```

Der Befehl aktualisiert JSON, Markdown, `latest_operator_intent_contract.*` und schreibt eine `status_history`.

Wichtig: Intent-Lifecycle-Schreibvorgänge und neue `operator-intent --signal`-Materialisierungen müssen seriell laufen. `latest_operator_intent_contract.*` darf nicht durch parallele alte Statusupdates zurückspringen; der CLI-Statusbefehl prüft deshalb direkt vor dem Latest-Write erneut, ob der Contract noch der aktuelle Latest-Intent ist.

Der nächste konkrete Arbeitsblock wird aus dem neuesten Intent als lokale Queue materialisiert:

```bash
python3 scripts/project_intelligence_graph/pig.py autonomy-queue
```

Das schreibt `outputs/project_intelligence_graph/autonomy_execution_queue.json/md`. Der Autonomy Governor bevorzugt daraus `ready`/`in_progress` Queue-Blöcke vor dem rohen Intent, damit Dauerloop-Arbeit konkreter ist als „weiter planen“.

Queue-Blöcke werden über eine State-Datei weitergeschaltet:

```bash
python3 scripts/project_intelligence_graph/pig.py autonomy-queue --set-block intent-to-fix-contract --set-status completed_verified --note "Verifier summary"
```

Das schreibt `outputs/project_intelligence_graph/autonomy_execution_queue_state.json` und regeneriert die Queue. Danach sollte der Autonomy Governor den nächsten `ready`/`in_progress` Block melden oder ein echtes Gate zeigen.

Lokale Dirt-, Backlog-, Verifier- und Gate-Signale werden separat gescannt:

```bash
python3 scripts/project_intelligence_graph/pig.py autonomy-dirt-scan
python3 scripts/project_intelligence_graph/pig.py autonomy-dirt-scan --run-verifiers
```

Das schreibt `outputs/project_intelligence_graph/autonomy_dirt_backlog_scan.json/md`. Der Scan ist lokal und reversibel: Er klassifiziert Dirty Trees, listet sichere nächste Schritte und führt mit `--run-verifiers` die bekannte lokale Deterministik-Suite aus. Dirty-Einträge bekommen zusätzlich `ownership_counts`, `classified_sample` und `handoff_cards`, damit Source Changes, Verifier/Tests, Operator-Dokumente, generierte Artefakte, gated Runtime-/Source-Artefakte und unbekannte Einträge vor Commit/Cleanup getrennt betrachtet werden. Der Output nennt zusätzlich, wie viele Verifier ausgeführt, bestanden, fehlgeschlagen oder noch geplant sind. Public, Production, Auth/Credentials, Geld, externe Kommunikation, Löschung, echte Personen-/Mandantendaten, Financial-Advice-Publishing und Room16-Rerun/Push/Publish bleiben Operator-Gates.

Der Operator Brief liest diesen Scan mit. Bei Dirty Worktrees wird `overall_status=REVIEW`, nicht weil der Build kaputt ist, sondern weil Cleanup/Commit/Handoff erst nach Ownership-Sichtung sicher ist.

## Autonomy Governor

Der Autonomy Governor verhindert, dass Langläufe, Nightruns oder breite Projektaufträge nach einem grünen Teilcheck als fertig gemeldet werden, obwohl noch sichere lokale Arbeit existiert.

Führende Dateien:

- `docs/project-intelligence-graph/AUTONOMY_GOVERNOR_SCHEMA.json`
- `docs/project-intelligence-graph/AUTONOMY_GOVERNOR_REGISTRY.json`
- `outputs/project_intelligence_graph/autonomy_governor_audit.md/json`

Statuslogik:

- `ready` / `in_progress`: weiterarbeiten; Autonomie ist nicht fertig.
- `blocked_operator_gate`: stoppen und Gate benennen.
- `monitoring` / `parked`: sichtbar halten, aber nicht als aktive Arbeit claimen.
- `completed_verified`: nur mit Verifier-, Memory- und Handoff-Evidence.

## Fresh Session Readiness

Der Fresh Session Readiness Audit macht sichtbar, ob wichtige Startpunkte genug Kontext tragen, bevor sie als dauerhafte Wahrheit oder Handoff gelten.

Führende Dateien:

- `docs/project-intelligence-graph/FRESH_SESSION_READINESS_SCHEMA.json`
- `outputs/project_intelligence_graph/fresh_session_readiness_audit.md/json`

Pflichtsignale:

- Zweck oder Kurzbild
- Status
- Aliases, Synonyme oder Suchbegriffe
- Grenzen oder Operator-Gates
- Evidence, Verifier oder Check-Befehl
- lokaler Pfad, Wikilink oder Cross-Link
- nächster sicherer Schritt

## Agenten-Portabilität

Die PIG-Kernlogik ist agentenagnostisch: Python-CLI, JSON/JSONL, Markdown und HTML. Codex-Skills sind nur die Codex-spezifische Bedienhülle. Claude Code, Vivi oder andere Coding-Agenten können dieselben Befehle und Artefakte nutzen, solange sie lokalen Dateizugriff und Python haben. Für andere Agenten sollte die Skill-Logik als normales Runbook oder Provider-spezifische Agent-Instructions gespiegelt werden.

## Abschlusskriterium

`--validate` muss `PASS` melden. Ein valider Lauf hat:

- gültiges JSON-Schema
- nicht-leere Output-Artefakte
- eindeutige Relationship-IDs
- vollständige Provenance- und Temporal-Felder
- keine unresolved Focus-Links
- HTML-Subgraph mit eingebettetem Graphdatensatz
- Local, Global und Hybrid Search liefern Treffer
- Explain liefert ein- oder ausgehende Beziehungen
- Context-Pack wird geschrieben
- alle HTML-Views werden geschrieben
- `pig.py selftest` meldet `PASS`
- Risk/Decision/Coverage/Policy Outputs existieren und sind parsebar
- `NODE_SCHEMA.json`, `PREDICATE_REGISTRY.json` und `POLICY_RULES.json` sind vorhanden
- `pig.py full-check` meldet `PASS` und schreibt `full_check_report.md/json`
- `pig.py operator-brief` schreibt eine einfache Operator-Sicht
- `pig.py validate-fix` validiert Hardening-Fix-Verträge
- `pig.py quality-gate` meldet `PASS`, bevor ein Fix als Verbesserung gilt
- `pig.py planning-quality` zeigt Roadmap-/Contract-/Archetype-/Job-Card-/Execution-History-Gates
