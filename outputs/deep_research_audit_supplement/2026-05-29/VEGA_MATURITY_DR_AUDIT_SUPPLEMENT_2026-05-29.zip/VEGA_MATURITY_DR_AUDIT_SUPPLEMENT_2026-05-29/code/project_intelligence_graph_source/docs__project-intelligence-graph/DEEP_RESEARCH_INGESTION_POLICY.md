# Deep Research Ingestion Policy

Status: `active_local`

## Zweck

B06 nimmt Deep-Research-Befunde nicht als Wahrheit, sondern als lokale, überprüfbare Routing-Claims auf. Jeder Befund braucht Quelle, Zielblock, erlaubte lokale Aktion, geschlossene Gates, Verifier und Memory-Route.

## Harte Grenzen

- Kein Publish, Public, Production, Deploy, Push oder Delete.
- Keine Auth-, Credential-, Payment- oder Provider-Aktion.
- Keine externe Kommunikation.
- Keine echten Personen-, Mandanten-, Steuer- oder regulierten Finanzdaten.
- Kein Room16-Rerun und kein Financial-Advice-Publishing.
- Keine Rohdaten-Reinklusion ohne eigenen Operator-Go- und Redaktionsvertrag.

## Akzeptanz

Ein B06-Lauf ist nur gültig, wenn:

- mindestens acht Research-Befunde als Claims geroutet sind,
- jede Claim-Route gültige `source_ids`, `target_block`, `memory_routes` und einen Verifier hat,
- B02 Source Registry, B03 Contradiction Engine und B05 Portable Evidence Capsule `PASS` sind,
- alle harten Gates sichtbar geschlossen bleiben,
- `runtime_action_executed=false`, `external_action_executed=false`, `raw_data_ingested=false`.

## Output

Führende Artefakte:

- `outputs/project_intelligence_graph/deep_research_ingestion.json`
- `outputs/project_intelligence_graph/deep_research_ingestion.md`
- `outputs/project_intelligence_graph/deep_research_ingestion_audit.json`
- `outputs/project_intelligence_graph/deep_research_ingestion_audit.md`

Verifier:

```bash
python3 scripts/project_intelligence_graph/pig.py deep-research-ingest --json
```
