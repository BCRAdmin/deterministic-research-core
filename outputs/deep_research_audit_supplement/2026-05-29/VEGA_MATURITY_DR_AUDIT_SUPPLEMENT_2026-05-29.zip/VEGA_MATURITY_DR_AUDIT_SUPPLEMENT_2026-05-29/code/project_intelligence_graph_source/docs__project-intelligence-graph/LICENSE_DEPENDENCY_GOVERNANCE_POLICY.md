# License Dependency Governance Policy

B13 ist eine lokale Governance- und Kandidateninventur. Sie ist keine Rechtsberatung, keine Lizenzfreigabe und keine Erlaubnis zur Weitergabe.

## Harte Grenzen

- Keine externe Kommunikation.
- Keine externe Veröffentlichung oder Weitergabe.
- Kein Public-, Production-, Deploy-, Payment- oder Auth-Schritt.
- Kein Rechtsurteil über Lizenzen.
- Kein Schluss, dass Redistribution erlaubt ist.
- Keine Nutzung echter Personen- oder Mandantendaten.

## Akzeptierte lokale Arbeit

- Bestehende Provenance-Kandidaten aus Deep-Research-Bundles lesen.
- Lokale Dependency-Manifeste inventarisieren.
- Kandidaten nach Quelle, Typ, Schicht und Review-State gruppieren.
- Bundle-Inclusion-Regeln als interne Review-Regeln formulieren.
- Alle unklaren Drittquellen als `review_required` und `not_cleared` markieren.

## Status-Semantik

`PASS` bedeutet: Die Kandidateninventur, Dependency-Manifeste und Bundle-Regeln sind lokal sichtbar, prüfbar und gate-konform. `PASS` bedeutet nicht: Lizenz geprüft, Rechtslage geklärt, externe Nutzung erlaubt oder Veröffentlichung freigegeben.
