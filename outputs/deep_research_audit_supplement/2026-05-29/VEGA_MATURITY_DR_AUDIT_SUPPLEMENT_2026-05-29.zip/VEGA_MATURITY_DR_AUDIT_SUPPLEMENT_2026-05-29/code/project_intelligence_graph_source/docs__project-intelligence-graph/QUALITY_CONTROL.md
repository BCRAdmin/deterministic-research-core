# Project Intelligence Graph Quality Control

Quality Control beantwortet eine einfache Frage:

> Ist diese Änderung wirklich eine Verbesserung, oder hat sie nur ein Problem verschoben?

## Standardfolge

Vor der Änderung:

```bash
python3 scripts/project_intelligence_graph/pig.py quality-baseline --label before-fix
```

Nach der Änderung:

```bash
python3 scripts/project_intelligence_graph/pig.py quality-gate \
  --baseline outputs/project_intelligence_graph/quality_baseline.json \
  --improvement "short evidence of what improved"
```

Dann:

```bash
python3 scripts/project_intelligence_graph/pig.py full-check
```

## Harte Blocker

Das Gate blockiert, wenn:

- `full_check_status` nicht `PASS` ist
- `implementation_status` nicht `PASS` ist
- Selftests fehlschlagen
- Selftest-Anzahl sinkt
- aktive R4/R5-Automationen zunehmen
- offene P0-Entscheidungen zunehmen
- Coverage-Gaps zunehmen
- Policy-Items zunehmen
- keine Improvement-Evidence angegeben oder messbar ist
- eine Regression, neue Fehler oder neue Einschränkungen sichtbar werden

## Was als Verbesserung zählt

Akzeptiert wird:

- ein Status verbessert sich
- ein Risiko-/Gap-/P0-Zähler sinkt
- neue sinnvolle Prüfabdeckung wird hinzugefügt
- der Operator bekommt weniger rohe Komplexität
- eine klare Improvement-Evidence wird angegeben und das Regression-Gate bleibt grün

Wenn das Quality Gate oder ein projektspezifischer Verifier neue Fehler, neue Einschränkungen oder größere Risk-/Operator-Last zeigt, ist die Änderung keine akzeptierte Verbesserung. Dann erst neu analysieren und kleiner schneiden.

## Was nicht zählt

Nicht ausreichend:

- WARN umbenennen
- Reports manuell editieren
- rote Checks entfernen
- problematische Source-Klassen aus Coverage löschen
- neue Risiken als "bekannt" verstecken

## Output

- `outputs/project_intelligence_graph/quality_baseline.json`
- `outputs/project_intelligence_graph/quality_baseline_report.md`
- `outputs/project_intelligence_graph/quality_gate_report.json`
- `outputs/project_intelligence_graph/quality_gate_report.md`
- `outputs/project_intelligence_graph/quality_snapshots/*.json`
