# Shannon Security Sandbox Contract

Status: active

Canonical name: `Shannon Security Sandbox`

Aliases: `Shannon`, `Shanon`, `KeygraphHQ/shannon`

## Purpose

Shannon is a named security sandbox rail for authorized local exploit, PoC and security-learning work. It exists so every session can distinguish a risky sandbox from ordinary quality, design or agent work.

## Hard Gates

- Written scope exists before any execution.
- Only owned local test apps or explicit test targets are in scope.
- No live, customer or third-party systems.
- Credentials are synthetic, isolated or absent.
- Docker/worker execution stays inside sandbox boundaries and needs explicit operator go.
- AGPL-3.0 licensing is treated as a legal/adoption gate before code copying.
- Findings need human verification before being promoted.

## Allowed Actions

- Read repo docs and prior audit notes.
- Prepare a local sandbox plan.
- Check scope, data, network and credential boundaries.
- Run isolated local tests only after all hard gates pass.

## Forbidden Actions

- Live/customer/third-party scanning.
- Credential setup against real services.
- External network attack or exploitation.
- Docker worker start against external targets without operator go.
- Copying AGPL implementation code into proprietary runtime without a legal decision.
- Publishing exploit findings without human verification.

## Fresh Session Rule

When a user says `Shannon`, `Shanon` or `KeygraphHQ/shannon`, load only:

```text
VEGA_START_HERE -> Decision - Thin Roles Thick Rails -> capability_registry.json -> this contract
```

Then stop at scope verification until the hard gates are clear.

## Verifier

- `python3 scripts/project_intelligence_graph/pig.py capability-registry --json`
- `python3 scripts/project_intelligence_graph/pig.py shannon-sandbox --json`
