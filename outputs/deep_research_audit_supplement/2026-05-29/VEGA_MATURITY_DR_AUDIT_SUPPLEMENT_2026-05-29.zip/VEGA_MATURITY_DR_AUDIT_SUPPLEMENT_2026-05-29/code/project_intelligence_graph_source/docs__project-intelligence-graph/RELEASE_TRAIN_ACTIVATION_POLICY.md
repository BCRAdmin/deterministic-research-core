# Release Train Activation Policy

B14 ist eine lokale Readiness- und Gate-Schicht. Sie darf Release-Trains, Abhängigkeiten, Blocker, Verifier und Operator-Entscheidungen sichtbar machen, aber keine Aktivierung ausführen.

Ein `PASS` im Audit bedeutet:

- lokale Release-Train-Pakete sind vollständig und quellengebunden;
- Public, Production, Deploy, Publish, Payment/Geld, Auth/Credentials, externe Kommunikation, echte Daten, Room16-Rerun, Finanzpublishing, Remote-Bridge-Arming und irreversible Aktionen bleiben geschlossen;
- Lizenz-/Provenance-Fragen bleiben Kandidatenarbeit aus B13 und keine Rechts- oder Redistribution-Freigabe;
- jedes Aktivieren braucht ein eigenes explizites Operator-Go plus passende Fach-/Rechts-/Datenschutzprüfung.

B14 darf keine Produktivfreigabe, keine öffentliche Freigabe, keine Zahlungs- oder Auth-Aktivierung, keine externe Kommunikation und keine echte Datenverarbeitung behaupten.
