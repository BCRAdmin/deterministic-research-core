---
type: fresh_session_handoff_template
status: active
updated: 2026-05-22
systems:
  - Vega
  - Vivi
  - Project Intelligence Graph
  - LIONCOM
tags:
  - quality-operating-system
  - fresh-session
---

# Fresh Session Handoff Format

## Zweck

Eine frische Vega-, Vivi-, Codex- oder Claude-Code-Session soll nicht aus Chat-Resten rekonstruieren, was gilt. Das Handoff zeigt den kleinsten sicheren Startpfad.

## Härtungsanalyse

- Handoff verweist auf lokale Artefakte, nicht auf Chat-Erinnerung.
- Offene Operator-Gates bleiben sichtbar.
- Der nächste sichere Schritt darf keine Public-, Production-, Credential-, Money-, Lösch- oder External-Send-Aktion sein.

## Zielbild-/Archetypanalyse

Archetyp: [[Agent Job Card]] plus [[Operator Dashboard / Control Surface]]. Eine neue Session liest Backbone, Operator Brief, Quality-OS-Surface, letzten Run und offene Gates.

## Pflichtfelder

### handoff_id

Stabiler Identifier.

### generated_at

UTC-Zeitpunkt.

### latest_run

Letzter relevanter Workflow Run.

### reading_order

Konkrete Lesereihenfolge für die frische Session.

### open_gates

Gates, die bewusst nicht gelöst wurden.

### active_contracts

Build Contracts, die nicht abgeschlossen sind.

### next_safe_step

Der eine sichere nächste Schritt.

### verifier_summary

Welche Checks den Stand belegen.

### blocked_actions

Aktionen, die nur mit Operator-Go erlaubt sind.

### memory_status

Ob Latest Session Context, Learnings und Roadmap aktualisiert wurden oder noch Pending-Sync brauchen.

## Nicht-Ziele

- keine n8n-Runtime
- kein Chat-only-Handoff
- keine stille Gate-Freigabe
- keine frische Session in riskante Aktion führen

## Verifier

- `python3 scripts/project_intelligence_graph/pig.py validate-quality-os`
- `python3 scripts/project_intelligence_graph/pig.py full-check`

## Cross-Project-Wirkung

Systemweit: jedes größere DreamFactory-/LIONCOM-/Room16-/PIG-Projekt kann später ein solches Handoff erzeugen.

## Operator-Gates

Public, Production, Credentials/Auth, Geld, Löschung, externe Kommunikation und Room16-Reruns bleiben harte Operator-Gates.
