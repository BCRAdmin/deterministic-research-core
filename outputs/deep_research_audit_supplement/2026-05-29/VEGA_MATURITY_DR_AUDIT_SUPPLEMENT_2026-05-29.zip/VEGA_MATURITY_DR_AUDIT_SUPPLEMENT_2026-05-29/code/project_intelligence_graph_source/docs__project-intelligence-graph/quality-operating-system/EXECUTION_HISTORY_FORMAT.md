---
type: execution_history_template
status: active
updated: 2026-05-22
systems:
  - Vega
  - Vivi
  - Project Intelligence Graph
tags:
  - quality-operating-system
  - execution-history
  - workflow-run
---

# Workflow Execution History Minimum

## Zweck

Ein Workflow Run darf nicht nur im Chat existieren. Diese Struktur ist das kleinste lokale Format für Verlauf, Verifier, Failure, Evidence und Memory-Updates.

## Pflichtfelder

### run_id

Stabiler Lauf-Identifier, zum Beispiel `20260522T020000Z-quality-os-contracts`.

### started_at

UTC-Zeitpunkt im ISO-Format.

### contract

Pfad oder ID des Build Contracts.

### workflow_steps

Geordnete Liste der Job Cards, Gate Nodes, Verifier und Memory-Schritte.

### current_step

Aktueller Step-ID oder `completed`.

### approval_nodes

Liste sichtbarer Human-Approval-Gates mit Status.

### verifiers

Liste der erwarteten und gelaufenen Checks.

### status

`running`, `waiting_for_operator`, `waiting_for_evidence`, `retry_allowed`, `failed_safe`, `completed_verified` oder `closed_no_action`.

### failures

Strukturierte Fehler mit Step-ID, Ursache, Retry-Erlaubnis und Stop-Regel.

### evidence

Pfade, Command-Ausgaben, Reports oder Artefakte, die den Lauf belegen.

### memory_updates

Welche Vault-/Backbone-/Pending-Sync-Änderungen wurden geschrieben oder sind nötig?

### completed_at

UTC-Zeitpunkt oder `null`, solange der Lauf offen ist.

## V3 Control-Felder

### control_state

`running`, `paused`, `waiting_for_operator`, `retry_allowed`, `completed` oder ein projektspezifischer lokaler Status.

### retry_count

Wie oft ein Run oder Step schon wiederholt wurde.

### pause_resume_retry

Objekt mit den Controls `pause`, `resume` und `retry`. Jedes Control muss sagen, ob es lokal erlaubt ist, ein Operator-Gate braucht und ob es Runtime-Wirkung hätte.

### operator_actions

Liste lokaler Operator Actions. Riskante Actions müssen `operator_gate_required=true` tragen und dürfen nicht automatisch ausgeführt werden.

## JSON Skeleton

```json
{
  "run_id": "20260522T020000Z-quality-os-contracts",
  "started_at": "2026-05-22T02:00:00Z",
  "contract": "docs/project-intelligence-graph/quality-operating-system/BUILD_CONTRACT_TEMPLATE.md",
  "workflow_steps": [
    {
      "step_id": "contract-template",
      "type": "JobCard",
      "status": "completed_verified",
      "output": "BUILD_CONTRACT_TEMPLATE.md"
    }
  ],
  "current_step": "completed",
  "approval_nodes": [
    {
      "id": "public_release_gate",
      "status": "not_required_for_local_build"
    }
  ],
  "verifiers": [
    {
      "command": "python3 scripts/project_intelligence_graph/pig.py full-check",
      "status": "pending"
    }
  ],
  "status": "completed_verified",
  "control_state": "completed",
  "retry_count": 0,
  "pause_resume_retry": {
    "pause": {
      "status": "ready_for_future_running_runs",
      "runtime_effect": "local_state_only"
    },
    "resume": {
      "status": "ready_for_future_paused_runs",
      "runtime_effect": "local_state_only"
    },
    "retry": {
      "status": "metadata_ready_gate_bound",
      "runtime_effect": "none_until_operator_or_safe_local_gate"
    }
  },
  "operator_actions": [],
  "failures": [],
  "evidence": [],
  "memory_updates": [],
  "completed_at": null
}
```
