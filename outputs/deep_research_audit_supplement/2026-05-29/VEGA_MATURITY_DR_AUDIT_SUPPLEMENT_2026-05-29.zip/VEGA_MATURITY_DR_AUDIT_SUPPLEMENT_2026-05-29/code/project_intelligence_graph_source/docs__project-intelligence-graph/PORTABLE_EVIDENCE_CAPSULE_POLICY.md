# Portable Evidence Capsule Policy

Status: active local policy

## Zweck

Die Portable Evidence Capsule ist ein kleines claim-level Beweispaket für interne und spätere Audit-Vorbereitung. Sie soll zeigen, warum ein lokaler `PASS`-Claim nachvollziehbar ist, ohne rohe PIG-Graphdaten, Datenbanken, lokale Runtime-Dumps oder absolute private Ursprungspfade mitzuschleppen.

## Pflichtregeln

- Capsule-Claims nennen `source_ids`, relative Evidence-Pfade, Hashes, Verifier und geschlossene Operator-Gates.
- Absolute Pfade sind in der Capsule selbst verboten.
- Rohgraph, `.git`, Datenbanken, Credentials/Auth, echte Personen-/Mandantendaten und Room16-Reruns bleiben ausgeschlossen.
- `portable_pass` bedeutet nur lokal belegt und reproduzierbar zusammengefasst. Es bedeutet nicht Public, Production, Publish, Payment, Auth, externe Kommunikation oder externe Audit-Freigabe.
- Jede externe Weitergabe braucht ein separates Operator-Go und ein Redaktionsprofil.

## Verhältnis zu B02/B03/B04

- B02 liefert Source Registry und Evidence Spine.
- B03 liefert Contradiction-/Staleness-Entscheidungen.
- B04 liefert das große Deep-Research-Bundle.
- B05 extrahiert daraus eine kleinere, portable Beweisoberfläche für einzelne lokale Claims.
