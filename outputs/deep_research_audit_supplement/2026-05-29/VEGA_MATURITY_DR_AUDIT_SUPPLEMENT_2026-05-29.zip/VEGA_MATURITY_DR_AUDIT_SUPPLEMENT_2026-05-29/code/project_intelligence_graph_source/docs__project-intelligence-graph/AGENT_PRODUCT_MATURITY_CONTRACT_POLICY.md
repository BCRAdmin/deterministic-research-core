# Agent Product Maturity Contract Policy

## Zweck

Das Agent Product Maturity Contract ist die zweite harte Schranke nach dem Agentization Decision Gate. Es erlaubt, später echte Agentenprodukte zu bauen, ohne heute das System mit Rollen, Startkontext und Persona-Regeln aufzublähen.

## Harte Regeln

- Ein Agent-Kandidat ist noch kein Produktagent.
- Ein Produktagent braucht einen eigenen Vertrag mit Operator-Problem, Zielnutzer, Trigger, Job Cards, Artefaktvertrag, Verifier, Handoff, Memory, Safety-Gates, Kontextbudget, Operator-Surface, Support/Rollback und kommerzieller oder operativer Rolle.
- Kein Agent darf `agent_approved` sein, wenn kein vollständiger Produktreifevertrag existiert.
- Der Vertrag darf keine Runtime-, externe, Public-, Production-, Payment-, Auth- oder irreversible Aktion öffnen.
- Design-, Quality-, Security- oder Benchmark-Ideen bleiben Capabilities, bis sie wiederkehrende Arbeit, eigene Outputs und echten Produktnutzen belegen.

## Produktreife-Kriterien

- klare Zielgruppe oder interner Operator-Workflow
- wiederkehrendes, eigenständiges Arbeitsproblem
- deterministische Verifier und Failure-Fixtures
- lesbares Handoff für Vega/Operator
- Obsidian-/PIG-Memory-Route
- frische Session mit kleinem Kontextbudget
- sichtbare LION/PIG Operator-Surface
- Support-, Rollback- und Nicht-Ziele
- keine Namenskollision mit `Operator`, `Vega`, `Vivi`, `Codex`, `Vegapunk` oder `Shannon`

## Abschlussregel

Block 10 gilt erst als grün, wenn `agent-product-contract`, `full-check`, Source Registry und LION Planning Surface den Produktvertrag anzeigen und weiterhin keine Produktagenten ohne Vertrag zulassen.
