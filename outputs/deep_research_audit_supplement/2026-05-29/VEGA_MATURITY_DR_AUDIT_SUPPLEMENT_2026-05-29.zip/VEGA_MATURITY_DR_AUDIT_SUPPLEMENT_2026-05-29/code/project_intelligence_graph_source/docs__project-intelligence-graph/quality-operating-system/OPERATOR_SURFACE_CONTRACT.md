---
type: operator_surface_contract
status: active
updated: 2026-05-22
systems:
  - LIONCOM
  - Project Intelligence Graph
  - Vega
  - Vivi
tags:
  - quality-operating-system
  - operator-surface
---

# Operator Surface Vorbereitung

## Zielbild

LIONCOM muss später nicht n8n einbetten. Es soll eine lokale, PIG-gespeiste Planning-Quality-/Workflow-Run-Sicht zeigen.

## Härtungsanalyse

- Quelle bleibt PIG/Backbone, nicht Chat.
- Riskante Approval Nodes bleiben sichtbar statt implizit freigegeben.
- Statuswerte müssen aus lokalen Artefakten kommen und dürfen nicht als Modell-/Provider-Wahrheit verwechselt werden.

## Zielbild-/Archetypanalyse

Archetyp: [[Operator Dashboard / Control Surface]] mit n8n-inspirierter Workflow-Run-Sicht, aber ohne n8n-Runtime.

## Datenstruktur

Operator soll sehen können:

- aktive Build Contracts
- offene `needs_target_picture`
- offene Approval Nodes
- aktuelle Workflow Runs
- letzter Verifier
- nächster sicherer Schritt
- warum etwas gestoppt wurde
- ob eine Verbesserung lokal, projektübergreifend oder systemweit gilt
- Operator Actions mit `available_local_record` oder `blocked_operator_gate`
- Pause-/Resume-/Retry-Control-State für Workflow Runs
- Fresh-Session-Handoff mit Lesereihenfolge und offenen Gates

## Cross-Project-Wirkung

Systemweit: dieselbe Datenstruktur soll für Vega, Vivi, Codex, Claude Code und andere lokale Agenten funktionieren.

## Quelle

Primaere lokale Datenquellen:

- `outputs/project_intelligence_graph/contract_quality_gate.json`
- `outputs/project_intelligence_graph/contract_quality_gate.md`
- `outputs/project_intelligence_graph/operator_brief.json`
- `outputs/project_intelligence_graph/full_check_report.json`
- `outputs/project_intelligence_graph/quality_os_operator_controls.json`
- `outputs/project_intelligence_graph/quality_os_fresh_session_handoff.json`
- Build-Contract-, Job-Card- und Execution-History-Artefakte aus diesem Ordner und dem Vault

## Nicht-Ziele

- keine n8n-Runtime
- keine Cloud-Abhängigkeit
- keine Credentials-Schicht
- kein Public-/Production-Schalter ohne Operator-Go
- keine echte Approval-/Retry-Ausführung ohne passendes Operator-Gate

## Verifier

- `python3 scripts/project_intelligence_graph/pig.py full-check`
- `python3 scripts/project_intelligence_graph/pig.py operator-brief`
- `python3 scripts/project_intelligence_graph/pig.py validate-quality-os`
- PIG selftest muss eine Planning-Quality-Control-View erzeugen.
