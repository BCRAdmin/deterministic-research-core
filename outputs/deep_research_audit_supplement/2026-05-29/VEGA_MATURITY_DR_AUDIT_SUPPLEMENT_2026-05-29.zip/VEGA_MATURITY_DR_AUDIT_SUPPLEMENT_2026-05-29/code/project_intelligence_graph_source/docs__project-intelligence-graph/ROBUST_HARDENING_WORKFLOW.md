# Robust Hardening Workflow

Ziel: Jede künftige Härtung oder Reparatur soll so eng geführt sein, dass auch ein schwaches LLM oder ein müder Operator das System korrekt nutzen kann.

## Ein Befehl für Zustand

```bash
python3 scripts/project_intelligence_graph/pig.py operator-brief
```

Der Operator Brief sagt:

- was jetzt zu tun ist
- was nicht getan werden darf
- welche Statuswerte gelten
- welche sicheren Befehle erlaubt sind

## Ein Vertrag vor jeder Härtung

Vor nicht-trivialen Änderungen:

```bash
python3 scripts/project_intelligence_graph/pig.py new-fix "short title" \
  --objective "one sentence objective" \
  --risk-class R2 \
  --allowed "scripts/project_intelligence_graph/pig.py" \
  --allowed "docs/project-intelligence-graph/README.md"
```

Der Contract wird hier geschrieben:

```text
outputs/project_intelligence_graph/hardening_fix_contracts/
```

## Quality Control

Vor der Änderung:

```bash
python3 scripts/project_intelligence_graph/pig.py quality-baseline --label before-fix
```

Nach der Änderung:

```bash
python3 scripts/project_intelligence_graph/pig.py quality-gate \
  --baseline outputs/project_intelligence_graph/quality_baseline.json \
  --improvement "short evidence of what improved"
```

Das Gate blockiert:

- fehlgeschlagenen Full-Check
- verlorene Selftests
- neue Selftest-Fails
- mehr aktive R4/R5-Automationen
- mehr offene P0-Entscheidungen
- mehr Coverage-Gaps
- mehr Policy-Items
- fehlende Improvement-Evidence
- Regression, neue Fehler oder neue Einschränkungen

## Pflichtregeln

1. Kein Fix ohne Ziel in einem Satz.
2. Kein breiter Dateizugriff ohne `allowed_paths`.
3. Generierte Reports nie manuell editieren.
4. Status nur durch Scanner, CLI oder State-Dateien ändern.
5. R4/R5 braucht sichtbare Operator-Entscheidung oder explizites Go.
6. `WARN` ist kein Fehler zum Wegformulieren, sondern sichtbare Restarbeit.
7. Quality Baseline vor der Änderung, Quality Gate nach der Änderung.
8. Wenn Quality Gate / Verifier neue Fehler, neue Einschränkungen oder größere Risk-/Operator-Last zeigt, ist es keine akzeptierte Verbesserung; erst neu analysieren und kleiner schneiden.
9. Abschluss immer mit:

   ```bash
   python3 scripts/project_intelligence_graph/pig.py full-check
   ```

## Validierung

Alle Fix-Verträge prüfen:

```bash
python3 scripts/project_intelligence_graph/pig.py validate-fix
```

Einen bestimmten Contract prüfen:

```bash
python3 scripts/project_intelligence_graph/pig.py validate-fix --path outputs/project_intelligence_graph/hardening_fix_contracts/CONTRACT.json
```

## Einfachste Bedienfolge

Wenn der Agent oder Operator unsicher ist:

```bash
python3 scripts/project_intelligence_graph/pig.py operator-brief
python3 scripts/project_intelligence_graph/pig.py new-fix "what you are about to change" --objective "why this change is needed"
python3 scripts/project_intelligence_graph/pig.py quality-baseline --label before-fix
python3 scripts/project_intelligence_graph/pig.py quality-gate --baseline outputs/project_intelligence_graph/quality_baseline.json --improvement "what improved"
python3 scripts/project_intelligence_graph/pig.py full-check
```

## Abschlussvertrag

Eine Härtung gilt erst als fertig, wenn:

- der Contract valide ist
- das Quality Gate PASS meldet
- die Änderung im erlaubten Scope bleibt
- `full-check` PASS meldet
- neue dauerhafte Regeln im Skill, README, CLAUDE.md oder Backbone stehen
- der Operator nicht aus rohen JSON-Dateien entscheiden muss
