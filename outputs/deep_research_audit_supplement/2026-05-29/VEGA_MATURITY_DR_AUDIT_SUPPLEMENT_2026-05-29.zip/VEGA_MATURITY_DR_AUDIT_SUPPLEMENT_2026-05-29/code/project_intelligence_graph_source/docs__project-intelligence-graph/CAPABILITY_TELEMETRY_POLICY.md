# Capability Telemetry Policy

## Zweck

Capability-Telemetrie beantwortet eine schmale Frage: Welche Capabilities, Gates, Benchmarks oder Sandboxes haben nachweislich Wert erzeugt, ohne daraus voreilig neue Agentenrollen zu machen?

## Harte Regeln

- Ein Eintrag zählt nur, wenn er ein Artefakt verbessert, ein Risiko blockiert, ein Dokument lesbarer macht, eine Oberfläche verifiziert oder einen belegten Fehler verhindert.
- Jede Nutzung braucht `capability_id`, Datum, Projekt, Outcome, Verifier, Evidence-Pfad und mindestens eine positive Wertmetrik.
- GitHub-Stars, Benchmarks und fremde Repos werden als Nutzung erfasst, wenn sie Entscheidungen, Audits oder Vergleichbarkeit verbessern. Das ist keine Runtime-Adoption.
- `agent_candidate_signal=true` reicht nie allein. Agent-Kandidaten brauchen Trigger, Job Card, Artefakt, Verifier, Handoff und Memory-Proof.
- Shannon bleibt eine Security-Sandbox. Shannon-Telemetrie darf Schutzwert und Scope-Prüfung erfassen, aber keine laufende Security-Agent-Rolle ableiten.
- Design-, Motion-, Anti-Slop- und Report-Qualität laufen zuerst als Hintergrund-Gates. Ein eigener Quality-Design-Agent entsteht erst nach wiederkehrendem eigenem Arbeitskreislauf.

## Zählweise

- `usage_count`: belegte Nutzungen pro Capability.
- `verified_value_count`: Nutzung mit Outcome, Verifier und Evidence.
- `prevented_issue_count`: verhinderte Fehlentscheidung, falscher Scope, falsche Archivierung oder falsche Runtime-Aktivierung.
- `risk_blocked_count`: bewusst blockiertes Risiko wie Installation, externe Aktion, Live-Scan, Scope-Drift oder Agenten-Bloat.
- `better_document_count`: lesbarer oder auditierbarer Output, der für den Operator dauerhaft besser nutzbar ist.
- `verified_surface_count`: UI, PDF, Report oder Operator-Surface wurde maschinell oder visuell geprüft.
- `time_saved_estimate_minutes`: nur eintragen, wenn der Wert konservativ belegbar ist; sonst `0`.

## Abschlussregel

Block 8 gilt erst als grün, wenn `capability-telemetry` PASS meldet, `usage_total > 0`, `agent_candidate_count = 0` ohne Lifecycle-Beweis bleibt und die Telemetrie in Source Registry, Full Check und LION Operator Surface sichtbar ist.
