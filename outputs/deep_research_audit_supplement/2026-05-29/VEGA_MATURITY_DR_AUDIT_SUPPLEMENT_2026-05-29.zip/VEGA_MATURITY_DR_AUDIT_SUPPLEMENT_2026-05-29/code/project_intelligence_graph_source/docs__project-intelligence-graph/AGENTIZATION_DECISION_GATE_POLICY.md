# Agentization Decision Gate Policy

## Zweck

Das Agentization Decision Gate verhindert Agenten-Bloat. Neue Namen bleiben zuerst Capability, Gate, Benchmark, Sandbox oder Review-Modus, bis echter Lifecycle-Wert belegt ist.

## Pflicht-Lifecycle

Eine Capability darf erst Agent-Kandidat werden, wenn alle Stationen nachweisbar sind:

```text
Trigger -> Job Card -> Work -> Artifact -> Verifier -> Handoff -> Memory
```

## Harte Regeln

- Kein neuer Agent ohne `agentization-gate` PASS.
- Default ist `stay_capability`.
- Mindesttelemetrie vor Kandidatur: mindestens fünf belegte Nutzungen, mindestens drei verified-value Events und `agent_candidate_ready=true`.
- Namen dürfen nicht mit `Operator`, `Vega`, `Vivi`, `Codex` oder `Vegapunk` kollidieren.
- Shannon bleibt Security-Sandbox, nicht Security-Agent.
- Design-, Motion-, Anti-Slop- und Report-Qualität laufen im Hintergrund als Gates, bis ein eigener wiederkehrender Arbeitskreislauf belegt ist.
- Das Gate darf keine Runtime-, externe oder irreversible Aktion ausführen.

## Harte Ablehnung

Agentifizierung ist abzulehnen, wenn sie nur durch ein gutes Repo, einen GitHub-Star, Branding, Geschmack, Benchmark-Interesse oder eine einmalige Analyse motiviert ist.

## Abschlussregel

Block 9 gilt erst als grün, wenn `agentization-gate`, `capability-registry`, `source-registry`, `operator-surface`, Full Check und LION Planning Surface die Gate-Werte ohne neue Agentenrolle anzeigen.
