# Room16 QualityDecision Integration Policy

## Zweck

B10 verbindet die lokale Room16 QualityDecision-Wahrheit mit der Product Rail Matrix. Die Integration ist ein PIG-Nachweisartefakt, kein Room16-Rerun, kein Publish-Befehl und keine Sichtbarkeitsänderung.

## Harte Regeln

- QualityDecision ist die Lebenszyklus-Wahrheit für `quality_verdict`, `review_status`, `publishable`, `public_ready`, `visibility` und `public_rating`.
- `local_verifier_green` bedeutet nur: lokale Nachweise sind vorhanden und prüfbar.
- `publishable_text_green=false`, `operator_gate_required=true`, `public_ready=0` oder `effective_public=0` blockieren Public/Member/Publish.
- Room16-Rerun, Push, Publish, Public-/Member-Sichtbarkeit, Production, Geld/Payment, Auth/Credentials, externe Kommunikation, echte Personen-/Mandantendaten, Financial-Advice-Publishing, Delete und irreversible Aktionen bleiben Operator-Gates.
- B10 darf nur vorhandene lokale Evidence lesen und PIG-Artefakte regenerieren.

## Done Definition

- B10 hat Schema, Policy, Integration und Audit.
- Der Audit verifiziert QualityDecision-Core, Schema, Tests, App-Wiring, Core-V2-Handoff, B09-Achsen, Review-Gate, Manual-Review-Pakete und Publish-Readiness.
- Die Aktion-Flags bleiben alle `false`.
- Ein PASS im Audit bedeutet `completed_verified_local`, nicht Publish- oder Produktivfreigabe.
