# Separate Acceptance Runner

## Purpose

The separate acceptance runner is a small shared harness for project-specific
audit profiles. It standardizes result sections, command checks, JSON reports,
Markdown reports, and the operator-facing command entrypoint.

It is not a replacement for `pig.py full-check`, and it is not a new agent or
large workflow framework. A profile should exist only when it prevents repeated
one-off audit scripts or helps a fresh session run a proven verification path in
one command.

## Standard Command

```bash
python3 scripts/project_intelligence_graph/separate_acceptance.py --profile capability-governance
```

List available profiles:

```bash
python3 scripts/project_intelligence_graph/separate_acceptance.py --list-profiles
```

Fast local smoke run for the current profile:

```bash
python3 scripts/project_intelligence_graph/separate_acceptance.py --profile capability-governance --skip-full-check --skip-lion
```

## Current Profile

`capability-governance` runs the Thin Roles capability governance acceptance
path. It checks the capability registry, Shannon sandbox contract, fresh session
context budget, background quality gates, telemetry, agentization gate, product
maturity contract, source registry, operator surface, LION surface, vault memory
anchors, worker regression guard, core verifiers, and the umbrella full-check.

Reports:

- `outputs/project_intelligence_graph/capability_governance_separate_test_report.md`
- `outputs/project_intelligence_graph/capability_governance_separate_test_report.json`

## Profile Contract

A profile should:

- keep domain-specific checks in its own script;
- use `separate_acceptance_runner.py` for common helpers and report writing;
- produce Markdown and JSON reports;
- separate code, CLI, artifact, UI, memory, regression, and umbrella checks when relevant;
- expose runtime, external, and irreversible action flags as false unless the operator explicitly approved otherwise;
- stay small enough that a fresh session can understand the profile without reading old chat history.

Do not create a new profile for a single local bug fix. Use one when the same
acceptance shape will be reused across projects or sessions.
