# Operator Intent Contract Template

Use this before turning a tired or broad operator signal into a build plan.

CLI materializer:

```bash
python3 scripts/project_intelligence_graph/pig.py operator-intent --signal "Originales Operator-Signal"
```

Lifecycle update:

```bash
python3 scripts/project_intelligence_graph/pig.py operator-intent --intent-id "contract-id" --set-status completed_verified --note "Verifier summary"
```

Outputs:

- `outputs/project_intelligence_graph/operator_intent_contracts/*.json`
- `outputs/project_intelligence_graph/operator_intent_contracts/*.md`
- `outputs/project_intelligence_graph/latest_operator_intent_contract.json`
- `outputs/project_intelligence_graph/latest_operator_intent_contract.md`

```json
{
  "schema_version": 1,
  "intent_id": "YYYYMMDD-short-slug",
  "created_at": "YYYY-MM-DDTHH:MM:SSZ",
  "operator_signal": "Raw operator wording or short quote.",
  "plain_language_goal": "What Björn wants in normal words.",
  "target_picture": "What Björn should later see, control, decide or trust.",
  "done_definition": [
    "Concrete finished-state criterion."
  ],
  "non_goals": [
    "What must not be built or claimed."
  ],
  "affected_projects": [
    "PIG",
    "LIONCOM",
    "Room16",
    "Kanzlei AI Assist",
    "Agent Ops"
  ],
  "impact_radius": "systemwide",
  "rule_candidates": [
    "possible new or changed rule id"
  ],
  "operator_gates": [
    "Public",
    "Production",
    "money",
    "credentials",
    "auth",
    "deletion",
    "external communication",
    "real client/person data",
    "financial-advice publishing",
    "Room16 rerun"
  ],
  "deterministic_system_preference": true,
  "cost_policy": "Prefer deterministic schemas, parsers, state machines and local verifiers over LLM-heavy chat behavior unless language/research synthesis is the actual task.",
  "verifier_plan": [
    "python3 scripts/project_intelligence_graph/pig.py rule-propagation",
    "python3 scripts/project_intelligence_graph/pig.py full-check"
  ],
  "propagation_check_required": true,
  "next_safe_block": "Smallest local reversible implementation block.",
  "status": "ready_to_build"
}
```
