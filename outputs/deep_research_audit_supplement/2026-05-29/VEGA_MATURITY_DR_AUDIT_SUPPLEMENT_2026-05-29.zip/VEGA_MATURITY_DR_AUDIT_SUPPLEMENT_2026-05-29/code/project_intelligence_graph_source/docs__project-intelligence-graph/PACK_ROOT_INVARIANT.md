# Pack Root Invariant

Status: `active`

## Begriffe

Ein `runnable pack root` ist ein entpackter Ordner, der als aktuelles Arbeitsverzeichnis direkt die lokale PIG-Minimalverifikation tragen kann. Wenn ein Audit- oder Verification-Pack einen Ordner `workspace/` enthält, gilt dieser Ordner als `runnable pack root`, außer die README markiert ihn ausdrücklich als reinen Snapshot.

Ein `source/evidence snapshot` ist ein Lesepaket aus Quellen, Reports, Handoffs und Evidenzdateien. Es darf `workspace` nicht als Top-Level-Ordnername verwenden, wenn die Mindestbefehle dort nicht reproduzierbar laufen. Ein Snapshot muss dann klar als `local_only_snapshot`, `evidence_snapshot` oder `source_snapshot` benannt sein.

## Mindestbefehle

Diese Befehle müssen in einem `runnable pack root` grün laufen:

```bash
python3 -m unittest discover -s tests -p 'test_*.py'
python3 scripts/project_intelligence_graph/replay_pack.py --pack-root .
python3 scripts/project_intelligence_graph/pig.py --help
```

`python3 scripts/project_intelligence_graph/pig.py full-check --json` gehört nicht zur Minimalinvariante. Der volle `full-check` bleibt `original_workspace_only`, solange Vault-, LIONCOM- und historische Full-Check-Abhängigkeiten nicht über explizite Stubs, Fixtures oder sichere Config aufgelöst sind.

## Pflichtartefakte

Ein `runnable pack root` enthält mindestens:

- `scripts/project_intelligence_graph/pig.py`
- `scripts/project_intelligence_graph/replay_pack.py`
- `scripts/project_intelligence_graph/m9_efficiency.py`
- `tests/project_intelligence_graph/`
- `tests/fixtures/`
- `status_semantics.yml`
- `profile_manifests/generator_sources.json`
- `independent_replay_pack.json`
- `profiles/generator_sources/scripts/project_intelligence_graph/archive_reference_helpers.py`
- `profiles/generator_sources/scripts/project_intelligence_graph/dirt_status_helpers.py`
- `profiles/generator_sources/scripts/project_intelligence_graph/evidence_budget_helpers.py`
- `profiles/generator_sources/scripts/project_intelligence_graph/report_markdown.py`

## Statuswahrheit

`replay_pack.py --pack-root .` darf nur `PASS` melden, wenn die Pflichtartefakte vorhanden sind, die Generator-Helper kompilieren und importieren, die Import-Closure nicht fehlt und die ausführbaren Mindestchecks erfolgreich laufen. Fehlende Manifeste, Fixtures oder Helper sind mindestens `ACTION_REQUIRED`; fehlschlagende Mindestbefehle sind `FAIL`.

```mermaid
flowchart TD
  A["Audit/Verification ZIP entpackt"] --> B{"Top-Level workspace/ vorhanden?"}
  B -->|ja| C["workspace/ muss runnable pack root sein"]
  B -->|nein| D["Paket darf source/evidence snapshot sein"]
  C --> E["unittest, replay_pack, pig --help"]
  E --> F{"alle grün?"}
  F -->|ja| G["Root-Replay PASS"]
  F -->|nein| H["ACTION_REQUIRED oder FAIL"]
  D --> I["README muss Snapshot-Grenze klar markieren"]
```
