# Roadmap Prompt Pack Ingest Policy

## Purpose

This policy prevents implementation-ready roadmap/prompt packs from being reduced to a First Mention or a chat summary.

## Trigger

A source is a roadmap prompt pack when it includes at least two of:

- roadmap or implementation plan
- masterprompt or agent work order
- build plan or acceptance criteria
- architecture or workflow diagram
- QA/verifier/publish-check rules
- privacy/policy/stop rules
- manifest or source URL list

## Required Import Evidence

- source identity and hash
- visible vault import target
- leading MOC or project anchor
- project/seed/canonical routing
- canvas for roadmap/architecture/workflow knowledge
- quality/safety audit with scoped PASS/WARN/FAIL
- resolved wikilinks for the new import surface
- explicit outer-chat precedence when the pack contains a prompt

## Gate Runner

```bash
python3 scripts/project_intelligence_graph/roadmap_prompt_pack_ingest_gate.py \
  --source-zip /path/to/pack.zip \
  --import-root "/path/to/vault/Human Overview/<folder>" \
  --vault-root "/path/to/vault"
```

PASS means the import surface is durable and linked. It does not mean product code was implemented or professionally approved.
