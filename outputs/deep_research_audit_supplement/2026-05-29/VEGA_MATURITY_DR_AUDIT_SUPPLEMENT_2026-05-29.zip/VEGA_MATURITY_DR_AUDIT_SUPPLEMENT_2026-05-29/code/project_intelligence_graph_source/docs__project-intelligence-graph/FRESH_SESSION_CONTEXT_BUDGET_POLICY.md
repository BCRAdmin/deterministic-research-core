# Fresh Session Context Budget Policy

## Purpose

The Fresh Session Context Budget keeps new Vega, Vivi and Codex sessions from loading too much historical context before they know the active task.

## Rule

A fresh session should start from the smallest useful context route:

```text
Start note -> canonical decision/rule -> capability registry -> one relevant detail surface
```

Default maximum: `4` core notes before an overview note or task-specific surface must carry the rest.

## Required Task Routes

- External repo audit: start note, External Repo Audit Standard, capability registry, relevant audit/repo note.
- Design review: start note, Thin Roles decision, design quality gate entry, project UI surface or screenshot.
- Shannon/security work: start note, Thin Roles decision, Shannon Security Sandbox registry entry, Shannon sandbox rule.
- Benchmark or LLM comparison: start note, capability registry, Codeneedle benchmark entry, current model/provider truth.
- Readable report delivery: start note, Readable Report Delivery Standard, report capability entry, source evidence layer.
- New agent idea: start note, Thin Roles decision, Agentization Decision Gate, capability telemetry artifact.

## Hard Rejections

- Loading all reports or all starred repositories before a specific question is known.
- Treating a capability as an agent because a name sounds useful.
- Opening runtime, public, production, payment, auth, external communication or irreversible gates from context loading alone.

## Verifier

```bash
python3 scripts/project_intelligence_graph/pig.py fresh-session-budget --json
python3 scripts/project_intelligence_graph/pig.py fresh-session-readiness --json
python3 scripts/project_intelligence_graph/pig.py capability-registry --json
python3 scripts/project_intelligence_graph/pig.py full-check --json
```

## Done Definition

This policy is healthy when the Fresh Session Context Budget is `PASS`, every listed task route stays within `4` core notes, and LION/PIG surfaces expose the budget without creating a new agent role.
