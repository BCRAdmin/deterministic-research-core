# Vivi Worker v3 Policy

Status: active local policy  
Block: B07  
Scope: PIG-generated claim plans and supervisor audits only

## Purpose

Vivi Worker v3 is a safer local project worker pattern. It does not broaden Vivi into a general autonomous actor. It makes Vivi useful by limiting work to typed local claims with sources, verifiers, evidence, denied-action acknowledgement and Vega/PIG supervisor review.

## Required Card Fields

Every v3 worker card must contain:

- `job_id`
- `block_id`
- `claim_type`
- `risk_class`
- `source_ids`
- `expected_outputs`
- `verifiers`
- `denied_actions_acknowledged`
- `runtime_action_executed=false`
- `irreversible_action=false`
- `supervisor_required=true`

## Allowed Claim Types

- `status_reconciliation`
- `source_registry_update`
- `evidence_capsule_dry_run`
- `bundle_sanitizer_verify`
- `deep_research_claim_extract`
- `product_rail_matrix_update`
- `license_inventory_draft`
- `local_doc_update`
- `local_schema_fixture`
- `contradiction_report_build`

## Permanent Denylist

Vivi v3 may not perform or imply any of these actions without a separate operator gate:

- push
- delete
- deploy
- publish
- production
- payment or money movement
- credentials or auth changes
- external communication
- real person or client data
- Room16 rerun
- visibility, public or member switch
- financial or tax advice
- irreversible action

## Status Semantics

The supervisor must keep these fields separate:

- `verifier_run_success`
- `artifact_state_green`
- `publishable_text_green`
- `operator_gate_open`
- `externally_validated`

A verifier pass can never imply public readiness, production readiness, external validation or an open operator gate.

## Supervisor Failure Classes

- `denied_action_requested`
- `missing_source_ids`
- `missing_verifier`
- `stale_conflict_unresolved`
- `gate_required`
- `external_validation_missing`
- `manual_review_required`
- `runtime_action_risk`

## Completion Rule

A card can only reach `completed_verified` after local verifier evidence exists, denied actions stayed closed, runtime/external/irreversible actions stayed false and Vega/PIG supervisor audit passed.
