# Product Rail Matrix Policy

Status: active

## Zweck

B09 materialisiert die Produkt-Rails als lokale Entscheidungsmatrix. Die Matrix bündelt Room16, Kanzlei AI Assist, Utility Websites und Membership/Quellwert mit derselben Reifesprache:

- lokale Verifier-Reife
- Artefakt-/Rail-Reife
- Launch-/Activation-Posture
- Public-, Production-, Payment-, Auth- und externe Validierung
- Operator-Gates und nächste sichere Arbeit

## Harte Grenze

Die Product Rail Matrix ist eine lokale, read-only Entscheidungsfläche. Sie darf keine Public-, Production-, Payment-, Auth-, Credential-, Publishing-, Rerun-, Push-, Delete-, externe Kommunikations- oder irreversible Aktion auslösen.

## Status-Semantik

`PASS` in einem Rail-Verifier bedeutet lokale Prüfbarkeit. Es bedeutet nicht:

- publishbare Ausgabe
- externe Validierung
- geöffnetes Operator-Gate
- Product-/Production-Reife
- erlaubte Zahlungs-, Provider-, Credential- oder Kommunikationsaktion

Wenn eine Rail lokal grün ist, aber Public/Production/External/Payment/Auth geschlossen bleibt, muss die Matrix `local_verified_operator_gated` oder einen ähnlich klaren Zustand zeigen.

## Akzeptanz

B09 ist nur akzeptiert, wenn:

- alle vier Kern-Rails enthalten sind
- jede Rail Source-IDs und Evidence-Refs trägt
- alle Reifeachsen vorhanden sind
- geschlossene Gates in jeder Rail sichtbar bleiben
- Runtime-, External- und Irreversible-Flags überall `false` sind
- B08 Decision Cockpit, Status Semantics, Project Verticals, Launch Readiness und Source Registry als Abhängigkeiten grün oder erwartbar `WARN` sind
- LIONCOM die Matrix lesen kann, ohne Runtime-Aktionen freizuschalten
