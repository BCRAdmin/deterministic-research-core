# Project Intelligence Graph Agent Portability

Der Project Intelligence Graph ist als lokale, agentenagnostische Projektschicht gebaut.

## Nutzbar mit

- Codex
- Claude Code
- Vivi
- Vega
- anderen Coding-Agenten mit lokalem Dateizugriff und Python

## Nicht portable Schicht

Codex-Skills sind Codex-spezifische Bedienhüllen:

- `/Users/BjornRosinger/.codex/skills/vega-project-intelligence-graph/SKILL.md`

Sie sind hilfreich, aber nicht die Produktlogik.

## Portable Schicht

Diese Dateien sind die eigentliche Schnittstelle:

- `scripts/project_intelligence_graph/scan_project_intelligence_graph.py`
- `scripts/project_intelligence_graph/pig.py`
- `docs/project-intelligence-graph/*.json`
- `outputs/project_intelligence_graph/*.json`
- `outputs/project_intelligence_graph/*.jsonl`
- `outputs/project_intelligence_graph/*.md`
- `outputs/project_intelligence_graph/views/*.html`

## Standardvertrag für jeden Agenten

1. Vor Aussagen über aktuellen PIG-Zustand:

   ```bash
   python3 scripts/project_intelligence_graph/pig.py full-check
   python3 scripts/project_intelligence_graph/pig.py operator-brief
   ```

2. Danach lesen:

   - `outputs/project_intelligence_graph/operator_brief.md`
   - `outputs/project_intelligence_graph/full_check_report.md`
   - `outputs/project_intelligence_graph/summary.json`
   - `outputs/project_intelligence_graph/operator_decision_inbox.md`
   - `outputs/project_intelligence_graph/automation_risk_registry.md`
   - `outputs/project_intelligence_graph/coverage_manifest.md`
   - `outputs/project_intelligence_graph/policy_gate_report.md`

3. Operator-Entscheidungen nur über State setzen:

   ```bash
   python3 scripts/project_intelligence_graph/pig.py decisions --set ITEM_ID --state accepted --note "reason"
   ```

4. Generierte Reports nicht manuell editieren.

5. Vor nicht-trivialen Fixes oder Härtungen einen Fix-Vertrag anlegen:

   ```bash
   python3 scripts/project_intelligence_graph/pig.py new-fix "short title" --objective "one sentence objective"
   python3 scripts/project_intelligence_graph/pig.py validate-fix
   ```

## Langlauf- / Nightrun-Vertrag

Wenn ein Agent einen Nightrun, Autoloop oder langen Abwesenheitslauf fortsetzt, muss er zusätzlich lesen:

```text
/Users/BjornRosinger/Documents/Obsidian/Test Vaul Privat/Human Overview/Canonical/Rules/Rule - Long Run Completion Discipline.md
```

Nicht nach dem ersten grünen Teilcheck stoppen. Ein grüner PIG-Check ist dann nur ein Checkpoint. Abschluss ist erst erlaubt bei:

- Zeitfensterende,
- echtem Operator-Gate,
- leerem verifiziertem Backlog inklusive Dirt/Verifier/Memory/Handoff,
- oder ausdrücklichem Operator-Stopp.

Heartbeat-/Langlauf-Automationen dürfen nicht gelöscht werden, nur weil ein Block PASS ist.

PIG prüft diese Verdrahtung im Planning-Quality-Gate als `long_run_completion:agent_entrypoint`. Wenn dieser Check WARN meldet, ist ein Agenten-Startpunkt nicht robust genug für unbeaufsichtigte Läufe.

Für Quality-OS-/PIG-/Agent-Ops-Langläufe braucht ein Abschluss oder Checkpoint zusätzlich einen JSON-Report unter `outputs/project_intelligence_graph/long_run_completion_reports/`. `python3 scripts/project_intelligence_graph/pig.py long-run-audit` muss PASS sein, bevor ein Agent Langlauf-Completion behauptet.

## Warum das wichtig ist

Wenn Agenten nur eine Codex-Skill lesen können, ist das System an Codex gebunden. Wenn sie CLI, JSON und Markdown lesen können, bleibt das System provider-neutral.
