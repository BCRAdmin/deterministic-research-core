---
type: project_intelligence_graph_ontology
status: active
updated: 2026-05-22
---

# Project Intelligence Graph Ontology v2

## Zweck

Der `Project Intelligence Graph` ist keine neue Wahrheitsschicht.
Er ist ein lokaler Index über vorhandene Wahrheitsschichten:

- Obsidian / Human Overview
- LIONCOM / Mission Control
- Room16 / Quellwert
- Handoffs, Claims und Evidence-Packs
- Git/CI/Verifier-Artefakte
- Codex- und LaunchAgent-Automationen

Der Graph darf beobachten, verknüpfen, prüfen und anzeigen.
Er darf nicht automatisch Obsidian, Code, Gates oder Runtime-State umschreiben.

## Nodes

| Type | Bedeutung |
| --- | --- |
| `Note` | Markdown-Note im Human-Overview-Vault |
| `Project` | Projektkarte oder stabiler Projektanker |
| `System` | Systemkarte, Runtime oder Tool |
| `Agent` | Vivi, Vega, Operator oder andere Rolle |
| `ApprovalNode` | sichtbares Human-Approval-Gate in Workflow oder Job Card |
| `Archetype` | wiederverwendbarer Zielbild-Archetyp für eine Auftragsart |
| `ArchetypeLibrary` | indexierte Sammlung wiederverwendbarer Archetypen |
| `Feature` | Feature-/Produktbereich |
| `BuildContract` | providerneutraler Bauvertrag für größere Operator-Aufträge |
| `Status` | Statuswert wie `active`, `local_preview`, `parked_no_current_intent` |
| `Category` | Frontmatter-/Tag-/Kategorieanker |
| `Lane` | Agenten- oder Delivery-Lane |
| `Claim` | claimbares Arbeitspaket |
| `EvidencePack` | Belegpaket für einen Claim |
| `Evidence` | generischer Beleganker für Execution History |
| `EvidenceItem` | einzelner Beleg |
| `ExecutionHistory` | aufgezeichneter Workflow-Run-Verlauf |
| `Verifier` | Test, Gate, Script oder Prüflauf |
| `Gate` | Operator-, Public-, Deploy-, Credential- oder Safety-Gate |
| `JobCard` | node-artiger Arbeitsauftrag mit Input, Output, Verifier, Stop- und Retry-Regel |
| `QualityGate` | Gate, das Contracts, Roadmaps, Outputs oder Evidence prüft |
| `Workflow` | Workflow-Form oder Workflow-Run-Archetyp |
| `Output` | durch Job Card oder Workflow erzeugter Output |
| `Improvement` | lokale, projektübergreifende oder systemweite Verbesserung |
| `OperatorSurface` | operatorfreundliche Status- oder Steuerdatenfläche |
| `OperatorAction` | lokale, maschinenlesbare Operator-Entscheidung oder Hold-/Approval-Aktion |
| `Roadmap` | Plan-/Roadmap-Artefakt mit Dual-Lens-Qualitätsanforderungen |
| `Report` | Bericht, Handoff, QA-Report oder Review |
| `RunControl` | Pause-/Resume-/Retry-Steuerinformation für Workflow Runs |
| `SupervisorAudit` | read-only Audit, der Runner-Ausgaben, übersprungene Verifier, Execution History, Gates und Wahrheitsstatus prüft |
| `FreshSessionHandoff` | kompaktes Startpaket für frische Agenten-Sessions |
| `RulePropagationRegistry` | Registry, die systemweite Regeln auf erforderliche Zielpunkte und Verifier mappt |
| `RulePropagationRule` | einzelne systemweite Regel mit Source-Ankern, Impact-Scopes und Propagation-Zielen |
| `ProjectInvariantRegistry` | Registry für Projektinvarianten, Gates, Verifier und Operator-Surfaces |
| `ProjectInvariant` | maschinenlesbare Nicht-kaputtmachen-Wahrheit eines Projekts oder Systems |
| `AgentEntryPointRegistry` | Registry bekannter Agenten-/Skill-Startpunkte |
| `AgentEntryPoint` | Agenten-, Skill- oder Runbook-Einstiegspunkt, der systemweite Regeln tragen muss |
| `OperatorIntentContract` | Vertrag, der ein Operator-Signal in Zielbild, Nicht-Ziele, Gates, Verifier und Propagation übersetzt |
| `Automation` | Codex-Cron, Heartbeat oder LaunchAgent-nahe Job Card |
| `Repository` | lokales oder GitHub-Repo |
| `File` | relevante Quelldatei oder Artefaktdatei |
| `FreshDataSource` | registrierte lokale Quelle für Projekt-, Runtime-, Verifier- oder Datenreife-Artefakte |
| `FreshDataItem` | beobachteter frischer oder historischer Daten-Eingang mit Klassifikation und nächstem sicherem Schritt |
| `RiskClass` | Automation-/Capability-Risikoklasse R1-R5 |
| `Capability` | mutierende oder lesende Fähigkeitsklasse |
| `Workspace` | lokaler Ausführungs-/Projektpfad |
| `UnknownTarget` | beobachteter Link ohne aufgelöstes Ziel |

## Relationships

| Predicate | Bedeutung |
| --- | --- |
| `links_to` | Markdown-WikiLink von Note zu Ziel |
| `mentions_unknown_target` | WikiLink konnte nicht auf eine Note abgebildet werden |
| `asserts_status` | Quelle behauptet Statuswert |
| `has_person` | Frontmatter-Relation zu Person/Agent |
| `has_feature` | Frontmatter-Relation zu Feature |
| `has_system` | Frontmatter-Relation zu System |
| `has_category` | Frontmatter-Relation zu Kategorie/Tag |
| `contains_lane` | Projekt/Handoff enthält Lane |
| `contains_claim` | Lane/Artifact enthält Claim |
| `describes_claim` | Artifact beschreibt Claim |
| `has_evidence_pack` | Claim oder Lane verweist auf Evidence-Pack |
| `validated_by` | Claim/Report wird durch Verifier belegt |
| `blocked_by` | Entity wird durch Gate oder Failure blockiert |
| `supersedes` | neueres Artefakt ersetzt älteres |
| `exposes_surface` | System/Projekt hat App/API/Operator-Surface |
| `runs_automation` | Automation arbeitet für Projekt/System |
| `has_risk_class` | Automation/Fähigkeit ist als R1-R5 klassifiziert |
| `requires_operator_gate` | Entity braucht ein explizites Operator-Gate |
| `propagates_to` | systemweite Regel muss in einem Zielpunkt sichtbar sein |
| `can_mutate` | Automation/Fähigkeit kann lokal oder extern mutieren |
| `runs_in_workspace` | Automation läuft in einem lokalen Workspace |
| `uses` | Build Contract oder Workflow nutzt einen Archetyp |
| `defines` | Build Contract definiert Workflow oder Output-Vertrag |
| `declares_invariant` | Registry deklariert eine Projektinvariante |
| `contains` | Workflow, Library oder Artefakt enthält einen Child-Node |
| `requires` | Job Card oder Workflow braucht Approval Node oder Gate |
| `requires_propagation` | Agenten-Entry-Point verlangt eine bestimmte systemweite Regel |
| `produces` | Job Card oder Workflow erzeugt Output |
| `validates` | Verifier validiert Output oder Contract |
| `checks` | Quality Gate prüft Build Contract, Roadmap oder Output |
| `records` | Workflow Run zeichnet Execution History auf |
| `references` | Execution History oder Artefakt referenziert Evidence |
| `controls` | RunControl oder OperatorSurface steuert einen Workflow Run lokal |
| `hands_off_to` | Handoff übergibt Kontext an Agent, Operator oder System |
| `affects` | Improvement wirkt auf Project, System oder Agent |
| `observes_fresh_data` | Fresh Data Intake beobachtet lokale Projekt-/Runtime-Daten read-only |

## Quality Operating System Beziehungen

Neue Beziehungen für Build Contracts, Workflow Runs, Job Cards und Gates:

```text
BuildContract -> uses -> Archetype
BuildContract -> defines -> Workflow
Workflow -> contains -> JobCard
JobCard -> requires -> ApprovalNode
JobCard -> produces -> Output
Verifier -> validates -> Output
QualityGate -> checks -> BuildContract
WorkflowRun -> records -> ExecutionHistory
ExecutionHistory -> references -> Evidence
OperatorSurface -> contains -> OperatorAction
OperatorAction -> requires -> ApprovalNode
WorkflowRun -> contains -> RunControl
FreshSessionHandoff -> references -> ExecutionHistory
Improvement -> affects -> Project/System/Agent
FreshDataSource -> observes_fresh_data -> FreshDataItem
FreshDataItem -> references -> Evidence
FreshDataItem -> requires_operator_gate -> Gate
Room16ReviewGateStatus -> references -> ManualReviewEntry
Room16ReviewGateStatus -> checks -> VisibilityGate
Room16ReviewGateStatus -> produces -> FreshDataItem
Room16ManualReviewPacket -> references -> Evidence
Room16ManualReviewPacket -> checks -> ManualReviewEntry
Room16ManualReviewPacket -> produces -> FreshDataItem
SupervisorAudit -> checks -> ExecutionHistory
SupervisorAudit -> checks -> JobCard
SupervisorAudit -> checks -> Verifier
SupervisorAudit -> produces -> QualityGate
```

`n8n` bleibt in dieser Ontologie Referenz-Archetyp für sichtbare Workflows, Nodes, Job Cards, Approval Nodes, Execution History, Retry/Pause/Resume und Templates. Es ist keine Runtime-, Credential- oder Cloud-Abhängigkeit.

Quality OS V3 fügt nur lokale Control-Metadaten hinzu: Operator Actions, Run Controls und Fresh-Session-Handoffs. Diese dürfen Status und nächste sichere Schritte anzeigen, aber keine Public-, Production-, Credential-, Money-, Lösch-, externe Kommunikations- oder Room16-Rerun-Aktion ausführen.

## Systemwide Rule Propagation Beziehungen

Neue Beziehungen für den Rückwärtsplan vom Endziel:

```text
ProjectIntelligenceGraph -> checks -> RulePropagationRegistry
RulePropagationRegistry -> contains -> RulePropagationRule
RulePropagationRule -> propagates_to -> AgentEntryPoint/File
AgentEntryPoint -> requires_propagation -> RulePropagationRule
ProjectInvariantRegistry -> declares_invariant -> ProjectInvariant
ProjectIntelligenceGraph -> defines -> OperatorIntentContract
```

Diese Schicht beantwortet künftig automatisch: Wenn Bjorn eine neue Arbeitsregel formuliert, welche Skills, Policies, Projekte, Automationen, Verifier und Operator-Surfaces müssen davon wissen?

## Relationship Record

Jede Kante muss Provenance und Zeitstatus tragen. Das Schema liegt in:

`docs/project-intelligence-graph/RELATIONSHIP_SCHEMA.json`

Node- und Predicate-Regeln liegen in:

- `docs/project-intelligence-graph/NODE_SCHEMA.json`
- `docs/project-intelligence-graph/PREDICATE_REGISTRY.json`
- `docs/project-intelligence-graph/POLICY_RULES.json`

Pflichtfelder:

- `subject`
- `predicate`
- `object`
- `source_path`
- `source_span`
- `source_sha256`
- `observed_at`
- `valid_from`
- `valid_to`
- `confidence`
- `extraction_method`
- `status`

## Status-Regel

- `observed`: Quelle wurde gesehen, aber nicht als Wahrheit promoviert.
- `asserted`: Quelle behauptet etwas explizit.
- `inferred`: Regel hat eine Beziehung abgeleitet.
- `verified`: Beziehung wird durch Verifier/Gate belegt.
- `superseded`: Beziehung wurde durch spätere Quelle ersetzt.
- `contradicted`: Beziehung steht im Widerspruch zu anderer führender Wahrheit.

## Control-Layer-Grenzen

Der Graph scannt lokal und schreibt nur nach:

- `outputs/project_intelligence_graph/nodes.jsonl`
- `outputs/project_intelligence_graph/relationships.jsonl`
- `outputs/project_intelligence_graph/drift_report.md`
- `outputs/project_intelligence_graph/subgraph-lioncom-room16-quellwert.html`
- `outputs/project_intelligence_graph/summary.json`
- `outputs/project_intelligence_graph/automation_risk_registry.md/json`
- `outputs/project_intelligence_graph/operator_decision_inbox.md/json`
- `outputs/project_intelligence_graph/coverage_manifest.md/json`
- `outputs/project_intelligence_graph/policy_gate_report.md/json`

Keine Cloud, kein externer Provider, keine automatische Vault-Änderung.
