# Quellwert Data Maturity Policy

## Zweck

B12 macht Quellwert/Utility/Membership-Datenreife als lokale, prüfbare Evidence-Schicht sichtbar. Der Block ist kein Go für Public, Production, Payment, Auth, externe Analytics, externe Kommunikation, Provider-Aktionen oder Financial-Advice-Publishing.

## Führende Semantik

- `utility_maturity_status=not_mature` ist ein ehrlicher Reifezustand, kein Buildfehler.
- `membership_preview_status=pass` heißt nur: lokale Preview-/Non-Advice-Oberfläche ist prüfbar.
- `launch_readiness_status=WARN` kann korrekt sein, solange Public, Production, Payment, Auth und externe Datenzugriffe geschlossen bleiben.
- B12-Audit `PASS` heißt: die lokalen Datenreife-, Preview- und Gate-Signale sind konsistent und nicht mit Launch-Freigabe verwechselt.

## Harte Gates

Public, Production, Deploy, Payment/Geld, Auth/Credentials, externe Analytics-Zugriffe, Provider-Aktionen, externe Kommunikation, Live-Affiliate-/Ads-Aktivierung, Financial-Advice-Publishing, Delete und irreversible Aktionen bleiben geschlossen.

## Akzeptierte lokale Arbeit

- lokale Datenreife-Pakete regenerieren
- Utility-/Quellwert-/Membership-Evidence zusammenführen
- Review-Fenster, `not_mature`-Status und Gate-Ledger sichtbar machen
- Operator-Handoff vorbereiten, ohne externe Daten abzurufen oder Veröffentlichung auszulösen
