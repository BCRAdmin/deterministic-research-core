# Kanzlei Synthetic Factory Policy

## Zweck

B11 macht Kanzlei AI Assist als synthetische, lokal verifizierbare Test- und Nachweisschiene sichtbar. Der Block ist kein Go für echte Mandantendaten, DATEV, Cloud, Auth, Production oder finale Steuerentscheidungen.

## Führende Semantik

- `verify_all_status=PASS` heißt nur: lokale Struktur-, Schema-, Privacy- und Textqualität ist grün.
- `product_readiness_status=PASS` heißt nur: der lokale MVP ist als Operator-Paket vorbereitet.
- `synthetic_only=true` ist Pflicht, bevor B11 als abgeschlossen gelten darf.
- `operator_gate_required=true` bleibt auch bei PASS bestehen.

## Harte Gates

Push, Delete, Publish, Deploy, Production, Public, Payment, Auth/Credentials, externe Kommunikation, echte Personen-/Mandantendaten, DATEV-Upload, Cloud-/Provider-Verarbeitung, finale Steuerentscheidung und irreversible Aktionen bleiben geschlossen.

## Akzeptierte lokale Arbeit

- synthetische Golden Cases ergänzen oder prüfen
- lokale Kanzlei-Verifier ausführen
- PIG-Evidence und Operator-Handoff aktualisieren
- Widersprüche zwischen lokaler Verifikation und Produkt-/Betriebsreife sichtbar machen
