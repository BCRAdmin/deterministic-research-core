# Sanitized Evidence Capsule Policy

`minimal_review` is the default profile for DreamFactory evidence capsules.

Rules:

- Use `source_id`, relative path, SHA-256 and short structured excerpts.
- Do not copy raw graph files.
- Do not include `scripts/project_intelligence_graph/pig.py` or `full_check_report.json` unless a separate `code_review` profile is explicitly requested.
- Absolute local user paths, secrets, credentials, tunnel URLs and raw runtime data must scan as zero.
- A capsule is internal evidence only; external sharing still requires Operator-Go and provenance/legal review.
