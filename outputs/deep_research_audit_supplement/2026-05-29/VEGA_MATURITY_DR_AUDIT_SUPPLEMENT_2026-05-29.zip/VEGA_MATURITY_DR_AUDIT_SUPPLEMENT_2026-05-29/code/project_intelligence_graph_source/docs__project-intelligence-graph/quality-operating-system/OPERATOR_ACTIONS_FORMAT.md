---
type: operator_action_template
status: active
updated: 2026-05-22
systems:
  - Vega
  - Vivi
  - Project Intelligence Graph
  - LIONCOM
tags:
  - quality-operating-system
  - operator-actions
---

# Operator Actions Format

## Zweck

Operator Actions sind lokale, maschinenlesbare Entscheidungspunkte für Approval Nodes, Hold-Entscheidungen und Run Controls. Sie sind keine Runtime-Automation und keine n8n-Runtime.

## Härtungsanalyse

- Riskante Aktionen bleiben `blocked_operator_gate`, bis der Operator explizit entscheidet.
- Jede Action beschreibt `runtime_effect`, damit UI und Agent nicht aus Versehen Public, Production, Credentials, Geld oder externe Kommunikation öffnen.
- Actions dürfen lokale Statussicht und Handoff verbessern, aber kein geschlossenes Gate ausführen.

## Zielbild-/Archetypanalyse

Archetyp: [[Operator Dashboard / Control Surface]] mit sichtbaren Approval-Buttons als Entscheidungsmodell. Der erste lokale Stand zeigt, was verfügbar, was nur Hold-Record und was hart operator-gated ist.

## Pflichtfelder

### action_id

Stabiler Identifier der Action.

### action_type

`hold`, `approve`, `reject`, `pause`, `resume`, `retry` oder `close`.

### contract

Build-Contract-ID oder Pfad.

### approval_node

Approval Node, Gate oder Run-Control, auf die sich die Action bezieht.

### status

`available_local_record`, `blocked_operator_gate`, `ready_for_future_running_runs`, `metadata_ready_gate_bound` oder `closed_no_action`.

### allowed_when

Wann diese Action sicher ist.

### blocked_when

Wann diese Action stoppen muss.

### evidence

Lokale Artefakte, die den Action-Status belegen.

### verifier

Verifier, der die Action-Struktur prüft.

### audit_trail

Wo spätere Ausführung oder Entscheidung protokolliert werden muss.

### no_runtime_effect

Explizite Aussage, ob die Action in diesem Stand keine Runtime-Wirkung hat.

## Nicht-Ziele

- keine n8n-Runtime
- keine versteckte Approval-Ausführung
- keine Public-/Production-/Credential-/Money-/External-Send-Aktion

## Verifier

- `python3 scripts/project_intelligence_graph/pig.py validate-quality-os`
- `python3 scripts/project_intelligence_graph/pig.py operator-surface`
- `node scripts/verify_planning_quality_surface.mjs`

## Cross-Project-Wirkung

Systemweit: dieselbe Action-Struktur kann später für Vivi, Vega, Codex, Claude Code und andere lokale Agenten genutzt werden.

## Operator-Gates

Alles mit `operator_gate_required=true` bleibt Anzeige- und Handoff-Information, bis Bjorn ein explizites Go gibt.
