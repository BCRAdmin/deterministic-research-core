# Source Registry Policy

## Zweck

B02 macht Quellen zu prüfbaren Objekten. Entscheidungen, Claims, Deep-Research-Pakete und Operator-Flächen sollen nicht nur Pfade nennen, sondern `source_id`, Herkunft, Sensitivität, Frische, Sharing-Status und Zitierregel tragen.

## Regeln

- Jeder neue Evidence-Claim referenziert `source_ids`.
- Excluded Sources bleiben sichtbar, aber mit Ausschlussgrund und Re-Include-Gate.
- Raw Runtime, Secrets, echte Personen-/Mandantendaten, `.git`, Datenbanken und nicht geprüfte Source-Inputs bleiben ausgeschlossen.
- `PASS` im Source-Registry-Audit bedeutet lokale Nachvollziehbarkeit. Es bedeutet nicht externe Redistribution, Lizenzfreigabe, Public Release oder rechtliche Validierung.
- Dritte dürfen nur redigierte Pakete erhalten, wenn Redaction-, Secret-, Leak- und License-Review-Pfade grün oder explizit operator-geprüft sind.

## Führende Artefakte

- `docs/project-intelligence-graph/SOURCE_RECORD_SCHEMA.json`
- `docs/project-intelligence-graph/EVIDENCE_CAPSULE_SCHEMA.json`
- `outputs/project_intelligence_graph/source_registry.json`
- `outputs/project_intelligence_graph/evidence_spine.json`
- `outputs/project_intelligence_graph/source_registry_audit.json`

## Harte Gates

Push, Delete, Publish, Deploy, Public/Production, Payment, Auth/Credentials, externe Kommunikation, echte Personen-/Mandantendaten, Financial-Advice-Publishing, Room16-Rerun und irreversible Aktionen bleiben geschlossen.
