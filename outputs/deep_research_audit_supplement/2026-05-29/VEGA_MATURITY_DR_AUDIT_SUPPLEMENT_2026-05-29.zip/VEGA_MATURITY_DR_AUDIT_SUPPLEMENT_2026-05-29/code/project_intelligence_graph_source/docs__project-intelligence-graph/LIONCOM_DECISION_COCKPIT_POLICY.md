# LIONCOM Decision Cockpit Policy

B08 macht LIONCOM zur lokalen Entscheidungsoberfläche für Mission, Evidenz, Widersprüche, Gates, Produkt-Rails und Worker-Aktionen.

## Harte Grenzen

- Das Cockpit ist read-only gegenüber Runtime-, Remote-, Credential-, Public-, Deploy-, Payment- und External-Communication-Flächen.
- Jede Karte muss Source, Evidence, Gate und Verifier sichtbar tragen.
- Status wird in Achsen getrennt: `local_ready`, `activation_ready`, `public_ready`, `production_ready`, `externally_validated`.
- `PASS` darf nicht als Public-, Production- oder External-Ready interpretiert werden.
- OpenJarvis/Jarvis ist für diesen Block out of scope und darf nicht als Decision-Cockpit-Wahrheit erscheinen.

## Erlaubte lokale Arbeit

- PIG-Evidence lesen und zu Decision Cards verdichten.
- Lokale UI-/API-Surfaces im Mirror bauen, die diese Evidence anzeigen.
- Deterministische lokale Verifier ausführen.
- Operator-Handoffs und Memory-Learnings schreiben.

## Nicht erlaubt ohne neues Go

- Remote Bridge scharf schalten.
- Telegram-, GitHub- oder andere Credentials aktivieren.
- GitHub write sync, Push, Public Deployment, Production Deployment, Payment, Auth oder externe Kommunikation starten.
- Room16-Rerun oder Sichtbarkeitswechsel auslösen.
