# Capability Registry Policy

Status: active

Purpose: keep Vega, Vivi and LIONCOM expandable without creating agent-name bloat.

## Core Rule

New named work modes start as capabilities, gates, benchmarks, sandboxes or review modes. They become agents only after the Agentization Decision Gate proves a recurring lifecycle:

```text
Trigger -> Job Card -> Work -> Artifact -> Verifier -> Handoff -> Memory
```

## Required Fields

Every record needs:

- `canonical_name`
- `aliases`
- `type`
- `source_repo_or_rule`
- `is`
- `is_not`
- `trigger`
- `when_not_to_use`
- `allowed_actions`
- `forbidden_actions`
- `evidence_note`
- `verifier`
- `fresh_session_budget`
- `agentization_status`

## Safety Defaults

- `is_agent` is false unless a later explicit canonical decision approves it.
- `runtime_action_executed`, `external_action_executed` and `irreversible_action_executed` stay false for registry generation and audits.
- Shannon is always `Shannon Security Sandbox`, never a general security agent.
- Design, motion and taste remain gates/review modes until telemetry proves a real recurring worker lifecycle.

## Fresh Session Budget

Default read order:

```text
VEGA_START_HERE -> Decision - Thin Roles Thick Rails -> capability_registry.json -> relevant detail note
```

If a capability needs more than four core notes to be understood, create or update an overview note instead of pushing every source into a fresh session.

## Operator Surface

LION should display capabilities as rails:

- active
- watch
- sandbox
- blocked
- agent_candidate

It must not imply that a capability is an agent unless `agentization_status` is `agent_approved`.
