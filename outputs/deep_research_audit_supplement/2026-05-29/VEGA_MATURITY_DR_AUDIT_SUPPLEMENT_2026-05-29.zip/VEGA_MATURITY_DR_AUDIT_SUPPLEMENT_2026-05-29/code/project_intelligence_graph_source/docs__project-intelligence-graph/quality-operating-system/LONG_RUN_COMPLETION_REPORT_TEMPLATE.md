# Long Run Completion Report Template

Use this for every Nightrun, Autoloop, Nachtrun, heartbeat-backed run, or long unattended operator run.

This is not a chat summary. It is the evidence bundle that makes a completion claim auditable.

## Required JSON Fields

- `schema_version`
- `report_id`
- `created_at`
- `run_scope`
- `completion_state`
- `core_request_checked`
- `backlog_checked`
- `dirt_checked`
- `verifiers_run`
- `memory_capture`
- `handoff_updated`
- `entrypoints_checked`
- `heartbeat_or_automation_state`
- `operator_gates`
- `next_safe_step`

## Completion States

- `running`: work continues.
- `checkpoint_verified`: a block is green, but the whole long run is not done.
- `operator_gate_reached`: the next meaningful step needs Bjorn.
- `time_window_exhausted`: the agreed unattended window is used up.
- `closed_verified_no_safe_work`: core work, backlog, dirt, verifiers, memory and handoff are checked; no safe local work remains.
- `stopped_by_operator`: Bjorn explicitly stopped the run.

## Hard Rule

Do not mark a run complete after the first green partial check.

Do not delete or pause a heartbeat/long-run automation merely because one verifier passed.

## Minimal JSON Example

```json
{
  "schema_version": 1,
  "report_id": "YYYYMMDD-long-run-example",
  "created_at": "YYYY-MM-DDTHH:MM:SSZ",
  "run_scope": "Local-only Vega long run for Quality OS / PIG / LIONCOM / project systems.",
  "completion_state": "checkpoint_verified",
  "core_request_checked": {
    "status": "partial",
    "evidence": []
  },
  "backlog_checked": {
    "status": "checked",
    "evidence": []
  },
  "dirt_checked": {
    "status": "checked",
    "evidence": []
  },
  "verifiers_run": [
    {
      "command": "python3 scripts/project_intelligence_graph/pig.py full-check",
      "status": "PASS"
    }
  ],
  "memory_capture": {
    "status": "updated",
    "paths": []
  },
  "handoff_updated": {
    "status": "updated",
    "paths": []
  },
  "entrypoints_checked": {
    "status": "PASS",
    "evidence": "planning-quality long_run_completion items"
  },
  "heartbeat_or_automation_state": {
    "status": "active_or_gated",
    "automation_id": ""
  },
  "operator_gates": [],
  "next_safe_step": "Continue local reversible work or report a real Operator Gate."
}
```

## PIG Verification

PIG scans long-run reports under:

```text
outputs/project_intelligence_graph/long_run_completion_reports/
```

Run:

```bash
python3 scripts/project_intelligence_graph/pig.py full-check
python3 scripts/project_intelligence_graph/pig.py long-run-audit
```
