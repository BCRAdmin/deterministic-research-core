---
type: job_card_template
status: active
updated: 2026-05-22
systems:
  - Vega
  - Vivi
  - Project Intelligence Graph
tags:
  - quality-operating-system
  - job-card
  - node-model
---

# Job Card Template Nach Node-Modell

## Zweck

Eine Job Card ist ein kleiner, node-artiger Auftrag, den auch schwache LLMs ausführen können, ohne Scope zu raten. Sie ist providerneutral und kann von Codex, Claude Code, Vivi, Vega oder anderen lokalen Agenten gelesen werden.

## Statuswerte

- `ready`
- `running`
- `waiting_for_operator`
- `waiting_for_evidence`
- `retry_allowed`
- `failed_safe`
- `completed_verified`
- `closed_no_action`

## Pflichtfelder

### Auftrag

Ein Satz, was erledigt werden soll.

### Zielbild

Was sieht oder bekommt der Operator nach erfolgreicher Ausführung?

### Input

Dateien, Artefakte, Daten, Kontextpakete oder Entscheidungen, die der Node lesen darf.

### erlaubte Aktion

Konkrete erlaubte lokale Aktionen.

### verbotene Aktion

Public, Production, Geld, Credentials/Auth, Löschung, externe Kommunikation, irreversible Zusagen und alle projektspezifischen Stopps.

### Output-Vertrag

Welche Dateien, Reports, JSON-Felder, UI-Zustände oder Belege müssen erzeugt werden?

### relevante Dateien/Artefakte

Liste der Zielpfade und Belegpfade.

### Evidence

Welche Belege muss der Node sammeln oder referenzieren?

### Verifier

Welche Kommandos, Scanner oder manuellen Checks müssen laufen?

### Stop-Regel

Wann muss der Node stoppen, statt weiter zu improvisieren?

### Retry-Regel

Wann ist Retry erlaubt, wie oft, und was muss sich vor dem Retry geändert haben?

### Status

Einer der Statuswerte aus diesem Template.

### nächster sicherer Schritt

Der kleinste sinnvolle Folgeschritt, wenn der Node erfolgreich ist oder sicher stoppt.

### Übergabe an Vega/PIG/Operator

Wer prüft, wer entscheidet, und welche PIG-/Memory-Ausgabe wird aktualisiert?

## Minimalbeispiel

```yaml
auftrag: "Pruefe eine Build-Contract-Datei"
zielbild: "Vega sieht sofort, ob Zielbild, Archetyp, Nicht-Ziele, Gates und Verifier fehlen."
input:
  - "docs/project-intelligence-graph/quality-operating-system/BUILD_CONTRACT_TEMPLATE.md"
erlaubte_aktion:
  - "lokal lesen"
  - "contract_quality_gate regenerieren"
verbotene_aktion:
  - "generated reports manuell gruen schreiben"
  - "Operator-Gates abschwaechen"
output_vertrag:
  - "outputs/project_intelligence_graph/contract_quality_gate.json"
evidence:
  - "fehlende Pflichtfelder oder PASS"
verifier:
  - "python3 scripts/project_intelligence_graph/pig.py full-check"
stop_regel: "Stoppe bei unlesbarer Struktur oder riskanter Aktion."
retry_regel: "Ein Retry ist erlaubt, wenn nur lokale Felder fehlen und keine Operator-Gates beruehrt werden."
status: "ready"
naechster_sicherer_schritt: "Fehlende Pflichtfelder im Contract ergaenzen oder Gate sichtbar machen."
uebergabe_an_vega_pig_operator: "PIG schreibt Gate-Report; Vega prueft; Operator entscheidet nur echte Approval Nodes."
```
