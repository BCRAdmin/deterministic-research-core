---
type: build_contract_template
status: active
updated: 2026-05-22
systems:
  - Vega
  - Vivi
  - Project Intelligence Graph
tags:
  - quality-operating-system
  - build-contract
  - dual-lens
---

# Build Contract Template

## Zweck

Dieses Template übersetzt größere Operator-Aufträge in einen lokalen, provider- und agentenneutralen Bauvertrag. Es ist kein Chat-Protokoll und keine Runtime-Abhängigkeit.

n8n darf in Build Contracts nur als Archetyp oder Vorlage auftauchen, nicht als Runtime-Abhängigkeit.

## Statuswerte

- `ready_to_build`
- `needs_target_picture`
- `needs_operator_gate`
- `blocked_by_missing_evidence`
- `defer_no_real_improvement`
- `completed_verified`
- `closed_no_action`

## Pflichtfelder

### operator_goal

Was will der Operator sichtbar erreichen?

### target_picture

Was soll der Operator später sehen, bedienen, prüfen oder entscheiden können?

### archetype

Welcher Archetyp aus der Archetype Library wird genutzt?

### workflow_shape

Node-artige Struktur: Trigger, Build Contract, Job Cards, Verifier, Approval Nodes, Memory Capture, Abschluss.

### scope

Welche Dateien, Projekte, Systeme und Outputs dürfen betroffen sein?

### non_goals

Was wird bewusst nicht gebaut, nicht geändert oder nicht entschieden?

### allowed_actions

Welche lokalen Aktionen sind ohne weiteres Operator-Go erlaubt?

### approval_nodes

Welche Human-Approval-Gates existieren? Mindestens markieren: Public, Production, Geld, Credentials/Auth, Löschung, externe Kommunikation, finale fachliche Ausgabe.

### hard_gates

Welche Gates stoppen den Lauf hart?

### outputs

Welche Artefakte müssen am Ende existieren?

### verifiers

Welche Checks beweisen Erfolg oder stoppen den Abschluss?

### execution_history_required

`true` für größere oder wiederverwendbare Läufe. Der Lauf darf nicht nur im Chat existieren.

### cross_project_effect

`local`, `project`, `cross_project` oder `systemwide`, plus Ziel für Memory, Rule, Skill, Verifier, PIG oder Operator-Surface.

### memory_capture_required

`true` wenn neue Regeln, Entscheidungen, Learnings, Fixes, Strukturen oder Project Seeds entstehen.

### status

Einer der Statuswerte aus diesem Template.

## Dual-Lens Pflichtblock

### Härtungsanalyse

- Welche bestehenden Gates, Verifier, PIG-Checks, Safe-Work-Regeln und Memory-Regeln werden wiederverwendet?
- Welche neue Härtung ist nötig?
- Was darf nicht kaputtgehen?

### Zielbild-/Archetypanalyse

- Welche konkrete Operator-Sicht entsteht?
- Welche Vorlage oder Referenz beschreibt das Ziel?
- Welche erste sichtbare Lieferung beweist Fortschritt?

## No-Build Regeln

- `defer_no_real_improvement`, wenn die Änderung nur Doku, Komplexität oder kosmetische Ordnung erzeugt.
- `needs_target_picture`, wenn das sichtbare Zielbild nicht belastbar ist.
- `needs_operator_gate`, wenn Public, Production, Geld, Credentials/Auth, Löschung, externe Kommunikation oder irreversible Zusagen berührt werden.
- `blocked_by_missing_evidence`, wenn Erfolg ohne lokale Belege nicht prüfbar ist.

## Minimalbeispiel

```yaml
operator_goal: "Quality Operating System weiterbauen"
target_picture: "Operator sieht aktive Contracts, offene Zielbildfragen, Approval Nodes, Workflow Runs und naechsten sicheren Schritt."
archetype: "n8n-inspired Workflow Run"
workflow_shape:
  - trigger: "operator_prompt"
  - contract: "build_contract"
  - job_cards: ["template", "scanner", "memory"]
  - approval_nodes: ["public_release_gate"]
  - verifiers: ["pig_full_check", "contract_quality_gate"]
scope:
  allowed_paths:
    - "docs/project-intelligence-graph/"
    - "scripts/project_intelligence_graph/"
    - "Human Overview/DreamFactory System/Agent Stack/"
non_goals:
  - "n8n als Runtime einfuehren"
  - "Public/Production aendern"
allowed_actions:
  - "lokale Markdown-/JSON-/Python-Aenderungen"
approval_nodes:
  - id: "public_release_gate"
    status: "not_required_for_local_build"
hard_gates:
  - "keine Credentials/Auth-Aenderung"
outputs:
  - "Build Contract Template"
  - "Archetype Library V1"
  - "Job Card Template"
  - "Execution History Format"
verifiers:
  - "python3 scripts/project_intelligence_graph/pig.py full-check"
execution_history_required: true
cross_project_effect: "systemwide"
memory_capture_required: true
status: "ready_to_build"
```
