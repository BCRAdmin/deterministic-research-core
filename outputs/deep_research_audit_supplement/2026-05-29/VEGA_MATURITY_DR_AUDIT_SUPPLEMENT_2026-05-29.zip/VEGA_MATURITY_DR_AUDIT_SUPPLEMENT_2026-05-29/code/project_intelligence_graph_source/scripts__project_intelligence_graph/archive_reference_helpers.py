"""Archive reference helpers for PIG shareable bundles."""

from __future__ import annotations

import hashlib
import zipfile
from pathlib import Path
from typing import Any


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_for_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def member_name_for_source(relative_path: str) -> str:
    return f"files/{relative_path.strip('/')}"


def zip_member_index(archive_path: Path) -> dict[str, dict[str, Any]]:
    if not archive_path.exists():
        return {}
    index: dict[str, dict[str, Any]] = {}
    with zipfile.ZipFile(archive_path) as archive:
        for info in archive.infolist():
            data = archive.read(info.filename)
            index[info.filename] = {
                "name": info.filename,
                "bytes": len(data),
                "compressed_bytes": info.compress_size,
                "sha256": sha256_bytes(data),
            }
    return index


def zip_stats(archive_path: Path) -> dict[str, Any]:
    index = zip_member_index(archive_path)
    return {
        "archive_path": str(archive_path),
        "archive_exists": archive_path.exists(),
        "archive_bytes": archive_path.stat().st_size if archive_path.exists() else 0,
        "archive_sha256": sha256_for_path(archive_path) if archive_path.exists() else "",
        "member_count": len(index),
        "uncompressed_bytes": sum(row["bytes"] for row in index.values()),
        "top_members": sorted(index.values(), key=lambda row: row["bytes"], reverse=True)[:12],
    }


def resolve_capsule_sources(
    *,
    workspace: Path,
    archive_path: Path,
    capsule_sources: list[dict[str, Any]],
) -> dict[str, Any]:
    members = zip_member_index(archive_path)
    rows: list[dict[str, Any]] = []
    missing: list[str] = []
    sha_mismatches: list[str] = []

    for source in capsule_sources:
        relative_path = str(source.get("relative_path", ""))
        expected_sha = str(source.get("sha256", ""))
        included = bool(source.get("included_in_archive", True))
        expected_member = member_name_for_source(relative_path)
        member = members.get(expected_member)
        workspace_path = workspace / relative_path
        workspace_sha = sha256_for_path(workspace_path) if workspace_path.exists() and workspace_path.is_file() else ""
        final_member_present = member is not None
        final_sha_match = bool(member and expected_sha and member.get("sha256") == expected_sha)
        workspace_sha_match = bool(workspace_sha and expected_sha and workspace_sha == expected_sha)

        if included and not final_member_present:
            missing.append(relative_path)
        if included and final_member_present and not final_sha_match:
            sha_mismatches.append(relative_path)

        status = "PASS" if (not included or (final_member_present and final_sha_match)) else "FAIL"
        resolution = "final_archive_member" if status == "PASS" and included else "external_or_excluded"
        if status != "PASS":
            resolution = "workspace_only" if workspace_sha_match else "missing_or_sha_mismatch"

        rows.append({
            "relative_path": relative_path,
            "expected_member": expected_member,
            "included_in_archive": included,
            "status": status,
            "resolution": resolution,
            "expected_sha256": expected_sha,
            "archive_member_sha256": member.get("sha256", "") if member else "",
            "workspace_sha256": workspace_sha,
            "final_archive_member_present": final_member_present,
            "final_archive_sha_match": final_sha_match,
            "workspace_sha_match": workspace_sha_match,
            "bytes": int(source.get("bytes", member.get("bytes", 0) if member else 0) or 0),
        })

    return {
        "archive": zip_stats(archive_path),
        "audited_source_count": len(capsule_sources),
        "archive_member_count": len(members),
        "missing_final_archive_member_count": len(missing),
        "sha_mismatch_count": len(sha_mismatches),
        "missing_final_archive_members": missing,
        "sha_mismatches": sha_mismatches,
        "source_resolution": rows,
    }
