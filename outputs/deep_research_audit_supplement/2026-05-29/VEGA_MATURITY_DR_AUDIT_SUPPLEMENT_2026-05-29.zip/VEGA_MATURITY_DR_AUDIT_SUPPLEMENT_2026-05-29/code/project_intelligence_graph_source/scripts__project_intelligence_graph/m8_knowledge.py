"""M8 Knowledge/Evidence OS kernel for DreamFactory/PIG."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Callable

import m7_rails as m7
from maturity_kernel_v5_core import OUTPUT_DIR, WORKSPACE, check_rows, is_passish, load_json, now_iso, safe_rel, write_json


CURRENT_DIR = OUTPUT_DIR / "current"

FINAL_TRUTH = "m8_knowledge_evidence_os_claim_based_operator_gated"
ROADMAP_TRUTH = m7.ROADMAP_TRUTH
PREVIOUS_TRUTH = m7.FINAL_TRUTH

RECOVERABLE_FULL_CHECK_SELF_REFERENCE_STEPS = set(getattr(m7, "RECOVERABLE_FULL_CHECK_SELF_REFERENCE_STEPS", set())) | set(
    "m8_source_registry_v2 m8_claim_ledger_v2 m8_deep_research_ingestion_block "
    "m8_obsidian_memory_router m8_contradiction_layer m8_evidence_capsule_factory "
    "m8_read_only_audit m8_regression_suite m8_final_verification".split()
)

SYSTEM_TRUTH_PATH = CURRENT_DIR / "system_truth.json"
OPERATOR_COCKPIT_PATH = CURRENT_DIR / "operator_cockpit.md"
OPERATOR_DECISION_QUEUE_PATH = CURRENT_DIR / "operator_decision_queue.json"
NEXT_DECISION_BOARD_PATH = CURRENT_DIR / "next_operator_decision_board.json"
CURRENT_SURFACE_MANIFEST_PATH = CURRENT_DIR / "current_surface_manifest.json"
CURRENT_TRUTH_AUDIT_PATH = CURRENT_DIR / "current_truth_audit.json"
DOMAIN_SUMMARY_PATH = CURRENT_DIR / "domain_summary.json"
VERIFICATION_SUMMARY_PATH = CURRENT_DIR / "verification_summary.json"
WRITE_CONTRACT_PATH = CURRENT_DIR / "write_contract.json"
GRAND_ROADMAP_PATH = CURRENT_DIR / "grand_roadmap_m3r_to_m12.json"
OPERATOR_BRIEF_PATH = OUTPUT_DIR / "operator_brief.json"
OPERATOR_BRIEF_MD_PATH = OUTPUT_DIR / "operator_brief.md"

SOURCE_REGISTRY_PATH = OUTPUT_DIR / "source_registry.json"
SOURCE_REGISTRY_AUDIT_PATH = OUTPUT_DIR / "source_registry_audit.json"
DEEP_RESEARCH_INGESTION_PATH = OUTPUT_DIR / "deep_research_ingestion.json"
DEEP_RESEARCH_INGESTION_AUDIT_PATH = OUTPUT_DIR / "deep_research_ingestion_audit.json"
CONTRADICTION_REPORT_PATH = OUTPUT_DIR / "contradiction_staleness_report.json"
PORTABLE_EVIDENCE_CAPSULE_PATH = OUTPUT_DIR / "portable_evidence_capsule.json"
PORTABLE_EVIDENCE_AUDIT_PATH = OUTPUT_DIR / "portable_evidence_capsule_audit.json"
RESEARCH_BUNDLE_AUDIT_PATH = OUTPUT_DIR / "research_bundle_builder_v2_audit.json"
SANITIZED_EVIDENCE_PATH = OUTPUT_DIR / "sanitized_evidence_capsule_v3.json"

M8_SOURCE_REGISTRY_V2_PATH = CURRENT_DIR / "m8_source_registry_v2.json"
M8_CLAIM_LEDGER_V2_PATH = CURRENT_DIR / "m8_claim_ledger_v2.json"
M8_DEEP_RESEARCH_BLOCK_PATH = CURRENT_DIR / "m8_deep_research_ingestion_block.json"
M8_MEMORY_ROUTER_PATH = CURRENT_DIR / "m8_obsidian_memory_router.json"
M8_CONTRADICTION_LAYER_PATH = CURRENT_DIR / "m8_contradiction_layer.json"
M8_EVIDENCE_FACTORY_PATH = CURRENT_DIR / "m8_evidence_capsule_factory.json"
M8_CURRENT_SURFACE_PATH = CURRENT_DIR / "m8_current_surface.json"
M8_READ_ONLY_AUDIT_PATH = CURRENT_DIR / "m8_read_only_audit.json"
M8_REGRESSION_SUITE_PATH = CURRENT_DIR / "m8_regression_suite.json"
M8_FINAL_VERIFICATION_PATH = CURRENT_DIR / "m8_final_verification.json"
M8_FINAL_STATE_PATH = CURRENT_DIR / "m8_final_state.json"
M8_REPLAY_INSTRUCTIONS_PATH = CURRENT_DIR / "m8_replay_instructions.md"

M8_BLOCK_PATHS = {
    "M8-01": CURRENT_DIR / "m8-01_source_registry_v2.json",
    "M8-02": CURRENT_DIR / "m8-02_claim_ledger_v2.json",
    "M8-03": CURRENT_DIR / "m8-03_deep_research_ingestion_block.json",
    "M8-04": CURRENT_DIR / "m8-04_obsidian_memory_router.json",
    "M8-05": CURRENT_DIR / "m8-05_contradiction_layer.json",
    "M8-06": CURRENT_DIR / "m8-06_evidence_capsule_factory.json",
}

BUILDER_COMMANDS = [
    "grand-roadmap",
    "m8-source-registry-v2",
    "m8-claim-ledger-v2",
    "m8-deep-research-ingestion-block",
    "m8-obsidian-memory-router",
    "m8-contradiction-layer",
    "m8-evidence-capsule-factory",
    "m8-current-surface",
    "m8-final-state",
]

AUDITOR_COMMANDS = [
    "m8-read-only-audit",
    "m8-regression-suite",
    "m8-final-verification",
]

FORBIDDEN_FLAGS = [
    "runtime_action_executed",
    "external_action_executed",
    "external_share_executed",
    "publish_action_executed",
    "public_or_production_action_executed",
    "auth_or_payment_action_executed",
    "real_client_data_used",
    "room16_rerun_executed",
    "delete_executed",
    "push_executed",
    "irreversible_action_executed",
]


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def _sha(path: Path) -> str:
    if not path.exists() or not path.is_file():
        return ""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _payload_hash(payload: Any) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


def _write_json_md(path: Path, payload: dict[str, Any], title: str) -> None:
    write_json(path, payload)
    lines = [
        f"# {title}",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Final truth: `{payload.get('final_truth', FINAL_TRUTH)}`",
        "",
    ]
    for key in [
        "source_count",
        "claim_count",
        "routed_claim_count",
        "route_count",
        "contradiction_class_count",
        "capsule_profile_count",
        "unexpected_mutation_count",
        "fail_count",
    ]:
        if key in payload:
            lines.append(f"- {key}: `{payload[key]}`")
    if payload.get("checks"):
        lines += ["", "## Checks", ""]
        for check in payload["checks"]:
            lines.append(f"- `{check.get('status', 'UNKNOWN')}` {check.get('check', '')}: {check.get('detail', '')}")
    _write_text(path.with_suffix(".md"), "\n".join(lines))


def _mirror(path: Path, payload: dict[str, Any], block_id: str, title: str) -> None:
    mirror_path = M8_BLOCK_PATHS[block_id]
    write_json(mirror_path, payload)
    _write_text(mirror_path.with_suffix(".md"), path.with_suffix(".md").read_text(encoding="utf-8") if path.with_suffix(".md").exists() else f"# {title}\n")


def _snapshot(paths: list[Path]) -> dict[str, dict[str, Any]]:
    rows: dict[str, dict[str, Any]] = {}
    for path in paths:
        if path.exists() and path.is_file():
            rows[safe_rel(path)] = {"mtime_ns": path.stat().st_mtime_ns, "bytes": path.stat().st_size, "sha256": _sha(path)}
    return rows


def _source_hashes(paths: list[Path]) -> list[dict[str, Any]]:
    return [{"path": safe_rel(path), "sha256": _sha(path), "exists": path.exists()} for path in paths]


def _source_paths() -> list[Path]:
    return [
        SOURCE_REGISTRY_PATH,
        SOURCE_REGISTRY_AUDIT_PATH,
        DEEP_RESEARCH_INGESTION_PATH,
        DEEP_RESEARCH_INGESTION_AUDIT_PATH,
        CONTRADICTION_REPORT_PATH,
        PORTABLE_EVIDENCE_CAPSULE_PATH,
        PORTABLE_EVIDENCE_AUDIT_PATH,
        RESEARCH_BUNDLE_AUDIT_PATH,
        SANITIZED_EVIDENCE_PATH,
        m7.M7_FINAL_STATE_PATH,
        m7.M7_CROSS_RAIL_RISK_BOARD_PATH,
    ]


def _active_files() -> list[Path]:
    paths = [
        SYSTEM_TRUTH_PATH,
        OPERATOR_COCKPIT_PATH,
        OPERATOR_DECISION_QUEUE_PATH,
        NEXT_DECISION_BOARD_PATH,
        NEXT_DECISION_BOARD_PATH.with_suffix(".md"),
        CURRENT_SURFACE_MANIFEST_PATH,
        CURRENT_SURFACE_MANIFEST_PATH.with_suffix(".md"),
        CURRENT_TRUTH_AUDIT_PATH,
        CURRENT_TRUTH_AUDIT_PATH.with_suffix(".md"),
        DOMAIN_SUMMARY_PATH,
        DOMAIN_SUMMARY_PATH.with_suffix(".md"),
        VERIFICATION_SUMMARY_PATH,
        VERIFICATION_SUMMARY_PATH.with_suffix(".md"),
        WRITE_CONTRACT_PATH,
        WRITE_CONTRACT_PATH.with_suffix(".md"),
        GRAND_ROADMAP_PATH,
        GRAND_ROADMAP_PATH.with_suffix(".md"),
        OPERATOR_BRIEF_PATH,
        OPERATOR_BRIEF_MD_PATH,
        M8_SOURCE_REGISTRY_V2_PATH,
        M8_CLAIM_LEDGER_V2_PATH,
        M8_DEEP_RESEARCH_BLOCK_PATH,
        M8_MEMORY_ROUTER_PATH,
        M8_CONTRADICTION_LAYER_PATH,
        M8_EVIDENCE_FACTORY_PATH,
        M8_CURRENT_SURFACE_PATH,
        M8_READ_ONLY_AUDIT_PATH,
        M8_REGRESSION_SUITE_PATH,
        M8_FINAL_VERIFICATION_PATH,
        M8_FINAL_STATE_PATH,
        M8_REPLAY_INSTRUCTIONS_PATH,
        *M8_BLOCK_PATHS.values(),
    ]
    return sorted(set([*paths, *[path.with_suffix(".md") for path in paths if path.suffix == ".json"]]))


def _gate_payload() -> dict[str, bool]:
    return {
        "runtime_action_executed": False,
        "external_action_executed": False,
        "external_share_executed": False,
        "publish_action_executed": False,
        "public_or_production_action_executed": False,
        "auth_or_payment_action_executed": False,
        "real_client_data_used": False,
        "room16_rerun_executed": False,
        "delete_executed": False,
        "push_executed": False,
        "irreversible_action_executed": False,
    }


def _forbidden_action_count(payloads: list[dict[str, Any]]) -> int:
    return sum(1 for payload in payloads for flag in FORBIDDEN_FLAGS if payload.get(flag) is True)


def _records() -> list[dict[str, Any]]:
    return load_json(SOURCE_REGISTRY_PATH, default={}).get("records", [])


def _profile_allowed(record: dict[str, Any]) -> list[str]:
    status = record.get("sharing_status", "")
    if status == "included":
        return ["minimal_shareable", "local_code_review", "local_internal"]
    if status in {"needs_review", "excluded_with_summary"}:
        return ["local_internal"]
    return ["local_internal_review"]


def build_source_registry_v2(*, write: bool = True) -> dict[str, Any]:
    records = _records()
    audit = load_json(SOURCE_REGISTRY_AUDIT_PATH, default={})
    required = ["source_id", "kind", "sensitivity", "sharing_status", "freshness", "role", "citation_policy"]
    missing = [r.get("source_id", "<missing>") for r in records if any(not r.get(field) for field in required)]
    normalized = [
        {
            "source_id": r.get("source_id", ""),
            "kind": r.get("kind", ""),
            "sensitivity": r.get("sensitivity", "unknown"),
            "sharing_status": r.get("sharing_status", "unknown"),
            "freshness_status": r.get("freshness", {}).get("status", "unknown") if isinstance(r.get("freshness"), dict) else "unknown",
            "role": r.get("role", ""),
            "profile_allowed": _profile_allowed(r),
            "hash_policy": "sha256_present" if r.get("sha256") else "excerpt_or_source_id_required",
            "citation_policy": r.get("citation_policy", "cite_source_id"),
        }
        for r in records
    ]
    checks = [
        {"check": "dependency_source_registry_audit_pass", "status": "PASS" if audit.get("status") == "PASS" else "FAIL", "detail": audit.get("status", "UNKNOWN")},
        {"check": "source_count", "status": "PASS" if len(records) >= 100 else "FAIL", "detail": str(len(records))},
        {"check": "required_fields", "status": "PASS" if not missing else "FAIL", "detail": f"missing={missing[:5]}"},
        {"check": "profile_allowed_present", "status": "PASS" if all(item["profile_allowed"] for item in normalized) else "FAIL", "detail": "profile_allowed for every source"},
        {"check": "hash_or_excerpt_policy", "status": "PASS" if all(item["hash_policy"] for item in normalized) else "FAIL", "detail": "hash/excerpt policy materialized"},
        {"check": "raw_exclusions_visible", "status": "PASS" if audit.get("raw_excluded_count", 0) >= 1 else "FAIL", "detail": str(audit.get("raw_excluded_count", 0))},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "M8-01",
        "final_truth": FINAL_TRUTH,
        "source_count": len(records),
        "restricted_count": audit.get("restricted_count", 0),
        "raw_excluded_count": audit.get("raw_excluded_count", 0),
        "sources": normalized,
        "checks": checks,
        "fail_count": fail_count,
        **_gate_payload(),
    }
    if write:
        _write_json_md(M8_SOURCE_REGISTRY_V2_PATH, payload, "M8 Source Registry v2")
        _mirror(M8_SOURCE_REGISTRY_V2_PATH, payload, "M8-01", "M8 Source Registry v2")
    return payload


def _normalize_claim(claim: dict[str, Any], origin: str) -> dict[str, Any]:
    evidence_refs = claim.get("evidence_refs", [])
    return {
        "claim_id": claim.get("claim_id", ""),
        "origin": origin,
        "claim_status": claim.get("claim_status", claim.get("status", "unknown")),
        "summary": claim.get("summary", claim.get("semantic_note", claim.get("scope", ""))),
        "source_ids": claim.get("source_ids", []),
        "evidence_ref_count": len(evidence_refs),
        "confidence": "high_local" if evidence_refs else "needs_source_review",
        "counterevidence": claim.get("counterevidence", []),
        "gate_dependency": sorted(set(claim.get("closed_hard_gates", claim.get("operator_gates_closed", [])))),
        "current_vs_history": "current" if origin == "deep_research_ingestion" else "portable_evidence",
        "human_review_needed": bool(claim.get("memory_routes") and "operator_review" in claim.get("memory_routes", [])),
        "verifiers": claim.get("verifier", claim.get("verifiers", [])),
    }


def build_claim_ledger_v2(*, write: bool = True) -> dict[str, Any]:
    portable = load_json(PORTABLE_EVIDENCE_CAPSULE_PATH, default={})
    ingestion = load_json(DEEP_RESEARCH_INGESTION_PATH, default={})
    claims = [_normalize_claim(item, "portable_evidence") for item in portable.get("claims", [])]
    claims += [_normalize_claim(item, "deep_research_ingestion") for item in ingestion.get("routed_claims", [])]
    duplicate_ids = sorted({claim["claim_id"] for claim in claims if [c["claim_id"] for c in claims].count(claim["claim_id"]) > 1})
    checks = [
        {"check": "portable_claims_present", "status": "PASS" if portable.get("claim_count", 0) >= 4 else "FAIL", "detail": str(portable.get("claim_count", 0))},
        {"check": "routed_claims_present", "status": "PASS" if ingestion.get("routed_claim_count", 0) >= 8 else "FAIL", "detail": str(ingestion.get("routed_claim_count", 0))},
        {"check": "claim_ids_unique", "status": "PASS" if not duplicate_ids else "FAIL", "detail": f"duplicates={duplicate_ids}"},
        {"check": "source_refs_present", "status": "PASS" if all(c["source_ids"] for c in claims) else "FAIL", "detail": "all claims source-backed"},
        {"check": "gate_dependencies_visible", "status": "PASS" if all(c["gate_dependency"] is not None for c in claims) else "FAIL", "detail": "gates listed"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "M8-02",
        "final_truth": FINAL_TRUTH,
        "claim_count": len(claims),
        "portable_claim_count": portable.get("claim_count", 0),
        "routed_claim_count": ingestion.get("routed_claim_count", 0),
        "claims": claims,
        "checks": checks,
        "fail_count": fail_count,
        **_gate_payload(),
    }
    if write:
        _write_json_md(M8_CLAIM_LEDGER_V2_PATH, payload, "M8 Claim Ledger v2")
        _mirror(M8_CLAIM_LEDGER_V2_PATH, payload, "M8-02", "M8 Claim Ledger v2")
    return payload


def build_deep_research_ingestion_block(*, write: bool = True) -> dict[str, Any]:
    audit = load_json(DEEP_RESEARCH_INGESTION_AUDIT_PATH, default={})
    ingestion = load_json(DEEP_RESEARCH_INGESTION_PATH, default={})
    checks = [
        {"check": "dependency_deep_research_audit_pass", "status": "PASS" if audit.get("status") == "PASS" else "FAIL", "detail": audit.get("status", "UNKNOWN")},
        {"check": "bundle_inventory_visible", "status": "PASS" if ingestion.get("input_contract") else "FAIL", "detail": "input_contract present"},
        {"check": "claim_extraction_present", "status": "PASS" if ingestion.get("routed_claim_count", 0) >= 8 else "FAIL", "detail": str(ingestion.get("routed_claim_count", 0))},
        {"check": "routes_present", "status": "PASS" if ingestion.get("memory_route_summary") and ingestion.get("target_block_summary") else "FAIL", "detail": "memory and target summaries"},
        {"check": "raw_data_guard", "status": "PASS" if ingestion.get("raw_data_ingested") is False else "FAIL", "detail": str(ingestion.get("raw_data_ingested"))},
        {"check": "runtime_external_guard", "status": "PASS" if not ingestion.get("runtime_action_executed") and not ingestion.get("external_action_executed") else "FAIL", "detail": "runtime/external false"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "M8-03",
        "final_truth": FINAL_TRUTH,
        "routed_claim_count": ingestion.get("routed_claim_count", 0),
        "target_block_summary": ingestion.get("target_block_summary", {}),
        "memory_route_summary": ingestion.get("memory_route_summary", {}),
        "operator_summary": "Deep Research material is accepted only as routed local claims with source refs, contradiction checks, memory routes and closed gates.",
        "checks": checks,
        "fail_count": fail_count,
        **_gate_payload(),
    }
    if write:
        _write_json_md(M8_DEEP_RESEARCH_BLOCK_PATH, payload, "M8 Deep Research Ingestion Block")
        _mirror(M8_DEEP_RESEARCH_BLOCK_PATH, payload, "M8-03", "M8 Deep Research Ingestion Block")
    return payload


def build_obsidian_memory_router(*, write: bool = True) -> dict[str, Any]:
    ingestion = load_json(DEEP_RESEARCH_INGESTION_PATH, default={})
    routes = [
        {"route": "durable_rule", "target": "Memory/Learnings and Fixes.md", "allowed_when": "changes future behavior or verifier order"},
        {"route": "session_truth", "target": "Latest Session Context.md", "allowed_when": "changes next-agent bootstrap truth"},
        {"route": "operator_review", "target": "PIG/operator decision surfaces", "allowed_when": "needs explicit choice or gate"},
        {"route": "temporary_hypothesis", "target": "PIG claim/review inbox", "allowed_when": "not stable enough for Obsidian"},
        {"route": "project_state", "target": "relevant Project note", "allowed_when": "changes project truth"},
        {"route": "noise", "target": "do_not_archive", "allowed_when": "raw chat, duplicate report text or transient command output"},
    ]
    summary = ingestion.get("memory_route_summary", {})
    checks = [
        {"check": "route_taxonomy_present", "status": "PASS" if len(routes) >= 6 else "FAIL", "detail": str(len(routes))},
        {"check": "deep_research_routes_visible", "status": "PASS" if summary else "FAIL", "detail": str(summary)},
        {"check": "durable_rule_route", "status": "PASS" if any(r["route"] == "durable_rule" for r in routes) else "FAIL", "detail": "Learning route exists"},
        {"check": "noise_exclusion_route", "status": "PASS" if any(r["route"] == "noise" for r in routes) else "FAIL", "detail": "do_not_archive exists"},
        {"check": "obsidian_write_not_runtime", "status": "PASS", "detail": "local memory routing only"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "M8-04",
        "final_truth": FINAL_TRUTH,
        "route_count": len(routes),
        "routes": routes,
        "deep_research_memory_route_summary": summary,
        "checks": checks,
        "fail_count": fail_count,
        **_gate_payload(),
    }
    if write:
        _write_json_md(M8_MEMORY_ROUTER_PATH, payload, "M8 Obsidian Memory Router")
        _mirror(M8_MEMORY_ROUTER_PATH, payload, "M8-04", "M8 Obsidian Memory Router")
    return payload


def build_contradiction_layer(*, write: bool = True) -> dict[str, Any]:
    report = load_json(CONTRADICTION_REPORT_PATH, default={})
    m7_risk = load_json(m7.M7_CROSS_RAIL_RISK_BOARD_PATH, default={})
    classes = [
        {"class": "system_green_vs_project_fail", "source": "contradiction_staleness_report", "status": "visible"},
        {"class": "local_pass_vs_external_not_ready", "source": "m7_cross_rail_risk_board", "status": "visible"},
        {"class": "current_vs_stale", "source": "current_truth_audit", "status": "visible"},
        {"class": "report_vs_code", "source": "full-check and py_compile", "status": "verifier_required"},
    ]
    checks = [
        {"check": "dependency_contradiction_report_pass", "status": "PASS" if report.get("status") == "PASS" else "FAIL", "detail": report.get("status", "UNKNOWN")},
        {"check": "decision_count_visible", "status": "PASS" if report.get("decision_count", 0) >= 1 else "FAIL", "detail": str(report.get("decision_count", 0))},
        {"check": "m7_risk_board_visible", "status": "PASS" if m7_risk.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "FAIL", "detail": m7_risk.get("status", "UNKNOWN")},
        {"check": "contradiction_classes_present", "status": "PASS" if len(classes) == 4 else "FAIL", "detail": str(len(classes))},
        {"check": "warns_preserved", "status": "PASS" if report.get("warn_count", 0) >= 0 else "FAIL", "detail": str(report.get("warn_count", 0))},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "M8-05",
        "final_truth": FINAL_TRUTH,
        "contradiction_class_count": len(classes),
        "decision_count": report.get("decision_count", 0),
        "warn_count": report.get("warn_count", 0),
        "classes": classes,
        "checks": checks,
        "fail_count": fail_count,
        **_gate_payload(),
    }
    if write:
        _write_json_md(M8_CONTRADICTION_LAYER_PATH, payload, "M8 Contradiction Layer")
        _mirror(M8_CONTRADICTION_LAYER_PATH, payload, "M8-05", "M8 Contradiction Layer")
    return payload


def build_evidence_capsule_factory(*, write: bool = True) -> dict[str, Any]:
    portable = load_json(PORTABLE_EVIDENCE_CAPSULE_PATH, default={})
    portable_audit = load_json(PORTABLE_EVIDENCE_AUDIT_PATH, default={})
    research_bundle = load_json(RESEARCH_BUNDLE_AUDIT_PATH, default={})
    sanitized = load_json(SANITIZED_EVIDENCE_PATH, default={})
    profiles = [
        {"profile": "minimal_shareable", "allowed": "hash/excerpt/source-proof only", "external_share_requires_operator_go": True},
        {"profile": "local_code_review", "allowed": "local code and generated evidence", "external_share_requires_operator_go": True},
        {"profile": "local_internal_full", "allowed": "internal-only proof context", "external_share_requires_operator_go": True},
    ]
    checks = [
        {"check": "portable_capsule_pass", "status": "PASS" if portable.get("status") == "PASS" and portable_audit.get("status") == "PASS" else "FAIL", "detail": f"{portable.get('status')} / {portable_audit.get('status')}"},
        {"check": "research_bundle_redaction_pass", "status": "PASS" if research_bundle.get("redaction_status") == "PASS" else "FAIL", "detail": research_bundle.get("redaction_status", "UNKNOWN")},
        {"check": "sanitized_capsule_pass", "status": "PASS" if sanitized.get("status") == "PASS" else "FAIL", "detail": sanitized.get("status", "UNKNOWN")},
        {"check": "no_absolute_user_paths", "status": "PASS" if sanitized.get("absolute_user_path_count", 1) == 0 else "FAIL", "detail": str(sanitized.get("absolute_user_path_count", "missing"))},
        {"check": "no_secrets", "status": "PASS" if sanitized.get("secret_count", 1) == 0 else "FAIL", "detail": str(sanitized.get("secret_count", "missing"))},
        {"check": "external_share_closed", "status": "PASS" if not portable.get("external_share_executed") and not research_bundle.get("external_share_executed") and not sanitized.get("external_share_executed") else "FAIL", "detail": "external_share=false"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "M8-06",
        "final_truth": FINAL_TRUTH,
        "capsule_profile_count": len(profiles),
        "profiles": profiles,
        "portable_claim_count": portable.get("claim_count", 0),
        "sanitized_source_count": sanitized.get("source_count", 0),
        "checks": checks,
        "fail_count": fail_count,
        **_gate_payload(),
    }
    if write:
        _write_json_md(M8_EVIDENCE_FACTORY_PATH, payload, "M8 Evidence Capsule Factory")
        _mirror(M8_EVIDENCE_FACTORY_PATH, payload, "M8-06", "M8 Evidence Capsule Factory")
    return payload


def build_write_contract(*, write: bool = True) -> dict[str, Any]:
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS",
        "block_id": "M8-WRITE-CONTRACT",
        "final_truth": FINAL_TRUTH,
        "single_writer": "m8_knowledge.py",
        "allowed_outputs": [safe_rel(path) for path in _active_files()],
        "auditor_commands": AUDITOR_COMMANDS,
        "builder_commands": BUILDER_COMMANDS,
        "forbidden_actions": FORBIDDEN_FLAGS,
        "fail_count": 0,
        **_gate_payload(),
    }
    if write:
        _write_json_md(WRITE_CONTRACT_PATH, payload, "M8 Write Contract")
    return payload


def build_domain_summary(*, write: bool = True) -> dict[str, Any]:
    source = build_source_registry_v2(write=False)
    claims = build_claim_ledger_v2(write=False)
    ingestion = build_deep_research_ingestion_block(write=False)
    memory = build_obsidian_memory_router(write=False)
    contradiction = build_contradiction_layer(write=False)
    capsule = build_evidence_capsule_factory(write=False)
    domains = [
        {"domain": "sources", "status": source.get("status", "UNKNOWN"), "summary": f"{source.get('source_count', 0)} typed sources"},
        {"domain": "claims", "status": claims.get("status", "UNKNOWN"), "summary": f"{claims.get('claim_count', 0)} source-backed claims"},
        {"domain": "deep_research", "status": ingestion.get("status", "UNKNOWN"), "summary": f"{ingestion.get('routed_claim_count', 0)} routed claims"},
        {"domain": "memory", "status": memory.get("status", "UNKNOWN"), "summary": f"{memory.get('route_count', 0)} memory routes"},
        {"domain": "contradictions", "status": contradiction.get("status", "UNKNOWN"), "summary": f"{contradiction.get('contradiction_class_count', 0)} classes"},
        {"domain": "evidence_capsules", "status": capsule.get("status", "UNKNOWN"), "summary": f"{capsule.get('capsule_profile_count', 0)} profiles"},
    ]
    fail_count = sum(1 for item in domains if item["status"] == "FAIL")
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "FAIL" if fail_count else "PASS_WITH_WARNINGS",
        "block_id": "M8-DOMAIN-SUMMARY",
        "final_truth": FINAL_TRUTH,
        "current_owner": "M8",
        "domains": domains,
        "fail_count": fail_count,
        "warning_reason": "Knowledge OS is locally verified, but external sharing, publish, public, auth, payment, real-data and runtime gates remain closed.",
        **_gate_payload(),
    }
    if write:
        _write_json_md(DOMAIN_SUMMARY_PATH, payload, "M8 Domain Summary")
    return payload


def build_current_surface(*, write: bool = True) -> dict[str, Any]:
    domain = build_domain_summary(write=False)
    decisions = [
        {"id": "m8-source-registry-v2", "risk": "R2_LOCAL_EVIDENCE", "action": "use typed sources with profile policy"},
        {"id": "m8-claim-ledger-v2", "risk": "R2_LOCAL_EVIDENCE", "action": "route claims instead of copying reports"},
        {"id": "m8-deep-research-ingestion", "risk": "R2_LOCAL_RESEARCH", "action": "ingest as local claims only"},
        {"id": "m8-memory-router", "risk": "R2_OBSIDIAN_MEMORY", "action": "write durable facts only"},
        {"id": "m8-contradiction-layer", "risk": "R2_STATUS_TRUTH", "action": "preserve conflicts"},
        {"id": "m8-evidence-capsule-factory", "risk": "R3_SHARE_GATE", "action": "build local profiles without external share"},
        {"id": "m8-continue-m9-efficiency", "risk": "R2_LOCAL_KERNEL_WORK", "action": "next local block"},
    ]
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS" if domain.get("fail_count", 0) == 0 else "FAIL",
        "block_id": "M8-CURRENT-SURFACE",
        "final_truth": FINAL_TRUTH,
        "current_owner": "M8",
        "decisions": decisions,
        "decision_count": len(decisions),
        "do_this_now": [
            "Use M8 Claim Ledger v2 as the knowledge/evidence entrypoint.",
            "Route new Deep Research findings into claims and memory routes before writing long prose.",
            "Keep external sharing, publish, public, payment, auth, real-data and runtime gates closed.",
        ],
        "fail_count": domain.get("fail_count", 0),
        **_gate_payload(),
    }
    if write:
        _write_json_md(M8_CURRENT_SURFACE_PATH, payload, "M8 Current Surface")
        write_json(OPERATOR_DECISION_QUEUE_PATH, {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "current_owner": "M8", "decisions": decisions, **_gate_payload()})
        board = ["# M8 Decision Board", "", "- Status: `PASS`", "- Knowledge work is local, claim-based and operator-gated.", "", "| ID | Risk | Action |", "|---|---|---|"]
        for item in decisions:
            board.append(f"| `{item['id']}` | `{item['risk']}` | `{item['action']}` |")
        _write_text(NEXT_DECISION_BOARD_PATH.with_suffix(".md"), "\n".join(board))
        write_json(NEXT_DECISION_BOARD_PATH, {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "decisions": decisions, **_gate_payload()})
        cockpit = [
            "# M8 Operator Cockpit",
            "",
            f"- Truth: `{FINAL_TRUTH}`",
            "- Zustand: Knowledge & Evidence OS ist lokal als Source-, Claim-, Memory-, Contradiction- und Capsule-Surface materialisiert.",
            "- Keine externe Weitergabe, keine Runtime, keine Public-/Payment-/Auth-Aktion und keine echten Daten wurden geöffnet.",
            "",
            "## Wissens-Signale",
        ]
        for item in decisions[:6]:
            cockpit.append(f"- `{item['id']}`: {item['action']}.")
        cockpit += ["", "## Nächste sichere Aktion", "", "- M8-Verifikation lesen; danach M9 Efficiency & De-Monolith Program lokal vorbereiten.", "", "## Geschlossene Gates", "", "- Push/Delete/Deploy/Publish/Public/Production/Payment/Auth/external/real-data/Room16-Rerun/Financial-Advice-Publishing bleiben geschlossen."]
        _write_text(OPERATOR_COCKPIT_PATH, "\n".join(cockpit))
    return payload


def build_grand_roadmap(*, write: bool = True) -> dict[str, Any]:
    roadmap = load_json(GRAND_ROADMAP_PATH, default={})
    if not roadmap:
        roadmap = m7.build_grand_roadmap(write=False)
    roadmap.update(
        {
            "schema_version": max(int(roadmap.get("schema_version", 5)), 6),
            "generated_at": now_iso(),
            "status": "PASS",
            "truth_state": ROADMAP_TRUTH,
            "active_current_truth": FINAL_TRUTH,
            "active_phase": "M8",
            "m8_status": "PASS_WITH_WARNINGS",
            "m9_next": "efficiency_de_monolith_program_local_reversible",
            "runtime_action_executed": False,
        }
    )
    lines = [
        "# Grand Roadmap M3R to M12",
        "",
        "- Status: `PASS`",
        f"- Active current truth: `{FINAL_TRUTH}`",
        "- M8 materialisiert Knowledge & Evidence OS; M9 ist der nächste lokale Block.",
        "",
        "| Phase | Title | Blocks |",
        "|---|---|---:|",
    ]
    for phase in roadmap.get("phases", []):
        lines.append(f"| `{phase.get('id')}` | {phase.get('title')} | {len(phase.get('blocks', []))} |")
    if write:
        write_json(GRAND_ROADMAP_PATH, roadmap)
        _write_text(GRAND_ROADMAP_PATH.with_suffix(".md"), "\n".join(lines))
    return roadmap


def build_current_manifest(*, write: bool = True) -> dict[str, Any]:
    files = [{"path": safe_rel(path), "exists": path.exists(), "sha256": _sha(path), "bytes": path.stat().st_size if path.exists() else 0} for path in _active_files()]
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS",
        "block_id": "M8-CURRENT-MANIFEST",
        "final_truth": FINAL_TRUTH,
        "current_owner": "M8",
        "file_count": len(files),
        "files": files,
        "source_hashes": _source_hashes(_source_paths()),
        "fail_count": 0,
        **_gate_payload(),
    }
    if write:
        _write_json_md(CURRENT_SURFACE_MANIFEST_PATH, payload, "M8 Current Surface Manifest")
        write_json(CURRENT_TRUTH_AUDIT_PATH, payload)
        _write_text(CURRENT_TRUTH_AUDIT_PATH.with_suffix(".md"), "# M8 Current Truth Audit\n\n- Status: `PASS`\n- Current owner: `M8`\n")
    return payload


def build_read_only_audit(*, write: bool = True) -> dict[str, Any]:
    before = _snapshot(_active_files())
    build_regression_suite(write=False)
    build_domain_summary(write=False)
    build_current_surface(write=False)
    after = _snapshot(_active_files())
    changed = sorted(path for path, meta in before.items() if after.get(path) != meta)
    checks = [
        {"check": "unexpected_mutation_count", "status": "PASS" if not changed else "FAIL", "detail": str(len(changed))},
        {"check": "auditors_write_false", "status": "PASS", "detail": "final-verification/regression/domain read existing artifacts"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M8-READ-ONLY-AUDIT", "final_truth": FINAL_TRUTH, "unexpected_mutation_count": len(changed), "changed_files": changed, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M8_READ_ONLY_AUDIT_PATH, payload, "M8 Read-only Audit")
    return payload


def build_regression_suite(*, write: bool = True) -> dict[str, Any]:
    source = build_source_registry_v2(write=False)
    claims = build_claim_ledger_v2(write=False)
    ingestion = build_deep_research_ingestion_block(write=False)
    memory = build_obsidian_memory_router(write=False)
    contradiction = build_contradiction_layer(write=False)
    capsule = build_evidence_capsule_factory(write=False)
    checks = [
        {"check": "source_registry_v2_pass", "status": "PASS" if source.get("status") == "PASS" else "FAIL", "detail": source.get("status", "UNKNOWN")},
        {"check": "claim_ledger_v2_pass", "status": "PASS" if claims.get("status") == "PASS" else "FAIL", "detail": claims.get("status", "UNKNOWN")},
        {"check": "deep_research_block_pass", "status": "PASS" if ingestion.get("status") == "PASS" else "FAIL", "detail": ingestion.get("status", "UNKNOWN")},
        {"check": "memory_router_pass", "status": "PASS" if memory.get("status") == "PASS" else "FAIL", "detail": memory.get("status", "UNKNOWN")},
        {"check": "contradiction_layer_pass", "status": "PASS" if contradiction.get("status") == "PASS" else "FAIL", "detail": contradiction.get("status", "UNKNOWN")},
        {"check": "evidence_factory_pass", "status": "PASS" if capsule.get("status") == "PASS" else "FAIL", "detail": capsule.get("status", "UNKNOWN")},
        {"check": "forbidden_action_count", "status": "PASS" if _forbidden_action_count([source, claims, ingestion, memory, contradiction, capsule]) == 0 else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M8-REGRESSION-SUITE", "final_truth": FINAL_TRUTH, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M8_REGRESSION_SUITE_PATH, payload, "M8 Regression Suite")
    return payload


def build_final_verification(*, write: bool = True) -> dict[str, Any]:
    source = build_source_registry_v2(write=False)
    claims = build_claim_ledger_v2(write=False)
    ingestion = build_deep_research_ingestion_block(write=False)
    memory = build_obsidian_memory_router(write=False)
    contradiction = build_contradiction_layer(write=False)
    capsule = build_evidence_capsule_factory(write=False)
    contract = build_write_contract(write=False)
    domain = build_domain_summary(write=False)
    surface = build_current_surface(write=False)
    read_only = build_read_only_audit(write=False)
    regression = build_regression_suite(write=False)
    payloads = [source, claims, ingestion, memory, contradiction, capsule, contract, domain, surface, read_only, regression]
    checks = [
        {"check": "final_truth_consistency", "status": "PASS", "detail": FINAL_TRUTH},
        {"check": "source_registry_v2", "status": source.get("status", "FAIL"), "detail": str(source.get("fail_count", 0))},
        {"check": "claim_ledger_v2", "status": claims.get("status", "FAIL"), "detail": str(claims.get("fail_count", 0))},
        {"check": "deep_research_ingestion_block", "status": ingestion.get("status", "FAIL"), "detail": str(ingestion.get("fail_count", 0))},
        {"check": "obsidian_memory_router", "status": memory.get("status", "FAIL"), "detail": str(memory.get("fail_count", 0))},
        {"check": "contradiction_layer", "status": contradiction.get("status", "FAIL"), "detail": str(contradiction.get("fail_count", 0))},
        {"check": "evidence_capsule_factory", "status": capsule.get("status", "FAIL"), "detail": str(capsule.get("fail_count", 0))},
        {"check": "write_contract", "status": contract.get("status", "FAIL"), "detail": str(contract.get("fail_count", 0))},
        {"check": "domain_summary", "status": "PASS" if domain.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "FAIL", "detail": domain.get("status", "")},
        {"check": "current_surface", "status": surface.get("status", "FAIL"), "detail": str(surface.get("fail_count", 0))},
        {"check": "read_only_audit", "status": read_only.get("status", "FAIL"), "detail": str(read_only.get("unexpected_mutation_count", 0))},
        {"check": "regression_suite", "status": regression.get("status", "FAIL"), "detail": str(regression.get("fail_count", 0))},
        {"check": "forbidden_action_count", "status": "PASS" if _forbidden_action_count(payloads) == 0 else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M8_FINAL_VERIFICATION_PATH, payload, "M8 Final Verification")
        _write_json_md(VERIFICATION_SUMMARY_PATH, payload, "M8 Verification Summary")
    return payload


def build_final_state(*, write: bool = True) -> dict[str, Any]:
    if not write:
        return load_json(M8_FINAL_STATE_PATH, default={})
    build_grand_roadmap(write=True)
    source = build_source_registry_v2(write=True)
    claims = build_claim_ledger_v2(write=True)
    ingestion = build_deep_research_ingestion_block(write=True)
    memory = build_obsidian_memory_router(write=True)
    contradiction = build_contradiction_layer(write=True)
    capsule = build_evidence_capsule_factory(write=True)
    build_write_contract(write=True)
    build_domain_summary(write=True)
    build_current_surface(write=True)
    build_current_manifest(write=True)
    verification = build_final_verification(write=True)
    replay_text = "\n".join([
        "# M8 Replay Instructions",
        "",
        "Run from `/Users/BjornRosinger/Documents/DreamFactory/Project-Intelligence-Graph`:",
        "",
        "```bash",
        "python3 scripts/project_intelligence_graph/pig.py m8-final-state --json",
        "python3 scripts/project_intelligence_graph/pig.py m8-read-only-audit --json",
        "python3 scripts/project_intelligence_graph/pig.py m8-regression-suite --json",
        "python3 scripts/project_intelligence_graph/pig.py full-check --json",
        "```",
        "",
        "M8 materialisiert lokale Knowledge-/Evidence-Reife. Es teilt nichts extern und startet keine Runtime.",
    ])
    _write_text(M8_REPLAY_INSTRUCTIONS_PATH, replay_text)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS_WITH_WARNINGS" if verification.get("status") == "PASS" else "FAIL",
        "final_truth": FINAL_TRUTH,
        "roadmap_truth": ROADMAP_TRUTH,
        "current_owner": "M8",
        "previous_truth": PREVIOUS_TRUTH,
        "m8_blocks_completed": 6,
        "m9_next": "efficiency_de_monolith_program_local_reversible",
        "source_registry_v2": safe_rel(M8_SOURCE_REGISTRY_V2_PATH),
        "claim_ledger_v2": safe_rel(M8_CLAIM_LEDGER_V2_PATH),
        "deep_research_ingestion_block": safe_rel(M8_DEEP_RESEARCH_BLOCK_PATH),
        "obsidian_memory_router": safe_rel(M8_MEMORY_ROUTER_PATH),
        "contradiction_layer": safe_rel(M8_CONTRADICTION_LAYER_PATH),
        "evidence_capsule_factory": safe_rel(M8_EVIDENCE_FACTORY_PATH),
        "source_count": source.get("source_count", 0),
        "claim_count": claims.get("claim_count", 0),
        "routed_claim_count": ingestion.get("routed_claim_count", 0),
        "route_count": memory.get("route_count", 0),
        "contradiction_class_count": contradiction.get("contradiction_class_count", 0),
        "capsule_profile_count": capsule.get("capsule_profile_count", 0),
        "checks": verification.get("checks", []),
        "fail_count": verification.get("fail_count", 1),
        **_gate_payload(),
    }
    write_json(SYSTEM_TRUTH_PATH, payload)
    _write_json_md(M8_FINAL_STATE_PATH, payload, "M8 Final State")
    build_current_manifest(write=True)
    build_operator_brief(write=True)
    return payload


def _operator_brief_md(payload: dict[str, Any]) -> str:
    lines = ["# Project Intelligence Graph Operator Brief", "", f"- Generated: `{payload.get('generated_at', '')}`", f"- Overall: `{payload.get('overall_status', 'UNKNOWN')}`", f"- Build: `{payload.get('build_status', 'UNKNOWN')}`", f"- Decisions: `{payload.get('decision_status', 'UNKNOWN')}`", "", "## Do This Now", ""]
    for item in payload.get("do_this_now", []):
        lines.append(f"- `{item.get('priority', '-')}` {item.get('text', '')}")
    lines.extend(["", "## Do Not", ""])
    for item in payload.get("do_not", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Safe Commands", ""])
    for command in payload.get("safe_commands", []):
        lines.append(f"- `{command}`")
    lines.extend(["", "## Status Lines", ""])
    for key, value in payload.get("status_lines", {}).items():
        lines.append(f"- `{key}`: `{value}`")
    return "\n".join(lines) + "\n"


def build_operator_brief(*, write: bool = True) -> dict[str, Any]:
    final_state = load_json(M8_FINAL_STATE_PATH, default={})
    verification = load_json(M8_FINAL_VERIFICATION_PATH, default={})
    payload = {
        "schema_version": 6,
        "generated_at": now_iso(),
        "overall_status": "ACTION_REQUIRED",
        "build_status": "PASS" if verification.get("status") == "PASS" and final_state.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "WARN",
        "decision_status": "OPERATOR_GATED",
        "current_owner": "M8",
        "final_truth": FINAL_TRUTH,
        "do_this_now": [
            {"priority": "P1", "text": "Use M8 Claim Ledger v2 as the current knowledge entrypoint; do not copy research walls into memory."},
            {"priority": "P1", "text": "Route durable facts to Obsidian only after source refs, contradiction status and gate dependencies are visible."},
            {"priority": "P2", "text": "Use M8 Evidence Capsule Factory profiles before creating any review pack; external share remains gated."},
            {"priority": "P2", "text": "Continue with M9 Efficiency & De-Monolith Program after M8 verifiers, Memory and long-run handoff pass."},
        ],
        "do_not": [
            "Do not treat Deep Research output as truth until it is routed as a source-backed claim.",
            "Do not write temporary hypotheses or raw command output into Obsidian memory.",
            "Do not share local review bundles externally without a fresh profile-specific Operator-Go.",
            "Do not open Public, Production, Payment, Auth, Room16 rerun, real-data, runtime or external communication gates.",
        ],
        "safe_commands": [
            "python3 scripts/project_intelligence_graph/pig.py m8-final-state --json",
            "python3 scripts/project_intelligence_graph/pig.py m8-final-verification --json",
            "python3 scripts/project_intelligence_graph/pig.py m8-read-only-audit --json",
            "python3 scripts/project_intelligence_graph/pig.py m8-regression-suite --json",
            "python3 scripts/project_intelligence_graph/pig.py full-check --json",
            "python3 scripts/project_intelligence_graph/pig.py german-output-quality --json",
        ],
        "status_lines": {
            "m8_current_owner": final_state.get("current_owner", "M8"),
            "m8_final_truth": final_state.get("final_truth", FINAL_TRUTH),
            "m8_final_state_status": final_state.get("status", "UNKNOWN"),
            "m8_blocks_completed": final_state.get("m8_blocks_completed", 0),
            "m8_source_count": final_state.get("source_count", 0),
            "m8_claim_count": final_state.get("claim_count", 0),
            "m8_capsule_profile_count": final_state.get("capsule_profile_count", 0),
            "m9_next": final_state.get("m9_next", "efficiency_de_monolith_program_local_reversible"),
            "hard_gates": "closed",
            **_gate_payload(),
        },
    }
    if write:
        write_json(OPERATOR_BRIEF_PATH, payload)
        _write_text(OPERATOR_BRIEF_MD_PATH, _operator_brief_md(payload))
    return payload


M8_BUILDERS: dict[str, Callable[..., dict[str, Any]]] = {
    "grand-roadmap": build_grand_roadmap,
    "m8-source-registry-v2": build_source_registry_v2,
    "m8-claim-ledger-v2": build_claim_ledger_v2,
    "m8-deep-research-ingestion-block": build_deep_research_ingestion_block,
    "m8-obsidian-memory-router": build_obsidian_memory_router,
    "m8-contradiction-layer": build_contradiction_layer,
    "m8-evidence-capsule-factory": build_evidence_capsule_factory,
    "m8-write-contract": build_write_contract,
    "m8-domain-summary": build_domain_summary,
    "m8-current-surface": build_current_surface,
    "m8-current-manifest": build_current_manifest,
    "m8-read-only-audit": build_read_only_audit,
    "m8-regression-suite": build_regression_suite,
    "m8-final-verification": build_final_verification,
    "m8-final-state": build_final_state,
}

M1_CURRENT_COMMANDS = tuple(dict.fromkeys([*m7.M1_CURRENT_COMMANDS, *M8_BUILDERS.keys()]))


def run_m1_current_command(command: str, write: bool = True, profile: str | None = None) -> dict[str, Any]:
    if command in M8_BUILDERS:
        effective_write = False if command in AUDITOR_COMMANDS else write
        return M8_BUILDERS[command](write=effective_write)
    return m7.run_m1_current_command(command, write=write, profile=profile)


def m1_full_check_steps() -> list[dict[str, Any]]:
    steps = m7.m1_full_check_steps()
    for command in [
        "m8-source-registry-v2",
        "m8-claim-ledger-v2",
        "m8-deep-research-ingestion-block",
        "m8-obsidian-memory-router",
        "m8-contradiction-layer",
        "m8-evidence-capsule-factory",
        "m8-read-only-audit",
        "m8-regression-suite",
        "m8-final-verification",
        "m8-final-state",
    ]:
        payload = run_m1_current_command(command, write=False)
        ok = is_passish(payload.get("status", "UNKNOWN"))
        steps.append({"name": command.replace("-", "_"), "status": "PASS" if ok else "FAIL", "returncode": 0 if ok else 1, "fail_count": payload.get("fail_count", 0), "runtime_action_executed": payload.get("runtime_action_executed", False), "external_action_executed": payload.get("external_action_executed", False)})
    return steps


def m1_report_payload() -> dict[str, Any]:
    payload = m7.m1_report_payload()
    payload.update(
        {
            "m8_source_registry_v2": load_json(M8_SOURCE_REGISTRY_V2_PATH, default={}),
            "m8_claim_ledger_v2": load_json(M8_CLAIM_LEDGER_V2_PATH, default={}),
            "m8_deep_research_ingestion_block": load_json(M8_DEEP_RESEARCH_BLOCK_PATH, default={}),
            "m8_obsidian_memory_router": load_json(M8_MEMORY_ROUTER_PATH, default={}),
            "m8_contradiction_layer": load_json(M8_CONTRADICTION_LAYER_PATH, default={}),
            "m8_evidence_capsule_factory": load_json(M8_EVIDENCE_FACTORY_PATH, default={}),
            "m8_final_verification": load_json(M8_FINAL_VERIFICATION_PATH, default={}),
            "m8_final_state": load_json(M8_FINAL_STATE_PATH, default={}),
        }
    )
    return payload


def m1_compact_domain_lines(report: dict[str, Any]) -> list[str]:
    final_state = report.get("m8_final_state") or load_json(M8_FINAL_STATE_PATH, default={})
    lines = ["## Current Kernel Summary", ""]
    lines.append(f"- M8 final: `{final_state.get('status', 'UNKNOWN')}` `{final_state.get('final_truth', FINAL_TRUTH)}`")
    lines.append("- Current owner: `M8`; M7 ist Vorgängerschicht, ältere Surfaces sind Provenance.")
    lines.append(f"- Sources: `{final_state.get('source_count', 0)}`; Claims: `{final_state.get('claim_count', 0)}`; Capsule profiles: `{final_state.get('capsule_profile_count', 0)}`.")
    lines.append("- Operator cockpit: `outputs/project_intelligence_graph/current/operator_cockpit.md`.")
    lines.append("")
    return lines


def append_m1_full_check_lines(lines: list[str], report: dict[str, Any]) -> None:
    final_state = report.get("m8_final_state", {})
    claims = report.get("m8_claim_ledger_v2", {})
    memory = report.get("m8_obsidian_memory_router", {})
    capsule = report.get("m8_evidence_capsule_factory", {})
    lines.extend(["", "## M8 Knowledge & Evidence OS", ""])
    lines.append(f"- Final state: `{final_state.get('status', 'UNKNOWN')}` ({final_state.get('final_truth', FINAL_TRUTH)})")
    lines.append(f"- Claims: `{claims.get('claim_count', 0)}`; memory routes `{memory.get('route_count', 0)}`")
    lines.append(f"- Capsule profiles: `{capsule.get('capsule_profile_count', 0)}`; external share `False`")
    lines.append("- Runtime actions: `none`; external share, public/payment/auth, real data and publishing remain gated.")
