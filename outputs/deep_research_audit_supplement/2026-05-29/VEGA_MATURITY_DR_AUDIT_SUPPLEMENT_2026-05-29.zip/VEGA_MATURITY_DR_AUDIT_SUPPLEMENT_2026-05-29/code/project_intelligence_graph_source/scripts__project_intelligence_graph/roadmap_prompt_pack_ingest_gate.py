#!/usr/bin/env python3
"""Validate Roadmap/Prompt Pack vault imports.

This gate is intentionally local and read-only. It checks whether a source pack
looks like an implementation-ready roadmap/prompt pack and whether the imported
vault folder contains the required durable anchors.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path
from typing import Any


MARKERS = {
    "roadmap": [r"\broadmap\b", r"3[- ]jahre", r"implementierungsplan"],
    "masterprompt": [r"masterprompt", r"arbeitsauftrag", r"build[- ]reihenfolge"],
    "build_plan": [r"build plan", r"\bBUILD\s+0\b", r"akzeptanzkriterien"],
    "architecture": [r"architektur", r"ablaufdiagram", r"```mermaid", r"flowchart"],
    "qa_verifier": [r"\bQA\b", r"verifier", r"golden test", r"publish check"],
    "privacy_policy": [r"datenschutz", r"privacy", r"policy", r"stop-regeln"],
    "manifest_sources": [r"manifest\.json", r"source_urls", r"quellen"],
}


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def source_payload(source_zip: Path | None, source_dir: Path | None) -> tuple[list[str], str, list[str]]:
    names: list[str] = []
    text_parts: list[str] = []
    errors: list[str] = []
    if source_zip:
        try:
            with zipfile.ZipFile(source_zip) as archive:
                bad = archive.testzip()
                if bad:
                    errors.append(f"zip_integrity_failed:{bad}")
                for info in archive.infolist():
                    names.append(info.filename)
                    if info.filename.lower().endswith((".md", ".txt", ".json", ".yaml", ".yml")):
                        try:
                            text_parts.append(archive.read(info).decode("utf-8", errors="replace"))
                        except Exception as exc:  # pragma: no cover - defensive
                            errors.append(f"zip_read_failed:{info.filename}:{exc}")
        except Exception as exc:
            errors.append(f"zip_open_failed:{exc}")
    if source_dir:
        for path in sorted(source_dir.rglob("*")):
            if path.is_file():
                names.append(str(path.relative_to(source_dir)))
                if path.suffix.lower() in {".md", ".txt", ".json", ".yaml", ".yml"}:
                    text_parts.append(read_text(path))
    return names, "\n".join(text_parts + names), errors


def classify(names_and_text: str) -> dict[str, Any]:
    lower = names_and_text.lower()
    hits: dict[str, list[str]] = {}
    for marker, patterns in MARKERS.items():
        marker_hits = [pattern for pattern in patterns if re.search(pattern, lower, re.IGNORECASE)]
        if marker_hits:
            hits[marker] = marker_hits
    return {
        "is_roadmap_prompt_pack": len(hits) >= 2,
        "marker_count": len(hits),
        "markers": sorted(hits),
    }


def load_json(path: Path, errors: list[str], label: str) -> Any | None:
    try:
        return json.loads(read_text(path))
    except Exception as exc:
        errors.append(f"{label}_json_parse_failed:{exc}")
        return None


def validate_canvas(vault_root: Path, canvas_path: Path, errors: list[str]) -> dict[str, int]:
    canvas = load_json(canvas_path, errors, "canvas")
    if not isinstance(canvas, dict):
        return {"nodes": 0, "edges": 0}
    nodes = canvas.get("nodes", [])
    edges = canvas.get("edges", [])
    if not isinstance(nodes, list) or not isinstance(edges, list):
        errors.append("canvas_nodes_or_edges_not_list")
        return {"nodes": 0, "edges": 0}
    node_ids = [node.get("id") for node in nodes if isinstance(node, dict)]
    edge_ids = [edge.get("id") for edge in edges if isinstance(edge, dict)]
    if len(node_ids) != len(set(node_ids)):
        errors.append("canvas_duplicate_node_ids")
    if len(edge_ids) != len(set(edge_ids)):
        errors.append("canvas_duplicate_edge_ids")
    node_set = set(node_ids)
    for node in nodes:
        if isinstance(node, dict) and node.get("type") == "file":
            target = node.get("file")
            if not target or not (vault_root / target).exists():
                errors.append(f"canvas_missing_file_node:{target}")
    for edge in edges:
        if not isinstance(edge, dict):
            continue
        if edge.get("fromNode") not in node_set or edge.get("toNode") not in node_set:
            errors.append(f"canvas_dangling_edge:{edge.get('id')}")
    return {"nodes": len(nodes), "edges": len(edges)}


def resolve_wikilink(vault_root: Path, note: Path, target: str) -> bool:
    clean = target.split("|", 1)[0].split("#", 1)[0]
    if not clean:
        return True
    human = vault_root / "Human Overview"
    candidates: list[Path]
    if clean.endswith(".canvas"):
        candidates = [vault_root / clean, human / clean, note.parent / clean]
    elif "/" in clean:
        candidates = [
            vault_root / f"{clean}.md",
            human / f"{clean}.md",
            note.parent / f"{clean}.md",
            vault_root / clean,
            human / clean,
            note.parent / clean,
        ]
    else:
        candidates = [note.parent / f"{clean}.md"]
        candidates.extend(human.rglob(f"{clean}.md"))
    return any(path.exists() for path in candidates)


def validate_wikilinks(vault_root: Path, import_root: Path, extra_notes: list[Path], errors: list[str]) -> int:
    notes = sorted(import_root.glob("*.md")) + [path for path in extra_notes if path.exists()]
    checked = 0
    for note in notes:
        checked += 1
        text = read_text(note)
        for raw in re.findall(r"!{0,1}\[\[([^\]]+)\]\]", text):
            if not resolve_wikilink(vault_root, note, raw):
                errors.append(f"unresolved_wikilink:{note.name}:{raw}")
    return checked


def find_one(import_root: Path, patterns: list[str]) -> Path | None:
    for path in sorted(import_root.iterdir()):
        if not path.is_file():
            continue
        lowered = path.name.lower()
        if any(pattern in lowered for pattern in patterns):
            return path
    return None


def validate_import(vault_root: Path, import_root: Path, extra_notes: list[Path]) -> dict[str, Any]:
    errors: list[str] = []
    if not import_root.exists():
        return {"status": "FAIL", "errors": [f"import_root_missing:{import_root}"]}
    files = [path for path in import_root.iterdir() if path.is_file()]
    required = {
        "moc": find_one(import_root, ["moc", "start", "index"]),
        "masterprompt": find_one(import_root, ["masterprompt", "prompt"]),
        "build_plan": find_one(import_root, ["build_plan", "build-plan", "build"]),
        "qa": find_one(import_root, ["qa", "verifier", "quality"]),
        "privacy": find_one(import_root, ["datenschutz", "privacy", "policy"]),
        "audit": find_one(import_root, ["audit"]),
        "canvas": find_one(import_root, [".canvas"]),
    }
    for key, path in required.items():
        if path is None:
            errors.append(f"required_anchor_missing:{key}")
    for json_name in ["manifest.json", "10_Source_URLs.json"]:
        candidate = import_root / json_name
        if candidate.exists():
            load_json(candidate, errors, json_name)
    canvas_stats = {"nodes": 0, "edges": 0}
    if required["canvas"] is not None:
        canvas_stats = validate_canvas(vault_root, required["canvas"], errors)
    if required["audit"] is not None:
        audit_text = read_text(required["audit"])
        if "PASS" not in audit_text and "pass" not in audit_text.lower():
            errors.append("audit_without_pass_marker")
        if "kein" not in audit_text.lower() and "not" not in audit_text.lower():
            errors.append("audit_missing_not_scope_language")
    checked_notes = validate_wikilinks(vault_root, import_root, extra_notes, errors)
    return {
        "status": "PASS" if not errors else "FAIL",
        "errors": errors,
        "imported_files": len(files),
        "canvas_nodes": canvas_stats["nodes"],
        "canvas_edges": canvas_stats["edges"],
        "checked_notes": checked_notes,
    }


def render_markdown(report: dict[str, Any]) -> str:
    lines = [
        "# Roadmap Prompt Pack Ingest Gate",
        "",
        f"- Status: `{report['status']}`",
        f"- Classification: `{report['classification']['is_roadmap_prompt_pack']}`",
        f"- Marker count: `{report['classification']['marker_count']}`",
        f"- Markers: `{', '.join(report['classification']['markers'])}`",
        f"- Imported files: `{report.get('imported_files', 0)}`",
        f"- Canvas nodes: `{report.get('canvas_nodes', 0)}`",
        f"- Canvas edges: `{report.get('canvas_edges', 0)}`",
        f"- Checked notes: `{report.get('checked_notes', 0)}`",
    ]
    if report.get("source_sha256"):
        lines.append(f"- Source SHA-256: `{report['source_sha256']}`")
    lines.append("")
    lines.append("## Errors")
    if report.get("errors"):
        lines.extend(f"- `{error}`" for error in report["errors"])
    else:
        lines.append("- none")
    lines.append("")
    lines.append("## Scope")
    lines.append("This gate validates durable vault import, canvas/link integrity and audit evidence. It does not validate product code or professional/fachliche correctness.")
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-zip", type=Path)
    parser.add_argument("--source-dir", type=Path)
    parser.add_argument("--import-root", type=Path, required=True)
    parser.add_argument("--vault-root", type=Path, required=True)
    parser.add_argument("--extra-note", type=Path, action="append", default=[])
    parser.add_argument("--report-json", type=Path)
    parser.add_argument("--report-md", type=Path)
    args = parser.parse_args()

    names, payload, source_errors = source_payload(args.source_zip, args.source_dir)
    classification = classify(payload)
    import_report = validate_import(args.vault_root, args.import_root, args.extra_note)
    errors = list(source_errors) + import_report["errors"]
    if not classification["is_roadmap_prompt_pack"]:
        errors.append("source_not_classified_as_roadmap_prompt_pack")
    status = "PASS" if not errors else "FAIL"
    report: dict[str, Any] = {
        "status": status,
        "classification": classification,
        "source_names_count": len(names),
        "errors": errors,
        **{key: value for key, value in import_report.items() if key not in {"status", "errors"}},
    }
    if args.source_zip and args.source_zip.exists():
        report["source_zip"] = str(args.source_zip)
        report["source_sha256"] = sha256(args.source_zip)
    if args.report_json:
        args.report_json.parent.mkdir(parents=True, exist_ok=True)
        args.report_json.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    if args.report_md:
        args.report_md.parent.mkdir(parents=True, exist_ok=True)
        args.report_md.write_text(render_markdown(report), encoding="utf-8")
    print(status)
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
