"""M6 Vivi-autonomy kernel for DreamFactory/PIG."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Callable

import m5_decision as m5
from maturity_kernel_v5_core import (
    HARD_GATES,
    OUTPUT_DIR,
    WORKSPACE,
    check_rows,
    is_passish,
    load_json,
    now_iso,
    safe_rel,
    write_json,
)


CURRENT_DIR = OUTPUT_DIR / "current"
SCRIPTS_DIR = WORKSPACE / "scripts/project_intelligence_graph"

FINAL_TRUTH = "m6_vivi_autonomy_kernel_dry_run_supervised_operator_gated"
ROADMAP_TRUTH = m5.ROADMAP_TRUTH
PREVIOUS_TRUTH = m5.FINAL_TRUTH

SYSTEM_TRUTH_PATH = CURRENT_DIR / "system_truth.json"
OPERATOR_COCKPIT_PATH = CURRENT_DIR / "operator_cockpit.md"
OPERATOR_DECISION_QUEUE_PATH = CURRENT_DIR / "operator_decision_queue.json"
NEXT_DECISION_BOARD_PATH = CURRENT_DIR / "next_operator_decision_board.json"
CURRENT_SURFACE_MANIFEST_PATH = CURRENT_DIR / "current_surface_manifest.json"
CURRENT_TRUTH_AUDIT_PATH = CURRENT_DIR / "current_truth_audit.json"
DOMAIN_SUMMARY_PATH = CURRENT_DIR / "domain_summary.json"
VERIFICATION_SUMMARY_PATH = CURRENT_DIR / "verification_summary.json"
WRITE_CONTRACT_PATH = CURRENT_DIR / "write_contract.json"
GRAND_ROADMAP_PATH = CURRENT_DIR / "grand_roadmap_m3r_to_m12.json"

M6_MISSION_CARD_PATH = CURRENT_DIR / "m6_mission_card_v4.json"
M6_CLAIM_LEASE_LEDGER_PATH = CURRENT_DIR / "m6_claim_lease_ledger.json"
M6_SKILL_LADDER_PATH = CURRENT_DIR / "m6_skill_ladder.json"
M6_WORK_SELECTION_POLICY_PATH = CURRENT_DIR / "m6_work_selection_policy.json"
M6_SUPERVISOR_EVAL_PATH = CURRENT_DIR / "m6_supervisor_eval.json"
M6_AUTONOMY_DRY_RUNS_PATH = CURRENT_DIR / "m6_autonomy_dry_runs.json"
M6_CURRENT_SURFACE_PATH = CURRENT_DIR / "m6_current_surface.json"
M6_READ_ONLY_AUDIT_PATH = CURRENT_DIR / "m6_read_only_audit.json"
M6_REGRESSION_SUITE_PATH = CURRENT_DIR / "m6_regression_suite.json"
M6_FINAL_VERIFICATION_PATH = CURRENT_DIR / "m6_final_verification.json"
M6_FINAL_STATE_PATH = CURRENT_DIR / "m6_final_state.json"
M6_REPLAY_INSTRUCTIONS_PATH = CURRENT_DIR / "m6_replay_instructions.md"

VIVI_WORKER_QUEUE_PATH = OUTPUT_DIR / "vivi_worker_queue.json"
VIVI_WORKER_SUPERVISOR_AUDIT_PATH = OUTPUT_DIR / "vivi_worker_supervisor_audit.json"
VIVI_MATURITY_CARDS_PATH = OUTPUT_DIR / "vivi_maturity_cards.json"
VIVI_V3_2_SUPERVISOR_AUDIT_PATH = OUTPUT_DIR / "vivi_v3_2_supervisor_audit.json"
VIVI_V3_3_SUPERVISOR_AUDIT_PATH = OUTPUT_DIR / "vivi_v3_3_supervisor_audit.json"
MODEL_PROVIDER_TRUTH_PATH = OUTPUT_DIR / "model_provider_truth.json"
OPERATOR_BRIEF_PATH = OUTPUT_DIR / "operator_brief.json"
OPERATOR_BRIEF_MD_PATH = OUTPUT_DIR / "operator_brief.md"

M6_BLOCK_PATHS = {
    "M6-01": CURRENT_DIR / "m6-01_vivi_mission_card_v4.json",
    "M6-02": CURRENT_DIR / "m6-02_vivi_claim_lease_ledger.json",
    "M6-03": CURRENT_DIR / "m6-03_vivi_skill_ladder.json",
    "M6-04": CURRENT_DIR / "m6-04_vivi_work_selection_policy.json",
    "M6-05": CURRENT_DIR / "m6-05_vivi_supervisor_eval.json",
    "M6-06": CURRENT_DIR / "m6-06_autonomy_dry_runs.json",
}

BUILDER_COMMANDS = [
    "grand-roadmap",
    "m6-mission-card-v4",
    "m6-claim-lease-ledger",
    "m6-skill-ladder",
    "m6-work-selection-policy",
    "m6-supervisor-eval",
    "m6-autonomy-dry-runs",
    "m6-current-surface",
    "m6-final-state",
]

AUDITOR_COMMANDS = [
    "m6-read-only-audit",
    "m6-regression-suite",
    "m6-final-verification",
]

FORBIDDEN_ACTIONS = [
    "runtime_worker_start_without_claim",
    "model_run_without_operator_go",
    "provider_change",
    "spend",
    *m5.FORBIDDEN_ACTIONS,
]


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def _sha(path: Path) -> str:
    if not path.exists() or not path.is_file():
        return ""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _payload_hash(payload: Any) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


def _write_json_md(path: Path, payload: dict[str, Any], title: str) -> None:
    write_json(path, payload)
    lines = [
        f"# {title}",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Final truth: `{payload.get('final_truth', FINAL_TRUTH)}`",
        "",
    ]
    for key in ["current_owner", "card_count", "lease_count", "level_count", "dry_run_count", "decision_count", "unexpected_mutation_count", "fail_count"]:
        if key in payload:
            lines.append(f"- {key}: `{payload[key]}`")
    if payload.get("warnings"):
        lines += ["", "## Warnungen", ""]
        for warning in payload["warnings"]:
            lines.append(f"- {warning}")
    if payload.get("checks"):
        lines += ["", "## Checks", ""]
        for check in payload["checks"]:
            lines.append(f"- `{check.get('status', 'UNKNOWN')}` {check.get('check', '')}: {check.get('detail', '')}")
    _write_text(path.with_suffix(".md"), "\n".join(lines))


def _snapshot(paths: list[Path]) -> dict[str, dict[str, Any]]:
    rows: dict[str, dict[str, Any]] = {}
    for path in paths:
        if path.exists() and path.is_file():
            rows[safe_rel(path)] = {"mtime_ns": path.stat().st_mtime_ns, "bytes": path.stat().st_size, "sha256": _sha(path)}
    return rows


def _aggregate(statuses: list[str]) -> str:
    if any(status == "FAIL" for status in statuses):
        return "FAIL"
    if any(status != "PASS" for status in statuses):
        return "PASS_WITH_WARNINGS"
    return "PASS"


def _source_paths() -> list[Path]:
    return [
        m5.M5_FINAL_STATE_PATH,
        m5.M5_DECISION_OBJECT_MODEL_PATH,
        m5.M5_OPERATOR_APPROVAL_PROTOCOL_PATH,
        VIVI_WORKER_QUEUE_PATH,
        VIVI_WORKER_SUPERVISOR_AUDIT_PATH,
        VIVI_MATURITY_CARDS_PATH,
        VIVI_V3_2_SUPERVISOR_AUDIT_PATH,
        VIVI_V3_3_SUPERVISOR_AUDIT_PATH,
        MODEL_PROVIDER_TRUTH_PATH,
    ]


def _active_files() -> list[Path]:
    paths = [
        SYSTEM_TRUTH_PATH,
        OPERATOR_COCKPIT_PATH,
        OPERATOR_DECISION_QUEUE_PATH,
        NEXT_DECISION_BOARD_PATH,
        NEXT_DECISION_BOARD_PATH.with_suffix(".md"),
        CURRENT_SURFACE_MANIFEST_PATH,
        CURRENT_SURFACE_MANIFEST_PATH.with_suffix(".md"),
        CURRENT_TRUTH_AUDIT_PATH,
        CURRENT_TRUTH_AUDIT_PATH.with_suffix(".md"),
        DOMAIN_SUMMARY_PATH,
        DOMAIN_SUMMARY_PATH.with_suffix(".md"),
        VERIFICATION_SUMMARY_PATH,
        VERIFICATION_SUMMARY_PATH.with_suffix(".md"),
        WRITE_CONTRACT_PATH,
        WRITE_CONTRACT_PATH.with_suffix(".md"),
        GRAND_ROADMAP_PATH,
        GRAND_ROADMAP_PATH.with_suffix(".md"),
        M6_MISSION_CARD_PATH,
        M6_MISSION_CARD_PATH.with_suffix(".md"),
        M6_CLAIM_LEASE_LEDGER_PATH,
        M6_CLAIM_LEASE_LEDGER_PATH.with_suffix(".md"),
        M6_SKILL_LADDER_PATH,
        M6_SKILL_LADDER_PATH.with_suffix(".md"),
        M6_WORK_SELECTION_POLICY_PATH,
        M6_WORK_SELECTION_POLICY_PATH.with_suffix(".md"),
        M6_SUPERVISOR_EVAL_PATH,
        M6_SUPERVISOR_EVAL_PATH.with_suffix(".md"),
        M6_AUTONOMY_DRY_RUNS_PATH,
        M6_AUTONOMY_DRY_RUNS_PATH.with_suffix(".md"),
        M6_CURRENT_SURFACE_PATH,
        M6_CURRENT_SURFACE_PATH.with_suffix(".md"),
        M6_READ_ONLY_AUDIT_PATH,
        M6_READ_ONLY_AUDIT_PATH.with_suffix(".md"),
        M6_REGRESSION_SUITE_PATH,
        M6_REGRESSION_SUITE_PATH.with_suffix(".md"),
        M6_FINAL_VERIFICATION_PATH,
        M6_FINAL_VERIFICATION_PATH.with_suffix(".md"),
        M6_FINAL_STATE_PATH,
        M6_FINAL_STATE_PATH.with_suffix(".md"),
        M6_REPLAY_INSTRUCTIONS_PATH,
        *M6_BLOCK_PATHS.values(),
        *[path.with_suffix(".md") for path in M6_BLOCK_PATHS.values()],
    ]
    return sorted(set(paths))


def _source_hashes(paths: list[Path]) -> list[dict[str, Any]]:
    rows = []
    for path in paths:
        rows.append({"path": safe_rel(path), "exists": path.exists(), "sha256": _sha(path) if path.exists() and path.is_file() else ""})
    return rows


def _mission_cards() -> list[dict[str, Any]]:
    common_forbidden = [
        "push",
        "delete",
        "publish",
        "deploy",
        "production",
        "public",
        "payment",
        "auth/credentials",
        "external communication",
        "Room16 rerun",
        "provider change",
        "model run",
        "real person/client data",
        "irreversible action",
    ]
    cards = [
        {
            "card_id": "m6-vivi-current-surface-delta-audit",
            "claim": "Verify that a local Current Surface delta has evidence, hashes and no hidden runtime action.",
            "context": "Use M5/M6 current artifacts and PIG full-check outputs; do not inspect unrelated raw logs.",
            "level": 0,
            "risk_class": "R2",
            "allowed_files": [safe_rel(path) for path in [M6_MISSION_CARD_PATH, M6_SUPERVISOR_EVAL_PATH, M6_FINAL_STATE_PATH]],
            "forbidden_actions": common_forbidden,
            "expected_delta": "A short evidence-backed audit row, not a file mutation outside M6 outputs.",
            "verifier": ["python3 scripts/project_intelligence_graph/pig.py m6-supervisor-eval --json"],
            "stop_conditions": ["missing_source_hash", "verifier_fail", "runtime_action_required"],
            "evidence_hashes": _source_hashes([m5.M5_FINAL_STATE_PATH, VIVI_WORKER_SUPERVISOR_AUDIT_PATH]),
            "before_after_metrics": {"before_current_owner": "M5", "after_current_owner": "M6", "expected_runtime_actions": 0},
            "supervisor_verdict": {"status": "pending_supervisor_eval", "separate_from_worker_claim": True},
            "runtime_action_executed": False,
        },
        {
            "card_id": "m6-vivi-operator-copy-sentinel",
            "claim": "Check operator-facing German reports for real umlauts and no render leaks after a local kernel change.",
            "context": "Use PIG German Output Quality and only current operator-facing reports.",
            "level": 1,
            "risk_class": "R2",
            "allowed_files": [safe_rel(M6_SUPERVISOR_EVAL_PATH), safe_rel(M6_FINAL_VERIFICATION_PATH)],
            "forbidden_actions": common_forbidden,
            "expected_delta": "A lint/verifier evidence row; no factual rewrite by Vivi.",
            "verifier": ["python3 scripts/project_intelligence_graph/pig.py german-output-quality --json"],
            "stop_conditions": ["finding_count_gt_0", "fact_change_required", "manual_copy_rewrite_needed"],
            "evidence_hashes": _source_hashes([OUTPUT_DIR / "german_output_quality_gate.json"]),
            "before_after_metrics": {"expected_findings": 0, "humanizer_can_change_facts": False},
            "supervisor_verdict": {"status": "pending_supervisor_eval", "separate_from_worker_claim": True},
            "runtime_action_executed": False,
        },
        {
            "card_id": "m6-vivi-decision-pack-support",
            "claim": "Prepare the next safest support artifact for M5 decisions without executing commit, cleanup or quarantine.",
            "context": "Use M5 decision objects and approval protocol; support only, never act on candidates.",
            "level": 2,
            "risk_class": "R2",
            "allowed_files": [safe_rel(M6_AUTONOMY_DRY_RUNS_PATH), safe_rel(M6_WORK_SELECTION_POLICY_PATH)],
            "forbidden_actions": common_forbidden + ["commit", "cleanup", "quarantine move"],
            "expected_delta": "Dry-run support plan with expected file changes and preflight fail reasons.",
            "verifier": ["python3 scripts/project_intelligence_graph/pig.py m6-autonomy-dry-runs --json"],
            "stop_conditions": ["active_operator_go_missing_for_runtime_action", "candidate_pack_treated_as_permission"],
            "evidence_hashes": _source_hashes([m5.M5_DECISION_OBJECT_MODEL_PATH, m5.M5_OPERATOR_APPROVAL_PROTOCOL_PATH]),
            "before_after_metrics": {"m5_decision_count": 7, "m6_dry_run_count": 3, "runtime_actions": 0},
            "supervisor_verdict": {"status": "pending_supervisor_eval", "separate_from_worker_claim": True},
            "runtime_action_executed": False,
        },
    ]
    return cards


def _leases(cards: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {
            "lease_id": f"lease-{card['card_id']}",
            "card_id": card["card_id"],
            "claim_owner": None,
            "lease_status": "available_dry_run_only",
            "lease_expires_at": None,
            "stale_lease_recovery": "Return to available only after Vega supervisor confirms no active run exists.",
            "handoff": "Vega/PIG supervisor",
            "risky_domain_serial_required": card.get("risk_class") in {"R3", "R4", "R5"},
            "runtime_action_executed": False,
        }
        for card in cards
    ]


def _skill_levels() -> list[dict[str, Any]]:
    return [
        {"level": 0, "name": "read_only_audit", "allowed_claim_types": ["read_current_truth", "verify_existing_evidence"], "required_verifier": "read-only audit", "runtime_allowed": False},
        {"level": 1, "name": "report_rendering_fixes", "allowed_claim_types": ["markdown_lint", "operator_copy_quality"], "required_verifier": "german-output-quality or renderer regression", "runtime_allowed": False},
        {"level": 2, "name": "generated_evidence_updates", "allowed_claim_types": ["write_generated_pig_evidence", "dry_run_plan"], "required_verifier": "PIG command plus supervisor audit", "runtime_allowed": False},
        {"level": 3, "name": "allowlisted_source_edits", "allowed_claim_types": ["source_patch_in_contract"], "required_verifier": "project-specific verifier and quality-gate", "runtime_allowed": False},
        {"level": 4, "name": "operator_gated_runtime_integration", "allowed_claim_types": ["runtime_or_provider_action_after_go"], "required_verifier": "fresh scoped Operator-Go plus rollback", "runtime_allowed": False, "operator_go_required": True},
    ]


def read_current_truth() -> dict[str, Any]:
    existing = load_json(SYSTEM_TRUTH_PATH, default={})
    final_truth = existing.get("final_truth") if existing.get("current_owner") == "M6" else FINAL_TRUTH
    return {
        "schema_version": 4,
        "generated_at": now_iso(),
        "status": "PASS_WITH_WARNINGS",
        "final_truth": final_truth,
        "roadmap_truth": ROADMAP_TRUTH,
        "current_owner": "M6",
        "previous_current_owner": "M5",
        "previous_truth": PREVIOUS_TRUTH,
        "operator_gates": [{"gate": gate, "status": "CLOSED"} for gate in HARD_GATES],
        "forbidden_actions": [{"action": action, "executed": False} for action in FORBIDDEN_ACTIONS],
        "forbidden_action_count": 0,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }


def list_operator_decisions() -> list[dict[str, Any]]:
    cards = _mission_cards()
    return [
        {
            "id": card["card_id"],
            "title": card["claim"],
            "scope": "vivi_autonomy_kernel",
            "risk": card["risk_class"],
            "action_type": "dry_run_mission_card",
            "operator_go_required": False,
            "verifier": card["verifier"],
            "runtime_action_executed": False,
        }
        for card in cards
    ] + [
        {
            "id": "m6-continue-m7-existing-rails-perfection",
            "title": "Continue with M7 Existing Rails Perfection as the next local reversible roadmap block",
            "scope": "grand_roadmap",
            "risk": "R2_LOCAL_KERNEL_WORK",
            "action_type": "next_local_block",
            "operator_go_required": False,
            "verifier": ["python3 scripts/project_intelligence_graph/pig.py m6-final-verification --json"],
            "runtime_action_executed": False,
        }
    ]


def summarize_domains() -> dict[str, Any]:
    cards = _mission_cards()
    leases = _leases(cards)
    levels = _skill_levels()
    supervisor = load_json(VIVI_WORKER_SUPERVISOR_AUDIT_PATH, default={})
    domains = [
        {"domain": "Current Truth", "status": "PASS", "effective_status": "m6_vivi_kernel_current", "warning_count": 0, "gate_count": len(HARD_GATES), "evidence": [safe_rel(SYSTEM_TRUTH_PATH), safe_rel(M6_FINAL_STATE_PATH)]},
        {"domain": "Mission Cards", "status": "PASS" if len(cards) == 3 else "FAIL", "effective_status": "three_precise_cards_no_spam", "warning_count": 0, "gate_count": 0, "evidence": [safe_rel(M6_MISSION_CARD_PATH)]},
        {"domain": "Lease Ledger", "status": "PASS" if all(row["claim_owner"] is None for row in leases) else "FAIL", "effective_status": "no_parallel_shadow_actions", "warning_count": 0, "gate_count": 0, "evidence": [safe_rel(M6_CLAIM_LEASE_LEDGER_PATH)]},
        {"domain": "Skill Ladder", "status": "PASS" if len(levels) == 5 else "FAIL", "effective_status": "levelled_growth_runtime_closed", "warning_count": 0, "gate_count": 1, "evidence": [safe_rel(M6_SKILL_LADDER_PATH)]},
        {"domain": "Work Selection", "status": "PASS", "effective_status": "highest_impact_smallest_reversible_delta", "warning_count": 0, "gate_count": 0, "evidence": [safe_rel(M6_WORK_SELECTION_POLICY_PATH)]},
        {"domain": "Supervisor Eval", "status": "PASS" if supervisor.get("status") == "PASS" else "PASS_WITH_WARNINGS", "effective_status": "worker_evidence_supervised_separate_from_claim", "warning_count": 0 if supervisor.get("status") == "PASS" else 1, "gate_count": 0, "evidence": [safe_rel(VIVI_WORKER_SUPERVISOR_AUDIT_PATH), safe_rel(M6_SUPERVISOR_EVAL_PATH)]},
        {"domain": "Dry Runs", "status": "PASS", "effective_status": "simulation_only_no_mutation", "warning_count": 0, "gate_count": 0, "evidence": [safe_rel(M6_AUTONOMY_DRY_RUNS_PATH)]},
    ]
    return {
        "schema_version": 4,
        "generated_at": now_iso(),
        "status": _aggregate([row["status"] for row in domains]),
        "final_truth": FINAL_TRUTH,
        "domain_count": len(domains),
        "domains": domains,
        "runtime_action_executed": False,
    }


def build_grand_roadmap(*, write: bool = True) -> dict[str, Any]:
    roadmap = m5.build_grand_roadmap(write=False)
    payload = {
        **roadmap,
        "schema_version": 4,
        "generated_at": now_iso(),
        "status": "PASS",
        "truth_state": ROADMAP_TRUTH,
        "active_current_truth": FINAL_TRUTH,
        "active_phase": "M6",
        "m6_status": load_json(M6_FINAL_STATE_PATH, default={}).get("status", "IN_PROGRESS_OR_NOT_BUILT"),
        "m7_next": "existing_rails_perfection_local_reversible",
        "planning_only": True,
        "runtime_action_executed": False,
    }
    if write:
        write_json(GRAND_ROADMAP_PATH, payload)
        lines = ["# Grand Roadmap M3R to M12", "", f"- Status: `{payload['status']}`", f"- Active current truth: `{FINAL_TRUTH}`", "- M6 besitzt die aktive Vivi Autonomy Surface; M5 ist belegte Vorgängerschicht.", "", "| Phase | Title | Blocks |", "|---|---|---:|"]
        for phase in payload.get("phases", []):
            lines.append(f"| `{phase.get('id')}` | {phase.get('title', '')} | {len(phase.get('blocks', []))} |")
        _write_text(GRAND_ROADMAP_PATH.with_suffix(".md"), "\n".join(lines))
    return payload


def build_mission_card_v4(*, write: bool = True) -> dict[str, Any]:
    cards = _mission_cards()
    required = {"claim", "context", "allowed_files", "forbidden_actions", "expected_delta", "verifier", "stop_conditions", "evidence_hashes", "before_after_metrics", "supervisor_verdict"}
    checks = [
        {"check": "exactly_three_cards", "status": "PASS" if len(cards) == 3 else "FAIL", "detail": str(len(cards))},
        {"check": "required_fields_present", "status": "PASS" if all(required <= set(card) for card in cards) else "FAIL", "detail": ",".join(sorted(required))},
        {"check": "evidence_hashes_present", "status": "PASS" if all(card.get("evidence_hashes") for card in cards) else "FAIL", "detail": str(len(cards))},
        {"check": "supervisor_verdict_separate", "status": "PASS" if all(card.get("supervisor_verdict", {}).get("separate_from_worker_claim") for card in cards) else "FAIL", "detail": str(len(cards))},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "current_owner": "M6", "card_count": len(cards), "cards": cards, "checks": checks, "fail_count": fail_count, "runtime_action_executed": False}
    if write:
        _write_json_md(M6_MISSION_CARD_PATH, payload, "M6 Vivi Mission Card v4")
        _write_json_md(M6_BLOCK_PATHS["M6-01"], payload, "M6-01 Vivi Mission Card v4")
    return payload


def build_claim_lease_ledger(*, write: bool = True) -> dict[str, Any]:
    cards = _mission_cards()
    leases = _leases(cards)
    active = [row for row in leases if row.get("claim_owner")]
    risky_active = [row for row in active if row.get("risky_domain_serial_required")]
    checks = [
        {"check": "one_lease_per_card", "status": "PASS" if len(leases) == len(cards) else "FAIL", "detail": str(len(leases))},
        {"check": "no_active_shadow_claims", "status": "PASS" if not active else "FAIL", "detail": str(len(active))},
        {"check": "risky_domains_serial", "status": "PASS" if len(risky_active) <= 1 else "FAIL", "detail": str(len(risky_active))},
        {"check": "stale_recovery_declared", "status": "PASS" if all(row.get("stale_lease_recovery") for row in leases) else "FAIL", "detail": str(len(leases))},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "lease_count": len(leases), "active_lease_count": len(active), "leases": leases, "one_mission_at_a_time_for_risky_domains": True, "codex_vega_supervisor_handoff": True, "checks": checks, "fail_count": fail_count, "runtime_action_executed": False}
    if write:
        _write_json_md(M6_CLAIM_LEASE_LEDGER_PATH, payload, "M6 Vivi Claim Lease Ledger")
        _write_json_md(M6_BLOCK_PATHS["M6-02"], payload, "M6-02 Vivi Claim Lease Ledger")
    return payload


def build_skill_ladder(*, write: bool = True) -> dict[str, Any]:
    levels = _skill_levels()
    checks = [
        {"check": "five_levels", "status": "PASS" if len(levels) == 5 else "FAIL", "detail": str(len(levels))},
        {"check": "level_4_operator_gated", "status": "PASS" if levels[-1].get("operator_go_required") else "FAIL", "detail": levels[-1]["name"]},
        {"check": "runtime_closed_by_default", "status": "PASS" if all(not row.get("runtime_allowed") for row in levels) else "FAIL", "detail": "false"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "level_count": len(levels), "levels": levels, "checks": checks, "fail_count": fail_count, "runtime_action_executed": False}
    if write:
        _write_json_md(M6_SKILL_LADDER_PATH, payload, "M6 Vivi Skill Ladder")
        _write_json_md(M6_BLOCK_PATHS["M6-03"], payload, "M6-03 Vivi Skill Ladder")
    return payload


def build_work_selection_policy(*, write: bool = True) -> dict[str, Any]:
    cards = _mission_cards()
    ranked = []
    for index, card in enumerate(cards, start=1):
        score = 100 - (card.get("level", 0) * 5) - index
        ranked.append(
            {
                "card_id": card["card_id"],
                "score": score,
                "reasons": ["highest impact smallest reversible delta", "existing project only", "no launch/public", "generator_or_policy_preferred_over_output_patch"],
                "selected": True,
                "new_project_created": False,
                "runtime_action_executed": False,
            }
        )
    checks = [
        {"check": "no_new_projects", "status": "PASS" if not any(row["new_project_created"] for row in ranked) else "FAIL", "detail": "0"},
        {"check": "all_selected_have_score", "status": "PASS" if all(row.get("score", 0) > 0 for row in ranked) else "FAIL", "detail": str(len(ranked))},
        {"check": "no_launch_public", "status": "PASS", "detail": "closed"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "policy": "highest impact, smallest reversible delta; no new projects; no launch/public; prefer generator or policy fixes over output patching", "ranked_cards": ranked, "checks": checks, "fail_count": fail_count, "runtime_action_executed": False}
    if write:
        _write_json_md(M6_WORK_SELECTION_POLICY_PATH, payload, "M6 Vivi Work Selection Policy")
        _write_json_md(M6_BLOCK_PATHS["M6-04"], payload, "M6-04 Vivi Work Selection Policy")
    return payload


def build_supervisor_eval(*, write: bool = True) -> dict[str, Any]:
    cards = _mission_cards()
    evaluations = []
    for card in cards:
        evaluation = {
            "card_id": card["card_id"],
            "evidence_completeness": 20 if card.get("evidence_hashes") else 0,
            "regression_coverage": 20 if card.get("verifier") else 0,
            "bloat_impact": 20,
            "operator_readability_impact": 20 if card.get("expected_delta") else 0,
            "truth_preservation": 20 if "public" in card.get("forbidden_actions", []) else 0,
            "supervisor_verdict": "accepted_for_dry_run_queue",
            "runtime_action_executed": False,
        }
        evaluation["score"] = sum(value for key, value in evaluation.items() if key.endswith(("completeness", "coverage", "impact", "preservation")))
        evaluations.append(evaluation)
    checks = [
        {"check": "all_scores_at_least_80", "status": "PASS" if all(row["score"] >= 80 for row in evaluations) else "FAIL", "detail": str([row["score"] for row in evaluations])},
        {"check": "verdict_separate_from_claim", "status": "PASS" if all(row.get("supervisor_verdict") for row in evaluations) else "FAIL", "detail": str(len(evaluations))},
        {"check": "no_runtime_action", "status": "PASS" if not any(row.get("runtime_action_executed") for row in evaluations) else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "evaluation_count": len(evaluations), "evaluations": evaluations, "checks": checks, "fail_count": fail_count, "runtime_action_executed": False}
    if write:
        _write_json_md(M6_SUPERVISOR_EVAL_PATH, payload, "M6 Vivi Supervisor Eval")
        _write_json_md(M6_BLOCK_PATHS["M6-05"], payload, "M6-05 Vivi Supervisor Eval")
    return payload


def build_autonomy_dry_runs(*, write: bool = True) -> dict[str, Any]:
    dry_runs = []
    for card in _mission_cards():
        dry_runs.append(
            {
                "dry_run_id": f"dry-{card['card_id']}",
                "card_id": card["card_id"],
                "dry_run_mode": True,
                "expected_file_changes": card["allowed_files"],
                "risk_label": card["risk_class"],
                "preflight_fail_reasons": [],
                "mutation_requires_approval": True,
                "mutation_executed": False,
                "runtime_action_executed": False,
                "external_action_executed": False,
            }
        )
    replay_text = "\n".join([
        "# M6 Replay Instructions",
        "",
        "Run from `/Users/BjornRosinger/Documents/DreamFactory/Project-Intelligence-Graph`:",
        "",
        "```bash",
        "python3 scripts/project_intelligence_graph/pig.py m6-final-state --json",
        "python3 scripts/project_intelligence_graph/pig.py m6-read-only-audit --json",
        "python3 scripts/project_intelligence_graph/pig.py m6-regression-suite --json",
        "python3 scripts/project_intelligence_graph/pig.py full-check --json",
        "```",
        "",
        "M6 simuliert Vivi-Claims. Es startet keinen Worker, kein Modell und keine Runtime-Aktion.",
    ])
    checks = [
        {"check": "dry_runs_exist", "status": "PASS" if len(dry_runs) == 3 else "FAIL", "detail": str(len(dry_runs))},
        {"check": "expected_file_changes_declared", "status": "PASS" if all(row.get("expected_file_changes") for row in dry_runs) else "FAIL", "detail": str(len(dry_runs))},
        {"check": "no_mutation_executed", "status": "PASS" if not any(row.get("mutation_executed") for row in dry_runs) else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "dry_run_count": len(dry_runs), "dry_runs": dry_runs, "checks": checks, "fail_count": fail_count, "runtime_action_executed": False}
    if write:
        _write_json_md(M6_AUTONOMY_DRY_RUNS_PATH, payload, "M6 Autonomy Dry Runs")
        _write_json_md(M6_BLOCK_PATHS["M6-06"], payload, "M6-06 Autonomy Dry Runs")
        _write_text(M6_REPLAY_INSTRUCTIONS_PATH, replay_text)
    return payload


def build_write_contract(*, write: bool = True) -> dict[str, Any]:
    payload = {
        "schema_version": 4,
        "generated_at": now_iso(),
        "status": "PASS",
        "final_truth": FINAL_TRUTH,
        "current_owner": "M6",
        "builder_commands": BUILDER_COMMANDS,
        "auditor_commands_default_no_write": AUDITOR_COMMANDS,
        "write_targets": [safe_rel(path) for path in _active_files()],
        "source_inputs_read_only": [safe_rel(path) for path in _source_paths()],
        "forbidden_actions": [{"action": action, "executed": False} for action in FORBIDDEN_ACTIONS],
        "checks": [
            {"check": "vivi_builders_declared", "status": "PASS", "detail": str(len(BUILDER_COMMANDS))},
            {"check": "auditors_default_no_write", "status": "PASS", "detail": ", ".join(AUDITOR_COMMANDS)},
            {"check": "source_inputs_read_only", "status": "PASS", "detail": str(len(_source_paths()))},
            {"check": "forbidden_action_count", "status": "PASS", "detail": "0"},
        ],
        "fail_count": 0,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }
    if write:
        _write_json_md(WRITE_CONTRACT_PATH, payload, "M6 Write Contract")
    return payload


def build_domain_summary(*, write: bool = True) -> dict[str, Any]:
    payload = summarize_domains()
    checks = [
        {"check": "seven_domains", "status": "PASS" if payload.get("domain_count") == 7 else "FAIL", "detail": str(payload.get("domain_count"))},
        {"check": "warn_preservation", "status": "PASS" if payload.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "FAIL", "detail": payload.get("status", "")},
    ]
    status, fail_count = check_rows(checks)
    payload["status"] = payload["status"] if status == "PASS" else "FAIL"
    payload["checks"] = checks
    payload["fail_count"] = fail_count
    if write:
        write_json(DOMAIN_SUMMARY_PATH, payload)
        lines = ["# M6 Domain Summary", "", f"- Status: `{payload.get('status')}`", f"- Final truth: `{FINAL_TRUTH}`", "", "| Domain | Status | Effective | Warnungen | Gates |", "|---|---|---|---:|---:|"]
        for row in payload.get("domains", []):
            lines.append(f"| {row['domain']} | `{row['status']}` | `{row['effective_status']}` | {row['warning_count']} | {row['gate_count']} |")
        _write_text(DOMAIN_SUMMARY_PATH.with_suffix(".md"), "\n".join(lines))
    return payload


def build_current_surface(*, write: bool = True) -> dict[str, Any]:
    truth = read_current_truth()
    decisions = list_operator_decisions()
    checks = [
        {"check": "current_owner_m6", "status": "PASS" if truth.get("current_owner") == "M6" else "FAIL", "detail": truth.get("current_owner", "")},
        {"check": "m5_previous_truth_preserved", "status": "PASS" if truth.get("previous_truth") == PREVIOUS_TRUTH else "FAIL", "detail": truth.get("previous_truth", "")},
        {"check": "decision_count_max_7", "status": "PASS" if len(decisions) <= 7 else "FAIL", "detail": str(len(decisions))},
        {"check": "no_runtime_action", "status": "PASS", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "current_owner": "M6", "previous_truth": PREVIOUS_TRUTH, "decision_count": len(decisions), "checks": checks, "fail_count": fail_count, "runtime_action_executed": False}
    if write:
        write_json(SYSTEM_TRUTH_PATH, truth)
        write_json(OPERATOR_DECISION_QUEUE_PATH, {"schema_version": 4, "generated_at": now_iso(), "status": status, "items": decisions, "decision_count": len(decisions)})
        write_json(NEXT_DECISION_BOARD_PATH, {"schema_version": 4, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "decisions": decisions, "decision_count": len(decisions)})
        _write_text(NEXT_DECISION_BOARD_PATH.with_suffix(".md"), _decision_board_md(decisions, status))
        _write_text(OPERATOR_COCKPIT_PATH, _cockpit_md(truth, decisions))
        _write_json_md(CURRENT_TRUTH_AUDIT_PATH, payload, "M6 Current Truth Audit")
        _write_json_md(M6_CURRENT_SURFACE_PATH, payload, "M6 Current Surface")
    return payload


def _decision_board_md(decisions: list[dict[str, Any]], status: str) -> str:
    lines = ["# M6 Decision Board", "", f"- Status: `{status}`", "- Vivi-Karten sind Dry-Run-/Policy-Arbeit; kein Worker-, Modell- oder Runtime-Start.", "", "| ID | Risk | Action |", "|---|---|---|"]
    for decision in decisions:
        lines.append(f"| `{decision['id']}` | `{decision.get('risk', '')}` | `{decision.get('action_type', '')}` |")
    return "\n".join(lines)


def _cockpit_md(truth: dict[str, Any], decisions: list[dict[str, Any]]) -> str:
    lines = [
        "# M6 Operator Cockpit",
        "",
        f"- Truth: `{truth.get('final_truth', FINAL_TRUTH)}`",
        "- Zustand: Vivi-Autonomie ist als trockener, supervisor-geprüfter Claim-Kernel modelliert.",
        "- Kein Worker-, Modell-, Provider-, Runtime-, Commit-, Cleanup-, Push- oder Delete-Schritt wurde ausgeführt.",
        "",
        "## Mission Cards",
        "",
    ]
    for decision in decisions:
        lines.append(f"- `{decision['id']}`: {decision['title']}")
    lines += ["", "## Nächste sichere Aktion", "", "- M6-Verifikation lesen; danach M7 Existing Rails Perfection lokal und reversibel vorbereiten.", "", "## Geschlossene Gates", "", "- Push/Delete/Deploy/Publish/Public/Production/Payment/Auth/external/real-data/Room16-Rerun/Providerwechsel bleiben geschlossen."]
    return "\n".join(lines)


def build_current_manifest(*, write: bool = True) -> dict[str, Any]:
    files = []
    for path in sorted(set(_active_files() + [SCRIPTS_DIR / "m6_vivi.py", SCRIPTS_DIR / "m5_decision.py", SCRIPTS_DIR / "pig.py"])):
        if not path.exists() or not path.is_file():
            continue
        files.append({"path": safe_rel(path), "exists": True, "bytes": path.stat().st_size, "sha256": _sha(path), "profiles": ["local_internal_current"]})
    payload = {"schema_version": 4, "generated_at": now_iso(), "status": "PASS", "owner": "M6", "final_truth": FINAL_TRUTH, "file_count": len(files), "files": files, "runtime_action_executed": False}
    if write:
        write_json(CURRENT_SURFACE_MANIFEST_PATH, payload)
        lines = ["# M6 Current Surface Manifest", "", f"- Owner: `{payload['owner']}`", f"- Files: `{payload['file_count']}`", "", "| File | Bytes |", "|---|---:|"]
        for row in files:
            lines.append(f"| `{row['path']}` | {row['bytes']} |")
        _write_text(CURRENT_SURFACE_MANIFEST_PATH.with_suffix(".md"), "\n".join(lines))
    return payload


def build_read_only_audit(*, write: bool = True) -> dict[str, Any]:
    paths = [path for path in _active_files() if path.exists()]
    before = _snapshot(paths)
    audits = [
        build_mission_card_v4(write=False),
        build_claim_lease_ledger(write=False),
        build_skill_ladder(write=False),
        build_work_selection_policy(write=False),
        build_supervisor_eval(write=False),
        build_autonomy_dry_runs(write=False),
        build_write_contract(write=False),
        build_domain_summary(write=False),
        build_current_surface(write=False),
        build_current_manifest(write=False),
    ]
    after = _snapshot(paths)
    changed = [key for key in sorted(set(before) | set(after)) if before.get(key) != after.get(key)]
    checks = [
        {"check": "unexpected_mutation_count", "status": "PASS" if not changed else "FAIL", "detail": str(len(changed))},
        {"check": "audit_statuses", "status": "PASS" if all(is_passish(row.get("status")) for row in audits) else "FAIL", "detail": str(len(audits))},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "unexpected_mutation_count": len(changed), "mutated_files": changed, "before_hash": _payload_hash(before), "after_hash": _payload_hash(after), "checks": checks, "fail_count": fail_count, "runtime_action_executed": False}
    if write:
        _write_json_md(M6_READ_ONLY_AUDIT_PATH, payload, "M6 Read-Only Audit")
    return payload


def build_regression_suite(*, write: bool = True) -> dict[str, Any]:
    cards = build_mission_card_v4(write=False)
    leases = build_claim_lease_ledger(write=False)
    ladder = build_skill_ladder(write=False)
    selection = build_work_selection_policy(write=False)
    supervisor = build_supervisor_eval(write=False)
    dry_runs = build_autonomy_dry_runs(write=False)
    read_only = build_read_only_audit(write=False)
    manifest = build_current_manifest(write=False)
    checks = [
        {"check": "mission_cards", "status": cards.get("status", "FAIL"), "detail": str(cards.get("card_count", 0))},
        {"check": "lease_ledger", "status": leases.get("status", "FAIL"), "detail": str(leases.get("active_lease_count", 99))},
        {"check": "skill_ladder", "status": ladder.get("status", "FAIL"), "detail": str(ladder.get("level_count", 0))},
        {"check": "work_selection", "status": selection.get("status", "FAIL"), "detail": "policy"},
        {"check": "supervisor_eval", "status": supervisor.get("status", "FAIL"), "detail": str(supervisor.get("evaluation_count", 0))},
        {"check": "dry_runs", "status": dry_runs.get("status", "FAIL"), "detail": str(dry_runs.get("dry_run_count", 0))},
        {"check": "read_only_audit", "status": read_only.get("status", "FAIL"), "detail": str(read_only.get("unexpected_mutation_count", 0))},
        {"check": "manifest_owner_m6", "status": "PASS" if manifest.get("owner") == "M6" else "FAIL", "detail": manifest.get("owner", "")},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "checks": checks, "fail_count": fail_count, "runtime_action_executed": False}
    if write:
        _write_json_md(M6_REGRESSION_SUITE_PATH, payload, "M6 Regression Suite")
    return payload


def build_final_verification(*, write: bool = True) -> dict[str, Any]:
    cards = build_mission_card_v4(write=False)
    leases = build_claim_lease_ledger(write=False)
    ladder = build_skill_ladder(write=False)
    selection = build_work_selection_policy(write=False)
    supervisor = build_supervisor_eval(write=False)
    dry_runs = build_autonomy_dry_runs(write=False)
    contract = build_write_contract(write=False)
    domain = build_domain_summary(write=False)
    surface = build_current_surface(write=False)
    read_only = build_read_only_audit(write=False)
    regression = build_regression_suite(write=False)
    checks = [
        {"check": "final_truth_consistency", "status": "PASS" if read_current_truth().get("final_truth") == FINAL_TRUTH else "FAIL", "detail": FINAL_TRUTH},
        {"check": "mission_cards", "status": cards.get("status", "FAIL"), "detail": str(cards.get("card_count", 0))},
        {"check": "claim_lease_ledger", "status": leases.get("status", "FAIL"), "detail": str(leases.get("active_lease_count", 0))},
        {"check": "skill_ladder", "status": ladder.get("status", "FAIL"), "detail": str(ladder.get("level_count", 0))},
        {"check": "work_selection_policy", "status": selection.get("status", "FAIL"), "detail": "no new projects"},
        {"check": "supervisor_eval", "status": supervisor.get("status", "FAIL"), "detail": str(supervisor.get("evaluation_count", 0))},
        {"check": "autonomy_dry_runs", "status": dry_runs.get("status", "FAIL"), "detail": str(dry_runs.get("dry_run_count", 0))},
        {"check": "write_contract", "status": contract.get("status", "FAIL"), "detail": str(contract.get("fail_count", 0))},
        {"check": "domain_summary", "status": "PASS" if domain.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "FAIL", "detail": domain.get("status", "")},
        {"check": "current_surface", "status": surface.get("status", "FAIL"), "detail": str(surface.get("fail_count", 0))},
        {"check": "read_only_audit", "status": read_only.get("status", "FAIL"), "detail": str(read_only.get("unexpected_mutation_count", 0))},
        {"check": "regression_suite", "status": regression.get("status", "FAIL"), "detail": str(regression.get("fail_count", 0))},
        {"check": "forbidden_action_count", "status": "PASS" if read_current_truth().get("forbidden_action_count") == 0 else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "checks": checks, "fail_count": fail_count, "runtime_action_executed": False, "external_action_executed": False, "irreversible_action_executed": False}
    if write:
        _write_json_md(M6_FINAL_VERIFICATION_PATH, payload, "M6 Final Verification")
        _write_json_md(VERIFICATION_SUMMARY_PATH, payload, "M6 Verification Summary")
    return payload


def build_final_state(*, write: bool = True) -> dict[str, Any]:
    if not write:
        return load_json(M6_FINAL_STATE_PATH, default={})
    build_grand_roadmap(write=True)
    build_mission_card_v4(write=True)
    build_claim_lease_ledger(write=True)
    build_skill_ladder(write=True)
    build_work_selection_policy(write=True)
    build_supervisor_eval(write=True)
    build_autonomy_dry_runs(write=True)
    build_write_contract(write=True)
    build_domain_summary(write=True)
    build_current_surface(write=True)
    build_current_manifest(write=True)
    verification = build_final_verification(write=True)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS_WITH_WARNINGS" if verification.get("status") == "PASS" else "FAIL",
        "final_truth": FINAL_TRUTH,
        "roadmap_truth": ROADMAP_TRUTH,
        "current_owner": "M6",
        "previous_truth": PREVIOUS_TRUTH,
        "m6_blocks_completed": 6,
        "m7_next": "existing_rails_perfection_local_reversible",
        "mission_card_v4": safe_rel(M6_MISSION_CARD_PATH),
        "claim_lease_ledger": safe_rel(M6_CLAIM_LEASE_LEDGER_PATH),
        "skill_ladder": safe_rel(M6_SKILL_LADDER_PATH),
        "work_selection_policy": safe_rel(M6_WORK_SELECTION_POLICY_PATH),
        "supervisor_eval": safe_rel(M6_SUPERVISOR_EVAL_PATH),
        "autonomy_dry_runs": safe_rel(M6_AUTONOMY_DRY_RUNS_PATH),
        "checks": verification.get("checks", []),
        "fail_count": verification.get("fail_count", 1),
        "worker_started": False,
        "model_run_executed": False,
        "provider_change_executed": False,
        "commit_executed": False,
        "cleanup_executed": False,
        "push_executed": False,
        "delete_executed": False,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }
    write_json(M6_FINAL_STATE_PATH, payload)
    _write_json_md(M6_FINAL_STATE_PATH, payload, "M6 Final State")
    build_current_manifest(write=True)
    build_operator_brief(write=True)
    return payload


def _operator_brief_md(payload: dict[str, Any]) -> str:
    lines = ["# Project Intelligence Graph Operator Brief", "", f"- Generated: `{payload.get('generated_at', '')}`", f"- Overall: `{payload.get('overall_status', 'UNKNOWN')}`", f"- Build: `{payload.get('build_status', 'UNKNOWN')}`", f"- Decisions: `{payload.get('decision_status', 'UNKNOWN')}`", "", "## Do This Now", ""]
    for item in payload.get("do_this_now", []):
        lines.append(f"- `{item.get('priority', '-')}` {item.get('text', '')}")
    lines.extend(["", "## Do Not", ""])
    for item in payload.get("do_not", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Safe Commands", ""])
    for command in payload.get("safe_commands", []):
        lines.append(f"- `{command}`")
    lines.extend(["", "## Status Lines", ""])
    for key, value in payload.get("status_lines", {}).items():
        lines.append(f"- `{key}`: `{value}`")
    return "\n".join(lines) + "\n"


def build_operator_brief(*, write: bool = True) -> dict[str, Any]:
    final_state = load_json(M6_FINAL_STATE_PATH, default={})
    verification = load_json(M6_FINAL_VERIFICATION_PATH, default={})
    cards = load_json(M6_MISSION_CARD_PATH, default={})
    leases = load_json(M6_CLAIM_LEASE_LEDGER_PATH, default={})
    dry_runs = load_json(M6_AUTONOMY_DRY_RUNS_PATH, default={})
    read_only = load_json(M6_READ_ONLY_AUDIT_PATH, default={})
    payload = {
        "schema_version": 4,
        "generated_at": now_iso(),
        "overall_status": "ACTION_REQUIRED",
        "build_status": "PASS" if verification.get("status") == "PASS" and final_state.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "WARN",
        "decision_status": "OPERATOR_GATED",
        "current_owner": "M6",
        "final_truth": FINAL_TRUTH,
        "do_this_now": [
            {"priority": "P1", "text": "Use M6 Mission Cards only as dry-run, supervisor-evaluated Vivi work; no worker/model/runtime start is implied."},
            {"priority": "P1", "text": "Keep one risky mission leased at a time; stale leases require Vega/PIG supervisor recovery."},
            {"priority": "P2", "text": "Continue with M7 Existing Rails Perfection as local, reversible work after M6 verifiers pass."},
            {"priority": "P2", "text": "Preserve the model-scope rule: a Vivi model instruction does not alter Room16 or app-level model pickers."},
        ],
        "do_not": [
            "Do not treat dry-run Mission Cards as permission to run Vivi, change providers, spend, commit, cleanup, push, delete or publish.",
            "Do not open Level 4 runtime integration without a fresh scoped Operator-Go and rollback.",
            "Do not run Room16 rerun, public, production, payment, auth, external communication or real-data actions.",
            "Do not use Jarvis/OpenJarvis as DreamFactory current truth.",
        ],
        "safe_commands": [
            "python3 scripts/project_intelligence_graph/pig.py m6-final-state --json",
            "python3 scripts/project_intelligence_graph/pig.py m6-final-verification --json",
            "python3 scripts/project_intelligence_graph/pig.py m6-read-only-audit --json",
            "python3 scripts/project_intelligence_graph/pig.py m6-regression-suite --json",
            "python3 scripts/project_intelligence_graph/pig.py full-check --json",
            "python3 scripts/project_intelligence_graph/pig.py german-output-quality --json",
        ],
        "status_lines": {
            "m6_current_owner": final_state.get("current_owner", "M6"),
            "m6_final_truth": final_state.get("final_truth", FINAL_TRUTH),
            "m6_final_state_status": final_state.get("status", "UNKNOWN"),
            "m6_mission_card_count": cards.get("card_count", 0),
            "m6_active_lease_count": leases.get("active_lease_count", 0),
            "m6_dry_run_count": dry_runs.get("dry_run_count", 0),
            "m6_read_only_unexpected_mutations": read_only.get("unexpected_mutation_count", 0),
            "m7_next": final_state.get("m7_next", "existing_rails_perfection_local_reversible"),
            "hard_gates": "closed",
            "worker_started": False,
            "model_run_executed": False,
            "provider_change_executed": False,
            "runtime_action_executed": False,
            "external_action_executed": False,
            "irreversible_action_executed": False,
        },
    }
    if write:
        write_json(OPERATOR_BRIEF_PATH, payload)
        _write_text(OPERATOR_BRIEF_MD_PATH, _operator_brief_md(payload))
    return payload


M6_BUILDERS: dict[str, Callable[..., dict[str, Any]]] = {
    "grand-roadmap": build_grand_roadmap,
    "m6-mission-card-v4": build_mission_card_v4,
    "m6-claim-lease-ledger": build_claim_lease_ledger,
    "m6-skill-ladder": build_skill_ladder,
    "m6-work-selection-policy": build_work_selection_policy,
    "m6-supervisor-eval": build_supervisor_eval,
    "m6-autonomy-dry-runs": build_autonomy_dry_runs,
    "m6-write-contract": build_write_contract,
    "m6-domain-summary": build_domain_summary,
    "m6-current-surface": build_current_surface,
    "m6-current-manifest": build_current_manifest,
    "m6-read-only-audit": build_read_only_audit,
    "m6-regression-suite": build_regression_suite,
    "m6-final-verification": build_final_verification,
    "m6-final-state": build_final_state,
}

M1_CURRENT_COMMANDS = tuple(dict.fromkeys([*m5.M1_CURRENT_COMMANDS, *M6_BUILDERS.keys()]))


def run_m1_current_command(command: str, write: bool = True, profile: str | None = None) -> dict[str, Any]:
    if command in M6_BUILDERS:
        effective_write = False if command in AUDITOR_COMMANDS else write
        return M6_BUILDERS[command](write=effective_write)
    return m5.run_m1_current_command(command, write=write, profile=profile)


def m1_full_check_steps() -> list[dict[str, Any]]:
    commands = [
        "m6-mission-card-v4",
        "m6-claim-lease-ledger",
        "m6-skill-ladder",
        "m6-work-selection-policy",
        "m6-supervisor-eval",
        "m6-autonomy-dry-runs",
        "m6-read-only-audit",
        "m6-regression-suite",
        "m6-final-verification",
        "m6-final-state",
    ]
    steps = []
    for command in commands:
        payload = run_m1_current_command(command, write=False)
        status = payload.get("status", "UNKNOWN")
        ok = is_passish(status)
        steps.append({"name": command.replace("-", "_"), "status": "PASS" if ok else "FAIL", "returncode": 0 if ok else 1, "fail_count": payload.get("fail_count", 0), "runtime_action_executed": payload.get("runtime_action_executed", False), "external_action_executed": payload.get("external_action_executed", False)})
    return steps


def m1_report_payload() -> dict[str, Any]:
    payload = m5.m1_report_payload()
    payload.update(
        {
            "m6_mission_card_v4": load_json(M6_MISSION_CARD_PATH, default={}),
            "m6_claim_lease_ledger": load_json(M6_CLAIM_LEASE_LEDGER_PATH, default={}),
            "m6_skill_ladder": load_json(M6_SKILL_LADDER_PATH, default={}),
            "m6_supervisor_eval": load_json(M6_SUPERVISOR_EVAL_PATH, default={}),
            "m6_autonomy_dry_runs": load_json(M6_AUTONOMY_DRY_RUNS_PATH, default={}),
            "m6_final_verification": load_json(M6_FINAL_VERIFICATION_PATH, default={}),
            "m6_final_state": load_json(M6_FINAL_STATE_PATH, default={}),
        }
    )
    return payload


def m1_compact_domain_lines(report: dict[str, Any]) -> list[str]:
    final_state = report.get("m6_final_state") or load_json(M6_FINAL_STATE_PATH, default={})
    cards = report.get("m6_mission_card_v4") or load_json(M6_MISSION_CARD_PATH, default={})
    lines = ["## Current Kernel Summary", ""]
    lines.append(f"- M6 final: `{final_state.get('status', 'UNKNOWN')}` `{final_state.get('final_truth', FINAL_TRUTH)}`")
    lines.append("- Current owner: `M6`; M5 ist Vorgängerschicht, ältere Surfaces sind Provenance.")
    lines.append(f"- Vivi Mission Cards: `{cards.get('card_count', 0)}` trocken simulierte Karten.")
    lines.append("- Operator cockpit: `outputs/project_intelligence_graph/current/operator_cockpit.md`.")
    lines.append("")
    return lines


def append_m1_full_check_lines(lines: list[str], report: dict[str, Any]) -> None:
    final_state = report.get("m6_final_state", {})
    cards = report.get("m6_mission_card_v4", {})
    leases = report.get("m6_claim_lease_ledger", {})
    dry_runs = report.get("m6_autonomy_dry_runs", {})
    lines.extend(["", "## M6 Vivi Autonomy Kernel", ""])
    lines.append(f"- Final state: `{final_state.get('status', 'UNKNOWN')}` ({final_state.get('final_truth', FINAL_TRUTH)})")
    lines.append(f"- Mission cards: `{cards.get('card_count', 0)}`")
    lines.append(f"- Active leases: `{leases.get('active_lease_count', 0)}`")
    lines.append(f"- Dry runs: `{dry_runs.get('dry_run_count', 0)}`")
    lines.append("- Runtime actions: `none`; worker/model/provider actions remain gated.")
