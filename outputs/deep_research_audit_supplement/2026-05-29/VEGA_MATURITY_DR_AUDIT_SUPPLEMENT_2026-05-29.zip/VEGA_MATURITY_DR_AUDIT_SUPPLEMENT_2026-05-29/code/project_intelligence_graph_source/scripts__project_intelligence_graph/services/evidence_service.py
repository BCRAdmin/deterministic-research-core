"""Evidence loading service facade."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from evidence_io import MISSING, load_json_optional, load_json_required


def required_evidence(path: Path) -> dict[str, Any]:
    return load_json_required(path)


def optional_evidence(path: Path) -> dict[str, Any] | object:
    return load_json_optional(path)


__all__ = ["MISSING", "optional_evidence", "required_evidence"]
