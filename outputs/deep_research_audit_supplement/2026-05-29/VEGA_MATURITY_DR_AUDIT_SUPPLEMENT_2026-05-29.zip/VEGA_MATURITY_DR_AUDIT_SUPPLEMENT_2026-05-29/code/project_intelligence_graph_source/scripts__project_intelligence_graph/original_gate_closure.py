"""M14 original-workspace gate closure mapping."""

from __future__ import annotations

import datetime as dt
import json
from pathlib import Path
from typing import Any

from report_markdown import render_report_markdown


REPORT_JSON_NAME = "m14_original_gate_failure_map.json"
REPORT_MD_NAME = "m14_original_gate_failure_map.md"
ROADMAP_JSON_NAME = "m14_night_run_roadmap.json"
ROADMAP_MD_NAME = "m14_night_run_roadmap.md"
SYSTEM_TRUTH_STATUS = "PASS_WITH_WARNINGS"

CASCADE_ROOTS = {
    "deep_research_ingestion": "portable_evidence_capsule",
    "vivi_worker_v3_supervisor_audit": "deep_research_ingestion",
    "lioncom_decision_cockpit_audit": "portable_evidence_capsule",
    "product_rail_matrix_audit": "lioncom_decision_cockpit_audit",
    "room16_qualitydecision_integration": "product_rail_matrix_audit",
    "kanzlei_synthetic_factory": "product_rail_matrix_audit",
    "m7_lioncom_operator_os": "lioncom_decision_cockpit_audit",
    "m7_lioncom_safe_bridge": "lioncom_decision_cockpit_audit",
    "m7_room16_truth_pipeline": "room16_qualitydecision_integration",
    "m7_kanzlei_synthetic_proof": "kanzlei_synthetic_factory",
    "m8_deep_research_ingestion_block": "deep_research_ingestion",
    "m8_evidence_capsule_factory": "portable_evidence_capsule",
}

OPERATOR_GATED_STEPS = {
    "quellwert_data_maturity",
    "license_dependency_governance",
    "release_train_activation",
    "maturity_state",
    "m7_quellwert_data_kernel",
}

SELF_REFERENCE_STEPS = {
    "pig_helper_extraction",
    "pig_helper_extraction_v2",
    "non_mutating_full_check_audit",
    "helper_module_size_report_v3",
    "b46_b55_final_state",
    "b28_b35_final_state",
    "m7_final_state",
    "m7_final_verification",
}

RECOVERABLE_STATUS_STEPS = {
    "status_semantics_matrix",
    "status_semantics_fixture_report",
    "contradiction_staleness_engine",
    "portable_evidence_capsule",
    "bundle_reference_lint",
    "evidence_budget_enforcer_test",
    "markdown_renderer_regression",
    "dirt_burndown_v2",
    "vivi_v3_3_supervisor_audit",
    "existing_rails_quality_delta_v2",
}

RECOVERABLE_STEP_PREFIXES = ("m7_", "m8_")


def is_recoverable_original_gate_step(step_name: str) -> bool:
    return (
        step_name in RECOVERABLE_STATUS_STEPS
        or step_name in CASCADE_ROOTS
        or step_name in OPERATOR_GATED_STEPS
        or step_name in SELF_REFERENCE_STEPS
        or any(step_name.startswith(prefix) for prefix in RECOVERABLE_STEP_PREFIXES)
    )

ARTIFACT_STATUS_FILES = [
    ("portable_evidence_capsule", "portable_evidence_capsule_audit.json"),
    ("deep_research_ingestion", "deep_research_ingestion_audit.json"),
    ("vivi_worker_v3_supervisor_audit", "vivi_worker_v3_supervisor_audit.json"),
    ("lioncom_decision_cockpit_audit", "lioncom_decision_cockpit_audit.json"),
    ("product_rail_matrix_audit", "product_rail_matrix_audit.json"),
    ("room16_qualitydecision_integration", "room16_quality_decision_integration_audit.json"),
    ("kanzlei_synthetic_factory", "kanzlei_synthetic_factory_audit.json"),
    ("quellwert_data_maturity", "quellwert_data_maturity_audit.json"),
    ("license_dependency_governance", "license_dependency_governance_audit.json"),
    ("release_train_activation", "release_train_activation_audit.json"),
    ("maturity_state", "maturity_state.json"),
    ("pig_helper_extraction", "pig_helper_extraction_report.json"),
    ("helper_module_size_report_v3", "helper_module_size_report_v3.json"),
    ("b46_b55_final_state", "b46_b55_final_state.json"),
]


def _utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def _read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _profile_statuses(dual_report: dict[str, Any]) -> dict[str, str]:
    statuses = dual_report.get("profile_statuses")
    if isinstance(statuses, dict):
        return {str(key): str(value) for key, value in statuses.items()}
    profiles = dual_report.get("profiles", [])
    if isinstance(profiles, list):
        return {
            str(item.get("profile_id")): str(item.get("status", "UNKNOWN"))
            for item in profiles
            if isinstance(item, dict) and item.get("profile_id")
        }
    return {}


def _non_pass_steps(full_check: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for step in full_check.get("steps", []):
        if not isinstance(step, dict):
            continue
        if step.get("status") != "PASS":
            rows.append({
                "name": str(step.get("name", "unknown_step")),
                "status": str(step.get("status", "UNKNOWN")),
                "detail": str(step.get("detail", "")),
                "source": "full_check_report.steps",
                "nested_checks": [
                    nested for nested in step.get("checks", [])
                    if isinstance(nested, dict) and nested.get("status") != "PASS"
                ],
            })
    return rows


def _artifact_failures(output_dir: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for name, file_name in ARTIFACT_STATUS_FILES:
        path = output_dir / file_name
        payload = _read_json(path, default={})
        if not isinstance(payload, dict) or not payload:
            continue
        status = str(payload.get("status", payload.get("truth_status", "UNKNOWN")))
        if status == "PASS":
            continue
        rows.append({
            "name": name,
            "status": status,
            "detail": _artifact_detail(payload),
            "source": file_name,
            "fail_count": payload.get("fail_count"),
            "warn_count": payload.get("warn_count"),
        })
    return rows


def _artifact_detail(payload: dict[str, Any]) -> str:
    for key in ("overall_truth", "next_safe_step", "truth_status", "system_truth_status", "final_truth"):
        value = payload.get(key)
        if value:
            return str(value)
    checks = [
        item for item in payload.get("checks", [])
        if isinstance(item, dict) and item.get("status") != "PASS"
    ]
    if checks:
        first = checks[0]
        return f"{first.get('check', first.get('name', 'check'))}: {first.get('detail', '')}"
    return ""


def _classify_failure(row: dict[str, Any]) -> dict[str, Any]:
    name = str(row.get("name", "unknown_step"))
    nested = row.get("nested_checks", [])
    nested_names = {
        str(item.get("name", item.get("check", "")))
        for item in nested
        if isinstance(item, dict)
    }
    if name == "selftest" and "hardening_fix_contracts" in nested_names:
        category = "local_contract_hygiene_gate"
        root_dependency = "hardening_fix_contracts"
        proposed_action = "Finish or tighten the active local hardening contract, then rerun selftest/full-check."
        risk_level = "low"
        safe_next_step = "Close M14.A only after validate-fix, unit tests and dual full-check pass."
    elif name == "portable_evidence_capsule":
        category = "portable_evidence_self_reference_root"
        root_dependency = "full_check_report plus m13_dual_verification_report"
        proposed_action = "Convert the evidence claim from raw full-check PASS to dual-truth PASS_WITH_WARNINGS when B/C pass and A remains visible."
        risk_level = "medium"
        safe_next_step = "M14.B portable evidence dual-truth recovery with tests."
    elif name in CASCADE_ROOTS:
        category = "dependency_cascade"
        root_dependency = CASCADE_ROOTS[name]
        proposed_action = "Do not patch this follower directly; regenerate after the upstream root is repaired."
        risk_level = "low"
        safe_next_step = f"Wait for upstream {CASCADE_ROOTS[name]} block, then rerun this verifier."
    elif name in OPERATOR_GATED_STEPS:
        category = "operator_gated_domain_warning"
        root_dependency = "operator_or_external_gate"
        proposed_action = "Keep the warning explicit; do not force PASS without the real gate or a scoped local-only status semantic."
        risk_level = "high"
        safe_next_step = "M14.C normalize to PASS_WITH_WARNINGS where policy allows, without opening gates."
    elif name in SELF_REFERENCE_STEPS:
        category = "full_check_self_reference_followup"
        root_dependency = "current_full_check_status"
        proposed_action = "Recompute after the root gate is reduced; only then patch stale self-reference logic."
        risk_level = "medium"
        safe_next_step = "M14.D helper/final-state self-reference cleanup after M14.B/C."
    else:
        category = "unclassified_original_gate_failure"
        root_dependency = "unknown"
        proposed_action = "Inspect the source report before changing status semantics."
        risk_level = "medium"
        safe_next_step = "Create a narrow follow-up block if this remains after M14.B/C."

    return {
        "failure_id": f"m14a:{name}",
        "name": name,
        "status": row.get("status", "UNKNOWN"),
        "source": row.get("source", "unknown"),
        "detail": row.get("detail", ""),
        "category": category,
        "root_dependency": root_dependency,
        "proposed_action": proposed_action,
        "risk_level": risk_level,
        "safe_next_step": safe_next_step,
        "nested_non_pass_checks": nested,
    }


def _root_causes(classifications: list[dict[str, Any]], profile_statuses: dict[str, str]) -> list[dict[str, Any]]:
    roots: dict[str, dict[str, Any]] = {}
    if (
        profile_statuses.get("A_original_workspace_gate") != "PASS"
        and profile_statuses.get("B_pack_replay_mode") == "PASS"
        and profile_statuses.get("C_portable_core") == "PASS"
    ):
        roots["m13_original_gate_boundary"] = {
            "root_id": "m13_original_gate_boundary",
            "category": "m13_truth_boundary",
            "status": "WARN",
            "reason": "Profile A is not PASS while B/C are PASS; this is retained as visible original-workspace truth.",
            "safe_next_step": "Reduce original workspace blockers without changing B/C portable truth.",
        }
    for item in classifications:
        category = str(item.get("category"))
        if category == "dependency_cascade":
            continue
        root_id = str(item.get("root_dependency") or category)
        roots.setdefault(root_id, {
            "root_id": root_id,
            "category": category,
            "status": item.get("status", "UNKNOWN"),
            "reason": item.get("detail", ""),
            "safe_next_step": item.get("safe_next_step", ""),
        })
    return list(roots.values())


def _safe_blocks() -> list[dict[str, Any]]:
    return [
        {
            "block_id": "M14.A",
            "status": "current",
            "objective": "Map original-workspace gate failures without changing product/runtime gates.",
            "must_not_do": ["push", "deploy", "publish", "external_share", "auth_payment_runtime_activation"],
            "verifier": "python3 scripts/project_intelligence_graph/pig.py m14-original-gate-map --json",
        },
        {
            "block_id": "M14.B",
            "status": "ready_after_m14a",
            "objective": "Recover portable evidence self-reference using M13 dual truth, with warnings preserved.",
            "max_patch_surface": ["portable evidence claim semantics", "unit tests", "generated evidence"],
            "verifier": "portable-evidence, unittest, full-check --dual",
        },
        {
            "block_id": "M14.C",
            "status": "ready_after_m14b",
            "objective": "Separate operator-gated domain warnings from hard local failures where status semantics allow it.",
            "max_patch_surface": ["domain audit status semantics", "maturity state rollup"],
            "verifier": "quellwert/license/release/maturity-state plus full-check --dual",
        },
        {
            "block_id": "M14.D",
            "status": "ready_after_m14c",
            "objective": "Clean helper/final-state self-reference followers after true roots are reduced.",
            "max_patch_surface": ["helper extraction/final-state generators"],
            "verifier": "full-check --dual, quality-gate, long-run-audit",
        },
    ]


def _next_safe_block(classifications: list[dict[str, Any]]) -> tuple[str, str]:
    categories = {str(item.get("category")) for item in classifications}
    if "portable_evidence_self_reference_root" in categories:
        return "M14.B", "Start M14.B portable evidence dual-truth recovery."
    if "operator_gated_domain_warning" in categories:
        return "M14.C", "Start M14.C operator-gated warning/status-semantics normalization."
    if "full_check_self_reference_followup" in categories:
        return "M14.D", "Start M14.D helper and final-state self-reference cleanup."
    if "unclassified_original_gate_failure" in categories:
        return "M14.E", "Start M14.E narrow classification for remaining unclassified original-gate failures."
    return "monitoring_or_new_explicit_objective", "No classified local M14 root remains; rerun autonomy-governor before refilling."


def _build_roadmap(report: dict[str, Any]) -> dict[str, Any]:
    next_block, next_step = _next_safe_block(report.get("failure_classifications", []))
    return {
        "schema_version": 1,
        "generated_at": report["generated_at"],
        "status": report["status"],
        "system_truth_status": SYSTEM_TRUTH_STATUS,
        "night_mode": True,
        "candidate_only": True,
        "current_block": "M14.A",
        "safe_work_remaining": True,
        "blocks": _safe_blocks(),
        "next_safe_block": next_block if report.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "M14.A",
        "next_safe_step": next_step,
        "hard_gates_closed": report["hard_gates_closed"],
        "warnings": report["warnings"],
    }


def build_original_gate_failure_map(
    workspace: Path,
    *,
    output_dir: Path | None = None,
    write: bool = True,
) -> dict[str, Any]:
    workspace = Path(workspace).resolve()
    output_dir = Path(output_dir).resolve() if output_dir else workspace / "outputs" / "project_intelligence_graph"
    full_check = _read_json(output_dir / "full_check_report.json", default={})
    dual_report = _read_json(output_dir / "m13_dual_verification_report.json", default={})
    profile_statuses = _profile_statuses(dual_report if isinstance(dual_report, dict) else {})
    current_failures = _non_pass_steps(full_check if isinstance(full_check, dict) else {})
    artifact_failures = _artifact_failures(output_dir)
    seen = set()
    classifications: list[dict[str, Any]] = []
    for row in current_failures + artifact_failures:
        key = (row.get("name"), row.get("source"))
        if key in seen:
            continue
        seen.add(key)
        classifications.append(_classify_failure(row))

    b_c_pass = (
        profile_statuses.get("B_pack_replay_mode") == "PASS"
        and profile_statuses.get("C_portable_core") == "PASS"
    )
    a_visible_warning = profile_statuses.get("A_original_workspace_gate") not in {"", None, "PASS"}
    status = "PASS_WITH_WARNINGS" if classifications or a_visible_warning else "PASS"
    if not isinstance(full_check, dict) or not full_check:
        status = "ACTION_REQUIRED"

    next_block, next_step = _next_safe_block(classifications)
    report = {
        "schema_version": 1,
        "generated_at": _utc_now(),
        "status": status,
        "system_truth_status": SYSTEM_TRUTH_STATUS,
        "block_id": "M14.A",
        "workspace": str(workspace),
        "output_dir": str(output_dir),
        "candidate_only": True,
        "night_mode": True,
        "m13_profile_statuses": profile_statuses,
        "m13_kernel_b_c_pass": b_c_pass,
        "m13_original_gate_visible": a_visible_warning,
        "current_full_check_status": full_check.get("status", "MISSING") if isinstance(full_check, dict) else "MISSING",
        "current_full_check_non_pass_count": len(current_failures),
        "artifact_non_pass_count": len(artifact_failures),
        "failure_classifications": classifications,
        "root_causes": _root_causes(classifications, profile_statuses),
        "safe_blocks": _safe_blocks(),
        "next_safe_block": next_block,
        "next_safe_step": next_step,
        "hard_gates_closed": {
            "push": True,
            "deploy": True,
            "publish": True,
            "external_share": True,
            "auth_payment_runtime_activation": True,
            "m13_status_upgrade": True,
        },
        "warnings": [
            "This report is a closure map, not a status upgrade.",
            "B/C portable truth remains separate from A original-workspace truth.",
            "Operator-gated domain warnings must not be converted into PASS by convenience.",
            "Generated artifact failures are included because stale red reports can mask the current full-check frontier.",
        ],
    }
    roadmap = _build_roadmap(report)
    if write:
        _write_json(output_dir / REPORT_JSON_NAME, report)
        (output_dir / REPORT_MD_NAME).write_text(render_report_markdown("M14 Original Gate Failure Map", report), encoding="utf-8")
        _write_json(output_dir / ROADMAP_JSON_NAME, roadmap)
        (output_dir / ROADMAP_MD_NAME).write_text(render_report_markdown("M14 Night Run Roadmap", roadmap), encoding="utf-8")
    return report
