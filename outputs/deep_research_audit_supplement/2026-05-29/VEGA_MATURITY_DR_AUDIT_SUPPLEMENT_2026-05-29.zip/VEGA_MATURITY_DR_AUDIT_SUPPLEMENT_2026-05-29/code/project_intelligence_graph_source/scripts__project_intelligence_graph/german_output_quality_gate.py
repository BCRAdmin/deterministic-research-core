#!/usr/bin/env python3
"""Deterministic quality gate for German operator-facing prose outputs."""

from __future__ import annotations

import argparse
import datetime as dt
import json
import re
from pathlib import Path
from typing import Any

from config import resolve_runtime_paths

RUNTIME_PATHS = resolve_runtime_paths(__file__)
WORKSPACE = RUNTIME_PATHS.workspace
OUTPUT_DIR = RUNTIME_PATHS.outputs
DEFAULT_OUTPUT_JSON = OUTPUT_DIR / "german_output_quality_gate.json"
DEFAULT_OUTPUT_MD = OUTPUT_DIR / "german_output_quality_gate.md"

DEFAULT_EXCLUDE_PARTS = {
    ".git",
    ".next",
    ".pytest_cache",
    "node_modules",
    "dist",
    "build",
    "__pycache__",
    ".obsidian",
    "ATTACHMENTS",
    "LLM Deep Research",
}
TEXT_SUFFIXES = {".md", ".txt", ".html", ".tsx", ".ts", ".js", ".mjs", ".py"}
GERMAN_WORD_CHARS = "A-Za-zÄÖÜäöüß"

ASCII_UMLAUT_STEMS = (
    "abhaeng",
    "abschwaech",
    "aehn",
    "aelter",
    "aend",
    "aeuss",
    "anhaeng",
    "ausfuehr",
    "baeum",
    "beduerf",
    "beruecksichtig",
    "beruehr",
    "bestaet",
    "bloeck",
    "brueck",
    "drueck",
    "duerf",
    "einfueg",
    "einfuehr",
    "enthaelt",
    "ergaenz",
    "erwaehn",
    "faeh",
    "fehlschlaeg",
    "flaech",
    "fluendig",
    "frueh",
    "fueg",
    "fuehr",
    "fuer",
    "gedaechtnis",
    "gehoer",
    "geraet",
    "groess",
    "gruen",
    "gueltig",
    "haelf",
    "haeng",
    "haert",
    "haett",
    "huell",
    "itaet",
    "koenn",
    "kuenft",
    "laeuf",
    "laeng",
    "loesch",
    "loes",
    "lueck",
    "moeg",
    "mued",
    "muess",
    "naechst",
    "noetig",
    "nuetz",
    "oeff",
    "portabilitaet",
    "praesenz",
    "pruef",
    "qualitaet",
    "raeum",
    "rueck",
    "schlaeg",
    "schraenk",
    "schwaech",
    "spaet",
    "staend",
    "staerk",
    "temporaer",
    "traeg",
    "ueber",
    "ueberg",
    "ursprueng",
    "verfueg",
    "verknuepf",
    "vollstaend",
    "vorgaeng",
    "waeg",
    "waehl",
    "waer",
    "waehr",
    "zaehl",
    "zuverlaess",
    "zusaetz",
)
ASCII_SHARP_S_STEMS = (
    "ausser",
    "grosse",
    "grossem",
    "grossen",
    "grosser",
    "grosses",
)


def compile_ascii_german_patterns(prefix: str, stems: tuple[str, ...]) -> tuple[tuple[str, re.Pattern[str]], ...]:
    """Compile longer stems first so compound words get one useful finding."""
    return tuple(
        (
            f"{prefix}_{stem}",
            re.compile(rf"(?<![{GERMAN_WORD_CHARS}])[{GERMAN_WORD_CHARS}]*{re.escape(stem)}[{GERMAN_WORD_CHARS}]*(?![{GERMAN_WORD_CHARS}])", re.IGNORECASE),
        )
        for stem in sorted(stems, key=len, reverse=True)
    )


ASCII_GERMAN_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    *compile_ascii_german_patterns("ascii_umlaut", ASCII_UMLAUT_STEMS),
    *compile_ascii_german_patterns("ascii_sharp_s", ASCII_SHARP_S_STEMS),
)

HUMANIZER_LINT_PATTERNS: tuple[tuple[str, str, re.Pattern[str]], ...] = (
    ("visible_reasoning_label", "fail", re.compile(r"\b(Reasoning|Rationale|Chain of thought|Gedankenkette)\s*:", re.IGNORECASE)),
    ("ai_self_reference", "warn", re.compile(r"\b(as an ai|as a language model|ich\s+als\s+ki|als sprachmodell|ich bin eine ki|i cannot browse|ich kann nicht browsen)\b", re.IGNORECASE)),
    ("internal_system_language", "warn", re.compile(r"\b(TODO|FIXME|PLACEHOLDER|lorem ipsum|draft only|REQUESTED|Verification Queue|Code Tasks)\b", re.IGNORECASE)),
    ("markdown_leak", "warn", re.compile(r"```|&lt;br|<br\s*/?>")),
)


def visible_prose(line: str) -> str:
    """Remove technical spans that should not be judged as German prose."""
    line = re.sub(r"`[^`]*`", "", line)
    line = re.sub(r"\[\[[^\]]+\]\]", "", line)
    line = re.sub(r"\[[^\]]+\]\([^)]+\)", "", line)
    line = re.sub(r"\bhttps?://\S+", "", line)
    return line


def should_skip(path: Path) -> bool:
    return any(part in DEFAULT_EXCLUDE_PARTS for part in path.parts) or path.suffix.lower() not in TEXT_SUFFIXES


def is_allowed_humanizer_context(issue_type: str, token: str, prose: str) -> bool:
    """Avoid warning on terms that are being documented as system vocabulary, not leaked to readers."""
    if issue_type != "internal_system_language":
        return False
    token_lower = [REDACTED]
    prose_lower = prose.lower()
    if token_lower == "requested" and any(term in prose_lower for term in ["effective", "fallback", "model", "modell", "visibility"]):
        return True
    if token_lower == "requested" and "explicitly requested" in prose_lower:
        return True
    if token_lower == "placeholder" and any(term in prose_lower for term in [
        "placeholder=",
        "placeholder =",
        "placeholder?:",
        "placeholder-leak",
        "placeholder fail",
        "placeholder-text",
        "platzhalter",
        "statt placeholder",
        "ohne placeholder",
        "kein placeholder",
        "keine placeholder",
        "placeholder und",
        "placeholder-fixture",
        "placeholder outbound",
        "placeholder copy",
        "zeigt nur den placeholder",
        "gate",
        "check",
        "verifier",
        "review",
        "verifikation",
        "implementiert",
        "feld",
        "input.value",
        "ux",
        "prüf",
        "pruef",
    ]):
        return True
    if token_lower == "code tasks" and any(term in prose_lower for term in ["vega", "tech cell", "statuswahrheit"]):
        return True
    return False


def iter_files(paths: list[Path]) -> list[Path]:
    files: list[Path] = []
    for path in paths:
        if not path.exists():
            continue
        if path.is_file() and not should_skip(path):
            files.append(path)
        elif path.is_dir():
            for child in sorted(path.rglob("*")):
                if child.is_file() and not should_skip(child):
                    files.append(child)
    return sorted(set(files))


def scan_file(path: Path) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError as exc:
        return [{
            "path": str(path),
            "line": 0,
            "severity": "fail",
            "issue_type": "unreadable_file",
            "token": "",
            "excerpt": str(exc),
        }]

    in_code_fence = False
    for line_no, line in enumerate(lines, start=1):
        stripped = line.strip()
        if stripped.startswith("```"):
            in_code_fence = not in_code_fence
            continue
        if not stripped or in_code_fence:
            continue
        prose = visible_prose(line)
        if not prose.strip():
            continue
        matched_spans: set[tuple[int, int]] = set()
        for issue_type, pattern in ASCII_GERMAN_PATTERNS:
            for match in pattern.finditer(prose):
                span = match.span()
                if span in matched_spans:
                    continue
                matched_spans.add(span)
                findings.append({
                    "path": str(path),
                    "line": line_no,
                    "severity": "fail",
                    "issue_type": issue_type,
                    "token": match.group(0),
                    "excerpt": stripped[:220],
                })
        for issue_type, severity, pattern in HUMANIZER_LINT_PATTERNS:
            match = pattern.search(prose)
            if match:
                if is_allowed_humanizer_context(issue_type, match.group(0), prose):
                    continue
                findings.append({
                    "path": str(path),
                    "line": line_no,
                    "severity": severity,
                    "issue_type": issue_type,
                    "token": match.group(0),
                    "excerpt": stripped[:220],
                })
    return findings


def build_report(paths: list[Path]) -> dict[str, Any]:
    files = iter_files(paths)
    findings: list[dict[str, Any]] = []
    for path in files:
        findings.extend(scan_file(path))
    fail_count = sum(1 for item in findings if item["severity"] == "fail")
    warn_count = sum(1 for item in findings if item["severity"] == "warn")
    return {
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": "FAIL" if fail_count else ("WARN" if warn_count else "PASS"),
        "scanned_files": len(files),
        "finding_count": len(findings),
        "fail_count": fail_count,
        "warn_count": warn_count,
        "rule": "German operator-facing prose must use real Umlaute and must not leak reasoning labels, AI self-reference, placeholders or markdown/render artifacts. Technical spans, links and code are excluded.",
        "items": findings[:500],
        "truncated": len(findings) > 500,
    }


def write_report(report: dict[str, Any], json_path: Path, md_path: Path) -> None:
    json_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    lines = [
        "# German Output Quality Gate",
        "",
        f"- Status: `{report['status']}`",
        f"- Scanned files: `{report['scanned_files']}`",
        f"- Findings: `{report['finding_count']}`",
        f"- Fail: `{report['fail_count']}`",
        f"- Warn: `{report['warn_count']}`",
        "",
        "## Findings",
        "",
    ]
    for item in report["items"]:
        lines.append(f"- `{item['severity']}` `{item['issue_type']}` {item['path']}:{item['line']} `{item['token']}`")
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("paths", nargs="*", type=Path)
    parser.add_argument("--json-out", type=Path, default=DEFAULT_OUTPUT_JSON)
    parser.add_argument("--md-out", type=Path, default=DEFAULT_OUTPUT_MD)
    parser.add_argument("--strict", action="store_true", help="exit non-zero on WARN or FAIL")
    parser.add_argument("--fail-only", action="store_true", help="exit non-zero only on FAIL")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    paths = args.paths or [WORKSPACE / "outputs/project_intelligence_graph"]
    report = build_report(paths)
    write_report(report, args.json_out, args.md_out)
    print(json.dumps(report, ensure_ascii=False, indent=2) if args.json else f"{report['status']} findings={report['finding_count']} fail={report['fail_count']} warn={report['warn_count']}")
    if report["status"] == "FAIL":
        return 1 if (args.strict or args.fail_only) else 0
    if report["status"] == "WARN" and args.strict:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
