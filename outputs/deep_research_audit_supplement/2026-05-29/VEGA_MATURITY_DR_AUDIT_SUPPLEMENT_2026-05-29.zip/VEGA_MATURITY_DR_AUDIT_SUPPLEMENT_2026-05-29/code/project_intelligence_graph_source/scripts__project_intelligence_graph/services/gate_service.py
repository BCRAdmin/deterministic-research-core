"""Hard-gate helpers for local-only PIG workflows."""

from __future__ import annotations

from typing import Mapping


HARD_GATE_FIELDS = [
    "runtime_action_executed",
    "external_action_executed",
    "push_executed",
    "deploy_executed",
    "publish_executed",
    "public_or_production_action_executed",
    "auth_or_payment_action_executed",
    "room16_rerun_executed",
    "irreversible_action_executed",
]


def closed_gate_report(payload: Mapping[str, object]) -> dict[str, object]:
    open_gates = [field for field in HARD_GATE_FIELDS if payload.get(field) is True]
    return {
        "status": "PASS" if not open_gates else "FAIL",
        "open_gate_count": len(open_gates),
        "open_gates": open_gates,
    }
