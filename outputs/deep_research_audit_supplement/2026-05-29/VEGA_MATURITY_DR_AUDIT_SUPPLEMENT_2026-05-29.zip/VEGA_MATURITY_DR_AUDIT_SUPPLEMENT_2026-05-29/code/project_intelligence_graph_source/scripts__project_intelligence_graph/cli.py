"""CLI registry helpers for the PIG command surface."""

from __future__ import annotations

from collections.abc import Iterable


STATIC_MATURITY_KERNEL_COMMANDS = [
    "roadmap-reconciliation-v2",
    "stale-next-step-guard",
    "foreign-scope-status-split",
    "evidence-budget",
    "sanitized-review-bundle-v4",
    "bundle-profile-manifest",
    "dirt-burndown",
    "stale-generated-artifacts",
    "commit-hygiene-freshness",
    "operator-brief-v4",
    "operator-brief-v4-audit",
    "vivi-v3-2-cards",
    "vivi-v3-2-supervisor",
    "vivi-duplicate-delta-guard",
    "existing-rails-quality-slice",
    "code-pressure",
    "generated-evidence-dedup",
    "efficiency-monolith-pressure",
    "sanitized-b20-b26-capsule",
    "bundle-reference-lint",
    "archive-membership-audit",
    "evidence-budget-enforcer-test",
    "markdown-renderer-regression",
    "dirt-burndown-v2",
    "quarantine-restore-manifest",
    "commit-ready-batches",
    "pig-pressure-relief-plan",
    "pig-helper-extraction",
    "vivi-v3-3-lifecycle",
    "vivi-v3-3-supervisor",
    "existing-rails-quality-delta-v2",
    "three-cycle-work-log",
    "final-verification-summary",
    "operator-brief-v5",
    "sanitized-b28-b35-capsule",
    "b28-b35-final-state",
]


def maturity_kernel_command_names(
    v4_commands: Iterable[str],
    v5_commands: Iterable[str],
    current_commands: Iterable[str],
) -> list[str]:
    return list(dict.fromkeys([*STATIC_MATURITY_KERNEL_COMMANDS, *v4_commands, *v5_commands, *current_commands]))
