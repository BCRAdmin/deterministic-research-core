#!/usr/bin/env python3
"""Build a sanitized second-round Deep Research pack.

The first pack is useful for internal context, but the first Deep Research
analysis found predictable weaknesses: absolute local paths, stale status
surfaces, unclear audience, and no explicit source registry. This builder keeps
the useful evidence while producing a cleaner follow-up pack for the next run.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import re
import shutil
import subprocess
import sys
import unicodedata
from pathlib import Path
from typing import Any


WORKSPACE = Path(__file__).resolve().parents[2]
DEFAULT_SOURCE_DIR = WORKSPACE / "outputs/deep_research_bundles/20260525T043628-dreamfactory-system-deep-research-pack"
DEFAULT_OUTPUT_ROOT = WORKSPACE / "outputs/deep_research_bundles"

EXCLUDED_DIRS = {
    ".git",
    "node_modules",
    ".venv",
    "venv",
    ".local",
    ".runtime",
    "dist",
    "reports",
    "exports",
    "__pycache__",
    ".pytest_cache",
}

EXCLUDED_SUFFIXES = {
    ".zip",
    ".tgz",
    ".tar",
    ".gz",
    ".pdf",
    ".docx",
    ".xlsx",
    ".sqlite",
    ".sqlite3",
    ".db",
    ".pyc",
}

STALE_OR_NOISY_RELATIVE_PATHS = {
    "10_pig_quality_os/evidence/outputs/project_intelligence_graph/room16_german_output_quality_gate.json",
    "10_pig_quality_os/evidence/outputs/project_intelligence_graph/room16_german_output_quality_gate.md",
    "10_pig_quality_os/evidence/outputs/project_intelligence_graph/vault_umlaut_safe_autofix_manifest.json",
    "10_pig_quality_os/evidence/outputs/project_intelligence_graph/vault_umlaut_safe_autofix_manifest.md",
    "05_FILE_TREE_MANIFEST.txt",
    "05_SHA256SUMS.txt",
}

TEXT_SUFFIXES = {
    ".md",
    ".txt",
    ".json",
    ".jsonl",
    ".py",
    ".mjs",
    ".js",
    ".ts",
    ".tsx",
    ".css",
    ".html",
    ".svg",
    ".toml",
    ".yaml",
    ".yml",
    ".csv",
    ".schema",
    ".canvas",
}

PATH_REDACTIONS = [
    ("workspace_root", re.compile(re.escape(str(WORKSPACE))), "<WORKSPACE_ROOT>"),
    (
        "obsidian_human_overview",
        re.compile(re.escape("/Users/BjornRosinger/Documents/Obsidian/Test Vaul Privat/Human Overview")),
        "<OBSIDIAN_HUMAN_OVERVIEW>",
    ),
    (
        "dreamfactory_root",
        re.compile(re.escape("/Users/BjornRosinger/Documents/DreamFactory")),
        "<DREAMFACTORY_ROOT>",
    ),
    (
        "agent_ops_root",
        re.compile(re.escape("/Users/BjornRosinger/Documents/DreamFactory/Room16/research-agent-ops")),
        "<AGENT_OPS_ROOT>",
    ),
    ("home_root", re.compile(re.escape("/Users/BjornRosinger")), "<LOCAL_USER_HOME>"),
    (
        "lowercase_or_derived_user_home_path",
        re.compile(r"/users/(?:bjornrosinger|<OPERATOR>|[A-Za-z0-9_.-]+)(?=/)", re.IGNORECASE),
        "<LOCAL_USER_HOME>",
    ),
    (
        "bare_user_path_prefix",
        re.compile(r"/users/", re.IGNORECASE),
        "<LOCAL_USER_PATH_PREFIX>/",
    ),
]

GENERAL_REDACTIONS = [
    ("operator_full_name", re.compile(r"\bBj[öo]rn(?:s|(?:\s+Rosinger|Rosinger)?)\b", re.IGNORECASE), "<OPERATOR>"),
    (
        "email",
        re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.IGNORECASE),
        "<EMAIL_REDACTED>",
    ),
    (
        "tunnel_url",
        re.compile(
            r"https?://[A-Za-z0-9.-]+\.(?:ngrok-free\.app|ngrok\.io|trycloudflare\.com|loca\.lt)(?:/[^\s)>'\"]*)?",
            re.IGNORECASE,
        ),
        "<TUNNEL_URL_REDACTED>",
    ),
    (
        "local_url",
        re.compile(r"https?://(?:localhost|127\.0\.0\.1|0\.0\.0\.0|\[::1\]):\d+(?:/[^\s)>'\"]*)?", re.IGNORECASE),
        "<LOCAL_URL_REDACTED>",
    ),
    (
        "local_endpoint",
        re.compile(r"\b(?:localhost|127\.0\.0\.1|0\.0\.0\.0):\d+\b", re.IGNORECASE),
        "<LOCAL_ENDPOINT_REDACTED>",
    ),
    (
        "launch_agent_label",
        re.compile(r"\b(?:com\.bcradmin|com\.lioncom|com\.dreamfactory)[A-Za-z0-9_.-]*\b", re.IGNORECASE),
        "<LAUNCH_AGENT_LABEL_REDACTED>",
    ),
]

SECRET_PATTERNS = [REDACTED]
    re.compile(r"sk-[A-Za-z0-9_-]{20,}"),
    re.compile(r"ghp_[A-Za-z0-9_]{20,}"),
    re.compile(r"github_pat_[A-Za-z0-9_]{20,}"),
    re.compile(r"xox[baprs]-[A-Za-z0-9-]{20,}"),
    re.compile(r"AKIA[0-9A-Z]{16}"),
    re.compile(r"-----BEGIN (?:RSA |OPENSSH |EC |DSA )?PRIVATE KEY-----"),
    re.compile(r"password\s*[:=]\s*[\"'][^\"']{8,}[\"']", re.IGNORECASE),
    re.compile(r"api[_-]?key\s*[:=]\s*[\"'][^\"']{12,}[\"']", re.IGNORECASE),
    re.compile(r"secret\s*[:=]\s*[\"'][^\"']{12,}[\"']", re.IGNORECASE),
]

THIRD_PARTY_TEXT_PATTERNS = {
    "upstream_reference": re.compile(r"\b(?:upstream|forked from|derived from|vendored|third[- ]party)\b", re.IGNORECASE),
    "repository_reference": re.compile(r"https?://(?:www\.)?github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", re.IGNORECASE),
    "academic_reference": re.compile(r"\b(?:arxiv|doi:|ssrn)\b", re.IGNORECASE),
    "license_reference": re.compile(
        r"\b(?:MIT License|License:\s*MIT|Lizenz:\s*MIT|Apache-2\.0|BSD-3-Clause|BSD-2-Clause|GPL-?[23]?|AGPL|LGPL|MPL-2\.0|ISC license)\b",
        re.IGNORECASE,
    ),
    "model_provider_reference": re.compile(r"\b(?:Kimi|Moonshot|DeepSeek|OpenAI|Anthropic|Gemini|Qwen|GLM)\b", re.IGNORECASE),
    "tradingagents_reference": re.compile(r"\bTradingAgents\b", re.IGNORECASE),
}

THIRD_PARTY_REVIEW_FILES = {
    "license",
    "license.md",
    "license.txt",
    "copying",
    "notice",
    "package.json",
    "package-lock.json",
    "pnpm-lock.yaml",
    "yarn.lock",
    "pyproject.toml",
    "requirements.txt",
    "requirements-dev.txt",
}

THIRD_PARTY_ASSET_SUFFIXES = {".png", ".jpg", ".jpeg", ".svg", ".webp", ".gif"}

ASCII_MAP = str.maketrans(
    {
        "ä": "ae",
        "ö": "oe",
        "ü": "ue",
        "Ä": "Ae",
        "Ö": "Oe",
        "Ü": "Ue",
        "ß": "ss",
        "–": "-",
        "—": "-",
        "“": '"',
        "”": '"',
        "’": "'",
        "‘": "'",
    }
)


def load_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def is_text_file(path: Path) -> bool:
    if path.suffix.lower() in TEXT_SUFFIXES:
        return True
    try:
        sample = path.read_bytes()[:2048]
    except Exception:
        return False
    return b"\x00" not in sample


def safe_component(component: str) -> str:
    translated = component.translate(ASCII_MAP)
    normalized = unicodedata.normalize("NFKD", translated).encode("ascii", "ignore").decode("ascii")
    normalized = re.sub(r"[^A-Za-z0-9._ -]+", "_", normalized)
    normalized = re.sub(r"\s+", " ", normalized).strip()
    return normalized or "unnamed"


def safe_relative_path(rel: Path) -> Path:
    return Path(*[safe_component(part) for part in rel.parts])


def sanitize_text(text: str) -> tuple[str, dict[str, int]]:
    counts: dict[str, int] = {}
    sanitized = text
    for name, pattern, replacement in [*PATH_REDACTIONS, *GENERAL_REDACTIONS]:
        sanitized, count = pattern.subn(replacement, sanitized)
        if count:
            counts[name] = counts.get(name, 0) + count
    return sanitized, counts


def should_exclude(rel: Path) -> tuple[bool, str]:
    if any(part in EXCLUDED_DIRS for part in rel.parts):
        return True, "excluded_dir"
    if rel.suffix.lower() in EXCLUDED_SUFFIXES:
        return True, "excluded_suffix"
    rel_posix = rel.as_posix()
    if rel_posix in STALE_OR_NOISY_RELATIVE_PATHS:
        return True, "stale_or_noisy"
    return False, ""


def classify_layer(rel: Path) -> str:
    first = rel.parts[0] if rel.parts else ""
    return {
        "00_workspace_bootstrap": "workspace_bootstrap",
        "10_pig_quality_os": "pig_quality_os",
        "20_obsidian_backbone": "obsidian_backbone",
        "30_codex_skills": "codex_skills",
        "35_agent_os_context": "agent_os_context",
        "40_product_rails": "product_rail",
    }.get(first, "bundle_meta")


def sensitivity_for(rel: Path) -> str:
    layer = classify_layer(rel)
    if layer in {"obsidian_backbone", "workspace_bootstrap"}:
        return "internal_sensitive_after_redaction"
    if layer == "product_rail":
        return "internal_product_after_redaction"
    if layer == "pig_quality_os":
        return "internal_governance_after_redaction"
    return "internal_after_redaction"


def secret_hits(root: Path) -> list[str]:
    hits: list[str] = []
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() in {".png", ".jpg", ".jpeg"}:
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        for pattern in SECRET_PATTERNS:
            if pattern.search(text):
                hits.append(str(path.relative_to(root)))
                break
    return sorted(set(hits))


def relative_leaks(root: Path) -> dict[str, list[str]]:
    checks = {
        "absolute_user_paths": re.compile(r"/users/(?:bjornrosinger|[^/\s]+)/", re.IGNORECASE),
        "bare_user_path_prefix": re.compile(r"/users/", re.IGNORECASE),
        "operator_name": re.compile(r"\bBj[öo]rn(?:s|(?:\s+Rosinger|Rosinger)?)\b", re.IGNORECASE),
        "email": GENERAL_REDACTIONS[1][1],
        "tunnel_url": GENERAL_REDACTIONS[2][1],
        "local_url": GENERAL_REDACTIONS[3][1],
        "local_endpoint": GENERAL_REDACTIONS[4][1],
    }
    found: dict[str, list[str]] = {key: [] for key in checks}
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() in {".png", ".jpg", ".jpeg"}:
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        for name, pattern in checks.items():
            if pattern.search(text):
                found[name].append(str(path.relative_to(root)))
    return {key: sorted(value) for key, value in found.items() if value}


def build_provenance_candidates(target_dir: Path, records: list[dict[str, Any]], generated_at: str) -> dict[str, Any]:
    records_by_path = {record["sanitized_relative_path"]: record for record in records}
    candidates: list[dict[str, Any]] = []
    by_type: dict[str, int] = {}

    for path in sorted(target_dir.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(target_dir).as_posix()
        lower_name = path.name.lower()
        suffix = path.suffix.lower()
        candidate_types: list[str] = []
        evidence: list[str] = []

        if lower_name in THIRD_PARTY_REVIEW_FILES or lower_name.startswith(("license", "notice", "copying")):
            candidate_types.append("license_or_dependency_file")
            evidence.append("path/name indicates license, notice or dependency manifest")
        if suffix in THIRD_PARTY_ASSET_SUFFIXES:
            candidate_types.append("asset_provenance_review")
            evidence.append("visual or media asset may need source/provenance review")
        if rel.startswith("40_product_rails/") and "/assets/" in rel:
            candidate_types.append("product_asset_review")
            evidence.append("product rail asset included in shareable research context")

        text_scan_skipped = False
        if is_text_file(path):
            if path.stat().st_size > 512_000:
                text_scan_skipped = True
            else:
                text = path.read_text(encoding="utf-8", errors="ignore")
                for candidate_type, pattern in THIRD_PARTY_TEXT_PATTERNS.items():
                    if pattern.search(text):
                        candidate_types.append(candidate_type)
                        evidence.append(f"text matches {candidate_type}")

        if candidate_types:
            record = records_by_path.get(rel, {})
            unique_types = sorted(set(candidate_types))
            for candidate_type in unique_types:
                by_type[candidate_type] = by_type.get(candidate_type, 0) + 1
            candidates.append(
                {
                    "relative_path": rel,
                    "candidate_types": unique_types,
                    "layer": record.get("layer", classify_layer(Path(rel))),
                    "suffix": suffix,
                    "kind": "text" if is_text_file(path) else "binary",
                    "evidence": sorted(set(evidence)),
                    "text_scan": "skipped_large_file" if text_scan_skipped else "completed_or_not_text",
                    "review_state": "review_required",
                    "redistribution_status": "not_cleared",
                    "license_status": "unknown_or_unverified",
                    "legal_conclusion": "none",
                }
            )

    return {
        "schema_version": 1,
        "generated_at": generated_at,
        "status": "WARN" if candidates else "PASS",
        "review_state": "candidate_inventory_only",
        "legal_conclusion": "none",
        "candidate_count": len(candidates),
        "by_type": dict(sorted(by_type.items())),
        "rules": [
            "This registry flags candidate files and references for human/license review.",
            "A candidate is not a finding of infringement, license incompatibility or public redistribution clearance.",
            "Public redistribution remains blocked until provenance and license status are reviewed from primary sources.",
        ],
        "candidates": candidates,
    }


def build_provenance_candidates_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Third-Party And Source Provenance Candidates",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Generated: `{payload.get('generated_at', 'UNKNOWN')}`",
        f"- Candidate count: `{payload.get('candidate_count', 0)}`",
        f"- Review state: `{payload.get('review_state', 'UNKNOWN')}`",
        f"- Legal conclusion: `{payload.get('legal_conclusion', 'none')}`",
        "",
        "## Meaning",
        "",
        "This is a review-only candidate inventory. It does not clear redistribution, licensing, publication, production use or legal safety.",
        "",
        "## Counts By Type",
        "",
    ]
    by_type = payload.get("by_type", {})
    if by_type:
        for candidate_type, count in by_type.items():
            lines.append(f"- `{candidate_type}`: `{count}`")
    else:
        lines.append("- No candidates found.")

    candidates = payload.get("candidates", [])
    if candidates:
        lines.extend(["", "## Candidate Files", ""])
        lines.extend(["| Path | Types | Layer | Review state |", "|---|---|---|---|"])
        for candidate in candidates[:200]:
            lines.append(
                "| "
                + " | ".join(
                    [
                        f"`{candidate.get('relative_path', '')}`",
                        ", ".join(f"`{item}`" for item in candidate.get("candidate_types", [])),
                        f"`{candidate.get('layer', 'unknown')}`",
                        f"`{candidate.get('review_state', 'unknown')}`",
                    ]
                )
                + " |"
            )
        if len(candidates) > 200:
            lines.append("")
            lines.append(f"Only the first 200 of {len(candidates)} candidates are shown here. Use the JSON registry for the full list.")

    lines.extend(["", "## Rules", ""])
    for rule in payload.get("rules", []):
        lines.append(f"- {rule}")
    return "\n".join(lines)


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    sanitized, _ = sanitize_text(text)
    path.write_text(sanitized.rstrip() + "\n", encoding="utf-8")


def status_line(status: dict[str, Any], *keys: str) -> str:
    return ", ".join(f"{key}={status.get(key, 'UNKNOWN')}" for key in keys)


def build_previous_dr_digest(generated_at: str) -> str:
    return f"""# Previous Deep Research Findings Digest

Generated: {generated_at}

## What The First Deep Research Run Found

The first run correctly understood the pack as a curated local system bundle, not as a single report. It found a strong local governance and verifier foundation around Vega, Vivi, PIG, Obsidian, LIONCOM and product rails.

The main critique was not "missing documentation". It was the gap between local PASS and external/product readiness:

- PIG and Quality OS are strong as local control layers.
- Product rails are locally verifiable, but public, payment, real-data and production moves remain gated.
- The first bundle leaked too much local metadata through absolute paths, operator names, ports, tunnel references and environment-specific paths.
- The bundle was curated, which protects privacy but reduces third-party reconstruction from raw evidence.
- Some status surfaces were stale or semantically confusing, especially around Room16 German Output Quality.
- OpenJarvis/Jarvis appeared in aggregated evidence despite being out of scope for this research path.
- The next high-leverage block should be Deep Research ingestion, source registry, contradiction detection, shareable evidence packaging and Vivi Worker v3 semantics.

## Important Correction For Round 2

The old PIG file `room16_german_output_quality_gate.*` in the first bundle was stale. The current canonical Room16 project-level verifier output is `company-dossier-lab/outputs/german_output_quality/room16_german_output_quality.*` and reports PASS. Round 2 must analyze the stale-vs-current status issue as a status aggregation problem, not as proof that current Room16 German output is failing.

## What Not To Spend Time On

- Do not pivot to Jarvis/OpenJarvis.
- Do not re-summarize the whole bundle.
- Do not interpret local PASS as launch approval.
- Do not propose public, production, payment, financial-advice publishing, real client data, Room16 reruns or external communication without explicit operator gates.
"""


def build_open_questions_answered(generated_at: str) -> str:
    return f"""# Open Questions Answered For Round 2

Generated: {generated_at}

These answers replace the open questions from the first Deep Research report unless Round 2 has strong evidence to challenge them.

## Intended Audience

The next bundle is for a private internal high-context Deep Research model run. It is not a public, customer, legal, investor, or external auditor package.

The goal is to produce implementation-grade strategy and architecture guidance for Vega/Codex to execute locally afterward.

## Sharing Profile

Use the profile `internal_shareable_after_redaction`.

This means:

- local paths, operator full name, emails, tunnel URLs, local URLs and launch-agent labels should be redacted
- internal architecture, code, verifiers and product rail structure may remain
- real secrets, local DBs, raw report runs, raw source inputs and generated publishable artifacts stay excluded
- outputs are still not public material

## Jurisdiction And Regulatory Lens

Assume Germany/EU as the default legal and privacy lens.

The research model should not provide legal, tax or financial advice. It may identify likely regulatory areas and recommend review gates. Finance-adjacent Room16/Quellwert content and tax-adjacent Kanzlei AI Assist content need explicit legal/privacy review before any public or real-data use.

## Missing Raw Data

Raw PIG graph exports, databases, raw report runs, `.git` history and source-input archives are intentionally excluded. Round 2 should not treat this as accidental loss.

The useful task is to design a portable privacy-safe evidence subset that would improve third-party reconstructability without leaking private or gated data.

## Live/Productive Testing

No productive live test is authorized. Round 2 should analyze the provided archive and current evidence only. It may propose local deterministic tests and acceptance criteria for Vega/Codex to run later.

## External References

Most references in the bundle are internal file references. If Round 2 can browse, it should use primary/official sources for license, legal, model/provider and dependency questions. If it cannot browse, it must mark external conclusions as unverified.

## Can Deep Research Write Code?

Do not rely on Deep Research to directly patch the repository. Use it for:

- architecture decisions
- JSON schema sketches
- pseudocode
- acceptance tests
- verifier designs
- source-registry fields
- migration plans
- risk analysis

If the Deep Research model can produce code, ask for small isolated snippets or diff sketches only. Vega/Codex should implement and verify code locally because this workspace requires file-level tests, gates and memory updates.

## What Round 2 Should Optimize For

Round 2 should optimize for implementable improvements:

- shareable bundle sanitizer
- source registry and sensitivity classification
- status semantics: `verifier_run_success` vs `artifact_state_green` vs `publishable_text_green` vs `operator_gate_open`
- contradiction detection
- portable evidence pack
- third-party/license registry
- Vivi Worker v3 claim semantics
- Deep Research ingestion flow into PIG and Obsidian
"""


def build_round2_prompt(generated_at: str) -> str:
    return f"""# Round 2 Deep Research Prompt

Generated: {generated_at}

You are the second Deep Research model analyzing a sanitized follow-up pack for the DreamFactory / Vega / Vivi / PIG system.

Do not repeat the first report. Build on it.

## Mission

Design the next implementable roadmap after the local Quality OS foundation. Focus on the transition from internal local governance to a shareable, auditable, contradiction-aware research and delivery system.

## Known Starting State

- The first pack contained 1481 files and was locally useful but too environment-specific for repeatable third-party review.
- The first Deep Research run found strong local governance and weak shareability/reproducibility.
- Current local state remains `operator_gated_or_monitoring`.
- Safe local backlog is considered empty unless this pack identifies a strictly local reversible improvement.
- Room16, Kanzlei AI Assist, Utility/Membership/Quellwert and LIONCOM are product rails with separate gates.
- Jarvis/OpenJarvis is out of scope for this run.
- Vivi model routing and Room16 model selection are separate.
- Room16 currently remains manual app-level model selection with DeepSeek 4 Pro / DS V4 Cloud unless explicitly changed for Room16.

## Open Questions Already Answered

Use `02_OPEN_QUESTIONS_ANSWERED.md` as fixed context. Do not ask those questions again unless you believe the answer is unsafe or incomplete.

## Required Output

Produce a report with these sections:

1. Executive diagnosis: what should be built next and why.
2. Evidence-aware critique of the new sanitized pack.
3. Status semantics design:
   - `verifier_run_success`
   - `artifact_state_green`
   - `publishable_text_green`
   - `operator_gate_open`
   - `external_validation_state`
4. Source Registry design:
   - file role
   - sensitivity class
   - provenance
   - freshness
   - raw-evidence dependency
   - included/excluded reason
   - citation policy
5. Contradiction Layer design:
   - stale-vs-current evidence
   - scoped-vs-global PASS
   - generated-evidence-vs-source truth
   - out-of-scope contamination
6. Deep Research Ingestion Block:
   - input contract
   - source registry
   - claim extraction
   - conflict review
   - PIG ingestion
   - Obsidian memory routing
   - operator review gate
7. Vivi Worker v3 design:
   - new claim semantics
   - allowed claim types
   - permanent denylist
   - verifier selection
   - evidence schema
   - failure states
   - supervisor audit criteria
8. Product rail guidance:
   - Room16
   - Kanzlei AI Assist
   - Utility/Membership/Quellwert
   - LIONCOM
9. Implementation-ready backlog:
   - 8 to 12 blocks
   - each with goal, files likely touched, verifier, evidence, done criteria, operator gates
10. What Vega/Codex should implement first before asking another model.
11. What must remain operator-gated.
12. Evidence appendix with cited file paths.

## Code Guidance

You may provide schema sketches, pseudocode and focused diff suggestions. Do not assume you can execute code or directly mutate the workspace. Make implementation instructions precise enough for Vega/Codex to patch locally and verify.

## Hard Gates

Do not recommend executing these without explicit operator approval:

- push
- delete
- publish
- deploy
- production
- public release
- payment or money movement
- auth or credentials handling
- external communication
- real person/client data
- financial-advice publishing
- Room16 rerun
- irreversible actions

## Evaluation Criteria

Prefer changes that reduce ambiguity, reduce privacy exposure, improve reproducibility, separate local PASS from product readiness, and create verifiable next actions. Reject improvements that only add more reports without improving decisions.
"""


def build_code_guidance(generated_at: str) -> str:
    return f"""# Code Writing Guidance For Deep Research

Generated: {generated_at}

Deep Research should not be treated as the repo-mutating coding agent for this workspace.

## Best Use

Use Deep Research for:

- architecture critique
- data contract design
- JSON schema sketches
- edge-case discovery
- risk taxonomy
- verifier specification
- product sequencing
- acceptance criteria

## Avoid

Avoid asking Deep Research to produce large full-file rewrites. It does not see live repo state after the bundle was created, cannot run local verifiers, and may not preserve local conventions.

## If It Writes Code

Ask for small patch sketches only:

- one function or one schema at a time
- include expected inputs and outputs
- include test cases
- state migration/backward compatibility concerns
- state which verifier must pass

Vega/Codex then implements locally with `apply_patch`, runs verifiers, updates PIG/Obsidian memory and rejects any change that creates regressions.
"""


def current_status_semantics() -> dict[str, Any]:
    return load_json(WORKSPACE / "outputs/project_intelligence_graph/status_semantics_matrix.json")


def current_status_semantics_summary(status_semantics: dict[str, Any]) -> str:
    if not status_semantics:
        return "Current status semantics matrix: unavailable"
    return status_line(
        status_semantics,
        "status",
        "truth_state",
        "project_count",
        "verifier_success_count",
        "publishable_count",
        "externally_validated_count",
        "operator_gate_open_count",
        "stale_conflict_count",
        "generated_at",
    )


def build_current_status_semantics_markdown(generated_at: str, status_semantics: dict[str, Any]) -> str:
    if not status_semantics:
        return f"""# Current Status Semantics Matrix

Generated: {generated_at}

Status semantics matrix was not available in the local workspace when this pack was built.
"""

    items = status_semantics.get("items", [])
    stale_conflicts = status_semantics.get("stale_conflicts", [])
    lines = [
        "# Current Status Semantics Matrix",
        "",
        f"Generated: {generated_at}",
        "",
        "## Summary",
        "",
        f"- Matrix status: `{status_semantics.get('status', 'UNKNOWN')}`",
        f"- Truth state: `{status_semantics.get('truth_state', 'UNKNOWN')}`",
        f"- Projects represented: `{status_semantics.get('project_count', 0)}`",
        f"- Local verifier successes: `{status_semantics.get('verifier_success_count', 0)}`",
        f"- Publishable outputs: `{status_semantics.get('publishable_count', 0)}`",
        f"- Externally validated outputs: `{status_semantics.get('externally_validated_count', 0)}`",
        f"- Open operator gates: `{status_semantics.get('operator_gate_open_count', 0)}`",
        f"- Stale conflicts: `{status_semantics.get('stale_conflict_count', 0)}`",
        "",
        "## Meaning",
        "",
        "The matrix status can be `WARN` while the implementation is healthy. Here `WARN` means local artifacts are verifier-backed but not publishable, externally validated, or operator-released.",
        "",
        "Round 2 should treat this file as the current local status truth for readiness semantics, not as a public-readiness claim.",
        "",
        "## Project Rows",
        "",
    ]
    if items:
        lines.extend(
            [
                "| Project | Verifier | Local artifact | Publishable | External validation | Operator gate | Effective readiness |",
                "|---|---:|---:|---:|---:|---:|---|",
            ]
        )
        for item in items:
            lines.append(
                "| "
                + " | ".join(
                    [
                        str(item.get("project_id", "UNKNOWN")),
                        str(item.get("verifier_status", "UNKNOWN")),
                        "green" if item.get("local_artifact_green") else "not_green",
                        "yes" if item.get("publishable_text_green") else "no",
                        str(item.get("external_validation_state", "UNKNOWN")),
                        "open" if item.get("operator_gate_open") else "closed",
                        str(item.get("effective_readiness", "UNKNOWN")),
                    ]
                )
                + " |"
            )
    else:
        lines.append("No project rows were available.")

    if stale_conflicts:
        lines.extend(["", "## Stale Conflicts", ""])
        for conflict in stale_conflicts:
            lines.extend(
                [
                    f"- `{conflict.get('conflict_id', 'UNKNOWN')}`: `{conflict.get('severity', 'UNKNOWN')}`",
                    f"  Current source: `{conflict.get('current_path', 'UNKNOWN')}`",
                    f"  Stale source: `{conflict.get('stale_path', 'UNKNOWN')}`",
                    f"  Summary: {conflict.get('summary', '')}",
                ]
            )

    semantic_rules = status_semantics.get("semantic_rules", [])
    if semantic_rules:
        lines.extend(["", "## Semantic Rules", ""])
        for rule in semantic_rules:
            lines.append(f"- {rule}")

    return "\n".join(lines)


def build_status_reconciliation(generated_at: str) -> str:
    current_room16 = load_json(WORKSPACE / "company-dossier-lab/outputs/german_output_quality/room16_german_output_quality.json")
    system_german = load_json(WORKSPACE / "outputs/project_intelligence_graph/german_output_quality_gate.json")
    autonomy = load_json(WORKSPACE / "outputs/project_intelligence_graph/autonomy_governor_audit.json")
    project_verticals = load_json(WORKSPACE / "outputs/project_intelligence_graph/project_vertical_rollout.json")
    launch = load_json(WORKSPACE / "outputs/project_intelligence_graph/launch_readiness_package.json")
    status_semantics = current_status_semantics()
    return f"""# Status Reconciliation For Round 2

Generated: {generated_at}

## Why This File Exists

The first Deep Research run found a real problem: the first bundle included an older PIG-level `room16_german_output_quality_gate.*` report that said FAIL, while the current Room16 project verifier output says PASS.

Round 2 should treat this as a status aggregation and stale evidence problem.

## Current Canonical Local Status

- Current Room16 project-level German output verifier: `{status_line(current_room16, "status", "finding_count", "fail_count", "warn_count", "generated_at")}`
- Current system-level German output quality gate: `{status_line(system_german, "status", "finding_count", "fail_count", "warn_count", "generated_at")}`
- Current Autonomy Governor: `{status_line(autonomy, "status", "autonomy_state", "safe_work_remaining", "ready_or_in_progress_count")}`
- Current project vertical rollout: `{status_line(project_verticals, "status", "project_effect_status", "rail_contract_status", "local_rail_completion_percent", "missing_verifier_count", "operator_gated_project_count")}`
- Current launch readiness: `{status_line(launch, "status", "project_effect_status", "launch_contract_status", "local_preflight_completion_percent", "operator_gate_count")}`
- Current status semantics matrix: `{current_status_semantics_summary(status_semantics)}`

## Current Status Semantics Matrix

The current machine-readable matrix is included as `08_CURRENT_STATUS_SEMANTICS.json` and `08_CURRENT_STATUS_SEMANTICS.md`.

Its intended interpretation is:

- local verifier success is not public readiness
- publishable output count is `{status_semantics.get("publishable_count", 0) if status_semantics else "UNKNOWN"}`
- externally validated output count is `{status_semantics.get("externally_validated_count", 0) if status_semantics else "UNKNOWN"}`
- open operator gate count is `{status_semantics.get("operator_gate_open_count", 0) if status_semantics else "UNKNOWN"}`
- stale conflict count is `{status_semantics.get("stale_conflict_count", 0) if status_semantics else "UNKNOWN"}`
- `WARN` means the readiness truth is gated/not external, not that the implementation failed

## Semantics For Round 2

`completed_verified` means the local claim/verifier was run and supervised. It does not mean that the product is publishable or externally validated.

Room16 current German output verifier PASS does not override:

- manual review gates
- publish gates
- financial-advice publishing gate
- Room16 rerun gate
- external validation needs

## Required Design Response

Round 2 should propose status fields that prevent this confusion:

- `verifier_run_success`
- `artifact_state_green`
- `publishable_text_green`
- `operator_gate_open`
- `stale_evidence_detected`
- `current_canonical_source`
- `external_validation_state`
"""


def build_backlog(generated_at: str) -> str:
    return f"""# Implementation-Ready Backlog Seed

Generated: {generated_at}

This is a seed backlog for Round 2 to critique, reorder and sharpen.

## Block 1: Shareable Research Bundle Sanitizer

Goal: make research packs portable and private by default.

Acceptance criteria:

- no absolute local user paths
- no operator full name
- no emails
- no tunnel URLs
- no local URLs with ports
- no `.git`, `node_modules`, local DBs, raw report runs or runtime dirs
- source registry generated
- manifest and hash list generated

Verifier:

- py_compile builder
- unzip integrity
- leak scan
- secret scan

## Block 2: Status Semantics Split

Goal: separate verifier success from artifact/product readiness.

Acceptance criteria:

- PIG and operator surfaces distinguish local verifier PASS from publishable/product PASS
- stale status surfaces are visible
- Room16 German-output stale conflict cannot recur silently

## Block 3: Source Registry And Evidence Classes

Goal: make every included/excluded source explicit.

Acceptance criteria:

- each file has role, sensitivity, freshness and provenance
- excluded classes have a reason
- raw evidence dependencies are named

## Block 4: Contradiction Layer

Goal: detect scoped-vs-global contradictions before handoff.

Acceptance criteria:

- status conflict report exists
- stale-vs-current source rules exist
- out-of-scope contamination is flagged

## Block 5: Deep Research Ingestion

Goal: turn DR reports into candidate claims, not automatic truth.

Acceptance criteria:

- input contract
- claim extraction
- citation checks
- contradiction review
- Obsidian/PIG routing
- operator gate review

## Block 6: Vivi Worker v3 Semantics

Goal: make Vivi safer and more useful without making it broad.

Acceptance criteria:

- new claim states
- explicit failure states
- verifier selector
- evidence schema
- supervisor audit criteria

## Block 7: Third-Party And License Registry

Goal: reduce redistribution and provenance ambiguity.

Acceptance criteria:

- dependency and upstream source inventory
- license status per source family
- bundle inclusion policy

## Block 8: Product Rail Readiness Matrix

Goal: make local, private preview, public, payment and production readiness visibly separate.

Acceptance criteria:

- per rail status table
- per rail hard gates
- per rail current canonical verifier
- per rail next safe local move
"""


def build_third_party_note(generated_at: str) -> str:
    return f"""# Third-Party And License Review Start

Generated: {generated_at}

This pack does not complete a legal/license review. It creates the next research task.

Round 2 should identify which included materials are:

- original local work
- upstream/open-source code or docs
- generated artifacts derived from upstream
- images or assets with unclear provenance
- model/provider references requiring current verification

Recommended output:

- `THIRD_PARTY_LICENSES.md`
- `SOURCE_PROVENANCE_REGISTRY.json`
- use `09_THIRD_PARTY_SOURCE_CANDIDATES.json` as candidate input, not as legal clearance
- bundle inclusion rules by source class
- primary-source links for any external claim

No public redistribution should be inferred from this internal research pack.
"""


def build_readme(generated_at: str) -> str:
    return f"""# DreamFactory Deep Research Follow-Up Pack

Generated: {generated_at}

This is the second-round, sanitized follow-up pack for the DreamFactory / Vega / Vivi / PIG system.

## Why This Pack Exists

The first Deep Research run found useful issues in the original pack:

- absolute local paths and operator metadata
- stale Room16/PIG German-output status conflict
- weak audience and jurisdiction assumptions
- insufficient source registry
- need for contradiction-aware status semantics
- need for Deep Research ingestion and Vivi Worker v3 design

This pack answers the open questions and gives the next Deep Research model a sharper task.

## Read Order

1. `00_README_FOLLOWUP.md`
2. `01_PREVIOUS_DR_FINDINGS_DIGEST.md`
3. `02_OPEN_QUESTIONS_ANSWERED.md`
4. `03_ROUND2_DEEP_RESEARCH_PROMPT.md`
5. `04_CODE_WRITING_GUIDANCE_FOR_DR.md`
6. `05_STATUS_RECONCILIATION.md`
7. `06_IMPLEMENTATION_READY_BACKLOG_SEED.md`
8. `07_THIRD_PARTY_AND_LICENSE_REVIEW_START.md`
9. `08_CURRENT_STATUS_SEMANTICS.json`
10. `08_CURRENT_STATUS_SEMANTICS.md`
11. `09_THIRD_PARTY_SOURCE_CANDIDATES.json`
12. `09_THIRD_PARTY_SOURCE_CANDIDATES.md`
13. `10_CURRENT_SOURCE_REGISTRY.json`
14. `11_CURRENT_EVIDENCE_SPINE.json`
15. `12_CURRENT_CONTRADICTIONS.json`
16. `SOURCE_REGISTRY.json`
17. Sanitized evidence folders copied from the original pack.

## Scope

This is internal, private and redacted. It is not a public launch, legal review, client-data workflow, financial-advice artifact, Room16 rerun, production deploy or payment step.

## Main Instruction

Do not summarize everything again. Design the next implementable architecture and roadmap: source registry, status semantics, contradiction layer, Deep Research ingestion, Vivi Worker v3 and product rail readiness.
"""


def copy_and_sanitize_tree(source_dir: Path, target_dir: Path) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, int]]:
    records: list[dict[str, Any]] = []
    excluded: list[dict[str, Any]] = []
    aggregate_redactions: dict[str, int] = {}
    used_paths: set[str] = set()

    for src in sorted(source_dir.rglob("*")):
        rel = src.relative_to(source_dir)
        exclude, reason = should_exclude(rel)
        if exclude:
            if src.is_file():
                excluded.append({"relative_path": rel.as_posix(), "reason": reason})
            continue
        if src.is_dir():
            continue

        safe_rel = safe_relative_path(rel)
        safe_rel_posix = safe_rel.as_posix()
        if safe_rel_posix in used_paths:
            stem = safe_rel.stem
            suffix = safe_rel.suffix
            parent = safe_rel.parent
            counter = 2
            while True:
                candidate = parent / f"{stem}-{counter}{suffix}"
                if candidate.as_posix() not in used_paths:
                    safe_rel = candidate
                    safe_rel_posix = candidate.as_posix()
                    break
                counter += 1
        used_paths.add(safe_rel_posix)
        dest = target_dir / safe_rel
        dest.parent.mkdir(parents=True, exist_ok=True)

        text_file = is_text_file(src)
        redactions: dict[str, int] = {}
        if text_file:
            text = src.read_text(encoding="utf-8", errors="replace")
            sanitized, redactions = sanitize_text(text)
            dest.write_text(sanitized, encoding="utf-8")
        else:
            shutil.copy2(src, dest)

        for name, count in redactions.items():
            aggregate_redactions[name] = aggregate_redactions.get(name, 0) + count

        records.append(
            {
                "source_relative_path": rel.as_posix(),
                "sanitized_relative_path": safe_rel_posix,
                "layer": classify_layer(rel),
                "suffix": src.suffix.lower(),
                "kind": "text" if text_file else "binary",
                "source_size_bytes": src.stat().st_size,
                "sanitized_size_bytes": dest.stat().st_size,
                "sensitivity": sensitivity_for(rel),
                "sharing_status": "included_after_redaction",
                "redactions": redactions,
                "path_was_normalized": rel.as_posix() != safe_rel_posix,
            }
        )

    return records, excluded, aggregate_redactions


def write_manifests(target_dir: Path) -> None:
    file_list = sorted(path.relative_to(target_dir).as_posix() for path in target_dir.rglob("*") if path.is_file())
    (target_dir / "05_FILE_TREE_MANIFEST.txt").write_text("\n".join(file_list) + "\n", encoding="utf-8")
    lines = []
    for rel in file_list:
        if rel == "05_SHA256SUMS.txt":
            continue
        path = target_dir / rel
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        lines.append(f"{digest}  {rel}")
    (target_dir / "05_SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def zip_dir(target_dir: Path, zip_path: Path) -> None:
    if zip_path.exists():
        raise FileExistsError(f"Refusing to overwrite existing zip: {zip_path}")
    subprocess.run(
        ["zip", "-qr", "-X", str(zip_path.name), str(target_dir.name)],
        cwd=str(target_dir.parent),
        check=True,
    )


def build_pack(source_dir: Path, output_root: Path, name: str | None = None) -> dict[str, Any]:
    if not source_dir.exists():
        raise FileNotFoundError(source_dir)
    generated_at = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    stamp = dt.datetime.now().strftime("%Y%m%dT%H%M%S")
    pack_name = name or f"{stamp}-dreamfactory-system-deep-research-followup-pack"
    target_dir = output_root / pack_name
    if target_dir.exists():
        raise FileExistsError(f"Refusing to overwrite existing directory: {target_dir}")
    target_dir.mkdir(parents=True)

    records, excluded, redactions = copy_and_sanitize_tree(source_dir, target_dir)

    write_text(target_dir / "00_README_FOLLOWUP.md", build_readme(generated_at))
    write_text(target_dir / "01_PREVIOUS_DR_FINDINGS_DIGEST.md", build_previous_dr_digest(generated_at))
    write_text(target_dir / "02_OPEN_QUESTIONS_ANSWERED.md", build_open_questions_answered(generated_at))
    write_text(target_dir / "03_ROUND2_DEEP_RESEARCH_PROMPT.md", build_round2_prompt(generated_at))
    write_text(target_dir / "04_CODE_WRITING_GUIDANCE_FOR_DR.md", build_code_guidance(generated_at))
    write_text(target_dir / "05_STATUS_RECONCILIATION.md", build_status_reconciliation(generated_at))
    write_text(target_dir / "06_IMPLEMENTATION_READY_BACKLOG_SEED.md", build_backlog(generated_at))
    write_text(target_dir / "07_THIRD_PARTY_AND_LICENSE_REVIEW_START.md", build_third_party_note(generated_at))
    status_semantics = current_status_semantics()
    write_text(
        target_dir / "08_CURRENT_STATUS_SEMANTICS.json",
        json.dumps(status_semantics, indent=2, ensure_ascii=False),
    )
    write_text(
        target_dir / "08_CURRENT_STATUS_SEMANTICS.md",
        build_current_status_semantics_markdown(generated_at, status_semantics),
    )
    current_workspace_specs = [
        (
            "10_CURRENT_SOURCE_REGISTRY.json",
            WORKSPACE / "outputs/project_intelligence_graph/source_registry.json",
            "b02_source_registry",
            "B02 machine-readable Source Registry with source ids, sensitivity, sharing status and citation policy.",
        ),
        (
            "10_CURRENT_SOURCE_REGISTRY.md",
            WORKSPACE / "outputs/project_intelligence_graph/source_registry.md",
            "b02_source_registry_human_readable",
            "B02 human-readable Source Registry.",
        ),
        (
            "11_CURRENT_EVIDENCE_SPINE.json",
            WORKSPACE / "outputs/project_intelligence_graph/evidence_spine.json",
            "b02_evidence_spine",
            "B02 claim-to-source evidence spine.",
        ),
        (
            "11_CURRENT_EVIDENCE_SPINE.md",
            WORKSPACE / "outputs/project_intelligence_graph/evidence_spine.md",
            "b02_evidence_spine_human_readable",
            "B02 human-readable evidence spine.",
        ),
        (
            "12_CURRENT_CONTRADICTIONS.json",
            WORKSPACE / "outputs/project_intelligence_graph/contradiction_staleness_report.json",
            "b03_contradiction_staleness",
            "B03 contradiction and staleness decisions.",
        ),
        (
            "12_CURRENT_CONTRADICTIONS.md",
            WORKSPACE / "outputs/project_intelligence_graph/contradiction_staleness_report.md",
            "b03_contradiction_staleness_human_readable",
            "B03 human-readable contradiction and staleness report.",
        ),
    ]
    current_workspace_evidence: list[dict[str, Any]] = []
    for artifact_name, source_path, role, description in current_workspace_specs:
        if source_path.exists():
            write_text(target_dir / artifact_name, source_path.read_text(encoding="utf-8", errors="replace"))
            current_workspace_evidence.append({
                "artifact_relative_path": artifact_name,
                "source_path": f"<WORKSPACE_ROOT>/{source_path.relative_to(WORKSPACE).as_posix()}",
                "role": role,
                "description": description,
                "sensitivity": "internal_governance_after_redaction",
                "sharing_status": "included_after_redaction",
                "freshness": "current_at_pack_generation",
                "provenance": "generated_by_pig_quality_os",
            })
    provenance_candidates = build_provenance_candidates(target_dir, records, generated_at)
    write_text(
        target_dir / "09_THIRD_PARTY_SOURCE_CANDIDATES.json",
        json.dumps(provenance_candidates, indent=2, ensure_ascii=False),
    )
    write_text(
        target_dir / "09_THIRD_PARTY_SOURCE_CANDIDATES.md",
        build_provenance_candidates_markdown(provenance_candidates),
    )

    leaks = relative_leaks(target_dir)
    secrets = [REDACTED]
    source_registry = {
        "schema_version": 2,
        "generated_at": generated_at,
        "source_dir": "<ORIGINAL_FIRST_ROUND_PACK>",
        "pack_name": pack_name,
        "file_count": len(records),
        "current_workspace_evidence": [
            {
                "artifact_relative_path": "08_CURRENT_STATUS_SEMANTICS.json",
                "source_path": "<WORKSPACE_ROOT>/outputs/project_intelligence_graph/status_semantics_matrix.json",
                "role": "current_status_truth",
                "sensitivity": "internal_governance_after_redaction",
                "sharing_status": "included_after_redaction",
                "freshness": "current_at_pack_generation",
                "provenance": "generated_by_pig_status_semantics",
            },
            {
                "artifact_relative_path": "08_CURRENT_STATUS_SEMANTICS.md",
                "source_path": "<WORKSPACE_ROOT>/outputs/project_intelligence_graph/status_semantics_matrix.md",
                "role": "current_status_truth_human_readable",
                "sensitivity": "internal_governance_after_redaction",
                "sharing_status": "included_after_redaction",
                "freshness": "current_at_pack_generation",
                "provenance": "generated_from_pig_status_semantics_for_round2",
            },
            {
                "artifact_relative_path": "09_THIRD_PARTY_SOURCE_CANDIDATES.json",
                "source_path": "<GENERATED_FROM_SANITIZED_PACK_CONTENT>",
                "role": "third_party_source_provenance_candidate_inventory",
                "sensitivity": "internal_governance_after_redaction",
                "sharing_status": "included_after_redaction",
                "freshness": "current_at_pack_generation",
                "provenance": "generated_by_followup_pack_builder",
            },
            {
                "artifact_relative_path": "09_THIRD_PARTY_SOURCE_CANDIDATES.md",
                "source_path": "<GENERATED_FROM_SANITIZED_PACK_CONTENT>",
                "role": "third_party_source_provenance_candidate_inventory_human_readable",
                "sensitivity": "internal_governance_after_redaction",
                "sharing_status": "included_after_redaction",
                "freshness": "current_at_pack_generation",
                "provenance": "generated_by_followup_pack_builder",
            },
            *current_workspace_evidence,
        ],
        "records": records,
    }
    (target_dir / "SOURCE_REGISTRY.json").write_text(json.dumps(source_registry, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    redaction_report = {
        "schema_version": 1,
        "generated_at": generated_at,
        "pack_name": pack_name,
        "source_file_count": len(records),
        "excluded_file_count": len(excluded),
        "redaction_counts": redactions,
        "excluded": excluded,
        "leak_scan": leaks,
        "secret_scan_hits": secrets,
        "status": "PASS" if not leaks and not secrets else "WARN",
    }
    (target_dir / "REDACTION_REPORT.json").write_text(json.dumps(redaction_report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    report_lines = [
        "# Redaction Report",
        "",
        f"- Status: `{redaction_report['status']}`",
        f"- Source files included: `{len(records)}`",
        f"- Files excluded: `{len(excluded)}`",
        f"- Secret scan hits: `{len(secrets)}`",
        f"- Leak scan categories: `{len(leaks)}`",
        "",
        "## Redaction Counts",
        "",
    ]
    for name, count in sorted(redactions.items()):
        report_lines.append(f"- `{name}`: `{count}`")
    if leaks:
        report_lines.extend(["", "## Remaining Leak Scan Hits", ""])
        for name, paths in leaks.items():
            report_lines.append(f"- `{name}`: `{len(paths)}` files")
    write_text(target_dir / "REDACTION_REPORT.md", "\n".join(report_lines))

    write_manifests(target_dir)
    zip_path = target_dir.with_suffix(".zip")
    zip_dir(target_dir, zip_path)
    zip_digest = hashlib.sha256(zip_path.read_bytes()).hexdigest()

    return {
        "status": redaction_report["status"],
        "pack_dir": str(target_dir),
        "zip_path": str(zip_path),
        "zip_sha256": zip_digest,
        "file_count": sum(1 for path in target_dir.rglob("*") if path.is_file()),
        "zip_size_bytes": zip_path.stat().st_size,
        "redaction_counts": redactions,
        "leak_scan": leaks,
        "secret_scan_hits": secrets,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Build sanitized DreamFactory Deep Research follow-up pack.")
    parser.add_argument("--source-dir", default=str(DEFAULT_SOURCE_DIR))
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT_ROOT))
    parser.add_argument("--name", default="")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    result = build_pack(Path(args.source_dir), Path(args.output_root), args.name or None)
    if args.json:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        print(f"Status: {result['status']}")
        print(f"Pack: {result['pack_dir']}")
        print(f"ZIP: {result['zip_path']}")
        print(f"SHA256: {result['zip_sha256']}")
        print(f"Files: {result['file_count']}")
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
