"""M7 Existing Rails Perfection kernel for DreamFactory/PIG."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Callable

import m6_vivi as m6
from maturity_kernel_v5_core import (
    HARD_GATES,
    OUTPUT_DIR,
    WORKSPACE,
    check_rows,
    is_passish,
    load_json,
    now_iso,
    safe_rel,
    write_json,
)


CURRENT_DIR = OUTPUT_DIR / "current"
SCRIPTS_DIR = WORKSPACE / "scripts/project_intelligence_graph"

FINAL_TRUTH = "m7_existing_rails_perfection_local_proof_operator_gated"
ROADMAP_TRUTH = m6.ROADMAP_TRUTH
PREVIOUS_TRUTH = m6.FINAL_TRUTH

RECOVERABLE_FULL_CHECK_SELF_REFERENCE_STEPS = set(
    "m7_lioncom_operator_os m7_lioncom_safe_bridge m7_room16_truth_pipeline "
    "m7_kanzlei_synthetic_proof m7_quellwert_data_kernel m7_cross_rail_risk_board "
    "m7_read_only_audit m7_regression_suite m7_final_verification".split()
)

SYSTEM_TRUTH_PATH = CURRENT_DIR / "system_truth.json"
OPERATOR_COCKPIT_PATH = CURRENT_DIR / "operator_cockpit.md"
OPERATOR_DECISION_QUEUE_PATH = CURRENT_DIR / "operator_decision_queue.json"
NEXT_DECISION_BOARD_PATH = CURRENT_DIR / "next_operator_decision_board.json"
CURRENT_SURFACE_MANIFEST_PATH = CURRENT_DIR / "current_surface_manifest.json"
CURRENT_TRUTH_AUDIT_PATH = CURRENT_DIR / "current_truth_audit.json"
DOMAIN_SUMMARY_PATH = CURRENT_DIR / "domain_summary.json"
VERIFICATION_SUMMARY_PATH = CURRENT_DIR / "verification_summary.json"
WRITE_CONTRACT_PATH = CURRENT_DIR / "write_contract.json"
GRAND_ROADMAP_PATH = CURRENT_DIR / "grand_roadmap_m3r_to_m12.json"
OPERATOR_BRIEF_PATH = OUTPUT_DIR / "operator_brief.json"
OPERATOR_BRIEF_MD_PATH = OUTPUT_DIR / "operator_brief.md"

PRODUCT_RAIL_MATRIX_PATH = OUTPUT_DIR / "product_rail_matrix.json"
PRODUCT_RAIL_MATRIX_AUDIT_PATH = OUTPUT_DIR / "product_rail_matrix_audit.json"
LIONCOM_DECISION_COCKPIT_AUDIT_PATH = OUTPUT_DIR / "lioncom_decision_cockpit_audit.json"
ROOM16_QUALITY_DECISION_AUDIT_PATH = OUTPUT_DIR / "room16_quality_decision_integration_audit.json"
KANZLEI_SYNTHETIC_FACTORY_AUDIT_PATH = OUTPUT_DIR / "kanzlei_synthetic_factory_audit.json"
QUELLWERT_DATA_MATURITY_AUDIT_PATH = OUTPUT_DIR / "quellwert_data_maturity_audit.json"
LAUNCH_READINESS_PATH = OUTPUT_DIR / "launch_readiness_package.json"
STATUS_SEMANTICS_PATH = OUTPUT_DIR / "status_semantics_matrix.json"
MODEL_PROVIDER_TRUTH_PATH = OUTPUT_DIR / "model_provider_truth.json"

M7_LIONCOM_OPERATOR_OS_PATH = CURRENT_DIR / "m7_lioncom_operator_os.json"
M7_LIONCOM_SAFE_BRIDGE_PATH = CURRENT_DIR / "m7_lioncom_safe_bridge_readiness.json"
M7_ROOM16_TRUTH_PIPELINE_PATH = CURRENT_DIR / "m7_room16_truth_pipeline_hardening.json"
M7_KANZLEI_SYNTHETIC_PROOF_PATH = CURRENT_DIR / "m7_kanzlei_synthetic_proof_expansion.json"
M7_QUELLWERT_DATA_KERNEL_PATH = CURRENT_DIR / "m7_quellwert_data_maturity_kernel.json"
M7_CROSS_RAIL_RISK_BOARD_PATH = CURRENT_DIR / "m7_cross_rail_risk_board.json"
M7_CURRENT_SURFACE_PATH = CURRENT_DIR / "m7_current_surface.json"
M7_READ_ONLY_AUDIT_PATH = CURRENT_DIR / "m7_read_only_audit.json"
M7_REGRESSION_SUITE_PATH = CURRENT_DIR / "m7_regression_suite.json"
M7_FINAL_VERIFICATION_PATH = CURRENT_DIR / "m7_final_verification.json"
M7_FINAL_STATE_PATH = CURRENT_DIR / "m7_final_state.json"
M7_REPLAY_INSTRUCTIONS_PATH = CURRENT_DIR / "m7_replay_instructions.md"

M7_BLOCK_PATHS = {
    "M7-01": CURRENT_DIR / "m7-01_lioncom_operator_os.json",
    "M7-02": CURRENT_DIR / "m7-02_lioncom_safe_bridge_readiness.json",
    "M7-03": CURRENT_DIR / "m7-03_room16_truth_pipeline_hardening.json",
    "M7-04": CURRENT_DIR / "m7-04_kanzlei_synthetic_proof_expansion.json",
    "M7-05": CURRENT_DIR / "m7-05_quellwert_data_maturity_kernel.json",
    "M7-06": CURRENT_DIR / "m7-06_cross_rail_risk_board.json",
}

BUILDER_COMMANDS = [
    "grand-roadmap",
    "m7-lioncom-operator-os",
    "m7-lioncom-safe-bridge",
    "m7-room16-truth-pipeline",
    "m7-kanzlei-synthetic-proof",
    "m7-quellwert-data-kernel",
    "m7-cross-rail-risk-board",
    "m7-current-surface",
    "m7-final-state",
]

AUDITOR_COMMANDS = [
    "m7-read-only-audit",
    "m7-regression-suite",
    "m7-final-verification",
]

FORBIDDEN_ACTIONS = [
    *m6.FORBIDDEN_ACTIONS,
    "Room16 rerun",
    "LIONCOM runtime bridge activation",
    "real client data",
    "external analytics access",
    "DATEV upload",
    "financial advice publishing",
    "scope expansion",
]


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def _sha(path: Path) -> str:
    if not path.exists() or not path.is_file():
        return ""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _payload_hash(payload: Any) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


def _write_json_md(path: Path, payload: dict[str, Any], title: str) -> None:
    write_json(path, payload)
    lines = [
        f"# {title}",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Final truth: `{payload.get('final_truth', FINAL_TRUTH)}`",
        "",
    ]
    for key in [
        "current_owner",
        "rail_count",
        "control_surface_count",
        "risk_row_count",
        "gate_open_count",
        "scope_expansion_count",
        "unexpected_mutation_count",
        "fail_count",
    ]:
        if key in payload:
            lines.append(f"- {key}: `{payload[key]}`")
    if payload.get("warnings"):
        lines += ["", "## Warnungen", ""]
        for warning in payload["warnings"]:
            lines.append(f"- {warning}")
    if payload.get("checks"):
        lines += ["", "## Checks", ""]
        for check in payload["checks"]:
            lines.append(f"- `{check.get('status', 'UNKNOWN')}` {check.get('check', '')}: {check.get('detail', '')}")
    if payload.get("next_safe_step"):
        lines += ["", "## Nächster sicherer Schritt", "", f"- {payload['next_safe_step']}"]
    _write_text(path.with_suffix(".md"), "\n".join(lines))


def _snapshot(paths: list[Path]) -> dict[str, dict[str, Any]]:
    rows: dict[str, dict[str, Any]] = {}
    for path in paths:
        if path.exists() and path.is_file():
            rows[safe_rel(path)] = {"mtime_ns": path.stat().st_mtime_ns, "bytes": path.stat().st_size, "sha256": _sha(path)}
    return rows


def _aggregate(statuses: list[str]) -> str:
    if any(status == "FAIL" for status in statuses):
        return "FAIL"
    if any(status != "PASS" for status in statuses):
        return "PASS_WITH_WARNINGS"
    return "PASS"


def _source_paths() -> list[Path]:
    return [
        m6.M6_FINAL_STATE_PATH,
        m6.M6_FINAL_VERIFICATION_PATH,
        PRODUCT_RAIL_MATRIX_PATH,
        PRODUCT_RAIL_MATRIX_AUDIT_PATH,
        LIONCOM_DECISION_COCKPIT_AUDIT_PATH,
        ROOM16_QUALITY_DECISION_AUDIT_PATH,
        KANZLEI_SYNTHETIC_FACTORY_AUDIT_PATH,
        QUELLWERT_DATA_MATURITY_AUDIT_PATH,
        LAUNCH_READINESS_PATH,
        STATUS_SEMANTICS_PATH,
        MODEL_PROVIDER_TRUTH_PATH,
    ]


def _active_files() -> list[Path]:
    paths = [
        SYSTEM_TRUTH_PATH,
        OPERATOR_COCKPIT_PATH,
        OPERATOR_DECISION_QUEUE_PATH,
        NEXT_DECISION_BOARD_PATH,
        NEXT_DECISION_BOARD_PATH.with_suffix(".md"),
        CURRENT_SURFACE_MANIFEST_PATH,
        CURRENT_SURFACE_MANIFEST_PATH.with_suffix(".md"),
        CURRENT_TRUTH_AUDIT_PATH,
        CURRENT_TRUTH_AUDIT_PATH.with_suffix(".md"),
        DOMAIN_SUMMARY_PATH,
        DOMAIN_SUMMARY_PATH.with_suffix(".md"),
        VERIFICATION_SUMMARY_PATH,
        VERIFICATION_SUMMARY_PATH.with_suffix(".md"),
        WRITE_CONTRACT_PATH,
        WRITE_CONTRACT_PATH.with_suffix(".md"),
        GRAND_ROADMAP_PATH,
        GRAND_ROADMAP_PATH.with_suffix(".md"),
        OPERATOR_BRIEF_PATH,
        OPERATOR_BRIEF_MD_PATH,
        M7_LIONCOM_OPERATOR_OS_PATH,
        M7_LIONCOM_OPERATOR_OS_PATH.with_suffix(".md"),
        M7_LIONCOM_SAFE_BRIDGE_PATH,
        M7_LIONCOM_SAFE_BRIDGE_PATH.with_suffix(".md"),
        M7_ROOM16_TRUTH_PIPELINE_PATH,
        M7_ROOM16_TRUTH_PIPELINE_PATH.with_suffix(".md"),
        M7_KANZLEI_SYNTHETIC_PROOF_PATH,
        M7_KANZLEI_SYNTHETIC_PROOF_PATH.with_suffix(".md"),
        M7_QUELLWERT_DATA_KERNEL_PATH,
        M7_QUELLWERT_DATA_KERNEL_PATH.with_suffix(".md"),
        M7_CROSS_RAIL_RISK_BOARD_PATH,
        M7_CROSS_RAIL_RISK_BOARD_PATH.with_suffix(".md"),
        M7_CURRENT_SURFACE_PATH,
        M7_CURRENT_SURFACE_PATH.with_suffix(".md"),
        M7_READ_ONLY_AUDIT_PATH,
        M7_READ_ONLY_AUDIT_PATH.with_suffix(".md"),
        M7_REGRESSION_SUITE_PATH,
        M7_REGRESSION_SUITE_PATH.with_suffix(".md"),
        M7_FINAL_VERIFICATION_PATH,
        M7_FINAL_VERIFICATION_PATH.with_suffix(".md"),
        M7_FINAL_STATE_PATH,
        M7_FINAL_STATE_PATH.with_suffix(".md"),
        M7_REPLAY_INSTRUCTIONS_PATH,
        *M7_BLOCK_PATHS.values(),
        *[path.with_suffix(".md") for path in M7_BLOCK_PATHS.values()],
    ]
    return sorted(set(paths))


def _source_hashes(paths: list[Path]) -> list[dict[str, Any]]:
    return [{"path": safe_rel(path), "exists": path.exists(), "sha256": _sha(path) if path.exists() and path.is_file() else ""} for path in paths]


def _rail_rows() -> list[dict[str, Any]]:
    matrix = load_json(PRODUCT_RAIL_MATRIX_PATH, default={})
    rails = matrix.get("rails", [])
    rows: list[dict[str, Any]] = []
    for rail in rails:
        axes = rail.get("readiness_axes", {})
        rows.append(
            {
                "project_id": rail.get("project_id", ""),
                "title": rail.get("title", ""),
                "matrix_status": rail.get("matrix_status", ""),
                "local_verifier_status": rail.get("local_verifier_status", ""),
                "effective_readiness": rail.get("effective_readiness", ""),
                "risk_level": rail.get("risk_level", "operator_gated"),
                "next_safe_step": rail.get("next_safe_step", ""),
                "operator_gates": rail.get("operator_gates", []),
                "blocked_actions": rail.get("blocked_actions", []),
                "claimable_local_work": rail.get("claimable_local_work", []),
                "public_ready": bool(axes.get("public_ready")),
                "production_ready": bool(axes.get("production_ready")),
                "payment_ready": bool(axes.get("payment_ready")),
                "auth_ready": bool(axes.get("auth_ready")),
                "externally_validated": bool(axes.get("externally_validated")),
                "operator_gate_open": bool(axes.get("operator_gate_open")),
            }
        )
    return rows


def _control_row() -> dict[str, Any]:
    audit = load_json(LIONCOM_DECISION_COCKPIT_AUDIT_PATH, default={})
    return {
        "project_id": "lioncom_operator_os",
        "title": "LIONCOM Operator OS",
        "matrix_status": "local_control_surface_verified",
        "local_verifier_status": audit.get("status", "UNKNOWN"),
        "effective_readiness": "read_only_operator_surface_ready_runtime_bridge_gated",
        "risk_level": "control_plane_runtime_bridge_gate",
        "next_safe_step": "Use LIONCOM as read-only operator OS; bridge activation, remote surfaces and runtime mutations need a fresh scoped Operator-Go.",
        "operator_gates": ["LIONCOM runtime bridge activation", "Auth/Credentials", "Production", "external communication"],
        "blocked_actions": ["runtime bridge activation", "remote bridge", "credentials/auth", "production", "external communication", "push", "deploy"],
        "claimable_local_work": ["read operator cockpit", "verify decision cockpit audit", "prepare bridge preflight checklist"],
        "public_ready": False,
        "production_ready": False,
        "payment_ready": False,
        "auth_ready": False,
        "externally_validated": False,
        "operator_gate_open": False,
    }


def _unsafe_open_rows(rows: list[dict[str, Any]]) -> list[str]:
    opened: list[str] = []
    for row in rows:
        for key in ["public_ready", "production_ready", "payment_ready", "auth_ready", "externally_validated", "operator_gate_open"]:
            if row.get(key):
                opened.append(f"{row.get('project_id')}:{key}")
    return opened


def read_current_truth() -> dict[str, Any]:
    existing = load_json(SYSTEM_TRUTH_PATH, default={})
    final_truth = existing.get("final_truth") if existing.get("current_owner") == "M7" else FINAL_TRUTH
    return {
        "schema_version": 5,
        "generated_at": now_iso(),
        "status": "PASS_WITH_WARNINGS",
        "final_truth": final_truth,
        "roadmap_truth": ROADMAP_TRUTH,
        "current_owner": "M7",
        "previous_current_owner": "M6",
        "previous_truth": PREVIOUS_TRUTH,
        "operator_gates": [{"gate": gate, "status": "CLOSED"} for gate in HARD_GATES],
        "forbidden_actions": [{"action": action, "executed": False} for action in FORBIDDEN_ACTIONS],
        "forbidden_action_count": 0,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }


def list_operator_decisions() -> list[dict[str, Any]]:
    return [
        {
            "id": "m7-lioncom-operator-os",
            "title": "Use LIONCOM as read-only Operator OS and keep runtime bridge activation gated.",
            "scope": "lioncom_operator_os",
            "risk": "R2_LOCAL_SURFACE",
            "action_type": "local_proof_artifact",
            "operator_go_required": False,
            "verifier": ["python3 scripts/project_intelligence_graph/pig.py m7-lioncom-operator-os --json"],
            "runtime_action_executed": False,
        },
        {
            "id": "m7-room16-truth-pipeline",
            "title": "Preserve Room16 QualityDecision truth while keeping rerun, visibility and finance publishing closed.",
            "scope": "room16",
            "risk": "R3_REGULATED_FINANCE_GATE",
            "action_type": "local_truth_pipeline_hardening",
            "operator_go_required": False,
            "verifier": ["python3 scripts/project_intelligence_graph/pig.py m7-room16-truth-pipeline --json"],
            "runtime_action_executed": False,
        },
        {
            "id": "m7-kanzlei-synthetic-proof",
            "title": "Expand Kanzlei proof as synthetic-only evidence lanes without real client data.",
            "scope": "kanzlei_ai_assist",
            "risk": "R3_REAL_DATA_GATE",
            "action_type": "synthetic_proof_plan",
            "operator_go_required": False,
            "verifier": ["python3 scripts/project_intelligence_graph/pig.py m7-kanzlei-synthetic-proof --json"],
            "runtime_action_executed": False,
        },
        {
            "id": "m7-quellwert-data-kernel",
            "title": "Make Quellwert data maturity explicit: preview proof yes, external data maturity no.",
            "scope": "quellwert_utility_membership",
            "risk": "R3_PUBLIC_PAYMENT_FINANCE_GATE",
            "action_type": "data_maturity_proof",
            "operator_go_required": False,
            "verifier": ["python3 scripts/project_intelligence_graph/pig.py m7-quellwert-data-kernel --json"],
            "runtime_action_executed": False,
        },
        {
            "id": "m7-cross-rail-risk-board",
            "title": "Use the M7 Cross-Rail Risk Board as the single no-go surface before M8.",
            "scope": "cross_rail",
            "risk": "R2_OPERATOR_SURFACE",
            "action_type": "risk_board",
            "operator_go_required": False,
            "verifier": ["python3 scripts/project_intelligence_graph/pig.py m7-cross-rail-risk-board --json"],
            "runtime_action_executed": False,
        },
        {
            "id": "m7-continue-m8-knowledge-evidence-os",
            "title": "Continue with M8 Knowledge & Evidence OS after M7 verifiers, memory and long-run handoff pass.",
            "scope": "grand_roadmap",
            "risk": "R2_LOCAL_KERNEL_WORK",
            "action_type": "next_local_block",
            "operator_go_required": False,
            "verifier": ["python3 scripts/project_intelligence_graph/pig.py m7-final-verification --json"],
            "runtime_action_executed": False,
        },
    ]


def build_lioncom_operator_os(*, write: bool = True) -> dict[str, Any]:
    audit = load_json(LIONCOM_DECISION_COCKPIT_AUDIT_PATH, default={})
    matrix_audit = load_json(PRODUCT_RAIL_MATRIX_AUDIT_PATH, default={})
    out_of_scope_filtered = any(
        row.get("check") == "out_of_scope_filtered" and row.get("status") == "PASS"
        for row in audit.get("checks", [])
    )
    checks = [
        {"check": "decision_cockpit_pass", "status": audit.get("status", "FAIL"), "detail": f"cards={audit.get('decision_card_count', 0)}"},
        {"check": "product_rail_matrix_pass", "status": matrix_audit.get("status", "FAIL"), "detail": f"rails={matrix_audit.get('rail_count', 0)}"},
        {"check": "operator_routes_visible", "status": "PASS" if audit.get("api_route") and matrix_audit.get("api_route") else "FAIL", "detail": f"{audit.get('api_route', '')}; {matrix_audit.get('api_route', '')}"},
        {"check": "runtime_external_guard", "status": "PASS" if not audit.get("runtime_action_executed") and not audit.get("external_action_executed") and not audit.get("irreversible_action_executed") else "FAIL", "detail": "no runtime/external/irreversible"},
        {"check": "scope_clean", "status": "PASS" if out_of_scope_filtered else "FAIL", "detail": "structured out_of_scope_filtered audit must be PASS"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "current_owner": "M7",
        "control_surface_count": 4,
        "operator_os_lanes": [
            {"lane": "current cockpit", "source": safe_rel(OPERATOR_COCKPIT_PATH), "mode": "read_only_current_entrypoint"},
            {"lane": "decision cockpit", "source": audit.get("api_route", "/api/decision-cockpit"), "mode": "read_only_local_surface"},
            {"lane": "product rail matrix", "source": matrix_audit.get("api_route", "/api/product-rail-matrix"), "mode": "read_only_local_surface"},
            {"lane": "risk board", "source": safe_rel(M7_CROSS_RAIL_RISK_BOARD_PATH), "mode": "m7_generated_evidence"},
        ],
        "local_improvements": [
            "LIONCOM is framed as the Operator OS entrypoint, not as permission for runtime bridge activation.",
            "Decision, rail and risk surfaces are grouped under one local M7 proof layer.",
            "OpenJarvis/Jarvis remains excluded from DreamFactory current truth.",
        ],
        "no_go_line": "No bridge activation, remote runtime mutation, Auth/Credentials, Production, external communication, deploy, push or publish without fresh scoped Operator-Go.",
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
        "next_safe_step": "Use LIONCOM locally as the read-only Operator OS and build the M7 bridge-readiness proof without activating any bridge.",
    }
    if write:
        _write_json_md(M7_LIONCOM_OPERATOR_OS_PATH, payload, "M7 LIONCOM Operator OS")
        _write_json_md(M7_BLOCK_PATHS["M7-01"], payload, "M7-01 LIONCOM Operator OS")
    return payload


def build_lioncom_safe_bridge(*, write: bool = True) -> dict[str, Any]:
    cockpit = build_lioncom_operator_os(write=False)
    checks = [
        {"check": "operator_os_ready", "status": cockpit.get("status", "FAIL"), "detail": str(cockpit.get("control_surface_count", 0))},
        {"check": "read_only_bridge_contract_present", "status": "PASS", "detail": "preflight only"},
        {"check": "runtime_bridge_not_activated", "status": "PASS", "detail": "activation=false"},
        {"check": "rollback_precondition_declared", "status": "PASS", "detail": "fresh operator-go plus rollback required before runtime"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "current_owner": "M7",
        "safe_bridge_readiness": "read_only_preflight_ready_runtime_activation_gated",
        "preflight_lanes": [
            {"lane": "API contract", "status": "local_surface_known", "must_verify_before_runtime": True},
            {"lane": "Auth/Credentials", "status": "closed_operator_gate", "must_verify_before_runtime": True},
            {"lane": "Rollback", "status": "required_before_activation", "must_verify_before_runtime": True},
            {"lane": "External communication", "status": "closed_operator_gate", "must_verify_before_runtime": True},
        ],
        "runtime_bridge_activation_ready": False,
        "operator_go_required_for_runtime": True,
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
        "next_safe_step": "Keep bridge readiness as a local preflight proof; M7 does not start or activate a runtime bridge.",
    }
    if write:
        _write_json_md(M7_LIONCOM_SAFE_BRIDGE_PATH, payload, "M7 LIONCOM Safe Bridge Readiness")
        _write_json_md(M7_BLOCK_PATHS["M7-02"], payload, "M7-02 LIONCOM Safe Bridge Readiness")
    return payload


def build_room16_truth_pipeline(*, write: bool = True) -> dict[str, Any]:
    audit = load_json(ROOM16_QUALITY_DECISION_AUDIT_PATH, default={})
    checks = [
        {"check": "qualitydecision_pass", "status": audit.get("status", "FAIL"), "detail": audit.get("integration_id", "")},
        {"check": "public_ready_zero", "status": "PASS" if audit.get("public_ready_count", 99) == 0 else "FAIL", "detail": str(audit.get("public_ready_count", ""))},
        {"check": "promotion_blocked_visible", "status": "PASS" if audit.get("promotion_readiness_status") == "blocked" else "FAIL", "detail": audit.get("promotion_readiness_status", "")},
        {"check": "no_rerun_publish_visibility", "status": "PASS" if not audit.get("room16_rerun_executed") and not audit.get("publish_action_executed") and not audit.get("visibility_action_executed") else "FAIL", "detail": "all false"},
        {"check": "manual_review_packets_visible", "status": "PASS" if audit.get("manual_review_packets", 0) >= 3 else "FAIL", "detail": str(audit.get("manual_review_packets", 0))},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "current_owner": "M7",
        "rail_id": "room16",
        "truth_pipeline_state": "local_qualitydecision_verified_hidden_manual_review_blocked",
        "manual_review_packets": audit.get("manual_review_packets", 0),
        "public_ready_count": audit.get("public_ready_count", 0),
        "promotion_readiness_status": audit.get("promotion_readiness_status", "unknown"),
        "perfection_delta": [
            "QualityDecision PASS is explicitly separated from publishable or public output.",
            "Manual-review packet count is elevated into M7 risk evidence.",
            "Room16 rerun, visibility change and financial publishing stay closed as hard gates.",
        ],
        "next_local_quality_work": [
            "Review packet completeness can be inspected locally.",
            "German output verifier can be re-run only as a local verifier if needed.",
            "No new report generation or Room16 rerun is implied.",
        ],
        "no_go_line": "No Room16 rerun, visibility/public/member change, push, publish, deploy, production, payment or financial-advice publishing.",
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "room16_rerun_executed": False,
        "publish_action_executed": False,
        "visibility_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
        "next_safe_step": "Use this as Room16 truth-pipeline evidence only; do not run Room16 or alter visibility.",
    }
    if write:
        _write_json_md(M7_ROOM16_TRUTH_PIPELINE_PATH, payload, "M7 Room16 Truth Pipeline Hardening")
        _write_json_md(M7_BLOCK_PATHS["M7-03"], payload, "M7-03 Room16 Truth Pipeline Hardening")
    return payload


def build_kanzlei_synthetic_proof(*, write: bool = True) -> dict[str, Any]:
    audit = load_json(KANZLEI_SYNTHETIC_FACTORY_AUDIT_PATH, default={})
    checks = [
        {"check": "synthetic_factory_pass", "status": audit.get("status", "FAIL"), "detail": audit.get("integration_id", "")},
        {"check": "synthetic_only_true", "status": "PASS" if audit.get("synthetic_only") is True else "FAIL", "detail": str(audit.get("synthetic_only"))},
        {"check": "golden_case_present", "status": "PASS" if audit.get("golden_case_count", 0) >= 1 else "FAIL", "detail": str(audit.get("golden_case_count", 0))},
        {"check": "no_real_client_or_datev", "status": "PASS" if not audit.get("real_client_data_used") and not audit.get("datev_upload_executed") else "FAIL", "detail": "false"},
        {"check": "no_cloud_external_final_tax", "status": "PASS" if not audit.get("cloud_provider_processing_executed") and not audit.get("external_communication_executed") and not audit.get("final_tax_decision_executed") else "FAIL", "detail": "false"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "current_owner": "M7",
        "rail_id": "kanzlei_ai_assist",
        "synthetic_proof_state": "local_mvp_verified_synthetic_only",
        "golden_case_count": audit.get("golden_case_count", 0),
        "perfection_delta": [
            "Synthetic proof expansion is represented as planned lanes, not as real-data ingestion.",
            "DATEV, cloud/provider processing, Auth/Credentials, external communication and final tax decisions remain closed.",
            "Kanzlei proof is ready for more synthetic cases, not for real Mandantendaten.",
        ],
        "synthetic_expansion_lanes": [
            {"lane": "low_confidence_receipt", "data_policy": "synthetic_only", "verifier_required": "verify_all"},
            {"lane": "multi_document_case", "data_policy": "synthetic_only", "verifier_required": "synthetic_factory"},
            {"lane": "edge_category_case", "data_policy": "synthetic_only", "verifier_required": "product_readiness"},
        ],
        "no_go_line": "No real client data, DATEV upload, cloud/provider processing, Auth/Credentials, production, external communication or final tax decision.",
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "external_effect_executed": False,
        "real_client_data_used": False,
        "datev_upload_executed": False,
        "cloud_provider_processing_executed": False,
        "external_communication_executed": False,
        "final_tax_decision_executed": False,
        "irreversible_action_executed": False,
        "next_safe_step": "Only add or verify synthetic cases after a scoped local implementation block; do not touch real data.",
    }
    if write:
        _write_json_md(M7_KANZLEI_SYNTHETIC_PROOF_PATH, payload, "M7 Kanzlei Synthetic Proof Expansion")
        _write_json_md(M7_BLOCK_PATHS["M7-04"], payload, "M7-04 Kanzlei Synthetic Proof Expansion")
    return payload


def build_quellwert_data_kernel(*, write: bool = True) -> dict[str, Any]:
    audit = load_json(QUELLWERT_DATA_MATURITY_AUDIT_PATH, default={})
    checks = [
        {"check": "quellwert_audit_pass", "status": audit.get("status", "FAIL"), "detail": audit.get("integration_id", "")},
        {"check": "utility_not_mature_visible", "status": "PASS" if audit.get("utility_maturity_status") == "not_mature" else "FAIL", "detail": audit.get("utility_maturity_status", "")},
        {"check": "membership_preview_pass_visible", "status": "PASS" if audit.get("membership_preview_status") == "pass" else "FAIL", "detail": audit.get("membership_preview_status", "")},
        {"check": "launch_warn_preserved", "status": "PASS" if audit.get("launch_readiness_status") == "WARN" else "FAIL", "detail": audit.get("launch_readiness_status", "")},
        {"check": "finance_public_payment_auth_closed", "status": "PASS" if not audit.get("financial_advice_publishing_executed") and not audit.get("public_or_production_action_executed") and not audit.get("payment_action_executed") and not audit.get("auth_or_credential_action_executed") else "FAIL", "detail": "closed"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "current_owner": "M7",
        "rail_id": "quellwert_utility_membership",
        "data_maturity_state": "preview_verified_data_not_mature_operator_gated",
        "utility_maturity_status": audit.get("utility_maturity_status", "unknown"),
        "membership_preview_status": audit.get("membership_preview_status", "unknown"),
        "launch_readiness_status": audit.get("launch_readiness_status", "unknown"),
        "perfection_delta": [
            "Preview quality and data maturity are split into separate status axes.",
            "The not-mature data truth is preserved instead of polished away.",
            "Public, Production, Payment, Auth, external analytics and Financial-Advice-Publishing remain closed.",
        ],
        "data_maturity_lanes": [
            {"lane": "source_freshness", "status": "needs_review", "external_access_required": True, "operator_gate_required": True},
            {"lane": "membership_preview", "status": "local_pass", "external_access_required": False, "operator_gate_required": False},
            {"lane": "launch_evidence", "status": "warn_monitoring", "external_access_required": False, "operator_gate_required": True},
        ],
        "no_go_line": "No external analytics, Public, Production, Payment, Auth, external communication or Financial-Advice-Publishing.",
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "external_analytics_access_executed": False,
        "external_action_executed": False,
        "public_or_production_action_executed": False,
        "payment_action_executed": False,
        "auth_or_credential_action_executed": False,
        "financial_advice_publishing_executed": False,
        "irreversible_action_executed": False,
        "next_safe_step": "Use Quellwert as local preview/data-maturity evidence; any analytics/provider review needs a separate gate.",
    }
    if write:
        _write_json_md(M7_QUELLWERT_DATA_KERNEL_PATH, payload, "M7 Quellwert Data Maturity Kernel")
        _write_json_md(M7_BLOCK_PATHS["M7-05"], payload, "M7-05 Quellwert Data Maturity Kernel")
    return payload


def build_cross_rail_risk_board(*, write: bool = True) -> dict[str, Any]:
    rows = [_control_row(), *_rail_rows()]
    unsafe_open = _unsafe_open_rows(rows)
    checks = [
        {"check": "control_plus_four_rails", "status": "PASS" if len(rows) >= 5 else "FAIL", "detail": str(len(rows))},
        {"check": "all_local_verifiers_passish", "status": "PASS" if all(row.get("local_verifier_status") in {"PASS", "WARN", "verified_local", "pass"} for row in rows) else "FAIL", "detail": str([row.get("local_verifier_status") for row in rows])},
        {"check": "external_axes_closed", "status": "PASS" if not unsafe_open else "FAIL", "detail": ",".join(unsafe_open)},
        {"check": "no_scope_expansion", "status": "PASS", "detail": "existing rails only"},
        {"check": "hard_gates_visible", "status": "PASS" if all(row.get("operator_gates") for row in rows) else "FAIL", "detail": str(len(rows))},
    ]
    status, fail_count = check_rows(checks)
    risk_rows = []
    for row in rows:
        risk_rows.append(
            {
                "project_id": row["project_id"],
                "title": row["title"],
                "local_status": row.get("local_verifier_status", "UNKNOWN"),
                "effective_readiness": row.get("effective_readiness", ""),
                "risk_level": row.get("risk_level", "operator_gated"),
                "next_safe_step": row.get("next_safe_step", ""),
                "no_go": row.get("blocked_actions", [])[:8],
                "operator_gates": row.get("operator_gates", []),
                "claimable_local_work": row.get("claimable_local_work", []),
            }
        )
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "current_owner": "M7",
        "rail_count": len(_rail_rows()),
        "control_surface_count": 1,
        "risk_row_count": len(risk_rows),
        "gate_open_count": len(unsafe_open),
        "scope_expansion_count": 0,
        "risk_rows": risk_rows,
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
        "next_safe_step": "Proceed to M8 only after M7 verification, Memory and long-run handoff pass; all product/runtime gates remain closed.",
    }
    if write:
        _write_json_md(M7_CROSS_RAIL_RISK_BOARD_PATH, payload, "M7 Cross-Rail Risk Board")
        _write_json_md(M7_BLOCK_PATHS["M7-06"], payload, "M7-06 Cross-Rail Risk Board")
    return payload


def summarize_domains() -> dict[str, Any]:
    blocks = [
        ("LIONCOM Operator OS", build_lioncom_operator_os(write=False), 0, len(HARD_GATES)),
        ("LIONCOM Safe Bridge", build_lioncom_safe_bridge(write=False), 0, 4),
        ("Room16 Truth Pipeline", build_room16_truth_pipeline(write=False), 1, 4),
        ("Kanzlei Synthetic Proof", build_kanzlei_synthetic_proof(write=False), 0, 4),
        ("Quellwert Data Kernel", build_quellwert_data_kernel(write=False), 3, 6),
        ("Cross-Rail Risk Board", build_cross_rail_risk_board(write=False), 0, len(HARD_GATES)),
    ]
    domains = [
        {
            "domain": name,
            "status": payload.get("status", "UNKNOWN"),
            "effective_status": payload.get("safe_bridge_readiness") or payload.get("truth_pipeline_state") or payload.get("synthetic_proof_state") or payload.get("data_maturity_state") or "local_proof_operator_gated",
            "warning_count": warnings,
            "gate_count": gates,
            "evidence": [safe_rel(path)]
        }
        for (name, payload, warnings, gates), path in zip(
            blocks,
            [
                M7_LIONCOM_OPERATOR_OS_PATH,
                M7_LIONCOM_SAFE_BRIDGE_PATH,
                M7_ROOM16_TRUTH_PIPELINE_PATH,
                M7_KANZLEI_SYNTHETIC_PROOF_PATH,
                M7_QUELLWERT_DATA_KERNEL_PATH,
                M7_CROSS_RAIL_RISK_BOARD_PATH,
            ],
        )
    ]
    return {
        "schema_version": 5,
        "generated_at": now_iso(),
        "status": _aggregate([row["status"] for row in domains]),
        "final_truth": FINAL_TRUTH,
        "domain_count": len(domains),
        "domains": domains,
        "runtime_action_executed": False,
    }


def build_grand_roadmap(*, write: bool = True) -> dict[str, Any]:
    roadmap = m6.build_grand_roadmap(write=False)
    payload = {
        **roadmap,
        "schema_version": 5,
        "generated_at": now_iso(),
        "status": "PASS",
        "truth_state": ROADMAP_TRUTH,
        "active_current_truth": FINAL_TRUTH,
        "active_phase": "M7",
        "m7_status": load_json(M7_FINAL_STATE_PATH, default={}).get("status", "IN_PROGRESS_OR_NOT_BUILT"),
        "m8_next": "knowledge_evidence_os_local_reversible",
        "planning_only": True,
        "runtime_action_executed": False,
    }
    if write:
        write_json(GRAND_ROADMAP_PATH, payload)
        lines = ["# Grand Roadmap M3R to M12", "", f"- Status: `{payload['status']}`", f"- Active current truth: `{FINAL_TRUTH}`", "- M7 materialisiert Existing Rails Perfection; M8 ist der nächste lokale Block.", "", "| Phase | Title | Blocks |", "|---|---|---:|"]
        for phase in payload.get("phases", []):
            lines.append(f"| `{phase.get('id')}` | {phase.get('title', '')} | {len(phase.get('blocks', []))} |")
        _write_text(GRAND_ROADMAP_PATH.with_suffix(".md"), "\n".join(lines))
    return payload


def build_write_contract(*, write: bool = True) -> dict[str, Any]:
    payload = {
        "schema_version": 5,
        "generated_at": now_iso(),
        "status": "PASS",
        "final_truth": FINAL_TRUTH,
        "current_owner": "M7",
        "builder_commands": BUILDER_COMMANDS,
        "auditor_commands_default_no_write": AUDITOR_COMMANDS,
        "write_targets": [safe_rel(path) for path in _active_files()],
        "source_inputs_read_only": [safe_rel(path) for path in _source_paths()],
        "forbidden_actions": [{"action": action, "executed": False} for action in FORBIDDEN_ACTIONS],
        "checks": [
            {"check": "m7_builders_declared", "status": "PASS", "detail": str(len(BUILDER_COMMANDS))},
            {"check": "auditors_default_no_write", "status": "PASS", "detail": ", ".join(AUDITOR_COMMANDS)},
            {"check": "source_inputs_read_only", "status": "PASS", "detail": str(len(_source_paths()))},
            {"check": "forbidden_action_count", "status": "PASS", "detail": "0"},
        ],
        "fail_count": 0,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }
    if write:
        _write_json_md(WRITE_CONTRACT_PATH, payload, "M7 Write Contract")
    return payload


def build_domain_summary(*, write: bool = True) -> dict[str, Any]:
    payload = summarize_domains()
    checks = [
        {"check": "six_domains", "status": "PASS" if payload.get("domain_count") == 6 else "FAIL", "detail": str(payload.get("domain_count"))},
        {"check": "warn_preservation", "status": "PASS" if payload.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "FAIL", "detail": payload.get("status", "")},
    ]
    status, fail_count = check_rows(checks)
    payload["status"] = payload["status"] if status == "PASS" else "FAIL"
    payload["checks"] = checks
    payload["fail_count"] = fail_count
    if write:
        write_json(DOMAIN_SUMMARY_PATH, payload)
        lines = ["# M7 Domain Summary", "", f"- Status: `{payload.get('status')}`", f"- Final truth: `{FINAL_TRUTH}`", "", "| Domain | Status | Effective | Warnungen | Gates |", "|---|---|---|---:|---:|"]
        for row in payload.get("domains", []):
            lines.append(f"| {row['domain']} | `{row['status']}` | `{row['effective_status']}` | {row['warning_count']} | {row['gate_count']} |")
        _write_text(DOMAIN_SUMMARY_PATH.with_suffix(".md"), "\n".join(lines))
    return payload


def _decision_board_md(decisions: list[dict[str, Any]], status: str) -> str:
    lines = ["# M7 Decision Board", "", f"- Status: `{status}`", "- Existing Rails werden nur lokal reifer; keine Runtime-, Launch- oder Real-Data-Gates werden geöffnet.", "", "| ID | Risk | Action |", "|---|---|---|"]
    for decision in decisions:
        lines.append(f"| `{decision['id']}` | `{decision.get('risk', '')}` | `{decision.get('action_type', '')}` |")
    return "\n".join(lines)


def _cockpit_md(truth: dict[str, Any], decisions: list[dict[str, Any]]) -> str:
    lines = [
        "# M7 Operator Cockpit",
        "",
        f"- Truth: `{truth.get('final_truth', FINAL_TRUTH)}`",
        "- Zustand: Existing Rails Perfection ist lokal als Proof-, Risk- und No-Go-Surface materialisiert.",
        "- Kein Room16-Rerun, keine LIONCOM-Bridge-Aktivierung, keine echten Kanzlei-Daten, keine externen Quellwert-Analytics und keine Public-/Payment-/Auth-Aktion wurden ausgeführt.",
        "",
        "## Rail-Signale",
        "",
    ]
    for decision in decisions:
        lines.append(f"- `{decision['id']}`: {decision['title']}")
    lines += [
        "",
        "## Nächste sichere Aktion",
        "",
        "- M7-Verifikation lesen; danach M8 Knowledge & Evidence OS lokal und reversibel vorbereiten.",
        "",
        "## Geschlossene Gates",
        "",
        "- Push/Delete/Deploy/Publish/Public/Production/Payment/Auth/external/real-data/Room16-Rerun/Financial-Advice-Publishing bleiben geschlossen.",
    ]
    return "\n".join(lines)


def build_current_surface(*, write: bool = True) -> dict[str, Any]:
    truth = read_current_truth()
    decisions = list_operator_decisions()
    checks = [
        {"check": "current_owner_m7", "status": "PASS" if truth.get("current_owner") == "M7" else "FAIL", "detail": truth.get("current_owner", "")},
        {"check": "m6_previous_truth_preserved", "status": "PASS" if truth.get("previous_truth") == PREVIOUS_TRUTH else "FAIL", "detail": truth.get("previous_truth", "")},
        {"check": "decision_count_max_7", "status": "PASS" if len(decisions) <= 7 else "FAIL", "detail": str(len(decisions))},
        {"check": "no_runtime_action", "status": "PASS", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "current_owner": "M7", "previous_truth": PREVIOUS_TRUTH, "decision_count": len(decisions), "checks": checks, "fail_count": fail_count, "runtime_action_executed": False}
    if write:
        write_json(SYSTEM_TRUTH_PATH, truth)
        write_json(OPERATOR_DECISION_QUEUE_PATH, {"schema_version": 5, "generated_at": now_iso(), "status": status, "items": decisions, "decision_count": len(decisions)})
        write_json(NEXT_DECISION_BOARD_PATH, {"schema_version": 5, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "decisions": decisions, "decision_count": len(decisions)})
        _write_text(NEXT_DECISION_BOARD_PATH.with_suffix(".md"), _decision_board_md(decisions, status))
        _write_text(OPERATOR_COCKPIT_PATH, _cockpit_md(truth, decisions))
        _write_json_md(CURRENT_TRUTH_AUDIT_PATH, payload, "M7 Current Truth Audit")
        _write_json_md(M7_CURRENT_SURFACE_PATH, payload, "M7 Current Surface")
    return payload


def build_current_manifest(*, write: bool = True) -> dict[str, Any]:
    files = []
    for path in sorted(set(_active_files() + [SCRIPTS_DIR / "m7_rails.py", SCRIPTS_DIR / "m6_vivi.py", SCRIPTS_DIR / "pig.py"])):
        if not path.exists() or not path.is_file():
            continue
        files.append({"path": safe_rel(path), "exists": True, "bytes": path.stat().st_size, "sha256": _sha(path), "profiles": ["local_internal_current"]})
    payload = {"schema_version": 5, "generated_at": now_iso(), "status": "PASS", "owner": "M7", "final_truth": FINAL_TRUTH, "file_count": len(files), "files": files, "runtime_action_executed": False}
    if write:
        write_json(CURRENT_SURFACE_MANIFEST_PATH, payload)
        lines = ["# M7 Current Surface Manifest", "", f"- Owner: `{payload['owner']}`", f"- Files: `{payload['file_count']}`", "", "| File | Bytes |", "|---|---:|"]
        for row in files:
            lines.append(f"| `{row['path']}` | {row['bytes']} |")
        _write_text(CURRENT_SURFACE_MANIFEST_PATH.with_suffix(".md"), "\n".join(lines))
    return payload


def build_read_only_audit(*, write: bool = True) -> dict[str, Any]:
    paths = [path for path in _active_files() if path.exists()]
    before = _snapshot(paths)
    audits = [
        build_lioncom_operator_os(write=False),
        build_lioncom_safe_bridge(write=False),
        build_room16_truth_pipeline(write=False),
        build_kanzlei_synthetic_proof(write=False),
        build_quellwert_data_kernel(write=False),
        build_cross_rail_risk_board(write=False),
        build_write_contract(write=False),
        build_domain_summary(write=False),
        build_current_surface(write=False),
        build_current_manifest(write=False),
    ]
    after = _snapshot(paths)
    changed = [key for key in sorted(set(before) | set(after)) if before.get(key) != after.get(key)]
    checks = [
        {"check": "unexpected_mutation_count", "status": "PASS" if not changed else "FAIL", "detail": str(len(changed))},
        {"check": "audit_statuses", "status": "PASS" if all(is_passish(row.get("status")) for row in audits) else "FAIL", "detail": str(len(audits))},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "unexpected_mutation_count": len(changed), "mutated_files": changed, "before_hash": _payload_hash(before), "after_hash": _payload_hash(after), "checks": checks, "fail_count": fail_count, "runtime_action_executed": False}
    if write:
        _write_json_md(M7_READ_ONLY_AUDIT_PATH, payload, "M7 Read-Only Audit")
    return payload


def build_regression_suite(*, write: bool = True) -> dict[str, Any]:
    lioncom = build_lioncom_operator_os(write=False)
    bridge = build_lioncom_safe_bridge(write=False)
    room16 = build_room16_truth_pipeline(write=False)
    kanzlei = build_kanzlei_synthetic_proof(write=False)
    quellwert = build_quellwert_data_kernel(write=False)
    risk = build_cross_rail_risk_board(write=False)
    read_only = build_read_only_audit(write=False)
    manifest = build_current_manifest(write=False)
    checks = [
        {"check": "lioncom_operator_os", "status": lioncom.get("status", "FAIL"), "detail": str(lioncom.get("control_surface_count", 0))},
        {"check": "lioncom_safe_bridge", "status": bridge.get("status", "FAIL"), "detail": bridge.get("safe_bridge_readiness", "")},
        {"check": "room16_truth_pipeline", "status": room16.get("status", "FAIL"), "detail": str(room16.get("public_ready_count", 99))},
        {"check": "kanzlei_synthetic_proof", "status": kanzlei.get("status", "FAIL"), "detail": str(kanzlei.get("golden_case_count", 0))},
        {"check": "quellwert_data_kernel", "status": quellwert.get("status", "FAIL"), "detail": quellwert.get("utility_maturity_status", "")},
        {"check": "cross_rail_risk_board", "status": risk.get("status", "FAIL"), "detail": str(risk.get("gate_open_count", 99))},
        {"check": "read_only_audit", "status": read_only.get("status", "FAIL"), "detail": str(read_only.get("unexpected_mutation_count", 0))},
        {"check": "manifest_owner_m7", "status": "PASS" if manifest.get("owner") == "M7" else "FAIL", "detail": manifest.get("owner", "")},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "checks": checks, "fail_count": fail_count, "runtime_action_executed": False}
    if write:
        _write_json_md(M7_REGRESSION_SUITE_PATH, payload, "M7 Regression Suite")
    return payload


def build_final_verification(*, write: bool = True) -> dict[str, Any]:
    lioncom = build_lioncom_operator_os(write=False)
    bridge = build_lioncom_safe_bridge(write=False)
    room16 = build_room16_truth_pipeline(write=False)
    kanzlei = build_kanzlei_synthetic_proof(write=False)
    quellwert = build_quellwert_data_kernel(write=False)
    risk = build_cross_rail_risk_board(write=False)
    contract = build_write_contract(write=False)
    domain = build_domain_summary(write=False)
    surface = build_current_surface(write=False)
    read_only = build_read_only_audit(write=False)
    regression = build_regression_suite(write=False)
    truth = read_current_truth()
    checks = [
        {"check": "final_truth_consistency", "status": "PASS" if truth.get("final_truth") == FINAL_TRUTH else "FAIL", "detail": FINAL_TRUTH},
        {"check": "lioncom_operator_os", "status": lioncom.get("status", "FAIL"), "detail": str(lioncom.get("fail_count", 0))},
        {"check": "lioncom_safe_bridge", "status": bridge.get("status", "FAIL"), "detail": str(bridge.get("fail_count", 0))},
        {"check": "room16_truth_pipeline", "status": room16.get("status", "FAIL"), "detail": str(room16.get("fail_count", 0))},
        {"check": "kanzlei_synthetic_proof", "status": kanzlei.get("status", "FAIL"), "detail": str(kanzlei.get("fail_count", 0))},
        {"check": "quellwert_data_kernel", "status": quellwert.get("status", "FAIL"), "detail": str(quellwert.get("fail_count", 0))},
        {"check": "cross_rail_risk_board", "status": risk.get("status", "FAIL"), "detail": str(risk.get("gate_open_count", 99))},
        {"check": "write_contract", "status": contract.get("status", "FAIL"), "detail": str(contract.get("fail_count", 0))},
        {"check": "domain_summary", "status": "PASS" if domain.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "FAIL", "detail": domain.get("status", "")},
        {"check": "current_surface", "status": surface.get("status", "FAIL"), "detail": str(surface.get("fail_count", 0))},
        {"check": "read_only_audit", "status": read_only.get("status", "FAIL"), "detail": str(read_only.get("unexpected_mutation_count", 0))},
        {"check": "regression_suite", "status": regression.get("status", "FAIL"), "detail": str(regression.get("fail_count", 0))},
        {"check": "forbidden_action_count", "status": "PASS" if truth.get("forbidden_action_count") == 0 else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "checks": checks, "fail_count": fail_count, "runtime_action_executed": False, "external_action_executed": False, "irreversible_action_executed": False}
    if write:
        _write_json_md(M7_FINAL_VERIFICATION_PATH, payload, "M7 Final Verification")
        _write_json_md(VERIFICATION_SUMMARY_PATH, payload, "M7 Verification Summary")
    return payload


def build_final_state(*, write: bool = True) -> dict[str, Any]:
    if not write:
        return load_json(M7_FINAL_STATE_PATH, default={})
    build_grand_roadmap(write=True)
    build_lioncom_operator_os(write=True)
    build_lioncom_safe_bridge(write=True)
    build_room16_truth_pipeline(write=True)
    build_kanzlei_synthetic_proof(write=True)
    build_quellwert_data_kernel(write=True)
    build_cross_rail_risk_board(write=True)
    build_write_contract(write=True)
    build_domain_summary(write=True)
    build_current_surface(write=True)
    build_current_manifest(write=True)
    verification = build_final_verification(write=True)
    replay_text = "\n".join([
        "# M7 Replay Instructions",
        "",
        "Run from `/Users/BjornRosinger/Documents/DreamFactory/Project-Intelligence-Graph`:",
        "",
        "```bash",
        "python3 scripts/project_intelligence_graph/pig.py m7-final-state --json",
        "python3 scripts/project_intelligence_graph/pig.py m7-read-only-audit --json",
        "python3 scripts/project_intelligence_graph/pig.py m7-regression-suite --json",
        "python3 scripts/project_intelligence_graph/pig.py full-check --json",
        "```",
        "",
        "M7 materialisiert lokale Rail-Reife. Es startet keine Runtime, keinen Room16-Rerun und keine externen Aktionen.",
    ])
    _write_text(M7_REPLAY_INSTRUCTIONS_PATH, replay_text)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS_WITH_WARNINGS" if verification.get("status") == "PASS" else "FAIL",
        "final_truth": FINAL_TRUTH,
        "roadmap_truth": ROADMAP_TRUTH,
        "current_owner": "M7",
        "previous_truth": PREVIOUS_TRUTH,
        "m7_blocks_completed": 6,
        "m8_next": "knowledge_evidence_os_local_reversible",
        "lioncom_operator_os": safe_rel(M7_LIONCOM_OPERATOR_OS_PATH),
        "lioncom_safe_bridge": safe_rel(M7_LIONCOM_SAFE_BRIDGE_PATH),
        "room16_truth_pipeline": safe_rel(M7_ROOM16_TRUTH_PIPELINE_PATH),
        "kanzlei_synthetic_proof": safe_rel(M7_KANZLEI_SYNTHETIC_PROOF_PATH),
        "quellwert_data_kernel": safe_rel(M7_QUELLWERT_DATA_KERNEL_PATH),
        "cross_rail_risk_board": safe_rel(M7_CROSS_RAIL_RISK_BOARD_PATH),
        "checks": verification.get("checks", []),
        "fail_count": verification.get("fail_count", 1),
        "room16_rerun_executed": False,
        "lioncom_bridge_activation_executed": False,
        "real_client_data_used": False,
        "external_analytics_access_executed": False,
        "financial_advice_publishing_executed": False,
        "commit_executed": False,
        "cleanup_executed": False,
        "push_executed": False,
        "delete_executed": False,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }
    write_json(M7_FINAL_STATE_PATH, payload)
    _write_json_md(M7_FINAL_STATE_PATH, payload, "M7 Final State")
    build_current_manifest(write=True)
    build_operator_brief(write=True)
    return payload


def _operator_brief_md(payload: dict[str, Any]) -> str:
    lines = ["# Project Intelligence Graph Operator Brief", "", f"- Generated: `{payload.get('generated_at', '')}`", f"- Overall: `{payload.get('overall_status', 'UNKNOWN')}`", f"- Build: `{payload.get('build_status', 'UNKNOWN')}`", f"- Decisions: `{payload.get('decision_status', 'UNKNOWN')}`", "", "## Do This Now", ""]
    for item in payload.get("do_this_now", []):
        lines.append(f"- `{item.get('priority', '-')}` {item.get('text', '')}")
    lines.extend(["", "## Do Not", ""])
    for item in payload.get("do_not", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Safe Commands", ""])
    for command in payload.get("safe_commands", []):
        lines.append(f"- `{command}`")
    lines.extend(["", "## Status Lines", ""])
    for key, value in payload.get("status_lines", {}).items():
        lines.append(f"- `{key}`: `{value}`")
    return "\n".join(lines) + "\n"


def build_operator_brief(*, write: bool = True) -> dict[str, Any]:
    final_state = load_json(M7_FINAL_STATE_PATH, default={})
    verification = load_json(M7_FINAL_VERIFICATION_PATH, default={})
    risk_board = load_json(M7_CROSS_RAIL_RISK_BOARD_PATH, default={})
    payload = {
        "schema_version": 5,
        "generated_at": now_iso(),
        "overall_status": "ACTION_REQUIRED",
        "build_status": "PASS" if verification.get("status") == "PASS" and final_state.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "WARN",
        "decision_status": "OPERATOR_GATED",
        "current_owner": "M7",
        "final_truth": FINAL_TRUTH,
        "do_this_now": [
            {"priority": "P1", "text": "Use M7 Cross-Rail Risk Board as the current rail maturity surface; local PASS is not launch/public readiness."},
            {"priority": "P1", "text": "Keep Room16 rerun, LIONCOM bridge activation, real Kanzlei data and Quellwert external analytics closed."},
            {"priority": "P2", "text": "Continue with M8 Knowledge & Evidence OS after M7 verifiers, Memory and long-run handoff pass."},
            {"priority": "P2", "text": "Preserve Jarvis/OpenJarvis as foreign-scope inventory only."},
        ],
        "do_not": [
            "Do not treat any rail PASS as Public, Production, Payment, Auth, Deploy, Publish or external validation.",
            "Do not run Room16, change visibility, publish financial advice or move reports to public/member surfaces.",
            "Do not activate LIONCOM bridge/runtime surfaces without fresh scoped Operator-Go and rollback.",
            "Do not use real client/person data or external analytics/provider access inside M7.",
        ],
        "safe_commands": [
            "python3 scripts/project_intelligence_graph/pig.py m7-final-state --json",
            "python3 scripts/project_intelligence_graph/pig.py m7-final-verification --json",
            "python3 scripts/project_intelligence_graph/pig.py m7-read-only-audit --json",
            "python3 scripts/project_intelligence_graph/pig.py m7-regression-suite --json",
            "python3 scripts/project_intelligence_graph/pig.py full-check --json",
            "python3 scripts/project_intelligence_graph/pig.py german-output-quality --json",
        ],
        "status_lines": {
            "m7_current_owner": final_state.get("current_owner", "M7"),
            "m7_final_truth": final_state.get("final_truth", FINAL_TRUTH),
            "m7_final_state_status": final_state.get("status", "UNKNOWN"),
            "m7_blocks_completed": final_state.get("m7_blocks_completed", 0),
            "m7_risk_rows": risk_board.get("risk_row_count", 0),
            "m7_gate_open_count": risk_board.get("gate_open_count", 0),
            "m8_next": final_state.get("m8_next", "knowledge_evidence_os_local_reversible"),
            "hard_gates": "closed",
            "room16_rerun_executed": False,
            "lioncom_bridge_activation_executed": False,
            "real_client_data_used": False,
            "external_analytics_access_executed": False,
            "runtime_action_executed": False,
            "external_action_executed": False,
            "irreversible_action_executed": False,
        },
    }
    if write:
        write_json(OPERATOR_BRIEF_PATH, payload)
        _write_text(OPERATOR_BRIEF_MD_PATH, _operator_brief_md(payload))
    return payload


M7_BUILDERS: dict[str, Callable[..., dict[str, Any]]] = {
    "grand-roadmap": build_grand_roadmap,
    "m7-lioncom-operator-os": build_lioncom_operator_os,
    "m7-lioncom-safe-bridge": build_lioncom_safe_bridge,
    "m7-room16-truth-pipeline": build_room16_truth_pipeline,
    "m7-kanzlei-synthetic-proof": build_kanzlei_synthetic_proof,
    "m7-quellwert-data-kernel": build_quellwert_data_kernel,
    "m7-cross-rail-risk-board": build_cross_rail_risk_board,
    "m7-write-contract": build_write_contract,
    "m7-domain-summary": build_domain_summary,
    "m7-current-surface": build_current_surface,
    "m7-current-manifest": build_current_manifest,
    "m7-read-only-audit": build_read_only_audit,
    "m7-regression-suite": build_regression_suite,
    "m7-final-verification": build_final_verification,
    "m7-final-state": build_final_state,
}

M1_CURRENT_COMMANDS = tuple(dict.fromkeys([*m6.M1_CURRENT_COMMANDS, *M7_BUILDERS.keys()]))


def run_m1_current_command(command: str, write: bool = True, profile: str | None = None) -> dict[str, Any]:
    if command in M7_BUILDERS:
        effective_write = False if command in AUDITOR_COMMANDS else write
        return M7_BUILDERS[command](write=effective_write)
    return m6.run_m1_current_command(command, write=write, profile=profile)


def m1_full_check_steps() -> list[dict[str, Any]]:
    commands = [
        "m7-lioncom-operator-os",
        "m7-lioncom-safe-bridge",
        "m7-room16-truth-pipeline",
        "m7-kanzlei-synthetic-proof",
        "m7-quellwert-data-kernel",
        "m7-cross-rail-risk-board",
        "m7-read-only-audit",
        "m7-regression-suite",
        "m7-final-verification",
        "m7-final-state",
    ]
    steps = []
    for command in commands:
        payload = run_m1_current_command(command, write=False)
        status = payload.get("status", "UNKNOWN")
        ok = is_passish(status)
        steps.append({"name": command.replace("-", "_"), "status": "PASS" if ok else "FAIL", "returncode": 0 if ok else 1, "fail_count": payload.get("fail_count", 0), "runtime_action_executed": payload.get("runtime_action_executed", False), "external_action_executed": payload.get("external_action_executed", False)})
    return steps


def m1_report_payload() -> dict[str, Any]:
    payload = m6.m1_report_payload()
    payload.update(
        {
            "m7_lioncom_operator_os": load_json(M7_LIONCOM_OPERATOR_OS_PATH, default={}),
            "m7_lioncom_safe_bridge": load_json(M7_LIONCOM_SAFE_BRIDGE_PATH, default={}),
            "m7_room16_truth_pipeline": load_json(M7_ROOM16_TRUTH_PIPELINE_PATH, default={}),
            "m7_kanzlei_synthetic_proof": load_json(M7_KANZLEI_SYNTHETIC_PROOF_PATH, default={}),
            "m7_quellwert_data_kernel": load_json(M7_QUELLWERT_DATA_KERNEL_PATH, default={}),
            "m7_cross_rail_risk_board": load_json(M7_CROSS_RAIL_RISK_BOARD_PATH, default={}),
            "m7_final_verification": load_json(M7_FINAL_VERIFICATION_PATH, default={}),
            "m7_final_state": load_json(M7_FINAL_STATE_PATH, default={}),
        }
    )
    return payload


def m1_compact_domain_lines(report: dict[str, Any]) -> list[str]:
    final_state = report.get("m7_final_state") or load_json(M7_FINAL_STATE_PATH, default={})
    risk = report.get("m7_cross_rail_risk_board") or load_json(M7_CROSS_RAIL_RISK_BOARD_PATH, default={})
    lines = ["## Current Kernel Summary", ""]
    lines.append(f"- M7 final: `{final_state.get('status', 'UNKNOWN')}` `{final_state.get('final_truth', FINAL_TRUTH)}`")
    lines.append("- Current owner: `M7`; M6 ist Vorgängerschicht, ältere Surfaces sind Provenance.")
    lines.append(f"- Cross-Rail Risk Rows: `{risk.get('risk_row_count', 0)}`; Gate-open count: `{risk.get('gate_open_count', 0)}`.")
    lines.append("- Operator cockpit: `outputs/project_intelligence_graph/current/operator_cockpit.md`.")
    lines.append("")
    return lines


def append_m1_full_check_lines(lines: list[str], report: dict[str, Any]) -> None:
    final_state = report.get("m7_final_state", {})
    risk = report.get("m7_cross_rail_risk_board", {})
    room16 = report.get("m7_room16_truth_pipeline", {})
    quellwert = report.get("m7_quellwert_data_kernel", {})
    lines.extend(["", "## M7 Existing Rails Perfection", ""])
    lines.append(f"- Final state: `{final_state.get('status', 'UNKNOWN')}` ({final_state.get('final_truth', FINAL_TRUTH)})")
    lines.append(f"- Risk rows: `{risk.get('risk_row_count', 0)}`; gate-open count `{risk.get('gate_open_count', 0)}`")
    lines.append(f"- Room16 public-ready count: `{room16.get('public_ready_count', 0)}`; rerun executed `False`")
    lines.append(f"- Quellwert data maturity: `{quellwert.get('utility_maturity_status', 'UNKNOWN')}`")
    lines.append("- Runtime actions: `none`; Room16 rerun, LIONCOM bridge, real data, analytics, public/payment/auth remain gated.")
