#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path


DREAMFACTORY_ROOT = Path("/Users/BjornRosinger/Documents/DreamFactory")
DOCUMENTS_ROOT = Path("/Users/BjornRosinger/Documents")
LEGACY_ROOTS = [
    "/Users/BjornRosinger/Documents/New project",
    "/Users/BjornRosinger/Documents/New project 2",
    "Documents/New project",
    "New project 2",
]
OUTPUT_DIR = DREAMFACTORY_ROOT / "Project-Intelligence-Graph" / "outputs" / "project_intelligence_graph"


def run_rg() -> list[dict[str, object]]:
    cmd = [
        "rg",
        "-n",
        "--hidden",
        "--glob",
        "!**/node_modules/**",
        "--glob",
        "!**/dist/**",
        "--glob",
        "!**/build/**",
        "--glob",
        "!**/*.png",
        "--glob",
        "!**/*.jpg",
        "--glob",
        "!**/*.pdf",
        "|".join(LEGACY_ROOTS),
        str(DREAMFACTORY_ROOT),
    ]
    proc = subprocess.run(cmd, text=True, capture_output=True, check=False)
    hits: list[dict[str, object]] = []
    for line in proc.stdout.splitlines():
        try:
            path, line_no, text = line.split(":", 2)
        except ValueError:
            continue
        hits.append({"path": path, "line": int(line_no), "text": text[:500]})
    return hits


def classify(path: str, text: str) -> str:
    rel = os.path.relpath(path, DREAMFACTORY_ROOT)
    if rel == "Project-Intelligence-Graph/scripts/project_intelligence_graph/system_wide_stale_path_audit.py":
        return "allowed_legacy_detector"
    if rel == "Project-Intelligence-Graph/company-dossier-lab/room16-app/server.mjs" and (
        "LEGACY_PROJECT_ROOTS" in text
        or "Documents/New project/company-dossier-lab" in text
    ):
        return "allowed_legacy_rebase"
    if "/Room16/Reports/" in path:
        return "historical_report_provenance"
    if any(part in rel for part in ("/outputs/", "/reports/", "/.runtime/", "/.next/", "/archive/")):
        return "historical_or_generated_provenance"
    if rel.startswith("Project-Intelligence-Graph/company-dossier-lab-") and (
        "/ops/ai-handoff/" in rel
        or "/README.md" in rel
        or "/docs/" in rel
        or rel.endswith("/BCR_REPORT_LAB.md")
    ):
        return "historical_worktree_provenance"
    if rel.startswith("Room16/research-agent-ops/") and (
        "documents_root_hygiene" in rel
        or "WORKSPACE_PLACEMENT.md" in rel
        or rel.endswith("README.md")
    ):
        return "allowed_legacy_detector"
    if rel.endswith("AGENTS.md") and "New project" in text:
        return "allowed_legacy_rule_text"
    if rel.endswith("test_services_render_cli.py") and "assertNotIn" in text:
        return "allowed_regression_test"
    if rel.startswith("codex_tools/") and "LEGACY_SRC_ROOT" in text:
        return "allowed_legacy_detector"
    return "active_blocker"


def worktree_legacy_hits() -> list[str]:
    repo = DREAMFACTORY_ROOT / "Project-Intelligence-Graph" / "company-dossier-lab"
    proc = subprocess.run(
        ["git", "worktree", "list", "--porcelain"],
        cwd=repo,
        text=True,
        capture_output=True,
        check=False,
    )
    return [line for line in proc.stdout.splitlines() if "New project" in line]


def build_report() -> dict[str, object]:
    root_findings = []
    for root in ("New project", "New project 2"):
        path = DOCUMENTS_ROOT / root
        if path.exists():
            root_findings.append(str(path))

    classified = []
    counts: dict[str, int] = {}
    for hit in run_rg():
        category = classify(str(hit["path"]), str(hit["text"]))
        hit["category"] = category
        classified.append(hit)
        counts[category] = counts.get(category, 0) + 1

    active_blockers = [hit for hit in classified if hit["category"] == "active_blocker"]
    worktree_hits = worktree_legacy_hits()
    status = "PASS" if not root_findings and not active_blockers and not worktree_hits else "FAIL"

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "status": status,
        "dreamfactory_root": str(DREAMFACTORY_ROOT),
        "legacy_roots_present": root_findings,
        "worktree_legacy_hits": worktree_hits,
        "hit_count": len(classified),
        "counts": counts,
        "active_blockers": active_blockers[:100],
        "samples": {
            category: [hit for hit in classified if hit["category"] == category][:10]
            for category in sorted(counts)
        },
        "rule": (
            "Active runtime, verifier, portfolio, git-worktree and venv entrypoints must not point "
            "to retired New project roots. Historical reports may keep provenance only when they "
            "are not consumed as current truth."
        ),
    }


def write_markdown(report: dict[str, object], path: Path) -> None:
    lines = [
        "# System-wide Stale Path Audit",
        "",
        f"- Status: `{report['status']}`",
        f"- Hits: `{report['hit_count']}`",
        f"- Legacy roots present: `{len(report['legacy_roots_present'])}`",
        f"- Worktree legacy hits: `{len(report['worktree_legacy_hits'])}`",
        "",
        "## Counts",
        "",
    ]
    counts = report["counts"]
    if isinstance(counts, dict):
        for key in sorted(counts):
            lines.append(f"- `{key}`: `{counts[key]}`")
    lines.extend(["", "## Active Blockers", ""])
    blockers = report["active_blockers"]
    if blockers:
        for hit in blockers:
            lines.append(f"- `{hit['path']}:{hit['line']}` {hit['text']}")
    else:
        lines.append("- None.")
    lines.extend(["", "## Rule", "", str(report["rule"]), ""])
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    report = build_report()
    json_path = OUTPUT_DIR / "system_wide_stale_path_audit.json"
    md_path = OUTPUT_DIR / "system_wide_stale_path_audit.md"
    json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    write_markdown(report, md_path)
    print(json.dumps({"status": report["status"], "json": str(json_path), "md": str(md_path)}, indent=2))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
