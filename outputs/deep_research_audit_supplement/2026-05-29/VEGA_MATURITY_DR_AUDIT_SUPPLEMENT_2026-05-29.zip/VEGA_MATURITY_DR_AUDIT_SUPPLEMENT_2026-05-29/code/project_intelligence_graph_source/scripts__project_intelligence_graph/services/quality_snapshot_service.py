"""Quality snapshot summarization helpers."""

from __future__ import annotations

from typing import Mapping


def summarize_quality_snapshot(snapshot: Mapping[str, object]) -> dict[str, object]:
    return {
        "full_check_status": snapshot.get("full_check_status", "UNKNOWN"),
        "implementation_status": snapshot.get("implementation_status", "UNKNOWN"),
        "coverage_status": snapshot.get("coverage_status", "UNKNOWN"),
        "warning_count": int(snapshot.get("warning_count", 0) or 0),
        "selftest_failed_count": int(snapshot.get("selftest_failed_count", 0) or 0),
    }
