"""Shared helpers for the B46-B55 maturity-kernel-v5 layer."""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import re
import zipfile
from pathlib import Path
from typing import Any

from archive_reference_helpers import zip_stats
from evidence_io import MISSING, MissingEvidenceError, load_json_optional, load_json_required
from report_markdown import render_report_markdown
from status_model import Verdict, aggregate_statuses, is_passish_status


WORKSPACE = Path(__file__).resolve().parents[2]
OUTPUT_DIR = WORKSPACE / "outputs/project_intelligence_graph"
REVIEW_BUNDLES_DIR = WORKSPACE / "outputs/review_bundles"
PIG_PATH = WORKSPACE / "scripts/project_intelligence_graph/pig.py"
V4_HELPER_PATH = WORKSPACE / "scripts/project_intelligence_graph/maturity_kernel_v4_helpers.py"

# Reset after the 2026-05-28 Capability Rails helper extraction. The guard
# measures future pig.py growth from the verified post-extraction baseline.
PIG_PY_B46_BASELINE_BYTES = 1_221_778
V4_HELPER_B46_BASELINE_BYTES = 53_248
MAX_NEW_HELPER_BYTES = 35_000

HARD_GATES = [
    "push",
    "delete",
    "publish",
    "deploy",
    "production",
    "public",
    "payment",
    "auth/credentials",
    "external communication",
    "real person/client data",
    "financial-advice publishing",
    "Room16 rerun",
    "Jarvis/OpenJarvis mutation",
    "irreversible actions",
]

PASSISH = {"PASS", "PASS_WITH_WARNINGS", "WARN_WITH_LOCAL_ONLY"}


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def timestamp() -> str:
    return dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def load_json(path: Path, default: Any | None = None) -> Any:
    if not path.exists():
        return {} if default is None else default
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def write_report(path: Path, title: str, payload: dict[str, Any]) -> None:
    write_json(path, payload)
    path.with_suffix(".md").write_text(render_report_markdown(title, payload), encoding="utf-8")


def safe_rel(path: Path) -> str:
    try:
        return str(path.relative_to(WORKSPACE))
    except ValueError:
        return str(path)


def abs_path(relative_or_absolute: str) -> Path:
    path = Path(relative_or_absolute)
    return path if path.is_absolute() else WORKSPACE / path


def sha256_for_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def latest_archive(pattern: str) -> Path | None:
    candidates = sorted(REVIEW_BUNDLES_DIR.glob(pattern))
    return candidates[-1] if candidates else None


def path_size(path: Path) -> int:
    return path.stat().st_size if path.exists() else 0


def check_rows(rows: list[dict[str, Any]]) -> tuple[str, int]:
    verdict = aggregate_statuses(row.get("status") for row in rows)
    fail_count = len([row for row in rows if aggregate_statuses([row.get("status")]) == Verdict.FAIL])
    return (verdict.name, fail_count)


def is_passish(status: str | None) -> bool:
    return is_passish_status(status) or str(status or "UNKNOWN") in PASSISH


def zip_text_risk_scan(archive_path: Path) -> dict[str, Any]:
    absolute_paths = 0
    localhost_count = 0
    secret_count = [REDACTED]
    scanned_member_count = 0
    if not archive_path.exists():
        return {
            "absolute_user_path_count": 0,
            "localhost_url_count": 0,
            "secret_count": 0,
            "scanned_member_count": 0,
        }
    with zipfile.ZipFile(archive_path) as archive:
        for info in archive.infolist():
            if info.is_dir() or info.file_size > 1_000_000:
                continue
            try:
                text = archive.read(info.filename).decode("utf-8")
            except UnicodeDecodeError:
                continue
            scanned_member_count += 1
            absolute_paths += len(re.findall(r"/Users/[A-Za-z0-9_. -]+", text))
            localhost_count += len(re.findall(r"https?://(?:localhost|127\.0\.0\.1|0\.0\.0\.0|\[?::1\]?):\d+", text))
            secret_count += len(
                re.findall(
                    r"(sk-[A-Za-z0-9]|ghp_[A-Za-z0-9]|BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY|api[_-]?key\s*[:=])",
                    text,
                    re.IGNORECASE,
                )
            )
    return {
        "absolute_user_path_count": absolute_paths,
        "localhost_url_count": localhost_count,
        "secret_count": secret_count,
        "scanned_member_count": scanned_member_count,
    }


def archive_measurement(path: Path | None, *, budget_bytes: int) -> dict[str, Any]:
    if path is None or not path.exists():
        return {
            "archive_exists": False,
            "archive_path": "",
            "archive_sha256": "",
            "archive_bytes": 0,
            "uncompressed_bytes": 0,
            "member_count": 0,
            "top_members": [],
            "budget_bytes": budget_bytes,
            "within_budget": False,
            **zip_text_risk_scan(Path("__missing__")),
        }
    stats = zip_stats(path)
    scan = zip_text_risk_scan(path)
    return {
        "archive_exists": True,
        "archive_path": safe_rel(path),
        "archive_sha256": stats.get("archive_sha256", ""),
        "archive_bytes": stats.get("archive_bytes", 0),
        "uncompressed_bytes": stats.get("uncompressed_bytes", 0),
        "member_count": stats.get("member_count", 0),
        "top_members": stats.get("top_members", []),
        "budget_bytes": budget_bytes,
        "within_budget": stats.get("archive_bytes", 0) <= budget_bytes,
        **scan,
    }
