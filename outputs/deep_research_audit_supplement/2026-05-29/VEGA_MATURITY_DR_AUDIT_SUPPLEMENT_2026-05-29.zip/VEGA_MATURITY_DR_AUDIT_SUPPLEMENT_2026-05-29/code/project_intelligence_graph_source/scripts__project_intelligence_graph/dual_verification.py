"""M13 dual verification profiles for portable and original workspace truth."""

from __future__ import annotations

import datetime as dt
import json
from pathlib import Path
from typing import Any

from pack_replay_mode import build_pack_replay_full_check
from redaction import scan_redaction_hits
from render.markdown import render_report_markdown
from replay_pack import build_replay_report


PORTABLE_REPORT_JSON_NAME = "m13_portable_core_verification.json"
PORTABLE_REPORT_MD_NAME = "m13_portable_core_verification.md"
DUAL_REPORT_JSON_NAME = "m13_dual_verification_report.json"
DUAL_REPORT_MD_NAME = "m13_dual_verification_report.md"
DUAL_README_NAME = "m13_dual_verification_readme.md"
SYSTEM_TRUTH_STATUS = "PASS_WITH_WARNINGS"

PORTABLE_CORE_ARTIFACTS = [
    "status_semantics.yml",
    "independent_replay_pack.json",
    "profile_manifests/generator_sources.json",
    "profiles/generator_sources/scripts/project_intelligence_graph/report_markdown.py",
    "tests/fixtures",
    "pack_replay_stubs.json",
    "pack_replay_stubs",
    "outputs/project_intelligence_graph/full_check_dependency_map.json",
]


def _utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _check(name: str, status: str, detail: str, **extra: Any) -> dict[str, Any]:
    return {"check": name, "status": status, "detail": detail, **extra}


def _status_from_checks(checks: list[dict[str, Any]]) -> str:
    if any(item.get("status") == "FAIL" for item in checks):
        return "FAIL"
    if any(item.get("status") == "ACTION_REQUIRED" for item in checks):
        return "ACTION_REQUIRED"
    return "PASS"


def _redaction_scan_dirs(pack_root: Path) -> list[Path]:
    candidates = [pack_root / "shareable_review_pack", pack_root.parent / "shareable_review_pack"]
    return [path for path in candidates if path.exists() and path.is_dir()]


def _scan_shareable_dirs(pack_root: Path) -> dict[str, Any]:
    findings: list[dict[str, Any]] = []
    scanned_files = 0
    for root in _redaction_scan_dirs(pack_root):
        for path in sorted(root.rglob("*")):
            if not path.is_file():
                continue
            try:
                text = path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            scanned_files += 1
            hits = scan_redaction_hits(text)
            slash_users = "/Users/" in text
            if hits["private_path_hits"] or hits["operator_identity_hits"] or slash_users:
                findings.append({
                    "path": str(path.relative_to(root)),
                    "shareable_root": str(root),
                    "private_path_hits": hits["private_path_hits"],
                    "operator_identity_hits": hits["operator_identity_hits"],
                    "contains_slash_users_literal": slash_users,
                })
    return {
        "status": "PASS" if not findings else "FAIL",
        "scanned_text_files": scanned_files,
        "finding_count": len(findings),
        "slash_users_literal_hit_files": sum(1 for item in findings if item["contains_slash_users_literal"]),
        "operator_identity_hit_files": sum(1 for item in findings if item["operator_identity_hits"]),
        "findings": findings,
    }


def _portable_artifact_check(pack_root: Path) -> dict[str, Any]:
    missing = [item for item in PORTABLE_CORE_ARTIFACTS if not (pack_root / item).exists()]
    return _check(
        "portable_core_artifacts_present",
        "PASS" if not missing else "ACTION_REQUIRED",
        "missing=" + json.dumps(missing, ensure_ascii=False),
        required_artifacts=PORTABLE_CORE_ARTIFACTS,
        missing=missing,
    )


def _profile_status(report: dict[str, Any]) -> str:
    return str(report.get("status", "FAIL"))


def _dual_matrix_status(profile_statuses: dict[str, str]) -> str:
    """Keep portable failures hard while preserving original-gate warnings."""

    if profile_statuses.get("B_pack_replay_mode") != "PASS" or profile_statuses.get("C_portable_core") != "PASS":
        return "FAIL"
    if profile_statuses.get("A_original_workspace_gate") != "PASS":
        return "PASS_WITH_WARNINGS"
    return "PASS"


def build_portable_core_verification(
    pack_root: Path,
    *,
    output_dir: Path | None = None,
    run_commands: bool = True,
    write: bool = True,
) -> dict[str, Any]:
    """Verify the self-contained portable profile without live workspace claims."""

    pack_root = Path(pack_root).resolve()
    output_dir = Path(output_dir).resolve() if output_dir else pack_root / "outputs" / "project_intelligence_graph"
    checks: list[dict[str, Any]] = [_portable_artifact_check(pack_root)]

    replay_report = build_replay_report(pack_root, run_commands=run_commands)
    checks.append(_check(
        "portable_replay_pack",
        _profile_status(replay_report),
        f"replay_pack status={replay_report.get('status')} fail={replay_report.get('fail_count', 0)} action_required={replay_report.get('action_required_count', 0)}",
        report=replay_report,
    ))

    pack_replay_report = build_pack_replay_full_check(
        pack_root,
        output_dir=output_dir,
        run_commands=run_commands,
        write=False,
    )
    checks.append(_check(
        "pack_replay_full_check_profile",
        _profile_status(pack_replay_report),
        f"pack_replay status={pack_replay_report.get('status')} fail={pack_replay_report.get('fail_count', 0)} action_required={pack_replay_report.get('action_required_count', 0)}",
        report=pack_replay_report,
    ))

    redaction_scan = _scan_shareable_dirs(pack_root)
    checks.append(_check(
        "shareable_review_pack_redaction",
        redaction_scan["status"],
        f"scanned={redaction_scan['scanned_text_files']} findings={redaction_scan['finding_count']}",
        report=redaction_scan,
    ))

    status = _status_from_checks(checks)
    report = {
        "schema_version": 1,
        "generated_at": _utc_now(),
        "status": status,
        "system_truth_status": SYSTEM_TRUTH_STATUS,
        "mode": "portable_core_verification",
        "pack_root": str(pack_root),
        "profile_id": "C_portable_core",
        "profile_claim": "portable_core_self_contained_tests_replay_help_and_stubbed_full_check",
        "original_workspace_full_check_claim_allowed": False,
        "regular_full_check_in_unpacked_pack": "original_workspace_only_not_claimed",
        "runtime_action_executed": False,
        "external_action_executed": False,
        "production_gate_opened": False,
        "checks": checks,
        "steps": checks,
        "fail_count": sum(1 for item in checks if item.get("status") == "FAIL"),
        "action_required_count": sum(1 for item in checks if item.get("status") == "ACTION_REQUIRED"),
        "warnings": [
            "Portable core verifies the self-contained review root and explicit stubs.",
            "Portable core does not claim live Vault, LIONCOM or runtime parity.",
            "Regular original full-check remains a separate original-workspace gate.",
        ],
    }
    if write:
        _write_json(output_dir / PORTABLE_REPORT_JSON_NAME, report)
        (output_dir / PORTABLE_REPORT_MD_NAME).write_text(render_report_markdown("M13 Portable Core Verification", report), encoding="utf-8")
    return report


def build_dual_verification_report(
    pack_root: Path,
    *,
    original_report: dict[str, Any] | None = None,
    output_dir: Path | None = None,
    run_commands: bool = True,
    write: bool = True,
) -> dict[str, Any]:
    """Combine A original, B pack replay and C portable-core truth into one matrix."""

    pack_root = Path(pack_root).resolve()
    output_dir = Path(output_dir).resolve() if output_dir else pack_root / "outputs" / "project_intelligence_graph"
    original_report = original_report or {}
    portable_report = build_portable_core_verification(
        pack_root,
        output_dir=output_dir,
        run_commands=run_commands,
        write=write,
    )
    pack_replay_report = next(
        (item.get("report", {}) for item in portable_report.get("checks", []) if item.get("check") == "pack_replay_full_check_profile"),
        {},
    )

    original_status = str(original_report.get("status", "ACTION_REQUIRED"))
    pack_status = str(pack_replay_report.get("status", "ACTION_REQUIRED"))
    portable_status = str(portable_report.get("status", "ACTION_REQUIRED"))
    profile_statuses = {
        "A_original_workspace_gate": original_status,
        "B_pack_replay_mode": pack_status,
        "C_portable_core": portable_status,
    }
    profiles = [
        {
            "profile_id": "A_original_workspace_gate",
            "status": original_status,
            "claim": "live original workspace verifier with Vault/LIONCOM/runtime-adjacent local evidence",
            "command": "python3 scripts/project_intelligence_graph/pig.py full-check --original-workspace --json",
            "portable": False,
            "shareable": False,
        },
        {
            "profile_id": "B_pack_replay_mode",
            "status": pack_status,
            "claim": "runnable pack replay plus explicit dependency stubs",
            "command": "python3 scripts/project_intelligence_graph/pig.py full-check --pack-replay --json",
            "portable": True,
            "shareable": False,
        },
        {
            "profile_id": "C_portable_core",
            "status": portable_status,
            "claim": "self-contained portable core: artifacts, replay, help, tests, pack replay and shareable redaction",
            "command": "python3 scripts/project_intelligence_graph/pig.py full-check --portable --json",
            "portable": True,
            "shareable": "shareable_review_pack_only",
        },
    ]
    checks = [_check(row["profile_id"], row["status"], row["claim"], profile=row) for row in profiles]
    status = _dual_matrix_status(profile_statuses)
    report = {
        "schema_version": 1,
        "generated_at": _utc_now(),
        "status": status,
        "system_truth_status": SYSTEM_TRUTH_STATUS,
        "mode": "m13_dual_verification",
        "pack_root": str(pack_root),
        "dual_truth": "A_original_workspace_gate plus B_pack_replay_mode plus C_portable_core",
        "strict_all_profiles_status": _status_from_checks(checks),
        "kernel_verification_status": "PASS" if status in {"PASS", "PASS_WITH_WARNINGS"} else "FAIL",
        "full_live_portability_claim": "not_claimed",
        "regular_full_check_in_unpacked_pack": "original_workspace_only_not_claimed",
        "runtime_action_executed": False,
        "external_action_executed": False,
        "production_gate_opened": False,
        "forbidden_actions_observed": [],
        "profiles": profiles,
        "checks": checks,
        "steps": checks,
        "profile_statuses": profile_statuses,
        "original_workspace_gate_status": original_status,
        "original_workspace_gate_warning": (
            "Original workspace full-check is not globally green; M13 records that as profile A truth instead of converting it into a portable claim."
            if original_status != "PASS"
            else ""
        ),
        "original_workspace_report_path": str(output_dir / "full_check_report.json"),
        "pack_replay_report_path": str(output_dir / "pack_replay_full_check_report.json"),
        "portable_core_report_path": str(output_dir / PORTABLE_REPORT_JSON_NAME),
        "fail_count": 0 if status in {"PASS", "PASS_WITH_WARNINGS"} else sum(1 for item in checks if item.get("status") == "FAIL"),
        "profile_fail_count": sum(1 for item in checks if item.get("status") == "FAIL"),
        "action_required_count": sum(1 for item in checks if item.get("status") == "ACTION_REQUIRED"),
        "warnings": [
            "M13 intentionally keeps live original workspace truth and portable pack truth separate.",
            "A/B/C all being PASS proves dual verification, not public launch, deploy, push, auth, payment or runtime activation.",
            "If A is not PASS while B/C are PASS, the M13 kernel is PASS_WITH_WARNINGS and the original workspace gate remains visible.",
            "Full live-workspace parity inside unpacked packs is not claimed until Vault/LIONCOM/runtime dependencies are intentionally ported or permanently gated.",
        ],
    }
    if write:
        _write_json(output_dir / DUAL_REPORT_JSON_NAME, report)
        (output_dir / DUAL_REPORT_MD_NAME).write_text(render_report_markdown("M13 Dual Verification", report), encoding="utf-8")
        (output_dir / DUAL_README_NAME).write_text(_dual_readme(report), encoding="utf-8")
    return report


def _dual_readme(report: dict[str, Any]) -> str:
    lines = [
        "# M13 Dual Verification Kernel",
        "",
        f"- Status: `{report.get('status', 'UNKNOWN')}`",
        f"- System truth: `{report.get('system_truth_status', 'UNKNOWN')}`",
        f"- Strict all-profiles status: `{report.get('strict_all_profiles_status', 'UNKNOWN')}`",
        "- Scope: `candidate_only`",
        "- Claim: A/B/C verification profiles are separate and machine-readable.",
        "",
        "## Profiles",
        "",
    ]
    for row in report.get("profiles", []):
        lines.append(f"- `{row.get('profile_id')}`: `{row.get('status')}` - {row.get('claim')}")
    lines.extend([
        "",
        "## Boundary",
        "",
        "`PASS` here is not a launch, push, deploy, publish, auth, payment, runtime or external-share permission.",
        "Regular live full-check inside unpacked packs remains `original_workspace_only_not_claimed` until a later scoped contract changes that.",
        "",
    ])
    return "\n".join(lines)
