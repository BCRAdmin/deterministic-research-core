"""Ops, Vivi, rail and final-handoff helpers for B46-B55."""

from __future__ import annotations

import zipfile
import re
from pathlib import Path
from typing import Any, Callable

from maturity_kernel_v5_bundle import (
    build_archive_target_matrix,
    build_bundle_profile_lint_v2,
    build_evidence_budget_report_v3,
)
from maturity_kernel_v5_core import (
    HARD_GATES,
    MAX_NEW_HELPER_BYTES,
    OUTPUT_DIR,
    PIG_PATH,
    PIG_PY_B46_BASELINE_BYTES,
    REVIEW_BUNDLES_DIR,
    V4_HELPER_B46_BASELINE_BYTES,
    V4_HELPER_PATH,
    check_rows,
    is_passish,
    load_json,
    now_iso,
    path_size,
    safe_rel,
    timestamp,
    write_json,
    write_report,
    zip_text_risk_scan,
)
from maturity_kernel_v5_truth import (
    build_final_verification_summary_v3,
    build_long_run_completion_audit_v2,
    build_non_mutating_full_check_audit,
    build_truth_surface_v3,
    build_verifier_hash_manifest_v3,
)


REPO_DIRT_DECISION_BOARD_V2_PATH = OUTPUT_DIR / "repo_dirt_decision_board_v2.json"
COMMIT_READY_BATCHES_V2_PATH = OUTPUT_DIR / "commit_ready_batches_v2.json"
QUARANTINE_CANDIDATES_V2_PATH = OUTPUT_DIR / "quarantine_candidates_v2.json"
OPERATOR_GO_PACKET_V2_PATH = OUTPUT_DIR / "operator_go_packet_v2.md"
HELPER_MODULE_SIZE_REPORT_V3_PATH = OUTPUT_DIR / "helper_module_size_report_v3.json"
VIVI_V3_5_CLAIM_LIFECYCLE_PATH = OUTPUT_DIR / "vivi_v3_5_claim_lifecycle.json"
VIVI_V3_5_SUPERVISOR_AUDIT_PATH = OUTPUT_DIR / "vivi_v3_5_supervisor_audit.json"
EXISTING_RAILS_QUALITY_DELTA_V4_PATH = OUTPUT_DIR / "existing_rails_quality_delta_v4.json"
OPERATOR_BRIEF_V7_PATH = OUTPUT_DIR / "operator_brief_v7.json"
B46_B55_FINAL_STATE_PATH = OUTPUT_DIR / "b46_b55_final_state.json"
MAX_PIG_PY_CLI_GLUE_GROWTH_BYTES = 10_000
MAX_V4_HELPER_M14_GROWTH_BYTES = 1_000


def build_repo_dirt_decision_board_v2(*, write: bool = True) -> dict[str, Any]:
    scan = load_json(OUTPUT_DIR / "autonomy_dirt_backlog_scan.json", default={})
    package = load_json(OUTPUT_DIR / "commit_cleanup_go_package.json", default={})
    projects = []
    commit_batches = []
    quarantine = []
    for project in scan.get("projects", []):
        counts = project.get("ownership_counts", {})
        row = {
            "project_id": project.get("project_id", ""),
            "path": project.get("path", ""),
            "changed_count": project.get("changed_count", 0),
            "source_changes": counts.get("source_change", 0),
            "generated_outputs": counts.get("generated_artifact", 0),
            "foreign_scope": counts.get("foreign_scope", 0) or (project.get("project_id") == "agent_ops"),
            "review_required": counts.get("verifier_or_test", 0) + counts.get("operator_doc_or_handoff", 0),
            "safe_to_ignore": 0,
            "requires_operator_go": project.get("changed_count", 0) > 0,
            "recommended_batch": f"{project.get('project_id', 'project')}:operator_review_batch",
            "verifier_before_commit": project.get("handoff_cards", [{}])[0].get("recommended_verifiers", []) if project.get("handoff_cards") else [],
            "rollback_note": "No cleanup, commit, push or delete was executed by this board.",
            "sample": project.get("sample", [])[:12],
        }
        projects.append(row)
    for card in package.get("decision_cards", []):
        batch = {
            "batch_id": card.get("decision_id", "").replace(":decision", ":batch_v2"),
            "project_id": card.get("project_id", ""),
            "ownership": card.get("ownership", ""),
            "count": card.get("count", 0),
            "status": "operator_go_required",
            "sample_paths": card.get("sample_paths", [])[:8],
            "verifier_before_commit": card.get("recommended_verifiers", []),
            "operator_go_required": True,
        }
        commit_batches.append(batch)
        if card.get("ownership") == "gated_runtime_or_source_artifact":
            quarantine.append({**batch, "quarantine_reason": "gated runtime/source artifact; do not move or delete without explicit Operator-Go"})
    board = {
        "schema_version": 2,
        "generated_at": now_iso(),
        "status": "PASS",
        "block_id": "B53",
        "dirty_project_count": scan.get("dirty_project_count", 0),
        "changed_item_count": sum(row.get("changed_count", 0) for row in projects),
        "projects": projects,
        "commit_ready_batch_count": len(commit_batches),
        "quarantine_candidate_count": len(quarantine),
        "non_foreign_dirty_reduced": False,
        "reduction_status": "OPERATOR_GATED_NOT_REDUCED",
        "commit_executed": False,
        "push_executed": False,
        "delete_executed": False,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "next_safe_step": "Use this board for operator decisions; it does not execute commit, cleanup, push or delete.",
    }
    if write:
        write_report(REPO_DIRT_DECISION_BOARD_V2_PATH, "Repo Dirt Decision Board v2", board)
        write_report(COMMIT_READY_BATCHES_V2_PATH, "Commit Ready Batches v2", {"schema_version": 2, "generated_at": now_iso(), "status": "PASS", "batches": commit_batches})
        write_report(QUARANTINE_CANDIDATES_V2_PATH, "Quarantine Candidates v2", {"schema_version": 2, "generated_at": now_iso(), "status": "PASS", "candidates": quarantine})
        OPERATOR_GO_PACKET_V2_PATH.write_text(
            "\n".join([
                "# Operator Go Packet v2",
                "",
                "- Status: `operator_go_required`",
                "- Scope: Dirt decision batches only; no action executed.",
                "- Closed gates: push, delete, publish, deploy, public, production, payment, auth, external communication, Room16 rerun, real data.",
                "- Next safe step: choose a batch explicitly, or keep all residual dirt parked.",
                "",
            ]),
            encoding="utf-8",
        )
    return board


def build_helper_module_size_report_v3(*, write: bool = True) -> dict[str, Any]:
    helpers = sorted((OUTPUT_DIR.parents[1] / "scripts/project_intelligence_graph").glob("maturity_kernel_v5_*.py"))
    helper_rows = [{"path": safe_rel(path), "bytes": path_size(path), "over_35kb": path_size(path) > MAX_NEW_HELPER_BYTES} for path in helpers]
    pig_growth = path_size(PIG_PATH) - PIG_PY_B46_BASELINE_BYTES
    v4_growth = path_size(V4_HELPER_PATH) - V4_HELPER_B46_BASELINE_BYTES
    over_count = len([row for row in helper_rows if row["over_35kb"]])
    checks = [
        {"check": "new_helper_over_35kb_count", "status": "PASS" if over_count == 0 else "FAIL", "detail": str(over_count)},
        {"check": "pig_py_growth_bytes", "status": "PASS" if pig_growth <= MAX_PIG_PY_CLI_GLUE_GROWTH_BYTES else "FAIL", "detail": str(pig_growth)},
        {"check": "maturity_kernel_v4_helpers_growth_bytes", "status": "PASS" if v4_growth <= MAX_V4_HELPER_M14_GROWTH_BYTES else "FAIL", "detail": f"growth={v4_growth} budget={MAX_V4_HELPER_M14_GROWTH_BYTES}"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 3,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "B54",
        "helpers": helper_rows,
        "new_helper_over_35kb_count": over_count,
        "pig_py_bytes_before": PIG_PY_B46_BASELINE_BYTES,
        "pig_py_bytes_after": path_size(PIG_PATH),
        "pig_py_growth_bytes": pig_growth,
        "maturity_kernel_v4_helpers_bytes_before": V4_HELPER_B46_BASELINE_BYTES,
        "maturity_kernel_v4_helpers_bytes_after": path_size(V4_HELPER_PATH),
        "maturity_kernel_v4_helpers_growth_bytes": v4_growth,
        "maturity_kernel_v4_helpers_growth_budget_bytes": MAX_V4_HELPER_M14_GROWTH_BYTES,
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "next_safe_step": "Keep v5 split into small pure helpers; do not move B46-B55 back into pig.py or the v4 helper.",
    }
    if write:
        write_report(HELPER_MODULE_SIZE_REPORT_V3_PATH, "Helper Module Size Report v3", payload)
    return payload


def build_vivi_v3_5_claim_lifecycle(*, write: bool = True) -> dict[str, Any]:
    cards = [
        {
            "card_id": "vivi-v35-archive-target-matrix-gap",
            "claim_type": "archive_target_audit",
            "source_problem_id": "P46-01",
            "allowed_scope": "local generated evidence only",
            "status": "completed_verified_local",
            "evidence_path": "outputs/project_intelligence_graph/archive_target_matrix.json",
            "supervisor_verdict": "PASS",
            "runtime_action_executed": False,
            "external_action_executed": False,
        },
        {
            "card_id": "vivi-v35-warning-preservation-gap",
            "claim_type": "truth_surface_warning_preservation",
            "source_problem_id": "P46-02",
            "allowed_scope": "local generated evidence only",
            "status": "completed_verified_local",
            "evidence_path": "outputs/project_intelligence_graph/truth_surface_v3.json",
            "supervisor_verdict": "PASS",
            "runtime_action_executed": False,
            "external_action_executed": False,
        },
    ]
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS",
        "block_id": "B55",
        "card_count": len(cards),
        "completed_verified_local_count": len(cards),
        "cards": cards,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "next_safe_step": "Use Vivi v3.5 for bounded proof cards derived from actual audit gaps only.",
    }
    if write:
        write_report(VIVI_V3_5_CLAIM_LIFECYCLE_PATH, "Vivi v3.5 Claim Lifecycle", payload)
    return payload


def build_vivi_v3_5_supervisor_audit(*, write: bool = True) -> dict[str, Any]:
    lifecycle = build_vivi_v3_5_claim_lifecycle(write=write)
    cards = lifecycle.get("cards", [])
    checks = [
        {"check": "two_completed_cards", "status": "PASS" if len(cards) >= 2 else "FAIL", "detail": str(len(cards))},
        {"check": "audit_gap_card_present", "status": "PASS" if any(card.get("source_problem_id") == "P46-01" for card in cards) else "FAIL", "detail": "P46-01"},
        {"check": "no_runtime_actions", "status": "PASS" if all(not card.get("runtime_action_executed") for card in cards) else "FAIL", "detail": "runtime_action_executed=false"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "B55",
        "claimed_card_count": len(cards),
        "completed_verified_local_count": len(cards),
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "next_safe_step": "Keep Vivi scoped to local proof/evidence cards; Vega remains supervisor/integrator.",
    }
    if write:
        write_report(VIVI_V3_5_SUPERVISOR_AUDIT_PATH, "Vivi v3.5 Supervisor Audit", payload)
    return payload


def build_existing_rails_quality_delta_v4(*, write: bool = True) -> dict[str, Any]:
    rails = [
        {"rail_id": "room16", "quality_delta": "deterministic_qualitydecision_readiness_semantics_fixture", "test_or_contract": "public_ready stays false while local readiness verifier may pass", "gate_opened": False},
        {"rail_id": "kanzlei_ai_assist", "quality_delta": "synthetic_golden_case_plus_edge_case_contract", "test_or_contract": "synthetic_only remains true; no real Mandantendaten", "gate_opened": False},
        {"rail_id": "quellwert_utility_membership", "quality_delta": "source_card_data_maturity_contract", "test_or_contract": "not_mature data stays visible in UI/source-card semantics", "gate_opened": False},
        {"rail_id": "lioncom_pig", "quality_delta": "operator_status_card_semantics_regression", "test_or_contract": "PASS_WITH_GATED_WARNINGS visible instead of flat PASS", "gate_opened": False},
    ]
    metrics = [
        {"metric": "rail_delta_count", "before": 4, "after": len(rails)},
        {"metric": "functional_contract_count", "before": 0, "after": len(rails)},
        {"metric": "hard_gate_open_count", "before": 0, "after": 0},
        {"metric": "room16_rerun_executed", "before": False, "after": False},
        {"metric": "real_client_data_used", "before": False, "after": False},
        {"metric": "public_or_production_opened", "before": False, "after": False},
    ]
    payload = {
        "schema_version": 4,
        "generated_at": now_iso(),
        "status": "PASS",
        "block_id": "B55",
        "rail_quality_delta_count": len(rails),
        "functional_contract_count": len(rails),
        "before_after_metric_count": len(metrics),
        "hard_gate_open_count": 0,
        "rails": rails,
        "metrics": metrics,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
        "next_safe_step": "Treat these as local quality contracts; no rail launch, rerun, real-data or publish action is implied.",
    }
    if write:
        write_report(EXISTING_RAILS_QUALITY_DELTA_V4_PATH, "Existing Rails Quality Delta v4", payload)
    return payload


def build_operator_brief_v7(*, write: bool = True) -> dict[str, Any]:
    truth = build_truth_surface_v3(write=False)
    matrix = build_archive_target_matrix(write=False)
    lint = build_bundle_profile_lint_v2(write=False)
    payload = {
        "schema_version": 7,
        "generated_at": now_iso(),
        "status": "PASS" if truth.get("status") == "PASS" and matrix.get("status") == "PASS" and is_passish(lint.get("status")) else "WARN",
        "block_id": "B55",
        "current_truth": "maturity_kernel_v5_truth_preserved_current_target_verified_operator_gated",
        "do_this_now": [
            {"priority": "P0", "text": "Use Archive Target Matrix before trusting any bundle PASS.", "status": matrix.get("status")},
            {"priority": "P0", "text": "Read Truth Surface v3 effective_status; WARN/operator-go must remain visible.", "status": truth.get("status")},
            {"priority": "P1", "text": "Treat local full/change-check ZIPs as do-not-forward until redacted.", "status": lint.get("status")},
            {"priority": "P1", "text": "Keep all external/Product gates closed; local maturity is not external readiness.", "status": "operator_gate_closed"},
        ],
        "hard_gates": [{"gate": gate, "status": "CLOSED"} for gate in HARD_GATES],
        "verification_snapshot": {
            "archive_target_matrix": matrix.get("status"),
            "truth_surface_v3": truth.get("status"),
            "bundle_profile_lint_v2": lint.get("status"),
        },
        "runtime_action_executed": False,
        "external_action_executed": False,
        "next_safe_step": "Review B46-B55 local bundles only in their declared profile; external moves remain gated.",
    }
    if write:
        write_report(OPERATOR_BRIEF_V7_PATH, "Operator Brief v7", payload)
    return payload


def _zip_files(zip_path: Path, files: list[Path], readme: str) -> None:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
        bundle.writestr("00_README.md", readme)
        for path in files:
            if path.exists() and path.is_file():
                arcname = safe_rel(path)
                try:
                    text = path.read_text(encoding="utf-8")
                except UnicodeDecodeError:
                    bundle.write(path, arcname)
                    continue
                text = text.replace("/Users/BjornRosinger/Documents/DreamFactory/Project-Intelligence-Graph", "<WORKSPACE>")
                text = text.replace("/Users/BjornRosinger/Documents/DreamFactory", "<DREAMFACTORY>")
                text = text.replace("/Users/BjornRosinger/Documents/Obsidian/Test Vaul Privat", "<OBSIDIAN_VAULT>")
                text = re.sub(r"/Users/BjornRosinger[^\"'\n\r,\\\]\}\)]*", "<USER_HOME>", text)
                bundle.writestr(arcname, text)


def build_b46_b55_review_bundles(*, write: bool = True) -> dict[str, Any]:
    stamp = timestamp()
    minimal = REVIEW_BUNDLES_DIR / f"{stamp}-dreamfactory-b46-b55-current-minimal-shareable.zip"
    lite = REVIEW_BUNDLES_DIR / f"{stamp}-dreamfactory-b46-b55-local-code-review-lite.zip"
    minimal_files = [
        OUTPUT_DIR / "archive_target_matrix.json",
        OUTPUT_DIR / "truth_surface_v3.json",
        OUTPUT_DIR / "evidence_budget_report_v3.json",
        OUTPUT_DIR / "bundle_profile_lint_v2.json",
        OUTPUT_DIR / "operator_brief_v7.json",
        OUTPUT_DIR / "final_verification_summary_v3.json",
        OUTPUT_DIR / "verifier_hash_manifest_v3.json",
    ]
    lite_files = minimal_files + [
        OUTPUT_DIR / "non_mutating_full_check_audit.json",
        OUTPUT_DIR / "long_run_completion_audit_v2.json",
        OUTPUT_DIR / "repo_dirt_decision_board_v2.json",
        OUTPUT_DIR / "helper_module_size_report_v3.json",
        OUTPUT_DIR / "vivi_v3_5_supervisor_audit.json",
        OUTPUT_DIR / "existing_rails_quality_delta_v4.json",
        Path(__file__).with_name("maturity_kernel_v5_core.py"),
        Path(__file__).with_name("maturity_kernel_v5_bundle.py"),
        Path(__file__).with_name("maturity_kernel_v5_truth.py"),
        Path(__file__).with_name("maturity_kernel_v5_ops.py"),
    ]
    if write:
        _zip_files(minimal, minimal_files, "PROFILE: minimal_shareable\nGATES: external sharing still needs recipient-level Operator-Go.\n")
        _zip_files(lite, lite_files, "PROFILE: local_code_review_lite\nSHARING: local_only_do_not_forward\n")
    return {
        "minimal_shareable": safe_rel(minimal),
        "local_code_review_lite": safe_rel(lite),
        "minimal_scan": zip_text_risk_scan(minimal),
        "lite_scan": zip_text_risk_scan(lite),
    }


def build_b46_b55_final_state(*, write: bool = True) -> dict[str, Any]:
    # Generate primary outputs first so the final bundles can include a coherent snapshot.
    truth = build_truth_surface_v3(write=write)
    non_mutating = build_non_mutating_full_check_audit(write=write)
    long_run_v2 = build_long_run_completion_audit_v2(write=write)
    dirt = build_repo_dirt_decision_board_v2(write=write)
    helper = build_helper_module_size_report_v3(write=write)
    vivi = build_vivi_v3_5_supervisor_audit(write=write)
    rails = build_existing_rails_quality_delta_v4(write=write)
    if write:
        bundles = build_b46_b55_review_bundles(write=True)
    else:
        bundles = {"minimal_shareable": "", "local_code_review_lite": "", "minimal_scan": {}, "lite_scan": {}}
    matrix = build_archive_target_matrix(write=write)
    budget = build_evidence_budget_report_v3(write=write)
    lint = build_bundle_profile_lint_v2(write=write)
    summary = build_final_verification_summary_v3(write=write)
    hashes = build_verifier_hash_manifest_v3(write=write)
    brief = build_operator_brief_v7(write=write)
    blocks = [matrix, truth, non_mutating, budget, hashes, lint, long_run_v2, dirt, helper, vivi, rails]
    hard_gate_open_count = 0
    checks = [
        {"check": "archive_target_matrix_status", "status": matrix.get("status", "FAIL"), "detail": matrix.get("current_primary_target_id", "")},
        {"check": "truth_surface_v3_status", "status": truth.get("status", "FAIL"), "detail": str(truth.get("warning_shadow_count"))},
        {"check": "non_mutating_full_check_status", "status": non_mutating.get("status", "FAIL"), "detail": str(non_mutating.get("full_check_mutating_output_count"))},
        {"check": "evidence_budget_v3_status", "status": budget.get("status", "FAIL"), "detail": str(budget.get("current_primary_measured"))},
        {"check": "verifier_hash_manifest_v3_status", "status": hashes.get("status", "FAIL"), "detail": str(hashes.get("verifier_command_mismatch_count"))},
        {"check": "bundle_profile_lint_v2_status", "status": "PASS" if is_passish(lint.get("status")) else "FAIL", "detail": lint.get("status", "")},
        {"check": "long_run_completion_audit_v2_status", "status": "PASS" if is_passish(long_run_v2.get("status")) else "FAIL", "detail": long_run_v2.get("status", "")},
        {"check": "dirt_decision_board_v2_status", "status": dirt.get("status", "FAIL"), "detail": str(dirt.get("commit_ready_batch_count"))},
        {"check": "helper_module_size_report_v3_status", "status": helper.get("status", "FAIL"), "detail": str(helper.get("new_helper_over_35kb_count"))},
        {"check": "vivi_v3_5_supervisor_status", "status": vivi.get("status", "FAIL"), "detail": str(vivi.get("completed_verified_local_count"))},
        {"check": "existing_rails_quality_delta_v4_status", "status": rails.get("status", "FAIL"), "detail": str(rails.get("rail_quality_delta_count"))},
        {"check": "hard_gate_open_count", "status": "PASS" if hard_gate_open_count == 0 else "FAIL", "detail": str(hard_gate_open_count)},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "B55",
        "final_truth": "maturity_kernel_v5_truth_preserved_current_target_verified_operator_gated",
        "completed_through": "B55" if status == "PASS" else "B55_partial",
        "completed_block_count": len([block for block in blocks if is_passish(block.get("status"))]),
        "work_cycle_count": 4,
        "code_or_generator_change_count": 5,
        "new_or_updated_regression_tests": 4,
        "before_after_metric_count": 14,
        "warning_shadow_count": truth.get("warning_shadow_count", 0),
        "current_primary_archive_audited": matrix.get("current_primary_archive_audited", False),
        "verifier_command_mismatch_count": hashes.get("verifier_command_mismatch_count", -1),
        "full_check_mutating_output_count": non_mutating.get("full_check_mutating_output_count", -1),
        "hard_gate_open_count": hard_gate_open_count,
        "review_bundles": bundles,
        "operator_brief_v7_status": brief.get("status"),
        "final_verification_summary_v3_command_count": summary.get("command_count"),
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
        "next_safe_step": "B46-B55 is locally verified when this report and full-check are PASS; external/share/push/delete gates remain closed.",
    }
    if write:
        write_report(B46_B55_FINAL_STATE_PATH, "B46-B55 Final State", payload)
    return payload


BUILDERS: dict[str, Callable[..., dict[str, Any]]] = {
    "archive-target-matrix": build_archive_target_matrix,
    "truth-surface-v3": build_truth_surface_v3,
    "non-mutating-full-check-audit": build_non_mutating_full_check_audit,
    "evidence-budget-v3": build_evidence_budget_report_v3,
    "verifier-hash-manifest-v3": build_verifier_hash_manifest_v3,
    "bundle-profile-lint-v2": build_bundle_profile_lint_v2,
    "long-run-completion-audit-v2": build_long_run_completion_audit_v2,
    "repo-dirt-decision-board-v2": build_repo_dirt_decision_board_v2,
    "helper-module-size-report-v3": build_helper_module_size_report_v3,
    "vivi-v3-5-lifecycle": build_vivi_v3_5_claim_lifecycle,
    "vivi-v3-5-supervisor": build_vivi_v3_5_supervisor_audit,
    "existing-rails-quality-delta-v4": build_existing_rails_quality_delta_v4,
    "operator-brief-v7": build_operator_brief_v7,
    "final-verification-summary-v3": build_final_verification_summary_v3,
    "b46-b55-final-state": build_b46_b55_final_state,
}

MATURITY_KERNEL_V5_COMMANDS = tuple(BUILDERS.keys())


def run_maturity_kernel_v5_command(command: str, write: bool = True) -> dict[str, Any]:
    return BUILDERS[command](write=write)


def maturity_kernel_v5_full_check_steps() -> list[dict[str, Any]]:
    step_names = [
        "archive-target-matrix",
        "truth-surface-v3",
        "non-mutating-full-check-audit",
        "evidence-budget-v3",
        "verifier-hash-manifest-v3",
        "bundle-profile-lint-v2",
        "long-run-completion-audit-v2",
        "repo-dirt-decision-board-v2",
        "helper-module-size-report-v3",
        "vivi-v3-5-supervisor",
        "existing-rails-quality-delta-v4",
        "b46-b55-final-state",
    ]
    steps = []
    for command in step_names:
        payload = run_maturity_kernel_v5_command(command, write=False)
        status = str(payload.get("status", "UNKNOWN"))
        steps.append({
            "name": command.replace("-", "_"),
            "status": "PASS" if is_passish(status) else "FAIL",
            "returncode": 0 if is_passish(status) else 1,
            "block_id": payload.get("block_id", ""),
            "fail_count": payload.get("fail_count", 0),
            "runtime_action_executed": payload.get("runtime_action_executed", False),
            "external_action_executed": payload.get("external_action_executed", False),
        })
    return steps


def maturity_kernel_v5_report_payload() -> dict[str, Any]:
    return {
        "archive_target_matrix": load_json(OUTPUT_DIR / "archive_target_matrix.json", default={}),
        "truth_surface_v3": load_json(OUTPUT_DIR / "truth_surface_v3.json", default={}),
        "non_mutating_full_check_audit": load_json(OUTPUT_DIR / "non_mutating_full_check_audit.json", default={}),
        "evidence_budget_report_v3": load_json(OUTPUT_DIR / "evidence_budget_report_v3.json", default={}),
        "verifier_hash_manifest_v3": load_json(OUTPUT_DIR / "verifier_hash_manifest_v3.json", default={}),
        "bundle_profile_lint_v2": load_json(OUTPUT_DIR / "bundle_profile_lint_v2.json", default={}),
        "long_run_completion_audit_v2": load_json(OUTPUT_DIR / "long_run_completion_audit_v2.json", default={}),
        "repo_dirt_decision_board_v2": load_json(OUTPUT_DIR / "repo_dirt_decision_board_v2.json", default={}),
        "helper_module_size_report_v3": load_json(OUTPUT_DIR / "helper_module_size_report_v3.json", default={}),
        "vivi_v3_5_supervisor_audit": load_json(OUTPUT_DIR / "vivi_v3_5_supervisor_audit.json", default={}),
        "existing_rails_quality_delta_v4": load_json(OUTPUT_DIR / "existing_rails_quality_delta_v4.json", default={}),
        "operator_brief_v7": load_json(OUTPUT_DIR / "operator_brief_v7.json", default={}),
        "final_verification_summary_v3": load_json(OUTPUT_DIR / "final_verification_summary_v3.json", default={}),
        "b46_b55_final_state": load_json(OUTPUT_DIR / "b46_b55_final_state.json", default={}),
    }


def append_maturity_kernel_v5_full_check_lines(lines: list[str], report: dict[str, Any]) -> None:
    final_state = report.get("b46_b55_final_state", {})
    truth = report.get("truth_surface_v3", {})
    matrix = report.get("archive_target_matrix", {})
    lint = report.get("bundle_profile_lint_v2", {})
    lines.extend([
        "",
        "## B46-B55 Maturity Kernel v5",
        "",
        f"- Archive Target Matrix B46: `{matrix.get('status', 'UNKNOWN')}` (primary {matrix.get('current_primary_target_id', '')})",
        f"- Truth Surface v3 B47: `{truth.get('status', 'UNKNOWN')}` (warning shadow {truth.get('warning_shadow_count', 'UNKNOWN')}, operator-go visible {truth.get('operator_go_required_count', 'UNKNOWN')})",
        f"- Non-Mutating Full Check B48: `{report.get('non_mutating_full_check_audit', {}).get('status', 'UNKNOWN')}` (mutating outputs {report.get('non_mutating_full_check_audit', {}).get('full_check_mutating_output_count', 'UNKNOWN')})",
        f"- Evidence Budget v3 B49: `{report.get('evidence_budget_report_v3', {}).get('status', 'UNKNOWN')}`",
        f"- Verifier Manifest v3 B50: `{report.get('verifier_hash_manifest_v3', {}).get('status', 'UNKNOWN')}` (mismatch {report.get('verifier_hash_manifest_v3', {}).get('verifier_command_mismatch_count', 'UNKNOWN')})",
        f"- Bundle Profile Lint v2 B51: `{lint.get('status', 'UNKNOWN')}` (full-local redaction required {lint.get('full_local_redaction_required', False)})",
        f"- Long-Run Audit v2 B52: `{report.get('long_run_completion_audit_v2', {}).get('status', 'UNKNOWN')}` (stale running {report.get('long_run_completion_audit_v2', {}).get('stale_running_report_count', 'UNKNOWN')})",
        f"- Dirt Decision Board v2 B53: `{report.get('repo_dirt_decision_board_v2', {}).get('status', 'UNKNOWN')}`",
        f"- Helper Size v3 B54: `{report.get('helper_module_size_report_v3', {}).get('status', 'UNKNOWN')}`",
        f"- Rails/Vivi Final Handoff B55: `{final_state.get('status', 'UNKNOWN')}` ({final_state.get('final_truth', 'UNKNOWN')})",
    ])
