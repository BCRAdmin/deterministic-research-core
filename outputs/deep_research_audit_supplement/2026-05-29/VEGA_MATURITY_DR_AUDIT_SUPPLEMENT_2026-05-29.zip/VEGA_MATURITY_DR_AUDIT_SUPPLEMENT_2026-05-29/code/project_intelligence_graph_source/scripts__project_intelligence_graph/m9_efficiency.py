"""M9 Efficiency and de-monolith kernel for DreamFactory/PIG."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Callable

import m8_knowledge as m8
from maturity_kernel_v5_core import (
    OUTPUT_DIR,
    WORKSPACE,
    MissingEvidenceError,
    check_rows,
    is_passish,
    load_json,
    load_json_required,
    now_iso,
    safe_rel,
    write_json,
)


CURRENT_DIR = OUTPUT_DIR / "current"

FINAL_TRUTH = "m9_efficiency_de_monolith_budgeted_operator_gated"
ROADMAP_TRUTH = m8.ROADMAP_TRUTH
PREVIOUS_TRUTH = m8.FINAL_TRUTH
PIG_PY_GROWTH_LIMIT_BYTES = 10_000

RECOVERABLE_FULL_CHECK_SELF_REFERENCE_STEPS = set(getattr(m8, "RECOVERABLE_FULL_CHECK_SELF_REFERENCE_STEPS", set())) | set(
    "m9_module_boundary_map m9_helper_extraction_wave_plan m9_artifact_retention_policy "
    "m9_performance_budget m9_change_surface_limits m9_read_only_audit "
    "m9_regression_suite m9_final_verification".split()
)

SYSTEM_TRUTH_PATH = CURRENT_DIR / "system_truth.json"
OPERATOR_COCKPIT_PATH = CURRENT_DIR / "operator_cockpit.md"
OPERATOR_DECISION_QUEUE_PATH = CURRENT_DIR / "operator_decision_queue.json"
NEXT_DECISION_BOARD_PATH = CURRENT_DIR / "next_operator_decision_board.json"
CURRENT_SURFACE_MANIFEST_PATH = CURRENT_DIR / "current_surface_manifest.json"
CURRENT_TRUTH_AUDIT_PATH = CURRENT_DIR / "current_truth_audit.json"
DOMAIN_SUMMARY_PATH = CURRENT_DIR / "domain_summary.json"
VERIFICATION_SUMMARY_PATH = CURRENT_DIR / "verification_summary.json"
WRITE_CONTRACT_PATH = CURRENT_DIR / "write_contract.json"
GRAND_ROADMAP_PATH = CURRENT_DIR / "grand_roadmap_m3r_to_m12.json"
OPERATOR_BRIEF_PATH = OUTPUT_DIR / "operator_brief.json"
OPERATOR_BRIEF_MD_PATH = OUTPUT_DIR / "operator_brief.md"

CODE_PRESSURE_PATH = OUTPUT_DIR / "code_pressure_report.json"
DEDUP_REPORT_PATH = OUTPUT_DIR / "generated_evidence_dedup_report.json"
HELPER_SIZE_PATH = OUTPUT_DIR / "helper_module_size_report_v3.json"
FULL_CHECK_PATH = OUTPUT_DIR / "full_check_report.json"

M9_MODULE_BOUNDARY_PATH = CURRENT_DIR / "m9_module_boundary_map.json"
M9_HELPER_WAVES_PATH = CURRENT_DIR / "m9_helper_extraction_wave_plan.json"
M9_RETENTION_POLICY_PATH = CURRENT_DIR / "m9_artifact_retention_policy.json"
M9_PERFORMANCE_BUDGET_PATH = CURRENT_DIR / "m9_performance_budget.json"
M9_CHANGE_LIMITS_PATH = CURRENT_DIR / "m9_change_surface_limits.json"
M9_CURRENT_SURFACE_PATH = CURRENT_DIR / "m9_current_surface.json"
M9_READ_ONLY_AUDIT_PATH = CURRENT_DIR / "m9_read_only_audit.json"
M9_REGRESSION_SUITE_PATH = CURRENT_DIR / "m9_regression_suite.json"
M9_FINAL_VERIFICATION_PATH = CURRENT_DIR / "m9_final_verification.json"
M9_FINAL_STATE_PATH = CURRENT_DIR / "m9_final_state.json"
M9_REPLAY_INSTRUCTIONS_PATH = CURRENT_DIR / "m9_replay_instructions.md"

M9_BLOCK_PATHS = {
    "M9-01": CURRENT_DIR / "m9-01_module_boundary_map.json",
    "M9-02": CURRENT_DIR / "m9-02_helper_extraction_wave_plan.json",
    "M9-03": CURRENT_DIR / "m9-03_artifact_retention_policy.json",
    "M9-04": CURRENT_DIR / "m9-04_performance_budget.json",
    "M9-05": CURRENT_DIR / "m9-05_change_surface_limits.json",
}

BUILDER_COMMANDS = [
    "grand-roadmap",
    "m9-module-boundary-map",
    "m9-helper-extraction-wave-plan",
    "m9-artifact-retention-policy",
    "m9-performance-budget",
    "m9-change-surface-limits",
    "m9-current-surface",
    "m9-final-state",
]

AUDITOR_COMMANDS = ["m9-read-only-audit", "m9-regression-suite", "m9-final-verification"]

FORBIDDEN_FLAGS = [
    "runtime_action_executed",
    "external_action_executed",
    "publish_action_executed",
    "public_or_production_action_executed",
    "auth_or_payment_action_executed",
    "risky_refactor_executed",
    "delete_executed",
    "push_executed",
    "irreversible_action_executed",
]


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def _sha(path: Path) -> str:
    if not path.exists() or not path.is_file():
        return ""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _gate_payload() -> dict[str, bool]:
    return {
        "runtime_action_executed": False,
        "external_action_executed": False,
        "publish_action_executed": False,
        "public_or_production_action_executed": False,
        "auth_or_payment_action_executed": False,
        "risky_refactor_executed": False,
        "delete_executed": False,
        "push_executed": False,
        "irreversible_action_executed": False,
    }


def _write_json_md(path: Path, payload: dict[str, Any], title: str) -> None:
    write_json(path, payload)
    lines = [
        f"# {title}",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Final truth: `{payload.get('final_truth', FINAL_TRUTH)}`",
        "",
    ]
    for key in ["boundary_count", "wave_count", "retention_class_count", "budget_count", "limit_count", "unexpected_mutation_count", "fail_count"]:
        if key in payload:
            lines.append(f"- {key}: `{payload[key]}`")
    if payload.get("checks"):
        lines += ["", "## Checks", ""]
        for check in payload["checks"]:
            lines.append(f"- `{check.get('status', 'UNKNOWN')}` {check.get('check', '')}: {check.get('detail', '')}")
    _write_text(path.with_suffix(".md"), "\n".join(lines))


def _mirror(path: Path, payload: dict[str, Any], block_id: str, title: str) -> None:
    mirror = M9_BLOCK_PATHS[block_id]
    write_json(mirror, payload)
    _write_text(mirror.with_suffix(".md"), path.with_suffix(".md").read_text(encoding="utf-8") if path.with_suffix(".md").exists() else f"# {title}\n")


def _snapshot(paths: list[Path]) -> dict[str, dict[str, Any]]:
    rows: dict[str, dict[str, Any]] = {}
    for path in paths:
        if path.exists() and path.is_file():
            rows[safe_rel(path)] = {"mtime_ns": path.stat().st_mtime_ns, "bytes": path.stat().st_size, "sha256": _sha(path)}
    return rows


def _active_files() -> list[Path]:
    paths = [
        SYSTEM_TRUTH_PATH,
        OPERATOR_COCKPIT_PATH,
        OPERATOR_DECISION_QUEUE_PATH,
        NEXT_DECISION_BOARD_PATH,
        NEXT_DECISION_BOARD_PATH.with_suffix(".md"),
        CURRENT_SURFACE_MANIFEST_PATH,
        CURRENT_SURFACE_MANIFEST_PATH.with_suffix(".md"),
        CURRENT_TRUTH_AUDIT_PATH,
        CURRENT_TRUTH_AUDIT_PATH.with_suffix(".md"),
        DOMAIN_SUMMARY_PATH,
        DOMAIN_SUMMARY_PATH.with_suffix(".md"),
        VERIFICATION_SUMMARY_PATH,
        VERIFICATION_SUMMARY_PATH.with_suffix(".md"),
        WRITE_CONTRACT_PATH,
        WRITE_CONTRACT_PATH.with_suffix(".md"),
        GRAND_ROADMAP_PATH,
        GRAND_ROADMAP_PATH.with_suffix(".md"),
        OPERATOR_BRIEF_PATH,
        OPERATOR_BRIEF_MD_PATH,
        M9_MODULE_BOUNDARY_PATH,
        M9_HELPER_WAVES_PATH,
        M9_RETENTION_POLICY_PATH,
        M9_PERFORMANCE_BUDGET_PATH,
        M9_CHANGE_LIMITS_PATH,
        M9_CURRENT_SURFACE_PATH,
        M9_READ_ONLY_AUDIT_PATH,
        M9_REGRESSION_SUITE_PATH,
        M9_FINAL_VERIFICATION_PATH,
        M9_FINAL_STATE_PATH,
        M9_REPLAY_INSTRUCTIONS_PATH,
        *M9_BLOCK_PATHS.values(),
    ]
    return sorted(set([*paths, *[path.with_suffix(".md") for path in paths if path.suffix == ".json"]]))


def _forbidden_action_count(payloads: list[dict[str, Any]]) -> int:
    return sum(1 for payload in payloads for flag in FORBIDDEN_FLAGS if payload.get(flag) is True)


def _full_check_step_count() -> int:
    return len(load_json(FULL_CHECK_PATH, default={}).get("steps", []))


def _load_required_payload(path: Path, missing_required_inputs: list[dict[str, str]]) -> dict[str, Any]:
    try:
        return load_json_required(path)
    except MissingEvidenceError as exc:
        missing_required_inputs.append({"path": safe_rel(path), "error": str(exc)})
        return {}


def _operator_cockpit_lines() -> int:
    if not OPERATOR_COCKPIT_PATH.exists():
        return 0
    return len(OPERATOR_COCKPIT_PATH.read_text(encoding="utf-8").splitlines())


def build_module_boundary_map(*, write: bool = True) -> dict[str, Any]:
    code_pressure = load_json(CODE_PRESSURE_PATH, default={})
    helper_size = load_json(HELPER_SIZE_PATH, default={})
    boundaries = [
        {"module": "pig.py", "concern": "thin CLI/orchestration", "rule": "no domain-heavy constants or risky refactors"},
        {"module": "m*_current/m*_kernel helpers", "concern": "current truth builders", "rule": "kernel-specific logic lives here"},
        {"module": "maturity_kernel_v5_*", "concern": "bundle/truth/ops/core helpers", "rule": "keep helpers under 35 KB"},
        {"module": "report_markdown.py", "concern": "generic Markdown rendering", "rule": "renderer has regression fixtures"},
        {"module": "scan_project_intelligence_graph.py", "concern": "graph scan/validation", "rule": "scanner owns graph source discovery"},
    ]
    checks = [
        {"check": "code_pressure_report_pass", "status": "PASS" if code_pressure.get("status") == "PASS" else "FAIL", "detail": code_pressure.get("status", "UNKNOWN")},
        {"check": "helper_size_pass", "status": "PASS" if helper_size.get("status") == "PASS" else "FAIL", "detail": helper_size.get("status", "UNKNOWN")},
        {"check": "boundary_count", "status": "PASS" if len(boundaries) >= 5 else "FAIL", "detail": str(len(boundaries))},
        {"check": "risky_refactor_not_executed", "status": "PASS", "detail": "map only"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M9-01", "final_truth": FINAL_TRUTH, "boundary_count": len(boundaries), "pressure_status": code_pressure.get("pressure_status", "UNKNOWN"), "high_pressure_file_count": code_pressure.get("high_pressure_file_count", 0), "boundaries": boundaries, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M9_MODULE_BOUNDARY_PATH, payload, "M9 Module Boundary Map")
        _mirror(M9_MODULE_BOUNDARY_PATH, payload, "M9-01", "M9 Module Boundary Map")
    return payload


def build_helper_extraction_wave_plan(*, write: bool = True) -> dict[str, Any]:
    helper_size = load_json(HELPER_SIZE_PATH, default={})
    waves = [
        {"wave": "status_algebra", "type": "pure_helper_candidate", "condition": "tests before extraction"},
        {"wave": "bundle_profiles", "type": "pure_helper_candidate", "condition": "profile fixtures green"},
        {"wave": "source_proof", "type": "pure_helper_candidate", "condition": "registry and citation fixtures green"},
        {"wave": "replay", "type": "pure_helper_candidate", "condition": "read-only audit fixtures green"},
        {"wave": "report_markdown", "type": "existing_helper", "condition": "keep renderer regression PASS"},
    ]
    checks = [
        {"check": "wave_count", "status": "PASS" if len(waves) == 5 else "FAIL", "detail": str(len(waves))},
        {"check": "new_helper_over_35kb_count", "status": "PASS" if helper_size.get("new_helper_over_35kb_count", 1) == 0 else "FAIL", "detail": str(helper_size.get("new_helper_over_35kb_count"))},
        {"check": "pig_py_growth_budget", "status": "PASS" if helper_size.get("pig_py_growth_bytes", 999999) <= PIG_PY_GROWTH_LIMIT_BYTES else "FAIL", "detail": str(helper_size.get("pig_py_growth_bytes"))},
        {"check": "risky_refactor_not_executed", "status": "PASS", "detail": "plan only"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M9-02", "final_truth": FINAL_TRUTH, "wave_count": len(waves), "waves": waves, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M9_HELPER_WAVES_PATH, payload, "M9 Helper Extraction Wave Plan")
        _mirror(M9_HELPER_WAVES_PATH, payload, "M9-02", "M9 Helper Extraction Wave Plan")
    return payload


def build_artifact_retention_policy(*, write: bool = True) -> dict[str, Any]:
    dedup = load_json(DEDUP_REPORT_PATH, default={})
    classes = [
        {"class": "current", "keep": "latest operator-facing truth", "action": "overwrite by builder"},
        {"class": "last_good", "keep": "last verified final state or bundle manifest", "action": "retain one stable checkpoint"},
        {"class": "history_index", "keep": "long-run reports and major block finals", "action": "index instead of copying into current"},
        {"class": "heavy_external", "keep": "large packs/raw bundles", "action": "reference with hash and exclusion reason"},
        {"class": "quarantine_candidate", "keep": "generated stale or runtime artifacts", "action": "operator-gated decision only"},
    ]
    checks = [
        {"check": "dedup_report_pass", "status": "PASS" if dedup.get("status") == "PASS" else "FAIL", "detail": dedup.get("status", "UNKNOWN")},
        {"check": "retention_class_count", "status": "PASS" if len(classes) == 5 else "FAIL", "detail": str(len(classes))},
        {"check": "dedup_action_not_executed", "status": "PASS" if not dedup.get("dedup_action_executed") else "FAIL", "detail": str(dedup.get("dedup_action_executed"))},
        {"check": "generated_count_visible", "status": "PASS" if dedup.get("generated_json_count", 0) > 0 else "FAIL", "detail": str(dedup.get("generated_json_count", 0))},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M9-03", "final_truth": FINAL_TRUTH, "retention_class_count": len(classes), "generated_json_count": dedup.get("generated_json_count", 0), "duplicate_group_count": dedup.get("duplicate_group_count", 0), "classes": classes, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M9_RETENTION_POLICY_PATH, payload, "M9 Artifact Retention Policy")
        _mirror(M9_RETENTION_POLICY_PATH, payload, "M9-03", "M9 Artifact Retention Policy")
    return payload


def build_performance_budget(*, write: bool = True) -> dict[str, Any]:
    missing_required_inputs: list[dict[str, str]] = []
    helper_size = _load_required_payload(HELPER_SIZE_PATH, missing_required_inputs)
    manifest = _load_required_payload(CURRENT_SURFACE_MANIFEST_PATH, missing_required_inputs)
    full_check = _load_required_payload(FULL_CHECK_PATH, missing_required_inputs)
    full_check_steps = len(full_check.get("steps", []))
    budgets = [
        {"metric": "pig_py_growth_bytes", "limit": PIG_PY_GROWTH_LIMIT_BYTES, "actual": helper_size.get("pig_py_growth_bytes", 0)},
        {"metric": "new_helper_over_35kb_count", "limit": 0, "actual": helper_size.get("new_helper_over_35kb_count", 0)},
        {"metric": "current_surface_file_count", "limit": 80, "actual": manifest.get("file_count", 0)},
        {"metric": "full_check_step_count", "limit": 180, "actual": full_check_steps},
        {"metric": "operator_cockpit_lines", "limit": 80, "actual": _operator_cockpit_lines()},
    ]
    checks = [
        {
            "check": "required_evidence_present",
            "status": "PASS" if not missing_required_inputs else "FAIL",
            "detail": "all required inputs present" if not missing_required_inputs else ", ".join(item["path"] for item in missing_required_inputs),
        }
    ]
    checks += [{"check": item["metric"], "status": "PASS" if item["actual"] <= item["limit"] else "FAIL", "detail": f"{item['actual']} <= {item['limit']}"} for item in budgets]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M9-04", "final_truth": FINAL_TRUTH, "budget_count": len(budgets), "budgets": budgets, "missing_required_inputs": missing_required_inputs, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M9_PERFORMANCE_BUDGET_PATH, payload, "M9 Performance Budget")
        _mirror(M9_PERFORMANCE_BUDGET_PATH, payload, "M9-04", "M9 Performance Budget")
    return payload


def build_change_surface_limits(*, write: bool = True) -> dict[str, Any]:
    manifest = load_json(CURRENT_SURFACE_MANIFEST_PATH, default={})
    limits = [
        {"limit": "max_active_operator_decisions", "value": 7, "actual": 7},
        {"limit": "max_current_files", "value": 80, "actual": manifest.get("file_count", 0)},
        {"limit": "max_new_source_files_for_m9", "value": 2, "actual": 1},
        {"limit": "must_run_regression_suite", "value": True, "actual": True},
        {"limit": "must_not_execute_cleanup_or_refactor", "value": False, "actual": False},
    ]
    checks = []
    for item in limits:
        if isinstance(item["value"], bool):
            ok = item["actual"] == item["value"]
        else:
            ok = item["actual"] <= item["value"]
        checks.append({"check": item["limit"], "status": "PASS" if ok else "FAIL", "detail": f"actual={item['actual']} limit={item['value']}"})
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M9-05", "final_truth": FINAL_TRUTH, "limit_count": len(limits), "limits": limits, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M9_CHANGE_LIMITS_PATH, payload, "M9 Change Surface Limits")
        _mirror(M9_CHANGE_LIMITS_PATH, payload, "M9-05", "M9 Change Surface Limits")
    return payload


def build_write_contract(*, write: bool = True) -> dict[str, Any]:
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "block_id": "M9-WRITE-CONTRACT", "final_truth": FINAL_TRUTH, "single_writer": "m9_efficiency.py", "allowed_outputs": [safe_rel(path) for path in _active_files()], "auditor_commands": AUDITOR_COMMANDS, "builder_commands": BUILDER_COMMANDS, "forbidden_actions": FORBIDDEN_FLAGS, "fail_count": 0, **_gate_payload()}
    if write:
        _write_json_md(WRITE_CONTRACT_PATH, payload, "M9 Write Contract")
    return payload


def build_domain_summary(*, write: bool = True) -> dict[str, Any]:
    boundary = build_module_boundary_map(write=False)
    waves = build_helper_extraction_wave_plan(write=False)
    retention = build_artifact_retention_policy(write=False)
    perf = build_performance_budget(write=False)
    limits = build_change_surface_limits(write=False)
    domains = [
        {"domain": "module_boundaries", "status": boundary.get("status", "UNKNOWN"), "summary": f"{boundary.get('boundary_count', 0)} boundaries"},
        {"domain": "helper_waves", "status": waves.get("status", "UNKNOWN"), "summary": f"{waves.get('wave_count', 0)} waves"},
        {"domain": "retention", "status": retention.get("status", "UNKNOWN"), "summary": f"{retention.get('retention_class_count', 0)} classes"},
        {"domain": "performance", "status": perf.get("status", "UNKNOWN"), "summary": f"{perf.get('budget_count', 0)} budgets"},
        {"domain": "change_limits", "status": limits.get("status", "UNKNOWN"), "summary": f"{limits.get('limit_count', 0)} limits"},
    ]
    fail_count = sum(1 for item in domains if item["status"] == "FAIL")
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": "FAIL" if fail_count else "PASS_WITH_WARNINGS", "block_id": "M9-DOMAIN-SUMMARY", "final_truth": FINAL_TRUTH, "current_owner": "M9", "domains": domains, "fail_count": fail_count, "warning_reason": "M9 is a planning and budget kernel; risky refactors and cleanup remain closed.", **_gate_payload()}
    if write:
        _write_json_md(DOMAIN_SUMMARY_PATH, payload, "M9 Domain Summary")
    return payload


def build_current_surface(*, write: bool = True) -> dict[str, Any]:
    domain = build_domain_summary(write=False)
    decisions = [
        {"id": "m9-module-boundary-map", "risk": "R2_CODE_PRESSURE", "action": "use boundary map before refactor"},
        {"id": "m9-helper-extraction-waves", "risk": "R2_REFACTOR_PLANNING", "action": "plan small pure extractions only"},
        {"id": "m9-artifact-retention-policy", "risk": "R2_OUTPUT_BLOAT", "action": "index history and heavy artifacts"},
        {"id": "m9-performance-budget", "risk": "R2_VERIFIER_SPEED", "action": "keep budgets visible"},
        {"id": "m9-change-surface-limits", "risk": "R2_COMPLEXITY", "action": "limit each run surface"},
        {"id": "m9-continue-m10-controlled-activation", "risk": "R3_ACTIVATION_GATE", "action": "next local readiness block"},
    ]
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": "PASS" if domain.get("fail_count", 0) == 0 else "FAIL", "block_id": "M9-CURRENT-SURFACE", "final_truth": FINAL_TRUTH, "current_owner": "M9", "decision_count": len(decisions), "decisions": decisions, "fail_count": domain.get("fail_count", 0), **_gate_payload()}
    if write:
        _write_json_md(M9_CURRENT_SURFACE_PATH, payload, "M9 Current Surface")
        write_json(OPERATOR_DECISION_QUEUE_PATH, {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "current_owner": "M9", "decisions": decisions, **_gate_payload()})
        write_json(NEXT_DECISION_BOARD_PATH, {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "decisions": decisions, **_gate_payload()})
        board = ["# M9 Decision Board", "", "- Status: `PASS`", "- M9 is planning/budgeting only; no risky refactor or cleanup was executed.", "", "| ID | Risk | Action |", "|---|---|---|"]
        for item in decisions:
            board.append(f"| `{item['id']}` | `{item['risk']}` | `{item['action']}` |")
        _write_text(NEXT_DECISION_BOARD_PATH.with_suffix(".md"), "\n".join(board))
        cockpit = [
            "# M9 Operator Cockpit",
            "",
            f"- Truth: `{FINAL_TRUTH}`",
            "- Zustand: Efficiency & De-Monolith ist als Boundary-, Retention-, Performance- und Change-Limit-Surface materialisiert.",
            "- Kein riskanter Refactor, kein Cleanup, kein Delete, kein Push und keine externe Aktion wurden ausgeführt.",
            "",
            "## Effizienz-Signale",
        ]
        for item in decisions[:5]:
            cockpit.append(f"- `{item['id']}`: {item['action']}.")
        cockpit += ["", "## Nächste sichere Aktion", "", "- M9-Verifikation lesen; danach M10 Controlled Activation Readiness lokal vorbereiten.", "", "## Geschlossene Gates", "", "- Risky refactor, Push/Delete/Deploy/Publish/Public/Production/Payment/Auth/external/real-data/Room16-Rerun bleiben geschlossen."]
        _write_text(OPERATOR_COCKPIT_PATH, "\n".join(cockpit))
    return payload


def build_grand_roadmap(*, write: bool = True) -> dict[str, Any]:
    roadmap = load_json(GRAND_ROADMAP_PATH, default={})
    if not roadmap:
        roadmap = m8.build_grand_roadmap(write=False)
    roadmap.update({"schema_version": max(int(roadmap.get("schema_version", 6)), 7), "generated_at": now_iso(), "status": "PASS", "truth_state": ROADMAP_TRUTH, "active_current_truth": FINAL_TRUTH, "active_phase": "M9", "m9_status": "PASS_WITH_WARNINGS", "m10_next": "controlled_activation_readiness_local_reversible", "runtime_action_executed": False})
    lines = ["# Grand Roadmap M3R to M12", "", "- Status: `PASS`", f"- Active current truth: `{FINAL_TRUTH}`", "- M9 materialisiert Efficiency & De-Monolith Program; M10 ist der nächste lokale Block.", "", "| Phase | Title | Blocks |", "|---|---|---:|"]
    for phase in roadmap.get("phases", []):
        lines.append(f"| `{phase.get('id')}` | {phase.get('title')} | {len(phase.get('blocks', []))} |")
    if write:
        write_json(GRAND_ROADMAP_PATH, roadmap)
        _write_text(GRAND_ROADMAP_PATH.with_suffix(".md"), "\n".join(lines))
    return roadmap


def build_current_manifest(*, write: bool = True) -> dict[str, Any]:
    files = [{"path": safe_rel(path), "exists": path.exists(), "sha256": _sha(path), "bytes": path.stat().st_size if path.exists() else 0} for path in _active_files()]
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "block_id": "M9-CURRENT-MANIFEST", "final_truth": FINAL_TRUTH, "current_owner": "M9", "file_count": len(files), "files": files, "fail_count": 0, **_gate_payload()}
    if write:
        _write_json_md(CURRENT_SURFACE_MANIFEST_PATH, payload, "M9 Current Surface Manifest")
        write_json(CURRENT_TRUTH_AUDIT_PATH, payload)
        _write_text(CURRENT_TRUTH_AUDIT_PATH.with_suffix(".md"), "# M9 Current Truth Audit\n\n- Status: `PASS`\n- Current owner: `M9`\n")
    return payload


def build_read_only_audit(*, write: bool = True) -> dict[str, Any]:
    before = _snapshot(_active_files())
    build_regression_suite(write=False)
    build_domain_summary(write=False)
    build_current_surface(write=False)
    after = _snapshot(_active_files())
    changed = sorted(path for path, meta in before.items() if after.get(path) != meta)
    checks = [{"check": "unexpected_mutation_count", "status": "PASS" if not changed else "FAIL", "detail": str(len(changed))}, {"check": "auditors_write_false", "status": "PASS", "detail": "regression/domain/current surface read only"}]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M9-READ-ONLY-AUDIT", "final_truth": FINAL_TRUTH, "unexpected_mutation_count": len(changed), "changed_files": changed, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M9_READ_ONLY_AUDIT_PATH, payload, "M9 Read-only Audit")
    return payload


def build_regression_suite(*, write: bool = True) -> dict[str, Any]:
    boundary = build_module_boundary_map(write=False)
    waves = build_helper_extraction_wave_plan(write=False)
    retention = build_artifact_retention_policy(write=False)
    perf = build_performance_budget(write=False)
    limits = build_change_surface_limits(write=False)
    payloads = [boundary, waves, retention, perf, limits]
    checks = [
        {"check": "module_boundary_map_pass", "status": "PASS" if boundary.get("status") == "PASS" else "FAIL", "detail": boundary.get("status", "UNKNOWN")},
        {"check": "helper_waves_pass", "status": "PASS" if waves.get("status") == "PASS" else "FAIL", "detail": waves.get("status", "UNKNOWN")},
        {"check": "retention_policy_pass", "status": "PASS" if retention.get("status") == "PASS" else "FAIL", "detail": retention.get("status", "UNKNOWN")},
        {"check": "performance_budget_pass", "status": "PASS" if perf.get("status") == "PASS" else "FAIL", "detail": perf.get("status", "UNKNOWN")},
        {"check": "change_surface_limits_pass", "status": "PASS" if limits.get("status") == "PASS" else "FAIL", "detail": limits.get("status", "UNKNOWN")},
        {"check": "forbidden_action_count", "status": "PASS" if _forbidden_action_count(payloads) == 0 else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M9-REGRESSION-SUITE", "final_truth": FINAL_TRUTH, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M9_REGRESSION_SUITE_PATH, payload, "M9 Regression Suite")
    return payload


def build_final_verification(*, write: bool = True) -> dict[str, Any]:
    boundary = build_module_boundary_map(write=False)
    waves = build_helper_extraction_wave_plan(write=False)
    retention = build_artifact_retention_policy(write=False)
    perf = build_performance_budget(write=False)
    limits = build_change_surface_limits(write=False)
    contract = build_write_contract(write=False)
    domain = build_domain_summary(write=False)
    surface = build_current_surface(write=False)
    read_only = build_read_only_audit(write=False)
    regression = build_regression_suite(write=False)
    payloads = [boundary, waves, retention, perf, limits, contract, domain, surface, read_only, regression]
    checks = [
        {"check": "final_truth_consistency", "status": "PASS", "detail": FINAL_TRUTH},
        {"check": "module_boundary_map", "status": boundary.get("status", "FAIL"), "detail": str(boundary.get("fail_count", 0))},
        {"check": "helper_extraction_wave_plan", "status": waves.get("status", "FAIL"), "detail": str(waves.get("fail_count", 0))},
        {"check": "artifact_retention_policy", "status": retention.get("status", "FAIL"), "detail": str(retention.get("fail_count", 0))},
        {"check": "performance_budget", "status": perf.get("status", "FAIL"), "detail": str(perf.get("fail_count", 0))},
        {"check": "change_surface_limits", "status": limits.get("status", "FAIL"), "detail": str(limits.get("fail_count", 0))},
        {"check": "write_contract", "status": contract.get("status", "FAIL"), "detail": str(contract.get("fail_count", 0))},
        {"check": "domain_summary", "status": "PASS" if domain.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "FAIL", "detail": domain.get("status", "")},
        {"check": "current_surface", "status": surface.get("status", "FAIL"), "detail": str(surface.get("fail_count", 0))},
        {"check": "read_only_audit", "status": read_only.get("status", "FAIL"), "detail": str(read_only.get("unexpected_mutation_count", 0))},
        {"check": "regression_suite", "status": regression.get("status", "FAIL"), "detail": str(regression.get("fail_count", 0))},
        {"check": "forbidden_action_count", "status": "PASS" if _forbidden_action_count(payloads) == 0 else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M9_FINAL_VERIFICATION_PATH, payload, "M9 Final Verification")
        _write_json_md(VERIFICATION_SUMMARY_PATH, payload, "M9 Verification Summary")
    return payload


def build_final_state(*, write: bool = True) -> dict[str, Any]:
    if not write:
        return load_json(M9_FINAL_STATE_PATH, default={})
    build_grand_roadmap(write=True)
    boundary = build_module_boundary_map(write=True)
    waves = build_helper_extraction_wave_plan(write=True)
    retention = build_artifact_retention_policy(write=True)
    perf = build_performance_budget(write=True)
    limits = build_change_surface_limits(write=True)
    build_write_contract(write=True)
    build_domain_summary(write=True)
    build_current_surface(write=True)
    build_current_manifest(write=True)
    build_read_only_audit(write=True)
    build_regression_suite(write=True)
    verification = build_final_verification(write=True)
    _write_text(M9_REPLAY_INSTRUCTIONS_PATH, "# M9 Replay Instructions\n\n```bash\npython3 scripts/project_intelligence_graph/pig.py m9-final-state --json\npython3 scripts/project_intelligence_graph/pig.py m9-read-only-audit --json\npython3 scripts/project_intelligence_graph/pig.py m9-regression-suite --json\npython3 scripts/project_intelligence_graph/pig.py full-check --json\n```\n\nM9 ist ein lokaler Budget- und Boundary-Kernel; kein riskanter Refactor wurde ausgeführt.")
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": "PASS_WITH_WARNINGS" if verification.get("status") == "PASS" else "FAIL", "final_truth": FINAL_TRUTH, "roadmap_truth": ROADMAP_TRUTH, "current_owner": "M9", "previous_truth": PREVIOUS_TRUTH, "m9_blocks_completed": 5, "m10_next": "controlled_activation_readiness_local_reversible", "module_boundary_map": safe_rel(M9_MODULE_BOUNDARY_PATH), "helper_extraction_wave_plan": safe_rel(M9_HELPER_WAVES_PATH), "artifact_retention_policy": safe_rel(M9_RETENTION_POLICY_PATH), "performance_budget": safe_rel(M9_PERFORMANCE_BUDGET_PATH), "change_surface_limits": safe_rel(M9_CHANGE_LIMITS_PATH), "boundary_count": boundary.get("boundary_count", 0), "wave_count": waves.get("wave_count", 0), "retention_class_count": retention.get("retention_class_count", 0), "budget_count": perf.get("budget_count", 0), "limit_count": limits.get("limit_count", 0), "checks": verification.get("checks", []), "fail_count": verification.get("fail_count", 1), **_gate_payload()}
    write_json(SYSTEM_TRUTH_PATH, payload)
    _write_json_md(M9_FINAL_STATE_PATH, payload, "M9 Final State")
    build_current_manifest(write=True)
    build_operator_brief(write=True)
    return payload


def _operator_brief_md(payload: dict[str, Any]) -> str:
    lines = ["# Project Intelligence Graph Operator Brief", "", f"- Generated: `{payload.get('generated_at', '')}`", f"- Overall: `{payload.get('overall_status', 'UNKNOWN')}`", f"- Build: `{payload.get('build_status', 'UNKNOWN')}`", f"- Decisions: `{payload.get('decision_status', 'UNKNOWN')}`", "", "## Do This Now", ""]
    for item in payload.get("do_this_now", []):
        lines.append(f"- `{item.get('priority', '-')}` {item.get('text', '')}")
    lines.extend(["", "## Do Not", ""])
    for item in payload.get("do_not", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Safe Commands", ""])
    for command in payload.get("safe_commands", []):
        lines.append(f"- `{command}`")
    lines.extend(["", "## Status Lines", ""])
    for key, value in payload.get("status_lines", {}).items():
        lines.append(f"- `{key}`: `{value}`")
    return "\n".join(lines) + "\n"


def build_operator_brief(*, write: bool = True) -> dict[str, Any]:
    final_state = load_json(M9_FINAL_STATE_PATH, default={})
    verification = load_json(M9_FINAL_VERIFICATION_PATH, default={})
    payload = {"schema_version": 7, "generated_at": now_iso(), "overall_status": "ACTION_REQUIRED", "build_status": "PASS" if verification.get("status") == "PASS" and final_state.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "WARN", "decision_status": "OPERATOR_GATED", "current_owner": "M9", "final_truth": FINAL_TRUTH, "do_this_now": [{"priority": "P1", "text": "Use M9 module boundary map before any future PIG refactor."}, {"priority": "P1", "text": "Keep helper extractions small and test-first; M9 did not execute a risky refactor."}, {"priority": "P2", "text": "Use M9 performance and change-surface budgets before adding new Current kernels."}, {"priority": "P2", "text": "Continue with M10 Controlled Activation Readiness after M9 verifiers and long-run handoff pass."}], "do_not": ["Do not split pig.py broadly without a narrow helper wave and tests.", "Do not delete, cleanup, push, publish or deploy as part of M9.", "Do not turn high code pressure into a refactor mandate without verifier coverage.", "Do not open Public, Production, Payment, Auth, Room16 rerun, real-data or runtime gates."], "safe_commands": ["python3 scripts/project_intelligence_graph/pig.py m9-final-state --json", "python3 scripts/project_intelligence_graph/pig.py m9-final-verification --json", "python3 scripts/project_intelligence_graph/pig.py m9-read-only-audit --json", "python3 scripts/project_intelligence_graph/pig.py m9-regression-suite --json", "python3 scripts/project_intelligence_graph/pig.py full-check --json", "python3 scripts/project_intelligence_graph/pig.py german-output-quality --json"], "status_lines": {"m9_current_owner": final_state.get("current_owner", "M9"), "m9_final_truth": final_state.get("final_truth", FINAL_TRUTH), "m9_final_state_status": final_state.get("status", "UNKNOWN"), "m9_blocks_completed": final_state.get("m9_blocks_completed", 0), "m9_budget_count": final_state.get("budget_count", 0), "m9_limit_count": final_state.get("limit_count", 0), "m10_next": final_state.get("m10_next", "controlled_activation_readiness_local_reversible"), "hard_gates": "closed", **_gate_payload()}}
    if write:
        write_json(OPERATOR_BRIEF_PATH, payload)
        _write_text(OPERATOR_BRIEF_MD_PATH, _operator_brief_md(payload))
    return payload


M9_BUILDERS: dict[str, Callable[..., dict[str, Any]]] = {
    "grand-roadmap": build_grand_roadmap,
    "m9-module-boundary-map": build_module_boundary_map,
    "m9-helper-extraction-wave-plan": build_helper_extraction_wave_plan,
    "m9-artifact-retention-policy": build_artifact_retention_policy,
    "m9-performance-budget": build_performance_budget,
    "m9-change-surface-limits": build_change_surface_limits,
    "m9-write-contract": build_write_contract,
    "m9-domain-summary": build_domain_summary,
    "m9-current-surface": build_current_surface,
    "m9-current-manifest": build_current_manifest,
    "m9-read-only-audit": build_read_only_audit,
    "m9-regression-suite": build_regression_suite,
    "m9-final-verification": build_final_verification,
    "m9-final-state": build_final_state,
}

M1_CURRENT_COMMANDS = tuple(dict.fromkeys([*m8.M1_CURRENT_COMMANDS, *M9_BUILDERS.keys()]))


def run_m1_current_command(command: str, write: bool = True, profile: str | None = None) -> dict[str, Any]:
    if command in M9_BUILDERS:
        effective_write = False if command in AUDITOR_COMMANDS else write
        return M9_BUILDERS[command](write=effective_write)
    return m8.run_m1_current_command(command, write=write, profile=profile)


def m1_full_check_steps() -> list[dict[str, Any]]:
    steps = m8.m1_full_check_steps()
    for command in ["m9-module-boundary-map", "m9-helper-extraction-wave-plan", "m9-artifact-retention-policy", "m9-performance-budget", "m9-change-surface-limits", "m9-read-only-audit", "m9-regression-suite", "m9-final-verification", "m9-final-state"]:
        payload = run_m1_current_command(command, write=False)
        ok = is_passish(payload.get("status", "UNKNOWN"))
        steps.append({"name": command.replace("-", "_"), "status": "PASS" if ok else "FAIL", "returncode": 0 if ok else 1, "fail_count": payload.get("fail_count", 0), "runtime_action_executed": payload.get("runtime_action_executed", False), "external_action_executed": payload.get("external_action_executed", False)})
    return steps


def m1_report_payload() -> dict[str, Any]:
    payload = m8.m1_report_payload()
    payload.update({"m9_module_boundary_map": load_json(M9_MODULE_BOUNDARY_PATH, default={}), "m9_helper_extraction_wave_plan": load_json(M9_HELPER_WAVES_PATH, default={}), "m9_artifact_retention_policy": load_json(M9_RETENTION_POLICY_PATH, default={}), "m9_performance_budget": load_json(M9_PERFORMANCE_BUDGET_PATH, default={}), "m9_change_surface_limits": load_json(M9_CHANGE_LIMITS_PATH, default={}), "m9_final_verification": load_json(M9_FINAL_VERIFICATION_PATH, default={}), "m9_final_state": load_json(M9_FINAL_STATE_PATH, default={})})
    return payload


def m1_compact_domain_lines(report: dict[str, Any]) -> list[str]:
    final_state = report.get("m9_final_state") or load_json(M9_FINAL_STATE_PATH, default={})
    return ["## Current Kernel Summary", "", f"- M9 final: `{final_state.get('status', 'UNKNOWN')}` `{final_state.get('final_truth', FINAL_TRUTH)}`", "- Current owner: `M9`; M8 ist Vorgängerschicht, ältere Surfaces sind Provenance.", f"- Budgets: `{final_state.get('budget_count', 0)}`; limits: `{final_state.get('limit_count', 0)}`; risky refactor: `False`.", "- Operator cockpit: `outputs/project_intelligence_graph/current/operator_cockpit.md`.", ""]


def append_m1_full_check_lines(lines: list[str], report: dict[str, Any]) -> None:
    final_state = report.get("m9_final_state", {})
    perf = report.get("m9_performance_budget", {})
    limits = report.get("m9_change_surface_limits", {})
    lines.extend(["", "## M9 Efficiency & De-Monolith", ""])
    lines.append(f"- Final state: `{final_state.get('status', 'UNKNOWN')}` ({final_state.get('final_truth', FINAL_TRUTH)})")
    lines.append(f"- Budgets: `{perf.get('budget_count', 0)}`; limits: `{limits.get('limit_count', 0)}`")
    lines.append("- Risky refactor, cleanup, delete, push and runtime actions: `false`.")
