#!/usr/bin/env python3
"""Separate acceptance test report for Thin Roles capability governance."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
PIG_DIR = ROOT / "scripts" / "project_intelligence_graph"
OUTPUT_DIR = ROOT / "outputs" / "project_intelligence_graph"
DOCS_DIR = ROOT / "docs" / "project-intelligence-graph"
LIONCOM_DIR = Path("/Users/BjornRosinger/Documents/DreamFactory/LIONCOM/mission-control-board")
VAULT_DIR = Path("/Users/BjornRosinger/Documents/Obsidian/Test Vaul Privat/Human Overview")
REPORT_JSON = OUTPUT_DIR / "capability_governance_separate_test_report.json"
REPORT_MD = OUTPUT_DIR / "capability_governance_separate_test_report.md"

sys.path.insert(0, str(PIG_DIR))

from capability_registry import (  # noqa: E402
    build_agent_product_maturity_contract,
    build_agentization_decision_gate,
    build_background_quality_gates,
    build_capability_registry,
    build_capability_telemetry,
    build_fresh_session_context_budget,
    build_shannon_sandbox_contract,
    validate_capability_registry,
)
from separate_acceptance_runner import (  # noqa: E402
    add_payload_checks,
    add_result,
    build_acceptance_report,
    command_result,
    load_json,
    run_command,
    status_result,
    write_acceptance_report,
)


EXPECTED_CAPABILITY_IDS = {
    "shannon_security_sandbox",
    "codegraph_pig_lens",
    "codeneedle_model_benchmark",
    "design_quality_gate",
    "motion_quality_gate",
    "anti_slop_ui_review",
    "rowboat_ux_benchmark",
    "readable_report_delivery_standard",
    "external_repo_audit_standard",
    "agentization_decision_gate",
}

EXPECTED_DOCS = [
    DOCS_DIR / "CAPABILITY_REGISTRY_SCHEMA.json",
    DOCS_DIR / "CAPABILITY_REGISTRY_POLICY.md",
    DOCS_DIR / "SHANNON_SECURITY_SANDBOX_CONTRACT.md",
    DOCS_DIR / "FRESH_SESSION_CONTEXT_BUDGET_POLICY.md",
    DOCS_DIR / "BACKGROUND_QUALITY_GATES_POLICY.md",
    DOCS_DIR / "CAPABILITY_TELEMETRY_SCHEMA.json",
    DOCS_DIR / "CAPABILITY_TELEMETRY_POLICY.md",
    DOCS_DIR / "CAPABILITY_USAGE_LEDGER.json",
    DOCS_DIR / "AGENTIZATION_DECISION_GATE_SCHEMA.json",
    DOCS_DIR / "AGENTIZATION_DECISION_GATE_POLICY.md",
    DOCS_DIR / "AGENT_PRODUCT_MATURITY_CONTRACT_SCHEMA.json",
    DOCS_DIR / "AGENT_PRODUCT_MATURITY_CONTRACT_POLICY.md",
]

EXPECTED_SOURCE_IDS = {
    "pig:capability-registry-schema",
    "pig:capability-registry-policy",
    "pig:capability-telemetry-schema",
    "pig:capability-telemetry-policy",
    "pig:capability-usage-ledger",
    "pig:agentization-decision-gate-schema",
    "pig:agentization-decision-gate-policy",
    "pig:agent-product-maturity-contract-schema",
    "pig:agent-product-maturity-contract-policy",
    "pig:capability-registry",
    "pig:capability-registry-audit",
    "pig:capability-registry-telemetry",
    "pig:agentization-decision-gate",
    "pig:agent-product-maturity-contract",
    "pig:fresh-session-context-budget-policy",
}


def build_sections(*, skip_full_check: bool = False, skip_lion: bool = False) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    sections: list[dict[str, Any]] = []
    artifacts: dict[str, Any] = {}

    registry = build_capability_registry(output_dir=OUTPUT_DIR, docs_dir=DOCS_DIR, write=False)
    registry_validation = validate_capability_registry(registry, docs_dir=DOCS_DIR)
    records = registry.get("records", [])
    record_by_id = {record.get("capability_id"): record for record in records if isinstance(record, dict)}

    section = {"id": "registry", "title": "Capability Registry", "tests": []}
    add_result(section, "registry.status", "Registry status is PASS", registry.get("status") == "PASS", str(registry.get("status")))
    add_result(section, "registry.validation", "Registry validation is PASS", registry_validation.get("status") == "PASS", str(registry_validation.get("status")))
    add_payload_checks(section, "registry.validation", registry_validation.get("checks", []))
    add_result(section, "registry.expected_ids", "Expected capability IDs are present", EXPECTED_CAPABILITY_IDS.issubset(set(record_by_id)), f"missing={sorted(EXPECTED_CAPABILITY_IDS - set(record_by_id))}")
    add_result(section, "registry.no_agents", "Registry contains no approved/new agent roles", registry.get("summary", {}).get("agent_count") == 0, str(registry.get("summary", {}).get("agent_count")))
    add_result(section, "registry.no_runtime", "No registry record executed runtime/external/irreversible actions", all(not record.get(flag) for record in records for flag in ["runtime_action_executed", "external_action_executed", "irreversible_action_executed"]), "runtime flags all false")
    add_result(section, "registry.shannon", "Shannon remains a sandbox with typo alias", record_by_id.get("shannon_security_sandbox", {}).get("type") == "sandbox" and "Shanon" in record_by_id.get("shannon_security_sandbox", {}).get("aliases", []), record_by_id.get("shannon_security_sandbox", {}))
    add_result(section, "registry.design_modes", "Design/Motion/Anti-Slop are gates or review mode, not agents", all(record_by_id.get(cid, {}).get("is_agent") is False for cid in ["design_quality_gate", "motion_quality_gate", "anti_slop_ui_review"]), "is_agent=false")
    sections.append(section)

    shannon = build_shannon_sandbox_contract(output_dir=OUTPUT_DIR, docs_dir=DOCS_DIR, write=False)
    fresh = build_fresh_session_context_budget(output_dir=OUTPUT_DIR, docs_dir=DOCS_DIR, write=False)
    background = build_background_quality_gates(output_dir=OUTPUT_DIR, docs_dir=DOCS_DIR, write=False)
    section = {"id": "supporting_gates", "title": "Shannon, Fresh Session Budget, Background Gates", "tests": []}
    status_result(section, "shannon.status", "Shannon sandbox contract", shannon)
    add_payload_checks(section, "shannon", shannon.get("checks", []))
    status_result(section, "fresh.status", "Fresh session context budget", fresh)
    add_payload_checks(section, "fresh", fresh.get("checks", []))
    add_result(section, "fresh.max_notes", "Fresh session budget stays at max 4 core notes", fresh.get("max_default_core_notes") == 4, str(fresh.get("max_default_core_notes")))
    status_result(section, "background.status", "Background quality gates", background)
    add_payload_checks(section, "background", background.get("checks", []))
    add_result(section, "background.count", "Four background gates are present", background.get("gate_count") == 4, str(background.get("gate_count")))
    sections.append(section)

    telemetry = build_capability_telemetry(output_dir=OUTPUT_DIR, docs_dir=DOCS_DIR, write=False)
    section = {"id": "telemetry", "title": "Capability Telemetry", "tests": []}
    status_result(section, "telemetry.status", "Telemetry status", telemetry)
    add_payload_checks(section, "telemetry", telemetry.get("checks", []))
    add_result(section, "telemetry.item_count", "Telemetry covers every registry record", telemetry.get("item_count") == len(records), f"items={telemetry.get('item_count')} records={len(records)}")
    add_result(section, "telemetry.usage_total", "Telemetry has recorded usage", telemetry.get("usage_total", 0) >= 5, str(telemetry.get("usage_total")))
    add_result(section, "telemetry.ledger_total", "Usage total equals ledger event count", telemetry.get("usage_total") == telemetry.get("ledger_event_count"), f"usage={telemetry.get('usage_total')} ledger={telemetry.get('ledger_event_count')}")
    add_result(section, "telemetry.value", "Every usage has verified value or better", telemetry.get("verified_value_total", 0) >= telemetry.get("usage_total", 0), f"verified={telemetry.get('verified_value_total')} usage={telemetry.get('usage_total')}")
    add_result(section, "telemetry.risk", "Risk-blocking value is measured", telemetry.get("risk_blocked_total", 0) >= 4, str(telemetry.get("risk_blocked_total")))
    add_result(section, "telemetry.no_agent_candidate", "No capability is telemetry-ready as an agent candidate", telemetry.get("agent_candidate_count") == 0, str(telemetry.get("agent_candidate_count")))
    add_result(section, "telemetry.no_runtime", "Telemetry did not execute runtime/external/irreversible actions", all(telemetry.get(flag) is False for flag in ["runtime_action_executed", "external_action_executed", "irreversible_action_executed"]), "runtime flags false")
    sections.append(section)

    agentization = build_agentization_decision_gate(output_dir=OUTPUT_DIR, docs_dir=DOCS_DIR, write=False)
    section = {"id": "agentization", "title": "Agentization Decision Gate", "tests": []}
    status_result(section, "agentization.status", "Agentization gate status", agentization)
    add_payload_checks(section, "agentization", agentization.get("checks", []))
    add_result(section, "agentization.no_candidates", "No candidate agents are approved by default", agentization.get("candidate_agent_count") == 0 and agentization.get("approved_agent_count") == 0, f"candidate={agentization.get('candidate_agent_count')} approved={agentization.get('approved_agent_count')}")
    add_result(section, "agentization.stay_capability", "All registry items stay capability/gate/sandbox/review", agentization.get("stay_capability_count") == len(records), f"stay={agentization.get('stay_capability_count')} records={len(records)}")
    add_result(section, "agentization.all_decisions", "Every decision is stay_capability", all(item.get("decision") == "stay_capability" for item in agentization.get("decisions", [])), "all stay_capability")
    add_result(section, "agentization.lifecycle", "Required lifecycle is visible", "Trigger -> Job Card -> Work -> Artifact -> Verifier -> Handoff -> Memory" in str(agentization.get("required_lifecycle", "")), str(agentization.get("required_lifecycle", "")))
    sections.append(section)

    product = build_agent_product_maturity_contract(output_dir=OUTPUT_DIR, docs_dir=DOCS_DIR, write=False)
    section = {"id": "agent_product_contract", "title": "Agent Product Maturity Contract", "tests": []}
    status_result(section, "product.status", "Product contract status", product)
    add_payload_checks(section, "product", product.get("checks", []))
    add_result(section, "product.mode", "Mode stays template-ready without productized agents", product.get("mode") == "template_ready_no_productized_agents", str(product.get("mode")))
    add_result(section, "product.no_agents", "No approved/product-ready agents exist", product.get("candidate_agent_count") == 0 and product.get("approved_agent_count") == 0 and product.get("product_contract_ready_count") == 0, f"candidate={product.get('candidate_agent_count')} approved={product.get('approved_agent_count')} ready={product.get('product_contract_ready_count')}")
    add_result(section, "product.required_fields", "Product contract has complete required field template", len(product.get("required_contract_fields", [])) >= 14, str(product.get("required_contract_fields", [])))
    add_result(section, "product.dimensions", "Every readiness dimension is template_ready", all(item.get("status") == "template_ready" for item in product.get("readiness_dimensions", [])), product.get("readiness_dimensions", []))
    sections.append(section)

    section = {"id": "docs", "title": "Schemas, Policies, and Docs", "tests": []}
    for path in EXPECTED_DOCS:
        add_result(section, f"doc.{path.name}", path.name, path.exists() and path.stat().st_size > 0, str(path))
        if path.suffix == ".json" and path.exists():
            add_result(section, f"doc_json.{path.name}", f"{path.name} parses as JSON", bool(load_json(path, None)), str(path))
    sections.append(section)

    section = {"id": "cli", "title": "PIG CLI Commands", "tests": []}
    cli_payloads: dict[str, Any] = {}
    for command_name in ["capability-registry", "capability-telemetry", "agentization-gate", "agent-product-contract"]:
        command = run_command([sys.executable, "scripts/project_intelligence_graph/pig.py", command_name, "--json"], cwd=ROOT, timeout=90)
        command_result(section, f"cli.{command_name}", command_name, command)
        payload = json.loads(command["stdout"]) if command.get("returncode") == 0 and command.get("stdout", "").strip().startswith("{") else {}
        cli_payloads[command_name] = payload
        add_result(section, f"cli_status.{command_name}", f"{command_name} JSON status PASS", payload.get("status") == "PASS", str(payload.get("status", "UNKNOWN")))
    sections.append(section)

    section = {"id": "source_registry", "title": "Source Registry Integration", "tests": []}
    source_cmd = run_command([sys.executable, "scripts/project_intelligence_graph/pig.py", "source-registry", "--json"], cwd=ROOT, timeout=120)
    command_result(section, "source.command", "source-registry command", source_cmd)
    source_audit = json.loads(source_cmd["stdout"]) if source_cmd.get("returncode") == 0 and source_cmd.get("stdout", "").strip().startswith("{") else {}
    add_result(section, "source.audit", "Source registry audit is PASS", source_audit.get("status") == "PASS", str(source_audit.get("status", "UNKNOWN")))
    source_registry = load_json(OUTPUT_DIR / "source_registry.json", {})
    source_ids = {record.get("source_id") for record in source_registry.get("records", []) if isinstance(record, dict)}
    add_result(section, "source.expected_ids", "Capability governance sources are registered", EXPECTED_SOURCE_IDS.issubset(source_ids), f"missing={sorted(EXPECTED_SOURCE_IDS - source_ids)}")
    add_result(section, "source.no_fail", "Source registry fail_count is zero", source_audit.get("fail_count", 0) == 0, str(source_audit.get("fail_count", 0)))
    sections.append(section)

    section = {"id": "operator_surface", "title": "PIG Operator Surface", "tests": []}
    scan_cmd = run_command([sys.executable, "scripts/project_intelligence_graph/scan_project_intelligence_graph.py"], cwd=ROOT, timeout=180, capture=False)
    command_result(section, "surface.scan", "scan refreshes contract-quality evidence", scan_cmd)
    surface_cmd = run_command([sys.executable, "scripts/project_intelligence_graph/pig.py", "operator-surface", "--json"], cwd=ROOT, timeout=120, capture=False)
    command_result(section, "surface.command", "operator-surface command", surface_cmd)
    surface = load_json(OUTPUT_DIR / "quality_os_operator_surface.json", {})
    propagation = surface.get("systemwide_rule_propagation", {}) if isinstance(surface, dict) else {}
    governance = surface.get("governance", {}) if isinstance(surface, dict) else {}
    controls = surface.get("control_capabilities", {}) if isinstance(surface, dict) else {}
    add_result(section, "surface.status", "Operator surface status PASS", surface.get("status") == "PASS", str(surface.get("status", "UNKNOWN")))
    for key in ["capability_registry", "capability_telemetry", "agentization_decision_gate", "agent_product_maturity_contract", "shannon_security_sandbox_contract", "fresh_session_context_budget", "background_quality_gates"]:
        add_result(section, f"surface.{key}", f"Surface contains {key}", isinstance(propagation.get(key), dict), propagation.get(key, {}))
        add_result(section, f"surface_control.{key}", f"Control flag for {key} is true", controls.get(key) is True, str(controls.get(key)))
    add_result(section, "surface.governance_agentization", "Governance exposes zero approved agents", governance.get("agentization_approved_agent_count") == 0, governance.get("agentization_approved_agent_count"))
    add_result(section, "surface.governance_product", "Governance exposes zero product-ready agents", governance.get("agent_product_ready_count") == 0, governance.get("agent_product_ready_count"))
    sections.append(section)

    section = {"id": "lion", "title": "LION Surface and Types", "tests": []}
    if skip_lion:
        add_result(section, "lion.skipped", "LION tests skipped by flag", True, "--skip-lion")
    elif not LIONCOM_DIR.exists():
        add_result(section, "lion.exists", "LIONCOM directory exists", False, str(LIONCOM_DIR))
    else:
        verify_cmd = run_command(["node", "scripts/verify_planning_quality_surface.mjs"], cwd=LIONCOM_DIR, timeout=180)
        command_result(section, "lion.verify", "LION planning-quality verifier", verify_cmd)
        tsc_cmd = run_command(["npx", "tsc", "--noEmit", "--pretty", "false"], cwd=LIONCOM_DIR, timeout=240)
        command_result(section, "lion.tsc", "TypeScript noEmit", tsc_cmd)
        ui_text = (LIONCOM_DIR / "components" / "portfolio-control-tower-page.tsx").read_text(encoding="utf-8") if (LIONCOM_DIR / "components" / "portfolio-control-tower-page.tsx").exists() else ""
        type_text = (LIONCOM_DIR / "lib" / "types.ts").read_text(encoding="utf-8") if (LIONCOM_DIR / "lib" / "types.ts").exists() else ""
        verifier_text = (LIONCOM_DIR / "scripts" / "verify_planning_quality_surface.mjs").read_text(encoding="utf-8") if (LIONCOM_DIR / "scripts" / "verify_planning_quality_surface.mjs").exists() else ""
        add_result(section, "lion.ui_product", "Portfolio UI shows Product Contract", "Product Contract" in ui_text or "Agent Product Contract" in ui_text, "portfolio-control-tower-page.tsx")
        add_result(section, "lion.ui_telemetry", "Portfolio UI shows Capability Telemetry", "Capability Telemetry" in ui_text or "Telemetry" in ui_text, "portfolio-control-tower-page.tsx")
        add_result(section, "lion.type_product", "Type surface includes product contract", "agent_product_maturity_contract" in type_text, "lib/types.ts")
        add_result(section, "lion.verifier_product", "Verifier checks product contract", "Agent Product Contract" in verifier_text, "verify_planning_quality_surface.mjs")
    sections.append(section)

    section = {"id": "vault_memory", "title": "Vault Memory Anchors", "tests": []}
    latest = (VAULT_DIR / "Latest Session Context.md").read_text(encoding="utf-8") if (VAULT_DIR / "Latest Session Context.md").exists() else ""
    start = (VAULT_DIR / "VEGA_START_HERE.md").read_text(encoding="utf-8") if (VAULT_DIR / "VEGA_START_HERE.md").exists() else ""
    pig_system = (VAULT_DIR / "Canonical" / "Systems" / "System - Project Intelligence Graph.md").read_text(encoding="utf-8") if (VAULT_DIR / "Canonical" / "Systems" / "System - Project Intelligence Graph.md").exists() else ""
    roadmap = (VAULT_DIR / "DreamFactory System" / "Agent Stack" / "Agent Capability Naming Roadmap - 2026-05-28.md").read_text(encoding="utf-8") if (VAULT_DIR / "DreamFactory System" / "Agent Stack" / "Agent Capability Naming Roadmap - 2026-05-28.md").exists() else ""
    add_result(section, "vault.latest", "Latest Session mentions Blocks 8-10", "Agent Capability Blocks 8-10 gebaut" in latest, "Latest Session Context.md")
    add_result(section, "vault.start_agentization", "VEGA_START_HERE links Agentization Gate", "Rule - Agentization Decision Gate" in start, "VEGA_START_HERE.md")
    add_result(section, "vault.start_product", "VEGA_START_HERE links Product Contract", "Rule - Agent Product Maturity Contract" in start, "VEGA_START_HERE.md")
    add_result(section, "vault.pig_system", "PIG system note has capability governance section", "Capability Governance und Agenten-Gates" in pig_system, "System - Project Intelligence Graph.md")
    add_result(section, "vault.roadmap_status", "Roadmap records completed implementation status", "Umsetzungsstand 2026-05-28" in roadmap and "completed_verified" in roadmap, "Agent Capability Naming Roadmap")
    sections.append(section)

    section = {"id": "regression", "title": "Worker Retention Regression Guard", "tests": []}
    pig_source = (PIG_DIR / "pig.py").read_text(encoding="utf-8")
    add_result(section, "regression.source_retained_matches", "Retention uses matching completions", "retained_matches" in pig_source, "pig.py")
    add_result(section, "regression.no_stale_fallback", "Retention does not fallback to arbitrary completed card", "retained_matches[0] if retained_matches else" not in pig_source, "pig.py")
    add_result(section, "regression.closed_no_match", "No matching workflow path is explicit", "matching_completed_worker_run=False" in pig_source, "pig.py")
    worker_cmd = run_command([sys.executable, "scripts/project_intelligence_graph/pig.py", "vivi-worker", "--json"], cwd=ROOT, timeout=120, capture=False)
    command_result(section, "regression.worker", "vivi-worker command", worker_cmd)
    supervisor_cmd = run_command([sys.executable, "scripts/project_intelligence_graph/pig.py", "vivi-worker-supervisor", "--json"], cwd=ROOT, timeout=120)
    command_result(section, "regression.supervisor_command", "vivi-worker-supervisor command", supervisor_cmd)
    supervisor = json.loads(supervisor_cmd["stdout"]) if supervisor_cmd.get("returncode") == 0 and supervisor_cmd.get("stdout", "").strip().startswith("{") else {}
    add_result(section, "regression.supervisor_status", "Supervisor audit is PASS", supervisor.get("status") == "PASS", supervisor)
    supported_claim = (
        supervisor.get("mode") == "local_artifact_worker_mvp"
        and supervisor.get("claim_type") in {"refresh_operator_surface_evidence", ""}
    ) or (
        supervisor.get("mode") == "safe_project_worker_v2"
        and supervisor.get("claim_type") in {"run_project_verifier", "generated_artifact_review", ""}
    )
    add_result(section, "regression.supervisor_claim", "Supervisor accepts only mode-supported claim types", supported_claim, {"mode": supervisor.get("mode"), "claim_type": supervisor.get("claim_type")})
    sections.append(section)

    section = {"id": "core_verifiers", "title": "Core Verifiers", "tests": []}
    py_compile = run_command([sys.executable, "-m", "py_compile", "scripts/project_intelligence_graph/capability_registry.py", "scripts/project_intelligence_graph/pig.py", "scripts/project_intelligence_graph/capability_governance_separate_test.py"], cwd=ROOT, timeout=90)
    command_result(section, "core.py_compile", "py_compile", py_compile)
    unit = run_command([sys.executable, "-m", "unittest", "tests.project_intelligence_graph.test_services_render_cli"], cwd=ROOT, timeout=120)
    command_result(section, "core.unit", "PIG services/render/CLI unit suite", unit)
    german = run_command([sys.executable, "scripts/project_intelligence_graph/pig.py", "german-output-quality", "--json"], cwd=ROOT, timeout=120, capture=False)
    command_result(section, "core.german_command", "German output quality command", german)
    german_payload = load_json(OUTPUT_DIR / "german_output_quality_gate.json", {})
    add_result(section, "core.german_status", "German output quality PASS with zero fail count", german_payload.get("status") == "PASS" and german_payload.get("fail_count", 0) == 0, german_payload)
    fresh_cmd = run_command([sys.executable, "scripts/project_intelligence_graph/pig.py", "fresh-session-readiness", "--json"], cwd=ROOT, timeout=120, capture=False)
    command_result(section, "core.fresh_command", "Fresh session readiness command", fresh_cmd)
    fresh_payload = load_json(OUTPUT_DIR / "fresh_session_readiness_audit.json", {})
    add_result(section, "core.fresh_status", "Fresh session readiness PASS", fresh_payload.get("status") == "PASS", fresh_payload)
    sections.append(section)

    if not skip_full_check:
        section = {"id": "full_check", "title": "Umbrella Full Check", "tests": []}
        full = run_command([sys.executable, "scripts/project_intelligence_graph/pig.py", "full-check", "--json"], cwd=ROOT, timeout=360, capture=False)
        command_result(section, "full.command", "full-check command", full)
        full_payload = load_json(OUTPUT_DIR / "full_check_report.json", {})
        failed_steps = [item.get("name") for item in full_payload.get("steps", []) if isinstance(item, dict) and item.get("status") != "PASS"]
        add_result(section, "full.status", "Full check status PASS", full_payload.get("status") == "PASS", str(full_payload.get("status", "UNKNOWN")))
        add_result(section, "full.failed_steps", "No failed full-check steps", not failed_steps, f"failed={failed_steps}")
        add_result(section, "full.step_count", "Full check covers at least 160 steps", len(full_payload.get("steps", [])) >= 160, str(len(full_payload.get("steps", []))))
        for step_name in ["capability_registry", "capability_telemetry", "agentization_decision_gate", "agent_product_maturity_contract", "vivi_worker_supervisor_audit"]:
            step = next((item for item in full_payload.get("steps", []) if isinstance(item, dict) and item.get("name") == step_name), {})
            add_result(section, f"full.step.{step_name}", f"Full check step {step_name} PASS", step.get("status") == "PASS", step)
        sections.append(section)

    artifacts.update({
        "capability_registry_record_count": len(records),
        "capability_telemetry_usage_total": telemetry.get("usage_total", 0),
        "capability_telemetry_risk_blocked_total": telemetry.get("risk_blocked_total", 0),
        "agentization_candidate_agent_count": agentization.get("candidate_agent_count", 0),
        "agentization_approved_agent_count": agentization.get("approved_agent_count", 0),
        "agent_product_contract_mode": product.get("mode", ""),
        "agent_product_ready_count": product.get("product_contract_ready_count", 0),
    })
    return sections, artifacts


def build_report(*, skip_full_check: bool = False, skip_lion: bool = False) -> dict[str, Any]:
    sections, artifacts = build_sections(skip_full_check=skip_full_check, skip_lion=skip_lion)
    report = build_acceptance_report(
        title="Capability Governance Separate Test Report",
        sections=sections,
        artifacts=artifacts,
        report_json_path=REPORT_JSON,
        report_md_path=REPORT_MD,
    )
    write_acceptance_report(report, report_json_path=REPORT_JSON, report_md_path=REPORT_MD)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Run separate capability governance acceptance tests.")
    parser.add_argument("--json", action="store_true", help="Print the full JSON report.")
    parser.add_argument("--skip-full-check", action="store_true", help="Skip the slow full-check umbrella run.")
    parser.add_argument("--skip-lion", action="store_true", help="Skip LION verifier and TypeScript checks.")
    args = parser.parse_args()
    report = build_report(skip_full_check=args.skip_full_check, skip_lion=args.skip_lion)
    if args.json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        summary = report["summary"]
        print(f"{report['status']} capability governance separate tests")
        print(f"tests={summary['total']} pass={summary['pass']} fail={summary['fail']}")
        print(f"markdown={REPORT_MD}")
        print(f"json={REPORT_JSON}")
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
