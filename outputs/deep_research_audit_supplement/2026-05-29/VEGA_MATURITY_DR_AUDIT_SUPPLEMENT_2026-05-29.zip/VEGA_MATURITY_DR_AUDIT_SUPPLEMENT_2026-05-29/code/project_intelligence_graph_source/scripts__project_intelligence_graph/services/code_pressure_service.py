"""Code-pressure service wrapper."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable

from code_pressure import build_code_pressure_report_payload


def build_code_pressure(
    *,
    workspace: Path,
    output_dir: Path,
    quality_os_surface_path: Path,
    source_registry_path: Path,
    code_pressure_report_path: Path,
    write_json: Callable[[Path, Any], None],
    render_markdown: Callable[[str, dict[str, Any]], str],
    safe_rel: Callable[[Path], str],
    write: bool = False,
) -> dict[str, Any]:
    return build_code_pressure_report_payload(
        workspace=workspace,
        output_dir=output_dir,
        quality_os_surface_path=quality_os_surface_path,
        source_registry_path=source_registry_path,
        code_pressure_report_path=code_pressure_report_path,
        write=write,
        write_json=write_json,
        render_markdown=render_markdown,
        safe_rel=safe_rel,
    )
