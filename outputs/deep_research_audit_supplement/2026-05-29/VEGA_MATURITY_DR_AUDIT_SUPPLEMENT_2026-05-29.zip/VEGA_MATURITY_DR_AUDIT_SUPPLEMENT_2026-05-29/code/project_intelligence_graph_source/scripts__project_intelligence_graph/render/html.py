"""Small HTML rendering helpers for local report previews."""

from __future__ import annotations

import html


def render_preformatted_html(title: str, body: str) -> str:
    return f"<!doctype html><meta charset='utf-8'><title>{html.escape(title)}</title><pre>{html.escape(body)}</pre>"
