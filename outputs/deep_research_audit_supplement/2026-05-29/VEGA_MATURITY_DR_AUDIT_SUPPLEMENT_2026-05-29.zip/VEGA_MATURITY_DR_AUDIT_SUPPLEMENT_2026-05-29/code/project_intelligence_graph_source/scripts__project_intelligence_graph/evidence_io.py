"""Strict evidence loading helpers for fail-closed verifier paths."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class MissingEvidenceError(RuntimeError):
    """Raised when required local evidence is missing or unreadable."""


MISSING = object()


def load_json_required(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise MissingEvidenceError(f"required evidence missing: {path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise MissingEvidenceError(f"invalid required evidence json: {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise MissingEvidenceError(f"required evidence is not a json object: {path}")
    return payload


def load_json_optional(path: Path) -> dict[str, Any] | object:
    if not path.exists():
        return MISSING
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise MissingEvidenceError(f"optional evidence is not a json object: {path}")
    return payload

