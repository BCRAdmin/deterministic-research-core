"""M11 one-app experience kernel for DreamFactory/PIG."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any, Callable

import m10_activation as m10
from maturity_kernel_v5_core import OUTPUT_DIR, check_rows, is_passish, load_json, now_iso, safe_rel, write_json


CURRENT_DIR = OUTPUT_DIR / "current"

FINAL_TRUTH = "m11_one_app_experience_operator_ux_local_only"
ROADMAP_TRUTH = m10.ROADMAP_TRUTH
PREVIOUS_TRUTH = m10.FINAL_TRUTH

RECOVERABLE_FULL_CHECK_SELF_REFERENCE_STEPS = set(getattr(m10, "RECOVERABLE_FULL_CHECK_SELF_REFERENCE_STEPS", set())) | set(
    "m11_one_cockpit_ux m11_decision_wizard m11_vivi_mission_console "
    "m11_rail_health_cards m11_bundle_builder_ui m11_read_only_audit "
    "m11_regression_suite m11_final_verification".split()
)

SYSTEM_TRUTH_PATH = CURRENT_DIR / "system_truth.json"
OPERATOR_COCKPIT_PATH = CURRENT_DIR / "operator_cockpit.md"
OPERATOR_DECISION_QUEUE_PATH = CURRENT_DIR / "operator_decision_queue.json"
NEXT_DECISION_BOARD_PATH = CURRENT_DIR / "next_operator_decision_board.json"
CURRENT_SURFACE_MANIFEST_PATH = CURRENT_DIR / "current_surface_manifest.json"
CURRENT_TRUTH_AUDIT_PATH = CURRENT_DIR / "current_truth_audit.json"
DOMAIN_SUMMARY_PATH = CURRENT_DIR / "domain_summary.json"
VERIFICATION_SUMMARY_PATH = CURRENT_DIR / "verification_summary.json"
WRITE_CONTRACT_PATH = CURRENT_DIR / "write_contract.json"
GRAND_ROADMAP_PATH = CURRENT_DIR / "grand_roadmap_m3r_to_m12.json"
OPERATOR_BRIEF_PATH = OUTPUT_DIR / "operator_brief.json"
OPERATOR_BRIEF_MD_PATH = OUTPUT_DIR / "operator_brief.md"

M11_ONE_COCKPIT_PATH = CURRENT_DIR / "m11_one_cockpit_ux.json"
M11_DECISION_WIZARD_PATH = CURRENT_DIR / "m11_decision_wizard.json"
M11_VIVI_CONSOLE_PATH = CURRENT_DIR / "m11_vivi_mission_console.json"
M11_RAIL_HEALTH_PATH = CURRENT_DIR / "m11_rail_health_cards.json"
M11_BUNDLE_UI_PATH = CURRENT_DIR / "m11_bundle_builder_ui.json"
M11_CURRENT_SURFACE_PATH = CURRENT_DIR / "m11_current_surface.json"
M11_READ_ONLY_AUDIT_PATH = CURRENT_DIR / "m11_read_only_audit.json"
M11_REGRESSION_SUITE_PATH = CURRENT_DIR / "m11_regression_suite.json"
M11_FINAL_VERIFICATION_PATH = CURRENT_DIR / "m11_final_verification.json"
M11_FINAL_STATE_PATH = CURRENT_DIR / "m11_final_state.json"
M11_REPLAY_INSTRUCTIONS_PATH = CURRENT_DIR / "m11_replay_instructions.md"

M11_BLOCK_PATHS = {
    "M11-01": CURRENT_DIR / "m11-01_one_cockpit_ux.json",
    "M11-02": CURRENT_DIR / "m11-02_decision_wizard.json",
    "M11-03": CURRENT_DIR / "m11-03_vivi_mission_console.json",
    "M11-04": CURRENT_DIR / "m11-04_rail_health_cards.json",
    "M11-05": CURRENT_DIR / "m11-05_bundle_builder_ui.json",
}

BUILDER_COMMANDS = [
    "grand-roadmap",
    "m11-one-cockpit-ux",
    "m11-decision-wizard",
    "m11-vivi-mission-console",
    "m11-rail-health-cards",
    "m11-bundle-builder-ui",
    "m11-current-surface",
    "m11-final-state",
]

AUDITOR_COMMANDS = ["m11-read-only-audit", "m11-regression-suite", "m11-final-verification"]

FORBIDDEN_FLAGS = [
    "runtime_action_executed",
    "external_action_executed",
    "publish_action_executed",
    "public_or_production_action_executed",
    "auth_or_payment_action_executed",
    "auth_or_credential_action_executed",
    "operator_go_token_write_executed",
    "github_write_sync_executed",
    "remote_bridge_activation_executed",
    "telegram_send_executed",
    "delete_executed",
    "push_executed",
    "deploy_executed",
    "room16_rerun_executed",
    "irreversible_action_executed",
]


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def _sha(path: Path) -> str:
    if not path.exists() or not path.is_file():
        return ""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _gate_payload() -> dict[str, bool]:
    return {
        "runtime_action_executed": False,
        "external_action_executed": False,
        "publish_action_executed": False,
        "public_or_production_action_executed": False,
        "auth_or_payment_action_executed": False,
        "auth_or_credential_action_executed": False,
        "operator_go_token_write_executed": False,
        "github_write_sync_executed": False,
        "remote_bridge_activation_executed": False,
        "telegram_send_executed": False,
        "delete_executed": False,
        "push_executed": False,
        "deploy_executed": False,
        "room16_rerun_executed": False,
        "irreversible_action_executed": False,
    }


def _write_json_md(path: Path, payload: dict[str, Any], title: str) -> None:
    write_json(path, payload)
    lines = [
        f"# {title}",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Final truth: `{payload.get('final_truth', FINAL_TRUTH)}`",
        "",
    ]
    for key in [
        "section_count",
        "step_count",
        "mission_panel_count",
        "rail_card_count",
        "profile_count",
        "decision_count",
        "unexpected_mutation_count",
        "fail_count",
    ]:
        if key in payload:
            lines.append(f"- {key}: `{payload[key]}`")
    if payload.get("checks"):
        lines += ["", "## Checks", ""]
        for check in payload["checks"]:
            lines.append(f"- `{check.get('status', 'UNKNOWN')}` {check.get('check', '')}: {check.get('detail', '')}")
    _write_text(path.with_suffix(".md"), "\n".join(lines))


def _mirror(path: Path, payload: dict[str, Any], block_id: str, title: str) -> None:
    mirror = M11_BLOCK_PATHS[block_id]
    write_json(mirror, payload)
    md = path.with_suffix(".md")
    _write_text(mirror.with_suffix(".md"), md.read_text(encoding="utf-8") if md.exists() else f"# {title}\n")


def _snapshot(paths: list[Path]) -> dict[str, dict[str, Any]]:
    rows: dict[str, dict[str, Any]] = {}
    for path in paths:
        if path.exists() and path.is_file():
            rows[safe_rel(path)] = {"mtime_ns": path.stat().st_mtime_ns, "bytes": path.stat().st_size, "sha256": _sha(path)}
    return rows


def _active_files() -> list[Path]:
    paths = [
        SYSTEM_TRUTH_PATH,
        OPERATOR_COCKPIT_PATH,
        OPERATOR_DECISION_QUEUE_PATH,
        NEXT_DECISION_BOARD_PATH,
        NEXT_DECISION_BOARD_PATH.with_suffix(".md"),
        CURRENT_SURFACE_MANIFEST_PATH,
        CURRENT_SURFACE_MANIFEST_PATH.with_suffix(".md"),
        CURRENT_TRUTH_AUDIT_PATH,
        CURRENT_TRUTH_AUDIT_PATH.with_suffix(".md"),
        DOMAIN_SUMMARY_PATH,
        DOMAIN_SUMMARY_PATH.with_suffix(".md"),
        VERIFICATION_SUMMARY_PATH,
        VERIFICATION_SUMMARY_PATH.with_suffix(".md"),
        WRITE_CONTRACT_PATH,
        WRITE_CONTRACT_PATH.with_suffix(".md"),
        GRAND_ROADMAP_PATH,
        GRAND_ROADMAP_PATH.with_suffix(".md"),
        OPERATOR_BRIEF_PATH,
        OPERATOR_BRIEF_MD_PATH,
        M11_ONE_COCKPIT_PATH,
        M11_DECISION_WIZARD_PATH,
        M11_VIVI_CONSOLE_PATH,
        M11_RAIL_HEALTH_PATH,
        M11_BUNDLE_UI_PATH,
        M11_CURRENT_SURFACE_PATH,
        M11_READ_ONLY_AUDIT_PATH,
        M11_REGRESSION_SUITE_PATH,
        M11_FINAL_VERIFICATION_PATH,
        M11_FINAL_STATE_PATH,
        M11_REPLAY_INSTRUCTIONS_PATH,
        *M11_BLOCK_PATHS.values(),
    ]
    return sorted(set([*paths, *[path.with_suffix(".md") for path in paths if path.suffix == ".json"]]))


def _forbidden_action_count(payloads: list[dict[str, Any]]) -> int:
    return sum(1 for payload in payloads for flag in FORBIDDEN_FLAGS if payload.get(flag) is True)


def build_one_cockpit_ux(*, write: bool = True) -> dict[str, Any]:
    sections = [
        {"id": "current_state", "source": "system_truth", "visible": True},
        {"id": "warnings", "source": "domain_summary", "visible": True},
        {"id": "decisions", "source": "next_operator_decision_board", "visible": True},
        {"id": "safe_next_actions", "source": "operator_brief", "visible": True},
        {"id": "vivi_missions", "source": "m11_vivi_mission_console", "visible": True},
        {"id": "bundle_status", "source": "m11_bundle_builder_ui", "visible": True},
    ]
    checks = [
        {"check": "five_minute_comprehension_sections", "status": "PASS" if len(sections) == 6 else "FAIL", "detail": str(len(sections))},
        {"check": "single_start_surface", "status": "PASS", "detail": safe_rel(OPERATOR_COCKPIT_PATH)},
        {"check": "runtime_action_not_executed", "status": "PASS", "detail": "false"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M11-01", "final_truth": FINAL_TRUTH, "section_count": len(sections), "target_comprehension_minutes": 5, "sections": sections, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M11_ONE_COCKPIT_PATH, payload, "M11 One Cockpit UX")
        _mirror(M11_ONE_COCKPIT_PATH, payload, "M11-01", "M11 One Cockpit UX")
    return payload


def build_decision_wizard(*, write: bool = True) -> dict[str, Any]:
    steps = [
        {"id": "batch_summary", "input": "decision board", "mutation": False},
        {"id": "risk", "input": "risk class and blocked gates", "mutation": False},
        {"id": "test_evidence", "input": "verifier summary and hashes", "mutation": False},
        {"id": "approve_defer_reject", "input": "operator selection", "mutation": False},
        {"id": "operator_go_token", "input": "explicit scoped go only", "mutation": "blocked_until_go"},
    ]
    checks = [
        {"check": "wizard_step_count", "status": "PASS" if len(steps) == 5 else "FAIL", "detail": str(len(steps))},
        {"check": "operator_go_token_not_written", "status": "PASS", "detail": "false"},
        {"check": "risky_actions_require_explicit_go", "status": "PASS", "detail": "approve step is local-only"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M11-02", "final_truth": FINAL_TRUTH, "step_count": len(steps), "steps": steps, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M11_DECISION_WIZARD_PATH, payload, "M11 Decision Wizard")
        _mirror(M11_DECISION_WIZARD_PATH, payload, "M11-02", "M11 Decision Wizard")
    return payload


def build_vivi_mission_console(*, write: bool = True) -> dict[str, Any]:
    m6 = load_json(CURRENT_DIR / "m6_mission_card_v4.json", default={})
    cards = m6.get("mission_cards", []) or m6.get("cards", [])
    panels = [
        {"id": "ready_cards", "source": "mission_card_v4", "status": "local_only"},
        {"id": "claimed_card", "source": "claim_lease_ledger", "status": "no_active_lease"},
        {"id": "evidence_delta", "source": "mission outputs", "status": "hash_required"},
        {"id": "supervisor_verdict", "source": "m6_supervisor_eval", "status": "required"},
        {"id": "stop_retry_approve", "source": "operator action", "status": "operator_gated"},
    ]
    checks = [
        {"check": "mission_panel_count", "status": "PASS" if len(panels) == 5 else "FAIL", "detail": str(len(panels))},
        {"check": "runtime_worker_not_started", "status": "PASS", "detail": "false"},
        {"check": "active_lease_not_required", "status": "PASS", "detail": "console view only"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M11-03", "final_truth": FINAL_TRUTH, "mission_panel_count": len(panels), "source_mission_card_count": len(cards), "panels": panels, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M11_VIVI_CONSOLE_PATH, payload, "M11 Vivi Mission Console")
        _mirror(M11_VIVI_CONSOLE_PATH, payload, "M11-03", "M11 Vivi Mission Console")
    return payload


def build_rail_health_cards(*, write: bool = True) -> dict[str, Any]:
    rails = [
        {"id": "lioncom", "status": "local_verified_operator_gated", "gate": "bridge/runtime activation", "proof": "m7_lioncom_operator_os"},
        {"id": "room16", "status": "local_verified_operator_gated", "gate": "rerun/publish/financial advice", "proof": "room16_qualitydecision"},
        {"id": "kanzlei_ai_assist", "status": "synthetic_local_verified", "gate": "real client data/DATEV/auth", "proof": "kanzlei_synthetic_factory"},
        {"id": "quellwert_utility_membership", "status": "data_maturity_warn_operator_gated", "gate": "public/payment/auth/external analytics", "proof": "quellwert_data_maturity"},
    ]
    checks = [
        {"check": "rail_card_count", "status": "PASS" if len(rails) == 4 else "FAIL", "detail": str(len(rails))},
        {"check": "all_rails_have_gate", "status": "PASS" if all(item.get("gate") for item in rails) else "FAIL", "detail": "required"},
        {"check": "no_rail_activation", "status": "PASS", "detail": "all local-only"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M11-04", "final_truth": FINAL_TRUTH, "rail_card_count": len(rails), "rails": rails, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M11_RAIL_HEALTH_PATH, payload, "M11 Rail Health Cards")
        _mirror(M11_RAIL_HEALTH_PATH, payload, "M11-04", "M11 Rail Health Cards")
    return payload


def build_bundle_builder_ui(*, write: bool = True) -> dict[str, Any]:
    profiles = [
        {"id": "minimal_shareable", "state": "lint_required", "warning": "not external approval"},
        {"id": "local_code_review", "state": "local_only_do_not_forward", "warning": "may contain local paths or code context"},
        {"id": "local_internal_full", "state": "operator_only", "warning": "not shareable"},
    ]
    controls = ["profile chooser", "lint result", "post-pack hash", "sharing warning", "no local-only leakage scan"]
    checks = [
        {"check": "profile_count", "status": "PASS" if len(profiles) == 3 else "FAIL", "detail": str(len(profiles))},
        {"check": "control_count", "status": "PASS" if len(controls) == 5 else "FAIL", "detail": str(len(controls))},
        {"check": "external_share_not_executed", "status": "PASS", "detail": "false"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M11-05", "final_truth": FINAL_TRUTH, "profile_count": len(profiles), "profiles": profiles, "controls": controls, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M11_BUNDLE_UI_PATH, payload, "M11 Bundle Builder UI")
        _mirror(M11_BUNDLE_UI_PATH, payload, "M11-05", "M11 Bundle Builder UI")
    return payload


def build_write_contract(*, write: bool = True) -> dict[str, Any]:
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "block_id": "M11-WRITE-CONTRACT", "final_truth": FINAL_TRUTH, "single_writer": "m11_one_app.py", "allowed_outputs": [safe_rel(path) for path in _active_files()], "auditor_commands": AUDITOR_COMMANDS, "builder_commands": BUILDER_COMMANDS, "forbidden_actions": FORBIDDEN_FLAGS, "fail_count": 0, **_gate_payload()}
    if write:
        _write_json_md(WRITE_CONTRACT_PATH, payload, "M11 Write Contract")
    return payload


def build_domain_summary(*, write: bool = True) -> dict[str, Any]:
    cockpit = build_one_cockpit_ux(write=False)
    wizard = build_decision_wizard(write=False)
    console = build_vivi_mission_console(write=False)
    rails = build_rail_health_cards(write=False)
    bundle = build_bundle_builder_ui(write=False)
    domains = [
        {"domain": "one_cockpit_ux", "status": cockpit.get("status", "UNKNOWN"), "summary": f"{cockpit.get('section_count', 0)} sections"},
        {"domain": "decision_wizard", "status": wizard.get("status", "UNKNOWN"), "summary": f"{wizard.get('step_count', 0)} steps"},
        {"domain": "vivi_mission_console", "status": console.get("status", "UNKNOWN"), "summary": f"{console.get('mission_panel_count', 0)} panels"},
        {"domain": "rail_health_cards", "status": rails.get("status", "UNKNOWN"), "summary": f"{rails.get('rail_card_count', 0)} rails"},
        {"domain": "bundle_builder_ui", "status": bundle.get("status", "UNKNOWN"), "summary": f"{bundle.get('profile_count', 0)} profiles"},
    ]
    fail_count = sum(1 for item in domains if item["status"] == "FAIL")
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": "FAIL" if fail_count else "PASS_WITH_WARNINGS", "block_id": "M11-DOMAIN-SUMMARY", "final_truth": FINAL_TRUTH, "current_owner": "M11", "domains": domains, "fail_count": fail_count, "warning_reason": "M11 is a local operator UX surface; no runtime app mutation or external release is executed.", **_gate_payload()}
    if write:
        _write_json_md(DOMAIN_SUMMARY_PATH, payload, "M11 Domain Summary")
    return payload


def build_current_surface(*, write: bool = True) -> dict[str, Any]:
    domain = build_domain_summary(write=False)
    decisions = [
        {"id": "m11-one-cockpit-ux", "risk": "R2_OPERATOR_CLARITY", "action": "use single start surface"},
        {"id": "m11-decision-wizard", "risk": "R3_OPERATOR_GO", "action": "show approval path without writing go token"},
        {"id": "m11-vivi-mission-console", "risk": "R3_AUTONOMY", "action": "show Vivi mission state without runtime start"},
        {"id": "m11-rail-health-cards", "risk": "R3_PRODUCT_RAILS", "action": "show local rail health and gates"},
        {"id": "m11-bundle-builder-ui", "risk": "R3_SHARING", "action": "choose bundle profile with warnings"},
        {"id": "m11-continue-m12-rc-decision", "risk": "R2_RELEASE_CANDIDATE", "action": "next local RC decision block"},
    ]
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": "PASS" if domain.get("fail_count", 0) == 0 else "FAIL", "block_id": "M11-CURRENT-SURFACE", "final_truth": FINAL_TRUTH, "current_owner": "M11", "decision_count": len(decisions), "decisions": decisions, "fail_count": domain.get("fail_count", 0), **_gate_payload()}
    if write:
        _write_json_md(M11_CURRENT_SURFACE_PATH, payload, "M11 Current Surface")
        write_json(OPERATOR_DECISION_QUEUE_PATH, {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "current_owner": "M11", "decisions": decisions, **_gate_payload()})
        write_json(NEXT_DECISION_BOARD_PATH, {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "decisions": decisions, **_gate_payload()})
        lines = ["# M11 Decision Board", "", "- Status: `PASS`", "- One-App-Erfahrung ist lokal als Operator-UX-Surface materialisiert.", "", "| ID | Risk | Action |", "|---|---|---|"]
        for item in decisions:
            lines.append(f"| `{item['id']}` | `{item['risk']}` | `{item['action']}` |")
        _write_text(NEXT_DECISION_BOARD_PATH.with_suffix(".md"), "\n".join(lines))
        cockpit_lines = [
            "# M11 Operator Cockpit",
            "",
            f"- Truth: `{FINAL_TRUTH}`",
            "- Zustand: DreamFactory One App Experience ist lokal als schlanke Operator-UX-Surface materialisiert.",
            "- Keine Runtime-App, kein Public Launch, kein Auth, kein Payment, kein Push und keine externe Kommunikation wurden aktiviert.",
            "",
            "## In fünf Minuten verstehen",
            "",
            "- Current State, Warnungen, Entscheidungen, sichere nächste Aktionen, Vivi-Missionen und Bundle-Status liegen in einer Startfläche.",
            "",
            "## UX-Flächen",
        ]
        for item in decisions[:5]:
            cockpit_lines.append(f"- `{item['id']}`: {item['action']}.")
        cockpit_lines += ["", "## Nächste sichere Aktion", "", "- M11-Verifikation lesen; danach M12 Release Candidate Decision lokal bauen.", "", "## Geschlossene Gates", "", "- Runtime-App-Mutation, Operator-Go-Token, Push/Delete/Deploy/Publish/Public/Production/Payment/Auth/externe Kommunikation/Redistribution bleiben geschlossen."]
        _write_text(OPERATOR_COCKPIT_PATH, "\n".join(cockpit_lines))
    return payload


def build_grand_roadmap(*, write: bool = True) -> dict[str, Any]:
    roadmap = load_json(GRAND_ROADMAP_PATH, default={}) or m10.build_grand_roadmap(write=False)
    roadmap.update({"schema_version": max(int(roadmap.get("schema_version", 8)), 9), "generated_at": now_iso(), "status": "PASS", "truth_state": ROADMAP_TRUTH, "active_current_truth": FINAL_TRUTH, "active_phase": "M11", "m11_status": "PASS_WITH_WARNINGS", "m12_next": "release_candidate_decision_local_reversible", "runtime_action_executed": False, "external_action_executed": False})
    lines = ["# Grand Roadmap M3R to M12", "", "- Status: `PASS`", f"- Active current truth: `{FINAL_TRUTH}`", "- M11 materialisiert DreamFactory One App Experience; M12 ist der nächste lokale Block.", "", "| Phase | Title | Blocks |", "|---|---|---:|"]
    for phase in roadmap.get("phases", []):
        lines.append(f"| `{phase.get('id')}` | {phase.get('title')} | {len(phase.get('blocks', []))} |")
    if write:
        write_json(GRAND_ROADMAP_PATH, roadmap)
        _write_text(GRAND_ROADMAP_PATH.with_suffix(".md"), "\n".join(lines))
    return roadmap


def build_current_manifest(*, write: bool = True) -> dict[str, Any]:
    files = [{"path": safe_rel(path), "exists": path.exists(), "sha256": _sha(path), "bytes": path.stat().st_size if path.exists() else 0} for path in _active_files()]
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "block_id": "M11-CURRENT-MANIFEST", "final_truth": FINAL_TRUTH, "current_owner": "M11", "file_count": len(files), "files": files, "fail_count": 0, **_gate_payload()}
    if write:
        _write_json_md(CURRENT_SURFACE_MANIFEST_PATH, payload, "M11 Current Surface Manifest")
        write_json(CURRENT_TRUTH_AUDIT_PATH, payload)
        _write_text(CURRENT_TRUTH_AUDIT_PATH.with_suffix(".md"), "# M11 Current Truth Audit\n\n- Status: `PASS`\n- Current owner: `M11`\n")
    return payload


def build_read_only_audit(*, write: bool = True) -> dict[str, Any]:
    before = _snapshot(_active_files())
    build_regression_suite(write=False)
    build_domain_summary(write=False)
    build_current_surface(write=False)
    after = _snapshot(_active_files())
    changed = sorted(path for path, meta in before.items() if after.get(path) != meta)
    checks = [{"check": "unexpected_mutation_count", "status": "PASS" if not changed else "FAIL", "detail": str(len(changed))}, {"check": "auditors_write_false", "status": "PASS", "detail": "regression/domain/current surface read only"}]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M11-READ-ONLY-AUDIT", "final_truth": FINAL_TRUTH, "unexpected_mutation_count": len(changed), "changed_files": changed, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M11_READ_ONLY_AUDIT_PATH, payload, "M11 Read-only Audit")
    return payload


def build_regression_suite(*, write: bool = True) -> dict[str, Any]:
    cockpit = build_one_cockpit_ux(write=False)
    wizard = build_decision_wizard(write=False)
    console = build_vivi_mission_console(write=False)
    rails = build_rail_health_cards(write=False)
    bundle = build_bundle_builder_ui(write=False)
    payloads = [cockpit, wizard, console, rails, bundle]
    checks = [
        {"check": "one_cockpit_ux_pass", "status": cockpit.get("status", "FAIL"), "detail": str(cockpit.get("fail_count", 0))},
        {"check": "decision_wizard_pass", "status": wizard.get("status", "FAIL"), "detail": str(wizard.get("fail_count", 0))},
        {"check": "vivi_mission_console_pass", "status": console.get("status", "FAIL"), "detail": str(console.get("fail_count", 0))},
        {"check": "rail_health_cards_pass", "status": rails.get("status", "FAIL"), "detail": str(rails.get("fail_count", 0))},
        {"check": "bundle_builder_ui_pass", "status": bundle.get("status", "FAIL"), "detail": str(bundle.get("fail_count", 0))},
        {"check": "forbidden_action_count", "status": "PASS" if _forbidden_action_count(payloads) == 0 else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M11-REGRESSION-SUITE", "final_truth": FINAL_TRUTH, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M11_REGRESSION_SUITE_PATH, payload, "M11 Regression Suite")
    return payload


def build_final_verification(*, write: bool = True) -> dict[str, Any]:
    cockpit = build_one_cockpit_ux(write=False)
    wizard = build_decision_wizard(write=False)
    console = build_vivi_mission_console(write=False)
    rails = build_rail_health_cards(write=False)
    bundle = build_bundle_builder_ui(write=False)
    contract = build_write_contract(write=False)
    domain = build_domain_summary(write=False)
    surface = build_current_surface(write=False)
    read_only = build_read_only_audit(write=False)
    regression = build_regression_suite(write=False)
    payloads = [cockpit, wizard, console, rails, bundle, contract, domain, surface, read_only, regression]
    checks = [
        {"check": "final_truth_consistency", "status": "PASS", "detail": FINAL_TRUTH},
        {"check": "one_cockpit_ux", "status": cockpit.get("status", "FAIL"), "detail": str(cockpit.get("fail_count", 0))},
        {"check": "decision_wizard", "status": wizard.get("status", "FAIL"), "detail": str(wizard.get("fail_count", 0))},
        {"check": "vivi_mission_console", "status": console.get("status", "FAIL"), "detail": str(console.get("fail_count", 0))},
        {"check": "rail_health_cards", "status": rails.get("status", "FAIL"), "detail": str(rails.get("fail_count", 0))},
        {"check": "bundle_builder_ui", "status": bundle.get("status", "FAIL"), "detail": str(bundle.get("fail_count", 0))},
        {"check": "write_contract", "status": contract.get("status", "FAIL"), "detail": str(contract.get("fail_count", 0))},
        {"check": "domain_summary", "status": "PASS" if domain.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "FAIL", "detail": domain.get("status", "")},
        {"check": "current_surface", "status": surface.get("status", "FAIL"), "detail": str(surface.get("fail_count", 0))},
        {"check": "read_only_audit", "status": read_only.get("status", "FAIL"), "detail": str(read_only.get("unexpected_mutation_count", 0))},
        {"check": "regression_suite", "status": regression.get("status", "FAIL"), "detail": str(regression.get("fail_count", 0))},
        {"check": "forbidden_action_count", "status": "PASS" if _forbidden_action_count(payloads) == 0 else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M11_FINAL_VERIFICATION_PATH, payload, "M11 Final Verification")
        _write_json_md(VERIFICATION_SUMMARY_PATH, payload, "M11 Verification Summary")
    return payload


def build_final_state(*, write: bool = True) -> dict[str, Any]:
    if not write:
        return load_json(M11_FINAL_STATE_PATH, default={})
    build_grand_roadmap(write=True)
    cockpit = build_one_cockpit_ux(write=True)
    wizard = build_decision_wizard(write=True)
    console = build_vivi_mission_console(write=True)
    rails = build_rail_health_cards(write=True)
    bundle = build_bundle_builder_ui(write=True)
    build_write_contract(write=True)
    build_domain_summary(write=True)
    build_current_surface(write=True)
    build_current_manifest(write=True)
    build_read_only_audit(write=True)
    build_regression_suite(write=True)
    verification = build_final_verification(write=True)
    _write_text(M11_REPLAY_INSTRUCTIONS_PATH, "# M11 Replay Instructions\n\n```bash\npython3 scripts/project_intelligence_graph/pig.py m11-final-state --json\npython3 scripts/project_intelligence_graph/pig.py m11-read-only-audit --json\npython3 scripts/project_intelligence_graph/pig.py m11-regression-suite --json\npython3 scripts/project_intelligence_graph/pig.py full-check --json\n```\n\nM11 ist ein lokaler Operator-UX-Kernel. Keine Runtime-App-Mutation oder externe Veröffentlichung wurde ausgeführt.")
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": "PASS_WITH_WARNINGS" if verification.get("status") == "PASS" else "FAIL", "final_truth": FINAL_TRUTH, "roadmap_truth": ROADMAP_TRUTH, "current_owner": "M11", "previous_truth": PREVIOUS_TRUTH, "m11_blocks_completed": 5, "m12_next": "release_candidate_decision_local_reversible", "one_cockpit_ux": safe_rel(M11_ONE_COCKPIT_PATH), "decision_wizard": safe_rel(M11_DECISION_WIZARD_PATH), "vivi_mission_console": safe_rel(M11_VIVI_CONSOLE_PATH), "rail_health_cards": safe_rel(M11_RAIL_HEALTH_PATH), "bundle_builder_ui": safe_rel(M11_BUNDLE_UI_PATH), "section_count": cockpit.get("section_count", 0), "wizard_step_count": wizard.get("step_count", 0), "mission_panel_count": console.get("mission_panel_count", 0), "rail_card_count": rails.get("rail_card_count", 0), "profile_count": bundle.get("profile_count", 0), "decision_count": build_current_surface(write=False).get("decision_count", 0), "checks": verification.get("checks", []), "fail_count": verification.get("fail_count", 1), **_gate_payload()}
    write_json(SYSTEM_TRUTH_PATH, payload)
    _write_json_md(M11_FINAL_STATE_PATH, payload, "M11 Final State")
    build_current_manifest(write=True)
    build_operator_brief(write=True)
    return payload


def _operator_brief_md(payload: dict[str, Any]) -> str:
    lines = ["# Project Intelligence Graph Operator Brief", "", f"- Generated: `{payload.get('generated_at', '')}`", f"- Overall: `{payload.get('overall_status', 'UNKNOWN')}`", f"- Build: `{payload.get('build_status', 'UNKNOWN')}`", f"- Decisions: `{payload.get('decision_status', 'UNKNOWN')}`", "", "## Do This Now", ""]
    for item in payload.get("do_this_now", []):
        lines.append(f"- `{item.get('priority', '-')}` {item.get('text', '')}")
    lines.extend(["", "## Do Not", ""])
    for item in payload.get("do_not", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Safe Commands", ""])
    for command in payload.get("safe_commands", []):
        lines.append(f"- `{command}`")
    lines.extend(["", "## Status Lines", ""])
    for key, value in payload.get("status_lines", {}).items():
        lines.append(f"- `{key}`: `{value}`")
    return "\n".join(lines) + "\n"


def build_operator_brief(*, write: bool = True) -> dict[str, Any]:
    final_state = load_json(M11_FINAL_STATE_PATH, default={})
    verification = load_json(M11_FINAL_VERIFICATION_PATH, default={})
    payload = {"schema_version": 9, "generated_at": now_iso(), "overall_status": "ACTION_REQUIRED", "build_status": "PASS" if verification.get("status") == "PASS" and final_state.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "WARN", "decision_status": "OPERATOR_GATED", "current_owner": "M11", "final_truth": FINAL_TRUTH, "do_this_now": [{"priority": "P1", "text": "Use the M11 operator cockpit as the single local start surface for current state, warnings, decisions, Vivi missions and bundle status."}, {"priority": "P1", "text": "Treat Decision Wizard approvals as review-only until a fresh scoped Operator-Go exists."}, {"priority": "P2", "text": "Continue with M12 Release Candidate Decision after M11 verifiers and long-run handoff pass."}], "do_not": ["Do not mutate the runtime app, write an operator_go token or start Vivi runtime from M11.", "Do not publish, deploy, push, open payment/auth or send external messages from M11.", "Do not treat bundle UI profile selection as external sharing approval.", "Do not open Room16 rerun, real-data, Financial-Advice-Publishing or irreversible gates."], "safe_commands": ["python3 scripts/project_intelligence_graph/pig.py m11-final-state --json", "python3 scripts/project_intelligence_graph/pig.py m11-final-verification --json", "python3 scripts/project_intelligence_graph/pig.py m11-read-only-audit --json", "python3 scripts/project_intelligence_graph/pig.py m11-regression-suite --json", "python3 scripts/project_intelligence_graph/pig.py full-check --json", "python3 scripts/project_intelligence_graph/pig.py german-output-quality --json"], "status_lines": {"m11_current_owner": final_state.get("current_owner", "M11"), "m11_final_truth": final_state.get("final_truth", FINAL_TRUTH), "m11_final_state_status": final_state.get("status", "UNKNOWN"), "m11_blocks_completed": final_state.get("m11_blocks_completed", 0), "m11_section_count": final_state.get("section_count", 0), "m11_rail_card_count": final_state.get("rail_card_count", 0), "m12_next": final_state.get("m12_next", "release_candidate_decision_local_reversible"), "hard_gates": "closed", **_gate_payload()}}
    if write:
        write_json(OPERATOR_BRIEF_PATH, payload)
        _write_text(OPERATOR_BRIEF_MD_PATH, _operator_brief_md(payload))
    return payload


M11_BUILDERS: dict[str, Callable[..., dict[str, Any]]] = {
    "grand-roadmap": build_grand_roadmap,
    "m11-one-cockpit-ux": build_one_cockpit_ux,
    "m11-decision-wizard": build_decision_wizard,
    "m11-vivi-mission-console": build_vivi_mission_console,
    "m11-rail-health-cards": build_rail_health_cards,
    "m11-bundle-builder-ui": build_bundle_builder_ui,
    "m11-write-contract": build_write_contract,
    "m11-domain-summary": build_domain_summary,
    "m11-current-surface": build_current_surface,
    "m11-current-manifest": build_current_manifest,
    "m11-read-only-audit": build_read_only_audit,
    "m11-regression-suite": build_regression_suite,
    "m11-final-verification": build_final_verification,
    "m11-final-state": build_final_state,
}

M1_CURRENT_COMMANDS = tuple(dict.fromkeys([*m10.M1_CURRENT_COMMANDS, *M11_BUILDERS.keys()]))


def run_m1_current_command(command: str, write: bool = True, profile: str | None = None) -> dict[str, Any]:
    if command in M11_BUILDERS:
        effective_write = False if command in AUDITOR_COMMANDS else write
        return M11_BUILDERS[command](write=effective_write)
    return m10.run_m1_current_command(command, write=write, profile=profile)


def m1_full_check_steps() -> list[dict[str, Any]]:
    steps = m10.m1_full_check_steps()
    for command in ["m11-one-cockpit-ux", "m11-decision-wizard", "m11-vivi-mission-console", "m11-rail-health-cards", "m11-bundle-builder-ui", "m11-read-only-audit", "m11-regression-suite", "m11-final-verification", "m11-final-state"]:
        payload = run_m1_current_command(command, write=False)
        ok = is_passish(payload.get("status", "UNKNOWN"))
        steps.append({"name": command.replace("-", "_"), "status": "PASS" if ok else "FAIL", "returncode": 0 if ok else 1, "fail_count": payload.get("fail_count", 0), "runtime_action_executed": payload.get("runtime_action_executed", False), "external_action_executed": payload.get("external_action_executed", False)})
    return steps


def m1_report_payload() -> dict[str, Any]:
    payload = m10.m1_report_payload()
    payload.update({"m11_one_cockpit_ux": load_json(M11_ONE_COCKPIT_PATH, default={}), "m11_decision_wizard": load_json(M11_DECISION_WIZARD_PATH, default={}), "m11_vivi_mission_console": load_json(M11_VIVI_CONSOLE_PATH, default={}), "m11_rail_health_cards": load_json(M11_RAIL_HEALTH_PATH, default={}), "m11_bundle_builder_ui": load_json(M11_BUNDLE_UI_PATH, default={}), "m11_final_verification": load_json(M11_FINAL_VERIFICATION_PATH, default={}), "m11_final_state": load_json(M11_FINAL_STATE_PATH, default={})})
    return payload


def m1_compact_domain_lines(report: dict[str, Any]) -> list[str]:
    final_state = report.get("m11_final_state") or load_json(M11_FINAL_STATE_PATH, default={})
    return ["## Current Kernel Summary", "", f"- M11 final: `{final_state.get('status', 'UNKNOWN')}` `{final_state.get('final_truth', FINAL_TRUTH)}`", "- Current owner: `M11`; M10 ist Vorgängerschicht, ältere Surfaces sind Provenance.", f"- Sections: `{final_state.get('section_count', 0)}`; rail cards: `{final_state.get('rail_card_count', 0)}`; hard gates: `closed`.", "- Operator cockpit: `outputs/project_intelligence_graph/current/operator_cockpit.md`.", ""]


def append_m1_full_check_lines(lines: list[str], report: dict[str, Any]) -> None:
    final_state = report.get("m11_final_state", {})
    lines.extend(["", "## M11 DreamFactory One App Experience", ""])
    lines.append(f"- Final state: `{final_state.get('status', 'UNKNOWN')}` ({final_state.get('final_truth', FINAL_TRUTH)})")
    lines.append(f"- Sections: `{final_state.get('section_count', 0)}`; wizard steps: `{final_state.get('wizard_step_count', 0)}`; rail cards: `{final_state.get('rail_card_count', 0)}`; bundle profiles: `{final_state.get('profile_count', 0)}`.")
    lines.append("- Runtime mutation, operator-go token write, push, deploy, auth, payment, external communication and irreversible actions: `false`.")
