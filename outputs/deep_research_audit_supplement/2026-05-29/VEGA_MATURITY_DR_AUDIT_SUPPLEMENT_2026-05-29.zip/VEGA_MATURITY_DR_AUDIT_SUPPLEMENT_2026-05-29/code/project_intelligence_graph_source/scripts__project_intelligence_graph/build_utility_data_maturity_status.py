from __future__ import annotations

import datetime as dt
import json
from pathlib import Path


WORKSPACE = Path(__file__).resolve().parents[2]
VAULT_NOTE = Path(
    "/Users/BjornRosinger/Documents/Obsidian/Test Vaul Privat/Human Overview/Project - Utility Websites Portfolio.md"
)
OUT_DIR = WORKSPACE / "outputs/utility_websites/data_maturity"
OUT_JSON = OUT_DIR / "latest-data-maturity-status.json"
OUT_MD = OUT_DIR / "latest-data-maturity-status.md"
WEBSITE_DELIVERY_LATEST = WORKSPACE / ".runtime/website-delivery/latest-cycle.json"
RUNNER_LATEST = WORKSPACE / "website-delivery-runner/.runtime/website-delivery/latest-cycle.json"


def read_json(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {"status": "unreadable", "path": str(path)}
    return value if isinstance(value, dict) else {"status": "unreadable", "path": str(path)}


def iso_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def days_until(date_text: str, today: dt.date) -> int:
    return (dt.date.fromisoformat(date_text) - today).days


def build_payload() -> dict:
    today = dt.datetime.now().astimezone().date()
    note_text = VAULT_NOTE.read_text(encoding="utf-8") if VAULT_NOTE.exists() else ""
    review_dates = ["2026-05-25", "2026-06-01"]
    review_windows = [
        {
            "date": date_text,
            "days_until": days_until(date_text, today),
            "status": "due_or_past" if days_until(date_text, today) <= 0 else "future",
        }
        for date_text in review_dates
    ]
    root_cycle = read_json(WEBSITE_DELIVERY_LATEST)
    runner_cycle = read_json(RUNNER_LATEST)
    root_status = str(root_cycle.get("status") or "missing")
    runner_status = str(runner_cycle.get("status") or "missing")
    next_due = min((window for window in review_windows if window["status"] == "future"), key=lambda item: item["days_until"], default=None)
    due_windows = [window for window in review_windows if window["status"] == "due_or_past"]
    maturity_status = "not_mature"
    signal_status = "needs_review" if due_windows else "monitoring"
    return {
        "schema_version": 1,
        "generated_at": iso_now(),
        "project": "utility_websites",
        "status": "WARN",
        "maturity_status": maturity_status,
        "signal_status": signal_status,
        "runtime_action_executed": False,
        "source_note": str(VAULT_NOTE),
        "active_lanes": [
            "materialbedarf-rechner.de",
            "mein-elterngeldrechner.de",
            "microtool-starter-kit",
        ],
        "evidence": {
            "vault_mentions_not_mature": "Urteil `not_mature`" in note_text,
            "vault_mentions_materialbedarf": "materialbedarf-rechner.de" in note_text,
            "vault_mentions_elterngeld": "mein-elterngeldrechner.de" in note_text,
            "website_delivery_latest": {
                "path": str(WEBSITE_DELIVERY_LATEST),
                "exists": WEBSITE_DELIVERY_LATEST.exists(),
                "cycle_id": root_cycle.get("cycleId") or root_cycle.get("latestCycleId") or "",
                "status": root_status,
                "started_at": root_cycle.get("startedAt") or "",
                "finished_at": root_cycle.get("finishedAt") or root_cycle.get("completedAt") or "",
            },
            "website_delivery_runner_latest": {
                "path": str(RUNNER_LATEST),
                "exists": RUNNER_LATEST.exists(),
                "cycle_id": runner_cycle.get("cycleId") or runner_cycle.get("latestCycleId") or "",
                "status": runner_status,
                "started_at": runner_cycle.get("startedAt") or "",
                "finished_at": runner_cycle.get("finishedAt") or runner_cycle.get("completedAt") or "",
            },
        },
        "review_windows": review_windows,
        "operator_gates": [
            "live affiliate or ads activation",
            "production/deploy go",
            "external provider actions",
            "legal/tax/benefit claims",
            "new domain assumptions",
            "public monetization decisions",
        ],
        "next_safe_step": (
            f"Wait for the next data maturity window on {next_due['date']} before deriving monetization, rewrite or production work."
            if next_due
            else "Run a local data maturity review; do not open monetization, public or provider gates automatically."
        ),
        "notes": [
            "This packet is read-only and does not fetch GSC, Plausible, AdSense or provider data.",
            "not_mature is an operator signal, not a build failure.",
            "Materialbedarf and Elterngeld follow measurement/trust gates; the parked word-cluster project is not an active work lane.",
        ],
    }


def to_markdown(payload: dict) -> str:
    lines = [
        "# Utility Websites Data Maturity",
        "",
        f"- Status: `{payload['status']}`",
        f"- Maturity: `{payload['maturity_status']}`",
        f"- Signal: `{payload['signal_status']}`",
        f"- Runtime action executed: `{payload['runtime_action_executed']}`",
        "",
        "## Active Lanes",
        "",
    ]
    for lane in payload["active_lanes"]:
        lines.append(f"- `{lane}`")
    lines.extend(["", "## Review Windows", ""])
    for window in payload["review_windows"]:
        lines.append(f"- `{window['date']}`: `{window['status']}`, days_until `{window['days_until']}`")
    lines.extend(["", "## Evidence", ""])
    for key, value in payload["evidence"].items():
        if isinstance(value, dict):
            lines.append(f"- `{key}`: status `{value.get('status', 'unknown')}`, cycle `{value.get('cycle_id', '')}`")
        else:
            lines.append(f"- `{key}`: `{value}`")
    lines.extend(["", "## Operator Gates", ""])
    for gate in payload["operator_gates"]:
        lines.append(f"- `{gate}`")
    lines.extend(["", "## Next Safe Step", "", payload["next_safe_step"], ""])
    return "\n".join(lines)


def main() -> int:
    payload = build_payload()
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    OUT_JSON.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    OUT_MD.write_text(to_markdown(payload), encoding="utf-8")
    print(f"Utility data maturity status written: {OUT_JSON}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
