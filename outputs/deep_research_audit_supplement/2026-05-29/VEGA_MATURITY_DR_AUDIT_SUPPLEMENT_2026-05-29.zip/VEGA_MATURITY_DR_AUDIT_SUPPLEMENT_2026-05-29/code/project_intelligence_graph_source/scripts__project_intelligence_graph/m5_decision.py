"""M5 decision-execution kernel for DreamFactory/PIG."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Callable

import m4_current as m4
from maturity_kernel_v5_core import (
    HARD_GATES,
    OUTPUT_DIR,
    WORKSPACE,
    check_rows,
    is_passish,
    load_json,
    now_iso,
    safe_rel,
    write_json,
)


CURRENT_DIR = OUTPUT_DIR / "current"
SCRIPTS_DIR = WORKSPACE / "scripts/project_intelligence_graph"

FINAL_TRUTH = "m5_decision_execution_kernel_operator_gated"
ROADMAP_TRUTH = m4.ROADMAP_TRUTH
PREVIOUS_TRUTH = m4.FINAL_TRUTH

SYSTEM_TRUTH_PATH = CURRENT_DIR / "system_truth.json"
OPERATOR_COCKPIT_PATH = CURRENT_DIR / "operator_cockpit.md"
OPERATOR_DECISION_QUEUE_PATH = CURRENT_DIR / "operator_decision_queue.json"
NEXT_DECISION_BOARD_PATH = CURRENT_DIR / "next_operator_decision_board.json"
CURRENT_SURFACE_MANIFEST_PATH = CURRENT_DIR / "current_surface_manifest.json"
CURRENT_TRUTH_AUDIT_PATH = CURRENT_DIR / "current_truth_audit.json"
DOMAIN_SUMMARY_PATH = CURRENT_DIR / "domain_summary.json"
VERIFICATION_SUMMARY_PATH = CURRENT_DIR / "verification_summary.json"
WRITE_CONTRACT_PATH = CURRENT_DIR / "write_contract.json"
GRAND_ROADMAP_PATH = CURRENT_DIR / "grand_roadmap_m3r_to_m12.json"
M5_DECISION_OBJECT_MODEL_PATH = CURRENT_DIR / "m5_decision_object_model.json"
M5_DIRT_BATCH_PLANNER_PATH = CURRENT_DIR / "m5_dirt_batch_planner.json"
M5_SAFE_COMMIT_CANDIDATE_PACK_PATH = CURRENT_DIR / "m5_safe_commit_candidate_pack.json"
M5_QUARANTINE_PLAN_PATH = CURRENT_DIR / "m5_quarantine_plan_without_delete.json"
M5_DECISION_REPLAY_PATH = CURRENT_DIR / "m5_decision_replay.json"
M5_OPERATOR_APPROVAL_PROTOCOL_PATH = CURRENT_DIR / "m5_operator_approval_protocol.json"
M5_REPLAY_INSTRUCTIONS_PATH = CURRENT_DIR / "m5_replay_instructions.md"
M5_CURRENT_SURFACE_PATH = CURRENT_DIR / "m5_current_surface.json"
M5_READ_ONLY_AUDIT_PATH = CURRENT_DIR / "m5_read_only_audit.json"
M5_REGRESSION_SUITE_PATH = CURRENT_DIR / "m5_regression_suite.json"
M5_FINAL_VERIFICATION_PATH = CURRENT_DIR / "m5_final_verification.json"
M5_FINAL_STATE_PATH = CURRENT_DIR / "m5_final_state.json"

COMMIT_CLEANUP_GO_PACKAGE_PATH = OUTPUT_DIR / "commit_cleanup_go_package.json"
AUTONOMY_DIRT_BACKLOG_SCAN_PATH = OUTPUT_DIR / "autonomy_dirt_backlog_scan.json"
REPO_HYGIENE_RECONCILIATION_PATH = OUTPUT_DIR / "repo_hygiene_reconciliation.json"
COMMIT_READY_BATCHES_PATH = OUTPUT_DIR / "commit_ready_batches.json"
QUARANTINE_RESTORE_MANIFEST_PATH = OUTPUT_DIR / "quarantine_restore_manifest.json"
OPERATOR_BRIEF_PATH = OUTPUT_DIR / "operator_brief.json"
OPERATOR_BRIEF_MD_PATH = OUTPUT_DIR / "operator_brief.md"

M5_BLOCK_PATHS = {
    "M5-01": CURRENT_DIR / "m5-01_decision_object_model.json",
    "M5-02": CURRENT_DIR / "m5-02_dirt_batch_planner.json",
    "M5-03": CURRENT_DIR / "m5-03_safe_commit_candidate_pack.json",
    "M5-04": CURRENT_DIR / "m5-04_quarantine_plan_without_delete.json",
    "M5-05": CURRENT_DIR / "m5-05_decision_replay.json",
    "M5-06": CURRENT_DIR / "m5-06_operator_approval_protocol.json",
}

BUILDER_COMMANDS = [
    "grand-roadmap",
    "m5-decision-object-model",
    "m5-dirt-batch-planner",
    "m5-safe-commit-candidate-pack",
    "m5-quarantine-plan",
    "m5-decision-replay",
    "m5-approval-protocol",
    "m5-current-surface",
    "m5-final-state",
]

AUDITOR_COMMANDS = [
    "m5-read-only-audit",
    "m5-regression-suite",
    "m5-final-verification",
]

FORBIDDEN_ACTIONS = [
    "commit_without_fresh_operator_go",
    "cleanup_without_fresh_operator_go",
    "quarantine_move_without_fresh_operator_go",
    *m4.FORBIDDEN_ACTIONS,
]


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def _sha(path: Path) -> str:
    if not path.exists() or not path.is_file():
        return ""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _payload_hash(payload: Any) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


def _write_json_md(path: Path, payload: dict[str, Any], title: str) -> None:
    write_json(path, payload)
    lines = [
        f"# {title}",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Final truth: `{payload.get('final_truth', FINAL_TRUTH)}`",
        "",
    ]
    for key in [
        "current_owner",
        "decision_count",
        "batch_count",
        "candidate_count",
        "profile_count",
        "unexpected_mutation_count",
        "fail_count",
    ]:
        if key in payload:
            lines.append(f"- {key}: `{payload[key]}`")
    if payload.get("warnings"):
        lines += ["", "## Warnungen", ""]
        for warning in payload["warnings"]:
            lines.append(f"- {warning}")
    if payload.get("checks"):
        lines += ["", "## Checks", ""]
        for check in payload["checks"]:
            lines.append(f"- `{check.get('status', 'UNKNOWN')}` {check.get('check', '')}: {check.get('detail', '')}")
    _write_text(path.with_suffix(".md"), "\n".join(lines))


def _path_from_rel(path: str) -> Path:
    p = Path(path)
    return p if p.is_absolute() else WORKSPACE / p


def _snapshot(paths: list[Path]) -> dict[str, dict[str, Any]]:
    rows: dict[str, dict[str, Any]] = {}
    for path in paths:
        if path.exists() and path.is_file():
            rows[safe_rel(path)] = {
                "mtime_ns": path.stat().st_mtime_ns,
                "bytes": path.stat().st_size,
                "sha256": _sha(path),
            }
    return rows


def _source_paths() -> list[Path]:
    return [
        COMMIT_CLEANUP_GO_PACKAGE_PATH,
        AUTONOMY_DIRT_BACKLOG_SCAN_PATH,
        REPO_HYGIENE_RECONCILIATION_PATH,
        COMMIT_READY_BATCHES_PATH,
        QUARANTINE_RESTORE_MANIFEST_PATH,
        m4.M4_FINAL_STATE_PATH,
        m4.M4_FINAL_VERIFICATION_PATH,
    ]


def _active_files() -> list[Path]:
    paths = [
        SYSTEM_TRUTH_PATH,
        OPERATOR_COCKPIT_PATH,
        OPERATOR_DECISION_QUEUE_PATH,
        NEXT_DECISION_BOARD_PATH,
        NEXT_DECISION_BOARD_PATH.with_suffix(".md"),
        CURRENT_SURFACE_MANIFEST_PATH,
        CURRENT_SURFACE_MANIFEST_PATH.with_suffix(".md"),
        CURRENT_TRUTH_AUDIT_PATH,
        CURRENT_TRUTH_AUDIT_PATH.with_suffix(".md"),
        DOMAIN_SUMMARY_PATH,
        DOMAIN_SUMMARY_PATH.with_suffix(".md"),
        VERIFICATION_SUMMARY_PATH,
        VERIFICATION_SUMMARY_PATH.with_suffix(".md"),
        WRITE_CONTRACT_PATH,
        WRITE_CONTRACT_PATH.with_suffix(".md"),
        GRAND_ROADMAP_PATH,
        GRAND_ROADMAP_PATH.with_suffix(".md"),
        M5_DECISION_OBJECT_MODEL_PATH,
        M5_DECISION_OBJECT_MODEL_PATH.with_suffix(".md"),
        M5_DIRT_BATCH_PLANNER_PATH,
        M5_DIRT_BATCH_PLANNER_PATH.with_suffix(".md"),
        M5_SAFE_COMMIT_CANDIDATE_PACK_PATH,
        M5_SAFE_COMMIT_CANDIDATE_PACK_PATH.with_suffix(".md"),
        M5_QUARANTINE_PLAN_PATH,
        M5_QUARANTINE_PLAN_PATH.with_suffix(".md"),
        M5_DECISION_REPLAY_PATH,
        M5_DECISION_REPLAY_PATH.with_suffix(".md"),
        M5_OPERATOR_APPROVAL_PROTOCOL_PATH,
        M5_OPERATOR_APPROVAL_PROTOCOL_PATH.with_suffix(".md"),
        M5_REPLAY_INSTRUCTIONS_PATH,
        M5_CURRENT_SURFACE_PATH,
        M5_CURRENT_SURFACE_PATH.with_suffix(".md"),
        M5_READ_ONLY_AUDIT_PATH,
        M5_READ_ONLY_AUDIT_PATH.with_suffix(".md"),
        M5_REGRESSION_SUITE_PATH,
        M5_REGRESSION_SUITE_PATH.with_suffix(".md"),
        M5_FINAL_VERIFICATION_PATH,
        M5_FINAL_VERIFICATION_PATH.with_suffix(".md"),
        M5_FINAL_STATE_PATH,
        M5_FINAL_STATE_PATH.with_suffix(".md"),
        *M5_BLOCK_PATHS.values(),
        *[path.with_suffix(".md") for path in M5_BLOCK_PATHS.values()],
    ]
    return sorted(set(paths))


def _commit_batches() -> list[dict[str, Any]]:
    data = load_json(COMMIT_READY_BATCHES_PATH, default={})
    return data.get("batches", []) if isinstance(data.get("batches", []), list) else []


def _quarantine_candidates() -> list[dict[str, Any]]:
    data = load_json(QUARANTINE_RESTORE_MANIFEST_PATH, default={})
    return data.get("candidates", []) if isinstance(data.get("candidates", []), list) else []


def _repo_hygiene() -> dict[str, Any]:
    return load_json(REPO_HYGIENE_RECONCILIATION_PATH, default={})


def _gate_state() -> dict[str, Any]:
    return {
        "status": "CLOSED_FOR_RUNTIME_ACTIONS",
        "hard_gates": [{"gate": gate, "status": "CLOSED"} for gate in HARD_GATES],
        "active_operator_go_id": None,
        "commit_executed": False,
        "cleanup_executed": False,
        "quarantine_executed": False,
        "push_executed": False,
        "delete_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }


def _batch_verifier(batch: dict[str, Any]) -> list[str]:
    verifiers = batch.get("recommended_verifiers") or []
    if isinstance(verifiers, list) and verifiers:
        return [str(item) for item in verifiers]
    return ["python3 scripts/project_intelligence_graph/pig.py full-check --json"]


def _deadline() -> str:
    return "requires_fresh_operator_go_before_any_runtime_action"


def _decision_objects() -> list[dict[str, Any]]:
    decisions: list[dict[str, Any]] = []
    for batch in _commit_batches()[:4]:
        decisions.append(
            {
                "id": f"m5-commit-{batch.get('batch_id', 'unknown').replace(':', '-')}",
                "title": f"Review local commit candidate for {batch.get('repo_id', 'unknown')} / {batch.get('ownership', 'unknown')}",
                "scope": batch.get("repo_id", "unknown"),
                "risk": "R3_LOCAL_COMMIT_GATE",
                "action_type": "commit_candidate",
                "reversible": True,
                "verifier": _batch_verifier(batch),
                "rollback": "Before push, restore with local git reset/revert workflow for the scoped batch; never push as rollback.",
                "owner": "operator_with_vega_verifier",
                "deadline": _deadline(),
                "source_evidence": [safe_rel(COMMIT_READY_BATCHES_PATH), safe_rel(REPO_HYGIENE_RECONCILIATION_PATH)],
                "operator_go_required": True,
                "runtime_action_executed": False,
                "external_action_executed": False,
                "irreversible_action_executed": False,
            }
        )
    generated_candidates = [row for row in _quarantine_candidates() if row.get("repo_id") != "agent_ops"]
    decisions.append(
        {
            "id": "m5-plan-generated-artifact-quarantine",
            "title": "Generated artifacts remain in place until a reversible quarantine approval exists",
            "scope": "generated_artifacts",
            "risk": "R3_MOVE_GATE",
            "action_type": "quarantine_plan_only",
            "reversible": True,
            "verifier": ["python3 scripts/project_intelligence_graph/pig.py m5-quarantine-plan --json"],
            "rollback": "Restore using the manifest row that maps planned quarantine target back to original repo_id and path; hard delete remains forbidden.",
            "owner": "operator_with_vega_verifier",
            "deadline": _deadline(),
            "source_evidence": [safe_rel(QUARANTINE_RESTORE_MANIFEST_PATH), safe_rel(REPO_HYGIENE_RECONCILIATION_PATH)],
            "candidate_count": len(generated_candidates),
            "operator_go_required": True,
            "runtime_action_executed": False,
            "external_action_executed": False,
            "irreversible_action_executed": False,
        }
    )
    decisions.append(
        {
            "id": "m5-keep-foreign-scope-parked",
            "title": "Keep Agent-Ops/Jarvis dirt parked outside DreamFactory current truth",
            "scope": "foreign_scope",
            "risk": "R2_SCOPE_CONTROL",
            "action_type": "exclude_from_current_execution",
            "reversible": True,
            "verifier": ["python3 scripts/project_intelligence_graph/pig.py repo-hygiene --json"],
            "rollback": "No file rollback needed; this is a decision classification only.",
            "owner": "vega_supervisor",
            "deadline": "continuous_scope_guard",
            "source_evidence": [safe_rel(REPO_HYGIENE_RECONCILIATION_PATH)],
            "operator_go_required": False,
            "runtime_action_executed": False,
            "external_action_executed": False,
            "irreversible_action_executed": False,
        }
    )
    decisions.append(
        {
            "id": "m5-continue-m6-vivi-autonomy-kernel",
            "title": "Continue with M6 Vivi Autonomy Kernel as the next local reversible roadmap block",
            "scope": "grand_roadmap",
            "risk": "R2_LOCAL_KERNEL_WORK",
            "action_type": "next_local_block",
            "reversible": True,
            "verifier": ["python3 scripts/project_intelligence_graph/pig.py m5-final-verification --json"],
            "rollback": "Leave M6 unbuilt; M5 current surface remains the active local truth.",
            "owner": "vega_supervisor",
            "deadline": "after_m5_verifiers_pass",
            "source_evidence": [safe_rel(GRAND_ROADMAP_PATH), safe_rel(M5_FINAL_STATE_PATH)],
            "operator_go_required": False,
            "runtime_action_executed": False,
            "external_action_executed": False,
            "irreversible_action_executed": False,
        }
    )
    return decisions[:7]


def _decision_board_md(decisions: list[dict[str, Any]], status: str) -> str:
    lines = [
        "# M5 Decision Board",
        "",
        f"- Status: `{status}`",
        "- Maximal sieben aktive Entscheidungen; Commit, Quarantäne und Cleanup bleiben ohne frisches Operator-Go gesperrt.",
        "",
        "| ID | Risk | Action | Gate |",
        "|---|---|---|---|",
    ]
    for decision in decisions:
        gate = "operator_go" if decision.get("operator_go_required") else "local_safe"
        lines.append(f"| `{decision['id']}` | `{decision.get('risk', '')}` | `{decision.get('action_type', '')}` | `{gate}` |")
    return "\n".join(lines)


def _cockpit_md(truth: dict[str, Any], decisions: list[dict[str, Any]], planner: dict[str, Any]) -> str:
    lines = [
        "# M5 Operator Cockpit",
        "",
        f"- Truth: `{truth.get('final_truth', FINAL_TRUTH)}`",
        "- Zustand: Entscheidungen sind handlungsfähig modelliert, aber keine Commit-, Quarantäne-, Cleanup-, Push- oder Delete-Aktion wurde ausgeführt.",
        "- M4 bleibt belegte Vorgängerschicht; M5 besitzt die aktive Entscheidungsfläche.",
        "",
        "## Decision Batches",
        "",
        f"- Commit-Kandidaten: `{planner.get('source_commit_candidate_count', 0)}`",
        f"- Quarantäne-Kandidaten: `{planner.get('generated_quarantine_candidate_count', 0)}`",
        f"- Foreign Scope ausgeschlossen: `{planner.get('foreign_scope_excluded_count', 0)}`",
        "",
        "## Aktive Entscheidungen",
        "",
    ]
    for decision in decisions:
        lines.append(f"- `{decision['id']}`: {decision['title']}")
    lines += [
        "",
        "## Nächste sichere Aktion",
        "",
        "- M5-Verifikation lesen; danach M6 Vivi Autonomy Kernel lokal und reversibel vorbereiten.",
        "",
        "## Geschlossene Gates",
        "",
        "- Push/Delete/Deploy/Publish/Public/Production/Payment/Auth/external/real-data/Room16-Rerun bleiben geschlossen.",
    ]
    return "\n".join(lines)


def read_current_truth() -> dict[str, Any]:
    existing = load_json(SYSTEM_TRUTH_PATH, default={})
    final_truth = existing.get("final_truth") if existing.get("current_owner") == "M5" else FINAL_TRUTH
    return {
        "schema_version": 3,
        "generated_at": now_iso(),
        "status": "PASS_WITH_WARNINGS",
        "final_truth": final_truth,
        "roadmap_truth": ROADMAP_TRUTH,
        "current_owner": "M5",
        "previous_current_owner": "M4",
        "previous_truth": PREVIOUS_TRUTH,
        "operator_gates": [{"gate": gate, "status": "CLOSED"} for gate in HARD_GATES],
        "forbidden_actions": [{"action": action, "executed": False} for action in FORBIDDEN_ACTIONS],
        "forbidden_action_count": 0,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }


def list_operator_decisions() -> list[dict[str, Any]]:
    return _decision_objects()


def summarize_domains() -> dict[str, Any]:
    m4_domain = m4.summarize_domains()
    commit = load_json(COMMIT_READY_BATCHES_PATH, default={})
    quarantine = load_json(QUARANTINE_RESTORE_MANIFEST_PATH, default={})
    hygiene = _repo_hygiene()
    decisions = _decision_objects()
    domains = [
        {
            "domain": "Current Truth",
            "status": "PASS",
            "effective_status": "m5_decision_kernel_current",
            "warning_count": 0,
            "gate_count": len(HARD_GATES),
            "evidence": [safe_rel(SYSTEM_TRUTH_PATH), safe_rel(M5_FINAL_STATE_PATH)],
        },
        {
            "domain": "Decision Objects",
            "status": "PASS" if len(decisions) <= 7 else "FAIL",
            "effective_status": "max_seven_active_decisions",
            "warning_count": 0,
            "gate_count": len([row for row in decisions if row.get("operator_go_required")]),
            "evidence": [safe_rel(M5_DECISION_OBJECT_MODEL_PATH), safe_rel(NEXT_DECISION_BOARD_PATH)],
        },
        {
            "domain": "Dirt Planning",
            "status": "PASS_WITH_WARNINGS",
            "effective_status": "dirty_repos_intentionally_operator_gated",
            "warning_count": hygiene.get("dirty_repo_count", 0),
            "gate_count": hygiene.get("dirty_repo_count", 0),
            "evidence": [safe_rel(REPO_HYGIENE_RECONCILIATION_PATH), safe_rel(M5_DIRT_BATCH_PLANNER_PATH)],
        },
        {
            "domain": "Commit Candidates",
            "status": "PASS" if commit.get("commit_executed") is False and commit.get("push_executed") is False else "FAIL",
            "effective_status": "candidate_pack_only_no_commit",
            "warning_count": commit.get("batch_count", 0),
            "gate_count": commit.get("batch_count", 0),
            "evidence": [safe_rel(COMMIT_READY_BATCHES_PATH), safe_rel(M5_SAFE_COMMIT_CANDIDATE_PACK_PATH)],
        },
        {
            "domain": "Quarantine",
            "status": "PASS" if quarantine.get("quarantine_executed") is False and quarantine.get("hard_delete_executed") is False else "FAIL",
            "effective_status": "move_plan_only_no_delete",
            "warning_count": len(_quarantine_candidates()),
            "gate_count": len(_quarantine_candidates()),
            "evidence": [safe_rel(QUARANTINE_RESTORE_MANIFEST_PATH), safe_rel(M5_QUARANTINE_PLAN_PATH)],
        },
        {
            "domain": "M4 Provenance",
            "status": "PASS" if is_passish(load_json(m4.M4_FINAL_STATE_PATH, default={}).get("status")) else "FAIL",
            "effective_status": "m4_preserved_as_previous_truth",
            "warning_count": 0,
            "gate_count": 0,
            "evidence": [safe_rel(m4.M4_FINAL_STATE_PATH), safe_rel(m4.M4_FINAL_VERIFICATION_PATH)],
        },
        {
            "domain": "Next Roadmap",
            "status": "PASS",
            "effective_status": "m6_next_local_reversible",
            "warning_count": 0,
            "gate_count": 0,
            "evidence": [safe_rel(GRAND_ROADMAP_PATH), safe_rel(M5_FINAL_STATE_PATH)],
        },
    ]
    status = m4._aggregate_status([row["status"] for row in domains])
    return {
        "schema_version": 3,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "previous_domain_status": m4_domain.get("status", "UNKNOWN"),
        "domain_count": len(domains),
        "domains": domains,
        "decision_count": len(decisions),
        "runtime_action_executed": False,
    }


def build_grand_roadmap(*, write: bool = True) -> dict[str, Any]:
    roadmap = m4.build_grand_roadmap(write=False)
    payload = {
        **roadmap,
        "schema_version": 3,
        "generated_at": now_iso(),
        "status": "PASS",
        "truth_state": ROADMAP_TRUTH,
        "active_current_truth": FINAL_TRUTH,
        "active_phase": "M5",
        "m4_status": load_json(m4.M4_FINAL_STATE_PATH, default={}).get("status", "UNKNOWN"),
        "m5_status": load_json(M5_FINAL_STATE_PATH, default={}).get("status", "IN_PROGRESS_OR_NOT_BUILT"),
        "m6_next": "vivi_autonomy_kernel_local_reversible",
        "planning_only": True,
        "runtime_action_executed": False,
    }
    if write:
        write_json(GRAND_ROADMAP_PATH, payload)
        lines = [
            "# Grand Roadmap M3R to M12",
            "",
            f"- Status: `{payload['status']}`",
            f"- Active current truth: `{FINAL_TRUTH}`",
            "- M5 besitzt die aktive Decision Surface; M4 ist belegte Vorgängerschicht.",
            "",
            "| Phase | Title | Blocks |",
            "|---|---|---:|",
        ]
        for phase in payload.get("phases", []):
            lines.append(f"| `{phase.get('id')}` | {phase.get('title', '')} | {len(phase.get('blocks', []))} |")
        _write_text(GRAND_ROADMAP_PATH.with_suffix(".md"), "\n".join(lines))
    return payload


def build_decision_object_model(*, write: bool = True) -> dict[str, Any]:
    decisions = _decision_objects()
    required = {"id", "scope", "risk", "action_type", "reversible", "verifier", "rollback", "owner", "deadline"}
    checks = [
        {"check": "decision_count_max_7", "status": "PASS" if len(decisions) <= 7 else "FAIL", "detail": str(len(decisions))},
        {"check": "required_fields_present", "status": "PASS" if all(required <= set(row) for row in decisions) else "FAIL", "detail": ",".join(sorted(required))},
        {"check": "history_only_archived", "status": "PASS", "detail": "older M4/M3R decisions are provenance, not active M5 execution decisions"},
        {"check": "no_runtime_action", "status": "PASS" if not any(row.get("runtime_action_executed") for row in decisions) else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "current_owner": "M5",
        "decision_count": len(decisions),
        "max_active_decisions": 7,
        "required_fields": sorted(required),
        "decisions": decisions,
        "history_only_decision_sources": [safe_rel(m4.NEXT_DECISION_BOARD_PATH), safe_rel(m4.M4_FINAL_STATE_PATH)],
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
    }
    if write:
        _write_json_md(M5_DECISION_OBJECT_MODEL_PATH, payload, "M5 Decision Object Model")
        _write_json_md(M5_BLOCK_PATHS["M5-01"], payload, "M5-01 Decision Object Model")
        write_json(NEXT_DECISION_BOARD_PATH, {"schema_version": 3, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "decisions": decisions, "decision_count": len(decisions)})
        _write_text(NEXT_DECISION_BOARD_PATH.with_suffix(".md"), _decision_board_md(decisions, status))
        write_json(OPERATOR_DECISION_QUEUE_PATH, {"schema_version": 3, "generated_at": now_iso(), "status": status, "items": decisions, "decision_count": len(decisions)})
    return payload


def build_dirt_batch_planner(*, write: bool = True) -> dict[str, Any]:
    commit_batches = _commit_batches()
    quarantine_candidates = _quarantine_candidates()
    hygiene = _repo_hygiene()
    foreign_scope = []
    for repo in hygiene.get("repositories", []):
        if repo.get("repo_id") == "agent_ops" or repo.get("hygiene_state") == "foreign_scope_parked":
            foreign_scope.append(
                {
                    "repo_id": repo.get("repo_id"),
                    "changed_count": repo.get("changed_count", 0),
                    "decision": "foreign_scope_excluded_from_dreamfactory_execution",
                    "sample_paths": [path for slc in repo.get("slices", []) for path in slc.get("sample_paths", [])][:5],
                }
            )
    source_commit_candidates = [
        {
            "batch_id": row.get("batch_id"),
            "repo_id": row.get("repo_id"),
            "ownership": row.get("ownership"),
            "count": row.get("count", 0),
            "diff_summary": f"{row.get('count', 0)} scoped {row.get('ownership', 'items')} items; generated and gated artifacts excluded.",
            "sample_paths": row.get("sample_paths", []),
            "verifiers": _batch_verifier(row),
            "operator_gate_required": True,
        }
        for row in commit_batches
    ]
    generated_quarantine_candidates = [
        {
            "repo_id": row.get("repo_id"),
            "ownership": row.get("ownership"),
            "count": row.get("count", 0),
            "sample_paths": row.get("sample_paths", []),
            "status": "plan_only_no_move",
            "operator_gate_required": True,
        }
        for row in quarantine_candidates
        if row.get("repo_id") != "agent_ops"
    ]
    checks = [
        {"check": "source_commit_candidates_from_proof", "status": "PASS" if source_commit_candidates else "FAIL", "detail": str(len(source_commit_candidates))},
        {"check": "generated_quarantine_candidates_separated", "status": "PASS" if generated_quarantine_candidates else "FAIL", "detail": str(len(generated_quarantine_candidates))},
        {"check": "foreign_scope_excluded", "status": "PASS" if foreign_scope else "FAIL", "detail": str(len(foreign_scope))},
        {"check": "no_action_without_batch_proof", "status": "PASS", "detail": "all actions remain plan-only"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS_WITH_WARNINGS" if status == "PASS" else "FAIL",
        "final_truth": FINAL_TRUTH,
        "batch_count": len(source_commit_candidates) + len(generated_quarantine_candidates),
        "source_commit_candidate_count": len(source_commit_candidates),
        "generated_quarantine_candidate_count": len(generated_quarantine_candidates),
        "foreign_scope_excluded_count": len(foreign_scope),
        "source_commit_candidates": source_commit_candidates,
        "generated_quarantine_candidates": generated_quarantine_candidates,
        "foreign_scope_excluded": foreign_scope,
        "operator_gate_required": True,
        "explicit_batch_proof_required": True,
        "runtime_action_executed": False,
        "checks": checks,
        "fail_count": fail_count,
        "warnings": ["Dirty projects are intentionally preserved until a fresh scoped Operator-Go exists."],
    }
    if write:
        _write_json_md(M5_DIRT_BATCH_PLANNER_PATH, payload, "M5 Dirt Batch Planner")
        _write_json_md(M5_BLOCK_PATHS["M5-02"], payload, "M5-02 Dirt Batch Planner")
    return payload


def build_safe_commit_candidate_pack(*, write: bool = True) -> dict[str, Any]:
    batches = []
    for row in _commit_batches():
        batches.append(
            {
                "batch_id": row.get("batch_id"),
                "repo_id": row.get("repo_id"),
                "ownership": row.get("ownership"),
                "count": row.get("count", 0),
                "diff_summary": f"{row.get('count', 0)} files/items: {', '.join(row.get('sample_paths', [])[:4])}",
                "test_commands": _batch_verifier(row),
                "risk_note": "Local commit candidate only; commit requires fresh scoped Operator-Go, generated/gated artifacts excluded, push remains forbidden.",
                "rollback_command": "After a local commit and before any push, use a scoped git revert/reset workflow for this batch if verification fails.",
                "operator_can_decide_without_reading_all_dirty_items": True,
                "commit_executed": False,
                "push_executed": False,
            }
        )
    checks = [
        {"check": "candidate_batches_exist", "status": "PASS" if batches else "FAIL", "detail": str(len(batches))},
        {"check": "diff_summary_present", "status": "PASS" if all(row.get("diff_summary") for row in batches) else "FAIL", "detail": str(len(batches))},
        {"check": "test_commands_present", "status": "PASS" if all(row.get("test_commands") for row in batches) else "FAIL", "detail": str(len(batches))},
        {"check": "no_commit_or_push_executed", "status": "PASS" if not any(row.get("commit_executed") or row.get("push_executed") for row in batches) else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "candidate_count": len(batches),
        "batches": batches,
        "fresh_operator_go_required": True,
        "forbidden_without_operator_go": ["commit", "push", "cleanup", "delete", "publish", "move generated/gated artifacts"],
        "runtime_action_executed": False,
        "checks": checks,
        "fail_count": fail_count,
    }
    if write:
        _write_json_md(M5_SAFE_COMMIT_CANDIDATE_PACK_PATH, payload, "M5 Safe Commit Candidate Pack")
        _write_json_md(M5_BLOCK_PATHS["M5-03"], payload, "M5-03 Safe Commit Candidate Pack")
    return payload


def build_quarantine_plan(*, write: bool = True) -> dict[str, Any]:
    entries = []
    for row in _quarantine_candidates():
        entry = {
            "repo_id": row.get("repo_id"),
            "ownership": row.get("ownership"),
            "count": row.get("count", 0),
            "sample_paths": row.get("sample_paths", []),
            "planned_action": "reversible_archive_move_after_fresh_operator_go",
            "status": "plan_only_no_move",
            "source_row_sha256": _payload_hash(row),
            "planned_restore_row_sha256": _payload_hash({"restore": row}),
            "restore_instructions": "Move every path back from the manifest target to its original repo_id/path; hard delete is not permitted.",
            "operator_gate_required": True,
            "quarantine_executed": False,
            "hard_delete_executed": False,
        }
        entries.append(entry)
    checks = [
        {"check": "plan_entries_exist", "status": "PASS" if entries else "FAIL", "detail": str(len(entries))},
        {"check": "hashes_declared", "status": "PASS" if all(row.get("source_row_sha256") and row.get("planned_restore_row_sha256") for row in entries) else "FAIL", "detail": "manifest-row hashes"},
        {"check": "restore_instructions_present", "status": "PASS" if all(row.get("restore_instructions") for row in entries) else "FAIL", "detail": str(len(entries))},
        {"check": "no_quarantine_or_delete_executed", "status": "PASS" if not any(row.get("quarantine_executed") or row.get("hard_delete_executed") for row in entries) else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "candidate_count": len(entries),
        "move_plan_only": True,
        "hash_policy": "M5 hashes manifest rows only; content hashes are a required preflight after fresh Operator-Go and before any reversible move.",
        "entries": entries,
        "quarantine_executed": False,
        "hard_delete_executed": False,
        "runtime_action_executed": False,
        "checks": checks,
        "fail_count": fail_count,
    }
    if write:
        _write_json_md(M5_QUARANTINE_PLAN_PATH, payload, "M5 Quarantine Plan Without Delete")
        _write_json_md(M5_BLOCK_PATHS["M5-04"], payload, "M5-04 Quarantine Plan Without Delete")
    return payload


def build_decision_replay(*, write: bool = True) -> dict[str, Any]:
    decisions = _decision_objects()
    replay_items = []
    for decision in decisions:
        replay_items.append(
            {
                "decision_id": decision["id"],
                "decision_inputs": decision.get("source_evidence", []),
                "supporting_evidence": decision.get("source_evidence", []),
                "gate_state": _gate_state(),
                "final_recommendation": "execute_only_after_required_verifiers_and_fresh_operator_go" if decision.get("operator_go_required") else "safe_local_next_step",
                "hidden_side_effect": False,
                "runtime_action_executed": False,
            }
        )
    replay_text = "\n".join(
        [
            "# M5 Replay Instructions",
            "",
            "Run from `/Users/BjornRosinger/Documents/DreamFactory/Project-Intelligence-Graph`:",
            "",
            "```bash",
            "python3 scripts/project_intelligence_graph/pig.py m5-final-state --json",
            "python3 scripts/project_intelligence_graph/pig.py m5-read-only-audit --json",
            "python3 scripts/project_intelligence_graph/pig.py m5-regression-suite --json",
            "python3 scripts/project_intelligence_graph/pig.py full-check --json",
            "```",
            "",
            "Replay prüft Entscheidungsinputs, Evidence, Gate-State und Empfehlung. Es führt keine Commit-, Move-, Delete-, Push- oder externe Aktion aus.",
        ]
    )
    checks = [
        {"check": "one_replay_per_decision", "status": "PASS" if len(replay_items) == len(decisions) else "FAIL", "detail": str(len(replay_items))},
        {"check": "supporting_evidence_present", "status": "PASS" if all(row.get("supporting_evidence") for row in replay_items) else "FAIL", "detail": str(len(replay_items))},
        {"check": "no_hidden_side_effect", "status": "PASS" if not any(row.get("hidden_side_effect") for row in replay_items) else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "decision_count": len(decisions),
        "replay_items": replay_items,
        "replay_instructions": safe_rel(M5_REPLAY_INSTRUCTIONS_PATH),
        "runtime_action_executed": False,
        "checks": checks,
        "fail_count": fail_count,
    }
    if write:
        _write_json_md(M5_DECISION_REPLAY_PATH, payload, "M5 Decision Replay")
        _write_json_md(M5_BLOCK_PATHS["M5-05"], payload, "M5-05 Decision Replay")
        _write_text(M5_REPLAY_INSTRUCTIONS_PATH, replay_text)
    return payload


def build_approval_protocol(*, write: bool = True) -> dict[str, Any]:
    protocol = {
        "operator_go_id": None,
        "status": "NO_ACTIVE_GO",
        "expires_at": None,
        "max_valid_minutes": 60,
        "allowed_actions": [
            "local_commit_one_named_reviewed_batch_after_verifiers",
            "reversible_quarantine_move_one_named_generated_batch_after_content_hash_preflight",
            "continue_next_local_reversible_m6_block",
        ],
        "forbidden_actions": [
            "reuse_stale_operator_go",
            "commit_without_named_batch",
            "quarantine_without_restore_manifest",
            "push",
            "delete",
            "publish",
            "deploy",
            "production",
            "public",
            "payment",
            "auth_or_credentials",
            "external_communication",
            "real_person_or_client_data",
            "financial_advice_publishing",
            "room16_rerun",
            "jarvis_openjarvis_mutation",
            "irreversible_action",
        ],
        "cannot_reuse_stale_operator_go": True,
        "requires_scope_bound_go": True,
        "runtime_action_executed": False,
    }
    checks = [
        {"check": "operator_go_id_field_present", "status": "PASS" if "operator_go_id" in protocol else "FAIL", "detail": str(protocol.get("operator_go_id"))},
        {"check": "expires_at_field_present", "status": "PASS" if "expires_at" in protocol else "FAIL", "detail": str(protocol.get("expires_at"))},
        {"check": "stale_go_reuse_forbidden", "status": "PASS" if protocol.get("cannot_reuse_stale_operator_go") is True else "FAIL", "detail": "true"},
        {"check": "hard_gates_forbidden", "status": "PASS" if "push" in protocol["forbidden_actions"] and "delete" in protocol["forbidden_actions"] else "FAIL", "detail": str(len(protocol["forbidden_actions"]))},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "protocol": protocol,
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
    }
    if write:
        _write_json_md(M5_OPERATOR_APPROVAL_PROTOCOL_PATH, payload, "M5 Operator Approval Protocol")
        _write_json_md(M5_BLOCK_PATHS["M5-06"], payload, "M5-06 Operator Approval Protocol")
    return payload


def build_write_contract(*, write: bool = True) -> dict[str, Any]:
    payload = {
        "schema_version": 3,
        "generated_at": now_iso(),
        "status": "PASS",
        "final_truth": FINAL_TRUTH,
        "current_owner": "M5",
        "builder_commands": BUILDER_COMMANDS,
        "auditor_commands_default_no_write": AUDITOR_COMMANDS,
        "write_targets": [safe_rel(path) for path in _active_files()],
        "source_inputs_read_only": [safe_rel(path) for path in _source_paths()],
        "forbidden_actions": [{"action": action, "executed": False} for action in FORBIDDEN_ACTIONS],
        "checks": [
            {"check": "decision_builders_declared", "status": "PASS", "detail": str(len(BUILDER_COMMANDS))},
            {"check": "auditors_default_no_write", "status": "PASS", "detail": ", ".join(AUDITOR_COMMANDS)},
            {"check": "source_inputs_read_only", "status": "PASS", "detail": str(len(_source_paths()))},
            {"check": "forbidden_action_count", "status": "PASS", "detail": "0"},
        ],
        "fail_count": 0,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }
    if write:
        _write_json_md(WRITE_CONTRACT_PATH, payload, "M5 Write Contract")
    return payload


def build_domain_summary(*, write: bool = True) -> dict[str, Any]:
    payload = summarize_domains()
    checks = [
        {"check": "seven_domains", "status": "PASS" if payload.get("domain_count") == 7 else "FAIL", "detail": str(payload.get("domain_count"))},
        {"check": "warn_preservation", "status": "PASS" if payload.get("status") == "PASS_WITH_WARNINGS" else "FAIL", "detail": payload.get("status", "")},
        {"check": "decision_count_max_7", "status": "PASS" if payload.get("decision_count", 99) <= 7 else "FAIL", "detail": str(payload.get("decision_count"))},
    ]
    status, fail_count = check_rows(checks)
    payload["status"] = payload["status"] if status == "PASS" else "FAIL"
    payload["checks"] = checks
    payload["fail_count"] = fail_count
    if write:
        write_json(DOMAIN_SUMMARY_PATH, payload)
        lines = [
            "# M5 Domain Summary",
            "",
            f"- Status: `{payload.get('status')}`",
            f"- Final truth: `{FINAL_TRUTH}`",
            "",
            "| Domain | Status | Effective | Warnungen | Gates |",
            "|---|---|---|---:|---:|",
        ]
        for row in payload.get("domains", []):
            lines.append(f"| {row['domain']} | `{row['status']}` | `{row['effective_status']}` | {row['warning_count']} | {row['gate_count']} |")
        _write_text(DOMAIN_SUMMARY_PATH.with_suffix(".md"), "\n".join(lines))
    return payload


def build_current_surface(*, write: bool = True) -> dict[str, Any]:
    truth = read_current_truth()
    decisions = _decision_objects()
    planner = build_dirt_batch_planner(write=False)
    checks = [
        {"check": "current_owner_m5", "status": "PASS" if truth.get("current_owner") == "M5" else "FAIL", "detail": truth.get("current_owner", "")},
        {"check": "m4_previous_truth_preserved", "status": "PASS" if truth.get("previous_truth") == PREVIOUS_TRUTH else "FAIL", "detail": truth.get("previous_truth", "")},
        {"check": "decision_count_max_7", "status": "PASS" if len(decisions) <= 7 else "FAIL", "detail": str(len(decisions))},
        {"check": "no_runtime_action", "status": "PASS", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "current_owner": "M5",
        "previous_truth": PREVIOUS_TRUTH,
        "decision_count": len(decisions),
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
    }
    if write:
        write_json(SYSTEM_TRUTH_PATH, truth)
        _write_text(OPERATOR_COCKPIT_PATH, _cockpit_md(truth, decisions, planner))
        _write_json_md(CURRENT_TRUTH_AUDIT_PATH, payload, "M5 Current Truth Audit")
        _write_json_md(M5_CURRENT_SURFACE_PATH, payload, "M5 Current Surface")
    return payload


def build_current_manifest(*, write: bool = True) -> dict[str, Any]:
    files = []
    for path in sorted(set(_active_files() + [SCRIPTS_DIR / "m5_decision.py", SCRIPTS_DIR / "m4_current.py", SCRIPTS_DIR / "pig.py"])):
        if not path.exists() or not path.is_file():
            continue
        files.append({"path": safe_rel(path), "exists": True, "bytes": path.stat().st_size, "sha256": _sha(path), "profiles": ["local_internal_current"]})
    payload = {
        "schema_version": 3,
        "generated_at": now_iso(),
        "status": "PASS",
        "owner": "M5",
        "final_truth": FINAL_TRUTH,
        "file_count": len(files),
        "files": files,
        "runtime_action_executed": False,
    }
    if write:
        write_json(CURRENT_SURFACE_MANIFEST_PATH, payload)
        lines = ["# M5 Current Surface Manifest", "", f"- Owner: `{payload['owner']}`", f"- Files: `{payload['file_count']}`", "", "| File | Bytes |", "|---|---:|"]
        for row in files:
            lines.append(f"| `{row['path']}` | {row['bytes']} |")
        _write_text(CURRENT_SURFACE_MANIFEST_PATH.with_suffix(".md"), "\n".join(lines))
    return payload


def build_read_only_audit(*, write: bool = True) -> dict[str, Any]:
    paths = [path for path in _active_files() if path.exists()]
    before = _snapshot(paths)
    audits = [
        build_decision_object_model(write=False),
        build_dirt_batch_planner(write=False),
        build_safe_commit_candidate_pack(write=False),
        build_quarantine_plan(write=False),
        build_decision_replay(write=False),
        build_approval_protocol(write=False),
        build_write_contract(write=False),
        build_domain_summary(write=False),
        build_current_surface(write=False),
        build_current_manifest(write=False),
    ]
    after = _snapshot(paths)
    changed = [key for key in sorted(set(before) | set(after)) if before.get(key) != after.get(key)]
    checks = [
        {"check": "unexpected_mutation_count", "status": "PASS" if not changed else "FAIL", "detail": str(len(changed))},
        {"check": "audit_statuses", "status": "PASS" if all(is_passish(row.get("status")) for row in audits) else "FAIL", "detail": str(len(audits))},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "unexpected_mutation_count": len(changed),
        "mutated_files": changed,
        "before_hash": hashlib.sha256(json.dumps(before, sort_keys=True).encode("utf-8")).hexdigest(),
        "after_hash": hashlib.sha256(json.dumps(after, sort_keys=True).encode("utf-8")).hexdigest(),
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
    }
    if write:
        _write_json_md(M5_READ_ONLY_AUDIT_PATH, payload, "M5 Read-Only Audit")
    return payload


def build_regression_suite(*, write: bool = True) -> dict[str, Any]:
    decisions = build_decision_object_model(write=False)
    planner = build_dirt_batch_planner(write=False)
    commits = build_safe_commit_candidate_pack(write=False)
    quarantine = build_quarantine_plan(write=False)
    replay = build_decision_replay(write=False)
    protocol = build_approval_protocol(write=False)
    read_only = build_read_only_audit(write=False)
    manifest = build_current_manifest(write=False)
    checks = [
        {"check": "decision_object_model", "status": decisions.get("status", "FAIL"), "detail": str(decisions.get("decision_count", 0))},
        {"check": "dirt_planner_has_warns_not_fail", "status": "PASS" if planner.get("status") == "PASS_WITH_WARNINGS" else "FAIL", "detail": planner.get("status", "")},
        {"check": "commit_pack_no_commit", "status": commits.get("status", "FAIL"), "detail": str(commits.get("candidate_count", 0))},
        {"check": "quarantine_plan_no_delete", "status": quarantine.get("status", "FAIL"), "detail": str(quarantine.get("candidate_count", 0))},
        {"check": "decision_replay_no_side_effect", "status": replay.get("status", "FAIL"), "detail": str(replay.get("decision_count", 0))},
        {"check": "approval_protocol_no_active_go", "status": "PASS" if protocol.get("protocol", {}).get("status") == "NO_ACTIVE_GO" else "FAIL", "detail": protocol.get("protocol", {}).get("status", "")},
        {"check": "read_only_audit", "status": read_only.get("status", "FAIL"), "detail": str(read_only.get("unexpected_mutation_count", 0))},
        {"check": "manifest_owner_m5", "status": "PASS" if manifest.get("owner") == "M5" else "FAIL", "detail": manifest.get("owner", "")},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
    }
    if write:
        _write_json_md(M5_REGRESSION_SUITE_PATH, payload, "M5 Regression Suite")
    return payload


def build_final_verification(*, write: bool = True) -> dict[str, Any]:
    decision_model = build_decision_object_model(write=False)
    planner = build_dirt_batch_planner(write=False)
    commits = build_safe_commit_candidate_pack(write=False)
    quarantine = build_quarantine_plan(write=False)
    replay = build_decision_replay(write=False)
    protocol = build_approval_protocol(write=False)
    contract = build_write_contract(write=False)
    domain = build_domain_summary(write=False)
    surface = build_current_surface(write=False)
    read_only = build_read_only_audit(write=False)
    regression = build_regression_suite(write=False)
    checks = [
        {"check": "final_truth_consistency", "status": "PASS" if read_current_truth().get("final_truth") == FINAL_TRUTH else "FAIL", "detail": FINAL_TRUTH},
        {"check": "decision_object_model", "status": decision_model.get("status", "FAIL"), "detail": str(decision_model.get("decision_count", 0))},
        {"check": "dirt_batch_planner", "status": "PASS" if planner.get("status") == "PASS_WITH_WARNINGS" else "FAIL", "detail": planner.get("status", "")},
        {"check": "safe_commit_candidate_pack", "status": commits.get("status", "FAIL"), "detail": str(commits.get("candidate_count", 0))},
        {"check": "quarantine_plan", "status": quarantine.get("status", "FAIL"), "detail": str(quarantine.get("candidate_count", 0))},
        {"check": "decision_replay", "status": replay.get("status", "FAIL"), "detail": str(replay.get("decision_count", 0))},
        {"check": "approval_protocol", "status": protocol.get("status", "FAIL"), "detail": protocol.get("protocol", {}).get("status", "")},
        {"check": "write_contract", "status": contract.get("status", "FAIL"), "detail": str(contract.get("fail_count", 0))},
        {"check": "domain_summary", "status": "PASS" if domain.get("status") == "PASS_WITH_WARNINGS" else "FAIL", "detail": domain.get("status", "")},
        {"check": "current_surface", "status": surface.get("status", "FAIL"), "detail": str(surface.get("fail_count", 0))},
        {"check": "read_only_audit", "status": read_only.get("status", "FAIL"), "detail": str(read_only.get("unexpected_mutation_count", 0))},
        {"check": "regression_suite", "status": regression.get("status", "FAIL"), "detail": str(regression.get("fail_count", 0))},
        {"check": "forbidden_action_count", "status": "PASS" if read_current_truth().get("forbidden_action_count") == 0 else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }
    if write:
        _write_json_md(M5_FINAL_VERIFICATION_PATH, payload, "M5 Final Verification")
        _write_json_md(VERIFICATION_SUMMARY_PATH, payload, "M5 Verification Summary")
    return payload


def build_final_state(*, write: bool = True) -> dict[str, Any]:
    if not write:
        return load_json(M5_FINAL_STATE_PATH, default={})
    build_grand_roadmap(write=True)
    build_decision_object_model(write=True)
    build_dirt_batch_planner(write=True)
    build_safe_commit_candidate_pack(write=True)
    build_quarantine_plan(write=True)
    build_decision_replay(write=True)
    build_approval_protocol(write=True)
    build_write_contract(write=True)
    build_domain_summary(write=True)
    build_current_surface(write=True)
    build_current_manifest(write=True)
    verification = build_final_verification(write=True)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS_WITH_WARNINGS" if verification.get("status") == "PASS" else "FAIL",
        "final_truth": FINAL_TRUTH,
        "roadmap_truth": ROADMAP_TRUTH,
        "current_owner": "M5",
        "previous_truth": PREVIOUS_TRUTH,
        "m5_blocks_completed": 6,
        "m6_next": "vivi_autonomy_kernel_local_reversible",
        "decision_object_model": safe_rel(M5_DECISION_OBJECT_MODEL_PATH),
        "dirt_batch_planner": safe_rel(M5_DIRT_BATCH_PLANNER_PATH),
        "safe_commit_candidate_pack": safe_rel(M5_SAFE_COMMIT_CANDIDATE_PACK_PATH),
        "quarantine_plan": safe_rel(M5_QUARANTINE_PLAN_PATH),
        "decision_replay": safe_rel(M5_DECISION_REPLAY_PATH),
        "approval_protocol": safe_rel(M5_OPERATOR_APPROVAL_PROTOCOL_PATH),
        "checks": verification.get("checks", []),
        "fail_count": verification.get("fail_count", 1),
        "forbidden_action_count": 0,
        "commit_executed": False,
        "cleanup_executed": False,
        "quarantine_executed": False,
        "push_executed": False,
        "delete_executed": False,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }
    write_json(M5_FINAL_STATE_PATH, payload)
    _write_json_md(M5_FINAL_STATE_PATH, payload, "M5 Final State")
    build_current_manifest(write=True)
    build_operator_brief(write=True)
    return payload


def _operator_brief_md(payload: dict[str, Any]) -> str:
    lines = [
        "# Project Intelligence Graph Operator Brief",
        "",
        f"- Generated: `{payload.get('generated_at', '')}`",
        f"- Overall: `{payload.get('overall_status', 'UNKNOWN')}`",
        f"- Build: `{payload.get('build_status', 'UNKNOWN')}`",
        f"- Decisions: `{payload.get('decision_status', 'UNKNOWN')}`",
        "",
        "## Do This Now",
        "",
    ]
    for item in payload.get("do_this_now", []):
        lines.append(f"- `{item.get('priority', '-')}` {item.get('text', '')}")
    lines.extend(["", "## Do Not", ""])
    for item in payload.get("do_not", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Safe Commands", ""])
    for command in payload.get("safe_commands", []):
        lines.append(f"- `{command}`")
    lines.extend(["", "## Status Lines", ""])
    for key, value in payload.get("status_lines", {}).items():
        lines.append(f"- `{key}`: `{value}`")
    return "\n".join(lines) + "\n"


def build_operator_brief(*, write: bool = True) -> dict[str, Any]:
    final_state = load_json(M5_FINAL_STATE_PATH, default={})
    verification = load_json(M5_FINAL_VERIFICATION_PATH, default={})
    decisions = load_json(M5_DECISION_OBJECT_MODEL_PATH, default={})
    planner = load_json(M5_DIRT_BATCH_PLANNER_PATH, default={})
    read_only = load_json(M5_READ_ONLY_AUDIT_PATH, default={})
    protocol = load_json(M5_OPERATOR_APPROVAL_PROTOCOL_PATH, default={})
    payload = {
        "schema_version": 3,
        "generated_at": now_iso(),
        "overall_status": "ACTION_REQUIRED",
        "build_status": "PASS" if verification.get("status") == "PASS" and final_state.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "WARN",
        "decision_status": "OPERATOR_GATED",
        "current_owner": "M5",
        "final_truth": FINAL_TRUTH,
        "do_this_now": [
            {"priority": "P1", "text": "Use the M5 Decision Board for commit, quarantine and dirt decisions; do not act from raw dirt lists."},
            {"priority": "P1", "text": "Require a fresh scoped Operator-Go before any local commit, cleanup or reversible quarantine move."},
            {"priority": "P2", "text": "Continue with M6 Vivi Autonomy Kernel as local, reversible work after M5 verifiers pass."},
            {"priority": "P2", "text": "Keep Jarvis/OpenJarvis parked as foreign scope unless a separate formal handoff changes that."},
        ],
        "do_not": [
            "Do not treat M5 candidate packs as permission to commit, push, delete or move files.",
            "Do not reuse old or broad Operator-Go for commits, cleanup or quarantine moves.",
            "Do not run push/delete/deploy/publish/public/payment/auth/external communication/real-data/Room16-Rerun without explicit scoped Operator-Go.",
            "Do not use Jarvis/OpenJarvis as DreamFactory current truth.",
        ],
        "safe_commands": [
            "python3 scripts/project_intelligence_graph/pig.py m5-final-state --json",
            "python3 scripts/project_intelligence_graph/pig.py m5-final-verification --json",
            "python3 scripts/project_intelligence_graph/pig.py m5-read-only-audit --json",
            "python3 scripts/project_intelligence_graph/pig.py m5-regression-suite --json",
            "python3 scripts/project_intelligence_graph/pig.py full-check --json",
            "python3 scripts/project_intelligence_graph/pig.py german-output-quality --json",
        ],
        "status_lines": {
            "m5_current_owner": final_state.get("current_owner", "M5"),
            "m5_final_truth": final_state.get("final_truth", FINAL_TRUTH),
            "m5_final_state_status": final_state.get("status", "UNKNOWN"),
            "m5_decision_count": decisions.get("decision_count", 0),
            "m5_commit_candidate_count": planner.get("source_commit_candidate_count", 0),
            "m5_quarantine_candidate_count": planner.get("generated_quarantine_candidate_count", 0),
            "m5_read_only_unexpected_mutations": read_only.get("unexpected_mutation_count", 0),
            "m5_active_operator_go": protocol.get("protocol", {}).get("operator_go_id"),
            "m6_next": final_state.get("m6_next", "vivi_autonomy_kernel_local_reversible"),
            "hard_gates": "closed",
            "commit_executed": False,
            "cleanup_executed": False,
            "quarantine_executed": False,
            "push_executed": False,
            "delete_executed": False,
            "runtime_action_executed": False,
            "external_action_executed": False,
            "irreversible_action_executed": False,
        },
    }
    if write:
        write_json(OPERATOR_BRIEF_PATH, payload)
        _write_text(OPERATOR_BRIEF_MD_PATH, _operator_brief_md(payload))
    return payload


M5_BUILDERS: dict[str, Callable[..., dict[str, Any]]] = {
    "grand-roadmap": build_grand_roadmap,
    "m5-decision-object-model": build_decision_object_model,
    "m5-dirt-batch-planner": build_dirt_batch_planner,
    "m5-safe-commit-candidate-pack": build_safe_commit_candidate_pack,
    "m5-quarantine-plan": build_quarantine_plan,
    "m5-decision-replay": build_decision_replay,
    "m5-approval-protocol": build_approval_protocol,
    "m5-write-contract": build_write_contract,
    "m5-domain-summary": build_domain_summary,
    "m5-current-surface": build_current_surface,
    "m5-current-manifest": build_current_manifest,
    "m5-read-only-audit": build_read_only_audit,
    "m5-regression-suite": build_regression_suite,
    "m5-final-verification": build_final_verification,
    "m5-final-state": build_final_state,
}

M1_CURRENT_COMMANDS = tuple(dict.fromkeys([*m4.M1_CURRENT_COMMANDS, *M5_BUILDERS.keys()]))


def run_m1_current_command(command: str, write: bool = True, profile: str | None = None) -> dict[str, Any]:
    if command in M5_BUILDERS:
        effective_write = False if command in AUDITOR_COMMANDS else write
        return M5_BUILDERS[command](write=effective_write)
    return m4.run_m1_current_command(command, write=write, profile=profile)


def m1_full_check_steps() -> list[dict[str, Any]]:
    commands = [
        "m5-decision-object-model",
        "m5-dirt-batch-planner",
        "m5-safe-commit-candidate-pack",
        "m5-quarantine-plan",
        "m5-decision-replay",
        "m5-approval-protocol",
        "m5-read-only-audit",
        "m5-regression-suite",
        "m5-final-verification",
        "m5-final-state",
    ]
    steps = []
    for command in commands:
        payload = run_m1_current_command(command, write=False)
        status = payload.get("status", "UNKNOWN")
        ok = is_passish(status)
        steps.append(
            {
                "name": command.replace("-", "_"),
                "status": "PASS" if ok else "FAIL",
                "returncode": 0 if ok else 1,
                "fail_count": payload.get("fail_count", 0),
                "runtime_action_executed": payload.get("runtime_action_executed", False),
                "external_action_executed": payload.get("external_action_executed", False),
            }
        )
    return steps


def m1_report_payload() -> dict[str, Any]:
    payload = m4.m1_report_payload()
    payload.update(
        {
            "m5_decision_object_model": load_json(M5_DECISION_OBJECT_MODEL_PATH, default={}),
            "m5_dirt_batch_planner": load_json(M5_DIRT_BATCH_PLANNER_PATH, default={}),
            "m5_safe_commit_candidate_pack": load_json(M5_SAFE_COMMIT_CANDIDATE_PACK_PATH, default={}),
            "m5_quarantine_plan": load_json(M5_QUARANTINE_PLAN_PATH, default={}),
            "m5_final_verification": load_json(M5_FINAL_VERIFICATION_PATH, default={}),
            "m5_final_state": load_json(M5_FINAL_STATE_PATH, default={}),
        }
    )
    return payload


def m1_compact_domain_lines(report: dict[str, Any]) -> list[str]:
    final_state = report.get("m5_final_state") or load_json(M5_FINAL_STATE_PATH, default={})
    planner = report.get("m5_dirt_batch_planner") or load_json(M5_DIRT_BATCH_PLANNER_PATH, default={})
    lines = ["## Current Kernel Summary", ""]
    lines.append(f"- M5 final: `{final_state.get('status', 'UNKNOWN')}` `{final_state.get('final_truth', FINAL_TRUTH)}`")
    lines.append("- Current owner: `M5`; M4 ist Vorgängerschicht, M3R/M2/M1/Bxx sind Provenance.")
    lines.append(f"- Decision kernel: `{planner.get('status', 'UNKNOWN')}` mit `{planner.get('batch_count', 0)}` planbaren Batches.")
    lines.append("- Operator cockpit: `outputs/project_intelligence_graph/current/operator_cockpit.md`.")
    lines.append("")
    return lines


def append_m1_full_check_lines(lines: list[str], report: dict[str, Any]) -> None:
    final_state = report.get("m5_final_state", {})
    planner = report.get("m5_dirt_batch_planner", {})
    decisions = report.get("m5_decision_object_model", {})
    lines.extend(["", "## M5 Decision Execution Kernel", ""])
    lines.append(f"- Final state: `{final_state.get('status', 'UNKNOWN')}` ({final_state.get('final_truth', FINAL_TRUTH)})")
    lines.append(f"- Active decisions: `{decisions.get('decision_count', 0)}`")
    lines.append(f"- Commit candidates: `{planner.get('source_commit_candidate_count', 0)}`")
    lines.append(f"- Quarantine candidates: `{planner.get('generated_quarantine_candidate_count', 0)}`")
    lines.append("- Runtime actions: `none`; commit, cleanup and quarantine remain fresh-Operator-Go gated.")
