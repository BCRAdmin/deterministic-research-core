"""Refresh local project verifier evidence needed by PIG surfaces."""

from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any


def _run(command: list[str], cwd: Path) -> dict[str, Any]:
    proc = subprocess.run(command, cwd=cwd, text=True, capture_output=True, check=False)
    return {
        "command": " ".join(command),
        "cwd": str(cwd),
        "returncode": proc.returncode,
        "status": "PASS" if proc.returncode == 0 else "FAIL",
        "stdout_tail": proc.stdout[-1000:],
        "stderr_tail": proc.stderr[-1000:],
    }


def refresh_project_verifier_evidence(workspace: Path) -> dict[str, Any]:
    steps: list[dict[str, Any]] = []

    room16_output = workspace / "company-dossier-lab/outputs/german_output_quality/room16_german_output_quality.json"
    room16_app = workspace / "company-dossier-lab/room16-app"
    if not room16_output.exists() and (room16_app / "package.json").exists():
        steps.append(_run(["npm", "run", "verify:german-output-quality"], room16_app))

    kanzlei = workspace / "kanzlei-ai-assist"
    python_bin = kanzlei / ".venv/bin/python"
    python_cmd = str(python_bin) if python_bin.exists() else "python3"
    kanzlei_outputs = [
        kanzlei / "outputs/verification/latest-verify-all.json",
        kanzlei / "outputs/product_readiness/latest-product-readiness.json",
        kanzlei / "outputs/synthetic_factory/latest-synthetic-factory.json",
    ]
    if kanzlei.exists() and not all(path.exists() for path in kanzlei_outputs):
        steps.append(_run([python_cmd, "scripts/verify/verify_all.py"], kanzlei))
        steps.append(_run([python_cmd, "scripts/verify/product_readiness.py"], kanzlei))
        steps.append(_run([python_cmd, "scripts/verify/synthetic_factory.py"], kanzlei))

    return {
        "status": "PASS" if all(step["status"] == "PASS" for step in steps) else "FAIL",
        "step_count": len(steps),
        "steps": steps,
        "runtime_action_executed": False,
        "external_action_executed": False,
    }
