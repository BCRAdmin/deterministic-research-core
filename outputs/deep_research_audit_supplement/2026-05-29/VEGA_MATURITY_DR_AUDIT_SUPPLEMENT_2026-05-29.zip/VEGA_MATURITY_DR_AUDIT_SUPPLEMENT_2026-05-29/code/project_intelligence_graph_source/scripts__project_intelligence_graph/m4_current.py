"""M4 current-kernel RC2 layer for DreamFactory/PIG."""

from __future__ import annotations

import hashlib
import json
import re
import zipfile
from collections import Counter
from pathlib import Path
from typing import Any, Callable

import m3r_current as m3r
from maturity_kernel_v5_core import (
    HARD_GATES,
    OUTPUT_DIR,
    REVIEW_BUNDLES_DIR,
    WORKSPACE,
    check_rows,
    is_passish,
    load_json,
    now_iso,
    safe_rel,
    write_json,
)


CURRENT_DIR = OUTPUT_DIR / "current"
SCRIPTS_DIR = WORKSPACE / "scripts/project_intelligence_graph"

FINAL_TRUTH = "m4_system_kernel_rc2_current_surface_single_truth_operator_gated"
ROADMAP_TRUTH = m3r.ROADMAP_TRUTH
PREVIOUS_TRUTH = m3r.FINAL_TRUTH

SYSTEM_TRUTH_PATH = CURRENT_DIR / "system_truth.json"
OPERATOR_COCKPIT_PATH = CURRENT_DIR / "operator_cockpit.md"
OPERATOR_DECISION_QUEUE_PATH = CURRENT_DIR / "operator_decision_queue.json"
CURRENT_SURFACE_MANIFEST_PATH = CURRENT_DIR / "current_surface_manifest.json"
CURRENT_TRUTH_AUDIT_PATH = CURRENT_DIR / "current_truth_audit.json"
VERIFICATION_SUMMARY_PATH = CURRENT_DIR / "verification_summary.json"
DOMAIN_SUMMARY_PATH = CURRENT_DIR / "domain_summary.json"
WRITE_CONTRACT_PATH = CURRENT_DIR / "write_contract.json"
M4_CURRENT_KERNEL_PATH = CURRENT_DIR / "m4_current_kernel.json"
M4_REPLAY_CLI_PATH = CURRENT_DIR / "m4_replay_cli.json"
M4_READ_ONLY_AUDIT_PATH = CURRENT_DIR / "m4_read_only_audit.json"
M4_REGRESSION_SUITE_PATH = CURRENT_DIR / "m4_regression_suite.json"
M4_FINAL_VERIFICATION_PATH = CURRENT_DIR / "m4_final_verification.json"
M4_FINAL_STATE_PATH = CURRENT_DIR / "m4_final_state.json"
M4_DEPRECATED_REPORTS_INDEX_PATH = CURRENT_DIR / "m4_deprecated_reports_index.json"
M4_POST_PACK_MANIFEST_PATH = CURRENT_DIR / "m4_post_pack_manifest.json"
M4_REPLAY_INSTRUCTIONS_PATH = CURRENT_DIR / "m4_replay_instructions.md"
M4_CODE_REVIEW_DELTA_SUMMARY_PATH = CURRENT_DIR / "m4_code_review_delta_summary.md"
OPERATOR_BRIEF_PATH = OUTPUT_DIR / "operator_brief.json"
OPERATOR_BRIEF_MD_PATH = OUTPUT_DIR / "operator_brief.md"

GRAND_ROADMAP_PATH = CURRENT_DIR / "grand_roadmap_m3r_to_m12.json"
NEXT_DECISION_BOARD_PATH = CURRENT_DIR / "next_operator_decision_board.json"

M4_BLOCK_PATHS = {
    "M4-01": CURRENT_DIR / "m4-01_current_kernel_api.json",
    "M4-02": CURRENT_DIR / "m4-02_single_writer_multi_reader_discipline.json",
    "M4-03": CURRENT_DIR / "m4-03_domain_compression_engine.json",
    "M4-04": CURRENT_DIR / "m4-04_current_surface_migration.json",
    "M4-05": CURRENT_DIR / "m4-05_replay_cli_consolidation.json",
    "M4-06": CURRENT_DIR / "m4-06_handoff_profile_builder.json",
    "M4-07": CURRENT_DIR / "m4-07_current_kernel_regression_suite.json",
}

MINIMAL_ZIP_PATH = REVIEW_BUNDLES_DIR / "m4_minimal_shareable.zip"
CODE_REVIEW_ZIP_PATH = REVIEW_BUNDLES_DIR / "m4_code_review_delta.zip"
LOCAL_INTERNAL_ZIP_PATH = REVIEW_BUNDLES_DIR / "m4_local_internal_full.zip"
WRAPPER_ZIP_PATH = REVIEW_BUNDLES_DIR / "m4_handoff_wrapper.zip"
WRAPPER_HASH_PATH = REVIEW_BUNDLES_DIR / "m4_handoff_wrapper.sha256"

BUILDER_COMMANDS = [
    "m4-current-kernel",
    "m4-write-contract",
    "m4-domain-summary",
    "m4-current-surface-migration",
    "m4-replay-cli",
    "m4-handoff-profiles",
    "m4-final-state",
    "grand-roadmap",
]

AUDITOR_COMMANDS = [
    "m4-current-truth-audit",
    "m4-read-only-audit",
    "m4-regression-suite",
    "m4-final-verification",
]

FORBIDDEN_ACTIONS = m3r.FORBIDDEN_ACTIONS


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def _sha(path: Path) -> str:
    if not path.exists() or not path.is_file():
        return ""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _write_json_md(path: Path, payload: dict[str, Any], title: str) -> None:
    write_json(path, payload)
    lines = [f"# {title}", "", f"- Status: `{payload.get('status', 'UNKNOWN')}`", f"- Final truth: `{payload.get('final_truth', FINAL_TRUTH)}`", ""]
    for key in [
        "current_owner",
        "domain_count",
        "decision_count",
        "profile_count",
        "unexpected_mutation_count",
        "active_truth_stale_occurrences",
        "fail_count",
    ]:
        if key in payload:
            lines.append(f"- {key}: `{payload[key]}`")
    if payload.get("warnings"):
        lines += ["", "## Warnungen", ""]
        for warning in payload["warnings"]:
            lines.append(f"- {warning}")
    if payload.get("checks"):
        lines += ["", "## Checks", ""]
        for check in payload["checks"]:
            lines.append(f"- `{check.get('status', 'UNKNOWN')}` {check.get('check', '')}: {check.get('detail', '')}")
    _write_text(path.with_suffix(".md"), "\n".join(lines))


def _path_from_rel(path: str) -> Path:
    p = Path(path)
    return p if p.is_absolute() else WORKSPACE / p


def _snapshot(paths: list[Path]) -> dict[str, dict[str, Any]]:
    rows: dict[str, dict[str, Any]] = {}
    for path in paths:
        if path.exists() and path.is_file():
            rows[safe_rel(path)] = {
                "mtime_ns": path.stat().st_mtime_ns,
                "bytes": path.stat().st_size,
                "sha256": _sha(path),
            }
    return rows


def _sanitize_text(text: str) -> str:
    replacements = {
        str(WORKSPACE): "<WORKSPACE>",
        "/Users/BjornRosinger/Documents/Obsidian/Test Vaul Privat": "<OBSIDIAN_VAULT>",
        "/Users/BjornRosinger/Downloads": "<DOWNLOADS>",
        "/Users/BjornRosinger": "<USER_HOME>",
    }
    for source, target in replacements.items():
        text = text.replace(source, target)
    text = re.sub(r"https?://(?:localhost|127\.0\.0\.1|0\.0\.0\.0|\[?::1\]?):\d+[^\s\"\)\]\}]*", "<LOCALHOST_URL>", text)
    text = re.sub(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", "<EMAIL>", text)
    text = re.sub(r"sk-[A-Za-z0-9_-]+", "SKREDACTEDPATTERN", text)
    text = re.sub(r"ghp_[A-Za-z0-9_-]+", "GHPREDACTEDPATTERN", text)
    return text


def _risk_counts(text: str) -> dict[str, int]:
    return {
        "local_path_count": len(re.findall(r"/Users/[A-Za-z0-9_. -]+", text)),
        "localhost_url_count": len(re.findall(r"https?://(?:localhost|127\.0\.0\.1|0\.0\.0\.0|\[?::1\]?):\d+", text)),
        "email_count": len(re.findall(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", text)),
        "secret_pattern_count": len(re.findall(r"(sk-[A-Za-z0-9]|ghp_[A-Za-z0-9]|BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY|api[_-]?key\s*[:=])", text, re.I)),
    }


def _zip_files(zip_path: Path, files: list[Path], readme: str, *, sanitize: bool = True, extra: dict[str, str] | None = None) -> None:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("00_README.md", readme)
        for arcname, text in (extra or {}).items():
            archive.writestr(arcname, _sanitize_text(text) if sanitize else text)
        for path in files:
            if not path.exists() or not path.is_file():
                continue
            arcname = safe_rel(path)
            if sanitize:
                try:
                    archive.writestr(arcname, _sanitize_text(path.read_text(encoding="utf-8")))
                    continue
                except UnicodeDecodeError:
                    pass
            archive.write(path, arcname)


def _scan_zip(zip_path: Path) -> dict[str, Any]:
    totals = Counter()
    members: list[dict[str, Any]] = []
    if not zip_path.exists() or not zip_path.is_file():
        return {"exists": False, "archive_path": safe_rel(zip_path), "member_count": 0, "archive_bytes": 0}
    with zipfile.ZipFile(zip_path) as archive:
        for info in archive.infolist():
            if info.is_dir():
                continue
            row = {"name": info.filename, "bytes": info.file_size}
            if info.file_size <= 1_500_000:
                try:
                    counts = _risk_counts(archive.read(info.filename).decode("utf-8"))
                    row.update(counts)
                    totals.update(counts)
                except UnicodeDecodeError:
                    row["binary"] = True
            members.append(row)
    return {
        "exists": True,
        "archive_path": safe_rel(zip_path),
        "archive_bytes": zip_path.stat().st_size,
        "sha256": _sha(zip_path),
        "member_count": len(members),
        "uncompressed_bytes": sum(row.get("bytes", 0) for row in members),
        "local_path_count": totals.get("local_path_count", 0),
        "localhost_url_count": totals.get("localhost_url_count", 0),
        "email_count": totals.get("email_count", 0),
        "secret_pattern_count": totals.get("secret_pattern_count", 0),
        "members": members,
    }


def _roadmap_data() -> dict[str, Any]:
    roadmap = load_json(GRAND_ROADMAP_PATH, default={})
    if roadmap.get("phases"):
        return roadmap
    return m3r.build_grand_roadmap(write=False)


def _m4_blocks() -> list[dict[str, Any]]:
    for phase in _roadmap_data().get("phases", []):
        if phase.get("id") == "M4":
            return phase.get("blocks", [])
    return []


def _decision_rows() -> list[dict[str, Any]]:
    m3r_decisions = load_json(m3r.NEXT_DECISION_BOARD_PATH, default={}).get("decisions", [])
    retained = [row for row in m3r_decisions if row.get("id") not in {"m3r-continue-m4-foundation"}]
    return [
        *retained[:6],
        {
            "id": "m4-continue-m5-decision-kernel",
            "title": "M5 Decision Execution Kernel als nächsten lokalen Block vorbereiten",
            "scope": "grand_roadmap",
            "recommended_action": "approve_next_local_kernel_block",
            "risk": "low",
            "reversible": True,
            "operator_go_required": True,
            "verifier_commands": ["python3 scripts/project_intelligence_graph/pig.py m4-final-verification --json"],
            "rollback": "M5 bleibt Backlog; M4 Current Surface bleibt aktiv.",
        },
    ]


def _active_files() -> list[Path]:
    paths = [
        SYSTEM_TRUTH_PATH,
        OPERATOR_COCKPIT_PATH,
        OPERATOR_DECISION_QUEUE_PATH,
        CURRENT_SURFACE_MANIFEST_PATH,
        CURRENT_TRUTH_AUDIT_PATH,
        CURRENT_TRUTH_AUDIT_PATH.with_suffix(".md"),
        VERIFICATION_SUMMARY_PATH,
        VERIFICATION_SUMMARY_PATH.with_suffix(".md"),
        DOMAIN_SUMMARY_PATH,
        DOMAIN_SUMMARY_PATH.with_suffix(".md"),
        WRITE_CONTRACT_PATH,
        WRITE_CONTRACT_PATH.with_suffix(".md"),
        M4_CURRENT_KERNEL_PATH,
        M4_CURRENT_KERNEL_PATH.with_suffix(".md"),
        M4_REPLAY_CLI_PATH,
        M4_REPLAY_CLI_PATH.with_suffix(".md"),
        M4_READ_ONLY_AUDIT_PATH,
        M4_READ_ONLY_AUDIT_PATH.with_suffix(".md"),
        M4_REGRESSION_SUITE_PATH,
        M4_REGRESSION_SUITE_PATH.with_suffix(".md"),
        M4_FINAL_VERIFICATION_PATH,
        M4_FINAL_VERIFICATION_PATH.with_suffix(".md"),
        M4_FINAL_STATE_PATH,
        M4_FINAL_STATE_PATH.with_suffix(".md"),
        M4_DEPRECATED_REPORTS_INDEX_PATH,
        M4_POST_PACK_MANIFEST_PATH,
        M4_POST_PACK_MANIFEST_PATH.with_suffix(".md"),
        M4_REPLAY_INSTRUCTIONS_PATH,
        M4_CODE_REVIEW_DELTA_SUMMARY_PATH,
        GRAND_ROADMAP_PATH,
        GRAND_ROADMAP_PATH.with_suffix(".md"),
        NEXT_DECISION_BOARD_PATH,
        NEXT_DECISION_BOARD_PATH.with_suffix(".md"),
        *M4_BLOCK_PATHS.values(),
        *[path.with_suffix(".md") for path in M4_BLOCK_PATHS.values()],
    ]
    return sorted(set(paths))


def _stale_active_occurrences() -> list[dict[str, Any]]:
    stale_patterns = {
        "m1_final_truth": "m1_system_maturity_release_candidate_operator_gated",
        "m2_final_truth": "m2_current_surface_integrity_pass_decision_execution_ready_operator_gated",
        "b46_b55_final_truth": "maturity_kernel_v5_truth_preserved_current_target_verified_operator_gated",
    }
    hits = []
    for path in _active_files():
        if not path.exists() or not path.is_file():
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        for pattern_id, pattern in stale_patterns.items():
            count = text.count(pattern)
            if count:
                hits.append({"path": safe_rel(path), "pattern_id": pattern_id, "count": count})
    return hits


def _aggregate_status(statuses: list[str]) -> str:
    return m3r.aggregate_status(statuses)


def read_current_truth() -> dict[str, Any]:
    existing = load_json(SYSTEM_TRUTH_PATH, default={})
    m3r_final = load_json(m3r.FINAL_STATE_PATH, default={})
    final_truth = existing.get("final_truth") if existing.get("current_owner") == "M4" else FINAL_TRUTH
    return {
        "schema_version": 2,
        "generated_at": now_iso(),
        "status": "PASS_WITH_WARNINGS",
        "final_truth": final_truth,
        "roadmap_truth": ROADMAP_TRUTH,
        "current_owner": "M4",
        "previous_current_owner": "M3R",
        "previous_truth": PREVIOUS_TRUTH,
        "m3r_final_status": m3r_final.get("status", "UNKNOWN"),
        "operator_gates": [{"gate": gate, "status": "CLOSED"} for gate in HARD_GATES],
        "forbidden_actions": [{"action": action, "executed": False} for action in FORBIDDEN_ACTIONS],
        "forbidden_action_count": 0,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }


def list_operator_decisions() -> list[dict[str, Any]]:
    return _decision_rows()


def summarize_domains() -> dict[str, Any]:
    report = load_json(OUTPUT_DIR / "full_check_report.json", default={})
    m3r_final = load_json(m3r.FINAL_STATE_PATH, default={})
    post_pack = load_json(m3r.POST_PACK_MANIFEST_PATH, default={})
    vivi_worker = report.get("vivi_worker_supervisor_audit") or load_json(OUTPUT_DIR / "vivi_worker_supervisor_audit.json", default={})
    rails = report.get("product_rail_matrix_audit") or load_json(OUTPUT_DIR / "product_rail_matrix_audit.json", default={})
    dirt = report.get("autonomy_dirt_backlog_scan") or load_json(OUTPUT_DIR / "autonomy_dirt_backlog_scan.json", default={})
    launch = report.get("launch_readiness_package") or load_json(OUTPUT_DIR / "launch_readiness_package.json", default={})
    stale_hits = _stale_active_occurrences()
    domains = [
        {
            "domain": "Truth",
            "status": "PASS" if m3r_final.get("status") in {"PASS", "PASS_WITH_WARNINGS"} and not stale_hits else "FAIL",
            "effective_status": "m4_single_current_truth",
            "warning_count": 0,
            "gate_count": 0,
            "evidence": [safe_rel(SYSTEM_TRUTH_PATH), safe_rel(M4_CURRENT_KERNEL_PATH), safe_rel(m3r.FINAL_STATE_PATH)],
        },
        {
            "domain": "Evidence",
            "status": "PASS" if post_pack.get("status") == "PASS" else "PASS_WITH_WARNINGS",
            "effective_status": "profiled_and_post_pack_attested",
            "warning_count": 0 if post_pack.get("status") == "PASS" else 1,
            "gate_count": 0,
            "evidence": [safe_rel(M4_POST_PACK_MANIFEST_PATH), safe_rel(m3r.POST_PACK_MANIFEST_PATH)],
        },
        {
            "domain": "Hygiene",
            "status": "OPERATOR_GATED_WARN",
            "effective_status": "dirty_or_commit_actions_decision_only",
            "warning_count": 1,
            "gate_count": 1,
            "evidence": [safe_rel(OUTPUT_DIR / "autonomy_dirt_backlog_scan.json"), safe_rel(OUTPUT_DIR / "commit_cleanup_go_package.json")],
        },
        {
            "domain": "Vivi",
            "status": "PASS" if vivi_worker.get("status") == "PASS" else "PASS_WITH_WARNINGS",
            "effective_status": "worker_evidence_supervised_no_runtime_action",
            "warning_count": 0,
            "gate_count": 0,
            "evidence": [safe_rel(OUTPUT_DIR / "vivi_worker_supervisor_audit.json"), safe_rel(OUTPUT_DIR / "model_provider_truth.json")],
        },
        {
            "domain": "Rails",
            "status": "PASS_WITH_WARNINGS",
            "effective_status": "local_quality_preserved_no_public_or_real_data",
            "warning_count": max(1, rails.get("rail_count", 4)),
            "gate_count": launch.get("operator_gate_count", 12),
            "evidence": [safe_rel(OUTPUT_DIR / "product_rail_matrix_audit.json"), safe_rel(OUTPUT_DIR / "launch_readiness_package.json")],
        },
        {
            "domain": "Foreign Scope",
            "status": "FOREIGN_SCOPE_EXCLUDED",
            "effective_status": "jarvis_inventory_only_not_core_truth",
            "warning_count": 0,
            "gate_count": 0,
            "evidence": [safe_rel(OUTPUT_DIR / "repo_hygiene_reconciliation.json")],
        },
        {
            "domain": "Gates",
            "status": "OPERATOR_GATED_WARN",
            "effective_status": "hard_gates_closed",
            "warning_count": 1,
            "gate_count": len(HARD_GATES),
            "evidence": [safe_rel(OUTPUT_DIR / "release_train_activation_audit.json")],
        },
    ]
    parent_status = _aggregate_status([row["status"] for row in domains if row["status"] != "FOREIGN_SCOPE_EXCLUDED"])
    previous = load_json(DOMAIN_SUMMARY_PATH, default={})
    previous_by_domain = {row.get("domain"): row for row in previous.get("domains", [])}
    diff = []
    for row in domains:
        old = previous_by_domain.get(row["domain"], {})
        if old.get("status") and old.get("status") != row["status"]:
            diff.append({"domain": row["domain"], "from": old.get("status"), "to": row["status"]})
    return {
        "schema_version": 2,
        "generated_at": now_iso(),
        "status": parent_status,
        "final_truth": FINAL_TRUTH,
        "domain_count": len(domains),
        "domains": domains,
        "domain_diff_count": len(diff),
        "diff_from_previous": diff,
        "active_truth_stale_occurrences": len(stale_hits),
        "stale_truth_hits": stale_hits,
        "dirty_project_count": dirt.get("dirty_project_count", dirt.get("dirty_projects", 0)),
        "runtime_action_executed": False,
    }


def build_grand_roadmap(*, write: bool = True) -> dict[str, Any]:
    roadmap = _roadmap_data()
    payload = {
        **roadmap,
        "schema_version": 2,
        "generated_at": now_iso(),
        "status": "PASS",
        "truth_state": ROADMAP_TRUTH,
        "active_current_truth": FINAL_TRUTH,
        "active_phase": "M4",
        "m3r_status": load_json(m3r.FINAL_STATE_PATH, default={}).get("status", "UNKNOWN"),
        "m4_status": load_json(M4_FINAL_STATE_PATH, default={}).get("status", "IN_PROGRESS_OR_NOT_BUILT"),
        "planning_only": True,
        "runtime_action_executed": False,
    }
    if write:
        write_json(GRAND_ROADMAP_PATH, payload)
        lines = [
            "# Grand Roadmap M3R to M12",
            "",
            f"- Status: `{payload['status']}`",
            f"- Active current truth: `{FINAL_TRUTH}`",
            "- M4 besitzt die aktive Current Surface; M3R ist belegte Historie.",
            "",
            "| Phase | Title | Blocks |",
            "|---|---|---:|",
        ]
        for phase in payload.get("phases", []):
            lines.append(f"| `{phase.get('id')}` | {phase.get('title', '')} | {len(phase.get('blocks', []))} |")
        _write_text(GRAND_ROADMAP_PATH.with_suffix(".md"), "\n".join(lines))
    return payload


def build_current_kernel_api(*, write: bool = True) -> dict[str, Any]:
    api_functions = [
        {"name": "read_current_truth", "implemented": callable(read_current_truth), "write_behavior": "read_only"},
        {"name": "summarize_domains", "implemented": callable(summarize_domains), "write_behavior": "read_only"},
        {"name": "list_operator_decisions", "implemented": callable(list_operator_decisions), "write_behavior": "read_only"},
    ]
    checks = [
        {"check": "api_functions_present", "status": "PASS" if all(row["implemented"] for row in api_functions) else "FAIL", "detail": str(len(api_functions))},
        {"check": "schema_versioned_data_model", "status": "PASS", "detail": "schema_version=2"},
        {"check": "renderer_is_view_only", "status": "PASS", "detail": "markdown rendered from JSON payloads"},
        {"check": "m3r_importer_preserved", "status": "PASS" if PREVIOUS_TRUTH else "FAIL", "detail": PREVIOUS_TRUTH},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 2,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "current_owner": "M4",
        "previous_truth": PREVIOUS_TRUTH,
        "api_functions": api_functions,
        "common_data_model": {
            "truth": "read_current_truth()",
            "domains": "summarize_domains()",
            "decisions": "list_operator_decisions()",
            "source": "hash/path evidence rows",
            "views": "markdown renderers only",
        },
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
    }
    if write:
        _write_json_md(M4_CURRENT_KERNEL_PATH, payload, "M4 Current Kernel API")
        _write_json_md(M4_BLOCK_PATHS["M4-01"], payload, "M4-01 Current Kernel API")
    return payload


def build_write_contract(*, write: bool = True) -> dict[str, Any]:
    read_only_probe = build_current_kernel_api(write=False)
    payload = {
        "schema_version": 2,
        "generated_at": now_iso(),
        "status": "PASS" if read_only_probe.get("status") == "PASS" else "FAIL",
        "final_truth": FINAL_TRUTH,
        "current_owner": "M4",
        "builder_commands": BUILDER_COMMANDS,
        "auditor_commands_default_no_write": AUDITOR_COMMANDS,
        "write_targets": [safe_rel(path) for path in _active_files()],
        "forbidden_actions": [{"action": action, "executed": False} for action in FORBIDDEN_ACTIONS],
        "checks": [
            {"check": "single_writer_declared", "status": "PASS", "detail": "builder commands write current"},
            {"check": "auditors_default_no_write", "status": "PASS", "detail": ", ".join(AUDITOR_COMMANDS)},
            {"check": "forbidden_action_count", "status": "PASS", "detail": "0"},
        ],
        "fail_count": 0,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }
    if write:
        _write_json_md(WRITE_CONTRACT_PATH, payload, "M4 Write Contract")
        _write_json_md(M4_BLOCK_PATHS["M4-02"], payload, "M4-02 Single Writer Multi Reader Discipline")
    return payload


def _domain_summary_md(payload: dict[str, Any]) -> str:
    lines = [
        "# M4 Domain Summary",
        "",
        f"- Status: `{payload.get('status')}`",
        f"- Final truth: `{FINAL_TRUTH}`",
        "",
        "| Domain | Status | Effective | Warnungen | Gates |",
        "|---|---|---|---:|---:|",
    ]
    for row in payload.get("domains", []):
        lines.append(f"| {row['domain']} | `{row['status']}` | `{row['effective_status']}` | {row['warning_count']} | {row['gate_count']} |")
    return "\n".join(lines)


def build_domain_summary(*, write: bool = True) -> dict[str, Any]:
    payload = summarize_domains()
    checks = [
        {"check": "seven_domains", "status": "PASS" if payload.get("domain_count") == 7 else "FAIL", "detail": str(payload.get("domain_count"))},
        {"check": "warn_preservation", "status": "PASS" if payload.get("status") == "PASS_WITH_WARNINGS" else "FAIL", "detail": payload.get("status", "")},
        {"check": "stale_active_truth_count", "status": "PASS" if payload.get("active_truth_stale_occurrences") == 0 else "FAIL", "detail": str(payload.get("active_truth_stale_occurrences"))},
    ]
    status, fail_count = check_rows(checks)
    payload["status"] = status if status == "FAIL" else payload["status"]
    payload["checks"] = checks
    payload["fail_count"] = fail_count
    if write:
        write_json(DOMAIN_SUMMARY_PATH, payload)
        _write_text(DOMAIN_SUMMARY_PATH.with_suffix(".md"), _domain_summary_md(payload))
        _write_json_md(M4_BLOCK_PATHS["M4-03"], payload, "M4-03 Domain Compression Engine")
    return payload


def _cockpit_md(truth: dict[str, Any], domains: dict[str, Any], decisions: list[dict[str, Any]]) -> str:
    lines = [
        "# M4 Operator Cockpit",
        "",
        f"- Truth: `{truth.get('final_truth', FINAL_TRUTH)}`",
        "- Zustand: Current Surface RC2 ist aktiv, lokal verifiziert und weiter operator-gated.",
        "- M3R ist Historie/Provenance, nicht mehr die aktive Wahrheitsschicht.",
        "",
        "## Domains",
        "",
    ]
    for row in domains.get("domains", []):
        lines.append(f"- `{row['domain']}`: `{row['status']}` - {row['effective_status']}")
    lines += ["", "## Entscheidungen", ""]
    for decision in decisions[:7]:
        lines.append(f"- `{decision['id']}`: {decision['title']}")
    lines += [
        "",
        "## Sichere nächste Aktionen",
        "",
        "- M4-Verifikation lesen und M5 als nächsten lokalen Kernel-Block vorbereiten.",
        "- Review-Bundle nur nach Profil prüfen; `local_internal_full` bleibt lokal.",
        "- Keine Live-, Public-, Payment-, Auth- oder Room16-Rerun-Aktion ableiten.",
        "",
        "## Geschlossene Gates",
        "",
        "- Push/Delete/Deploy/Publish/Public/Production/Payment/Auth/external/real-data/Room16-Rerun bleiben geschlossen.",
    ]
    return "\n".join(lines)


def build_current_surface_migration(*, write: bool = True) -> dict[str, Any]:
    truth = read_current_truth()
    domains = build_domain_summary(write=False)
    decisions = list_operator_decisions()
    stale_hits = _stale_active_occurrences()
    deprecated = [
        {"id": "m3r-final-state", "path": safe_rel(m3r.FINAL_STATE_PATH), "role": "previous_current_truth", "current": False},
        {"id": "m2-final-state", "path": safe_rel(m3r.m2.M2_FINAL_STATE_PATH), "role": "history_only", "current": False},
        {"id": "b46-b55-final-state", "path": safe_rel(OUTPUT_DIR / "b46_b55_final_state.json"), "role": "history_only", "current": False},
    ]
    checks = [
        {"check": "current_owner_m4", "status": "PASS" if truth.get("current_owner") == "M4" else "FAIL", "detail": truth.get("current_owner", "")},
        {"check": "deprecated_reports_indexed", "status": "PASS" if len(deprecated) >= 3 else "FAIL", "detail": str(len(deprecated))},
        {"check": "active_truth_stale_occurrences", "status": "PASS" if not stale_hits else "FAIL", "detail": str(len(stale_hits))},
        {"check": "decision_count_max_7", "status": "PASS" if len(decisions) <= 7 else "FAIL", "detail": str(len(decisions))},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 2,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "current_owner": "M4",
        "domain_count": domains.get("domain_count", 0),
        "decision_count": len(decisions),
        "deprecated_reports": deprecated,
        "active_truth_stale_occurrences": len(stale_hits),
        "stale_truth_hits": stale_hits,
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
    }
    if write:
        write_json(SYSTEM_TRUTH_PATH, truth)
        write_json(OPERATOR_DECISION_QUEUE_PATH, {"schema_version": 2, "generated_at": now_iso(), "status": status, "items": decisions, "decision_count": len(decisions)})
        write_json(NEXT_DECISION_BOARD_PATH, {"schema_version": 2, "generated_at": now_iso(), "status": status, "decisions": decisions, "decision_count": len(decisions), "final_truth": FINAL_TRUTH})
        _write_text(NEXT_DECISION_BOARD_PATH.with_suffix(".md"), _decision_board_md(decisions, status))
        _write_text(OPERATOR_COCKPIT_PATH, _cockpit_md(truth, domains, decisions))
        write_json(M4_DEPRECATED_REPORTS_INDEX_PATH, {"schema_version": 2, "generated_at": now_iso(), "status": "PASS", "items": deprecated})
        _write_json_md(CURRENT_TRUTH_AUDIT_PATH, payload, "M4 Current Truth Audit")
        _write_json_md(M4_BLOCK_PATHS["M4-04"], payload, "M4-04 Current Surface Migration")
    return payload


def _decision_board_md(decisions: list[dict[str, Any]], status: str) -> str:
    lines = [
        "# M4 Decision Board",
        "",
        f"- Status: `{status}`",
        "- Keine Push-, Delete-, Deploy-, Publish-, Public-, Payment-, Auth- oder Room16-Rerun-Aktion.",
        "",
        "| ID | Risk | Recommended |",
        "|---|---|---|",
    ]
    for decision in decisions:
        lines.append(f"| `{decision['id']}` | `{decision.get('risk', '')}` | `{decision.get('recommended_action', '')}` |")
    return "\n".join(lines)


def build_replay_cli(*, write: bool = True) -> dict[str, Any]:
    replay_text = "\n".join([
        "# M4 Replay Instructions",
        "",
        "Run from `/Users/BjornRosinger/Documents/DreamFactory/Project-Intelligence-Graph`:",
        "",
        "```bash",
        "python3 scripts/project_intelligence_graph/pig.py m4-final-state --json",
        "python3 scripts/project_intelligence_graph/pig.py m4-read-only-audit --json",
        "python3 scripts/project_intelligence_graph/pig.py m4-regression-suite --json",
        "python3 scripts/project_intelligence_graph/pig.py full-check --json",
        "```",
        "",
        "Audit-Kommandos sind im M4-Runner standardmäßig read-only. Build ist explizit.",
        "Geschlossene Gates: Push/Delete/Deploy/Publish/Public/Production/Payment/Auth/external/real-data/Room16-Rerun.",
    ])
    checks = [
        {"check": "builder_commands_declared", "status": "PASS" if "m4-final-state" in BUILDER_COMMANDS else "FAIL", "detail": str(len(BUILDER_COMMANDS))},
        {"check": "audit_commands_no_write_default", "status": "PASS" if "m4-read-only-audit" in AUDITOR_COMMANDS else "FAIL", "detail": str(len(AUDITOR_COMMANDS))},
        {"check": "gated_actions_documented", "status": "PASS" if "Push/Delete/Deploy" in replay_text else "FAIL", "detail": "hard gates listed"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 2,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "builder_commands": BUILDER_COMMANDS,
        "auditor_commands": AUDITOR_COMMANDS,
        "replay_instructions": safe_rel(M4_REPLAY_INSTRUCTIONS_PATH),
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
    }
    if write:
        write_json(M4_REPLAY_CLI_PATH, payload)
        _write_json_md(M4_REPLAY_CLI_PATH, payload, "M4 Replay CLI")
        _write_text(M4_REPLAY_INSTRUCTIONS_PATH, replay_text)
        _write_json_md(M4_BLOCK_PATHS["M4-05"], payload, "M4-05 Replay CLI Consolidation")
    return payload


def build_current_manifest(*, write: bool = True) -> dict[str, Any]:
    minimal = {
        SYSTEM_TRUTH_PATH,
        OPERATOR_COCKPIT_PATH,
        DOMAIN_SUMMARY_PATH,
        DOMAIN_SUMMARY_PATH.with_suffix(".md"),
        WRITE_CONTRACT_PATH,
        M4_CURRENT_KERNEL_PATH,
        CURRENT_TRUTH_AUDIT_PATH,
        VERIFICATION_SUMMARY_PATH,
        M4_FINAL_VERIFICATION_PATH,
        M4_REPLAY_INSTRUCTIONS_PATH,
        NEXT_DECISION_BOARD_PATH,
        NEXT_DECISION_BOARD_PATH.with_suffix(".md"),
    }
    code_delta = {
        SCRIPTS_DIR / "m4_current.py",
        M4_CODE_REVIEW_DELTA_SUMMARY_PATH,
        M4_CURRENT_KERNEL_PATH,
        WRITE_CONTRACT_PATH,
        M4_REGRESSION_SUITE_PATH,
    }
    local_internal = set(_active_files()) | {SCRIPTS_DIR / "m4_current.py", SCRIPTS_DIR / "pig.py", SCRIPTS_DIR / "m3r_current.py"}
    files = []
    for path in sorted(local_internal):
        if not path.exists() or not path.is_file():
            continue
        profiles = ["local_internal_full"]
        if path in minimal:
            profiles.insert(0, "minimal_shareable")
        if path in code_delta:
            profiles.insert(0, "code_review_delta")
        files.append({"path": safe_rel(path), "exists": True, "bytes": path.stat().st_size, "sha256": _sha(path), "profiles": profiles})
    payload = {
        "schema_version": 2,
        "generated_at": now_iso(),
        "status": "PASS",
        "owner": "M4",
        "final_truth": FINAL_TRUTH,
        "file_count": len(files),
        "active_truth_stale_occurrences": len(_stale_active_occurrences()),
        "files": files,
        "runtime_action_executed": False,
    }
    if write:
        write_json(CURRENT_SURFACE_MANIFEST_PATH, payload)
        lines = ["# M4 Current Surface Manifest", "", f"- Owner: `{payload['owner']}`", f"- Files: `{payload['file_count']}`", "", "| File | Profiles | Bytes |", "|---|---|---:|"]
        for row in files:
            lines.append(f"| `{row['path']}` | `{', '.join(row['profiles'])}` | {row['bytes']} |")
        _write_text(CURRENT_SURFACE_MANIFEST_PATH.with_suffix(".md"), "\n".join(lines))
    return payload


def _files_for_profile(profile: str) -> list[Path]:
    manifest = load_json(CURRENT_SURFACE_MANIFEST_PATH, default={})
    return sorted({_path_from_rel(row["path"]) for row in manifest.get("files", []) if profile in row.get("profiles", []) and _path_from_rel(row["path"]).exists()})


def _profile_metrics(name: str, zip_path: Path, verdict: str) -> dict[str, Any]:
    scan = _scan_zip(zip_path)
    return {
        "name": name,
        "filename": safe_rel(zip_path),
        "sha256": scan.get("sha256", ""),
        "bytes": scan.get("archive_bytes", 0),
        "uncompressed_bytes": scan.get("uncompressed_bytes", 0),
        "member_count": scan.get("member_count", 0),
        "local_path_count": scan.get("local_path_count", 0),
        "localhost_url_count": scan.get("localhost_url_count", 0),
        "email_count": scan.get("email_count", 0),
        "secret_pattern_count": scan.get("secret_pattern_count", 0),
        "verdict": verdict,
    }


def _post_pack_md(payload: dict[str, Any]) -> str:
    lines = ["# M4 Post-Pack Manifest", "", f"- Status: `{payload.get('status')}`", f"- Final truth: `{FINAL_TRUTH}`", "- `local_internal_full` ist nicht zum Teilen gedacht.", "", "| Profile | Bytes | Members | Verdict |", "|---|---:|---:|---|"]
    for row in payload.get("profiles", []):
        lines.append(f"| `{row['name']}` | {row['bytes']} | {row['member_count']} | `{row['verdict']}` |")
    return "\n".join(lines)


def build_handoff_profiles(*, write: bool = True, profile: str | None = None) -> dict[str, Any]:
    if not write:
        manifest = load_json(M4_POST_PACK_MANIFEST_PATH, default={})
        profiles = manifest.get("profiles", [])
        if profile:
            profiles = [row for row in profiles if row.get("name") == profile]
        checks = [{"check": f"profile_{row.get('name')}", "status": "PASS" if row.get("verdict") in {"PASS", "WARN_NOT_SHAREABLE"} else "FAIL", "detail": row.get("verdict", "")} for row in profiles]
        if not checks:
            checks = [{"check": "profiles_exist", "status": "FAIL", "detail": "0"}]
        status, fail_count = check_rows(checks)
        return {"schema_version": 2, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "profile": profile or "all", "profile_count": len(profiles), "profiles": profiles, "checks": checks, "fail_count": fail_count, "runtime_action_executed": False}

    build_current_manifest(write=True)
    minimal_files = _files_for_profile("minimal_shareable")
    code_files = _files_for_profile("code_review_delta")
    internal_files = _files_for_profile("local_internal_full")
    _write_text(M4_CODE_REVIEW_DELTA_SUMMARY_PATH, "\n".join([
        "# M4 Code Review Delta Summary",
        "",
        "- `scripts/project_intelligence_graph/m4_current.py`: M4 Current Kernel RC2 helper.",
        "- `scripts/project_intelligence_graph/pig.py`: thin import switch only.",
        "- `scripts/project_intelligence_graph/m3r_current.py`: upstream historical/current predecessor imported as provenance.",
    ]))
    _zip_files(MINIMAL_ZIP_PATH, minimal_files, "PROFILE: minimal_shareable\nTRUTH: " + FINAL_TRUTH + "\n", sanitize=True)
    _zip_files(CODE_REVIEW_ZIP_PATH, code_files, "PROFILE: code_review_delta\nLOCAL TECHNICAL REVIEW ONLY\n", sanitize=True)
    _zip_files(LOCAL_INTERNAL_ZIP_PATH, internal_files, "PROFILE: local_internal_full\nLOCAL ONLY - DO NOT FORWARD\n", sanitize=True)
    profiles = [
        _profile_metrics("minimal_shareable", MINIMAL_ZIP_PATH, "PASS"),
        _profile_metrics("code_review_delta", CODE_REVIEW_ZIP_PATH, "PASS"),
        _profile_metrics("local_internal_full", LOCAL_INTERNAL_ZIP_PATH, "WARN_NOT_SHAREABLE"),
    ]
    for row in profiles[:2]:
        if row["local_path_count"] or row["localhost_url_count"] or row["email_count"] or row["secret_pattern_count"]:
            row["verdict"] = "FAIL"
    checks = [
        {"check": "profile_count", "status": "PASS" if len(profiles) == 3 else "FAIL", "detail": str(len(profiles))},
        {"check": "minimal_shareable_clean", "status": "PASS" if profiles[0]["verdict"] == "PASS" else "FAIL", "detail": profiles[0]["verdict"]},
        {"check": "code_review_delta_clean", "status": "PASS" if profiles[1]["verdict"] == "PASS" else "FAIL", "detail": profiles[1]["verdict"]},
        {"check": "internal_marked_not_shareable", "status": "PASS" if profiles[2]["verdict"] == "WARN_NOT_SHAREABLE" else "FAIL", "detail": profiles[2]["verdict"]},
    ]
    status, fail_count = check_rows(checks)
    post_pack = {
        "schema_version": 2,
        "created_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "profiles": profiles,
        "self_hash_policy": "external_wrapper_manifest",
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
    }
    write_json(M4_POST_PACK_MANIFEST_PATH, post_pack)
    _write_text(M4_POST_PACK_MANIFEST_PATH.with_suffix(".md"), _post_pack_md(post_pack))
    wrapper_extra = {
        "m4_post_pack_manifest.json": json.dumps(post_pack, indent=2, ensure_ascii=False),
        "m4_post_pack_manifest.md": _post_pack_md(post_pack),
        "m4_operator_cockpit.md": OPERATOR_COCKPIT_PATH.read_text(encoding="utf-8") if OPERATOR_COCKPIT_PATH.exists() else "",
        "m4_replay_instructions.md": M4_REPLAY_INSTRUCTIONS_PATH.read_text(encoding="utf-8") if M4_REPLAY_INSTRUCTIONS_PATH.exists() else "",
    }
    _zip_files(WRAPPER_ZIP_PATH, [MINIMAL_ZIP_PATH, CODE_REVIEW_ZIP_PATH], "M4 handoff wrapper. Nested ZIP hashes are in m4_post_pack_manifest.json.\n", sanitize=False, extra=wrapper_extra)
    WRAPPER_HASH_PATH.write_text(f"{_sha(WRAPPER_ZIP_PATH)}  {WRAPPER_ZIP_PATH.name}\n", encoding="utf-8")
    payload = {
        "schema_version": 2,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "profile_count": len(profiles),
        "profiles": profiles,
        "wrapper": safe_rel(WRAPPER_ZIP_PATH),
        "wrapper_sha256": _sha(WRAPPER_ZIP_PATH),
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
    }
    _write_json_md(M4_BLOCK_PATHS["M4-06"], payload, "M4-06 Handoff Profile Builder")
    return payload


def build_read_only_audit(*, write: bool = True) -> dict[str, Any]:
    paths = [path for path in _active_files() if path.exists()]
    before = _snapshot(paths)
    audits = [
        build_current_kernel_api(write=False),
        build_write_contract(write=False),
        build_domain_summary(write=False),
        build_current_surface_migration(write=False),
        build_replay_cli(write=False),
        build_handoff_profiles(write=False),
    ]
    after = _snapshot(paths)
    changed = [key for key in sorted(set(before) | set(after)) if before.get(key) != after.get(key)]
    checks = [
        {"check": "unexpected_mutation_count", "status": "PASS" if not changed else "FAIL", "detail": str(len(changed))},
        {"check": "audit_statuses", "status": "PASS" if all(is_passish(row.get("status")) or row.get("status") in {"PASS_WITH_WARNINGS"} for row in audits) else "FAIL", "detail": str(len(audits))},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 2,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "unexpected_mutation_count": len(changed),
        "mutated_files": changed,
        "before_hash": hashlib.sha256(json.dumps(before, sort_keys=True).encode("utf-8")).hexdigest(),
        "after_hash": hashlib.sha256(json.dumps(after, sort_keys=True).encode("utf-8")).hexdigest(),
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
    }
    if write:
        _write_json_md(M4_READ_ONLY_AUDIT_PATH, payload, "M4 Read-Only Audit")
    return payload


def build_regression_suite(*, write: bool = True) -> dict[str, Any]:
    domain = build_domain_summary(write=False)
    read_only = build_read_only_audit(write=False)
    manifest = build_current_manifest(write=False)
    source = m3r.build_source_proof_index(write=False)
    checks = [
        {"check": "status_algebra_warn_child", "status": "PASS" if _aggregate_status(["PASS", "WARN"]) == "PASS_WITH_WARNINGS" else "FAIL", "detail": _aggregate_status(["PASS", "WARN"])},
        {"check": "stale_truth_tests", "status": "PASS" if domain.get("active_truth_stale_occurrences") == 0 else "FAIL", "detail": str(domain.get("active_truth_stale_occurrences"))},
        {"check": "manifest_owner_m4", "status": "PASS" if manifest.get("owner") == "M4" else "FAIL", "detail": manifest.get("owner", "")},
        {"check": "source_proof_index_tests", "status": "PASS" if source.get("status") == "PASS" else "FAIL", "detail": source.get("status", "")},
        {"check": "read_only_replay_tests", "status": read_only.get("status", "FAIL"), "detail": str(read_only.get("unexpected_mutation_count"))},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 2,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
    }
    if write:
        _write_json_md(M4_REGRESSION_SUITE_PATH, payload, "M4 Regression Suite")
        _write_json_md(M4_BLOCK_PATHS["M4-07"], payload, "M4-07 Current Kernel Regression Suite")
    return payload


def build_final_verification(*, write: bool = True) -> dict[str, Any]:
    kernel = build_current_kernel_api(write=False)
    contract = build_write_contract(write=False)
    domain = build_domain_summary(write=False)
    migration = build_current_surface_migration(write=False)
    replay = build_replay_cli(write=False)
    profiles = build_handoff_profiles(write=False)
    read_only = build_read_only_audit(write=False)
    regression = build_regression_suite(write=False)
    checks = [
        {"check": "final_truth_consistency", "status": "PASS" if read_current_truth().get("final_truth") == FINAL_TRUTH else "FAIL", "detail": FINAL_TRUTH},
        {"check": "kernel_api", "status": kernel.get("status", "FAIL"), "detail": str(kernel.get("fail_count", 0))},
        {"check": "write_contract", "status": contract.get("status", "FAIL"), "detail": str(contract.get("fail_count", 0))},
        {"check": "domain_compression", "status": "PASS" if domain.get("status") == "PASS_WITH_WARNINGS" else "FAIL", "detail": domain.get("status", "")},
        {"check": "surface_migration", "status": migration.get("status", "FAIL"), "detail": str(migration.get("active_truth_stale_occurrences", 0))},
        {"check": "replay_cli", "status": replay.get("status", "FAIL"), "detail": str(replay.get("fail_count", 0))},
        {"check": "handoff_profiles", "status": profiles.get("status", "FAIL"), "detail": str(profiles.get("profile_count", 0))},
        {"check": "read_only_audit", "status": read_only.get("status", "FAIL"), "detail": str(read_only.get("unexpected_mutation_count", 0))},
        {"check": "regression_suite", "status": regression.get("status", "FAIL"), "detail": str(regression.get("fail_count", 0))},
        {"check": "forbidden_action_count", "status": "PASS" if read_current_truth().get("forbidden_action_count", 1) == 0 else "FAIL", "detail": str(read_current_truth().get("forbidden_action_count", 1))},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 2,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }
    if write:
        _write_json_md(M4_FINAL_VERIFICATION_PATH, payload, "M4 Final Verification")
        _write_json_md(VERIFICATION_SUMMARY_PATH, payload, "M4 Verification Summary")
    return payload


def build_final_state(*, write: bool = True) -> dict[str, Any]:
    if not write:
        return load_json(M4_FINAL_STATE_PATH, default={})
    build_grand_roadmap(write=True)
    build_current_kernel_api(write=True)
    build_write_contract(write=True)
    build_domain_summary(write=True)
    build_current_surface_migration(write=True)
    build_replay_cli(write=True)
    build_regression_suite(write=True)
    build_current_manifest(write=True)
    build_handoff_profiles(write=True)
    verification = build_final_verification(write=True)
    payload = {
        "schema_version": 2,
        "generated_at": now_iso(),
        "status": "PASS_WITH_WARNINGS" if verification.get("status") == "PASS" else "FAIL",
        "final_truth": FINAL_TRUTH,
        "roadmap_truth": ROADMAP_TRUTH,
        "current_owner": "M4",
        "previous_truth": PREVIOUS_TRUTH,
        "m4_blocks_completed": 7,
        "m5_next": "decision_execution_kernel_operator_gated",
        "domain_summary": safe_rel(DOMAIN_SUMMARY_PATH),
        "operator_cockpit": safe_rel(OPERATOR_COCKPIT_PATH),
        "write_contract": safe_rel(WRITE_CONTRACT_PATH),
        "handoff_wrapper": safe_rel(WRAPPER_ZIP_PATH),
        "minimal_shareable_bundle": safe_rel(MINIMAL_ZIP_PATH),
        "code_review_delta_bundle": safe_rel(CODE_REVIEW_ZIP_PATH),
        "local_internal_bundle": safe_rel(LOCAL_INTERNAL_ZIP_PATH),
        "checks": verification.get("checks", []),
        "fail_count": verification.get("fail_count", 1),
        "forbidden_action_count": 0,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }
    write_json(M4_FINAL_STATE_PATH, payload)
    _write_json_md(M4_FINAL_STATE_PATH, payload, "M4 Final State")
    build_current_manifest(write=True)
    build_operator_brief(write=True)
    return payload


def _operator_brief_md(payload: dict[str, Any]) -> str:
    lines = [
        "# Project Intelligence Graph Operator Brief",
        "",
        f"- Generated: `{payload.get('generated_at', '')}`",
        f"- Overall: `{payload.get('overall_status', 'UNKNOWN')}`",
        f"- Build: `{payload.get('build_status', 'UNKNOWN')}`",
        f"- Decisions: `{payload.get('decision_status', 'UNKNOWN')}`",
        "",
        "## Do This Now",
        "",
    ]
    for item in payload.get("do_this_now", []):
        lines.append(f"- `{item.get('priority', '-')}` {item.get('text', '')}")
    lines.extend(["", "## Do Not", ""])
    for item in payload.get("do_not", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Safe Commands", ""])
    for command in payload.get("safe_commands", []):
        lines.append(f"- `{command}`")
    lines.extend(["", "## Status Lines", ""])
    for key, value in payload.get("status_lines", {}).items():
        lines.append(f"- `{key}`: `{value}`")
    return "\n".join(lines) + "\n"


def build_operator_brief(*, write: bool = True) -> dict[str, Any]:
    final_state = load_json(M4_FINAL_STATE_PATH, default={})
    domain = load_json(DOMAIN_SUMMARY_PATH, default={})
    verification = load_json(M4_FINAL_VERIFICATION_PATH, default={})
    read_only = load_json(M4_READ_ONLY_AUDIT_PATH, default={})
    profiles = load_json(M4_POST_PACK_MANIFEST_PATH, default={})
    decisions = list_operator_decisions()
    payload = {
        "schema_version": 2,
        "generated_at": now_iso(),
        "overall_status": "ACTION_REQUIRED",
        "build_status": "PASS" if verification.get("status") == "PASS" and final_state.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "WARN",
        "decision_status": "OPERATOR_GATED",
        "current_owner": "M4",
        "final_truth": FINAL_TRUTH,
        "do_this_now": [
            {"priority": "P1", "text": "Use M4 Operator Cockpit as the current truth surface; M3R is provenance."},
            {"priority": "P1", "text": "Run `pig.py full-check` before changing PIG or automation control files."},
            {"priority": "P2", "text": "Continue with M5 Decision Execution Kernel only as local, reversible, operator-gated work."},
            {"priority": "P2", "text": "Keep `local_internal_full` local; share only profile-linted bundles."},
        ],
        "do_not": [
            "Do not treat local PASS as public, production, legal, finance or tax readiness.",
            "Do not run push/delete/deploy/publish/public/payment/auth/external communication/real-data/Room16-Rerun without explicit scoped Operator-Go.",
            "Do not parallelize M4 read-only audits with M4 builders; run audit after build has settled.",
            "Do not use Jarvis/OpenJarvis as DreamFactory current truth.",
        ],
        "safe_commands": [
            "python3 scripts/project_intelligence_graph/pig.py m4-final-state --json",
            "python3 scripts/project_intelligence_graph/pig.py m4-read-only-audit --json",
            "python3 scripts/project_intelligence_graph/pig.py m4-regression-suite --json",
            "python3 scripts/project_intelligence_graph/pig.py m4-handoff-profiles --no-write --json",
            "python3 scripts/project_intelligence_graph/pig.py full-check --json",
            "python3 scripts/project_intelligence_graph/pig.py german-output-quality --json",
            "python3 scripts/project_intelligence_graph/pig.py quality-gate --baseline outputs/project_intelligence_graph/quality_baseline.json --improvement \"M4 current kernel RC2 completed\" --json",
        ],
        "status_lines": {
            "m4_current_owner": final_state.get("current_owner", "M4"),
            "m4_final_truth": final_state.get("final_truth", FINAL_TRUTH),
            "m4_final_state_status": final_state.get("status", "UNKNOWN"),
            "m4_domain_status": domain.get("status", "UNKNOWN"),
            "m4_domain_count": domain.get("domain_count", 0),
            "m4_active_truth_stale_occurrences": domain.get("active_truth_stale_occurrences", 0),
            "m4_read_only_unexpected_mutations": read_only.get("unexpected_mutation_count", 0),
            "m4_profile_count": len(profiles.get("profiles", [])),
            "m4_decision_count": len(decisions),
            "m5_next": final_state.get("m5_next", "decision_execution_kernel_operator_gated"),
            "hard_gates": "closed",
            "runtime_action_executed": False,
            "external_action_executed": False,
            "irreversible_action_executed": False,
        },
    }
    if write:
        write_json(OPERATOR_BRIEF_PATH, payload)
        _write_text(OPERATOR_BRIEF_MD_PATH, _operator_brief_md(payload))
    return payload


M4_BUILDERS: dict[str, Callable[..., dict[str, Any]]] = {
    "grand-roadmap": build_grand_roadmap,
    "m4-current-kernel": build_current_kernel_api,
    "m4-current-truth-audit": build_current_surface_migration,
    "m4-write-contract": build_write_contract,
    "m4-domain-summary": build_domain_summary,
    "m4-current-surface-migration": build_current_surface_migration,
    "m4-replay-cli": build_replay_cli,
    "m4-handoff-profiles": build_handoff_profiles,
    "m4-read-only-audit": build_read_only_audit,
    "m4-regression-suite": build_regression_suite,
    "m4-final-verification": build_final_verification,
    "m4-final-state": build_final_state,
}

M1_CURRENT_COMMANDS = tuple(dict.fromkeys([*m3r.M1_CURRENT_COMMANDS, *M4_BUILDERS.keys()]))


def run_m1_current_command(command: str, write: bool = True, profile: str | None = None) -> dict[str, Any]:
    if command in M4_BUILDERS:
        effective_write = False if command in AUDITOR_COMMANDS else write
        if command == "m4-handoff-profiles":
            return build_handoff_profiles(write=effective_write, profile=profile)
        return M4_BUILDERS[command](write=effective_write)
    return m3r.run_m1_current_command(command, write=write, profile=profile)


def m1_full_check_steps() -> list[dict[str, Any]]:
    commands = [
        "m4-current-kernel",
        "m4-write-contract",
        "m4-domain-summary",
        "m4-current-surface-migration",
        "m4-replay-cli",
        "m4-handoff-profiles",
        "m4-read-only-audit",
        "m4-regression-suite",
        "m4-final-verification",
        "m4-final-state",
    ]
    steps = []
    for command in commands:
        payload = run_m1_current_command(command, write=False)
        status = payload.get("status", "UNKNOWN")
        ok = is_passish(status) or status in {"PASS_WITH_WARNINGS"}
        steps.append({
            "name": command.replace("-", "_"),
            "status": "PASS" if ok else "FAIL",
            "returncode": 0 if ok else 1,
            "fail_count": payload.get("fail_count", 0),
            "runtime_action_executed": payload.get("runtime_action_executed", False),
            "external_action_executed": payload.get("external_action_executed", False),
        })
    return steps


def m1_report_payload() -> dict[str, Any]:
    payload = m3r.m1_report_payload()
    payload.update({
        "m4_current_kernel": load_json(M4_CURRENT_KERNEL_PATH, default={}),
        "m4_domain_summary": load_json(DOMAIN_SUMMARY_PATH, default={}),
        "m4_write_contract": load_json(WRITE_CONTRACT_PATH, default={}),
        "m4_final_verification": load_json(M4_FINAL_VERIFICATION_PATH, default={}),
        "m4_final_state": load_json(M4_FINAL_STATE_PATH, default={}),
        "m4_post_pack_manifest": load_json(M4_POST_PACK_MANIFEST_PATH, default={}),
    })
    return payload


def m1_compact_domain_lines(report: dict[str, Any]) -> list[str]:
    final_state = report.get("m4_final_state") or load_json(M4_FINAL_STATE_PATH, default={})
    domain = report.get("m4_domain_summary") or load_json(DOMAIN_SUMMARY_PATH, default={})
    lines = ["## Current Kernel Summary", ""]
    lines.append(f"- M4 final: `{final_state.get('status', 'UNKNOWN')}` `{final_state.get('final_truth', FINAL_TRUTH)}`")
    lines.append("- Current owner: `M4`; M3R ist belegte Historie, ältere M1/M2/Bxx-Surfaces sind Provenance.")
    lines.append(f"- Domain summary: `{domain.get('status', 'UNKNOWN')}` mit `{domain.get('domain_count', 0)}` Domänen.")
    lines.append("- Operator cockpit: `outputs/project_intelligence_graph/current/operator_cockpit.md`.")
    lines.append("")
    return lines


def append_m1_full_check_lines(lines: list[str], report: dict[str, Any]) -> None:
    final_state = report.get("m4_final_state", {})
    post_pack = report.get("m4_post_pack_manifest", {})
    domain = report.get("m4_domain_summary", {})
    lines.extend(["", "## M4 Current Kernel", ""])
    lines.append(f"- Final state: `{final_state.get('status', 'UNKNOWN')}` ({final_state.get('final_truth', FINAL_TRUTH)})")
    lines.append(f"- Domains: `{domain.get('domain_count', 0)}` status `{domain.get('status', 'UNKNOWN')}`")
    lines.append(f"- Handoff wrapper: `{final_state.get('handoff_wrapper', safe_rel(WRAPPER_ZIP_PATH))}`")
    lines.append(f"- Bundle profiles: `{len(post_pack.get('profiles', []))}`")
