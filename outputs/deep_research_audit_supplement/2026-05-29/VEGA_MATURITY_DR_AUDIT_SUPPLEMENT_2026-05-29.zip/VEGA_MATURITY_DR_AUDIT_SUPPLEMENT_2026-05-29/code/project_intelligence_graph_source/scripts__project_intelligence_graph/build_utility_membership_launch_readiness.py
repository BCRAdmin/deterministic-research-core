from __future__ import annotations

import datetime as dt
import json
from pathlib import Path


WORKSPACE = Path(__file__).resolve().parents[2]
OUT_JSON = WORKSPACE / "outputs/project_intelligence_graph/utility_membership_launch_readiness.json"
OUT_MD = WORKSPACE / "outputs/project_intelligence_graph/utility_membership_launch_readiness.md"

UTILITY_STATUS_PATH = WORKSPACE / "outputs/utility_websites/data_maturity/latest-data-maturity-status.json"
MEMBERSHIP_PREVIEW_PATH = WORKSPACE / "outputs/project_intelligence_graph/project_vertical_membership_preview_verifier.json"
LAUNCH_READINESS_PATH = WORKSPACE / "outputs/project_intelligence_graph/launch_readiness_package.json"

OPERATOR_GATES = [
    "Public",
    "Production",
    "Payment/Geld",
    "Auth/Credentials",
    "externe Kommunikation",
    "externe Analytics-Zugriffe",
    "Financial-Advice-Publishing",
    "Deploy",
]


def load_json(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {"status": "unreadable", "path": str(path.relative_to(WORKSPACE))}
    return value if isinstance(value, dict) else {"status": "unreadable", "path": str(path.relative_to(WORKSPACE))}


def failed_membership_checks(payload: dict) -> list[dict]:
    results = payload.get("results", [])
    if not isinstance(results, list):
        return [{"check": "results_shape", "detail": "results is not a list"}]
    return [item for item in results if isinstance(item, dict) and not item.get("pass")]


def build_markdown(payload: dict) -> str:
    lines = [
        "# Utility + Membership Launch Readiness",
        "",
        f"Generated: {payload['generated_at']}",
        f"Status: {payload['status']}",
        "",
        "## Summary",
        "",
        f"- Utility signal: `{payload['utility']['signal_status']}`",
        f"- Utility maturity: `{payload['utility']['maturity_status']}`",
        f"- Due windows: `{payload['utility']['due_window_count']}`",
        f"- Membership preview: `{payload['membership']['verdict']}`",
        f"- Membership failed checks: `{payload['membership']['failed_count']}`",
        f"- Runtime action executed: `{payload['runtime_action_executed']}`",
        f"- External action executed: `{payload['external_action_executed']}`",
        "",
        "## Operator Decision Package",
        "",
        f"- Current decision: `{payload['operator_decision_package']['current_decision']}`",
        f"- Next safe step: {payload['operator_decision_package']['next_safe_step']}",
        "",
        "## Gates",
        "",
    ]
    for gate in payload["operator_gates"]:
        lines.append(f"- `{gate}`")
    lines.extend(["", "## Findings", ""])
    if payload["findings"]:
        for finding in payload["findings"]:
            lines.append(f"- {finding['severity']}: {finding['message']}")
    else:
        lines.append("- No structural findings.")
    lines.extend(["", "## Stop-Regel", "", payload["stop_rule"], ""])
    return "\n".join(lines)


def main() -> int:
    utility = load_json(UTILITY_STATUS_PATH)
    membership = load_json(MEMBERSHIP_PREVIEW_PATH)
    launch = load_json(LAUNCH_READINESS_PATH)
    findings: list[dict[str, str]] = []

    utility_runtime_ok = utility.get("runtime_action_executed") is False
    if utility.get("status") not in {"PASS", "WARN"}:
        findings.append({"severity": "FAIL", "message": "Utility data maturity status is missing or not PASS/WARN."})
    if not utility_runtime_ok:
        findings.append({"severity": "FAIL", "message": "Utility data maturity does not report runtime_action_executed=false."})

    membership_failed = failed_membership_checks(membership)
    if membership.get("verdict") != "pass":
        findings.append({"severity": "FAIL", "message": "Membership preview verifier is not pass."})
    if membership_failed:
        findings.append({"severity": "FAIL", "message": f"Membership preview has {len(membership_failed)} failed checks."})

    if launch and launch.get("runtime_action_executed") is not False:
        findings.append({"severity": "FAIL", "message": "Launch readiness package does not report runtime_action_executed=false."})

    due_windows = [
        window
        for window in utility.get("review_windows", [])
        if isinstance(window, dict) and window.get("status") == "due_or_past"
    ]
    if due_windows:
        findings.append({
            "severity": "WARN",
            "message": f"Utility data review window is due or past ({len(due_windows)} window(s)); external analytics access remains gated.",
        })
    if utility.get("maturity_status") != "mature":
        findings.append({"severity": "WARN", "message": "Utility websites are not mature enough for monetization or production scaling."})

    fail_count = len([finding for finding in findings if finding["severity"] == "FAIL"])
    warn_count = len([finding for finding in findings if finding["severity"] == "WARN"])
    status = "FAIL" if fail_count else ("WARN" if warn_count else "PASS")
    payload = {
        "schema_version": 1,
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": status,
        "utility": {
            "status": utility.get("status", "UNKNOWN"),
            "maturity_status": utility.get("maturity_status", "UNKNOWN"),
            "signal_status": utility.get("signal_status", "UNKNOWN"),
            "due_window_count": len(due_windows),
            "review_windows": utility.get("review_windows", []),
            "runtime_action_executed": utility.get("runtime_action_executed", None),
        },
        "membership": {
            "verdict": membership.get("verdict", "missing"),
            "base_url": membership.get("baseUrl", ""),
            "checked_at": membership.get("checkedAt", ""),
            "failed_count": len(membership_failed),
        },
        "launch_readiness_status": launch.get("status", "UNKNOWN"),
        "runtime_action_executed": False,
        "external_action_executed": False,
        "payment_action_executed": False,
        "public_or_production_action_executed": False,
        "auth_or_credential_action_executed": False,
        "operator_gate_required": True,
        "operator_gates": OPERATOR_GATES,
        "operator_decision_package": {
            "current_decision": "monitoring_no_launch" if status != "FAIL" else "repair_local_readiness",
            "allowed_local_decisions": ["refresh_local_preview", "refresh_data_maturity_packet", "prepare_operator_handoff"],
            "forbidden_without_operator_go": [
                "deploy",
                "publish",
                "production",
                "payment",
                "auth_credentials",
                "external_analytics_access",
                "external_send",
                "financial_advice_publish",
            ],
            "next_safe_step": (
                "Utility-Datenfenster lokal beobachten und Membership-Preview grün halten; Launch, Payment, Public, Auth und externe Datenzugriffe bleiben geschlossen."
            ),
        },
        "findings": findings,
        "fail_count": fail_count,
        "warn_count": warn_count,
        "source_paths": {
            "utility_data_maturity": str(UTILITY_STATUS_PATH.relative_to(WORKSPACE)),
            "membership_preview": str(MEMBERSHIP_PREVIEW_PATH.relative_to(WORKSPACE)),
            "launch_readiness": str(LAUNCH_READINESS_PATH.relative_to(WORKSPACE)),
        },
        "stop_rule": "Stop bei Public, Production, Payment/Geld, Auth/Credentials, externer Kommunikation, externem Analytics-Zugriff, Financial-Advice-Publishing oder Deploy.",
    }

    OUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    OUT_JSON.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    OUT_MD.write_text(build_markdown(payload) + "\n", encoding="utf-8")
    print(f"Utility/Membership launch readiness {status}. Output: {OUT_JSON}")
    return 0 if status in {"PASS", "WARN"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
