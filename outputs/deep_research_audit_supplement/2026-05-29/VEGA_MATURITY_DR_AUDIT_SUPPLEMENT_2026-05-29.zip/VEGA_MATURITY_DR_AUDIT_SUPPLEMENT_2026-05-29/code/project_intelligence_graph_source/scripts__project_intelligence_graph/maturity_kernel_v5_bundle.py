"""Archive target and bundle-profile helpers for B46-B55."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from maturity_kernel_v5_core import (
    OUTPUT_DIR,
    REVIEW_BUNDLES_DIR,
    archive_measurement,
    check_rows,
    latest_archive,
    load_json,
    now_iso,
    safe_rel,
    write_report,
)


ARCHIVE_TARGET_MATRIX_PATH = OUTPUT_DIR / "archive_target_matrix.json"
EVIDENCE_BUDGET_REPORT_V3_PATH = OUTPUT_DIR / "evidence_budget_report_v3.json"
BUNDLE_PROFILE_LINT_V2_PATH = OUTPUT_DIR / "bundle_profile_lint_v2.json"


PROFILE_BUDGETS = {
    "minimal_shareable": 250_000,
    "current_local_lite": 300_000,
    "internal_full_or_local_code_review": 1_500_000,
    "nested_previous": 300_000,
}


def _target_row(
    *,
    target_id: str,
    profile: str,
    path: Path | None,
    source_capsule: str,
    is_current_primary: bool,
    is_nested_previous: bool,
    shareability: str,
    allowed_consumers: list[str],
    absolute_path_policy: str,
) -> dict[str, Any]:
    measured = archive_measurement(path, budget_bytes=PROFILE_BUDGETS.get(profile, 250_000))
    return {
        "target_id": target_id,
        "profile": profile,
        "source_capsule": source_capsule,
        "is_current_primary": is_current_primary,
        "is_nested_previous": is_nested_previous,
        "shareability": shareability,
        "allowed_consumers": allowed_consumers,
        "absolute_path_policy": absolute_path_policy,
        **measured,
    }


def discover_archive_targets() -> list[dict[str, Any]]:
    b46_minimal = latest_archive("*dreamfactory-b46-b55-current-minimal-shareable.zip")
    b46_lite = latest_archive("*dreamfactory-b46-b55-local-code-review-lite.zip")
    b36_lite = latest_archive("*dreamfactory-b36-b45-local-code-review-lite.zip")
    b36_full = latest_archive("*dreamfactory-b36-b45-change-check.zip")
    b28_minimal = latest_archive("*dreamfactory-b28-b35-maturity-kernel-v3-minimal-shareable.zip")
    current_primary = b46_lite or b36_lite
    rows = [
        _target_row(
            target_id="b46_b55_minimal_shareable",
            profile="minimal_shareable",
            path=b46_minimal,
            source_capsule="b46_b55_final_handoff",
            is_current_primary=False,
            is_nested_previous=False,
            shareability="shareable_after_operator_recipient_go",
            allowed_consumers=["operator", "vega", "deep_research_after_review"],
            absolute_path_policy="must_be_zero",
        ),
        _target_row(
            target_id="b46_b55_current_local_lite" if b46_lite else "b36_b45_current_local_lite_fallback",
            profile="current_local_lite",
            path=current_primary,
            source_capsule="b46_b55_final_handoff" if b46_lite else "b36_b45_change_check",
            is_current_primary=True,
            is_nested_previous=False,
            shareability="local_only_do_not_forward",
            allowed_consumers=["operator", "vega", "codex"],
            absolute_path_policy="must_be_zero",
        ),
        _target_row(
            target_id="b36_b45_internal_full_local_review",
            profile="internal_full_or_local_code_review",
            path=b36_full,
            source_capsule="b36_b45_change_check",
            is_current_primary=False,
            is_nested_previous=True,
            shareability="local_only_do_not_forward",
            allowed_consumers=["operator", "vega"],
            absolute_path_policy="local_only_allowed_with_warning",
        ),
        _target_row(
            target_id="b36_b45_previous_lite",
            profile="nested_previous",
            path=b36_lite,
            source_capsule="b36_b45_local_code_review_lite",
            is_current_primary=False,
            is_nested_previous=True,
            shareability="local_only_do_not_forward",
            allowed_consumers=["operator", "vega", "codex"],
            absolute_path_policy="must_be_zero",
        ),
        _target_row(
            target_id="b28_b35_previous_minimal",
            profile="nested_previous",
            path=b28_minimal,
            source_capsule="b28_b35_sanitized_capsule",
            is_current_primary=False,
            is_nested_previous=True,
            shareability="shareable_after_operator_recipient_go",
            allowed_consumers=["operator", "vega", "deep_research_after_review"],
            absolute_path_policy="must_be_zero",
        ),
    ]
    return rows


def build_archive_target_matrix(*, write: bool = True) -> dict[str, Any]:
    targets = discover_archive_targets()
    primary_count = len([row for row in targets if row.get("is_current_primary")])
    current_primary = next((row for row in targets if row.get("is_current_primary")), {})
    previous_nested_ok = all(not row.get("is_current_primary") for row in targets if "b28_b35" in row.get("target_id", ""))
    checks = [
        {"check": "exactly_one_current_primary", "status": "PASS" if primary_count == 1 else "FAIL", "detail": str(primary_count)},
        {"check": "current_primary_archive_audited", "status": "PASS" if current_primary.get("archive_exists") else "FAIL", "detail": current_primary.get("archive_path", "")},
        {"check": "previous_nested_archive_audited_as_nested_only", "status": "PASS" if previous_nested_ok else "FAIL", "detail": "b28/b36 previous targets are nested only"},
        {"check": "no_stale_target_ambiguity", "status": "PASS" if primary_count == 1 and current_primary.get("profile") == "current_local_lite" else "FAIL", "detail": current_primary.get("target_id", "")},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "B46",
        "target_count": len(targets),
        "current_primary_target_id": current_primary.get("target_id", ""),
        "current_primary_archive_audited": bool(current_primary.get("archive_exists")),
        "previous_nested_archive_audited_as_nested_only": previous_nested_ok,
        "stale_target_ambiguity_count": 0 if primary_count == 1 else primary_count,
        "targets": targets,
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "next_safe_step": "Use target_id=current_primary for current review decisions; older archives remain nested_previous only.",
    }
    if write:
        write_report(ARCHIVE_TARGET_MATRIX_PATH, "Archive Target Matrix", payload)
    return payload


def _budget_profile(row: dict[str, Any]) -> dict[str, Any]:
    allowed_to_share = row.get("profile") == "minimal_shareable" and row.get("absolute_user_path_count") == 0 and row.get("localhost_url_count") == 0 and row.get("secret_count") == 0
    return {
        "profile": row.get("profile"),
        "target_id": row.get("target_id"),
        "archive_path": row.get("archive_path"),
        "archive_exists": row.get("archive_exists"),
        "archive_bytes": row.get("archive_bytes", 0),
        "uncompressed_bytes": row.get("uncompressed_bytes", 0),
        "member_count": row.get("member_count", 0),
        "top_members": row.get("top_members", []),
        "absolute_user_path_count": row.get("absolute_user_path_count", 0),
        "localhost_url_count": row.get("localhost_url_count", 0),
        "secret_count": row.get("secret_count", 0),
        "budget_bytes": row.get("budget_bytes", 0),
        "within_budget": row.get("within_budget", False),
        "allowed_to_share": allowed_to_share,
    }


def build_evidence_budget_report_v3(*, write: bool = True) -> dict[str, Any]:
    matrix = build_archive_target_matrix(write=False)
    targets = matrix.get("targets", [])
    profiles = []
    for profile in ["minimal_shareable", "current_local_lite", "internal_full_or_local_code_review"]:
        row = next((item for item in targets if item.get("profile") == profile), {})
        profiles.append(_budget_profile(row))
    stale_refs = [row for row in profiles if row.get("profile") != "current_local_lite" and row.get("target_id") == matrix.get("current_primary_target_id")]
    checks = [
        {"check": "all_declared_profiles_measured", "status": "PASS" if all(row.get("archive_exists") for row in profiles) else "FAIL", "detail": str(len([row for row in profiles if row.get("archive_exists")]))},
        {"check": "estimated_values_used", "status": "PASS", "detail": "false"},
        {"check": "stale_archive_reference_count", "status": "PASS" if not stale_refs else "FAIL", "detail": str(len(stale_refs))},
        {"check": "current_primary_measured", "status": "PASS" if any(row.get("target_id") == matrix.get("current_primary_target_id") for row in profiles) else "FAIL", "detail": matrix.get("current_primary_target_id", "")},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 3,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "B49",
        "profiles": profiles,
        "all_declared_profiles_measured": all(row.get("archive_exists") for row in profiles),
        "estimated_values_used": False,
        "stale_archive_reference_count": len(stale_refs),
        "current_primary_measured": any(row.get("target_id") == matrix.get("current_primary_target_id") for row in profiles),
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "next_safe_step": "Read budget by profile; do not reuse old B28-B35 minimal bytes as the current target budget.",
    }
    if write:
        write_report(EVIDENCE_BUDGET_REPORT_V3_PATH, "Evidence Budget Report v3", payload)
    return payload


def _lint_result(row: dict[str, Any]) -> dict[str, Any]:
    profile = row.get("profile", "")
    path_hits = int(row.get("absolute_user_path_count", 0))
    localhost_hits = int(row.get("localhost_url_count", 0))
    secret_hits = [REDACTED]
    if profile in {"minimal_shareable", "current_local_lite", "nested_previous"}:
        result = "PASS" if path_hits == localhost_hits == secret_hits == 0 else "FAIL"
        allowed = profile == "minimal_shareable" and result == "PASS"
        redact = result != "PASS"
    else:
        result = "WARN" if path_hits or localhost_hits else ("FAIL" if secret_hits else "PASS")
        allowed = False
        redact = bool(path_hits or localhost_hits or secret_hits)
    return {
        "archive_path": row.get("archive_path", ""),
        "target_id": row.get("target_id", ""),
        "profile": profile,
        "sharing_class": row.get("shareability", ""),
        "absolute_user_path_count": path_hits,
        "localhost_url_count": localhost_hits,
        "secret_count": secret_hits,
        "policy_result": result,
        "allowed_to_forward": allowed,
        "redaction_required_before_share": redact,
    }


def build_bundle_profile_lint_v2(*, write: bool = True) -> dict[str, Any]:
    matrix = build_archive_target_matrix(write=False)
    items = [_lint_result(row) for row in matrix.get("targets", []) if row.get("archive_exists")]
    fail_count = len([row for row in items if row.get("policy_result") == "FAIL"])
    local_warn_count = len([row for row in items if row.get("policy_result") == "WARN"])
    status = "FAIL" if fail_count else ("WARN_WITH_LOCAL_ONLY" if local_warn_count else "PASS")
    payload = {
        "schema_version": 2,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "B51",
        "items": items,
        "shareable_absolute_user_path_count": sum(row["absolute_user_path_count"] for row in items if row["profile"] == "minimal_shareable"),
        "local_lite_absolute_user_path_count": sum(row["absolute_user_path_count"] for row in items if row["profile"] == "current_local_lite"),
        "secret_count": sum(row["secret_count"] for row in items),
        "full_local_redaction_required": any(row["redaction_required_before_share"] for row in items if row["profile"] == "internal_full_or_local_code_review"),
        "fail_count": fail_count,
        "local_only_warn_count": local_warn_count,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "next_safe_step": "Forward only minimal/shareable artifacts after recipient-level Operator-Go; local review bundles stay do-not-forward.",
    }
    if write:
        write_report(BUNDLE_PROFILE_LINT_V2_PATH, "Bundle Profile Lint v2", payload)
    return payload
