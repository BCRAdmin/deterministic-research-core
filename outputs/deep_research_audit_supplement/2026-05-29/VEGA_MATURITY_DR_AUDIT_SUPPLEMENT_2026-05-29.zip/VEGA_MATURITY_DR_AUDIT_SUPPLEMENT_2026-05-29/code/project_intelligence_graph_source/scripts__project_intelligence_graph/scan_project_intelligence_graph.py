#!/usr/bin/env python3
"""Build Project Intelligence Graph artifacts from local DreamFactory sources."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import html
import json
import os
import re
import subprocess
from pathlib import Path
from typing import Any

from config import resolve_runtime_paths

RUNTIME_PATHS = resolve_runtime_paths(__file__)
WORKSPACE = RUNTIME_PATHS.workspace
AGENT_OS_WORKSPACE = Path("/Users/BjornRosinger/Documents/DreamFactory/Room16/research-agent-ops")
LIONCOM_APP = Path("/Users/BjornRosinger/Documents/DreamFactory/LIONCOM/mission-control-board")
VAULT = Path("/Users/BjornRosinger/Documents/Obsidian/Test Vaul Privat/Human Overview")
OUTPUT_DIR = RUNTIME_PATHS.outputs
DOCS_DIR = WORKSPACE / "docs/project-intelligence-graph"
SCHEMA_PATH = WORKSPACE / "docs/project-intelligence-graph/RELATIONSHIP_SCHEMA.json"
NODE_SCHEMA_PATH = DOCS_DIR / "NODE_SCHEMA.json"
PREDICATE_REGISTRY_PATH = DOCS_DIR / "PREDICATE_REGISTRY.json"
POLICY_RULES_PATH = DOCS_DIR / "POLICY_RULES.json"
BUILD_CONTRACT_SCHEMA_PATH = DOCS_DIR / "BUILD_CONTRACT_SCHEMA.json"
JOB_CARD_SCHEMA_PATH = DOCS_DIR / "JOB_CARD_SCHEMA.json"
EXECUTION_HISTORY_SCHEMA_PATH = DOCS_DIR / "EXECUTION_HISTORY_SCHEMA.json"
LONG_RUN_COMPLETION_SCHEMA_PATH = DOCS_DIR / "LONG_RUN_COMPLETION_REPORT_SCHEMA.json"
RULE_PROPAGATION_SCHEMA_PATH = DOCS_DIR / "RULE_PROPAGATION_REGISTRY_SCHEMA.json"
RULE_PROPAGATION_REGISTRY_PATH = DOCS_DIR / "RULE_PROPAGATION_REGISTRY.json"
PROJECT_INVARIANT_SCHEMA_PATH = DOCS_DIR / "PROJECT_INVARIANT_REGISTRY_SCHEMA.json"
PROJECT_INVARIANT_REGISTRY_PATH = DOCS_DIR / "PROJECT_INVARIANT_REGISTRY.json"
AGENT_ENTRYPOINT_SCHEMA_PATH = DOCS_DIR / "AGENT_ENTRYPOINT_REGISTRY_SCHEMA.json"
AGENT_ENTRYPOINT_REGISTRY_PATH = DOCS_DIR / "AGENT_ENTRYPOINT_REGISTRY.json"
OPERATOR_INTENT_CONTRACT_SCHEMA_PATH = DOCS_DIR / "OPERATOR_INTENT_CONTRACT_SCHEMA.json"
OPERATOR_INTENT_TEMPLATE_PATH = DOCS_DIR / "quality-operating-system/OPERATOR_INTENT_CONTRACT_TEMPLATE.md"
OPERATOR_INTENT_CONTRACTS_DIR = OUTPUT_DIR / "operator_intent_contracts"
IMPACT_RADIUS_RULES_SCHEMA_PATH = DOCS_DIR / "IMPACT_RADIUS_RULES_SCHEMA.json"
IMPACT_RADIUS_RULES_PATH = DOCS_DIR / "IMPACT_RADIUS_RULES.json"
GERMAN_OUTPUT_QUALITY_SCHEMA_PATH = DOCS_DIR / "GERMAN_OUTPUT_QUALITY_REGISTRY_SCHEMA.json"
GERMAN_OUTPUT_QUALITY_REGISTRY_PATH = DOCS_DIR / "GERMAN_OUTPUT_QUALITY_REGISTRY.json"
OPERATOR_DECISION_STATE_PATH = OUTPUT_DIR / "operator_decision_state.json"
LONG_RUN_REPORTS_DIR = OUTPUT_DIR / "long_run_completion_reports"
QUALITY_OS_DOCS = DOCS_DIR / "quality-operating-system"
QUALITY_OS_VAULT = VAULT / "DreamFactory System/Agent Stack/Quality Operating System"
QUALITY_OS_ROADMAP = VAULT / "DreamFactory System/Agent Stack/Vega Vivi Quality Operating System Roadmap - 2026-05-22.md"
N8N_ARCHETYPE_REFERENCE = VAULT / "DreamFactory System/Agent Stack/n8n Workflow Archetype Reference - 2026-05-22.md"
LONG_RUN_RULE = VAULT / "Canonical/Rules/Rule - Long Run Completion Discipline.md"
VAULT_UMLAUT_HYGIENE_PATH = OUTPUT_DIR / "vault_umlaut_hygiene.json"
SKILL_POLICY_REGRESSION_AUDIT_PATH = OUTPUT_DIR / "skill_policy_regression_guard_audit.json"
LONG_RUN_ENTRYPOINTS = [
    ("workspace_agents", WORKSPACE / "AGENTS.md", "repo-local Codex/Vega bootstrap"),
    ("kanzlei_agents", WORKSPACE / "kanzlei-ai-assist/AGENTS.md", "project-specific Kanzlei bootstrap"),
    ("vega_start_here", VAULT / "VEGA_START_HERE.md", "primary Obsidian bootstrap"),
    ("canonical_index", VAULT / "Canonical/Canonical Index.md", "canonical rules index"),
    ("latest_session_context", VAULT / "Latest Session Context.md", "latest session handoff"),
    ("learnings_and_fixes", VAULT / "Memory/Learnings and Fixes.md", "durable behavior learning"),
    ("skill_vega_session_bootstrap", Path("/Users/BjornRosinger/.codex/skills/vega-session-bootstrap/SKILL.md"), "Codex skill bootstrap"),
    ("skill_vivi_session_start", Path("/Users/BjornRosinger/.codex/skills/vivi-session-start/SKILL.md"), "Vivi skill bootstrap"),
    ("skill_pig", Path("/Users/BjornRosinger/.codex/skills/vega-project-intelligence-graph/SKILL.md"), "PIG skill runbook"),
    ("skill_memory", Path("/Users/BjornRosinger/.codex/skills/vega-obsidian-memory/SKILL.md"), "memory routing skill"),
    ("skill_project_brain", Path("/Users/BjornRosinger/.codex/skills/vega-project-brain/SKILL.md"), "project reading skill"),
    ("skill_analysis_ingest", Path("/Users/BjornRosinger/.codex/skills/vega-analysis-ingest/SKILL.md"), "analysis ingest skill"),
    ("skill_multi_agent_research", Path("/Users/BjornRosinger/.codex/skills/vega-multi-agent-research/SKILL.md"), "multi-agent research skill"),
    ("claude_portable", WORKSPACE / "CLAUDE.md", "portable Claude/agent instructions"),
    ("agent_portability", DOCS_DIR / "AGENT_PORTABILITY.md", "provider-neutral PIG instructions"),
]
SKILL_POLICY_REGRESSION_TARGETS = [
    ("workspace_agents", WORKSPACE / "AGENTS.md", "repo bootstrap"),
    ("claude_portable", WORKSPACE / "CLAUDE.md", "portable agent instructions"),
    ("skill_vega_session_bootstrap", Path("/Users/BjornRosinger/.codex/skills/vega-session-bootstrap/SKILL.md"), "session bootstrap"),
    ("skill_vivi_session_start", Path("/Users/BjornRosinger/.codex/skills/vivi-session-start/SKILL.md"), "Vivi session start"),
    ("skill_pig", Path("/Users/BjornRosinger/.codex/skills/vega-project-intelligence-graph/SKILL.md"), "PIG improvement loop"),
    ("skill_analysis_ingest", Path("/Users/BjornRosinger/.codex/skills/vega-analysis-ingest/SKILL.md"), "analysis ingest"),
    ("skill_multi_agent_research", Path("/Users/BjornRosinger/.codex/skills/vega-multi-agent-research/SKILL.md"), "multi-agent research"),
    ("skill_utility_website_loop", Path("/Users/BjornRosinger/.codex/skills/utility-website-delivery-loop/SKILL.md"), "utility website improvement loop"),
    ("policy_rules", POLICY_RULES_PATH, "PIG policy rules"),
    ("quality_control_doc", DOCS_DIR / "QUALITY_CONTROL.md", "PIG quality control"),
    ("robust_hardening_doc", DOCS_DIR / "ROBUST_HARDENING_WORKFLOW.md", "hardening workflow"),
    ("vivi_autonomous_refill", Path("/Users/BjornRosinger/Documents/DreamFactory/LIONCOM/scripts/seed_autonomous_refill.py"), "Vivi auto research / autonomous refill"),
    ("autonomous_delivery_workflow", VAULT / "DreamFactory System/Agent Stack/Vega + Vivi Autonomous Delivery Workflow.md", "Vega/Vivi autonomous delivery workflow"),
    ("vivi_person_note", VAULT / "Canonical/People/Person - Vivi.md", "Vivi canonical operating rules"),
]
UMLAUT_ASCII_PATTERNS = [
    (re.compile(r"\bfuer\b", re.IGNORECASE), "für"),
    (re.compile(r"\b\w*fuehr\w*\b", re.IGNORECASE), "führ..."),
    (re.compile(r"\b\w*ueber\w*\b", re.IGNORECASE), "über..."),
    (re.compile(r"\b\w*pruef\w*\b", re.IGNORECASE), "prüf..."),
    (re.compile(r"\b\w*gruend\w*\b", re.IGNORECASE), "gründ..."),
    (re.compile(r"\bgruen\w*\b", re.IGNORECASE), "grün..."),
    (re.compile(r"\b\w*haert\w*\b", re.IGNORECASE), "härt..."),
    (re.compile(r"\b\w*spaet\w*\b", re.IGNORECASE), "spät..."),
    (re.compile(r"\b\w*waehr\w*\b", re.IGNORECASE), "währ..."),
    (re.compile(r"\b\w*waer\w*\b", re.IGNORECASE), "wär..."),
    (re.compile(r"\b\w*haett\w*\b", re.IGNORECASE), "hätt..."),
    (re.compile(r"\b\w*moeg\w*\b", re.IGNORECASE), "mög..."),
    (re.compile(r"\b\w*koenn\w*\b", re.IGNORECASE), "könn..."),
    (re.compile(r"\b\w*muess\w*\b", re.IGNORECASE), "müss..."),
    (re.compile(r"\b\w*duerf\w*\b", re.IGNORECASE), "dürf..."),
    (re.compile(r"\b\w*aender\w*\b", re.IGNORECASE), "änder..."),
    (re.compile(r"\b\w*oeff\w*\b", re.IGNORECASE), "öff..."),
    (re.compile(r"\b\w*loes\w*\b", re.IGNORECASE), "lös..."),
    (re.compile(r"\b\w*noetig\w*\b", re.IGNORECASE), "nötig..."),
    (re.compile(r"\b\w*frueh\w*\b", re.IGNORECASE), "früh..."),
    (re.compile(r"\b\w*staerk\w*\b", re.IGNORECASE), "stärk..."),
    (re.compile(r"\b\w*staend\w*\b", re.IGNORECASE), "ständ..."),
    (re.compile(r"\b\w*groess\w*\b", re.IGNORECASE), "größ..."),
    (re.compile(r"\b\w*flaech\w*\b", re.IGNORECASE), "fläch..."),
    (re.compile(r"\b\w*geraet\w*\b", re.IGNORECASE), "gerät..."),
    (re.compile(r"\b\w*haelf\w*\b", re.IGNORECASE), "hälf..."),
    (re.compile(r"\b\w*faeh\w*\b", re.IGNORECASE), "fäh..."),
    (re.compile(r"\b\w*traeg\w*\b", re.IGNORECASE), "träg..."),
    (re.compile(r"\b\w*waeg\w*\b", re.IGNORECASE), "wäg..."),
    (re.compile(r"\b\w*kuenft\w*\b", re.IGNORECASE), "künft..."),
    (re.compile(r"\b\w*bestaet\w*\b", re.IGNORECASE), "bestät..."),
    (re.compile(r"\b\w*ausgewaehl\w*\b", re.IGNORECASE), "ausgewähl..."),
    (re.compile(r"\b\w*angestoss\w*\b", re.IGNORECASE), "angestoß..."),
    (re.compile(r"\b\w*zusaetz\w*\b", re.IGNORECASE), "zusätz..."),
    (re.compile(r"\b\w*bloeck\w*\b", re.IGNORECASE), "blöck..."),
    (re.compile(r"\b\w*praesenz\w*\b", re.IGNORECASE), "präsenz"),
    (re.compile(r"\b\w*vollstaend\w*\b", re.IGNORECASE), "vollständ..."),
    (re.compile(r"\b\w*beduerf\w*\b", re.IGNORECASE), "bedürf..."),
    (re.compile(r"\b\w*zuverlaess\w*\b", re.IGNORECASE), "zuverläss..."),
    (re.compile(r"\b\w*verknuepf\w*\b", re.IGNORECASE), "verknüpf..."),
    (re.compile(r"\b\w*ergaenz\w*\b", re.IGNORECASE), "ergänz..."),
    (re.compile(r"\b\w*enthael\w*\b", re.IGNORECASE), "enthält..."),
    (re.compile(r"\b\w*ursprueng\w*\b", re.IGNORECASE), "ursprüng..."),
    (re.compile(r"\b\w*brueck\w*\b", re.IGNORECASE), "brück..."),
    (re.compile(r"\b\w*drueck\w*\b", re.IGNORECASE), "drück..."),
    (re.compile(r"\b\w*zurueck\w*\b", re.IGNORECASE), "zurück..."),
    (re.compile(r"\brueck\w*\b", re.IGNORECASE), "rück..."),
    (re.compile(r"\b\w*aeuss\w*\b", re.IGNORECASE), "äuß..."),
    (re.compile(r"\bqualitaet\b", re.IGNORECASE), "Qualität"),
    (re.compile(r"\bkapazitaet\b", re.IGNORECASE), "Kapazität"),
    (re.compile(r"\bungefaehr\b", re.IGNORECASE), "ungefähr"),
    (re.compile(r"\boberflaeche\b", re.IGNORECASE), "Oberfläche"),
    (re.compile(r"\bloesung\b", re.IGNORECASE), "Lösung"),
]
REPO_SCAN_ROOTS = [
    WORKSPACE / "company-dossier-lab",
    WORKSPACE / "kanzlei-ai-assist",
    AGENT_OS_WORKSPACE,
    LIONCOM_APP,
]
FOCUS_LABELS = {
    "Project - LIONCOM Dashboard",
    "Project - Quellwert",
    "System - Obsidian Knowledge Base",
    "DreamFactory Struktur- und Tool-Mapping - 2026-05-22",
    "Project Intelligence Graph - Empfehlung 2026-05-22",
}
WIKILINK_RE = re.compile(r"\[\[([^\]]+)\]\]")
HEADING_RE = re.compile(r"^(#{1,6})\s+(.+)$", re.MULTILINE)
STATUS_RE = re.compile(r"\b(active|local_preview|parked_no_current_intent|closed_pending_operator_go|candidate_recommended|paused|ACTIVE|PAUSED)\b")
RISK_TOKEN_RE = [REDACTED]
    r"\b(deploy|publish|operator-go|live|adsense|affiliate|github|git\s+push|push|credential|secret|token|oauth|api key|"
    r"production|public|dns|cloudflare|money|payment|checkout|delete|remove|destructive|external|send)\b",
    re.IGNORECASE,
)
MUTATING_TOKEN_RE = [REDACTED]
EXTERNAL_TOKEN_RE = [REDACTED]
NEGATED_RISK_CONTEXT_RE = re.compile(
    r"\b(no|not|do\s+not|does\s+not|without|never|blocked|forbidden|kein|keine|keinen|ohne|nicht|stopps?|harte\s+stopps?)\b",
    re.IGNORECASE,
)


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def sha256_file(path: Path) -> str:
    try:
        return hashlib.sha256(path.read_bytes()).hexdigest()
    except Exception:
        return hashlib.sha256(str(path).encode("utf-8")).hexdigest()


def stable_id(*parts: object) -> str:
    payload = "\u241f".join(str(part) for part in parts)
    return hashlib.sha1(payload.encode("utf-8")).hexdigest()[:20]


def slug(value: str) -> str:
    value = value.strip().replace("\\", "/")
    value = re.sub(r"\s+", "-", value)
    value = re.sub(r"[^A-Za-z0-9._:/#-]+", "", value)
    return value.strip("-").lower() or "unknown"


def node_id(kind: str, label: str) -> str:
    return f"{kind}:{slug(label)}"


def note_id(path: Path) -> str:
    rel = path.relative_to(VAULT).with_suffix("").as_posix()
    return f"note:{slug(rel)}"


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def parse_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    if not text.startswith("---\n"):
        return {}, text
    end = text.find("\n---", 4)
    if end == -1:
        return {}, text
    block = text[4:end].splitlines()
    body = text[end + 4 :]
    data: dict[str, Any] = {}
    current_key: str | None = None
    for raw in block:
        line = raw.rstrip()
        if not line.strip():
            continue
        if not line.startswith(" ") and ":" in line:
            key, value = line.split(":", 1)
            key = key.strip()
            value = value.strip()
            if value == "":
                data[key] = []
                current_key = key
            else:
                data[key] = strip_yaml_scalar(value)
                current_key = None
            continue
        if current_key and line.strip().startswith("- "):
            item = strip_yaml_scalar(line.strip()[2:].strip())
            if not isinstance(data.get(current_key), list):
                data[current_key] = []
            data[current_key].append(item)
    return data, body


def strip_yaml_scalar(value: str) -> str:
    if value in {"null", "None", "~"}:
        return ""
    if (value.startswith('"') and value.endswith('"')) or (value.startswith("'") and value.endswith("'")):
        return value[1:-1]
    return value


def as_list(value: Any) -> list[str]:
    if value is None or value == "":
        return []
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    return [str(value).strip()]


def clean_wikilink(raw: str) -> str:
    target = raw.split("|", 1)[0].split("#", 1)[0].strip()
    return target


def compact_search_text(text: str, limit: int = 4000) -> str:
    compacted = re.sub(r"\s+", " ", text).strip()
    return compacted[:limit]


class GraphBuilder:
    def __init__(self) -> None:
        self.nodes: dict[str, dict[str, Any]] = {}
        self.relationships: dict[str, dict[str, Any]] = {}
        self.note_index: dict[str, str] = {}
        self.note_paths: dict[str, Path] = {}
        self.observed_at = utc_now()
        self.scan_date = self.observed_at[:10]
        self.findings: list[dict[str, Any]] = []
        self.coverage_sources: list[dict[str, Any]] = []
        self.automation_risks: list[dict[str, Any]] = []
        self.policy_items: list[dict[str, Any]] = []
        self.decision_items: list[dict[str, Any]] = []
        self.contract_quality_items: list[dict[str, Any]] = []

    def add_node(self, node: str, kind: str, label: str, **properties: Any) -> None:
        existing = self.nodes.get(node, {})
        merged_props = dict(existing.get("properties", {}))
        merged_props.update({k: v for k, v in properties.items() if v not in (None, "", [])})
        self.nodes[node] = {
            "id": node,
            "type": kind,
            "label": label,
            "properties": merged_props,
        }

    def add_rel(
        self,
        subject: str,
        predicate: str,
        obj: str,
        source_path: Path,
        source_span: str,
        *,
        valid_from: str | None = None,
        valid_to: str | None = None,
        confidence: float = 1.0,
        extraction_method: str,
        status: str,
    ) -> None:
        rid = "rel:" + stable_id(subject, predicate, obj, str(source_path), source_span, valid_from, valid_to, status)
        self.relationships[rid] = {
            "id": rid,
            "subject": subject,
            "predicate": predicate,
            "object": obj,
            "source_path": str(source_path),
            "source_span": source_span,
            "source_sha256": sha256_file(source_path),
            "observed_at": self.observed_at,
            "valid_from": valid_from or self.scan_date,
            "valid_to": valid_to,
            "confidence": round(float(confidence), 3),
            "extraction_method": extraction_method,
            "status": status,
        }

    def build_note_index(self) -> None:
        paths = list(VAULT.rglob("*.md")) + list(VAULT.rglob("*.canvas"))
        for path in paths:
            if "/ATTACHMENTS/" in path.as_posix():
                continue
            nid = note_id(path)
            rel_no_ext = path.relative_to(VAULT).with_suffix("").as_posix()
            rel_with_ext = path.relative_to(VAULT).as_posix()
            stem = path.stem
            filename = path.name
            for key in {rel_no_ext, rel_with_ext, stem, filename, rel_no_ext.replace("/", "/"), f"Canonical/{stem}"}:
                self.note_index[key] = nid
                self.note_index[key.lower()] = nid
            self.note_paths[nid] = path

    def resolve_note_target(self, target: str) -> str | None:
        candidates = [
            target,
            target.lower(),
            target.replace("\\", "/"),
            target.replace("\\", "/").lower(),
            Path(target).name,
            Path(target).name.lower(),
            Path(target).with_suffix("").as_posix(),
            Path(target).with_suffix("").as_posix().lower(),
        ]
        for candidate in candidates:
            if candidate in self.note_index:
                return self.note_index[candidate]
        return None

    def scan_obsidian(self) -> None:
        self.build_note_index()
        self.coverage_sources.append({
            "source_class": "obsidian_human_overview",
            "status": "scanned",
            "path": str(VAULT),
            "expected": "Markdown and Canvas notes below Human Overview, excluding ATTACHMENTS",
            "scanned_items": len(self.note_paths),
            "coverage_level": "broad_metadata_and_links",
            "limitations": ["frontmatter parser is intentionally light", "body semantics are search text, not full NLP extraction"],
        })
        for path in sorted(self.note_paths.values()):
            text = read_text(path)
            fm, body = parse_frontmatter(text)
            nid = note_id(path)
            label = path.stem
            note_type = "Canvas" if path.suffix == ".canvas" else "Note"
            if label.startswith("Project - "):
                note_type = "Project"
            if label.startswith("System - "):
                note_type = "System"
            self.add_node(
                nid,
                note_type,
                label,
                source_path=str(path),
                updated=fm.get("updated", ""),
                status=fm.get("status", ""),
                relative_path=path.relative_to(VAULT).as_posix(),
                search_text=compact_search_text(body),
            )
            self.validate_complete_context_note(path, fm, body, text)
            if fm.get("status"):
                status_node = node_id("status", str(fm["status"]))
                self.add_node(status_node, "Status", str(fm["status"]))
                self.add_rel(
                    nid,
                    "asserts_status",
                    status_node,
                    path,
                    "frontmatter.status",
                    valid_from=str(fm.get("updated") or self.scan_date),
                    extraction_method="frontmatter",
                    status="asserted",
                )
            for key, predicate, kind in [
                ("people", "has_person", "Agent"),
                ("features", "has_feature", "Feature"),
                ("systems", "has_system", "System"),
                ("categories", "has_category", "Category"),
                ("tags", "has_category", "Category"),
            ]:
                for item in as_list(fm.get(key)):
                    oid = node_id(kind.lower(), item)
                    self.add_node(oid, kind, item)
                    self.add_rel(
                        nid,
                        predicate,
                        oid,
                        path,
                        f"frontmatter.{key}",
                        valid_from=str(fm.get("updated") or self.scan_date),
                        extraction_method="frontmatter",
                        status="asserted",
                    )
            for match in WIKILINK_RE.finditer(body):
                target = clean_wikilink(match.group(1))
                if not target:
                    continue
                target_node = self.resolve_note_target(target)
                line_no = body[: match.start()].count("\n") + 1
                if target_node:
                    self.add_rel(
                        nid,
                        "links_to",
                        target_node,
                        path,
                        f"wikilink:{target}:line:{line_no}",
                        valid_from=str(fm.get("updated") or self.scan_date),
                        confidence=0.98,
                        extraction_method="wikilink",
                        status="observed",
                    )
                else:
                    unknown = node_id("unknown", target)
                    self.add_node(unknown, "UnknownTarget", target)
                    self.add_rel(
                        nid,
                        "mentions_unknown_target",
                        unknown,
                        path,
                        f"wikilink:{target}:line:{line_no}",
                        valid_from=str(fm.get("updated") or self.scan_date),
                        confidence=0.8,
                        extraction_method="wikilink",
                        status="observed",
                    )
            self.extract_heading_statuses(path, nid, body, str(fm.get("updated") or self.scan_date))

    def scan_vault_umlaut_hygiene(self) -> None:
        """Find likely legacy ASCII umlaut spellings in operator-facing Vault prose."""
        sample_limit = 300
        findings: list[dict[str, Any]] = []
        top_files: dict[str, int] = {}
        total_findings = 0
        scanned = 0
        for path in sorted(self.note_paths.values()):
            if path.suffix.lower() != ".md":
                continue
            rel = path.relative_to(VAULT).as_posix()
            if rel.startswith(("ATTACHMENTS/", "LLM Deep Research/reports/")):
                continue
            scanned += 1
            in_code_fence = False
            for line_no, line in enumerate(read_text(path).splitlines(), start=1):
                stripped = line.strip()
                if stripped.startswith("```"):
                    in_code_fence = not in_code_fence
                    continue
                if not stripped or in_code_fence:
                    continue
                visible_prose = re.sub(r"`[^`]*`|\[\[[^\]]+\]\]|\bhttps?://\S+", "", line)
                for pattern, suggestion in UMLAUT_ASCII_PATTERNS:
                    match = pattern.search(visible_prose)
                    if not match:
                        continue
                    path_key = str(path)
                    total_findings += 1
                    top_files[path_key] = top_files.get(path_key, 0) + 1
                    if len(findings) < sample_limit:
                        findings.append({
                            "path": path_key,
                            "line": line_no,
                            "token": match.group(0),
                            "suggestion": suggestion,
                            "excerpt": line.strip()[:220],
                        })
                    break
        sorted_top_files = [
            {"path": path, "finding_count": count}
            for path, count in sorted(top_files.items(), key=lambda item: (-item[1], item[0]))[:20]
        ]
        payload = {
            "generated_at": self.observed_at,
            "status": "WARN" if total_findings else "PASS",
            "scanned_files": scanned,
            "finding_count": total_findings,
            "sample_count": len(findings),
            "sample_limit": sample_limit,
            "truncated": total_findings > len(findings),
            "top_files": sorted_top_files,
            "rule": "Detect likely German ae/oe/ue transliterations in operator-facing Vault prose. Code fences, inline code spans, wikilinks and URLs are excluded because paths, slugs, commands and quoted source text can be intentional.",
            "items": findings,
        }
        write_json(VAULT_UMLAUT_HYGIENE_PATH, payload)
        write_markdown_table(
            OUTPUT_DIR / "vault_umlaut_hygiene.md",
            "Vault Umlaut Hygiene",
            [
                "Report-only Check fuer alte ae/oe/ue-Schreibweisen in operator-facing Vault-Prosa.",
                "Code-Fences, Inline-Code, Wikilinks und URLs werden nicht als Prosa gezaehlt.",
                "WARN bedeutet: bitte gezielt nachziehen, nicht global suchen/ersetzen.",
                f"Findings total: {total_findings}; sample shown: {len(findings)}; scanned files: {scanned}.",
            ],
            ["path", "line", "token", "suggestion", "excerpt"],
            findings,
        )
        self.coverage_sources.append({
            "source_class": "vault_umlaut_hygiene",
            "status": "scanned",
            "path": str(VAULT_UMLAUT_HYGIENE_PATH),
            "expected": "Report likely ASCII umlaut spellings in Vault prose",
            "scanned_items": scanned,
            "coverage_level": "operator_facing_markdown_hygiene",
            "limitations": ["WARN only", "excludes quoted source text, paths, slugs, wikilinks, URLs and code"],
        })

    def scan_skill_policy_regression_guards(self) -> None:
        """Check whether active skills/policies require a regression gate before accepting improvements."""
        items: list[dict[str, Any]] = []
        for target_id, path, role in SKILL_POLICY_REGRESSION_TARGETS:
            exists = path.exists()
            text = read_text(path) if exists else ""
            normalized = normalize_text_for_gate(text)
            has_quality_gate = any(token in normalized for token in [
                "quality gate",
                "quality baseline",
                "quality gate muss pass",
                "pig py quality gate",
                "npm run check all",
                "verify all",
            ])
            has_regression_guard = any(token in normalized for token in [
                "regression",
                "keine neuen fehler",
                "keine neuen einschraenkungen",
                "new failed checks",
                "increased p0",
                "increased coverage gaps",
                "no new errors",
                "new errors",
                "new restrictions",
                "no regressions",
            ])
            has_rejection_rule = any(token in normalized for token in [
                "keine akzeptierte verbesserung",
                "not an accepted improvement",
                "accepted improvement",
                "before calling a change an improvement",
                "nur echte verbesserung",
                "reject failed improvement",
                "nur als kandidat",
            ])
            missing = []
            if not exists:
                missing.append("target_exists")
            if not has_quality_gate:
                missing.append("quality_gate_or_verifier")
            if not has_regression_guard:
                missing.append("regression_guard")
            if not has_rejection_rule:
                missing.append("reject_failed_improvement")
            status = "WARN" if missing else "PASS"
            items.append({
                "target_id": target_id,
                "role": role,
                "path": str(path),
                "status": status,
                "missing_fields": missing,
                "summary": (
                    f"{role} lacks full regression-gated improvement wording: {', '.join(missing)}"
                    if missing
                    else f"{role} requires quality/regression gate before accepting improvements."
                ),
                "recommended_action": (
                    "analyse this entry point before patching; add a no-regression acceptance rule only if it actually controls improvements"
                    if missing
                    else "ready"
                ),
            })
        payload = {
            "generated_at": self.observed_at,
            "status": "WARN" if any(item["status"] == "WARN" for item in items) else "PASS",
            "targets_checked": len(items),
            "items": items,
        }
        write_json(SKILL_POLICY_REGRESSION_AUDIT_PATH, payload)
        write_markdown_table(
            OUTPUT_DIR / "skill_policy_regression_guard_audit.md",
            "Skill Policy Regression Guard Audit",
            [
                "Prueft, ob aktive Skills, Policies und Autoresearch-/Verbesserungsloops Verbesserungen erst nach Regression-Gate akzeptieren.",
                "WARN heisst: nicht blind patchen, sondern den Einstiegspunkt neu bewerten und dann gezielt schaerfen.",
            ],
            ["target_id", "role", "status", "path", "missing_fields", "summary", "recommended_action"],
            items,
        )
        self.coverage_sources.append({
            "source_class": "skill_policy_regression_guard_audit",
            "status": "scanned",
            "path": str(SKILL_POLICY_REGRESSION_AUDIT_PATH),
            "expected": "Active improvement loops reject changes that add errors or restrictions",
            "scanned_items": len(items),
            "coverage_level": "entrypoint_policy_text",
            "limitations": ["text audit only", "does not prove downstream runtime enforcement"],
        })

    def resolve_registry_path(self, value: str) -> Path:
        path = Path(value)
        return path if path.is_absolute() else WORKSPACE / path

    def scan_rule_propagation_registry(self) -> None:
        """Check whether systemwide rules are propagated to the entrypoints they must govern."""
        payload = read_json(RULE_PROPAGATION_REGISTRY_PATH, default=None)
        items: list[dict[str, Any]] = []
        rules = payload.get("rules", []) if isinstance(payload, dict) else []
        registry_errors: list[str] = []
        required_rule_fields = [
            "rule_id",
            "title",
            "aliases",
            "source_anchors",
            "impact_scopes",
            "required_targets",
            "verifier",
            "acceptance_rule",
            "propagation_status",
        ]
        if not isinstance(payload, dict):
            registry_errors.append("registry is not a JSON object")
        elif not rules:
            registry_errors.append("registry has no rules")

        registry_node = node_id("rule-propagation-registry", "Systemwide Rule Propagation Registry")
        self.add_node(registry_node, "RulePropagationRegistry", "Systemwide Rule Propagation Registry", source_path=str(RULE_PROPAGATION_REGISTRY_PATH))
        pig_node = node_id("system", "Project Intelligence Graph")
        self.add_node(pig_node, "System", "Project Intelligence Graph", source_path=str(WORKSPACE))
        self.add_rel(
            pig_node,
            "checks",
            registry_node,
            RULE_PROPAGATION_REGISTRY_PATH,
            "rule_propagation_registry",
            confidence=0.97,
            extraction_method="quality_gate_scan",
            status="verified",
        )

        for rule in rules if isinstance(rules, list) else []:
            if not isinstance(rule, dict):
                items.append({
                    "rule_id": "invalid_rule",
                    "target_id": "",
                    "status": "FAIL",
                    "path": str(RULE_PROPAGATION_REGISTRY_PATH),
                    "missing_fields": ["rule_object"],
                    "summary": "Rule entry is not a JSON object.",
                    "recommended_action": "replace this rule entry with a valid object",
                })
                continue
            missing_rule_fields = [field for field in required_rule_fields if rule.get(field) in (None, "", [], {})]
            rule_id = str(rule.get("rule_id") or "missing_rule_id")
            rule_node = node_id("rule-propagation-rule", rule_id)
            self.add_node(
                rule_node,
                "RulePropagationRule",
                str(rule.get("title") or rule_id),
                source_path=str(RULE_PROPAGATION_REGISTRY_PATH),
                rule_id=rule_id,
                aliases=rule.get("aliases", []),
                impact_scopes=rule.get("impact_scopes", []),
                propagation_status=rule.get("propagation_status", ""),
                acceptance_rule=rule.get("acceptance_rule", ""),
            )
            self.add_rel(
                registry_node,
                "contains",
                rule_node,
                RULE_PROPAGATION_REGISTRY_PATH,
                f"rule:{rule_id}",
                confidence=0.98,
                extraction_method="quality_gate_scan",
                status="verified",
            )
            if missing_rule_fields:
                items.append({
                    "rule_id": rule_id,
                    "target_id": "",
                    "status": "FAIL",
                    "path": str(RULE_PROPAGATION_REGISTRY_PATH),
                    "missing_fields": missing_rule_fields,
                    "summary": f"Rule {rule_id} is missing required registry fields.",
                    "recommended_action": "complete the rule entry before relying on propagation audit",
                })
                continue
            for anchor in rule.get("source_anchors", []):
                anchor_path = self.resolve_registry_path(str(anchor))
                if not anchor_path.exists():
                    items.append({
                        "rule_id": rule_id,
                        "target_id": "source_anchor",
                        "status": "FAIL",
                        "path": str(anchor_path),
                        "missing_fields": ["source_anchor_exists"],
                        "summary": f"Source anchor for {rule_id} does not exist.",
                        "recommended_action": "fix source_anchors or create the durable rule anchor",
                    })
            for target in rule.get("required_targets", []):
                if not isinstance(target, dict):
                    continue
                target_id = str(target.get("target_id") or "missing_target_id")
                target_path = self.resolve_registry_path(str(target.get("path", "")))
                target_kind = str(target.get("kind") or "file")
                required_terms = [str(term) for term in target.get("required_terms", []) if str(term).strip()]
                target_node = node_id(target_kind, f"{target_id}:{target_path}")
                self.add_node(target_node, "AgentEntryPoint" if "entrypoint" in target_kind or "skill" in target_kind else "File", target_id, source_path=str(target_path), entrypoint_kind=target_kind)
                self.add_rel(
                    rule_node,
                    "propagates_to",
                    target_node,
                    RULE_PROPAGATION_REGISTRY_PATH,
                    f"rule:{rule_id}.target:{target_id}",
                    confidence=0.96,
                    extraction_method="quality_gate_scan",
                    status="verified",
                )
                text = read_text(target_path) if target_path.exists() else ""
                normalized = normalize_text_for_gate(text)
                missing_terms = [term for term in required_terms if normalize_text_for_gate(term) not in normalized]
                missing: list[str] = []
                if not target_path.exists():
                    missing.append("target_exists")
                if missing_terms:
                    missing.extend([f"term:{term}" for term in missing_terms])
                item_status = "WARN" if missing else "PASS"
                items.append({
                    "rule_id": rule_id,
                    "target_id": target_id,
                    "kind": target_kind,
                    "status": item_status,
                    "path": str(target_path),
                    "required_terms": required_terms,
                    "missing_fields": missing,
                    "summary": (
                        f"{rule_id} is not fully visible in {target_id}: {', '.join(missing)}"
                        if missing
                        else f"{rule_id} is visible in {target_id}."
                    ),
                    "recommended_action": (
                        "propagate the rule wording or mark the target as intentionally exempt"
                        if missing
                        else "ready"
                    ),
                })
        status = "FAIL" if registry_errors or any(item["status"] == "FAIL" for item in items) else ("WARN" if any(item["status"] == "WARN" for item in items) else "PASS")
        audit = {
            "generated_at": self.observed_at,
            "status": status,
            "rules_checked": len(rules) if isinstance(rules, list) else 0,
            "targets_checked": len(items),
            "registry_errors": registry_errors,
            "items": items,
            "source": str(RULE_PROPAGATION_REGISTRY_PATH),
        }
        write_json(OUTPUT_DIR / "rule_propagation_audit.json", audit)
        write_markdown_table(
            OUTPUT_DIR / "rule_propagation_audit.md",
            "Rule Propagation Audit",
            [
                "Prueft, ob systemweite Operator-Regeln in Skills, Agenten-Entry-Points, Policies und Runtime-Rails sichtbar sind.",
                "WARN bedeutet: Regel wurde nicht in jedem erwarteten Ziel gefunden; FAIL bedeutet kaputte Registry oder fehlender fuehrender Anker.",
            ],
            ["rule_id", "target_id", "kind", "status", "path", "missing_fields", "summary", "recommended_action"],
            items,
        )
        self.contract_quality_items.append({
            "item_id": f"rule-propagation-registry-{stable_id(status, len(items))}",
            "severity": "fail" if status == "FAIL" else ("warn" if status == "WARN" else "info"),
            "artifact_kind": "systemwide_rule_propagation:registry",
            "status": status,
            "path": str(RULE_PROPAGATION_REGISTRY_PATH),
            "summary": f"Rule propagation audit status={status}, rules={len(rules) if isinstance(rules, list) else 0}, targets={len(items)}.",
            "required_fields": required_rule_fields,
            "missing_fields": registry_errors,
            "recommended_action": "repair rule registry before accepting systemwide rule changes" if status == "FAIL" else "review WARN targets or continue",
        })
        self.coverage_sources.append({
            "source_class": "rule_propagation_registry",
            "status": "scanned",
            "path": str(RULE_PROPAGATION_REGISTRY_PATH),
            "expected": "Systemwide rules declare all required propagation targets and verifiers",
            "scanned_items": len(items),
            "coverage_level": "rule_to_entrypoint_text_gate",
            "limitations": ["text presence audit", "does not execute every downstream project verifier"],
        })

    def scan_project_invariant_registry(self) -> None:
        """Validate project-level invariants that must be considered by cross-project improvements."""
        payload = read_json(PROJECT_INVARIANT_REGISTRY_PATH, default=None)
        projects = payload.get("projects", []) if isinstance(payload, dict) else []
        items: list[dict[str, Any]] = []
        registry_errors: list[str] = []
        required_fields = [
            "project_id",
            "title",
            "scope",
            "operator_intent",
            "invariants",
            "forbidden_without_operator_go",
            "verifiers",
            "surfaces",
        ]
        if not isinstance(payload, dict):
            registry_errors.append("registry is not a JSON object")
        elif not projects:
            registry_errors.append("registry has no projects")
        registry_node = node_id("project-invariant-registry", "Project Invariant Registry")
        self.add_node(registry_node, "ProjectInvariantRegistry", "Project Invariant Registry", source_path=str(PROJECT_INVARIANT_REGISTRY_PATH))
        for project in projects if isinstance(projects, list) else []:
            if not isinstance(project, dict):
                continue
            project_id = str(project.get("project_id") or "missing_project_id")
            missing = [field for field in required_fields if project.get(field) in (None, "", [], {})]
            node = node_id("project-invariant", project_id)
            self.add_node(
                node,
                "ProjectInvariant",
                str(project.get("title") or project_id),
                source_path=str(PROJECT_INVARIANT_REGISTRY_PATH),
                project_id=project_id,
                operator_intent=project.get("operator_intent", ""),
                invariants=project.get("invariants", []),
                forbidden_without_operator_go=project.get("forbidden_without_operator_go", []),
            )
            self.add_rel(
                registry_node,
                "declares_invariant",
                node,
                PROJECT_INVARIANT_REGISTRY_PATH,
                f"project:{project_id}",
                confidence=0.98,
                extraction_method="quality_gate_scan",
                status="verified",
            )
            items.append({
                "project_id": project_id,
                "title": project.get("title", ""),
                "status": "FAIL" if missing else "PASS",
                "missing_fields": missing,
                "verifiers": project.get("verifiers", []),
                "surfaces": project.get("surfaces", []),
                "summary": (
                    f"{project_id} invariant entry is missing: {', '.join(missing)}"
                    if missing
                    else f"{project_id} declares operator intent, invariants, gates, verifiers and surfaces."
                ),
                "recommended_action": "complete invariant entry before cross-project propagation" if missing else "ready",
            })
        status = "FAIL" if registry_errors or any(item["status"] == "FAIL" for item in items) else "PASS"
        audit = {
            "generated_at": self.observed_at,
            "status": status,
            "projects_checked": len(items),
            "registry_errors": registry_errors,
            "items": items,
            "source": str(PROJECT_INVARIANT_REGISTRY_PATH),
        }
        write_json(OUTPUT_DIR / "project_invariant_audit.json", audit)
        write_markdown_table(
            OUTPUT_DIR / "project_invariant_audit.md",
            "Project Invariant Audit",
            [
                "Prueft, ob Kernprojekte ihre Operator-Intention, Nicht-ohne-Go-Grenzen, Verifier und Oberflaechen maschinenlesbar tragen.",
                "Diese Registry ist der Rueckwaertsplan vom Endzustand: erst wissen, was nie kaputtgehen darf, dann bauen.",
            ],
            ["project_id", "title", "status", "missing_fields", "verifiers", "surfaces", "summary", "recommended_action"],
            items,
        )
        self.contract_quality_items.append({
            "item_id": f"project-invariant-registry-{stable_id(status, len(items))}",
            "severity": "fail" if status == "FAIL" else "info",
            "artifact_kind": "project_invariant:registry",
            "status": status,
            "path": str(PROJECT_INVARIANT_REGISTRY_PATH),
            "summary": f"Project invariant audit status={status}, projects={len(items)}.",
            "required_fields": required_fields,
            "missing_fields": registry_errors,
            "recommended_action": "repair project invariant registry" if status == "FAIL" else "ready for impact-radius checks",
        })
        self.coverage_sources.append({
            "source_class": "project_invariant_registry",
            "status": "scanned",
            "path": str(PROJECT_INVARIANT_REGISTRY_PATH),
            "expected": "Cross-project improvement checks know project invariants, gates, verifiers and surfaces",
            "scanned_items": len(items),
            "coverage_level": "project_invariant_contract_gate",
            "limitations": ["declares verifier commands, does not run every project verifier"],
        })

    def scan_agent_entrypoint_registry(self) -> None:
        """Validate that known agent start points are registered and mapped to propagation rules."""
        payload = read_json(AGENT_ENTRYPOINT_REGISTRY_PATH, default=None)
        rule_payload = read_json(RULE_PROPAGATION_REGISTRY_PATH, default={})
        rule_ids = {str(rule.get("rule_id")) for rule in rule_payload.get("rules", []) if isinstance(rule, dict)}
        entrypoints = payload.get("entrypoints", []) if isinstance(payload, dict) else []
        items: list[dict[str, Any]] = []
        registry_errors: list[str] = []
        if not isinstance(payload, dict):
            registry_errors.append("registry is not a JSON object")
        elif not entrypoints:
            registry_errors.append("registry has no entrypoints")
        registry_node = node_id("agent-entrypoint-registry", "Agent Entry Point Registry")
        self.add_node(registry_node, "AgentEntryPointRegistry", "Agent Entry Point Registry", source_path=str(AGENT_ENTRYPOINT_REGISTRY_PATH))
        for entry in entrypoints if isinstance(entrypoints, list) else []:
            if not isinstance(entry, dict):
                continue
            entrypoint_id = str(entry.get("entrypoint_id") or "missing_entrypoint_id")
            path = self.resolve_registry_path(str(entry.get("path", "")))
            required_rule_ids = [str(rule_id) for rule_id in entry.get("required_rule_ids", [])]
            missing: list[str] = []
            if not path.exists():
                missing.append("entrypoint_exists")
            unknown_rules = [rule_id for rule_id in required_rule_ids if rule_id not in rule_ids]
            missing.extend([f"unknown_rule:{rule_id}" for rule_id in unknown_rules])
            if not required_rule_ids:
                missing.append("required_rule_ids")
            node = node_id("agent-entrypoint", entrypoint_id)
            self.add_node(node, "AgentEntryPoint", entrypoint_id, source_path=str(path), role=entry.get("role", ""), required_rule_ids=required_rule_ids)
            self.add_rel(
                registry_node,
                "contains",
                node,
                AGENT_ENTRYPOINT_REGISTRY_PATH,
                f"entrypoint:{entrypoint_id}",
                confidence=0.97,
                extraction_method="quality_gate_scan",
                status="verified",
            )
            for rule_id in required_rule_ids:
                if rule_id in rule_ids:
                    self.add_rel(
                        node,
                        "requires_propagation",
                        node_id("rule-propagation-rule", rule_id),
                        AGENT_ENTRYPOINT_REGISTRY_PATH,
                        f"entrypoint:{entrypoint_id}.requires:{rule_id}",
                        confidence=0.95,
                        extraction_method="quality_gate_scan",
                        status="verified",
                    )
            items.append({
                "entrypoint_id": entrypoint_id,
                "role": entry.get("role", ""),
                "status": "FAIL" if missing else "PASS",
                "path": str(path),
                "required_rule_ids": required_rule_ids,
                "missing_fields": missing,
                "summary": (
                    f"{entrypoint_id} registry entry is incomplete: {', '.join(missing)}"
                    if missing
                    else f"{entrypoint_id} exists and maps to required propagation rules."
                ),
                "recommended_action": "repair entrypoint registry before claiming agent-start coverage" if missing else "ready",
            })
        status = "FAIL" if registry_errors or any(item["status"] == "FAIL" for item in items) else "PASS"
        audit = {
            "generated_at": self.observed_at,
            "status": status,
            "entrypoints_checked": len(items),
            "registry_errors": registry_errors,
            "items": items,
            "source": str(AGENT_ENTRYPOINT_REGISTRY_PATH),
        }
        write_json(OUTPUT_DIR / "agent_entrypoint_audit.json", audit)
        write_markdown_table(
            OUTPUT_DIR / "agent_entrypoint_audit.md",
            "Agent Entry Point Audit",
            [
                "Prueft, ob Agenten-Startpunkte als Ziele fuer systemweite Regeln registriert sind.",
                "Der eigentliche Textnachweis liegt im Rule Propagation Audit.",
            ],
            ["entrypoint_id", "role", "status", "path", "required_rule_ids", "missing_fields", "summary", "recommended_action"],
            items,
        )
        self.contract_quality_items.append({
            "item_id": f"agent-entrypoint-registry-{stable_id(status, len(items))}",
            "severity": "fail" if status == "FAIL" else "info",
            "artifact_kind": "agent_entrypoint:registry",
            "status": status,
            "path": str(AGENT_ENTRYPOINT_REGISTRY_PATH),
            "summary": f"Agent entrypoint audit status={status}, entrypoints={len(items)}.",
            "required_fields": ["entrypoint_id", "path", "role", "required_rule_ids", "status"],
            "missing_fields": registry_errors,
            "recommended_action": "repair agent entrypoint registry" if status == "FAIL" else "ready",
        })
        self.coverage_sources.append({
            "source_class": "agent_entrypoint_registry",
            "status": "scanned",
            "path": str(AGENT_ENTRYPOINT_REGISTRY_PATH),
            "expected": "Known agent start points are mapped to required systemwide rules",
            "scanned_items": len(items),
            "coverage_level": "entrypoint_registry_gate",
            "limitations": ["does not replace detailed rule propagation text audit"],
        })

    def scan_operator_intent_contract_schema(self) -> None:
        """Validate the schema/template used to compile broad operator signals into build contracts."""
        schema = read_json(OPERATOR_INTENT_CONTRACT_SCHEMA_PATH, default=None)
        template_text = read_text(OPERATOR_INTENT_TEMPLATE_PATH) if OPERATOR_INTENT_TEMPLATE_PATH.exists() else ""
        required_fields = [
            "operator_signal",
            "plain_language_goal",
            "target_picture",
            "done_definition",
            "non_goals",
            "affected_projects",
            "impact_radius",
            "rule_candidates",
            "operator_gates",
            "deterministic_system_preference",
            "cost_policy",
            "verifier_plan",
            "propagation_check_required",
            "next_safe_block",
            "status",
        ]
        schema_required = schema.get("required", []) if isinstance(schema, dict) else []
        missing_schema = [field for field in required_fields if field not in schema_required]
        normalized_template = normalize_text_for_gate(template_text)
        missing_template = [field for field in required_fields if normalize_text_for_gate(field) not in normalized_template]
        errors = []
        if not isinstance(schema, dict):
            errors.append("schema is not valid JSON object")
        if not OPERATOR_INTENT_TEMPLATE_PATH.exists():
            errors.append("template missing")
        contract_items: list[dict[str, Any]] = []
        materialized_paths = sorted(OPERATOR_INTENT_CONTRACTS_DIR.glob("*.json")) if OPERATOR_INTENT_CONTRACTS_DIR.exists() else []
        for contract_path in materialized_paths:
            contract = read_json(contract_path, default=None)
            contract_missing: list[str] = []
            contract_errors: list[str] = []
            if not isinstance(contract, dict):
                contract_errors.append("contract is not valid JSON object")
                contract = {}
            for field in required_fields:
                if contract.get(field) in (None, "", [], {}):
                    contract_missing.append(field)
            contract_status = "FAIL" if contract_missing or contract_errors else "PASS"
            contract_items.append({
                "schema_path": str(OPERATOR_INTENT_CONTRACT_SCHEMA_PATH),
                "template_path": str(OPERATOR_INTENT_TEMPLATE_PATH),
                "contract_path": str(contract_path),
                "intent_id": contract.get("intent_id", contract_path.stem),
                "status": contract_status,
                "missing_schema_fields": [],
                "missing_template_fields": [],
                "missing_contract_fields": contract_missing,
                "errors": contract_errors,
                "summary": (
                    f"Materialized Operator Intent Contract {contract_path.name} is incomplete."
                    if contract_status == "FAIL"
                    else f"Materialized Operator Intent Contract {contract_path.name} is complete."
                ),
                "recommended_action": "repair materialized intent contract" if contract_status == "FAIL" else "ready",
            })
            contract_instance_node = node_id("operator-intent-instance", contract_path.stem)
            self.add_node(
                contract_instance_node,
                "OperatorIntentContract",
                contract.get("intent_id", contract_path.stem),
                source_path=str(contract_path),
                status=contract.get("status", "unknown"),
                affected_projects=contract.get("affected_projects", []),
            )
            self.add_rel(
                contract_instance_node,
                "uses",
                node_id("operator-intent-contract", "Operator Intent Contract"),
                contract_path,
                "operator_intent_contract_instance",
                confidence=0.95,
                extraction_method="quality_gate_scan",
                status="verified" if contract_status == "PASS" else "needs_review",
            )
        if any(item["status"] == "FAIL" for item in contract_items):
            errors.append("one or more materialized intent contracts are incomplete")
        status = "FAIL" if errors or missing_schema or missing_template else "PASS"
        item = {
            "schema_path": str(OPERATOR_INTENT_CONTRACT_SCHEMA_PATH),
            "template_path": str(OPERATOR_INTENT_TEMPLATE_PATH),
            "contract_path": "",
            "intent_id": "schema_template",
            "status": status,
            "missing_schema_fields": missing_schema,
            "missing_template_fields": missing_template,
            "missing_contract_fields": [],
            "errors": errors,
            "summary": (
                "Operator Intent Contract schema/template is incomplete."
                if status == "FAIL"
                else f"Operator Intent Contract schema/template are complete; materialized contracts={len(contract_items)}."
            ),
            "recommended_action": "complete schema/template before compiling broad operator requests" if status == "FAIL" else "ready",
        }
        contract_node = node_id("operator-intent-contract", "Operator Intent Contract")
        self.add_node(
            contract_node,
            "OperatorIntentContract",
            "Operator Intent Contract",
            source_path=str(OPERATOR_INTENT_CONTRACT_SCHEMA_PATH),
            required_fields=required_fields,
        )
        self.add_rel(
            node_id("system", "Project Intelligence Graph"),
            "defines",
            contract_node,
            OPERATOR_INTENT_CONTRACT_SCHEMA_PATH,
            "operator_intent_contract_schema",
            confidence=0.98,
            extraction_method="quality_gate_scan",
            status="verified",
        )
        audit = {
            "generated_at": self.observed_at,
            "status": status,
            "items": [item, *contract_items],
            "required_fields": required_fields,
            "materialized_contract_count": len(contract_items),
        }
        write_json(OUTPUT_DIR / "operator_intent_contract_audit.json", audit)
        write_markdown_table(
            OUTPUT_DIR / "operator_intent_contract_audit.md",
            "Operator Intent Contract Audit",
            [
                "Prueft, ob breite Operator-Signale in eine feste Zielbild-/Nicht-Ziel-/Verifier-/Propagation-Struktur uebersetzt werden koennen.",
            ],
            ["schema_path", "template_path", "contract_path", "intent_id", "status", "missing_schema_fields", "missing_template_fields", "missing_contract_fields", "errors", "summary", "recommended_action"],
            [item, *contract_items],
        )
        self.contract_quality_items.append({
            "item_id": f"operator-intent-contract-{stable_id(status, ','.join(missing_schema + missing_template + errors) or 'pass')}",
            "severity": "fail" if status == "FAIL" else "info",
            "artifact_kind": "operator_intent_contract:schema",
            "status": status,
            "path": str(OPERATOR_INTENT_CONTRACT_SCHEMA_PATH),
            "summary": item["summary"],
            "required_fields": required_fields,
            "missing_fields": missing_schema + missing_template + errors,
            "recommended_action": item["recommended_action"],
        })
        self.coverage_sources.append({
            "source_class": "operator_intent_contract",
            "status": "scanned",
            "path": f"{OPERATOR_INTENT_CONTRACT_SCHEMA_PATH} | {OPERATOR_INTENT_TEMPLATE_PATH} | {OPERATOR_INTENT_CONTRACTS_DIR}",
            "expected": "Broad operator signals can be compiled into target picture, gates, propagation and verifier plan",
            "scanned_items": 1 + len(contract_items),
            "coverage_level": "schema_template_and_materialized_contract_gate",
            "limitations": (
                ["no materialized intent contracts yet"]
                if not contract_items
                else ["materialized contracts are local planning artifacts; project-specific implementation verifiers still decide acceptance"]
            ),
        })

    def extract_heading_statuses(self, path: Path, nid: str, body: str, valid_from: str) -> None:
        for match in HEADING_RE.finditer(body):
            heading = match.group(2).strip()
            if "aktueller stand" not in heading.lower() and "aktuelle wahrheit" not in heading.lower():
                continue
            span_start = match.end()
            span = body[span_start : span_start + 1200]
            for status_match in STATUS_RE.finditer(span):
                value = status_match.group(1)
                status_node = node_id("status", value)
                self.add_node(status_node, "Status", value)
                self.add_rel(
                    nid,
                    "asserts_status",
                    status_node,
                    path,
                    f"heading:{heading}",
                    valid_from=valid_from,
                    confidence=0.72,
                    extraction_method="markdown_heading",
                    status="asserted",
                )

    def scan_handoffs(self) -> None:
        scanned_roots = 0
        scanned_files = 0
        for root in [WORKSPACE / "company-dossier-lab", WORKSPACE / "company-dossier-lab-core-v2-final"]:
            ops = root / "ops/ai-handoff"
            if not ops.exists():
                self.coverage_sources.append({
                    "source_class": "handoff_artifacts",
                    "status": "missing",
                    "path": str(ops),
                    "expected": "Room16/Quellwert ai-handoff artifacts",
                    "scanned_items": 0,
                    "coverage_level": "none",
                    "limitations": ["root not present"],
                })
                continue
            scanned_roots += 1
            repo_node = node_id("repo", root.name)
            self.add_node(repo_node, "Repository", root.name, source_path=str(root))
            for path in sorted(ops.rglob("*")):
                if path.suffix.lower() not in {".json", ".jsonl", ".md"}:
                    continue
                scanned_files += 1
                artifact_type = self.artifact_type(path)
                artifact_node = node_id("artifact", path.relative_to(root).as_posix())
                self.add_node(artifact_node, artifact_type, path.name, source_path=str(path), repo=root.name)
                self.add_rel(
                    repo_node,
                    "contains_artifact",
                    artifact_node,
                    path,
                    "path",
                    extraction_method="derived_rule",
                    status="observed",
                )
                lane_name = self.lane_from_path(path)
                if lane_name:
                    lane_node = node_id("lane", lane_name)
                    self.add_node(lane_node, "Lane", lane_name)
                    self.add_rel(
                        lane_node,
                        "contains_artifact",
                        artifact_node,
                        path,
                        "path.lanes",
                        extraction_method="derived_rule",
                        status="observed",
                    )
                if path.suffix.lower() == ".json":
                    self.scan_json_artifact(path, artifact_node, lane_name)
                elif path.suffix.lower() == ".jsonl":
                    self.scan_jsonl_artifact(path, artifact_node, lane_name)
                else:
                    self.scan_markdown_artifact(path, artifact_node, lane_name)
        self.coverage_sources.append({
            "source_class": "handoff_artifacts",
            "status": "scanned" if scanned_roots else "missing",
            "path": str(WORKSPACE),
            "expected": "company-dossier-lab*/ops/ai-handoff markdown/json/jsonl",
            "scanned_items": scanned_files,
            "coverage_level": "structured_claim_evidence_verifier_partial",
            "limitations": ["does not yet run git/CI reconciliation", "does not deeply validate report promotion state"],
        })

    def artifact_type(self, path: Path) -> str:
        name = path.name.lower()
        if "evidence" in name:
            return "EvidencePack"
        if "claim" in name:
            return "ClaimArtifact"
        if "lane_state" in name:
            return "LaneState"
        if "review" in name or "report" in name or "handoff" in name:
            return "Report"
        return "Artifact"

    def lane_from_path(self, path: Path) -> str | None:
        parts = list(path.parts)
        if "lanes" not in parts:
            return None
        idx = parts.index("lanes")
        if idx + 1 < len(parts):
            return parts[idx + 1]
        return None

    def scan_json_artifact(self, path: Path, artifact_node: str, lane_name: str | None) -> None:
        try:
            payload = json.loads(read_text(path))
        except json.JSONDecodeError as exc:
            self.findings.append({"severity": "error", "type": "json_parse", "path": str(path), "detail": str(exc)})
            return
        self.extract_structured_payload(path, artifact_node, payload, lane_name, "json_artifact")

    def scan_jsonl_artifact(self, path: Path, artifact_node: str, lane_name: str | None) -> None:
        for index, line in enumerate(read_text(path).splitlines(), start=1):
            if not line.strip():
                continue
            try:
                payload = json.loads(line)
            except json.JSONDecodeError as exc:
                self.findings.append({"severity": "error", "type": "jsonl_parse", "path": str(path), "detail": f"line {index}: {exc}"})
                continue
            self.extract_structured_payload(path, artifact_node, payload, lane_name, "jsonl_artifact", source_span=f"line:{index}")

    def scan_markdown_artifact(self, path: Path, artifact_node: str, lane_name: str | None) -> None:
        text = read_text(path)
        for claim_match in re.finditer(r"\b(C\d{3}|VIVI-CLAIM-[A-Z0-9-]+|CLAIM-[A-Z0-9-]+)\b", text):
            claim_id = claim_match.group(1)
            claim_node = node_id("claim", claim_id)
            self.add_node(claim_node, "Claim", claim_id)
            self.add_rel(
                artifact_node,
                "describes_claim",
                claim_node,
                path,
                f"markdown.claim:{claim_id}",
                confidence=0.86,
                extraction_method="markdown_heading",
                status="observed",
            )
            if lane_name:
                lane_node = node_id("lane", lane_name)
                self.add_rel(
                    lane_node,
                    "contains_claim",
                    claim_node,
                    path,
                    f"markdown.claim:{claim_id}",
                    confidence=0.82,
                    extraction_method="derived_rule",
                    status="inferred",
                )

    def extract_structured_payload(
        self,
        path: Path,
        artifact_node: str,
        payload: Any,
        lane_name: str | None,
        method: str,
        source_span: str = "json",
    ) -> None:
        if not isinstance(payload, dict):
            return
        claim_value = first_present(payload, ["claim_id", "id", "claim", "claimId"])
        if isinstance(claim_value, str) and ("CLAIM" in claim_value.upper() or re.match(r"C\d{3}$", claim_value)):
            claim_node = node_id("claim", claim_value)
            self.add_node(claim_node, "Claim", claim_value, status=str(first_present(payload, ["status", "state"]) or ""))
            self.add_rel(
                artifact_node,
                "describes_claim",
                claim_node,
                path,
                source_span,
                confidence=0.95,
                extraction_method=method,
                status="asserted",
            )
            if lane_name:
                lane_node = node_id("lane", lane_name)
                self.add_rel(
                    lane_node,
                    "contains_claim",
                    claim_node,
                    path,
                    source_span,
                    confidence=0.9,
                    extraction_method="derived_rule",
                    status="inferred",
                )
            status_value = first_present(payload, ["status", "state", "acceptance", "verdict"])
            if status_value:
                status_node = node_id("status", str(status_value))
                self.add_node(status_node, "Status", str(status_value))
                self.add_rel(
                    claim_node,
                    "asserts_status",
                    status_node,
                    path,
                    source_span,
                    confidence=0.94,
                    extraction_method=method,
                    status="asserted",
                )
        for key in ["evidence_pack", "evidencePack", "evidence_pack_path", "evidence_ids", "evidence"]:
            value = payload.get(key)
            for item in flatten_values(value):
                if not item:
                    continue
                evidence_node = node_id("evidence", str(item))
                self.add_node(evidence_node, "EvidenceItem", str(item))
                self.add_rel(
                    artifact_node,
                    "has_evidence_pack",
                    evidence_node,
                    path,
                    f"{source_span}.{key}",
                    confidence=0.86,
                    extraction_method=method,
                    status="observed",
                )
        for key in ["verifier", "verification", "tests", "test_command", "commands"]:
            value = payload.get(key)
            for item in flatten_values(value):
                if not item:
                    continue
                verifier_node = node_id("verifier", str(item))
                self.add_node(verifier_node, "Verifier", str(item))
                self.add_rel(
                    artifact_node,
                    "validated_by",
                    verifier_node,
                    path,
                    f"{source_span}.{key}",
                    confidence=0.8,
                    extraction_method=method,
                    status="observed",
                )

    def scan_automations(self) -> None:
        automation_root = Path.home() / ".codex/automations"
        if not automation_root.exists():
            self.coverage_sources.append({
                "source_class": "codex_automations",
                "status": "missing",
                "path": str(automation_root),
                "expected": "automation.toml files",
                "scanned_items": 0,
                "coverage_level": "none",
                "limitations": ["automation root missing"],
            })
            return
        automation_files = sorted(automation_root.glob("*/automation.toml"))
        for toml in automation_files:
            data = parse_toml_light(read_text(toml))
            name = data.get("name") or toml.parent.name
            status = data.get("status") or "unknown"
            kind = data.get("kind") or "automation"
            prompt = data.get("prompt") or ""
            rrule = data.get("rrule") or ""
            cwds = parse_toml_array(read_text(toml), "cwds")
            auto_node = node_id("automation", name)
            risk = classify_automation_risk(toml.parent.name, data, cwds)
            self.automation_risks.append(risk)
            self.add_node(
                auto_node,
                "Automation",
                name,
                source_path=str(toml),
                status=status,
                automation_kind=kind,
                rrule=rrule,
                risk_class=risk["risk_class"],
                mutating_capability=risk["mutating_capability"],
                operator_gate_required=risk["operator_gate_required"],
                risk_tokens=[REDACTED]
            )
            status_node = node_id("status", status)
            self.add_node(status_node, "Status", status)
            self.add_rel(
                auto_node,
                "asserts_status",
                status_node,
                toml,
                "automation.status",
                extraction_method="automation_toml",
                status="asserted",
            )
            kind_node = node_id("automation-kind", kind)
            self.add_node(kind_node, "Category", kind)
            self.add_rel(
                auto_node,
                "has_category",
                kind_node,
                toml,
                "automation.kind",
                extraction_method="automation_toml",
                status="asserted",
            )
            risk_node = node_id("risk", risk["risk_class"])
            self.add_node(risk_node, "RiskClass", risk["risk_class"])
            self.add_rel(
                auto_node,
                "has_risk_class",
                risk_node,
                toml,
                "automation.risk_class",
                confidence=0.92,
                extraction_method="automation_toml",
                status="inferred",
            )
            if risk["operator_gate_required"]:
                gate_node = node_id("gate", "operator-go-required")
                self.add_node(gate_node, "Gate", "operator-go-required")
                self.add_rel(
                    auto_node,
                    "requires_operator_gate",
                    gate_node,
                    toml,
                    "automation.operator_gate_required",
                    confidence=0.9,
                    extraction_method="automation_toml",
                    status="inferred",
                )
            if risk["mutating_capability"] in {"publish_or_deploy", "external_mutation", "memory_or_repo_write"}:
                capability_node = node_id("capability", risk["mutating_capability"])
                self.add_node(capability_node, "Capability", risk["mutating_capability"])
                self.add_rel(
                    auto_node,
                    "can_mutate",
                    capability_node,
                    toml,
                    "automation.prompt_risk_tokens",
                    confidence=0.82,
                    extraction_method="automation_toml",
                    status="inferred",
                )
            for cwd in cwds:
                workspace_node = node_id("workspace", cwd)
                self.add_node(workspace_node, "Workspace", cwd, source_path=cwd)
                self.add_rel(
                    auto_node,
                    "runs_in_workspace",
                    workspace_node,
                    toml,
                    "automation.cwds",
                    confidence=0.9,
                    extraction_method="automation_toml",
                    status="asserted",
                )
        self.coverage_sources.append({
            "source_class": "codex_automations",
            "status": "scanned",
            "path": str(automation_root),
            "expected": "automation.toml files with status, schedule, prompt risk and cwds",
            "scanned_items": len(automation_files),
            "coverage_level": "risk_metadata_prompt_scan",
            "limitations": ["does not inspect historical run logs yet", "next run time is not calculated from RRULE"],
        })

    def scan_repo_git_ci(self) -> None:
        repos = [path for path in REPO_SCAN_ROOTS if path.exists() and (path / ".git").exists()]
        pig_node = node_id("system", "Project Intelligence Graph")
        scanned_verifiers = 0
        for repo in repos:
            rel_repo = repo.as_posix()
            repo_node = node_id("repository", rel_repo)
            branch = run_git(repo, ["rev-parse", "--abbrev-ref", "HEAD"])
            commit = run_git(repo, ["rev-parse", "--short", "HEAD"])
            dirty_count = len([line for line in run_git(repo, ["status", "--short"]).splitlines() if line.strip()])
            self.add_node(
                repo_node,
                "Repository",
                repo.name,
                source_path=rel_repo,
                branch=branch,
                commit=commit,
                dirty_count=dirty_count,
            )
            self.add_rel(
                pig_node,
                "indexes",
                repo_node,
                repo,
                "repo_git_ci.local_repository",
                confidence=0.9,
                extraction_method="static_seed",
                status="observed",
            )
            status_label = "dirty" if dirty_count else "clean"
            status_node = node_id("status", f"git-{status_label}")
            self.add_node(status_node, "Status", f"git-{status_label}")
            self.add_rel(
                repo_node,
                "asserts_status",
                status_node,
                repo,
                "repo_git_ci.git_status",
                confidence=0.9,
                extraction_method="static_seed",
                status="asserted",
            )
            for verifier in discover_repo_verifiers(repo):
                scanned_verifiers += 1
                verifier_node = node_id("verifier", f"{repo.name}:{verifier}")
                self.add_node(verifier_node, "Verifier", f"{repo.name}: {verifier}", source_path=rel_repo)
                self.add_rel(
                    repo_node,
                    "validated_by",
                    verifier_node,
                    repo,
                    "repo_git_ci.verifier_script",
                    confidence=0.78,
                    extraction_method="static_seed",
                    status="observed",
                )
        self.coverage_sources.append({
            "source_class": "repo_git_ci",
            "status": "scanned" if repos else "missing",
            "path": " | ".join(repo.as_posix() for repo in repos) if repos else str(WORKSPACE),
            "expected": "Local git repositories, current branch/commit/dirty status and discoverable verifier scripts",
            "scanned_items": len(repos),
            "coverage_level": "local_git_status_and_verifier_inventory",
            "limitations": ["does not call remote GitHub APIs", "does not fetch CI run history", "dirty count is inventory, not a failure"],
            "verifier_count": scanned_verifiers,
        })

    def scan_runtime_state_and_operator_go(self) -> None:
        runtime_root = Path.home() / "Library/Application Support/LIONCOM/runtime-workspace"
        pig_node = node_id("system", "Project Intelligence Graph")
        runtime_files: list[Path] = []
        if runtime_root.exists():
            for pattern in ["*.json", ".runtime/*.json", "dashboard/data/*.json", ".recovery/*.json", "logs/*.log"]:
                runtime_files.extend(sorted(runtime_root.glob(pattern)))
        for path in runtime_files[:160]:
            file_node = node_id("file", path.as_posix())
            self.add_node(
                file_node,
                "File",
                path.name,
                source_path=str(path),
                relative_path=relative_runtime_path(path),
                modified_at=mtime_iso(path),
            )
            self.add_rel(
                pig_node,
                "indexes",
                file_node,
                path,
                "runtime_logs_and_last_runs.inventory",
                confidence=0.82,
                extraction_method="static_seed",
                status="observed",
            )

        operator_paths = [
            LIONCOM_APP / "scripts/run_operator_go_due.mjs",
            LIONCOM_APP / "scripts/check_operator_go_health.mjs",
            LIONCOM_APP / "scripts/OPERATOR_GO.md",
            LIONCOM_APP / "app/api/operator-go/route.ts",
            LIONCOM_APP / "lib/services/operatorGoStateService.ts",
            LIONCOM_APP / ".runtime/runtime-workspace/.recovery/operator-go-health.json",
            LIONCOM_APP / ".runtime/runtime-workspace/.recovery/operator-go-state.json",
            LIONCOM_APP / ".runtime/runtime-workspace/.recovery/operator-go-publish-log.jsonl",
            runtime_root / ".recovery/operator-go-state.json",
        ]
        existing_operator_paths = [path for path in operator_paths if path.exists()]
        gate_node = node_id("gate", "operator-go-required")
        self.add_node(gate_node, "Gate", "operator-go-required")
        for path in existing_operator_paths:
            file_node = node_id("file", path.as_posix())
            self.add_node(file_node, "File", path.name, source_path=str(path), modified_at=mtime_iso(path))
            self.add_rel(
                pig_node,
                "indexes",
                file_node,
                path,
                "lioncom_operator_go_runtime.inventory",
                confidence=0.9,
                extraction_method="static_seed",
                status="observed",
            )
            self.add_rel(
                file_node,
                "requires_operator_gate",
                gate_node,
                path,
                "lioncom_operator_go_runtime.operator_gate",
                confidence=0.88,
                extraction_method="static_seed",
                status="inferred",
            )
        self.coverage_sources.append({
            "source_class": "lioncom_operator_go_runtime",
            "status": "scanned" if existing_operator_paths else "missing",
            "path": " | ".join(path.as_posix() for path in existing_operator_paths[:6]) if existing_operator_paths else str(LIONCOM_APP),
            "expected": "operator-go health, run-due script, state and publish log surfaces",
            "scanned_items": len(existing_operator_paths),
            "coverage_level": "operator_go_static_lineage_and_state_inventory",
            "limitations": ["does not execute publisher", "does not reconstruct remote approval lineage"],
        })
        self.coverage_sources.append({
            "source_class": "runtime_logs_and_last_runs",
            "status": "scanned" if runtime_files else "missing",
            "path": str(runtime_root),
            "expected": "runtime JSON state, latest run files and logs",
            "scanned_items": len(runtime_files),
            "coverage_level": "runtime_state_and_log_inventory",
            "limitations": ["does not parse every log line", "mtime inventory is not a health verdict"],
        })

    def scan_quality_operating_system(self) -> None:
        paths = sorted(set(
            [path for root in [QUALITY_OS_DOCS, QUALITY_OS_VAULT] if root.exists() for path in root.rglob("*.md")]
            + [path for path in [QUALITY_OS_ROADMAP, N8N_ARCHETYPE_REFERENCE] if path.exists()]
        ))
        for path in paths:
            text = read_text(path)
            fm, body = parse_frontmatter(text)
            artifact_kind = classify_quality_os_artifact(path, fm, text)
            if not artifact_kind:
                continue
            artifact_node = node_id(artifact_kind["node_kind"], artifact_kind["label"])
            self.add_node(
                artifact_node,
                artifact_kind["node_type"],
                artifact_kind["label"],
                source_path=str(path),
                status=str(fm.get("status") or "observed"),
                relative_path=relative_quality_path(path),
                search_text=compact_search_text(body),
            )
            self.validate_quality_os_artifact(path, artifact_kind, text)
            if artifact_kind["node_type"] == "Archetype":
                library_node = node_id("library", "Archetype Library V1")
                self.add_node(library_node, "ArchetypeLibrary", "Archetype Library V1", source_path=str(QUALITY_OS_VAULT))
                self.add_rel(
                    library_node,
                    "contains",
                    artifact_node,
                    path,
                    "quality_os.archetype_library",
                    confidence=0.96,
                    extraction_method="quality_gate_scan",
                    status="verified",
                )
        self.add_quality_os_static_relationships()
        self.coverage_sources.append({
            "source_class": "quality_operating_system_contracts",
            "status": "scanned",
            "path": f"{QUALITY_OS_DOCS} | {QUALITY_OS_VAULT}",
            "expected": "Build contracts, archetypes, job cards, execution history, roadmap quality and n8n-as-reference boundary",
            "scanned_items": len(paths),
            "coverage_level": "required_field_and_relationship_gate",
            "limitations": ["validates declared structures, not yet every historical roadmap in the Vault"],
        })

    def scan_long_run_completion_entrypoints(self) -> None:
        """Ensure unattended-run discipline is wired into every known agent entry point."""
        rule_exists = LONG_RUN_RULE.exists()
        rule_text = read_text(LONG_RUN_RULE) if rule_exists else ""
        rule_normalized = normalize_text_for_gate(rule_text)
        rule_required = {
            "rule_file_exists": rule_exists,
            "defines_completion_states": all(token in rule_normalized for token in ["running", "checkpoint verified", "operator gate reached", "closed verified no safe work"]),
            "defines_heartbeat_guard": "heartbeat" in rule_normalized and any(token in rule_normalized for token in ["nicht loeschen", "nicht geloescht", "duerfen nicht geloescht", "nicht beenden"]),
            "defines_entrypoint_contract": "agenten entry point vertrag" in rule_normalized or "agenten entry-point vertrag" in rule_normalized,
            "defines_minimum_completion_check": "minimaler abschlusscheck" in rule_normalized,
            "defines_machine_readable_report": "maschinenlesbarer abschlussreport" in rule_normalized and "long run completion report schema" in rule_normalized,
        }
        rule_missing = [name for name, ok in rule_required.items() if not ok]
        self.contract_quality_items.append({
            "item_id": f"long-run-rule-{stable_id(LONG_RUN_RULE, ','.join(rule_missing) or 'pass')}",
            "severity": "fail" if rule_missing else "info",
            "artifact_kind": "long_run_completion:canonical_rule",
            "status": "FAIL" if rule_missing else "PASS",
            "path": str(LONG_RUN_RULE),
            "summary": (
                "Long-run canonical rule is missing required completion-discipline sections: " + ", ".join(rule_missing)
                if rule_missing
                else "Long-run canonical rule defines completion states, heartbeat guard, entrypoints and minimum completion check."
            ),
            "required_fields": list(rule_required),
            "missing_fields": rule_missing,
            "recommended_action": (
                "complete the canonical long-run rule before allowing night-run/autoloop completion claims"
                if rule_missing
                else "ready for unattended-run governance"
            ),
        })

        passed = 0
        for entry_id, path, role in LONG_RUN_ENTRYPOINTS:
            exists = path.exists()
            text = read_text(path) if exists else ""
            normalized = normalize_text_for_gate(text)
            has_rule_name = "long run completion discipline" in normalized
            has_night_run_language = any(token in normalized for token in ["nightrun", "nachtrun", "autoloop", "abwesenheitslauf", "long run", "night run"])
            has_no_first_green = (
                "nicht nach dem ersten gruen" in normalized
                or "ersten gruenen teilcheck" in normalized
                or "gruener teilcheck" in normalized
                or "gruene teilchecks" in normalized
                or "green full check is only a checkpoint" in normalized
                or "full check is only a checkpoint" in normalized
                or "only a checkpoint" in normalized
                or "ist nur ein checkpoint" in normalized
            )
            has_completion_gate = any(token in normalized for token in ["operator gate", "operator-gate", "zeitfenster", "time window", "backlog", "dirt", "handoff"])
            checks = {
                "entrypoint_exists": exists,
                "references_long_run_rule": has_rule_name or str(LONG_RUN_RULE) in text,
                "mentions_night_run_or_autoloop": has_night_run_language,
                "blocks_first_green_completion": has_no_first_green,
                "mentions_completion_gate_or_backlog": has_completion_gate,
            }
            missing = [name for name, ok in checks.items() if not ok]
            if not missing:
                passed += 1
            self.contract_quality_items.append({
                "item_id": f"long-run-entrypoint-{entry_id}-{stable_id(path, ','.join(missing) or 'pass')}",
                "severity": "warn" if missing else "info",
                "artifact_kind": "long_run_completion:agent_entrypoint",
                "status": "WARN" if missing else "PASS",
                "path": str(path),
                "summary": (
                    f"Agent entry point '{entry_id}' is missing long-run completion wiring: " + ", ".join(missing)
                    if missing
                    else f"Agent entry point '{entry_id}' carries long-run completion wiring."
                ),
                "required_fields": list(checks),
                "missing_fields": missing,
                "recommended_action": (
                    "add Rule - Long Run Completion Discipline pointer and no-first-green completion language"
                    if missing
                    else "ready for long-run starts"
                ),
                "entrypoint_role": role,
            })
        self.coverage_sources.append({
            "source_class": "long_run_completion_entrypoints",
            "status": "scanned",
            "path": " | ".join(str(path) for _, path, _ in LONG_RUN_ENTRYPOINTS),
            "expected": "Every agent bootstrap/runbook entrypoint references Long Run Completion Discipline",
            "scanned_items": len(LONG_RUN_ENTRYPOINTS),
            "coverage_level": "entrypoint_contract_gate",
            "limitations": [f"{passed}/{len(LONG_RUN_ENTRYPOINTS)} entrypoints currently pass"],
        })

    def scan_long_run_completion_reports(self) -> None:
        """Validate machine-readable long-run completion/checkpoint reports."""
        required = QUALITY_OS_REQUIRED_FIELDS["long_run_completion_report"]
        reports = sorted(LONG_RUN_REPORTS_DIR.glob("*.json")) if LONG_RUN_REPORTS_DIR.exists() else []
        items: list[dict[str, Any]] = []
        for path in reports:
            payload = read_json(path, default=None)
            missing: list[str] = []
            errors: list[str] = []
            if not isinstance(payload, dict):
                errors.append("report is not a JSON object")
                payload = {}
            for field in required:
                if payload.get(field) in (None, "", [], {}):
                    missing.append(field)
            state = str(payload.get("completion_state", ""))
            allowed_states = {
                "running",
                "checkpoint_verified",
                "operator_gate_reached",
                "time_window_exhausted",
                "closed_verified_no_safe_work",
                "stopped_by_operator",
            }
            if state not in allowed_states:
                errors.append(f"invalid completion_state {state!r}")
            verifiers = payload.get("verifiers_run", [])
            if not isinstance(verifiers, list) or not verifiers:
                errors.append("verifiers_run must be a non-empty list")
            elif any(str(item.get("status", "")).upper() not in {"PASS", "WARN", "SKIPPED", "GATED"} for item in verifiers if isinstance(item, dict)):
                errors.append("verifiers_run contains unsupported status")
            if state == "closed_verified_no_safe_work":
                for object_field in ["core_request_checked", "backlog_checked", "dirt_checked", "memory_capture", "handoff_updated", "entrypoints_checked", "heartbeat_or_automation_state"]:
                    value = payload.get(object_field)
                    if not isinstance(value, dict) or str(value.get("status", "")).lower() not in {"checked", "pass", "updated", "closed", "clear"}:
                        errors.append(f"closed run requires {object_field}.status checked/pass/updated/closed/clear")
            if state == "checkpoint_verified":
                heartbeat_state = payload.get("heartbeat_or_automation_state", {})
                if isinstance(heartbeat_state, dict) and str(heartbeat_state.get("status", "")).lower() in {"deleted", "paused", "stopped"}:
                    errors.append("checkpoint report must not delete/pause/stop heartbeat as completion proof")
            status = "FAIL" if missing or errors else "PASS"
            item = {
                "report_id": payload.get("report_id", path.stem),
                "path": str(path),
                "completion_state": state or "missing",
                "status": status,
                "missing_fields": missing,
                "errors": errors,
                "next_safe_step": payload.get("next_safe_step", ""),
            }
            items.append(item)
            self.contract_quality_items.append({
                "item_id": f"long-run-report-{stable_id(path, ','.join(missing + errors) or 'pass')}",
                "severity": "fail" if status == "FAIL" else "info",
                "artifact_kind": "long_run_completion:completion_report",
                "status": status,
                "path": str(path),
                "summary": (
                    f"Long-run completion report invalid: {', '.join(missing + errors)}"
                    if status == "FAIL"
                    else f"Long-run completion report valid with state {state}."
                ),
                "required_fields": required,
                "missing_fields": missing,
                "recommended_action": (
                    "complete the report before claiming long-run completion"
                    if status == "FAIL"
                    else "ready as machine-readable checkpoint/closure evidence"
                ),
            })
        audit_status = "PASS" if items and all(item["status"] == "PASS" for item in items) else ("WARN" if not items else "FAIL")
        payload = {
            "generated_at": self.observed_at,
            "status": audit_status,
            "reports_checked": len(items),
            "items": items,
            "schema": str(LONG_RUN_COMPLETION_SCHEMA_PATH),
            "reports_dir": str(LONG_RUN_REPORTS_DIR),
        }
        write_json(OUTPUT_DIR / "long_run_completion_audit.json", payload)
        write_markdown_table(
            OUTPUT_DIR / "long_run_completion_audit.md",
            "Long Run Completion Audit",
            ["Prueft, ob Nightrun-/Autoloop-Abschlussclaims als maschinenlesbare Reports belegt sind."],
            ["report_id", "completion_state", "status", "path", "missing_fields", "errors", "next_safe_step"],
            items,
        )
        self.coverage_sources.append({
            "source_class": "long_run_completion_reports",
            "status": "scanned" if items else "partial",
            "path": str(LONG_RUN_REPORTS_DIR),
            "expected": "Machine-readable long-run checkpoint/closure reports",
            "scanned_items": len(items),
            "coverage_level": "schema_and_completion_state_gate",
            "limitations": ["checkpoint reports do not claim whole-run closure"],
        })

    def validate_quality_os_artifact(self, path: Path, artifact_kind: dict[str, str], text: str) -> None:
        kind = artifact_kind["quality_kind"]
        required = QUALITY_OS_REQUIRED_FIELDS.get(kind, [])
        missing = [field for field in required if not has_quality_marker(text, field)]
        severity = "fail" if kind in {"build_contract", "archetype", "job_card", "execution_history"} else "warn"
        if missing:
            self.contract_quality_items.append({
                "item_id": f"{kind}-{stable_id(path, ','.join(missing))}",
                "severity": severity,
                "artifact_kind": kind,
                "status": "FAIL" if severity == "fail" else "WARN",
                "path": str(path),
                "summary": f"Missing required fields: {', '.join(missing)}",
                "required_fields": required,
                "missing_fields": missing,
                "recommended_action": "complete required fields before using this artifact as a build contract",
            })
        else:
            self.contract_quality_items.append({
                "item_id": f"{kind}-{stable_id(path, 'pass')}",
                "severity": "info",
                "artifact_kind": kind,
                "status": "PASS",
                "path": str(path),
                "summary": "Required fields present.",
                "required_fields": required,
                "missing_fields": [],
                "recommended_action": "ready for local use",
            })
        if "n8n" in text.lower():
            n8n_ok = (
                "nicht als runtime" in normalize_text_for_gate(text)
                or "nicht abhaengigkeit" in normalize_text_for_gate(text)
                or "nicht als fuehrende runtime" in normalize_text_for_gate(text)
                or "nicht als zentrale agenten runtime" in normalize_text_for_gate(text)
                or "nicht als runtime abhaengigkeit" in normalize_text_for_gate(text)
                or "keine n8n runtime" in normalize_text_for_gate(text)
                or "nicht n8n einbetten" in normalize_text_for_gate(text)
                or "nicht abhaengigkeit" in normalize_text_for_gate(text)
            )
            if not n8n_ok:
                self.contract_quality_items.append({
                    "item_id": f"n8n-boundary-{stable_id(path)}",
                    "severity": "fail",
                    "artifact_kind": "n8n_boundary",
                    "status": "FAIL",
                    "path": str(path),
                    "summary": "n8n is mentioned without an explicit local template-only / no-runtime boundary.",
                    "required_fields": ["n8n only as archetype/template, not runtime dependency"],
                    "missing_fields": ["n8n runtime boundary"],
                    "recommended_action": "state that n8n is reference archetype only and not a runtime dependency",
                })

    def validate_complete_context_note(self, path: Path, fm: dict[str, Any], body: str, text: str) -> None:
        """Warn when a durable canonical anchor is not self-contained enough for future agents."""
        try:
            rel_path = path.relative_to(VAULT).as_posix()
        except ValueError:
            return
        if path.suffix != ".md":
            return
        if rel_path.startswith("Canonical/Systems/System - "):
            anchor_kind = "canonical_system"
        elif rel_path.startswith("Canonical/Rules/Rule - "):
            anchor_kind = "canonical_rule"
        else:
            return

        normalized = normalize_text_for_gate(text)
        aliases = as_list(fm.get("aliases"))
        has_local_path = "`/" in body or "http://127.0.0.1" in body or "http://localhost" in body
        has_wikilink = "[[" in body
        checks = {
            "frontmatter.status": bool(fm.get("status")),
            "purpose_or_why": any(token in normalized for token in ["kurzbild", "warum", "wofuer", "zweck", "da ist"]),
            "aliases_or_synonyms": bool(aliases) or "synonyme" in normalized or "suchbegriffe" in normalized,
            "limits_or_gates": any(token in normalized for token in ["grenzen", "operator go", "nicht darf", "gate", "stop"]),
            "paths_or_links": has_local_path or has_wikilink,
            "evidence_or_verifier": any(token in normalized for token in ["evidence", "verifier", "pruef", "check", "befehl"]),
            "next_step_or_status": any(token in normalized for token in ["naechster schritt", "abschluss", "status", "morgen", "route"]),
        }
        missing = [name for name, ok in checks.items() if not ok]
        self.contract_quality_items.append({
            "item_id": f"complete-context-{stable_id(path, ','.join(missing) or 'pass')}",
            "severity": "warn" if missing else "info",
            "artifact_kind": f"complete_context_before_archival:{anchor_kind}",
            "status": "WARN" if missing else "PASS",
            "path": str(path),
            "summary": (
                "Canonical anchor is missing complete-context fields: " + ", ".join(missing)
                if missing
                else "Canonical anchor has complete-context fields for future sessions."
            ),
            "required_fields": list(checks),
            "missing_fields": missing,
            "recommended_action": (
                "add purpose, aliases/synonyms, boundaries, paths/evidence and next step before claiming durable archival"
                if missing
                else "ready for durable reference"
            ),
        })

    def add_quality_os_static_relationships(self) -> None:
        build_contract = node_id("build-contract", "Build Contract Template")
        archetype_library = node_id("library", "Archetype Library V1")
        workflow = node_id("workflow", "n8n-inspired Workflow Run")
        job_card = node_id("job-card", "Job Card Template")
        approval = node_id("approval", "Human Approval Node")
        output = node_id("output", "Quality Operating System Outputs")
        verifier = node_id("verifier", "contract_quality_gate")
        quality_gate = node_id("quality-gate", "PIG Roadmap / Contract Quality Gate")
        execution_history = node_id("execution-history", "Workflow Execution History Minimum")
        operator_action = node_id("operator-action", "Quality OS Operator Actions")
        run_control = node_id("run-control", "Quality OS Run Controls")
        fresh_handoff = node_id("fresh-session-handoff", "Quality OS Fresh Session Handoff")
        operator_surface = node_id("operator-surface", "Quality OS Operator Surface")
        evidence = node_id("evidence", "Quality OS Evidence")
        improvement = node_id("improvement", "Quality Operating System Improvement")
        system = node_id("system", "Project Intelligence Graph")
        for node, kind, label, source in [
            (build_contract, "BuildContract", "Build Contract Template", QUALITY_OS_DOCS / "BUILD_CONTRACT_TEMPLATE.md"),
            (archetype_library, "ArchetypeLibrary", "Archetype Library V1", QUALITY_OS_VAULT / "Archetype Library Index.md"),
            (workflow, "Workflow", "n8n-inspired Workflow Run", QUALITY_OS_VAULT / "Archetype Library/n8n-inspired Workflow Run.md"),
            (job_card, "JobCard", "Job Card Template", QUALITY_OS_DOCS / "JOB_CARD_TEMPLATE.md"),
            (approval, "ApprovalNode", "Human Approval Node", QUALITY_OS_DOCS / "BUILD_CONTRACT_TEMPLATE.md"),
            (output, "Output", "Quality Operating System Outputs", QUALITY_OS_DOCS / "OPERATOR_SURFACE_CONTRACT.md"),
            (verifier, "Verifier", "contract_quality_gate", Path(__file__)),
            (quality_gate, "QualityGate", "PIG Roadmap / Contract Quality Gate", Path(__file__)),
            (execution_history, "ExecutionHistory", "Workflow Execution History Minimum", QUALITY_OS_DOCS / "EXECUTION_HISTORY_FORMAT.md"),
            (operator_action, "OperatorAction", "Quality OS Operator Actions", QUALITY_OS_DOCS / "OPERATOR_ACTIONS_FORMAT.md"),
            (run_control, "RunControl", "Quality OS Run Controls", QUALITY_OS_DOCS / "OPERATOR_ACTIONS_FORMAT.md"),
            (fresh_handoff, "FreshSessionHandoff", "Quality OS Fresh Session Handoff", QUALITY_OS_DOCS / "FRESH_SESSION_HANDOFF_FORMAT.md"),
            (operator_surface, "OperatorSurface", "Quality OS Operator Surface", QUALITY_OS_DOCS / "OPERATOR_SURFACE_CONTRACT.md"),
            (evidence, "Evidence", "Quality OS Evidence", OUTPUT_DIR / "contract_quality_gate.json"),
            (improvement, "Improvement", "Quality Operating System Improvement", QUALITY_OS_ROADMAP),
        ]:
            self.add_node(node, kind, label, source_path=str(source))
        relationships = [
            (build_contract, "uses", archetype_library, QUALITY_OS_DOCS / "BUILD_CONTRACT_TEMPLATE.md", "BuildContract -> uses -> Archetype"),
            (build_contract, "defines", workflow, QUALITY_OS_DOCS / "BUILD_CONTRACT_TEMPLATE.md", "BuildContract -> defines -> Workflow"),
            (workflow, "contains", job_card, QUALITY_OS_DOCS / "JOB_CARD_TEMPLATE.md", "Workflow -> contains -> JobCard"),
            (job_card, "requires", approval, QUALITY_OS_DOCS / "JOB_CARD_TEMPLATE.md", "JobCard -> requires -> ApprovalNode"),
            (job_card, "produces", output, QUALITY_OS_DOCS / "JOB_CARD_TEMPLATE.md", "JobCard -> produces -> Output"),
            (verifier, "validates", output, Path(__file__), "Verifier -> validates -> Output"),
            (quality_gate, "checks", build_contract, Path(__file__), "QualityGate -> checks -> BuildContract"),
            (workflow, "records", execution_history, QUALITY_OS_DOCS / "EXECUTION_HISTORY_FORMAT.md", "WorkflowRun -> records -> ExecutionHistory"),
            (operator_surface, "contains", operator_action, QUALITY_OS_DOCS / "OPERATOR_ACTIONS_FORMAT.md", "OperatorSurface -> contains -> OperatorAction"),
            (operator_action, "requires", approval, QUALITY_OS_DOCS / "OPERATOR_ACTIONS_FORMAT.md", "OperatorAction -> requires -> ApprovalNode"),
            (execution_history, "contains", run_control, QUALITY_OS_DOCS / "OPERATOR_ACTIONS_FORMAT.md", "WorkflowRun -> contains -> RunControl"),
            (fresh_handoff, "references", execution_history, QUALITY_OS_DOCS / "FRESH_SESSION_HANDOFF_FORMAT.md", "FreshSessionHandoff -> references -> ExecutionHistory"),
            (execution_history, "references", evidence, QUALITY_OS_DOCS / "EXECUTION_HISTORY_FORMAT.md", "ExecutionHistory -> references -> Evidence"),
            (improvement, "affects", system, QUALITY_OS_ROADMAP, "Improvement -> affects -> Project/System/Agent"),
        ]
        for subject, predicate, obj, source_path, span in relationships:
            self.add_rel(
                subject,
                predicate,
                obj,
                source_path,
                span,
                confidence=0.95,
                extraction_method="quality_gate_scan",
                status="verified",
            )

    def add_static_focus(self) -> None:
        pig_node = node_id("system", "Project Intelligence Graph")
        self.add_node(pig_node, "System", "Project Intelligence Graph", status="v2-control-layer")
        output_node = node_id("file", "outputs/project_intelligence_graph/relationships.jsonl")
        self.add_node(output_node, "File", "relationships.jsonl", source_path=str(OUTPUT_DIR / "relationships.jsonl"))
        self.add_rel(
            pig_node,
            "exposes_surface",
            output_node,
            SCHEMA_PATH,
            "phase0.outputs",
            confidence=1.0,
            extraction_method="static_seed",
            status="verified",
        )
        for label in ["Project - LIONCOM Dashboard", "Project - Quellwert"]:
            target = self.resolve_note_target(label)
            if target:
                self.add_rel(
                    pig_node,
                    "indexes",
                    target,
                    SCHEMA_PATH,
                    f"phase0.focus:{label}",
                    confidence=1.0,
                    extraction_method="static_seed",
                    status="verified",
                )
        operator_go_script = LIONCOM_APP / "scripts/run_operator_go_due.mjs"
        if operator_go_script.exists():
            script_node = node_id("file", str(operator_go_script))
            self.add_node(script_node, "File", "run_operator_go_due.mjs", source_path=str(operator_go_script), risk_class="R4")
            self.add_rel(
                pig_node,
                "indexes",
                script_node,
                operator_go_script,
                "operator_go.publisher_script",
                confidence=0.95,
                extraction_method="static_seed",
                status="verified",
            )
            gate_node = node_id("gate", "operator-go-required")
            self.add_node(gate_node, "Gate", "operator-go-required")
            self.add_rel(
                script_node,
                "requires_operator_gate",
                gate_node,
                operator_go_script,
                "operator_go.live_publisher",
                confidence=0.95,
                extraction_method="static_seed",
                status="verified",
            )

    def derive_supersession(self) -> None:
        reports_by_base: dict[str, list[tuple[str, dict[str, Any]]]] = {}
        for rel in self.relationships.values():
            if rel["predicate"] != "asserts_status":
                continue
            subject = rel["subject"]
            if subject.startswith("note:") or subject.startswith("artifact:"):
                base = re.sub(r"20\d{6,}|2026-\d{2}-\d{2}|-\d{8,}", "", subject)
                reports_by_base.setdefault(base, []).append((rel["valid_from"], rel))
        for rows in reports_by_base.values():
            if len(rows) < 2:
                continue
            rows.sort(key=lambda item: item[0])
            for older, newer in zip(rows, rows[1:]):
                old_rel = older[1]
                old_rel["valid_to"] = newer[0]
                old_rel["status"] = "superseded"

    def analyze_drift(self) -> None:
        unresolved_focus = []
        focus_node_ids = self.focus_node_ids()
        for rel in self.relationships.values():
            if rel["predicate"] == "mentions_unknown_target" and rel["subject"] in focus_node_ids:
                unresolved_focus.append(rel)
        if unresolved_focus:
            self.findings.append({
                "severity": "warning",
                "type": "unresolved_focus_wikilink",
                "count": len(unresolved_focus),
                "detail": "Focus notes contain wikilinks without a resolved local note target.",
            })
        for label in ["Project - LIONCOM Dashboard", "Project - Quellwert"]:
            nid = self.resolve_note_target(label)
            if not nid:
                self.findings.append({"severity": "error", "type": "missing_focus_note", "detail": label})
                continue
            predicates = {rel["predicate"] for rel in self.relationships.values() if rel["subject"] == nid}
            for needed in ["asserts_status", "has_person", "has_feature", "has_system"]:
                if needed not in predicates:
                    self.findings.append({"severity": "error", "type": "missing_project_relationship", "detail": f"{label} lacks {needed}"})
        pig_rels = [rel for rel in self.relationships.values() if rel["subject"] == node_id("system", "Project Intelligence Graph")]
        if not pig_rels:
            self.findings.append({"severity": "error", "type": "missing_pig_static_seed", "detail": "Project Intelligence Graph seed relationships missing"})
        for risk in self.automation_risks:
            if risk["status"] == "ACTIVE" and risk["risk_class"] in {"R4", "R5"}:
                self.findings.append({
                    "severity": "warning",
                    "type": "active_high_risk_automation",
                    "detail": f"{risk['name']} is ACTIVE with {risk['risk_class']} ({risk['mutating_capability']})",
                })
        if any(risk["automation_id"] == "operator-go-midday-publisher" and risk["status"] == "ACTIVE" for risk in self.automation_risks):
            self.findings.append({
                "severity": "warning",
                "type": "operator_go_publisher_active",
                "detail": "operator-go-midday-publisher can execute approved due publish/deploy work and needs explicit high-risk visibility.",
            })

    def build_policy_and_decisions(self) -> None:
        guardrail_scan = AGENT_OS_WORKSPACE / "outputs/agent_os_readiness/GUARDRAIL_SCAN.json"
        memory_inbox = AGENT_OS_WORKSPACE / "outputs/agent_os_readiness/MEMORY_INBOX_CANDIDATES.json"
        guardrail_matrix = AGENT_OS_WORKSPACE / "outputs/agent_os_readiness/GUARDRAIL_POLICY_GATE_MATRIX.json"
        memory_workbench = AGENT_OS_WORKSPACE / "outputs/agent_os_readiness/MEMORY_PROMOTION_WORKBENCH.json"
        guardrail_count = count_guardrail_findings(guardrail_scan)
        memory_count = count_memory_candidates(memory_inbox)
        for risk in sorted(self.automation_risks, key=lambda item: (risk_sort_key(item["risk_class"]), item["name"])):
            if risk["status"] != "ACTIVE":
                continue
            if risk["risk_class"] in {"R4", "R5"}:
                self.policy_items.append({
                    "policy_id": "active_high_risk_automation_requires_review",
                    "severity": "high",
                    "gate_required": True,
                    "subject": risk["name"],
                    "risk_class": risk["risk_class"],
                    "reason": f"Active automation has mutating/external tokens: {', '.join(risk['risk_tokens']) or 'none'}",
                    "required_evidence": ["dry_run_or_health_check", "operator_go_lineage_if_live_mutation", "post_run_log"],
                })
                self.decision_items.append({
                    "item_id": f"review-{slug(risk['automation_id'])}",
                    "priority": "P0" if risk["automation_id"] == "operator-go-midday-publisher" else "P1",
                    "lane": "automation_risk",
                    "status": "needs_review",
                    "recommended_default": "keep_active_with_visibility" if risk["automation_id"] == "operator-go-midday-publisher" else "review_or_pause_if_no_current_need",
                    "operator_action": "confirm_allowed_scope_or_pause",
                    "summary": f"{risk['name']} is {risk['status']} and classified {risk['risk_class']} ({risk['mutating_capability']}).",
                    "consequence_if_ignored": "Automation can continue running without a concise operator-facing risk card.",
                    "source": risk["source_path"],
                })
        if guardrail_count and not count_guardrail_policy_gates(guardrail_matrix):
            self.decision_items.append({
                "item_id": "review-agent-os-guardrail-gates",
                "priority": "P1",
                "lane": "policy_governance",
                "status": "candidate_review",
                "recommended_default": "keep_as_gates_and_convert_p0_rules_to_policy_engine",
                "operator_action": "review_or_accept_policy_backlog",
                "summary": f"{guardrail_count} Agent-OS guardrail findings exist as report-level gates.",
                "consequence_if_ignored": "Important safety rules remain documented but not centrally enforced.",
                "source": str(guardrail_scan),
            })
        if memory_count and not count_memory_promotion_batches(memory_workbench):
            self.decision_items.append({
                "item_id": "review-memory-promotion-debt",
                "priority": "P1",
                "lane": "memory_governance",
                "status": "candidate_review",
                "recommended_default": "build_memory_promotion_workbench_before_manual_bulk_review",
                "operator_action": "do_not_review_raw_queue_manually",
                "summary": f"{memory_count} Memory Inbox candidates are waiting for promote/reject/merge triage.",
                "consequence_if_ignored": "Memory candidates can become a second unmaintained review queue.",
                "source": str(memory_inbox),
            })
        coverage_gaps = [item for item in self.coverage_sources if item.get("status") in {"not_implemented", "missing", "partial"}]
        if coverage_gaps:
            self.decision_items.append({
                "item_id": "close-pig-coverage-gaps",
                "priority": "P1",
                "lane": "project_intelligence_graph",
                "status": "implementation_backlog",
                "recommended_default": "implement_repo_ci_runtime_scanners_next",
                "operator_action": "no_operator_action_needed_for_local_build",
                "summary": f"{len(coverage_gaps)} coverage areas are missing or partial.",
                "consequence_if_ignored": "PIG can say no findings while meaningful source classes remain unassessed.",
                "source": str(OUTPUT_DIR / "coverage_manifest.json"),
            })

    def focus_node_ids(self) -> set[str]:
        ids = {node_id("system", "Project Intelligence Graph")}
        for label in FOCUS_LABELS:
            resolved = self.resolve_note_target(label)
            if resolved:
                ids.add(resolved)
        for node, payload in self.nodes.items():
            label = payload.get("label", "")
            if "Room16" in label or "Quellwert" in label or "LIONCOM" in label:
                ids.add(node)
        return ids

    def write_outputs(self) -> None:
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        write_jsonl(OUTPUT_DIR / "nodes.jsonl", sorted(self.nodes.values(), key=lambda n: n["id"]))
        write_jsonl(OUTPUT_DIR / "relationships.jsonl", sorted(self.relationships.values(), key=lambda r: r["id"]))
        self.write_control_outputs()
        self.write_summary()
        self.write_drift_report()
        self.write_subgraph_view()

    def write_control_outputs(self) -> None:
        self.add_static_coverage_gaps()
        self.build_policy_and_decisions()
        write_json(OUTPUT_DIR / "automation_risk_registry.json", {
            "generated_at": self.observed_at,
            "status": "WARN" if any(item["status"] == "ACTIVE" and item["risk_class"] in {"R4", "R5"} for item in self.automation_risks) else "PASS",
            "items": sorted(self.automation_risks, key=lambda item: (risk_sort_key(item["risk_class"]), item["name"])),
        })
        write_markdown_table(
            OUTPUT_DIR / "automation_risk_registry.md",
            "Automation Risk Registry",
            [
                "Lokale Risikokarte aller Codex-Automationen.",
                "R4/R5 bedeutet nicht automatisch falsch, aber es braucht explizite Operator-Sichtbarkeit.",
            ],
            ["name", "status", "kind", "risk_class", "mutating_capability", "operator_gate_required", "rrule", "risk_tokens", "guardrail_tokens"],
            sorted(self.automation_risks, key=lambda item: (risk_sort_key(item["risk_class"]), item["name"])),
        )
        coverage_status = "WARN" if any(item["status"] in {"not_implemented", "missing"} for item in self.coverage_sources) else "PASS"
        write_json(OUTPUT_DIR / "coverage_manifest.json", {
            "generated_at": self.observed_at,
            "status": coverage_status,
            "sources": self.coverage_sources,
        })
        write_markdown_table(
            OUTPUT_DIR / "coverage_manifest.md",
            "Project Intelligence Graph Coverage Manifest",
            ["Coverage zeigt, was geprueft wurde und was nur noch nicht Teil der Scan-Regeln ist."],
            ["source_class", "status", "scanned_items", "coverage_level", "path", "limitations"],
            self.coverage_sources,
        )
        policy_status = "WARN" if self.policy_items else "PASS"
        write_json(OUTPUT_DIR / "policy_gate_report.json", {
            "generated_at": self.observed_at,
            "status": policy_status,
            "items": self.policy_items,
        })
        write_markdown_table(
            OUTPUT_DIR / "policy_gate_report.md",
            "Policy & Gate Report",
            ["Regeln, die als Code-/Automation-Gate sichtbar sein muessen."],
            ["policy_id", "severity", "gate_required", "subject", "risk_class", "reason", "required_evidence"],
            self.policy_items,
        )
        self.decision_items = apply_decision_state(self.decision_items)
        open_decisions = [item for item in self.decision_items if item.get("operator_state", "open") not in {"accepted", "closed"}]
        decision_status = "ACTION_REQUIRED" if any(item["priority"] == "P0" for item in open_decisions) else ("REVIEW" if open_decisions else "CLEAR")
        write_json(OUTPUT_DIR / "operator_decision_inbox.json", {
            "generated_at": self.observed_at,
            "status": decision_status,
            "unresolved_count": len(open_decisions),
            "items": self.decision_items,
        })
        write_markdown_table(
            OUTPUT_DIR / "operator_decision_inbox.md",
            "Operator Decision Inbox",
            ["Entscheidungsansicht: nicht alle Graph-Fakten, sondern was jetzt reviewt, bestaetigt oder gebaut werden sollte."],
            ["item_id", "priority", "lane", "operator_state", "status", "recommended_default", "operator_action", "summary", "consequence_if_ignored"],
            self.decision_items,
        )
        contract_errors = [item for item in self.contract_quality_items if item.get("status") == "FAIL"]
        contract_warnings = [item for item in self.contract_quality_items if item.get("status") == "WARN"]
        contract_status = "FAIL" if contract_errors else ("WARN" if contract_warnings else "PASS")
        write_json(OUTPUT_DIR / "contract_quality_gate.json", {
            "generated_at": self.observed_at,
            "status": contract_status,
            "fail_count": len(contract_errors),
            "warn_count": len(contract_warnings),
            "items": self.contract_quality_items,
        })
        write_markdown_table(
            OUTPUT_DIR / "contract_quality_gate.md",
            "PIG Roadmap / Contract Quality Gate",
            [
                "Prueft Quality-Operating-System Roadmaps, Build Contracts, Archetypes, Job Cards und Execution History.",
                "WARN ist fuer operatorische Luecken erlaubt; FAIL markiert kaputte Artefakte oder unlesbare Struktur.",
            ],
            ["artifact_kind", "status", "severity", "path", "summary", "missing_fields", "recommended_action"],
            self.contract_quality_items,
        )

    def add_static_coverage_gaps(self) -> None:
        return

    def write_summary(self) -> None:
        rel_status_counts: dict[str, int] = {}
        node_type_counts: dict[str, int] = {}
        for node in self.nodes.values():
            node_type_counts[node["type"]] = node_type_counts.get(node["type"], 0) + 1
        for rel in self.relationships.values():
            rel_status_counts[rel["status"]] = rel_status_counts.get(rel["status"], 0) + 1
        errors = [finding for finding in self.findings if finding["severity"] == "error"]
        warnings = [finding for finding in self.findings if finding["severity"] == "warning"]
        coverage = read_json(OUTPUT_DIR / "coverage_manifest.json", default={"status": "UNKNOWN"})
        risk_registry = read_json(OUTPUT_DIR / "automation_risk_registry.json", default={"status": "UNKNOWN", "items": []})
        policy_report = read_json(OUTPUT_DIR / "policy_gate_report.json", default={"status": "UNKNOWN"})
        summary = {
            "generated_at": self.observed_at,
            "implementation_status": "PASS" if not errors else "FAIL",
            "coverage_status": coverage.get("status", "UNKNOWN"),
            "operator_risk_status": risk_registry.get("status", "UNKNOWN"),
            "policy_gate_status": policy_report.get("status", "UNKNOWN"),
            "node_count": len(self.nodes),
            "relationship_count": len(self.relationships),
            "node_type_counts": node_type_counts,
            "relationship_status_counts": rel_status_counts,
            "finding_counts": count_by(self.findings, "severity"),
            "warning_count": len(warnings),
            "automation_risk_counts": count_by(risk_registry.get("items", []), "risk_class"),
            "outputs": {
                "nodes": str(OUTPUT_DIR / "nodes.jsonl"),
                "relationships": str(OUTPUT_DIR / "relationships.jsonl"),
                "drift_report": str(OUTPUT_DIR / "drift_report.md"),
                "subgraph_view": str(OUTPUT_DIR / "subgraph-lioncom-room16-quellwert.html"),
                "automation_risk_registry": str(OUTPUT_DIR / "automation_risk_registry.json"),
                "operator_decision_inbox": str(OUTPUT_DIR / "operator_decision_inbox.json"),
                "coverage_manifest": str(OUTPUT_DIR / "coverage_manifest.json"),
                "policy_gate_report": str(OUTPUT_DIR / "policy_gate_report.json"),
                "contract_quality_gate": str(OUTPUT_DIR / "contract_quality_gate.json"),
            },
        }
        (OUTPUT_DIR / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    def write_drift_report(self) -> None:
        errors = [finding for finding in self.findings if finding["severity"] == "error"]
        warnings = [finding for finding in self.findings if finding["severity"] == "warning"]
        summary = read_json(OUTPUT_DIR / "summary.json", default={})
        lines = [
            "# Project Intelligence Graph Drift Report",
            "",
            f"- Generated: `{self.observed_at}`",
            f"- Implementation status: `{'PASS' if not errors else 'FAIL'}`",
            f"- Coverage status: `{summary.get('coverage_status', 'UNKNOWN')}`",
            f"- Operator risk status: `{summary.get('operator_risk_status', 'UNKNOWN')}`",
            f"- Policy gate status: `{summary.get('policy_gate_status', 'UNKNOWN')}`",
            f"- Nodes: `{len(self.nodes)}`",
            f"- Relationships: `{len(self.relationships)}`",
            f"- Blocking implementation findings: `{len(errors)}`",
            f"- Source observations / warnings: `{len(warnings)}`",
            "",
            "## Scope",
            "",
            "Phase 0 reads Obsidian, Handoff/Evidence artifacts and Codex automation metadata. It does not rewrite the Vault.",
            "",
            "## Findings",
            "",
        ]
        if not self.findings:
            lines.append("- No drift findings in the current rule set.")
        else:
            for finding in self.findings:
                lines.append(f"- `{finding['severity']}` `{finding['type']}`: {finding.get('detail', '')} {finding.get('count', '')}".rstrip())
        lines.extend([
            "",
            "## Implemented Phase-0 Guarantees",
            "",
            "- Relationship schema exists and is valid JSON.",
            "- Every relationship carries provenance: `source_path`, `source_span`, `source_sha256`.",
            "- Every relationship carries temporal fields: `observed_at`, `valid_from`, `valid_to`.",
            "- Drift report is generated from scanner findings.",
            "- LIONCOM / Room16 / Quellwert subgraph view is generated as a local HTML artifact.",
            "- Automation Risk Registry, Coverage Manifest, Policy Gate Report and Operator Decision Inbox are generated.",
        ])
        (OUTPUT_DIR / "drift_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    def write_subgraph_view(self) -> None:
        focus = self.focus_node_ids()
        expanded = set(focus)
        for rel in self.relationships.values():
            if rel["subject"] in focus or rel["object"] in focus:
                expanded.add(rel["subject"])
                expanded.add(rel["object"])
        sub_nodes = [self.nodes[node] for node in sorted(expanded) if node in self.nodes]
        sub_rels = [
            rel
            for rel in sorted(self.relationships.values(), key=lambda r: r["id"])
            if rel["subject"] in expanded and rel["object"] in expanded
        ]
        data = {"nodes": sub_nodes, "relationships": sub_rels, "generated_at": self.observed_at}
        html_doc = render_subgraph_html(data)
        (OUTPUT_DIR / "subgraph-lioncom-room16-quellwert.html").write_text(html_doc, encoding="utf-8")


def first_present(payload: dict[str, Any], keys: list[str]) -> Any:
    for key in keys:
        value = payload.get(key)
        if value not in (None, "", []):
            return value
    return None


def flatten_values(value: Any) -> list[Any]:
    if value in (None, "", []):
        return []
    if isinstance(value, (str, int, float, bool)):
        return [value]
    if isinstance(value, list):
        flattened: list[Any] = []
        for item in value:
            flattened.extend(flatten_values(item))
        return flattened
    if isinstance(value, dict):
        flattened = []
        for key in ["id", "path", "name", "command", "file", "source_id"]:
            if key in value:
                flattened.extend(flatten_values(value[key]))
        return flattened
    return [str(value)]


def parse_toml_light(text: str) -> dict[str, str]:
    data: dict[str, str] = {}
    current_multiline_key: str | None = None
    current_multiline: list[str] = []
    for raw in text.splitlines():
        line = raw.strip()
        if current_multiline_key:
            current_multiline.append(raw)
            if line.endswith('"') and not line.endswith('\\"'):
                data[current_multiline_key] = "\n".join(current_multiline).strip().strip('"')
                current_multiline_key = None
                current_multiline = []
            continue
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key == "prompt" and raw.count('"') == 1:
            current_multiline_key = key
            current_multiline = [raw.split("=", 1)[1].strip()]
            continue
        if key in {"id", "name", "status", "kind", "destination", "executionEnvironment", "execution_environment", "rrule", "model", "reasoning_effort", "prompt", "target_thread_id"}:
            data[key] = value
    return data


def parse_toml_array(text: str, key: str) -> list[str]:
    match = re.search(rf"^{re.escape(key)}\s*=\s*\[(.*?)\]", text, flags=re.MULTILINE | re.DOTALL)
    if not match:
        return []
    return re.findall(r'"([^"]+)"', match.group(1))


def run_git(repo: Path, args: list[str]) -> str:
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=repo,
            check=False,
            text=True,
            capture_output=True,
            timeout=5,
        )
    except Exception:
        return ""
    if result.returncode != 0:
        return ""
    return result.stdout.strip()


def discover_repo_verifiers(repo: Path) -> list[str]:
    verifiers: set[str] = set()
    package_json = repo / "package.json"
    if package_json.exists():
        package = read_json(package_json, default={})
        scripts = package.get("scripts", {}) if isinstance(package, dict) else {}
        for name in scripts:
            if any(token in name.lower() for token in ["test", "verify", "lint", "build", "typecheck"]):
                verifiers.add(f"npm run {name}")
    for root_name in ["scripts/verify", "scripts"]:
        root = repo / root_name
        if not root.exists():
            continue
        for path in sorted(root.glob("*"))[:80]:
            if path.is_file() and any(token in path.name.lower() for token in ["verify", "test", "check", "lint"]):
                verifiers.add(path.relative_to(repo).as_posix())
    if (repo / "pyproject.toml").exists() or (repo / "pytest.ini").exists() or (repo / "tests").exists():
        verifiers.add("python -m pytest")
    return sorted(verifiers)


def classify_automation_risk(automation_id: str, data: dict[str, str], cwds: list[str]) -> dict[str, Any]:
    name = data.get("name") or automation_id
    status = data.get("status") or "unknown"
    kind = data.get("kind") or "automation"
    prompt = data.get("prompt") or ""
    rrule = data.get("rrule") or ""
    scan_text = " ".join([automation_id, name, kind, status, prompt, rrule, " ".join(cwds)]).lower()
    active_tokens, negated_tokens = classify_risk_tokens(scan_text)
    tokens = [REDACTED]
    guardrail_tokens = [REDACTED]
    mutating = bool(active_tokens & {match.group(1).lower().replace(" ", "_") for match in MUTATING_TOKEN_RE.finditer(scan_text)})
    external = bool(active_tokens & {match.group(1).lower().replace(" ", "_") for match in EXTERNAL_TOKEN_RE.finditer(scan_text)})
    publish_or_deploy = any(token in tokens for token in {"deploy", "publish", "operator-go", "production", "public", "cloudflare", "dns", "checkout", "payment", "money"})
    credential = any(token in tokens for token in {"credential", "secret", "token", "oauth", "api_key"})
    destructive = any(token in tokens for token in {"delete", "remove", "destructive"})
    if destructive or credential:
        risk_class = "R5"
        capability = "credential_or_destructive"
    elif publish_or_deploy:
        risk_class = "R4"
        capability = "publish_or_deploy"
    elif external and mutating:
        risk_class = "R3"
        capability = "external_mutation"
    elif mutating:
        risk_class = "R2"
        capability = "memory_or_repo_write"
    elif external:
        risk_class = "R2"
        capability = "external_read_or_monitor"
    else:
        risk_class = "R1"
        capability = "local_read_or_analysis"
    if status == "PAUSED" and risk_class in {"R4", "R5"}:
        risk_class = "R3"
        capability = f"paused_{capability}"
    if automation_id == "vega-upstream-base-audit":
        risk_class = "R3"
        capability = "external_governance_review"
    operator_gate_required = risk_class in {"R3", "R4", "R5"} or publish_or_deploy or credential or destructive
    return {
        "automation_id": automation_id,
        "name": name,
        "status": status,
        "kind": kind,
        "rrule": rrule,
        "cwds": cwds,
        "risk_class": risk_class,
        "mutating_capability": capability,
        "external_surface": external,
        "operator_gate_required": operator_gate_required,
        "risk_tokens": tokens,
        "guardrail_tokens": guardrail_tokens,
        "source_path": str(Path.home() / ".codex/automations" / automation_id / "automation.toml"),
        "prompt_excerpt": compact_search_text(prompt, 260),
        "recommended_control": recommended_control_for_risk(risk_class, status, automation_id),
    }


def classify_risk_tokens(scan_text: str) -> tuple[set[str], set[str]]:
    active: set[str] = set()
    negated: set[str] = set()
    for match in RISK_TOKEN_RE.finditer(scan_text):
        token = [REDACTED]
        prefix = scan_text[max(0, match.start() - 80) : match.start()]
        sentence_start = max(scan_text.rfind(".", 0, match.start()), scan_text.rfind("\n", 0, match.start()), scan_text.rfind(";", 0, match.start()))
        sentence_end_candidates = [pos for pos in [scan_text.find(".", match.end()), scan_text.find("\n", match.end()), scan_text.find(";", match.end())] if pos != -1]
        sentence_end = min(sentence_end_candidates) if sentence_end_candidates else min(len(scan_text), match.end() + 180)
        sentence = scan_text[sentence_start + 1 : sentence_end]
        guardrail_sentence = any(
            marker in sentence
            for marker in [
                "stop only for real operator",
                "blocked actions",
                "blocked action",
                "not allowed",
                "forbidden",
                "harte stopps",
                "verboten",
                "operator gate",
                "operator-gate",
                "without operator go",
                "ohne operator go",
            ]
        )
        if NEGATED_RISK_CONTEXT_RE.search(prefix) or guardrail_sentence:
            negated.add(token)
        else:
            active.add(token)
    return active, negated


def recommended_control_for_risk(risk_class: str, status: str, automation_id: str) -> str:
    if automation_id == "operator-go-midday-publisher":
        return "keep only with visible risk card, mandatory dry-run/health proof and explicit approval lineage"
    if status != "ACTIVE":
        return "keep paused unless operator reactivates with fresh scope"
    if risk_class in {"R4", "R5"}:
        return "review immediately; add kill-switch and preflight evidence"
    if risk_class == "R3":
        return "review before runtime expansion"
    return "monitor"


def risk_sort_key(risk_class: str) -> int:
    return {"R5": 0, "R4": 1, "R3": 2, "R2": 3, "R1": 4}.get(risk_class, 9)


QUALITY_OS_REQUIRED_FIELDS = {
    "roadmap": [
        "Haertungsanalyse",
        "Zielbild-/Archetypanalyse",
        "Archetyp",
        "Nicht-Ziele",
        "Verifier",
        "Cross-Project",
        "Operator-Gates",
    ],
    "build_contract": [
        "operator_goal",
        "target_picture",
        "archetype",
        "workflow_shape",
        "scope",
        "non_goals",
        "allowed_actions",
        "approval_nodes",
        "hard_gates",
        "outputs",
        "verifiers",
        "execution_history_required",
        "cross_project_effect",
        "memory_capture_required",
        "status",
    ],
    "archetype": [
        "Wann nutzen",
        "Zielbild",
        "Inputs",
        "Outputs",
        "Gates",
        "Verifier",
        "Stop-Regeln",
        "typische Fehler",
        "gute Referenzen",
        "Provider-/Agent-Neutralitaet",
    ],
    "job_card": [
        "Auftrag",
        "Zielbild",
        "Input",
        "erlaubte Aktion",
        "verbotene Aktion",
        "Output-Vertrag",
        "relevante Dateien/Artefakte",
        "Evidence",
        "Verifier",
        "Stop-Regel",
        "Retry-Regel",
        "Status",
        "naechster sicherer Schritt",
        "Uebergabe an Vega/PIG/Operator",
    ],
    "execution_history": [
        "run_id",
        "started_at",
        "contract",
        "workflow_steps",
        "current_step",
        "approval_nodes",
        "verifiers",
        "status",
        "failures",
        "evidence",
        "memory_updates",
        "completed_at",
    ],
    "operator_action": [
        "action_id",
        "action_type",
        "contract",
        "approval_node",
        "status",
        "allowed_when",
        "blocked_when",
        "evidence",
        "verifier",
        "audit_trail",
        "no_runtime_effect",
    ],
    "fresh_session_handoff": [
        "handoff_id",
        "generated_at",
        "latest_run",
        "reading_order",
        "open_gates",
        "active_contracts",
        "next_safe_step",
        "verifier_summary",
        "blocked_actions",
        "memory_status",
    ],
    "long_run_completion_report": [
        "schema_version",
        "report_id",
        "created_at",
        "run_scope",
        "completion_state",
        "core_request_checked",
        "backlog_checked",
        "dirt_checked",
        "verifiers_run",
        "memory_capture",
        "handoff_updated",
        "entrypoints_checked",
        "heartbeat_or_automation_state",
        "operator_gates",
        "next_safe_step",
    ],
}


def normalize_text_for_gate(value: str) -> str:
    value = value.lower()
    replacements = {
        "ä": "ae",
        "ö": "oe",
        "ü": "ue",
        "ß": "ss",
        "–": "-",
        "—": "-",
    }
    for old, new in replacements.items():
        value = value.replace(old, new)
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def has_quality_marker(text: str, marker: str) -> bool:
    normalized_text = normalize_text_for_gate(text)
    normalized_marker = normalize_text_for_gate(marker)
    if normalized_marker in normalized_text:
        return True
    aliases = {
        "haertungsanalyse": ["haertung", "haertung wiederverwendet"],
        "zielbild archetypanalyse": ["zielbild", "operator zielbild", "target picture"],
        "nicht ziele": ["non goals", "nichtziele"],
        "cross project": ["cross project wirkung", "cross project effect"],
        "operator gates": ["approval nodes", "operator gate"],
        "provider agent neutralitaet": ["provider agent neutral", "agent neutral", "providerneutral"],
        "uebergabe an vega pig operator": ["uebergabe", "handoff"],
        "naechster sicherer schritt": ["next safe action", "next safe step"],
    }
    return any(alias in normalized_text for alias in aliases.get(normalized_marker, []))


def classify_quality_os_artifact(path: Path, fm: dict[str, Any], text: str) -> dict[str, str] | None:
    stem = path.stem
    declared_type = str(fm.get("type") or "")
    lower_path = path.as_posix().lower()
    lower_stem = stem.lower()
    if declared_type == "archetype" or "/archetype library/" in lower_path:
        return {"quality_kind": "archetype", "node_kind": "archetype", "node_type": "Archetype", "label": stem}
    if "build_contract_template" in declared_type or "build_contract_template" in lower_path or "build contract" in lower_stem:
        return {"quality_kind": "build_contract", "node_kind": "build-contract", "node_type": "BuildContract", "label": stem}
    if "job_card_template" in declared_type or "job_card_template" in lower_path or "job card" in lower_stem:
        return {"quality_kind": "job_card", "node_kind": "job-card", "node_type": "JobCard", "label": stem}
    if "execution_history_template" in declared_type or "execution_history" in lower_path or "execution history" in lower_stem:
        return {"quality_kind": "execution_history", "node_kind": "execution-history", "node_type": "ExecutionHistory", "label": stem}
    if "operator_action" in declared_type or "operator action" in lower_stem or "operator_actions" in lower_path:
        return {"quality_kind": "operator_action", "node_kind": "operator-action", "node_type": "OperatorAction", "label": stem}
    if "fresh_session_handoff" in declared_type or "fresh session handoff" in lower_stem or "fresh_session_handoff" in lower_path:
        return {"quality_kind": "fresh_session_handoff", "node_kind": "fresh-session-handoff", "node_type": "FreshSessionHandoff", "label": stem}
    if "roadmap" in declared_type or "roadmap" in lower_stem:
        return {"quality_kind": "roadmap", "node_kind": "roadmap", "node_type": "Roadmap", "label": stem}
    if "reference_archetype" in declared_type or "n8n workflow archetype reference" in lower_path:
        return {"quality_kind": "reference", "node_kind": "archetype-reference", "node_type": "Archetype", "label": stem}
    if "operator_surface_contract" in declared_type:
        return {"quality_kind": "roadmap", "node_kind": "operator-surface", "node_type": "OperatorSurface", "label": stem}
    return None


def relative_quality_path(path: Path) -> str:
    for root in [WORKSPACE, VAULT]:
        try:
            return path.relative_to(root).as_posix()
        except ValueError:
            continue
    return str(path)


def relative_runtime_path(path: Path) -> str:
    runtime_root = Path.home() / "Library/Application Support/LIONCOM/runtime-workspace"
    for root in [runtime_root, LIONCOM_APP, WORKSPACE, VAULT]:
        try:
            return path.relative_to(root).as_posix()
        except ValueError:
            continue
    return str(path)


def mtime_iso(path: Path) -> str:
    try:
        return dt.datetime.fromtimestamp(path.stat().st_mtime, tz=dt.timezone.utc).replace(microsecond=0).isoformat()
    except Exception:
        return ""


def read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def apply_decision_state(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    state = read_json(OPERATOR_DECISION_STATE_PATH, default={})
    state_items = state.get("items", {}) if isinstance(state, dict) else {}
    merged_items = []
    for item in items:
        merged = dict(item)
        item_state = state_items.get(item.get("item_id"), {}) if isinstance(state_items, dict) else {}
        merged["operator_state"] = item_state.get("state", "open")
        if item_state.get("note"):
            merged["operator_note"] = item_state["note"]
        if item_state.get("updated_at"):
            merged["operator_updated_at"] = item_state["updated_at"]
        merged_items.append(merged)
    return merged_items


def markdown_value(value: Any) -> str:
    if isinstance(value, list):
        return ", ".join(str(item) for item in value) if value else "-"
    if isinstance(value, dict):
        return json.dumps(value, ensure_ascii=False)
    if value in (None, ""):
        return "-"
    return str(value).replace("\n", " ")


def write_markdown_table(path: Path, title: str, intro: list[str], columns: list[str], rows: list[dict[str, Any]]) -> None:
    lines = [f"# {title}", ""]
    for paragraph in intro:
        lines.extend([paragraph, ""])
    lines.append(f"Rows: `{len(rows)}`")
    lines.append("")
    if rows:
        lines.append("| " + " | ".join(columns) + " |")
        lines.append("| " + " | ".join("---" for _ in columns) + " |")
        for row in rows:
            lines.append("| " + " | ".join(markdown_value(row.get(column)).replace("|", "\\|") for column in columns) + " |")
    else:
        lines.append("- No rows.")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def count_guardrail_findings(path: Path) -> int:
    payload = read_json(path, default={})
    if isinstance(payload, dict):
        for key in ["findings", "items", "checks"]:
            if isinstance(payload.get(key), list):
                return len(payload[key])
        if isinstance(payload.get("summary"), dict) and isinstance(payload["summary"].get("findings"), int):
            return int(payload["summary"]["findings"])
    return 0


def count_memory_candidates(path: Path) -> int:
    payload = read_json(path, default={})
    if isinstance(payload, dict):
        for key in ["candidates", "items"]:
            if isinstance(payload.get(key), list):
                return len(payload[key])
        if isinstance(payload.get("summary"), dict) and isinstance(payload["summary"].get("candidates"), int):
            return int(payload["summary"]["candidates"])
    return 0


def count_memory_promotion_batches(path: Path) -> int:
    payload = read_json(path, default={})
    if isinstance(payload, dict) and isinstance(payload.get("batches"), list):
        return len(payload["batches"])
    return 0


def count_guardrail_policy_gates(path: Path) -> int:
    payload = read_json(path, default={})
    if isinstance(payload, dict) and isinstance(payload.get("gates"), list):
        return len(payload["gates"])
    return 0


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.write_text("".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in rows), encoding="utf-8")


def count_by(rows: list[dict[str, Any]], key: str) -> dict[str, int]:
    counts: dict[str, int] = {}
    for row in rows:
        value = str(row.get(key, "unknown"))
        counts[value] = counts.get(value, 0) + 1
    return counts


def render_subgraph_html(data: dict[str, Any]) -> str:
    payload = json.dumps(data, ensure_ascii=False).replace("<", "\\u003c")
    node_count = len(data["nodes"])
    rel_count = len(data["relationships"])
    rows = []
    for rel in data["relationships"][:260]:
        rows.append(
            "<tr>"
            f"<td>{html.escape(label_for(data, rel['subject']))}</td>"
            f"<td><code>{html.escape(rel['predicate'])}</code></td>"
            f"<td>{html.escape(label_for(data, rel['object']))}</td>"
            f"<td>{html.escape(rel['status'])}</td>"
            f"<td>{html.escape(Path(rel['source_path']).name)}<br><small>{html.escape(rel['source_span'])}</small></td>"
            "</tr>"
        )
    return f"""<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Project Intelligence Graph - LIONCOM / Room16 / Quellwert</title>
  <style>
    :root {{
      color-scheme: light;
      --ink: #182027;
      --muted: #62717d;
      --line: #d8e0e5;
      --panel: #f7f9fa;
      --accent: #0f766e;
      --accent-2: #8a4f16;
      --bg: #ffffff;
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      color: var(--ink);
      background: var(--bg);
    }}
    header {{
      padding: 28px clamp(18px, 4vw, 52px) 18px;
      border-bottom: 1px solid var(--line);
    }}
    h1 {{
      margin: 0 0 10px;
      font-size: clamp(1.45rem, 2.4vw, 2.35rem);
      font-weight: 720;
      letter-spacing: 0;
    }}
    .meta {{
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      color: var(--muted);
      font-size: 0.95rem;
    }}
    main {{
      display: grid;
      grid-template-columns: minmax(260px, 360px) minmax(0, 1fr);
      min-height: calc(100vh - 114px);
    }}
    aside {{
      border-right: 1px solid var(--line);
      background: var(--panel);
      padding: 18px;
      overflow: auto;
    }}
    .node {{
      border: 1px solid var(--line);
      background: white;
      border-radius: 8px;
      padding: 10px 12px;
      margin-bottom: 8px;
      cursor: pointer;
    }}
    .node strong {{
      display: block;
      font-size: 0.94rem;
      overflow-wrap: anywhere;
    }}
    .node span {{
      color: var(--muted);
      font-size: 0.82rem;
    }}
    section {{
      padding: 18px clamp(16px, 3vw, 34px);
      overflow: auto;
    }}
    .toolbar {{
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      align-items: center;
      margin-bottom: 14px;
    }}
    input {{
      width: min(460px, 100%);
      border: 1px solid var(--line);
      border-radius: 6px;
      padding: 10px 12px;
      font: inherit;
    }}
    table {{
      width: 100%;
      border-collapse: collapse;
      table-layout: fixed;
      border: 1px solid var(--line);
      background: white;
    }}
    th, td {{
      border-bottom: 1px solid var(--line);
      padding: 10px;
      text-align: left;
      vertical-align: top;
      overflow-wrap: anywhere;
      font-size: 0.9rem;
    }}
    th {{
      background: #eef3f4;
      color: #24323a;
      font-size: 0.78rem;
      text-transform: uppercase;
      letter-spacing: 0;
    }}
    code {{
      color: var(--accent);
      font-size: 0.84rem;
    }}
    small {{
      color: var(--muted);
    }}
    .pill {{
      display: inline-flex;
      border: 1px solid var(--line);
      background: white;
      border-radius: 999px;
      padding: 6px 10px;
      font-size: 0.86rem;
    }}
    @media (max-width: 860px) {{
      main {{ grid-template-columns: 1fr; }}
      aside {{ border-right: 0; border-bottom: 1px solid var(--line); max-height: 280px; }}
      th:nth-child(4), td:nth-child(4) {{ display: none; }}
    }}
  </style>
</head>
<body>
  <header>
    <h1>Project Intelligence Graph</h1>
    <div class="meta">
      <span class="pill">LIONCOM / Room16 / Quellwert</span>
      <span class="pill">{node_count} Nodes</span>
      <span class="pill">{rel_count} Relationships</span>
      <span class="pill">Generated {html.escape(data['generated_at'])}</span>
    </div>
  </header>
  <main>
    <aside id="nodes"></aside>
    <section>
      <div class="toolbar">
        <input id="filter" aria-label="Filter relationships" placeholder="Filter: Project, Gate, Evidence, Room16 ...">
        <span id="visibleCount" class="pill"></span>
      </div>
      <table>
        <thead>
          <tr><th>Subject</th><th>Predicate</th><th>Object</th><th>Status</th><th>Provenance</th></tr>
        </thead>
        <tbody id="relationships">
          {''.join(rows)}
        </tbody>
      </table>
    </section>
  </main>
  <script id="graph-data" type="application/json">{payload}</script>
  <script>
    const data = JSON.parse(document.getElementById('graph-data').textContent);
    const nodes = document.getElementById('nodes');
    const filter = document.getElementById('filter');
    const relBody = document.getElementById('relationships');
    const visibleCount = document.getElementById('visibleCount');
    const nodeById = new Map(data.nodes.map((node) => [node.id, node]));

    function label(id) {{
      return (nodeById.get(id) || {{ label: id }}).label;
    }}

    function renderNodes(term = '') {{
      nodes.innerHTML = '';
      data.nodes
        .filter((node) => (node.label + ' ' + node.type).toLowerCase().includes(term))
        .slice(0, 120)
        .forEach((node) => {{
          const item = document.createElement('button');
          item.className = 'node';
          item.type = 'button';
          item.innerHTML = `<strong>${{node.label}}</strong><span>${{node.type}}</span>`;
          item.addEventListener('click', () => {{
            filter.value = node.label;
            renderRelationships(node.label.toLowerCase());
          }});
          nodes.appendChild(item);
        }});
    }}

    function renderRelationships(term = '') {{
      const rows = data.relationships.filter((rel) => {{
        const haystack = [label(rel.subject), rel.predicate, label(rel.object), rel.status, rel.source_path, rel.source_span]
          .join(' ')
          .toLowerCase();
        return haystack.includes(term);
      }});
      visibleCount.textContent = `${{rows.length}} sichtbar`;
      relBody.innerHTML = rows.slice(0, 260).map((rel) => `
        <tr>
          <td>${{label(rel.subject)}}</td>
          <td><code>${{rel.predicate}}</code></td>
          <td>${{label(rel.object)}}</td>
          <td>${{rel.status}}</td>
          <td>${{rel.source_path.split('/').pop()}}<br><small>${{rel.source_span}}</small></td>
        </tr>
      `).join('');
    }}

    filter.addEventListener('input', () => {{
      const term = filter.value.trim().toLowerCase();
      renderNodes(term);
      renderRelationships(term);
    }});
    renderNodes();
    renderRelationships();
  </script>
</body>
</html>
"""


def label_for(data: dict[str, Any], node_id_value: str) -> str:
    for node in data["nodes"]:
        if node["id"] == node_id_value:
            return str(node["label"])
    return node_id_value


def validate_outputs() -> int:
    errors: list[str] = []
    for path in [
        SCHEMA_PATH,
        NODE_SCHEMA_PATH,
        PREDICATE_REGISTRY_PATH,
        POLICY_RULES_PATH,
        BUILD_CONTRACT_SCHEMA_PATH,
        JOB_CARD_SCHEMA_PATH,
        EXECUTION_HISTORY_SCHEMA_PATH,
        LONG_RUN_COMPLETION_SCHEMA_PATH,
        RULE_PROPAGATION_SCHEMA_PATH,
        RULE_PROPAGATION_REGISTRY_PATH,
        PROJECT_INVARIANT_SCHEMA_PATH,
        PROJECT_INVARIANT_REGISTRY_PATH,
        AGENT_ENTRYPOINT_SCHEMA_PATH,
        AGENT_ENTRYPOINT_REGISTRY_PATH,
        OPERATOR_INTENT_CONTRACT_SCHEMA_PATH,
        IMPACT_RADIUS_RULES_SCHEMA_PATH,
        IMPACT_RADIUS_RULES_PATH,
        GERMAN_OUTPUT_QUALITY_SCHEMA_PATH,
        GERMAN_OUTPUT_QUALITY_REGISTRY_PATH,
        OUTPUT_DIR / "nodes.jsonl",
        OUTPUT_DIR / "relationships.jsonl",
        OUTPUT_DIR / "drift_report.md",
        OUTPUT_DIR / "subgraph-lioncom-room16-quellwert.html",
        OUTPUT_DIR / "summary.json",
        OUTPUT_DIR / "automation_risk_registry.json",
        OUTPUT_DIR / "operator_decision_inbox.json",
        OUTPUT_DIR / "coverage_manifest.json",
        OUTPUT_DIR / "policy_gate_report.json",
        OUTPUT_DIR / "contract_quality_gate.json",
        OUTPUT_DIR / "long_run_completion_audit.json",
        OUTPUT_DIR / "vault_umlaut_hygiene.json",
        OUTPUT_DIR / "skill_policy_regression_guard_audit.json",
        OUTPUT_DIR / "rule_propagation_audit.json",
        OUTPUT_DIR / "project_invariant_audit.json",
        OUTPUT_DIR / "agent_entrypoint_audit.json",
        OUTPUT_DIR / "operator_intent_contract_audit.json",
    ]:
        if not path.exists() or path.stat().st_size == 0:
            errors.append(f"missing or empty: {path}")
    for json_path in [
        SCHEMA_PATH,
        NODE_SCHEMA_PATH,
        PREDICATE_REGISTRY_PATH,
        POLICY_RULES_PATH,
        BUILD_CONTRACT_SCHEMA_PATH,
        JOB_CARD_SCHEMA_PATH,
        EXECUTION_HISTORY_SCHEMA_PATH,
        LONG_RUN_COMPLETION_SCHEMA_PATH,
        RULE_PROPAGATION_SCHEMA_PATH,
        RULE_PROPAGATION_REGISTRY_PATH,
        PROJECT_INVARIANT_SCHEMA_PATH,
        PROJECT_INVARIANT_REGISTRY_PATH,
        AGENT_ENTRYPOINT_SCHEMA_PATH,
        AGENT_ENTRYPOINT_REGISTRY_PATH,
        OPERATOR_INTENT_CONTRACT_SCHEMA_PATH,
        IMPACT_RADIUS_RULES_SCHEMA_PATH,
        IMPACT_RADIUS_RULES_PATH,
        GERMAN_OUTPUT_QUALITY_SCHEMA_PATH,
        GERMAN_OUTPUT_QUALITY_REGISTRY_PATH,
    ]:
        try:
            json.loads(json_path.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001 - CLI validator should report every parse error.
            errors.append(f"json invalid {json_path}: {exc}")
    predicate_registry = read_json(PREDICATE_REGISTRY_PATH, default={})
    allowed_predicates = set(predicate_registry.get("predicates", {}).keys())
    node_schema = read_json(NODE_SCHEMA_PATH, default={})
    allowed_node_types = set(node_schema.get("node_types", {}).keys())
    nodes_by_id: dict[str, dict[str, Any]] = {}
    if (OUTPUT_DIR / "nodes.jsonl").exists():
        for index, line in enumerate((OUTPUT_DIR / "nodes.jsonl").read_text(encoding="utf-8").splitlines(), start=1):
            try:
                node = json.loads(line)
            except json.JSONDecodeError as exc:
                errors.append(f"nodes line {index} invalid json: {exc}")
                continue
            nodes_by_id[node.get("id", "")] = node
            if allowed_node_types and node.get("type") not in allowed_node_types:
                errors.append(f"node {index} type not in NODE_SCHEMA: {node.get('type')}")
    rels = []
    rel_ids: set[str] = set()
    allowed_status = {"observed", "asserted", "inferred", "verified", "superseded", "contradicted"}
    allowed_methods = {"frontmatter", "wikilink", "markdown_heading", "json_artifact", "jsonl_artifact", "automation_toml", "static_seed", "derived_rule", "quality_gate_scan"}
    if (OUTPUT_DIR / "relationships.jsonl").exists():
        for index, line in enumerate((OUTPUT_DIR / "relationships.jsonl").read_text(encoding="utf-8").splitlines(), start=1):
            try:
                rel = json.loads(line)
            except json.JSONDecodeError as exc:
                errors.append(f"relationships line {index} invalid json: {exc}")
                continue
            rels.append(rel)
            for field in ["id", "subject", "predicate", "object", "source_path", "source_span", "source_sha256", "observed_at", "valid_from", "confidence", "extraction_method", "status"]:
                if field not in rel or rel[field] in ("", None):
                    errors.append(f"relationship {index} missing {field}")
            if rel.get("id") in rel_ids:
                errors.append(f"duplicate relationship id: {rel.get('id')}")
            rel_ids.add(rel.get("id", ""))
            if rel.get("status") not in allowed_status:
                errors.append(f"relationship {index} invalid status: {rel.get('status')}")
            if rel.get("extraction_method") not in allowed_methods:
                errors.append(f"relationship {index} invalid method: {rel.get('extraction_method')}")
            if allowed_predicates and rel.get("predicate") not in allowed_predicates:
                errors.append(f"relationship {index} predicate not in registry: {rel.get('predicate')}")
            if nodes_by_id and (rel.get("subject") not in nodes_by_id or rel.get("object") not in nodes_by_id):
                errors.append(f"relationship {index} has missing endpoint")
            if not isinstance(rel.get("confidence"), (int, float)) or not 0 <= rel.get("confidence", -1) <= 1:
                errors.append(f"relationship {index} invalid confidence")
    summary = {}
    if (OUTPUT_DIR / "summary.json").exists():
        summary = json.loads((OUTPUT_DIR / "summary.json").read_text(encoding="utf-8"))
        if summary.get("implementation_status") != "PASS":
            errors.append("summary implementation_status is not PASS")
        for field in ["coverage_status", "operator_risk_status", "policy_gate_status"]:
            if summary.get(field) not in {"PASS", "WARN"}:
                errors.append(f"summary {field} is not PASS/WARN: {summary.get(field)}")
        if summary.get("relationship_count", 0) < 25:
            errors.append("relationship_count too low for phase 0")
    risk_registry = read_json(OUTPUT_DIR / "automation_risk_registry.json", default={})
    if not risk_registry.get("items"):
        errors.append("automation risk registry has no items")
    decision_inbox = read_json(OUTPUT_DIR / "operator_decision_inbox.json", default={})
    if not decision_inbox.get("items"):
        errors.append("operator decision inbox has no items")
    coverage_manifest = read_json(OUTPUT_DIR / "coverage_manifest.json", default={})
    if not coverage_manifest.get("sources"):
        errors.append("coverage manifest has no sources")
    contract_quality = read_json(OUTPUT_DIR / "contract_quality_gate.json", default={})
    if contract_quality.get("status") not in {"PASS", "WARN"}:
        errors.append(f"contract quality gate is not PASS/WARN: {contract_quality.get('status')}")
    contract_items = contract_quality.get("items", [])
    if not any(str(item.get("artifact_kind", "")).startswith("complete_context_before_archival") for item in contract_items):
        errors.append("contract quality gate has no complete_context_before_archival items")
    if not any(str(item.get("artifact_kind", "")) == "long_run_completion:canonical_rule" and item.get("status") == "PASS" for item in contract_items):
        errors.append("contract quality gate has no passing long_run_completion canonical rule item")
    long_run_entrypoints = [item for item in contract_items if str(item.get("artifact_kind", "")) == "long_run_completion:agent_entrypoint"]
    if len(long_run_entrypoints) < len(LONG_RUN_ENTRYPOINTS):
        errors.append(f"contract quality gate has too few long-run entrypoint items: {len(long_run_entrypoints)}")
    long_run_audit = read_json(OUTPUT_DIR / "long_run_completion_audit.json", default={})
    if long_run_audit.get("status") not in {"PASS", "WARN"}:
        errors.append(f"long-run completion audit is not PASS/WARN: {long_run_audit.get('status')}")
    if not any(str(item.get("artifact_kind", "")) == "long_run_completion:completion_report" and item.get("status") == "PASS" for item in contract_items):
        errors.append("contract quality gate has no passing long_run_completion completion report item")
    vault_hygiene = read_json(OUTPUT_DIR / "vault_umlaut_hygiene.json", default={})
    if vault_hygiene.get("status") not in {"PASS", "WARN"}:
        errors.append(f"vault umlaut hygiene status is not PASS/WARN: {vault_hygiene.get('status')}")
    skill_policy_audit = read_json(OUTPUT_DIR / "skill_policy_regression_guard_audit.json", default={})
    if skill_policy_audit.get("status") not in {"PASS", "WARN"}:
        errors.append(f"skill/policy regression guard audit status is not PASS/WARN: {skill_policy_audit.get('status')}")
    for audit_name in [
        "rule_propagation_audit",
        "project_invariant_audit",
        "agent_entrypoint_audit",
        "operator_intent_contract_audit",
    ]:
        audit = read_json(OUTPUT_DIR / f"{audit_name}.json", default={})
        if audit.get("status") not in {"PASS", "WARN"}:
            errors.append(f"{audit_name} status is not PASS/WARN: {audit.get('status')}")
    html_text = (OUTPUT_DIR / "subgraph-lioncom-room16-quellwert.html").read_text(encoding="utf-8") if (OUTPUT_DIR / "subgraph-lioncom-room16-quellwert.html").exists() else ""
    for needle in ["Project Intelligence Graph", "LIONCOM", "Quellwert"]:
        if needle not in html_text:
            errors.append(f"subgraph html missing {needle}")
    drift_text = (OUTPUT_DIR / "drift_report.md").read_text(encoding="utf-8") if (OUTPUT_DIR / "drift_report.md").exists() else ""
    if "Implementation status: `PASS`" not in drift_text:
        errors.append("drift report does not show PASS")
    if errors:
        for error in errors:
            print(f"FAIL: {error}")
        return 1
    print(
        "PASS Project Intelligence Graph validation "
        f"nodes={summary.get('node_count')} relationships={summary.get('relationship_count')}"
    )
    return 0


def build() -> int:
    builder = GraphBuilder()
    builder.scan_obsidian()
    builder.scan_vault_umlaut_hygiene()
    builder.scan_repo_git_ci()
    builder.scan_handoffs()
    builder.scan_automations()
    builder.scan_runtime_state_and_operator_go()
    builder.scan_quality_operating_system()
    builder.scan_rule_propagation_registry()
    builder.scan_project_invariant_registry()
    builder.scan_agent_entrypoint_registry()
    builder.scan_operator_intent_contract_schema()
    builder.scan_long_run_completion_entrypoints()
    builder.scan_long_run_completion_reports()
    builder.scan_skill_policy_regression_guards()
    builder.add_static_focus()
    builder.derive_supersession()
    builder.analyze_drift()
    builder.write_outputs()
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Build or validate Project Intelligence Graph v0 artifacts.")
    parser.add_argument("--validate", action="store_true", help="Validate already generated artifacts.")
    args = parser.parse_args()
    if args.validate:
        return validate_outputs()
    return build()


if __name__ == "__main__":
    raise SystemExit(main())
