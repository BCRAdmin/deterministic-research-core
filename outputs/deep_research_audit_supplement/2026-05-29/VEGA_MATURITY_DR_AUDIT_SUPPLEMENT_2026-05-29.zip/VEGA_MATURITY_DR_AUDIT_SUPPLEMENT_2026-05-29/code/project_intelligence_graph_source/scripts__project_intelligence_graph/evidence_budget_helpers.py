"""Evidence budget helpers for actual archive measurements."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from archive_reference_helpers import zip_stats


def archive_budget_report(
    archive_path: Path,
    *,
    budget_bytes: int,
    expected_archive_bytes: int | None = None,
    stale_archive_paths: list[str] | None = None,
) -> dict[str, Any]:
    stats = zip_stats(archive_path)
    actual_archive_bytes = int(stats.get("archive_bytes", 0) or 0)
    stale = stale_archive_paths or []
    bytes_match = expected_archive_bytes is None or actual_archive_bytes == expected_archive_bytes
    within_budget = bool(actual_archive_bytes and actual_archive_bytes <= budget_bytes)
    return {
        "archive_path": str(archive_path),
        "archive_exists": bool(stats.get("archive_exists")),
        "archive_sha256": stats.get("archive_sha256", ""),
        "actual_archive_bytes": actual_archive_bytes,
        "expected_archive_bytes": expected_archive_bytes if expected_archive_bytes is not None else actual_archive_bytes,
        "actual_archive_bytes_match": bytes_match,
        "actual_member_count": int(stats.get("member_count", 0) or 0),
        "actual_uncompressed_bytes": int(stats.get("uncompressed_bytes", 0) or 0),
        "budget_bytes": budget_bytes,
        "within_budget": within_budget,
        "stale_archive_reference_count": len(stale),
        "stale_archive_paths": stale,
        "top_members": stats.get("top_members", []),
    }
