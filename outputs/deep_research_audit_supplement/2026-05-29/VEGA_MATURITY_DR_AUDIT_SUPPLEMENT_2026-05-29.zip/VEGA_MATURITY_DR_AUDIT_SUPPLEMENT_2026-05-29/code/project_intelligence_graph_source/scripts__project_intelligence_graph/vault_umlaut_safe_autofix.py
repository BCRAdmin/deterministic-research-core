#!/usr/bin/env python3
"""Safely replace obvious German ASCII umlaut spellings in operator-facing Vault notes."""

from __future__ import annotations

import argparse
import datetime as dt
import json
import re
from pathlib import Path


VAULT = Path("/Users/BjornRosinger/Documents/Obsidian/Test Vaul Privat/Human Overview")
OUTPUT_DIR = Path("/Users/BjornRosinger/Documents/DreamFactory/Project-Intelligence-Graph/outputs/project_intelligence_graph")
MANIFEST_JSON = OUTPUT_DIR / "vault_umlaut_safe_autofix_manifest.json"
MANIFEST_MD = OUTPUT_DIR / "vault_umlaut_safe_autofix_manifest.md"

SKIP_PREFIXES = ("ATTACHMENTS/", "LLM Deep Research/reports/")

REPLACEMENTS: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"\bFuer\b"), "Für"),
    (re.compile(r"\bfuer\b"), "für"),
    (re.compile(r"Fuer"), "Für"),
    (re.compile(r"fuer"), "für"),
    (re.compile(r"fuehr"), "führ"),
    (re.compile(r"Fuehr"), "Führ"),
    (re.compile(r"ueber"), "über"),
    (re.compile(r"Ueber"), "Über"),
    (re.compile(r"pruef"), "prüf"),
    (re.compile(r"Pruef"), "Prüf"),
    (re.compile(r"naechst"), "nächst"),
    (re.compile(r"Naechst"), "Nächst"),
    (re.compile(r"frueh"), "früh"),
    (re.compile(r"Frueh"), "Früh"),
    (re.compile(r"Ersterwaehn"), "Ersterwähn"),
    (re.compile(r"ersterwaehn"), "ersterwähn"),
    (re.compile(r"Erwaehn"), "Erwähn"),
    (re.compile(r"erwaehn"), "erwähn"),
    (re.compile(r"aehn"), "ähn"),
    (re.compile(r"Aehn"), "Ähn"),
    (re.compile(r"aelter"), "älter"),
    (re.compile(r"Aelter"), "Älter"),
    (re.compile(r"anhaeng"), "anhäng"),
    (re.compile(r"Anhaeng"), "Anhäng"),
    (re.compile(r"qualitaet"), "qualität"),
    (re.compile(r"Qualitaet"), "Qualität"),
    (re.compile(r"itaet"), "ität"),
    (re.compile(r"Itaet"), "Ität"),
    (re.compile(r"kapazitaet"), "kapazität"),
    (re.compile(r"Kapazitaet"), "Kapazität"),
    (re.compile(r"gruen"), "grün"),
    (re.compile(r"Gruen"), "Grün"),
    (re.compile(r"gruend"), "gründ"),
    (re.compile(r"Gruend"), "Gründ"),
    (re.compile(r"haert"), "härt"),
    (re.compile(r"Haert"), "Härt"),
    (re.compile(r"\bspaet"), "spät"),
    (re.compile(r"\bSpaet"), "Spät"),
    (re.compile(r"temporaer"), "temporär"),
    (re.compile(r"Temporaer"), "Temporär"),
    (re.compile(r"waehr"), "währ"),
    (re.compile(r"Waehr"), "Währ"),
    (re.compile(r"waehl"), "wähl"),
    (re.compile(r"Waehl"), "Wähl"),
    (re.compile(r"laeuf"), "läuf"),
    (re.compile(r"Laeuf"), "Läuf"),
    (re.compile(r"laeng"), "läng"),
    (re.compile(r"Laeng"), "Läng"),
    (re.compile(r"waer"), "wär"),
    (re.compile(r"Waer"), "Wär"),
    (re.compile(r"haett"), "hätt"),
    (re.compile(r"Haett"), "Hätt"),
    (re.compile(r"moeg"), "mög"),
    (re.compile(r"Moeg"), "Mög"),
    (re.compile(r"\bkoenn"), "könn"),
    (re.compile(r"\bKoenn"), "Könn"),
    (re.compile(r"\bmuess"), "müss"),
    (re.compile(r"\bMuess"), "Müss"),
    (re.compile(r"duerf"), "dürf"),
    (re.compile(r"Duerf"), "Dürf"),
    (re.compile(r"mued"), "müd"),
    (re.compile(r"Mued"), "Müd"),
    (re.compile(r"\baender"), "änder"),
    (re.compile(r"\bAender"), "Änder"),
    (re.compile(r"oeff"), "öff"),
    (re.compile(r"Oeff"), "Öff"),
    (re.compile(r"\bloesch"), "lösch"),
    (re.compile(r"\bLoesch"), "Lösch"),
    (re.compile(r"\bgeloescht"), "gelöscht"),
    (re.compile(r"\bGeloescht"), "Gelöscht"),
    (re.compile(r"loes"), "lös"),
    (re.compile(r"Loes"), "Lös"),
    (re.compile(r"noetig"), "nötig"),
    (re.compile(r"Noetig"), "Nötig"),
    (re.compile(r"nuetz"), "nütz"),
    (re.compile(r"Nuetz"), "Nütz"),
    (re.compile(r"aend"), "änd"),
    (re.compile(r"Aend"), "Änd"),
    (re.compile(r"staerk"), "stärk"),
    (re.compile(r"Staerk"), "Stärk"),
    (re.compile(r"staend"), "ständ"),
    (re.compile(r"Staend"), "Ständ"),
    (re.compile(r"schraenk"), "schränk"),
    (re.compile(r"Schraenk"), "Schränk"),
    (re.compile(r"schwaech"), "schwäch"),
    (re.compile(r"Schwaech"), "Schwäch"),
    (re.compile(r"groess"), "größ"),
    (re.compile(r"Groess"), "Größ"),
    (re.compile(r"grossen"), "großen"),
    (re.compile(r"Grossen"), "Großen"),
    (re.compile(r"grosser"), "großer"),
    (re.compile(r"Grosser"), "Großer"),
    (re.compile(r"grosses"), "großes"),
    (re.compile(r"Grosses"), "Großes"),
    (re.compile(r"grossem"), "großem"),
    (re.compile(r"Grossem"), "Großem"),
    (re.compile(r"grosse"), "große"),
    (re.compile(r"Grosse"), "Große"),
    (re.compile(r"\bGROSSEN\b"), "GROẞEN"),
    (re.compile(r"\bGROSSER\b"), "GROẞER"),
    (re.compile(r"\bGROSSES\b"), "GROẞES"),
    (re.compile(r"\bGROSSE\b"), "GROẞE"),
    (re.compile(r"flaech"), "fläch"),
    (re.compile(r"Flaech"), "Fläch"),
    (re.compile(r"geraet"), "gerät"),
    (re.compile(r"Geraet"), "Gerät"),
    (re.compile(r"gedaechtnis"), "gedächtnis"),
    (re.compile(r"Gedaechtnis"), "Gedächtnis"),
    (re.compile(r"gehoer"), "gehör"),
    (re.compile(r"Gehoer"), "Gehör"),
    (re.compile(r"haelf"), "hälf"),
    (re.compile(r"Haelf"), "Hälf"),
    (re.compile(r"haeng"), "häng"),
    (re.compile(r"Haeng"), "Häng"),
    (re.compile(r"faeh"), "fäh"),
    (re.compile(r"Faeh"), "Fäh"),
    (re.compile(r"traeg"), "träg"),
    (re.compile(r"Traeg"), "Träg"),
    (re.compile(r"waeg"), "wäg"),
    (re.compile(r"Waeg"), "Wäg"),
    (re.compile(r"kuenft"), "künft"),
    (re.compile(r"Kuenft"), "Künft"),
    (re.compile(r"gueltig"), "gültig"),
    (re.compile(r"Gueltig"), "Gültig"),
    (re.compile(r"bestaet"), "bestät"),
    (re.compile(r"Bestaet"), "Bestät"),
    (re.compile(r"aufraeum"), "aufräum"),
    (re.compile(r"Aufraeum"), "Aufräum"),
    (re.compile(r"raeum"), "räum"),
    (re.compile(r"Raeum"), "Räum"),
    (re.compile(r"ausgewaehl"), "ausgewähl"),
    (re.compile(r"Ausgewaehl"), "Ausgewähl"),
    (re.compile(r"angestoss"), "angestoß"),
    (re.compile(r"Angestoss"), "Angestoß"),
    (re.compile(r"zusaetz"), "zusätz"),
    (re.compile(r"Zusaetz"), "Zusätz"),
    (re.compile(r"zaehl"), "zähl"),
    (re.compile(r"Zaehl"), "Zähl"),
    (re.compile(r"bloeck"), "blöck"),
    (re.compile(r"Bloeck"), "Blöck"),
    (re.compile(r"praesenz"), "präsenz"),
    (re.compile(r"Praesenz"), "Präsenz"),
    (re.compile(r"vollstaend"), "vollständ"),
    (re.compile(r"Vollstaend"), "Vollständ"),
    (re.compile(r"beduerf"), "bedürf"),
    (re.compile(r"Beduerf"), "Bedürf"),
    (re.compile(r"zuverlaess"), "zuverläss"),
    (re.compile(r"Zuverlaess"), "Zuverläss"),
    (re.compile(r"verknuepf"), "verknüpf"),
    (re.compile(r"Verknuepf"), "Verknüpf"),
    (re.compile(r"ergaenz"), "ergänz"),
    (re.compile(r"Ergaenz"), "Ergänz"),
    (re.compile(r"enthaelt"), "enthält"),
    (re.compile(r"Enthaelt"), "Enthält"),
    (re.compile(r"ursprueng"), "ursprüng"),
    (re.compile(r"Ursprueng"), "Ursprüng"),
    (re.compile(r"brueck"), "brück"),
    (re.compile(r"Brueck"), "Brück"),
    (re.compile(r"beruecksichtig"), "berücksichtig"),
    (re.compile(r"Beruecksichtig"), "Berücksichtig"),
    (re.compile(r"beruehr"), "berühr"),
    (re.compile(r"Beruehr"), "Berühr"),
    (re.compile(r"drueck"), "drück"),
    (re.compile(r"Drueck"), "Drück"),
    (re.compile(r"zurueck"), "zurück"),
    (re.compile(r"Zurueck"), "Zurück"),
    (re.compile(r"rueck"), "rück"),
    (re.compile(r"Rueck"), "Rück"),
    (re.compile(r"aeuss"), "äuß"),
    (re.compile(r"Aeuss"), "Äuß"),
    (re.compile(r"ungefaehr"), "ungefähr"),
    (re.compile(r"Ungefaehr"), "Ungefähr"),
    (re.compile(r"oberflaeche"), "oberfläche"),
    (re.compile(r"Oberflaeche"), "Oberfläche"),
    (re.compile(r"loesung"), "lösung"),
    (re.compile(r"Loesung"), "Lösung"),
    (re.compile(r"lueck"), "lück"),
    (re.compile(r"Lueck"), "Lück"),
    (re.compile(r"baeum"), "bäum"),
    (re.compile(r"Baeum"), "Bäum"),
    (re.compile(r"huell"), "hüll"),
    (re.compile(r"Huell"), "Hüll"),
    (re.compile(r"vorgaeng"), "vorgäng"),
    (re.compile(r"Vorgaeng"), "Vorgäng"),
    (re.compile(r"verfueg"), "verfüg"),
    (re.compile(r"Verfueg"), "Verfüg"),
    (re.compile(r"fueg"), "füg"),
    (re.compile(r"Fueg"), "Füg"),
    (re.compile(r"schlaeg"), "schläg"),
    (re.compile(r"Schlaeg"), "Schläg"),
    (re.compile(r"fluendige"), "flüssige"),
    (re.compile(r"Fluendige"), "Flüssige"),
    (re.compile(r"fluendig"), "flüssig"),
    (re.compile(r"Fluendig"), "Flüssig"),
    (re.compile(r"\bausser"), "außer"),
    (re.compile(r"\bAusser"), "Außer"),
    (re.compile(r"\bAUSSER"), "AUẞER"),
)


def replace_visible_segment(segment: str) -> tuple[str, int]:
    count = 0
    current = segment
    for pattern, replacement in REPLACEMENTS:
        current, changed = pattern.subn(replacement, current)
        count += changed
    return current, count


def replace_outside_inline_code(line: str) -> tuple[str, int]:
    parts = re.split(r"(`[^`]*`|\[\[[^\]]+\]\]|https?://\S+|\b[a-z0-9]+(?:-[a-z0-9]+){2,}\b)", line)
    changed = 0
    for index, part in enumerate(parts):
        if (
            (part.startswith("`") and part.endswith("`"))
            or (part.startswith("[[") and part.endswith("]]"))
            or part.startswith(("http://", "https://"))
            or re.fullmatch(r"\b[a-z0-9]+(?:-[a-z0-9]+){2,}\b", part)
        ):
            continue
        parts[index], part_changed = replace_visible_segment(part)
        changed += part_changed
    return "".join(parts), changed


def should_skip_markdown_path(path: Path) -> bool:
    try:
        rel = path.relative_to(VAULT).as_posix()
    except ValueError:
        rel = path.as_posix()
    return rel.startswith(SKIP_PREFIXES)


def iter_markdown_files(roots: list[Path] | None = None) -> list[Path]:
    roots = roots or [VAULT]
    files: list[Path] = []
    for root in roots:
        if root.is_file() and root.suffix.lower() == ".md":
            if not should_skip_markdown_path(root):
                files.append(root)
            continue
        if not root.exists() or not root.is_dir():
            continue
        for path in sorted(root.rglob("*.md")):
            if should_skip_markdown_path(path):
                continue
            files.append(path)
    return files


def process_file(path: Path, write: bool) -> dict[str, object] | None:
    original = path.read_text(encoding="utf-8")
    lines = original.splitlines(keepends=True)
    new_lines: list[str] = []
    in_code_fence = False
    replacements = 0
    changed_lines: list[int] = []

    for line_no, raw_line in enumerate(lines, start=1):
        newline = ""
        body = raw_line
        if raw_line.endswith("\n"):
            newline = "\n"
            body = raw_line[:-1]
        stripped = body.strip()
        if stripped.startswith("```"):
            in_code_fence = not in_code_fence
            new_lines.append(raw_line)
            continue
        if in_code_fence:
            new_lines.append(raw_line)
            continue
        new_body, changed = replace_outside_inline_code(body)
        if changed:
            replacements += changed
            changed_lines.append(line_no)
        new_lines.append(new_body + newline)

    updated = "".join(new_lines)
    if updated == original:
        return None
    if write:
        path.write_text(updated, encoding="utf-8")
    return {
        "path": str(path),
        "replacements": replacements,
        "changed_line_count": len(changed_lines),
        "sample_lines": changed_lines[:20],
    }


def write_manifest(payload: dict[str, object]) -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    MANIFEST_JSON.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    lines = [
        "# Vault Umlaut Safe Autofix Manifest",
        "",
        f"- Generated: `{payload['generated_at']}`",
        f"- Mode: `{payload['mode']}`",
        f"- Files changed: `{payload['files_changed']}`",
        f"- Replacements: `{payload['replacements']}`",
        f"- Scanned files: `{payload['scanned_files']}`",
        "",
        "## Changed Files",
        "",
    ]
    for item in payload["items"][:120]:  # type: ignore[index]
        lines.append(
            f"- `{item['path']}`: {item['replacements']} replacements on {item['changed_line_count']} lines"  # type: ignore[index]
        )
    MANIFEST_MD.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("paths", nargs="*", type=Path, help="optional Markdown files or directories; defaults to the Human Overview vault")
    parser.add_argument("--write", action="store_true", help="write changes instead of dry-run")
    args = parser.parse_args()

    files = iter_markdown_files(args.paths)
    items = []
    for path in files:
        item = process_file(path, write=args.write)
        if item:
            items.append(item)

    payload = {
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "mode": "write" if args.write else "dry_run",
        "scanned_files": len(files),
        "files_changed": len(items),
        "replacements": sum(int(item["replacements"]) for item in items),
        "rule": "Replace only known German ASCII umlaut stems outside fenced code blocks and inline code spans; skip attachments and report archives.",
        "items": items,
    }
    write_manifest(payload)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
