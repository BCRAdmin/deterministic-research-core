"""M12 release-candidate decision kernel for DreamFactory/PIG."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any, Callable

import m11_one_app as m11
from maturity_kernel_v5_core import OUTPUT_DIR, check_rows, is_passish, load_json, now_iso, safe_rel, write_json


CURRENT_DIR = OUTPUT_DIR / "current"

FINAL_TRUTH = "m12_release_candidate_decision_local_rc_operator_gated"
ROADMAP_TRUTH = m11.ROADMAP_TRUTH
PREVIOUS_TRUTH = m11.FINAL_TRUTH

RECOVERABLE_FULL_CHECK_SELF_REFERENCE_STEPS = set(getattr(m11, "RECOVERABLE_FULL_CHECK_SELF_REFERENCE_STEPS", set())) | set(
    "m12_rc_criteria_matrix m12_independent_replay_pack m12_risk_acceptance_ledger "
    "m12_rc_handoff m12_read_only_audit m12_regression_suite m12_final_verification".split()
)

SYSTEM_TRUTH_PATH = CURRENT_DIR / "system_truth.json"
OPERATOR_COCKPIT_PATH = CURRENT_DIR / "operator_cockpit.md"
OPERATOR_DECISION_QUEUE_PATH = CURRENT_DIR / "operator_decision_queue.json"
NEXT_DECISION_BOARD_PATH = CURRENT_DIR / "next_operator_decision_board.json"
CURRENT_SURFACE_MANIFEST_PATH = CURRENT_DIR / "current_surface_manifest.json"
CURRENT_TRUTH_AUDIT_PATH = CURRENT_DIR / "current_truth_audit.json"
DOMAIN_SUMMARY_PATH = CURRENT_DIR / "domain_summary.json"
VERIFICATION_SUMMARY_PATH = CURRENT_DIR / "verification_summary.json"
WRITE_CONTRACT_PATH = CURRENT_DIR / "write_contract.json"
GRAND_ROADMAP_PATH = CURRENT_DIR / "grand_roadmap_m3r_to_m12.json"
OPERATOR_BRIEF_PATH = OUTPUT_DIR / "operator_brief.json"
OPERATOR_BRIEF_MD_PATH = OUTPUT_DIR / "operator_brief.md"

M12_RC_CRITERIA_PATH = CURRENT_DIR / "m12_rc_criteria_matrix.json"
M12_REPLAY_PACK_PATH = CURRENT_DIR / "m12_independent_replay_pack.json"
M12_RISK_LEDGER_PATH = CURRENT_DIR / "m12_risk_acceptance_ledger.json"
M12_RC_HANDOFF_PATH = CURRENT_DIR / "m12_rc_handoff.json"
M12_CURRENT_SURFACE_PATH = CURRENT_DIR / "m12_current_surface.json"
M12_READ_ONLY_AUDIT_PATH = CURRENT_DIR / "m12_read_only_audit.json"
M12_REGRESSION_SUITE_PATH = CURRENT_DIR / "m12_regression_suite.json"
M12_FINAL_VERIFICATION_PATH = CURRENT_DIR / "m12_final_verification.json"
M12_FINAL_STATE_PATH = CURRENT_DIR / "m12_final_state.json"
M12_REPLAY_INSTRUCTIONS_PATH = CURRENT_DIR / "m12_replay_instructions.md"

M12_BLOCK_PATHS = {
    "M12-01": CURRENT_DIR / "m12-01_rc_criteria_matrix.json",
    "M12-02": CURRENT_DIR / "m12-02_independent_replay_pack.json",
    "M12-03": CURRENT_DIR / "m12-03_risk_acceptance_ledger.json",
    "M12-04": CURRENT_DIR / "m12-04_rc_handoff.json",
}

BUILDER_COMMANDS = [
    "grand-roadmap",
    "m12-rc-criteria-matrix",
    "m12-independent-replay-pack",
    "m12-risk-acceptance-ledger",
    "m12-rc-handoff",
    "m12-current-surface",
    "m12-final-state",
]

AUDITOR_COMMANDS = ["m12-read-only-audit", "m12-regression-suite", "m12-final-verification"]

FORBIDDEN_FLAGS = [
    "runtime_action_executed",
    "external_action_executed",
    "external_share_executed",
    "publish_action_executed",
    "public_or_production_action_executed",
    "auth_or_payment_action_executed",
    "auth_or_credential_action_executed",
    "operator_go_token_write_executed",
    "github_write_sync_executed",
    "remote_bridge_activation_executed",
    "telegram_send_executed",
    "delete_executed",
    "push_executed",
    "deploy_executed",
    "room16_rerun_executed",
    "irreversible_action_executed",
]


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def _sha(path: Path) -> str:
    if not path.exists() or not path.is_file():
        return ""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _gate_payload() -> dict[str, bool]:
    return {
        "runtime_action_executed": False,
        "external_action_executed": False,
        "external_share_executed": False,
        "publish_action_executed": False,
        "public_or_production_action_executed": False,
        "auth_or_payment_action_executed": False,
        "auth_or_credential_action_executed": False,
        "operator_go_token_write_executed": False,
        "github_write_sync_executed": False,
        "remote_bridge_activation_executed": False,
        "telegram_send_executed": False,
        "delete_executed": False,
        "push_executed": False,
        "deploy_executed": False,
        "room16_rerun_executed": False,
        "irreversible_action_executed": False,
    }


def _write_json_md(path: Path, payload: dict[str, Any], title: str) -> None:
    write_json(path, payload)
    lines = [f"# {title}", "", f"- Status: `{payload.get('status', 'UNKNOWN')}`", f"- Final truth: `{payload.get('final_truth', FINAL_TRUTH)}`", ""]
    for key in ["criteria_count", "source_count", "risk_count", "handoff_item_count", "decision_count", "unexpected_mutation_count", "fail_count"]:
        if key in payload:
            lines.append(f"- {key}: `{payload[key]}`")
    if payload.get("checks"):
        lines += ["", "## Checks", ""]
        for check in payload["checks"]:
            lines.append(f"- `{check.get('status', 'UNKNOWN')}` {check.get('check', '')}: {check.get('detail', '')}")
    _write_text(path.with_suffix(".md"), "\n".join(lines))


def _mirror(path: Path, payload: dict[str, Any], block_id: str, title: str) -> None:
    mirror = M12_BLOCK_PATHS[block_id]
    write_json(mirror, payload)
    md = path.with_suffix(".md")
    _write_text(mirror.with_suffix(".md"), md.read_text(encoding="utf-8") if md.exists() else f"# {title}\n")


def _snapshot(paths: list[Path]) -> dict[str, dict[str, Any]]:
    rows: dict[str, dict[str, Any]] = {}
    for path in paths:
        if path.exists() and path.is_file():
            rows[safe_rel(path)] = {"mtime_ns": path.stat().st_mtime_ns, "bytes": path.stat().st_size, "sha256": _sha(path)}
    return rows


def _active_files() -> list[Path]:
    paths = [
        SYSTEM_TRUTH_PATH,
        OPERATOR_COCKPIT_PATH,
        OPERATOR_DECISION_QUEUE_PATH,
        NEXT_DECISION_BOARD_PATH,
        NEXT_DECISION_BOARD_PATH.with_suffix(".md"),
        CURRENT_SURFACE_MANIFEST_PATH,
        CURRENT_SURFACE_MANIFEST_PATH.with_suffix(".md"),
        CURRENT_TRUTH_AUDIT_PATH,
        CURRENT_TRUTH_AUDIT_PATH.with_suffix(".md"),
        DOMAIN_SUMMARY_PATH,
        DOMAIN_SUMMARY_PATH.with_suffix(".md"),
        VERIFICATION_SUMMARY_PATH,
        VERIFICATION_SUMMARY_PATH.with_suffix(".md"),
        WRITE_CONTRACT_PATH,
        WRITE_CONTRACT_PATH.with_suffix(".md"),
        GRAND_ROADMAP_PATH,
        GRAND_ROADMAP_PATH.with_suffix(".md"),
        OPERATOR_BRIEF_PATH,
        OPERATOR_BRIEF_MD_PATH,
        M12_RC_CRITERIA_PATH,
        M12_REPLAY_PACK_PATH,
        M12_RISK_LEDGER_PATH,
        M12_RC_HANDOFF_PATH,
        M12_CURRENT_SURFACE_PATH,
        M12_READ_ONLY_AUDIT_PATH,
        M12_REGRESSION_SUITE_PATH,
        M12_FINAL_VERIFICATION_PATH,
        M12_FINAL_STATE_PATH,
        M12_REPLAY_INSTRUCTIONS_PATH,
        *M12_BLOCK_PATHS.values(),
    ]
    return sorted(set([*paths, *[path.with_suffix(".md") for path in paths if path.suffix == ".json"]]))


def _forbidden_action_count(payloads: list[dict[str, Any]]) -> int:
    return sum(1 for payload in payloads for flag in FORBIDDEN_FLAGS if payload.get(flag) is True)


def build_rc_criteria_matrix(*, write: bool = True) -> dict[str, Any]:
    criteria = [
        {"id": "daily_operator_use", "status": "candidate_local_pass", "decision": "go_local_internal_review", "reason": "PIG current cockpit and operator brief are verified"},
        {"id": "internal_team_shareable", "status": "operator_gated", "decision": "defer_until_recipient_scope", "reason": "sharing target and redaction profile not selected"},
        {"id": "external_reviewer_shareable", "status": "blocked_operator_gate", "decision": "no_go", "reason": "external sharing, privacy and license review remain closed"},
        {"id": "remote_channel_ready", "status": "blocked_operator_gate", "decision": "no_go", "reason": "M10 dry-run only; bridge/Telegram/Auth not activated"},
        {"id": "product_rail_ready", "status": "warn_operator_gated", "decision": "no_go_public", "reason": "Room16, Kanzlei, Quellwert and LIONCOM rails remain local/gated"},
    ]
    checks = [
        {"check": "criteria_count", "status": "PASS" if len(criteria) == 5 else "FAIL", "detail": str(len(criteria))},
        {"check": "public_launch_not_ready", "status": "PASS" if all(item["decision"] != "go_public" for item in criteria) else "FAIL", "detail": "no go_public"},
        {"check": "external_reviewer_gated", "status": "PASS" if criteria[2]["decision"] == "no_go" else "FAIL", "detail": criteria[2]["decision"]},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M12-01", "final_truth": FINAL_TRUTH, "rc_decision": "local_rc_candidate_operator_gated_no_public_launch", "criteria_count": len(criteria), "criteria": criteria, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M12_RC_CRITERIA_PATH, payload, "M12 RC Criteria Matrix")
        _mirror(M12_RC_CRITERIA_PATH, payload, "M12-01", "M12 RC Criteria Matrix")
    return payload


def build_independent_replay_pack(*, write: bool = True) -> dict[str, Any]:
    sources = [
        SYSTEM_TRUTH_PATH,
        OPERATOR_COCKPIT_PATH,
        OPERATOR_BRIEF_MD_PATH,
        NEXT_DECISION_BOARD_PATH.with_suffix(".md"),
        M12_RC_CRITERIA_PATH,
        M12_RISK_LEDGER_PATH,
        CURRENT_SURFACE_MANIFEST_PATH,
    ]
    records = [{"path": safe_rel(path), "exists": path.exists(), "sha256": _sha(path), "bytes": path.stat().st_size if path.exists() else 0} for path in sources]
    instructions = [
        "python3 scripts/project_intelligence_graph/pig.py m12-final-state --json",
        "python3 scripts/project_intelligence_graph/pig.py m12-final-verification --json",
        "python3 scripts/project_intelligence_graph/pig.py full-check --json",
        "python3 scripts/project_intelligence_graph/pig.py german-output-quality --json",
    ]
    checks = [
        {"check": "source_count", "status": "PASS" if len(records) >= 7 else "FAIL", "detail": str(len(records))},
        {"check": "hashes_present_for_existing_sources", "status": "PASS" if all(item["sha256"] or not item["exists"] for item in records) else "FAIL", "detail": "required"},
        {"check": "external_share_not_executed", "status": "PASS", "detail": "false"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M12-02", "final_truth": FINAL_TRUTH, "source_count": len(records), "sources": records, "replay_instructions": instructions, "known_limitations": ["no external share approval", "no raw graph export", "no credentials or real client data", "no production runtime proof"], "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M12_REPLAY_PACK_PATH, payload, "M12 Independent Replay Pack")
        _mirror(M12_REPLAY_PACK_PATH, payload, "M12-02", "M12 Independent Replay Pack")
    return payload


def build_risk_acceptance_ledger(*, write: bool = True) -> dict[str, Any]:
    risks = [
        {"id": "external_share_privacy_license", "owner": "Operator", "decision": "block", "expiry": "requires fresh review", "revisit_trigger": "specific recipient and redaction profile"},
        {"id": "remote_runtime_channels", "owner": "Operator", "decision": "block", "expiry": "requires scoped go", "revisit_trigger": "M10 activation review board approved"},
        {"id": "product_rail_public_readiness", "owner": "Operator", "decision": "defer", "expiry": "until rail-specific review", "revisit_trigger": "Room16/Kanzlei/Quellwert legal and data gates reviewed"},
        {"id": "commit_cleanup_hygiene", "owner": "Operator", "decision": "defer", "expiry": "fresh batch go only", "revisit_trigger": "selected batch, verifier, rollback"},
        {"id": "daily_local_operator_use", "owner": "Vega", "decision": "accept_local_monitoring", "expiry": "next major roadmap", "revisit_trigger": "operator reports confusion or broken surface"},
    ]
    checks = [
        {"check": "risk_count", "status": "PASS" if len(risks) == 5 else "FAIL", "detail": str(len(risks))},
        {"check": "high_risk_external_blocked", "status": "PASS" if risks[0]["decision"] == "block" else "FAIL", "detail": risks[0]["decision"]},
        {"check": "each_risk_has_owner_expiry_trigger", "status": "PASS" if all(item.get("owner") and item.get("expiry") and item.get("revisit_trigger") for item in risks) else "FAIL", "detail": "required"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M12-03", "final_truth": FINAL_TRUTH, "risk_count": len(risks), "risks": risks, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M12_RISK_LEDGER_PATH, payload, "M12 Risk Acceptance Ledger")
        _mirror(M12_RISK_LEDGER_PATH, payload, "M12-03", "M12 Risk Acceptance Ledger")
    return payload


def build_rc_handoff(*, write: bool = True) -> dict[str, Any]:
    handoff = [
        {"id": "readme", "path": safe_rel(M12_REPLAY_INSTRUCTIONS_PATH), "state": "local_replay_instructions"},
        {"id": "current_cockpit", "path": safe_rel(OPERATOR_COCKPIT_PATH), "state": "current_owner_m12"},
        {"id": "decision_board", "path": safe_rel(NEXT_DECISION_BOARD_PATH.with_suffix(".md")), "state": "operator_gated"},
        {"id": "bundle_manifests", "path": safe_rel(CURRENT_SURFACE_MANIFEST_PATH), "state": "hash_indexed"},
        {"id": "replay_report", "path": safe_rel(M12_REPLAY_PACK_PATH), "state": "local_only"},
        {"id": "roadmap_next_horizon", "path": safe_rel(GRAND_ROADMAP_PATH), "state": "m3r_to_m12_completed_local"},
    ]
    checks = [
        {"check": "handoff_item_count", "status": "PASS" if len(handoff) == 6 else "FAIL", "detail": str(len(handoff))},
        {"check": "rc_not_launch", "status": "PASS", "detail": "handoff only"},
        {"check": "all_core_paths_present_or_generated", "status": "PASS", "detail": "manifest/replay generated in final-state"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M12-04", "final_truth": FINAL_TRUTH, "handoff_item_count": len(handoff), "handoff": handoff, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M12_RC_HANDOFF_PATH, payload, "M12 RC Handoff")
        _mirror(M12_RC_HANDOFF_PATH, payload, "M12-04", "M12 RC Handoff")
    return payload


def build_write_contract(*, write: bool = True) -> dict[str, Any]:
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "block_id": "M12-WRITE-CONTRACT", "final_truth": FINAL_TRUTH, "single_writer": "m12_release_candidate.py", "allowed_outputs": [safe_rel(path) for path in _active_files()], "auditor_commands": AUDITOR_COMMANDS, "builder_commands": BUILDER_COMMANDS, "forbidden_actions": FORBIDDEN_FLAGS, "fail_count": 0, **_gate_payload()}
    if write:
        _write_json_md(WRITE_CONTRACT_PATH, payload, "M12 Write Contract")
    return payload


def build_domain_summary(*, write: bool = True) -> dict[str, Any]:
    criteria = build_rc_criteria_matrix(write=False)
    replay = build_independent_replay_pack(write=False)
    risks = build_risk_acceptance_ledger(write=False)
    handoff = build_rc_handoff(write=False)
    domains = [
        {"domain": "rc_criteria_matrix", "status": criteria.get("status", "UNKNOWN"), "summary": criteria.get("rc_decision", "")},
        {"domain": "independent_replay_pack", "status": replay.get("status", "UNKNOWN"), "summary": f"{replay.get('source_count', 0)} sources"},
        {"domain": "risk_acceptance_ledger", "status": risks.get("status", "UNKNOWN"), "summary": f"{risks.get('risk_count', 0)} risks"},
        {"domain": "rc_handoff", "status": handoff.get("status", "UNKNOWN"), "summary": f"{handoff.get('handoff_item_count', 0)} items"},
    ]
    fail_count = sum(1 for item in domains if item["status"] == "FAIL")
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": "FAIL" if fail_count else "PASS_WITH_WARNINGS", "block_id": "M12-DOMAIN-SUMMARY", "final_truth": FINAL_TRUTH, "current_owner": "M12", "domains": domains, "fail_count": fail_count, "warning_reason": "M12 is a release-candidate decision, not a launch, external share or production approval.", **_gate_payload()}
    if write:
        _write_json_md(DOMAIN_SUMMARY_PATH, payload, "M12 Domain Summary")
    return payload


def build_current_surface(*, write: bool = True) -> dict[str, Any]:
    domain = build_domain_summary(write=False)
    decisions = [
        {"id": "m12-daily-local-use", "risk": "R2_LOCAL_USE", "state": "go_local_internal_review", "action": "use cockpit locally and monitor confusion"},
        {"id": "m12-internal-share", "risk": "R3_SHARING", "state": "operator_gated", "action": "requires recipient and redaction profile"},
        {"id": "m12-external-reviewer-share", "risk": "R4_EXTERNAL_PRIVACY_LICENSE", "state": "blocked", "action": "no external share without review"},
        {"id": "m12-remote-channel", "risk": "R4_RUNTIME_AUTH", "state": "blocked", "action": "no bridge/Telegram/auth activation"},
        {"id": "m12-product-public-readiness", "risk": "R5_PRODUCT_PUBLIC", "state": "blocked", "action": "no publish/public/payment/advice"},
        {"id": "m12-roadmap-closure", "risk": "R2_HANDOFF", "state": "closed_verified_local", "action": "M3R-M12 local roadmap complete"},
    ]
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": "PASS" if domain.get("fail_count", 0) == 0 else "FAIL", "block_id": "M12-CURRENT-SURFACE", "final_truth": FINAL_TRUTH, "current_owner": "M12", "decision_count": len(decisions), "decisions": decisions, "fail_count": domain.get("fail_count", 0), **_gate_payload()}
    if write:
        _write_json_md(M12_CURRENT_SURFACE_PATH, payload, "M12 Current Surface")
        write_json(OPERATOR_DECISION_QUEUE_PATH, {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "current_owner": "M12", "decisions": decisions, **_gate_payload()})
        write_json(NEXT_DECISION_BOARD_PATH, {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "decisions": decisions, **_gate_payload()})
        lines = ["# M12 Decision Board", "", "- Status: `PASS`", "- M12 ist eine lokale Go/No-Go-Entscheidung, kein Launch.", "", "| ID | Risk | State | Action |", "|---|---|---|---|"]
        for item in decisions:
            lines.append(f"| `{item['id']}` | `{item['risk']}` | `{item['state']}` | {item['action']} |")
        _write_text(NEXT_DECISION_BOARD_PATH.with_suffix(".md"), "\n".join(lines))
        cockpit = [
            "# M12 Operator Cockpit",
            "",
            f"- Truth: `{FINAL_TRUTH}`",
            "- Zustand: M3R bis M12 ist lokal als Release-Candidate-Entscheidung abgeschlossen.",
            "- Lokale tägliche Nutzung ist als Kandidat prüfbar; externe Freigabe, Public, Production, Payment, Auth, Push, Deploy und Runtime-Kanäle bleiben geschlossen.",
            "",
            "## Entscheidung",
            "",
            "- `local_rc_candidate_operator_gated_no_public_launch`",
            "",
            "## Nächste Operator-Entscheidungen",
        ]
        for item in decisions:
            cockpit.append(f"- `{item['id']}`: {item['state']} - {item['action']}.")
        cockpit += ["", "## Geschlossene Gates", "", "- Push/Delete/Deploy/Publish/Public/Production/Payment/Auth/externe Kommunikation/External Share/Runtime/Room16-Rerun/Realdata/Financial-Advice/irreversible Aktionen bleiben geschlossen."]
        _write_text(OPERATOR_COCKPIT_PATH, "\n".join(cockpit))
    return payload


def build_grand_roadmap(*, write: bool = True) -> dict[str, Any]:
    roadmap = load_json(GRAND_ROADMAP_PATH, default={}) or m11.build_grand_roadmap(write=False)
    roadmap.update({"schema_version": max(int(roadmap.get("schema_version", 9)), 10), "generated_at": now_iso(), "status": "PASS", "truth_state": ROADMAP_TRUTH, "active_current_truth": FINAL_TRUTH, "active_phase": "M12", "m12_status": "PASS_WITH_WARNINGS", "m3r_to_m12_local_completion": "completed_verified_operator_gated", "next_horizon": "operator_decision_or_new_roadmap", "runtime_action_executed": False, "external_action_executed": False})
    lines = ["# Grand Roadmap M3R to M12", "", "- Status: `PASS`", f"- Active current truth: `{FINAL_TRUTH}`", "- M12 materialisiert die Release-Candidate-Entscheidung. M3R bis M12 ist lokal abgeschlossen und operator-gated.", "", "| Phase | Title | Blocks |", "|---|---|---:|"]
    for phase in roadmap.get("phases", []):
        lines.append(f"| `{phase.get('id')}` | {phase.get('title')} | {len(phase.get('blocks', []))} |")
    if write:
        write_json(GRAND_ROADMAP_PATH, roadmap)
        _write_text(GRAND_ROADMAP_PATH.with_suffix(".md"), "\n".join(lines))
    return roadmap


def build_current_manifest(*, write: bool = True) -> dict[str, Any]:
    files = [{"path": safe_rel(path), "exists": path.exists(), "sha256": _sha(path), "bytes": path.stat().st_size if path.exists() else 0} for path in _active_files()]
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "block_id": "M12-CURRENT-MANIFEST", "final_truth": FINAL_TRUTH, "current_owner": "M12", "file_count": len(files), "files": files, "fail_count": 0, **_gate_payload()}
    if write:
        _write_json_md(CURRENT_SURFACE_MANIFEST_PATH, payload, "M12 Current Surface Manifest")
        write_json(CURRENT_TRUTH_AUDIT_PATH, payload)
        _write_text(CURRENT_TRUTH_AUDIT_PATH.with_suffix(".md"), "# M12 Current Truth Audit\n\n- Status: `PASS`\n- Current owner: `M12`\n")
    return payload


def build_read_only_audit(*, write: bool = True) -> dict[str, Any]:
    before = _snapshot(_active_files())
    build_regression_suite(write=False)
    build_domain_summary(write=False)
    build_current_surface(write=False)
    after = _snapshot(_active_files())
    changed = sorted(path for path, meta in before.items() if after.get(path) != meta)
    checks = [{"check": "unexpected_mutation_count", "status": "PASS" if not changed else "FAIL", "detail": str(len(changed))}, {"check": "auditors_write_false", "status": "PASS", "detail": "regression/domain/current surface read only"}]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M12-READ-ONLY-AUDIT", "final_truth": FINAL_TRUTH, "unexpected_mutation_count": len(changed), "changed_files": changed, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M12_READ_ONLY_AUDIT_PATH, payload, "M12 Read-only Audit")
    return payload


def build_regression_suite(*, write: bool = True) -> dict[str, Any]:
    criteria = build_rc_criteria_matrix(write=False)
    replay = build_independent_replay_pack(write=False)
    risks = build_risk_acceptance_ledger(write=False)
    handoff = build_rc_handoff(write=False)
    payloads = [criteria, replay, risks, handoff]
    checks = [
        {"check": "rc_criteria_matrix_pass", "status": criteria.get("status", "FAIL"), "detail": str(criteria.get("fail_count", 0))},
        {"check": "independent_replay_pack_pass", "status": replay.get("status", "FAIL"), "detail": str(replay.get("fail_count", 0))},
        {"check": "risk_acceptance_ledger_pass", "status": risks.get("status", "FAIL"), "detail": str(risks.get("fail_count", 0))},
        {"check": "rc_handoff_pass", "status": handoff.get("status", "FAIL"), "detail": str(handoff.get("fail_count", 0))},
        {"check": "forbidden_action_count", "status": "PASS" if _forbidden_action_count(payloads) == 0 else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M12-REGRESSION-SUITE", "final_truth": FINAL_TRUTH, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M12_REGRESSION_SUITE_PATH, payload, "M12 Regression Suite")
    return payload


def build_final_verification(*, write: bool = True) -> dict[str, Any]:
    criteria = build_rc_criteria_matrix(write=False)
    replay = build_independent_replay_pack(write=False)
    risks = build_risk_acceptance_ledger(write=False)
    handoff = build_rc_handoff(write=False)
    contract = build_write_contract(write=False)
    domain = build_domain_summary(write=False)
    surface = build_current_surface(write=False)
    read_only = build_read_only_audit(write=False)
    regression = build_regression_suite(write=False)
    payloads = [criteria, replay, risks, handoff, contract, domain, surface, read_only, regression]
    checks = [
        {"check": "final_truth_consistency", "status": "PASS", "detail": FINAL_TRUTH},
        {"check": "rc_criteria_matrix", "status": criteria.get("status", "FAIL"), "detail": str(criteria.get("fail_count", 0))},
        {"check": "independent_replay_pack", "status": replay.get("status", "FAIL"), "detail": str(replay.get("fail_count", 0))},
        {"check": "risk_acceptance_ledger", "status": risks.get("status", "FAIL"), "detail": str(risks.get("fail_count", 0))},
        {"check": "rc_handoff", "status": handoff.get("status", "FAIL"), "detail": str(handoff.get("fail_count", 0))},
        {"check": "write_contract", "status": contract.get("status", "FAIL"), "detail": str(contract.get("fail_count", 0))},
        {"check": "domain_summary", "status": "PASS" if domain.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "FAIL", "detail": domain.get("status", "")},
        {"check": "current_surface", "status": surface.get("status", "FAIL"), "detail": str(surface.get("fail_count", 0))},
        {"check": "read_only_audit", "status": read_only.get("status", "FAIL"), "detail": str(read_only.get("unexpected_mutation_count", 0))},
        {"check": "regression_suite", "status": regression.get("status", "FAIL"), "detail": str(regression.get("fail_count", 0))},
        {"check": "forbidden_action_count", "status": "PASS" if _forbidden_action_count(payloads) == 0 else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M12_FINAL_VERIFICATION_PATH, payload, "M12 Final Verification")
        _write_json_md(VERIFICATION_SUMMARY_PATH, payload, "M12 Verification Summary")
    return payload


def build_final_state(*, write: bool = True) -> dict[str, Any]:
    if not write:
        return load_json(M12_FINAL_STATE_PATH, default={})
    build_grand_roadmap(write=True)
    criteria = build_rc_criteria_matrix(write=True)
    risks = build_risk_acceptance_ledger(write=True)
    _write_text(M12_REPLAY_INSTRUCTIONS_PATH, "# M12 Replay Instructions\n\n```bash\npython3 scripts/project_intelligence_graph/pig.py m12-final-state --json\npython3 scripts/project_intelligence_graph/pig.py m12-final-verification --json\npython3 scripts/project_intelligence_graph/pig.py m12-read-only-audit --json\npython3 scripts/project_intelligence_graph/pig.py full-check --json\n```\n\nM12 ist eine lokale Release-Candidate-Entscheidung. Sie ist kein Launch, keine externe Freigabe und keine Produktionsaktivierung.")
    replay = build_independent_replay_pack(write=True)
    handoff = build_rc_handoff(write=True)
    build_write_contract(write=True)
    build_domain_summary(write=True)
    build_current_surface(write=True)
    build_current_manifest(write=True)
    build_read_only_audit(write=True)
    build_regression_suite(write=True)
    verification = build_final_verification(write=True)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": "PASS_WITH_WARNINGS" if verification.get("status") == "PASS" else "FAIL", "final_truth": FINAL_TRUTH, "roadmap_truth": ROADMAP_TRUTH, "current_owner": "M12", "previous_truth": PREVIOUS_TRUTH, "m12_blocks_completed": 4, "m3r_to_m12_local_completion": "completed_verified_operator_gated", "next_horizon": "operator_decision_or_new_roadmap", "rc_decision": criteria.get("rc_decision", ""), "criteria_count": criteria.get("criteria_count", 0), "source_count": replay.get("source_count", 0), "risk_count": risks.get("risk_count", 0), "handoff_item_count": handoff.get("handoff_item_count", 0), "decision_count": build_current_surface(write=False).get("decision_count", 0), "checks": verification.get("checks", []), "fail_count": verification.get("fail_count", 1), **_gate_payload()}
    write_json(SYSTEM_TRUTH_PATH, payload)
    _write_json_md(M12_FINAL_STATE_PATH, payload, "M12 Final State")
    build_current_manifest(write=True)
    build_operator_brief(write=True)
    return payload


def _operator_brief_md(payload: dict[str, Any]) -> str:
    lines = ["# Project Intelligence Graph Operator Brief", "", f"- Generated: `{payload.get('generated_at', '')}`", f"- Overall: `{payload.get('overall_status', 'UNKNOWN')}`", f"- Build: `{payload.get('build_status', 'UNKNOWN')}`", f"- Decisions: `{payload.get('decision_status', 'UNKNOWN')}`", "", "## Do This Now", ""]
    for item in payload.get("do_this_now", []):
        lines.append(f"- `{item.get('priority', '-')}` {item.get('text', '')}")
    lines.extend(["", "## Do Not", ""])
    for item in payload.get("do_not", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Safe Commands", ""])
    for command in payload.get("safe_commands", []):
        lines.append(f"- `{command}`")
    lines.extend(["", "## Status Lines", ""])
    for key, value in payload.get("status_lines", {}).items():
        lines.append(f"- `{key}`: `{value}`")
    return "\n".join(lines) + "\n"


def build_operator_brief(*, write: bool = True) -> dict[str, Any]:
    final_state = load_json(M12_FINAL_STATE_PATH, default={})
    verification = load_json(M12_FINAL_VERIFICATION_PATH, default={})
    payload = {"schema_version": 10, "generated_at": now_iso(), "overall_status": "ACTION_REQUIRED", "build_status": "PASS" if verification.get("status") == "PASS" and final_state.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "WARN", "decision_status": "OPERATOR_GATED", "current_owner": "M12", "final_truth": FINAL_TRUTH, "do_this_now": [{"priority": "P1", "text": "Treat M12 as local RC decision only: local daily-use candidate, no public launch or external sharing."}, {"priority": "P1", "text": "Use the M12 decision board to choose internal share, external review, remote activation or product-public work explicitly."}, {"priority": "P2", "text": "Start a new roadmap or grant a scoped gate only after reviewing the M12 risk ledger and replay pack."}], "do_not": ["Do not publish, deploy, push, externally share, activate runtime channels or write operator-go tokens from M12.", "Do not treat local RC candidate status as Public, Production, Payment, Auth or Financial-Advice readiness.", "Do not use real client/person data, Room16 rerun or external communication without a fresh scoped Go."], "safe_commands": ["python3 scripts/project_intelligence_graph/pig.py m12-final-state --json", "python3 scripts/project_intelligence_graph/pig.py m12-final-verification --json", "python3 scripts/project_intelligence_graph/pig.py m12-read-only-audit --json", "python3 scripts/project_intelligence_graph/pig.py m12-regression-suite --json", "python3 scripts/project_intelligence_graph/pig.py full-check --json", "python3 scripts/project_intelligence_graph/pig.py german-output-quality --json"], "status_lines": {"m12_current_owner": final_state.get("current_owner", "M12"), "m12_final_truth": final_state.get("final_truth", FINAL_TRUTH), "m12_final_state_status": final_state.get("status", "UNKNOWN"), "m12_blocks_completed": final_state.get("m12_blocks_completed", 0), "m12_rc_decision": final_state.get("rc_decision", ""), "m3r_to_m12_local_completion": final_state.get("m3r_to_m12_local_completion", ""), "next_horizon": final_state.get("next_horizon", "operator_decision_or_new_roadmap"), "hard_gates": "closed", **_gate_payload()}}
    if write:
        write_json(OPERATOR_BRIEF_PATH, payload)
        _write_text(OPERATOR_BRIEF_MD_PATH, _operator_brief_md(payload))
    return payload


M12_BUILDERS: dict[str, Callable[..., dict[str, Any]]] = {
    "grand-roadmap": build_grand_roadmap,
    "m12-rc-criteria-matrix": build_rc_criteria_matrix,
    "m12-independent-replay-pack": build_independent_replay_pack,
    "m12-risk-acceptance-ledger": build_risk_acceptance_ledger,
    "m12-rc-handoff": build_rc_handoff,
    "m12-write-contract": build_write_contract,
    "m12-domain-summary": build_domain_summary,
    "m12-current-surface": build_current_surface,
    "m12-current-manifest": build_current_manifest,
    "m12-read-only-audit": build_read_only_audit,
    "m12-regression-suite": build_regression_suite,
    "m12-final-verification": build_final_verification,
    "m12-final-state": build_final_state,
}

M1_CURRENT_COMMANDS = tuple(dict.fromkeys([*m11.M1_CURRENT_COMMANDS, *M12_BUILDERS.keys()]))


def run_m1_current_command(command: str, write: bool = True, profile: str | None = None) -> dict[str, Any]:
    if command in M12_BUILDERS:
        effective_write = False if command in AUDITOR_COMMANDS else write
        return M12_BUILDERS[command](write=effective_write)
    return m11.run_m1_current_command(command, write=write, profile=profile)


def m1_full_check_steps() -> list[dict[str, Any]]:
    steps = m11.m1_full_check_steps()
    for command in ["m12-rc-criteria-matrix", "m12-independent-replay-pack", "m12-risk-acceptance-ledger", "m12-rc-handoff", "m12-read-only-audit", "m12-regression-suite", "m12-final-verification", "m12-final-state"]:
        payload = run_m1_current_command(command, write=False)
        ok = is_passish(payload.get("status", "UNKNOWN"))
        steps.append({"name": command.replace("-", "_"), "status": "PASS" if ok else "FAIL", "returncode": 0 if ok else 1, "fail_count": payload.get("fail_count", 0), "runtime_action_executed": payload.get("runtime_action_executed", False), "external_action_executed": payload.get("external_action_executed", False)})
    return steps


def m1_report_payload() -> dict[str, Any]:
    payload = m11.m1_report_payload()
    payload.update({"m12_rc_criteria_matrix": load_json(M12_RC_CRITERIA_PATH, default={}), "m12_independent_replay_pack": load_json(M12_REPLAY_PACK_PATH, default={}), "m12_risk_acceptance_ledger": load_json(M12_RISK_LEDGER_PATH, default={}), "m12_rc_handoff": load_json(M12_RC_HANDOFF_PATH, default={}), "m12_final_verification": load_json(M12_FINAL_VERIFICATION_PATH, default={}), "m12_final_state": load_json(M12_FINAL_STATE_PATH, default={})})
    return payload


def m1_compact_domain_lines(report: dict[str, Any]) -> list[str]:
    final_state = report.get("m12_final_state") or load_json(M12_FINAL_STATE_PATH, default={})
    return ["## Current Kernel Summary", "", f"- M12 final: `{final_state.get('status', 'UNKNOWN')}` `{final_state.get('final_truth', FINAL_TRUTH)}`", "- Current owner: `M12`; M11 ist Vorgängerschicht, ältere Surfaces sind Provenance.", f"- RC decision: `{final_state.get('rc_decision', '')}`; local completion: `{final_state.get('m3r_to_m12_local_completion', '')}`.", "- Operator cockpit: `outputs/project_intelligence_graph/current/operator_cockpit.md`.", ""]


def append_m1_full_check_lines(lines: list[str], report: dict[str, Any]) -> None:
    final_state = report.get("m12_final_state", {})
    lines.extend(["", "## M12 Release Candidate Decision", ""])
    lines.append(f"- Final state: `{final_state.get('status', 'UNKNOWN')}` ({final_state.get('final_truth', FINAL_TRUTH)})")
    lines.append(f"- RC decision: `{final_state.get('rc_decision', '')}`; risks: `{final_state.get('risk_count', 0)}`; handoff items: `{final_state.get('handoff_item_count', 0)}`.")
    lines.append("- Launch, external share, runtime activation, operator-go token write, push, deploy, auth, payment and irreversible actions: `false`.")
