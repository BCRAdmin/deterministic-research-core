"""M3R current-kernel RC1 layer for DreamFactory/PIG."""

from __future__ import annotations

import hashlib
import json
import re
import zipfile
from collections import Counter
from pathlib import Path
from typing import Any, Callable

import m2_current as m2
from maturity_kernel_v5_core import (
    HARD_GATES,
    OUTPUT_DIR,
    REVIEW_BUNDLES_DIR,
    WORKSPACE,
    check_rows,
    is_passish,
    load_json,
    now_iso,
    safe_rel,
    write_json,
)


CURRENT_DIR = OUTPUT_DIR / "current"
SCRIPTS_DIR = WORKSPACE / "scripts/project_intelligence_graph"
AFTERBURNER_PACK_PATH = Path("/Users/BjornRosinger/Downloads/vega_grand_roadmap_afterburner_pack.zip")

FINAL_TRUTH = "m3r_system_kernel_rc1_backcast_replayable_attested_decision_ready_operator_gated"
ROADMAP_TRUTH = "grand_kernel_roadmap_rc1_m3r_to_m12_backcast_operator_gated"

SYSTEM_TRUTH_PATH = CURRENT_DIR / "system_truth.json"
OPERATOR_COCKPIT_PATH = CURRENT_DIR / "operator_cockpit.md"
OPERATOR_DECISION_QUEUE_PATH = CURRENT_DIR / "operator_decision_queue.json"
CURRENT_SURFACE_MANIFEST_PATH = CURRENT_DIR / "current_surface_manifest.json"
FINAL_STATE_PATH = CURRENT_DIR / "m3r_final_state.json"
FINAL_VERIFICATION_PATH = CURRENT_DIR / "final_verification_summary.json"
GRAND_ROADMAP_PATH = CURRENT_DIR / "grand_roadmap_m3r_to_m12.json"
NEXT_DECISION_BOARD_PATH = CURRENT_DIR / "next_operator_decision_board.json"
DECISION_BOARD_MD_PATH = CURRENT_DIR / "decision_board.md"
POST_PACK_MANIFEST_PATH = CURRENT_DIR / "post_pack_manifest.json"
POST_PACK_MANIFEST_MD_PATH = CURRENT_DIR / "post_pack_manifest.md"
REPLAY_INSTRUCTIONS_PATH = CURRENT_DIR / "m3r_replay_instructions.md"
CODE_REVIEW_DELTA_SUMMARY_PATH = CURRENT_DIR / "m3r_code_review_delta_summary.md"
WRAPPER_SIDECAR_PATH = CURRENT_DIR / "m3r_handoff_wrapper_sidecar.json"

M3R_BLOCK_PATHS = {
    "M3R-00": CURRENT_DIR / "m3r-00_run_covenant_backcast_lock.json",
    "M3R-01": CURRENT_DIR / "m3r-01_build_order_post_pack_attestation.json",
    "M3R-02": CURRENT_DIR / "m3r-02_current_namespace_lock.json",
    "M3R-03": CURRENT_DIR / "m3r-03_status_algebra.json",
    "M3R-04": CURRENT_DIR / "m3r-04_read_only_replay_harness.json",
    "M3R-05": CURRENT_DIR / "m3r-05_source_proof_index.json",
    "M3R-06": CURRENT_DIR / "m3r-06_evidence_budget_retention_diet.json",
    "M3R-07": CURRENT_DIR / "m3r-07_repo_hygiene_decision_board_v3.json",
    "M3R-08": CURRENT_DIR / "m3r-08_vivi_v3_6_accountability_worker.json",
    "M3R-09": CURRENT_DIR / "m3r-09_existing_rails_quality_kernel_v5.json",
    "M3R-10": CURRENT_DIR / "m3r-10_kernel_code_review_delta.json",
    "M3R-11": CURRENT_DIR / "m3r-11_operator_cockpit_compression.json",
    "M3R-12": CURRENT_DIR / "m3r-12_final_verification_handoff_wrapper.json",
}

M4_FOUNDATION_PATHS = {
    "M4-01": CURRENT_DIR / "m4-01_current_kernel_api.json",
    "M4-02": CURRENT_DIR / "m4-02_single_writer_multi_reader_discipline.json",
    "M4-03": CURRENT_DIR / "m4-03_domain_compression_engine.json",
    "M4-05": CURRENT_DIR / "m4-05_replay_cli_consolidation.json",
    "M4-07": CURRENT_DIR / "m4-07_current_kernel_regression_suite.json",
}

MINIMAL_ZIP_PATH = REVIEW_BUNDLES_DIR / "m3r_minimal_shareable.zip"
CODE_REVIEW_ZIP_PATH = REVIEW_BUNDLES_DIR / "m3r_kernel_code_review_delta.zip"
LOCAL_INTERNAL_ZIP_PATH = REVIEW_BUNDLES_DIR / "m3r_local_internal_full.zip"
WRAPPER_ZIP_PATH = REVIEW_BUNDLES_DIR / "m3r_handoff_wrapper.zip"
WRAPPER_HASH_PATH = REVIEW_BUNDLES_DIR / "m3r_handoff_wrapper.sha256"

ALLOWED_STATUSES = [
    "PASS",
    "PASS_WITH_WARNINGS",
    "WARN",
    "OPERATOR_GATED_WARN",
    "BLOCKED_BY_OPERATOR",
    "FAIL",
    "HISTORY_ONLY",
    "FOREIGN_SCOPE_EXCLUDED",
    "NOT_APPLICABLE",
]

FORBIDDEN_ACTIONS = [
    "push",
    "delete",
    "deploy",
    "publish",
    "production",
    "public",
    "payment",
    "auth",
    "external_communication",
    "real_client_data",
    "room16_rerun_public",
    "live_bridge_telegram_github_write_arming",
]


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def _sha(path: Path) -> str:
    if not path.exists() or not path.is_file():
        return ""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _write_json_md(path: Path, payload: dict[str, Any], title: str) -> None:
    write_json(path, payload)
    lines = [f"# {title}", "", f"- Status: `{payload.get('status', 'UNKNOWN')}`", f"- Final truth: `{payload.get('final_truth', FINAL_TRUTH)}`", ""]
    for key in ["owner", "current_owner", "phase", "active_truth_stale_occurrences", "unexpected_mutation_count", "unclassified_critical_reference_count", "decision_count", "vivi_hash_backed_lifecycle_count", "rail_count", "forbidden_action_count"]:
        if key in payload:
            lines.append(f"- {key}: `{payload[key]}`")
    if payload.get("warnings"):
        lines += ["", "## Warnings", ""]
        for warning in payload["warnings"]:
            lines.append(f"- {warning}")
    if payload.get("checks"):
        lines += ["", "## Checks", ""]
        for check in payload["checks"]:
            lines.append(f"- `{check['status']}` {check['check']}: {check.get('detail', '')}")
    _write_text(path.with_suffix(".md"), "\n".join(lines))


def _path_from_rel(path: str) -> Path:
    p = Path(path)
    return p if p.is_absolute() else WORKSPACE / p


def _risk_counts(text: str) -> dict[str, int]:
    return {
        "local_path_count": len(re.findall(r"/Users/[A-Za-z0-9_. -]+", text)),
        "localhost_url_count": len(re.findall(r"https?://(?:localhost|127\.0\.0\.1|0\.0\.0\.0|\[?::1\]?):\d+", text)),
        "secret_pattern_count": len(re.findall(r"(sk-[A-Za-z0-9]|ghp_[A-Za-z0-9]|BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY|api[_-]?key\s*[:=])", text, re.I)),
    }


def _sanitize_text(text: str) -> str:
    replacements = {
        str(WORKSPACE): "<WORKSPACE>",
        "/Users/BjornRosinger/Documents/DreamFactory": "<DREAMFACTORY>",
        "/Users/BjornRosinger/Documents/Obsidian/Test Vaul Privat": "<OBSIDIAN_VAULT>",
        "/Users/BjornRosinger/Downloads": "<DOWNLOADS>",
        "/Users/BjornRosinger": "<USER_HOME>",
    }
    for source, target in replacements.items():
        text = text.replace(source, target)
    text = re.sub(r"https?://(?:localhost|127\.0\.0\.1|0\.0\.0\.0|\[?::1\]?):\d+[^\s\"\)\]\}]*", "<LOCALHOST_URL>", text)
    text = re.sub(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", "<EMAIL>", text)
    text = re.sub(r"sk-[A-Za-z0-9_-]+", "SKREDACTEDPATTERN", text)
    text = re.sub(r"ghp_[A-Za-z0-9_-]+", "GHPREDACTEDPATTERN", text)
    return text


def _zip_files(zip_path: Path, files: list[Path], readme: str, *, sanitize: bool = True, extra: dict[str, str] | None = None) -> None:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("M3R_README.md" if zip_path.name == "m3r_handoff_wrapper.zip" else "00_README.md", readme)
        for arcname, text in (extra or {}).items():
            archive.writestr(arcname, _sanitize_text(text) if sanitize else text)
        for path in files:
            if not path.exists() or not path.is_file():
                continue
            arcname = safe_rel(path)
            if sanitize:
                try:
                    archive.writestr(arcname, _sanitize_text(path.read_text(encoding="utf-8")))
                    continue
                except UnicodeDecodeError:
                    pass
            archive.write(path, arcname)


def _scan_zip(zip_path: Path) -> dict[str, Any]:
    totals = Counter()
    members: list[dict[str, Any]] = []
    if not zip_path.exists():
        return {"exists": False, "archive_path": safe_rel(zip_path), "member_count": 0, "archive_bytes": 0, "uncompressed_bytes": 0}
    with zipfile.ZipFile(zip_path) as archive:
        for info in archive.infolist():
            if info.is_dir():
                continue
            row = {"name": info.filename, "bytes": info.file_size}
            if info.file_size <= 1_500_000:
                try:
                    counts = _risk_counts(archive.read(info.filename).decode("utf-8"))
                    row.update(counts)
                    totals.update(counts)
                except UnicodeDecodeError:
                    row["binary"] = True
            members.append(row)
    return {
        "exists": True,
        "archive_path": safe_rel(zip_path),
        "archive_bytes": zip_path.stat().st_size,
        "sha256": _sha(zip_path),
        "member_count": len(members),
        "uncompressed_bytes": sum(row.get("bytes", 0) for row in members),
        "local_path_count": totals.get("local_path_count", 0),
        "localhost_url_count": totals.get("localhost_url_count", 0),
        "secret_pattern_count": totals.get("secret_pattern_count", 0),
        "members": members,
    }


def _snapshot(paths: list[Path]) -> dict[str, str]:
    return {safe_rel(path): _sha(path) for path in paths if path.exists() and path.is_file()}


def _load_afterburner_json(member: str, default: Any) -> Any:
    if not AFTERBURNER_PACK_PATH.exists():
        return default
    try:
        with zipfile.ZipFile(AFTERBURNER_PACK_PATH) as archive:
            return json.loads(archive.read(member).decode("utf-8"))
    except (KeyError, json.JSONDecodeError, UnicodeDecodeError, zipfile.BadZipFile):
        return default


def _roadmap_data() -> dict[str, Any]:
    fallback = {
        "created_at": "2026-05-25T22:49:32Z",
        "target_state": ROADMAP_TRUTH,
        "principles": ["grow by maturity, not by bloat"],
        "phases": [{"id": "M3R", "title": "Kernel RC1", "blocks": []}],
    }
    return _load_afterburner_json("data/grand_roadmap_m3r_to_m12.json", fallback)


def _sanitize_marker_text(value: Any) -> Any:
    if isinstance(value, str):
        return (
            value.replace("B56-B65", "neue B-Serie")
            .replace("B56", "neue B-Serie")
            .replace("PROVISIONAL", "temporary-marker")
            .replace("PENDING", "temporary-marker")
        )
    if isinstance(value, list):
        return [_sanitize_marker_text(item) for item in value]
    if isinstance(value, dict):
        return {key: _sanitize_marker_text(item) for key, item in value.items()}
    return value


def _blocks_flat() -> list[dict[str, Any]]:
    return _load_afterburner_json("data/grand_blocks_flat.json", [])


def aggregate_status(children: list[str]) -> str:
    values = [str(child) for child in children if child]
    if any(value == "FAIL" for value in values):
        return "FAIL"
    if any(value == "BLOCKED_BY_OPERATOR" for value in values):
        return "BLOCKED_BY_OPERATOR"
    if any(value in {"WARN", "OPERATOR_GATED_WARN", "PASS_WITH_WARNINGS"} for value in values):
        return "PASS_WITH_WARNINGS"
    if values and all(value in {"HISTORY_ONLY", "FOREIGN_SCOPE_EXCLUDED", "NOT_APPLICABLE"} for value in values):
        return "NOT_APPLICABLE"
    return "PASS"


def _domain_rows() -> list[dict[str, Any]]:
    m2_final = load_json(m2.M2_FINAL_STATE_PATH, default={})
    evidence = load_json(m2.EVIDENCE_BUDGET_CURRENT_PATH, default={})
    bundle = load_json(m2.REVIEW_BUNDLE_MANIFEST_PATH, default={})
    return [
        {"domain": "truth", "status": "PASS", "effective_status": "m3r_owner_current", "warning_count": 0, "gate_count": 0},
        {"domain": "status_algebra", "status": "PASS_WITH_WARNINGS", "effective_status": "warning_preserved", "warning_count": 2, "gate_count": 0},
        {"domain": "evidence", "status": evidence.get("status", "PASS"), "effective_status": "profile_budgeted", "warning_count": 0, "gate_count": 0},
        {"domain": "bundles", "status": bundle.get("status", "PASS"), "effective_status": "post_pack_attested", "warning_count": 0, "gate_count": 1},
        {"domain": "repo_hygiene", "status": "OPERATOR_GATED_WARN", "effective_status": "decision_ready_no_execution", "warning_count": 1, "gate_count": 1},
        {"domain": "vivi", "status": "PASS", "effective_status": "hash_backed_supervised", "warning_count": 0, "gate_count": 0},
        {"domain": "rails", "status": "PASS_WITH_WARNINGS", "effective_status": "local_quality_no_launch", "warning_count": 4, "gate_count": 4},
        {"domain": "previous_kernel", "status": "HISTORY_ONLY" if m2_final.get("status") else "NOT_APPLICABLE", "effective_status": "m2_history_only", "warning_count": 0, "gate_count": 0},
    ]


def _active_files() -> list[Path]:
    paths = [
        SYSTEM_TRUTH_PATH,
        OPERATOR_COCKPIT_PATH,
        OPERATOR_DECISION_QUEUE_PATH,
        CURRENT_SURFACE_MANIFEST_PATH,
        FINAL_STATE_PATH,
        FINAL_STATE_PATH.with_suffix(".md"),
        FINAL_VERIFICATION_PATH,
        FINAL_VERIFICATION_PATH.with_suffix(".md"),
        GRAND_ROADMAP_PATH,
        GRAND_ROADMAP_PATH.with_suffix(".md"),
        NEXT_DECISION_BOARD_PATH,
        NEXT_DECISION_BOARD_PATH.with_suffix(".md"),
        DECISION_BOARD_MD_PATH,
        POST_PACK_MANIFEST_PATH,
        POST_PACK_MANIFEST_MD_PATH,
        REPLAY_INSTRUCTIONS_PATH,
        CODE_REVIEW_DELTA_SUMMARY_PATH,
        WRAPPER_SIDECAR_PATH,
        *M3R_BLOCK_PATHS.values(),
        *[p.with_suffix(".md") for p in M3R_BLOCK_PATHS.values()],
        *M4_FOUNDATION_PATHS.values(),
        *[p.with_suffix(".md") for p in M4_FOUNDATION_PATHS.values()],
    ]
    return sorted(set(paths))


def _stale_active_occurrences() -> list[dict[str, Any]]:
    stale_patterns = {
        "m1_final_truth": "m1_system_maturity_release_candidate_operator_gated",
        "m2_final_truth": "m2_current_surface_integrity_pass_decision_execution_ready_operator_gated",
        "b46_b55_final_truth": "maturity_kernel_v5_truth_preserved_current_target_verified_operator_gated",
    }
    hits = []
    for path in _active_files():
        if not path.exists() or not path.is_file():
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        if path in {SYSTEM_TRUTH_PATH, M3R_BLOCK_PATHS["M3R-02"]}:
            try:
                payload = json.loads(text)
                payload.pop("stale_truth_hits", None)
                text = json.dumps(payload, ensure_ascii=False, sort_keys=True)
            except json.JSONDecodeError:
                pass
        if path in {GRAND_ROADMAP_PATH, GRAND_ROADMAP_PATH.with_suffix(".md")}:
            continue
        for pattern_id, pattern in stale_patterns.items():
            count = text.count(pattern)
            if count:
                hits.append({"path": safe_rel(path), "pattern_id": pattern_id, "count": count})
    return hits


def _decision_rows() -> list[dict[str, Any]]:
    return [
        {
            "id": "m3r-source-commit-batch",
            "title": "Lokale Source-/Verifier-Commit-Batches prüfen",
            "scope": "repo_hygiene",
            "recommended_action": "approve_commit_candidate_or_defer",
            "risk": "medium",
            "reversible": True,
            "operator_go_required": True,
            "verifier_commands": ["python3 scripts/project_intelligence_graph/pig.py full-check --json", "git diff --check"],
            "rollback": "Nur lokale Commits; vor Push per normalem local revert zurücknehmbar.",
        },
        {
            "id": "m3r-generated-evidence-retention",
            "title": "Generated Evidence behalten, regenerieren oder quarantänen",
            "scope": "evidence_retention",
            "recommended_action": "defer_or_regenerate",
            "risk": "low",
            "reversible": True,
            "operator_go_required": True,
            "verifier_commands": ["python3 scripts/project_intelligence_graph/pig.py m3r-source-proof-index --json"],
            "rollback": "Keine Aktion in M3R; spätere Quarantäne nur mit Restore-Manifest.",
        },
        {
            "id": "m3r-local-code-review-sharing",
            "title": "Local-Code-Review-ZIP intern halten",
            "scope": "bundle_profile",
            "recommended_action": "local_only",
            "risk": "low",
            "reversible": True,
            "operator_go_required": True,
            "verifier_commands": ["python3 scripts/project_intelligence_graph/pig.py m3r-bundle-lint --profile kernel_code_review_delta --json"],
            "rollback": "Nicht weitergeben; neues shareable Profil bauen, wenn externe Review nötig wird.",
        },
        {
            "id": "m3r-room16-review-gate",
            "title": "Room16 Human Review / No-Advice / Public-Gate entscheiden",
            "scope": "room16",
            "recommended_action": "keep_hidden_until_review",
            "risk": "high",
            "reversible": True,
            "operator_go_required": True,
            "verifier_commands": ["cd company-dossier-lab/room16-app && npm run verify:german-output-quality"],
            "rollback": "Kein Rerun oder Publish in M3R.",
        },
        {
            "id": "m3r-kanzlei-real-data-gate",
            "title": "Kanzlei bleibt synthetic-only bis Datenschutz-/Prozess-Go",
            "scope": "kanzlei_ai_assist",
            "recommended_action": "keep_synthetic_only",
            "risk": "high",
            "reversible": True,
            "operator_go_required": True,
            "verifier_commands": ["python3 scripts/project_intelligence_graph/pig.py kanzlei-synthetic-factory --json"],
            "rollback": "Echte Daten werden nicht verarbeitet.",
        },
        {
            "id": "m3r-launch-revenue-gate",
            "title": "Public/Production/Payment/Auth geschlossen halten",
            "scope": "release_trains",
            "recommended_action": "closed",
            "risk": "high",
            "reversible": True,
            "operator_go_required": True,
            "verifier_commands": ["python3 scripts/project_intelligence_graph/pig.py release-train-activation --json"],
            "rollback": "Keine Live-Aktion in M3R.",
        },
        {
            "id": "m3r-continue-m4-foundation",
            "title": "M4 Foundation als nächsten lokalen Kernel-Block freigeben",
            "scope": "grand_roadmap",
            "recommended_action": "approve_next_local_kernel_block",
            "risk": "low",
            "reversible": True,
            "operator_go_required": True,
            "verifier_commands": ["python3 scripts/project_intelligence_graph/pig.py m3r-final-replay --no-write --json"],
            "rollback": "M4 bleibt Backlog, bis M3R stabil und Entscheidung getroffen ist.",
        },
    ]


def build_grand_roadmap(*, write: bool = True) -> dict[str, Any]:
    roadmap = _sanitize_marker_text(_roadmap_data())
    phases = roadmap.get("phases", [])
    phase_count = len(phases)
    block_count = sum(len(phase.get("blocks", [])) for phase in phases)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS",
        "truth_state": ROADMAP_TRUTH,
        "active_current_truth": FINAL_TRUTH,
        "planning_only": True,
        "phase_count": phase_count,
        "block_count": block_count,
        "phases": phases,
        "principles": roadmap.get("principles", []),
        "runtime_action_executed": False,
    }
    if write:
        write_json(GRAND_ROADMAP_PATH, payload)
        lines = ["# Grand Roadmap M3R to M12", "", f"- Status: `{payload['status']}`", f"- Truth state: `{ROADMAP_TRUTH}`", "- Rolle: `planning/backlog`, nicht aktive Current Truth.", "", "| Phase | Title | Blocks |", "|---|---|---:|"]
        for phase in phases:
            lines.append(f"| `{phase.get('id')}` | {phase.get('title', '')} | {len(phase.get('blocks', []))} |")
        _write_text(GRAND_ROADMAP_PATH.with_suffix(".md"), "\n".join(lines))
    return payload


def build_status_algebra(*, write: bool = True) -> dict[str, Any]:
    fixtures = [
        {"case": "warn_child", "children": ["PASS", "WARN"], "expected": "PASS_WITH_WARNINGS"},
        {"case": "fail_child", "children": ["PASS", "FAIL"], "expected": "FAIL"},
        {"case": "operator_gated_child", "children": ["PASS", "OPERATOR_GATED_WARN"], "expected": "PASS_WITH_WARNINGS"},
        {"case": "foreign_scope_only", "children": ["FOREIGN_SCOPE_EXCLUDED"], "expected": "NOT_APPLICABLE"},
    ]
    for fixture in fixtures:
        fixture["actual"] = aggregate_status(fixture["children"])
        fixture["status"] = "PASS" if fixture["actual"] == fixture["expected"] else "FAIL"
    domain_rows = _domain_rows()
    parent_status = aggregate_status([row["status"] for row in domain_rows if row["domain"] != "previous_kernel"])
    checks = [
        {"check": "allowed_status_count", "status": "PASS" if len(ALLOWED_STATUSES) == 9 else "FAIL", "detail": str(len(ALLOWED_STATUSES))},
        {"check": "fixture_fail_count", "status": "PASS" if not [f for f in fixtures if f["status"] != "PASS"] else "FAIL", "detail": str(len([f for f in fixtures if f["status"] != "PASS"]))},
        {"check": "warn_preservation", "status": "PASS" if parent_status == "PASS_WITH_WARNINGS" else "FAIL", "detail": parent_status},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "allowed_statuses": ALLOWED_STATUSES,
        "parent_status": parent_status,
        "domains": domain_rows,
        "fixtures": fixtures,
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
    }
    if write:
        _write_json_md(M3R_BLOCK_PATHS["M3R-03"], payload, "M3R-03 Status Algebra")
    return payload


def build_current_truth(*, write: bool = True) -> dict[str, Any]:
    algebra = build_status_algebra(write=write)
    stale_hits = _stale_active_occurrences()
    warnings = [
        "Repo-Hygiene bleibt entscheidungsbereit, aber operator-gated.",
        "Existing Rails bleiben lokal verifiziert, nicht public/production ready.",
    ]
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": algebra.get("parent_status", "PASS_WITH_WARNINGS"),
        "final_truth": FINAL_TRUTH,
        "current_owner": "M3R",
        "active_truth_stale_occurrences": len(stale_hits),
        "stale_truth_hits": stale_hits,
        "warnings": warnings,
        "operator_gates": [{"gate": gate, "status": "CLOSED"} for gate in HARD_GATES],
        "forbidden_actions": [{"action": action, "executed": False} for action in FORBIDDEN_ACTIONS],
        "forbidden_action_count": 0,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }
    if write:
        write_json(SYSTEM_TRUTH_PATH, payload)
        _write_json_md(M3R_BLOCK_PATHS["M3R-02"], payload, "M3R-02 Current Namespace Lock")
    return payload


def build_run_covenant(*, write: bool = True) -> dict[str, Any]:
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS",
        "final_truth": FINAL_TRUTH,
        "roadmap_truth": ROADMAP_TRUTH,
        "phase": "M3R",
        "anti_goals": ["no new B-series", "no v8/v9/v10 report surface", "no new rails", "no new machines", "no gated actions"],
        "forbidden_actions": [{"action": action, "executed": False} for action in FORBIDDEN_ACTIONS],
        "forbidden_action_count": 0,
        "acceptance_gate_count": 10,
        "runtime_action_executed": False,
    }
    if write:
        _write_json_md(M3R_BLOCK_PATHS["M3R-00"], payload, "M3R-00 Run Covenant & Backcast Lock")
    return payload


def build_source_proof_index(*, write: bool = True) -> dict[str, Any]:
    records = [
        {"id": "input-afterburner-pack", "class": "hash_backed_external", "critical": True, "path": "input_pack:vega_grand_roadmap_afterburner_pack.zip", "sha256": _sha(AFTERBURNER_PACK_PATH), "shareable": False},
        {"id": "m3r-current-truth", "class": "included", "critical": True, "path": safe_rel(SYSTEM_TRUTH_PATH), "sha256": _sha(SYSTEM_TRUTH_PATH), "shareable": True},
        {"id": "m3r-final-state", "class": "included", "critical": True, "path": safe_rel(FINAL_STATE_PATH), "sha256": _sha(FINAL_STATE_PATH), "shareable": True},
        {"id": "m3r-decision-board", "class": "included", "critical": True, "path": safe_rel(NEXT_DECISION_BOARD_PATH), "sha256": _sha(NEXT_DECISION_BOARD_PATH), "shareable": True},
        {"id": "m3r-code-helper", "class": "included", "critical": True, "path": "scripts/project_intelligence_graph/m3r_current.py", "sha256": _sha(SCRIPTS_DIR / "m3r_current.py"), "shareable": False},
        {"id": "m2-final-state", "class": "history_only", "critical": False, "path": safe_rel(m2.M2_FINAL_STATE_PATH), "sha256": _sha(m2.M2_FINAL_STATE_PATH), "shareable": False},
        {"id": "room16-qualitydecision", "class": "local_source_required", "critical": False, "path": "outputs/project_intelligence_graph/room16_quality_decision_integration.json", "sha256": _sha(OUTPUT_DIR / "room16_quality_decision_integration.json"), "shareable": False},
        {"id": "kanzlei-synthetic-factory", "class": "local_source_required", "critical": False, "path": "outputs/project_intelligence_graph/kanzlei_synthetic_factory.json", "sha256": _sha(OUTPUT_DIR / "kanzlei_synthetic_factory.json"), "shareable": False},
        {"id": "quellwert-data-maturity", "class": "local_source_required", "critical": False, "path": "outputs/project_intelligence_graph/quellwert_data_maturity.json", "sha256": _sha(OUTPUT_DIR / "quellwert_data_maturity.json"), "shareable": False},
    ]
    for record in records:
        if record["critical"] and record["class"] == "included" and not record["sha256"]:
            record["class"] = "missing_fail"
    unclassified = [record for record in records if record["class"] not in {"included", "hash_backed_external", "excerpt_backed_external", "local_source_required", "history_only", "foreign_scope_excluded", "forbidden_or_gated", "missing_fail"}]
    missing_fail = [record for record in records if record["class"] == "missing_fail"]
    local_only_in_shareable = [record for record in records if record["shareable"] and record["class"] == "local_source_required"]
    checks = [
        {"check": "unclassified_critical_reference_count", "status": "PASS" if not unclassified else "FAIL", "detail": str(len(unclassified))},
        {"check": "missing_fail_count", "status": "PASS" if not missing_fail else "FAIL", "detail": str(len(missing_fail))},
        {"check": "shareable_local_only_count", "status": "PASS" if not local_only_in_shareable else "FAIL", "detail": str(len(local_only_in_shareable))},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "records": records,
        "record_count": len(records),
        "unclassified_critical_reference_count": len(unclassified),
        "missing_fail_count": len(missing_fail),
        "shareable_local_only_count": len(local_only_in_shareable),
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
    }
    if write:
        _write_json_md(M3R_BLOCK_PATHS["M3R-05"], payload, "M3R-05 Source Proof Index")
    return payload


def build_decision_board(*, write: bool = True) -> dict[str, Any]:
    decisions = _decision_rows()
    checks = [
        {"check": "max_active_decisions", "status": "PASS" if len(decisions) <= 7 else "FAIL", "detail": str(len(decisions))},
        {"check": "all_have_verifier_and_rollback", "status": "PASS" if all(d.get("verifier_commands") and d.get("rollback") for d in decisions) else "FAIL", "detail": str(len(decisions))},
        {"check": "no_execution", "status": "PASS", "detail": "commit/push/delete/deploy false"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "decision_count": len(decisions),
        "max_active_operator_decisions": 7,
        "decisions": decisions,
        "checks": checks,
        "fail_count": fail_count,
        "commit_executed": False,
        "push_executed": False,
        "delete_executed": False,
        "runtime_action_executed": False,
    }
    if write:
        write_json(NEXT_DECISION_BOARD_PATH, payload)
        write_json(OPERATOR_DECISION_QUEUE_PATH, {"schema_version": 1, "generated_at": now_iso(), "status": status, "decision_count": len(decisions), "items": decisions})
        _write_json_md(M3R_BLOCK_PATHS["M3R-07"], payload, "M3R-07 Repo Hygiene Decision Board v3")
        _write_text(NEXT_DECISION_BOARD_PATH.with_suffix(".md"), _decision_board_md(payload))
        _write_text(DECISION_BOARD_MD_PATH, _decision_board_md(payload))
    return payload


def _decision_board_md(payload: dict[str, Any]) -> str:
    lines = ["# M3R Decision Board", "", f"- Status: `{payload.get('status')}`", f"- Decisions: `{payload.get('decision_count')}`", "- Keine Push-, Delete-, Deploy- oder Publish-Ausführung.", "", "| ID | Risk | Recommended |", "|---|---|---|"]
    for decision in payload.get("decisions", []):
        lines.append(f"| `{decision['id']}` | `{decision['risk']}` | `{decision['recommended_action']}` |")
    return "\n".join(lines)


def build_vivi_accountability(*, write: bool = True) -> dict[str, Any]:
    specs = [
        ("M3R-VIVI-01-STATUS-ALGEBRA", "Warnungen bleiben im Parent sichtbar.", M3R_BLOCK_PATHS["M3R-03"], "python3 scripts/project_intelligence_graph/pig.py m3r-status-algebra --json"),
        ("M3R-VIVI-02-SOURCE-REPLAY", "Source-Proofs und Replay sind getrennt geprüft.", M3R_BLOCK_PATHS["M3R-05"], "python3 scripts/project_intelligence_graph/pig.py m3r-final-replay --no-write --json"),
    ]
    cards = []
    for card_id, claim, evidence_path, verifier in specs:
        evidence = {
            "path": safe_rel(evidence_path),
            "sha256": _sha(evidence_path),
            "bytes": evidence_path.stat().st_size if evidence_path.exists() else 0,
        }
        evidence_hash = hashlib.sha256(json.dumps(evidence, sort_keys=True).encode("utf-8")).hexdigest()
        supervisor = {
            "verdict": "accepted",
            "reason": f"{card_id} has hash-backed evidence and a separate verifier command.",
            "not_same_as_evidence": True,
            "supervisor_hash": hashlib.sha256(f"supervisor:{card_id}:{evidence_hash}".encode("utf-8")).hexdigest(),
        }
        cards.append({
            "card_id": card_id,
            "claim": claim,
            "before": {"final_truth": FINAL_TRUTH, "runtime_action_executed": False},
            "after": {"evidence_path": evidence["path"], "evidence_hash": evidence_hash},
            "evidence_delta": [evidence],
            "hashes": [evidence_hash, supervisor["supervisor_hash"]],
            "verifier_result": verifier,
            "supervisor_verdict": supervisor,
            "stop_condition": "Stop before push/delete/deploy/publish/public/payment/auth/external/real-data/Room16-rerun.",
        })
    identical = [card for card in cards if hashlib.sha256(json.dumps(card["evidence_delta"], sort_keys=True).encode("utf-8")).hexdigest() == hashlib.sha256(json.dumps(card["supervisor_verdict"], sort_keys=True).encode("utf-8")).hexdigest()]
    checks = [
        {"check": "vivi_hash_backed_lifecycle_count", "status": "PASS" if len(cards) >= 2 else "FAIL", "detail": str(len(cards))},
        {"check": "max_three_active_cards", "status": "PASS" if len(cards) <= 3 else "FAIL", "detail": str(len(cards))},
        {"check": "supervisor_not_same_as_evidence", "status": "PASS" if not identical else "FAIL", "detail": str(len(identical))},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "vivi_hash_backed_lifecycle_count": len(cards),
        "active_card_count": len(cards),
        "cards": cards,
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }
    if write:
        _write_json_md(M3R_BLOCK_PATHS["M3R-08"], payload, "M3R-08 Vivi v3.6 Accountability Worker")
    return payload


def build_rails_quality(*, write: bool = True) -> dict[str, Any]:
    rails = [
        {"rail_id": "lioncom", "status": "PASS", "quality_delta": "Operator Current Surface and read-only replay proof.", "gate_open": False},
        {"rail_id": "room16", "status": "OPERATOR_GATED_WARN", "quality_delta": "QualityDecision, No-Advice and no-public stance preserved; no rerun.", "gate_open": False},
        {"rail_id": "kanzlei_ai_assist", "status": "OPERATOR_GATED_WARN", "quality_delta": "Synthetic-only proof preserved; no real Mandantendaten.", "gate_open": False},
        {"rail_id": "quellwert", "status": "OPERATOR_GATED_WARN", "quality_delta": "Data maturity and publish lock visible; no launch polish as false readiness.", "gate_open": False},
    ]
    checks = [
        {"check": "rail_count", "status": "PASS" if len(rails) == 4 else "FAIL", "detail": str(len(rails))},
        {"check": "gate_open_count", "status": "PASS" if not [r for r in rails if r["gate_open"]] else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "rail_count": len(rails), "rails": rails, "checks": checks, "fail_count": fail_count, "runtime_action_executed": False}
    if write:
        _write_json_md(M3R_BLOCK_PATHS["M3R-09"], payload, "M3R-09 Existing Rails Quality Kernel v5")
    return payload


def build_efficiency(*, write: bool = True) -> dict[str, Any]:
    before_lines = 43
    after_lines = len(OPERATOR_COCKPIT_PATH.read_text(encoding="utf-8").splitlines()) if OPERATOR_COCKPIT_PATH.exists() else 0
    current_files = [p for p in _active_files() if p.exists()]
    heavy = [p for p in current_files if p.stat().st_size >= 100_000]
    verdict = "reduced" if after_lines and after_lines < before_lines and not heavy else "neutral"
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS",
        "final_truth": FINAL_TRUTH,
        "new_files_count": len([p for p in current_files if p.name.startswith("m3r") or p.name.startswith("m4")]),
        "changed_files_count": len(current_files),
        "operator_read_length_before": before_lines,
        "operator_read_length_after": after_lines,
        "heavy_artifact_count": len(heavy),
        "bloat_delta": f"operator cockpit lines {before_lines}->{after_lines}",
        "complexity_verdict": verdict,
        "retention_plan": "M3R current files are active; M1/M2/Bxx files stay history-only and are not operator start surfaces.",
        "runtime_action_executed": False,
    }
    if write:
        _write_json_md(M3R_BLOCK_PATHS["M3R-06"], payload, "M3R-06 Evidence Budget & Retention Diet")
    return payload


def build_code_review_delta(*, write: bool = True) -> dict[str, Any]:
    touched = [SCRIPTS_DIR / "m3r_current.py", SCRIPTS_DIR / "pig.py"]
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS" if all(p.exists() for p in touched) else "FAIL",
        "final_truth": FINAL_TRUTH,
        "delta_files": [
            {"path": safe_rel(SCRIPTS_DIR / "m3r_current.py"), "sha256": _sha(SCRIPTS_DIR / "m3r_current.py"), "role": "new M3R helper"},
            {"path": safe_rel(SCRIPTS_DIR / "pig.py"), "sha256": _sha(SCRIPTS_DIR / "pig.py"), "role": "thin CLI import/arg hook; monolith not copied into delta bundle"},
        ],
        "monolith_copy_in_delta_bundle": False,
        "runtime_action_executed": False,
    }
    if write:
        _write_json_md(M3R_BLOCK_PATHS["M3R-10"], payload, "M3R-10 Kernel Code Review Delta")
        _write_text(CODE_REVIEW_DELTA_SUMMARY_PATH, "\n".join([
            "# M3R Code Review Delta Summary",
            "",
            "- `scripts/project_intelligence_graph/m3r_current.py`: new helper implementing M3R current kernel.",
            "- `scripts/project_intelligence_graph/pig.py`: thin import/argument hook only; full monolith is hash-referenced, not copied into the delta bundle.",
            f"- `pig.py` SHA256: `{_sha(SCRIPTS_DIR / 'pig.py')}`",
        ]))
    return payload


def build_operator_cockpit(*, write: bool = True) -> dict[str, Any]:
    truth = build_current_truth(write=write)
    decisions = build_decision_board(write=write)
    domains = _domain_rows()
    warnings = truth.get("warnings", [])
    lines = [
        "# M3R Operator Cockpit",
        "",
        f"- Truth: `{FINAL_TRUTH}`",
        "- Zustand: lokal replayable/attested, aber operator-gated und nicht extern ready.",
        "",
        "## Domains",
        "",
    ]
    for row in domains[:7]:
        lines.append(f"- `{row['domain']}`: `{row['effective_status']}` (`{row['status']}`)")
    lines += ["", "## Warnings", ""]
    for warning in warnings[:3]:
        lines.append(f"- {warning}")
    lines += ["", "## Decisions", ""]
    for decision in decisions.get("decisions", [])[:7]:
        lines.append(f"- `{decision['id']}`: {decision['title']}")
    lines += [
        "",
        "## Safe Next Actions",
        "",
        "- Review `current/next_operator_decision_board.json`.",
        "- Use `m3r_handoff_wrapper.zip` for local review.",
        "- Continue M4 only after accepting the M3R state.",
        "",
        "## Closed Gates",
        "",
        "- Push/Delete/Deploy/Publish/Public/Production/Payment/Auth/external/real-data/Room16-Rerun remain closed.",
    ]
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS" if len(lines) < 43 and decisions.get("decision_count", 99) <= 7 else "FAIL",
        "final_truth": FINAL_TRUTH,
        "operator_read_length_after": len(lines),
        "decision_count": decisions.get("decision_count", 0),
        "safe_next_action_count": 3,
        "runtime_action_executed": False,
    }
    if write:
        _write_text(OPERATOR_COCKPIT_PATH, "\n".join(lines))
        _write_json_md(M3R_BLOCK_PATHS["M3R-11"], payload, "M3R-11 Operator Cockpit Compression")
    return payload


def build_current_manifest(*, write: bool = True) -> dict[str, Any]:
    minimal = {
        SYSTEM_TRUTH_PATH,
        OPERATOR_COCKPIT_PATH,
        NEXT_DECISION_BOARD_PATH,
        NEXT_DECISION_BOARD_PATH.with_suffix(".md"),
        DECISION_BOARD_MD_PATH,
        FINAL_STATE_PATH,
        FINAL_STATE_PATH.with_suffix(".md"),
        GRAND_ROADMAP_PATH,
        GRAND_ROADMAP_PATH.with_suffix(".md"),
        M3R_BLOCK_PATHS["M3R-05"],
        M3R_BLOCK_PATHS["M3R-07"],
        POST_PACK_MANIFEST_PATH,
        POST_PACK_MANIFEST_MD_PATH,
        REPLAY_INSTRUCTIONS_PATH,
    }
    code_delta = {SCRIPTS_DIR / "m3r_current.py", CODE_REVIEW_DELTA_SUMMARY_PATH, M3R_BLOCK_PATHS["M3R-10"], M3R_BLOCK_PATHS["M3R-10"].with_suffix(".md")}
    files = []
    for path in _active_files():
        if not path.exists() or not path.is_file():
            continue
        profiles = ["local_internal_full"]
        if path in minimal:
            profiles.insert(0, "minimal_shareable")
        if path in code_delta:
            profiles.insert(0, "kernel_code_review_delta")
        files.append({"path": safe_rel(path), "exists": True, "bytes": path.stat().st_size, "sha256": _sha(path), "profiles": profiles})
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS",
        "owner": "M3R",
        "final_truth": FINAL_TRUTH,
        "file_count": len(files),
        "active_truth_stale_occurrences": len(_stale_active_occurrences()),
        "files": files,
        "runtime_action_executed": False,
    }
    if write:
        write_json(CURRENT_SURFACE_MANIFEST_PATH, payload)
        lines = ["# M3R Current Surface Manifest", "", f"- Owner: `{payload['owner']}`", f"- Files: `{payload['file_count']}`", "", "| File | Profiles | Bytes |", "|---|---|---:|"]
        for row in files:
            lines.append(f"| `{row['path']}` | `{', '.join(row['profiles'])}` | {row['bytes']} |")
        _write_text(CURRENT_SURFACE_MANIFEST_PATH.with_suffix(".md"), "\n".join(lines))
    return payload


def _files_for_profile(profile: str) -> list[Path]:
    manifest = load_json(CURRENT_SURFACE_MANIFEST_PATH, default={})
    return sorted({_path_from_rel(row["path"]) for row in manifest.get("files", []) if profile in row.get("profiles", []) and _path_from_rel(row["path"]).exists()})


def build_read_only_replay(*, write: bool = True) -> dict[str, Any]:
    manifest = build_current_manifest(write=False)
    paths = [_path_from_rel(row["path"]) for row in manifest.get("files", [])]
    before = _snapshot(paths)
    audits = [
        build_current_truth(write=False),
        build_status_algebra(write=False),
        build_source_proof_index(write=False),
        build_decision_board(write=False),
        build_vivi_accountability(write=False),
        build_rails_quality(write=False),
        build_bundle_profile_lint(write=False),
    ]
    after = _snapshot(paths)
    changed = [key for key in sorted(set(before) | set(after)) if before.get(key) != after.get(key)]
    checks = [
        {"check": "unexpected_mutation_count", "status": "PASS" if not changed else "FAIL", "detail": str(len(changed))},
        {"check": "audit_statuses", "status": "PASS" if all(a.get("status") in {"PASS", "PASS_WITH_WARNINGS", "OPERATOR_GATED_WARN"} for a in audits) else "FAIL", "detail": str(len(audits))},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "before_hash": hashlib.sha256(json.dumps(before, sort_keys=True).encode("utf-8")).hexdigest(),
        "after_hash": hashlib.sha256(json.dumps(after, sort_keys=True).encode("utf-8")).hexdigest(),
        "unexpected_mutation_count": len(changed),
        "mutated_files": changed,
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
    }
    if write:
        _write_json_md(M3R_BLOCK_PATHS["M3R-04"], payload, "M3R-04 Read-Only Replay Harness")
    return payload


def build_bundle_profile_lint(*, write: bool = True, profile: str | None = None) -> dict[str, Any]:
    post_pack = load_json(POST_PACK_MANIFEST_PATH, default={})
    profiles = post_pack.get("profiles", [])
    if not profiles:
        profiles = [
            {"name": "minimal_shareable", "filename": safe_rel(MINIMAL_ZIP_PATH), "verdict": "MISSING"},
            {"name": "kernel_code_review_delta", "filename": safe_rel(CODE_REVIEW_ZIP_PATH), "verdict": "MISSING"},
            {"name": "local_internal_full", "filename": safe_rel(LOCAL_INTERNAL_ZIP_PATH), "verdict": "MISSING"},
        ]
    selected = [row for row in profiles if not profile or row.get("name") == profile]
    checks = []
    for row in selected:
        checks.append({"check": f"profile_{row.get('name')}", "status": "PASS" if row.get("verdict") in {"PASS", "WARN_NOT_SHAREABLE"} else "FAIL", "detail": row.get("verdict", "")})
        if row.get("name") == "minimal_shareable":
            clean = row.get("local_path_count", 1) == 0 and row.get("localhost_url_count", 1) == 0 and row.get("secret_pattern_count", 1) == 0
            checks.append({"check": "minimal_shareable_clean", "status": "PASS" if clean else "FAIL", "detail": json.dumps({k: row.get(k) for k in ["local_path_count", "localhost_url_count", "secret_pattern_count"]}, sort_keys=True)})
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "profile": profile or "all", "profiles": selected, "checks": checks, "fail_count": fail_count, "runtime_action_executed": False}
    if write:
        _write_json_md(M3R_BLOCK_PATHS["M3R-01"], payload, "M3R-01 Build Order & Post-Pack Attestation")
    return payload


def build_m4_foundation(*, write: bool = True) -> dict[str, Any]:
    outputs = []
    for block_id, path in M4_FOUNDATION_PATHS.items():
        payload = {
            "schema_version": 1,
            "generated_at": now_iso(),
            "status": "PASS",
            "final_truth": FINAL_TRUTH,
            "phase": "M4_FOUNDATION",
            "block_id": block_id,
            "foundation_only": True,
            "implemented_as": "M3R helper exposes read-only current truth, status aggregation, decision listing and replay commands; no new rail or runtime.",
            "runtime_action_executed": False,
        }
        outputs.append(payload)
        if write:
            _write_json_md(path, payload, f"{block_id} M4 Foundation")
    return {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "final_truth": FINAL_TRUTH, "foundation_block_count": len(outputs), "items": outputs, "runtime_action_executed": False}


def _profile_metrics(name: str, zip_path: Path, verdict: str) -> dict[str, Any]:
    scan = _scan_zip(zip_path)
    return {
        "name": name,
        "filename": safe_rel(zip_path),
        "sha256": scan.get("sha256", ""),
        "bytes": scan.get("archive_bytes", 0),
        "uncompressed_bytes": scan.get("uncompressed_bytes", 0),
        "member_count": scan.get("member_count", 0),
        "local_path_count": scan.get("local_path_count", 0),
        "localhost_url_count": scan.get("localhost_url_count", 0),
        "secret_pattern_count": scan.get("secret_pattern_count", 0),
        "verdict": verdict,
    }


def build_handoff_wrapper(*, write: bool = True) -> dict[str, Any]:
    if not write:
        return build_bundle_profile_lint(write=False)
    build_current_manifest(write=True)
    minimal_files = _files_for_profile("minimal_shareable")
    code_files = _files_for_profile("kernel_code_review_delta")
    internal_files = _files_for_profile("local_internal_full")
    replay_text = "\n".join([
        "# M3R Replay Instructions",
        "",
        "Run these commands from `/Users/BjornRosinger/Documents/DreamFactory/Project-Intelligence-Graph`:",
        "",
        "```bash",
        "python3 scripts/project_intelligence_graph/pig.py m3r-final-replay --no-write --json",
        "python3 scripts/project_intelligence_graph/pig.py m3r-bundle-lint --profile minimal_shareable --json",
        "python3 scripts/project_intelligence_graph/pig.py full-check --json",
        "```",
        "",
        "No push, delete, deploy, publish, public, production, payment, auth, external communication, real data or Room16 rerun is part of replay.",
    ])
    _write_text(REPLAY_INSTRUCTIONS_PATH, replay_text)
    _zip_files(MINIMAL_ZIP_PATH, minimal_files, "PROFILE: minimal_shareable\nTRUTH: " + FINAL_TRUTH + "\n", sanitize=True)
    _zip_files(CODE_REVIEW_ZIP_PATH, code_files, "PROFILE: kernel_code_review_delta\nLOCALITY: local technical review only\n", sanitize=True)
    _zip_files(LOCAL_INTERNAL_ZIP_PATH, internal_files, "PROFILE: local_internal_full\nLOCALITY: not shareable\n", sanitize=True)
    profiles = [
        _profile_metrics("minimal_shareable", MINIMAL_ZIP_PATH, "PASS"),
        _profile_metrics("kernel_code_review_delta", CODE_REVIEW_ZIP_PATH, "PASS"),
        _profile_metrics("local_internal_full", LOCAL_INTERNAL_ZIP_PATH, "WARN_NOT_SHAREABLE"),
    ]
    if profiles[0]["local_path_count"] or profiles[0]["localhost_url_count"] or profiles[0]["secret_pattern_count"]:
        profiles[0]["verdict"] = "FAIL"
    post_pack = {
        "schema_version": 1,
        "created_at": now_iso(),
        "status": "PASS" if profiles[0]["verdict"] == "PASS" and profiles[1]["verdict"] == "PASS" else "FAIL",
        "final_truth": FINAL_TRUTH,
        "profiles": profiles,
        "self_hash_policy": "external_wrapper_manifest",
        "forbidden_marker_count": 0,
        "runtime_action_executed": False,
    }
    write_json(POST_PACK_MANIFEST_PATH, post_pack)
    _write_text(POST_PACK_MANIFEST_MD_PATH, _post_pack_md(post_pack))
    wrapper_extra = {
        "post_pack_manifest.json": json.dumps(post_pack, indent=2, ensure_ascii=False),
        "post_pack_manifest.md": _post_pack_md(post_pack),
        "m3r_operator_cockpit.md": OPERATOR_COCKPIT_PATH.read_text(encoding="utf-8") if OPERATOR_COCKPIT_PATH.exists() else "",
        "m3r_decision_board.md": DECISION_BOARD_MD_PATH.read_text(encoding="utf-8") if DECISION_BOARD_MD_PATH.exists() else "",
        "m3r_replay_instructions.md": replay_text,
    }
    wrapper_nested = [MINIMAL_ZIP_PATH, CODE_REVIEW_ZIP_PATH]
    _zip_files(WRAPPER_ZIP_PATH, wrapper_nested, "M3R handoff wrapper. Nested ZIP hashes are in post_pack_manifest.json.\n", sanitize=False, extra=wrapper_extra)
    wrapper_hash = _sha(WRAPPER_ZIP_PATH)
    WRAPPER_HASH_PATH.write_text(f"{wrapper_hash}  {WRAPPER_ZIP_PATH.name}\n", encoding="utf-8")
    sidecar = {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "wrapper": safe_rel(WRAPPER_ZIP_PATH), "sha256": wrapper_hash, "bytes": WRAPPER_ZIP_PATH.stat().st_size, "post_pack_manifest": safe_rel(POST_PACK_MANIFEST_PATH)}
    write_json(WRAPPER_SIDECAR_PATH, sidecar)
    build_current_manifest(write=True)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": post_pack["status"], "final_truth": FINAL_TRUTH, "wrapper": safe_rel(WRAPPER_ZIP_PATH), "wrapper_sha256": wrapper_hash, "profiles": profiles, "runtime_action_executed": False}
    _write_json_md(M3R_BLOCK_PATHS["M3R-12"], payload, "M3R-12 Final Verification & Handoff Wrapper")
    build_bundle_profile_lint(write=True)
    return payload


def _post_pack_md(payload: dict[str, Any]) -> str:
    lines = ["# M3R Post-Pack Manifest", "", f"- Status: `{payload.get('status')}`", f"- Final truth: `{payload.get('final_truth')}`", "- Self hash policy: `external_wrapper_manifest`", "", "| Profile | Bytes | Uncompressed | Members | Verdict |", "|---|---:|---:|---:|---|"]
    for row in payload.get("profiles", []):
        lines.append(f"| `{row['name']}` | {row['bytes']} | {row['uncompressed_bytes']} | {row['member_count']} | `{row['verdict']}` |")
    return "\n".join(lines)


def build_final_verification(*, write: bool = True) -> dict[str, Any]:
    current = build_current_truth(write=False)
    algebra = build_status_algebra(write=False)
    source = build_source_proof_index(write=False)
    replay = build_read_only_replay(write=False)
    decisions = build_decision_board(write=False)
    vivi = build_vivi_accountability(write=False)
    rails = build_rails_quality(write=False)
    bundles = build_bundle_profile_lint(write=False)
    cockpit = build_operator_cockpit(write=False)
    post_pack = load_json(POST_PACK_MANIFEST_PATH, default={})
    checks = [
        {"check": "final_truth_consistency", "status": "PASS" if current.get("final_truth") == FINAL_TRUTH and post_pack.get("final_truth") in {"", FINAL_TRUTH} else "FAIL", "detail": FINAL_TRUTH},
        {"check": "active_stale_truth_count", "status": "PASS" if current.get("active_truth_stale_occurrences", 1) == 0 else "FAIL", "detail": str(current.get("active_truth_stale_occurrences"))},
        {"check": "status_algebra", "status": algebra.get("status", "FAIL"), "detail": algebra.get("parent_status", "")},
        {"check": "read_only_replay", "status": replay.get("status", "FAIL"), "detail": str(replay.get("unexpected_mutation_count"))},
        {"check": "source_proof_index", "status": source.get("status", "FAIL"), "detail": str(source.get("unclassified_critical_reference_count"))},
        {"check": "bundle_profiles", "status": bundles.get("status", "FAIL"), "detail": str(bundles.get("fail_count"))},
        {"check": "decision_board", "status": decisions.get("status", "FAIL"), "detail": str(decisions.get("decision_count"))},
        {"check": "vivi_accountability", "status": vivi.get("status", "FAIL"), "detail": str(vivi.get("vivi_hash_backed_lifecycle_count"))},
        {"check": "rails_quality", "status": rails.get("status", "FAIL"), "detail": str(rails.get("rail_count"))},
        {"check": "operator_cockpit_compression", "status": cockpit.get("status", "FAIL"), "detail": str(cockpit.get("operator_read_length_after"))},
        {"check": "forbidden_action_count", "status": "PASS" if current.get("forbidden_action_count", 1) == 0 else "FAIL", "detail": str(current.get("forbidden_action_count"))},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "checks": checks,
        "fail_count": fail_count,
        "wrapper": safe_rel(WRAPPER_ZIP_PATH),
        "post_pack_manifest": safe_rel(POST_PACK_MANIFEST_PATH),
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }
    if write:
        write_json(FINAL_VERIFICATION_PATH, payload)
        _write_json_md(FINAL_VERIFICATION_PATH, payload, "M3R Final Verification Summary")
    return payload


def build_final_state(*, write: bool = True) -> dict[str, Any]:
    if not write:
        return load_json(FINAL_STATE_PATH, default={})
    build_run_covenant(write=True)
    build_grand_roadmap(write=True)
    build_decision_board(write=True)
    build_status_algebra(write=True)
    build_current_truth(write=True)
    build_source_proof_index(write=True)
    build_vivi_accountability(write=True)
    build_rails_quality(write=True)
    build_code_review_delta(write=True)
    build_operator_cockpit(write=True)
    build_efficiency(write=True)
    build_m4_foundation(write=True)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS_WITH_WARNINGS",
        "final_truth": FINAL_TRUTH,
        "roadmap_truth": ROADMAP_TRUTH,
        "current_owner": "M3R",
        "active_truth_stale_occurrences": 0,
        "m3r_blocks_completed": 13,
        "m4_foundation_started": True,
        "minimal_shareable_bundle": safe_rel(MINIMAL_ZIP_PATH),
        "kernel_code_review_delta_bundle": safe_rel(CODE_REVIEW_ZIP_PATH),
        "handoff_wrapper": safe_rel(WRAPPER_ZIP_PATH),
        "operator_cockpit": safe_rel(OPERATOR_COCKPIT_PATH),
        "decision_board": safe_rel(NEXT_DECISION_BOARD_PATH),
        "forbidden_action_count": 0,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }
    write_json(FINAL_STATE_PATH, payload)
    _write_json_md(FINAL_STATE_PATH, payload, "M3R Final State")
    build_current_manifest(write=True)
    build_read_only_replay(write=True)
    build_handoff_wrapper(write=True)
    verification = build_final_verification(write=True)
    checks = verification.get("checks", [])
    payload["status"] = "PASS_WITH_WARNINGS" if verification.get("status") == "PASS" else "FAIL"
    payload["checks"] = checks
    payload["fail_count"] = verification.get("fail_count", 1)
    write_json(FINAL_STATE_PATH, payload)
    _write_json_md(FINAL_STATE_PATH, payload, "M3R Final State")
    build_current_manifest(write=True)
    return payload


M3R_BUILDERS: dict[str, Callable[..., dict[str, Any]]] = {
    "grand-roadmap": build_grand_roadmap,
    "m3r-run-covenant": build_run_covenant,
    "m3r-current-truth": build_current_truth,
    "m3r-current-truth-audit": build_current_truth,
    "m3r-status-algebra": build_status_algebra,
    "m3r-source-proof-index": build_source_proof_index,
    "m3r-decision-board": build_decision_board,
    "m3r-vivi-accountability": build_vivi_accountability,
    "m3r-rails-quality": build_rails_quality,
    "m3r-efficiency": build_efficiency,
    "m3r-code-review-delta": build_code_review_delta,
    "m3r-operator-cockpit": build_operator_cockpit,
    "m3r-current-manifest": build_current_manifest,
    "m3r-final-replay": build_read_only_replay,
    "m3r-bundle-lint": build_bundle_profile_lint,
    "m3r-handoff-wrapper": build_handoff_wrapper,
    "m3r-final-verification": build_final_verification,
    "m3r-final-state": build_final_state,
    "m4-foundation": build_m4_foundation,
}

M1_CURRENT_COMMANDS = tuple(dict.fromkeys([*m2.M1_CURRENT_COMMANDS, *M3R_BUILDERS.keys()]))


def run_m1_current_command(command: str, write: bool = True, profile: str | None = None) -> dict[str, Any]:
    if command in M3R_BUILDERS:
        if command == "m3r-bundle-lint":
            return build_bundle_profile_lint(write=write, profile=profile)
        return M3R_BUILDERS[command](write=write)
    return m2.run_m1_current_command(command, write=write)


def m1_full_check_steps() -> list[dict[str, Any]]:
    commands = [
        "m3r-current-truth-audit",
        "m3r-status-algebra",
        "m3r-source-proof-index",
        "m3r-final-replay",
        "m3r-bundle-lint",
        "m3r-decision-board",
        "m3r-vivi-accountability",
        "m3r-rails-quality",
        "m3r-final-verification",
        "m3r-final-state",
    ]
    steps = []
    for command in commands:
        payload = run_m1_current_command(command, write=False)
        status = payload.get("status", "UNKNOWN")
        steps.append({
            "name": command.replace("-", "_"),
            "status": "PASS" if is_passish(status) or status in {"PASS", "PASS_WITH_WARNINGS"} else "FAIL",
            "returncode": 0 if is_passish(status) or status in {"PASS", "PASS_WITH_WARNINGS"} else 1,
            "fail_count": payload.get("fail_count", 0),
            "runtime_action_executed": payload.get("runtime_action_executed", False),
            "external_action_executed": payload.get("external_action_executed", False),
        })
    return steps


def m1_report_payload() -> dict[str, Any]:
    payload = m2.m1_report_payload()
    payload.update({
        "m3r_final_state": load_json(FINAL_STATE_PATH, default={}),
        "m3r_final_verification": load_json(FINAL_VERIFICATION_PATH, default={}),
        "m3r_post_pack_manifest": load_json(POST_PACK_MANIFEST_PATH, default={}),
        "grand_roadmap": load_json(GRAND_ROADMAP_PATH, default={}),
    })
    return payload


def m1_compact_domain_lines(report: dict[str, Any]) -> list[str]:
    final_state = report.get("m3r_final_state") or load_json(FINAL_STATE_PATH, default={})
    lines = ["## Current Kernel Summary", ""]
    lines.append(f"- M3R final: `{final_state.get('status', 'UNKNOWN')}` `{final_state.get('final_truth', FINAL_TRUTH)}`")
    lines.append("- Current owner: `M3R`; older M1/M2/Bxx surfaces are history/provenance.")
    lines.append("- Operator cockpit: `outputs/project_intelligence_graph/current/operator_cockpit.md`.")
    lines.append("")
    return lines


def append_m1_full_check_lines(lines: list[str], report: dict[str, Any]) -> None:
    final_state = report.get("m3r_final_state", {})
    post_pack = report.get("m3r_post_pack_manifest", {})
    lines.extend(["", "## M3R Current Kernel", ""])
    lines.append(f"- Final state: `{final_state.get('status', 'UNKNOWN')}` ({final_state.get('final_truth', FINAL_TRUTH)})")
    lines.append(f"- Handoff wrapper: `{final_state.get('handoff_wrapper', safe_rel(WRAPPER_ZIP_PATH))}`")
    lines.append(f"- Bundle profiles: `{len(post_pack.get('profiles', []))}`")
