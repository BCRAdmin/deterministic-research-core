"""Small Markdown rendering helpers for PIG reports."""

from __future__ import annotations

import json
import re
from typing import Any


DEFAULT_SKIP_KEYS = {
    "checks",
    "items",
    "profiles",
    "cards",
    "rails",
    "sources",
    "claims",
    "artifacts",
    "verifiers",
    "sections",
}

SECTION_KEY_TITLES = {
    "do_this_now": "Do This Now",
    "commands": "Commands",
    "verifiers_run": "Verifiers Run",
    "required_commands": "Required Commands",
    "hard_gates": "Hard Gates",
    "operator_gates": "Operator Gates",
    "stop_conditions": "Stop Conditions",
    "batches": "Batches",
    "candidates": "Candidates",
    "quality_dimensions": "Quality Dimensions",
    "memory_capture": "Memory Capture",
    "handoff_updated": "Handoff Updated",
    "verification_snapshot": "Verification Snapshot",
    "markdown_rendering": "Markdown Rendering",
    "residual_dirty_summary": "Residual Dirty Summary",
    "archive_membership": "Archive Membership",
    "source_resolution": "Source Resolution",
    "before_after_metrics": "Before/After Metrics",
    "acceptance_gates": "Acceptance Gates",
}

DEFAULT_SKIP_KEYS.update(SECTION_KEY_TITLES)

IDENTITY_KEYS = {
    "id",
    "item_id",
    "card_id",
    "rail_id",
    "repo_id",
    "source_id",
    "relative_path",
    "path",
    "name",
    "title",
    "profile",
    "candidate",
    "check",
    "command",
    "verifier",
    "phase",
    "metric",
    "gate",
    "archive_name",
    "priority",
}

SUMMARY_KEYS = [
    "text",
    "description",
    "summary",
    "status",
    "decision",
    "state",
    "reason",
    "detail",
    "value",
    "after",
    "before",
    "blocked_reason",
    "target_picture",
    "next_safe_step",
]


def record_value(value: Any) -> str:
    if isinstance(value, list):
        return ", ".join(str(item) for item in value)
    if isinstance(value, dict):
        return json.dumps(value, ensure_ascii=False)
    if value is None:
        return ""
    return str(value)


def compact_label(item: dict[str, Any]) -> str:
    for key in [
        "id",
        "item_id",
        "card_id",
        "rail_id",
        "repo_id",
        "source_id",
        "relative_path",
        "path",
        "name",
        "title",
        "profile",
        "candidate",
        "check",
        "command",
        "verifier",
        "phase",
        "metric",
        "gate",
        "archive_name",
        "priority",
    ]:
        value = item.get(key)
        if value:
            return str(value)
    return "record"


def compact_summary(item: dict[str, Any]) -> str:
    for key in SUMMARY_KEYS:
        value = item.get(key)
        if value not in (None, ""):
            return str(value)
    for key, value in item.items():
        if key in IDENTITY_KEYS or isinstance(value, (dict, list)) or value in (None, ""):
            continue
        return f"{key}={record_value(value)}"
    return ""


def append_item_block(lines: list[str], item: dict[str, Any], *, indent: str = "") -> None:
    label = compact_label(item)
    summary = compact_summary(item)
    if summary:
        lines.append(f"{indent}- `{label}`: {summary}")
    else:
        lines.append(f"{indent}- `{label}`: present")
    for key, value in item.items():
        if key in IDENTITY_KEYS or key in SUMMARY_KEYS:
            continue
        if isinstance(value, list) and all(isinstance(row, dict) for row in value):
            lines.append(f"{indent}  - `{key}`:")
            for row in value:
                append_item_block(lines, row, indent=f"{indent}    ")
        elif isinstance(value, dict):
            lines.append(f"{indent}  - `{key}`:")
            append_key_value_rows(lines, value, indent=f"{indent}    ")
        else:
            lines.append(f"{indent}  - `{key}`: {record_value(value)}")


def append_key_value_rows(lines: list[str], data: dict[str, Any], *, indent: str = "") -> None:
    for key, value in data.items():
        if isinstance(value, dict):
            lines.append(f"{indent}- `{key}`:")
            append_key_value_rows(lines, value, indent=f"{indent}  ")
        elif isinstance(value, list) and all(isinstance(row, dict) for row in value):
            lines.append(f"{indent}- `{key}`:")
            for row in value:
                append_item_block(lines, row, indent=f"{indent}  ")
        elif isinstance(value, list):
            lines.append(f"{indent}- `{key}`: {record_value(value)}")
        else:
            lines.append(f"{indent}- `{key}`: {record_value(value)}")


def append_section(lines: list[str], title: str, rows: list[Any]) -> None:
    if not rows:
        return
    lines.extend(["", f"## {title}", ""])
    for row in rows:
        if isinstance(row, dict):
            append_item_block(lines, row)
        else:
            lines.append(f"- {record_value(row)}")


def append_named_section(lines: list[str], title: str, value: Any) -> None:
    if value in (None, "", [], {}):
        return
    lines.extend(["", f"## {title}", ""])
    if isinstance(value, dict):
        append_key_value_rows(lines, value)
    elif isinstance(value, list):
        for row in value:
            if isinstance(row, dict):
                append_item_block(lines, row)
            else:
                lines.append(f"- {record_value(row)}")
    else:
        lines.append(str(value))


def render_report_markdown(title: str, payload: dict[str, Any], *, skip_keys: set[str] | None = None) -> str:
    skip = skip_keys or DEFAULT_SKIP_KEYS
    lines = [f"# {title}", ""]
    for key, value in payload.items():
        if key in skip or isinstance(value, (dict, list)):
            continue
        lines.append(f"- `{key}`: `{record_value(value)}`")
    if payload.get("checks"):
        lines.extend(["", "## Checks", ""])
        for check in payload.get("checks", []):
            if isinstance(check, dict):
                lines.append(f"- `{check.get('status', 'UNKNOWN')}` `{check.get('check', check.get('name', 'check'))}`: {check.get('detail', '')}")
            else:
                lines.append(f"- {record_value(check)}")
    for key, section_title in SECTION_KEY_TITLES.items():
        append_named_section(lines, section_title, payload.get(key))
    append_section(lines, "Items", payload.get("items", []))
    append_section(lines, "Profiles", payload.get("profiles", []))
    append_section(lines, "Cards", payload.get("cards", []))
    append_section(lines, "Rails", payload.get("rails", []))
    append_section(lines, "Sources", payload.get("sources", []))
    append_section(lines, "Artifacts", payload.get("artifacts", []))
    append_section(lines, "Sections", payload.get("sections", []))
    if payload.get("next_safe_step"):
        lines.extend(["", "## Next Safe Step", "", str(payload["next_safe_step"])])
    return "\n".join(lines) + "\n"


def count_blank_item_bullets(text: str) -> int:
    return len(re.findall(r"(?m)^-\s+`(?:item|record)`(?::\s*)?$", text))
