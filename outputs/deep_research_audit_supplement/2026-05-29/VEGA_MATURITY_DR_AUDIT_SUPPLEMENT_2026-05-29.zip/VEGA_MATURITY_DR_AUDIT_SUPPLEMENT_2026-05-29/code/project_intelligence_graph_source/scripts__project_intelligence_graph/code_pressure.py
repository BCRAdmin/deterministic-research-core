"""Code pressure report helpers for the PIG control plane."""

from __future__ import annotations

import datetime as dt
from pathlib import Path
from typing import Any, Callable


def build_code_pressure_report_payload(
    *,
    workspace: Path,
    output_dir: Path,
    quality_os_surface_path: Path,
    source_registry_path: Path,
    code_pressure_report_path: Path,
    write: bool,
    write_json: Callable[[Path, Any], None],
    render_markdown: Callable[[str, dict[str, Any]], str],
    safe_rel: Callable[[Path], str],
) -> dict[str, Any]:
    targets = [
        workspace / "scripts/project_intelligence_graph/pig.py",
        output_dir / "full_check_report.json",
        quality_os_surface_path,
        source_registry_path,
    ]
    missing = [safe_rel(path) for path in targets if not path.exists()]
    files = [
        {"path": safe_rel(path), "bytes": path.stat().st_size, "pressure": "high" if path.stat().st_size > 250_000 else "normal"}
        for path in targets
        if path.exists()
    ]
    checks = [
        {
            "check": "required_targets_present",
            "status": "PASS" if not missing else "FAIL",
            "detail": "all targets present" if not missing else ", ".join(missing),
        },
        {"check": "file_list_non_empty", "status": "PASS" if files else "FAIL", "detail": str(len(files))},
    ]
    fail_count = sum(1 for item in checks if item["status"] == "FAIL")
    payload = {
        "schema_version": 1,
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": "PASS" if fail_count == 0 else "FAIL",
        "block_id": "B26",
        "pressure_status": "HIGH" if any(item["pressure"] == "high" for item in files) else "NORMAL",
        "high_pressure_file_count": sum(1 for item in files if item["pressure"] == "high"),
        "missing_required_targets": missing,
        "files": files,
        "checks": checks,
        "fail_count": fail_count,
        "risky_refactor_executed": False,
        "recommended_action": "Use extraction map first; do not split the PIG monolith in this run without a narrower before/after test plan.",
        "next_safe_step": "Track code pressure and prefer future pure helper extraction over broad monolith surgery.",
    }
    if write:
        write_json(code_pressure_report_path, payload)
        (output_dir / "code_pressure_report.md").write_text(render_markdown("Code Pressure Report", payload), encoding="utf-8")
    return payload
