"""Central status semantics for local PIG reports."""

from __future__ import annotations

from enum import IntEnum
from typing import Iterable


class Verdict(IntEnum):
    FAIL = 0
    ACTION_REQUIRED = 1
    REVIEW = 2
    PASS_WITH_WARNINGS = 3
    PASS = 4


_STATUS_ALIASES = {
    "PASS": Verdict.PASS,
    "OK": Verdict.PASS,
    "COMPLETED_VERIFIED": Verdict.PASS,
    "PASS_WITH_WARNINGS": Verdict.PASS_WITH_WARNINGS,
    "WARN": Verdict.PASS_WITH_WARNINGS,
    "WARNING": Verdict.PASS_WITH_WARNINGS,
    "WARN_WITH_LOCAL_ONLY": Verdict.PASS_WITH_WARNINGS,
    "PASS_WARN": Verdict.PASS_WITH_WARNINGS,
    "REVIEW": Verdict.REVIEW,
    "NEEDS_REVIEW": Verdict.REVIEW,
    "ACTION_REQUIRED": Verdict.ACTION_REQUIRED,
    "OPERATOR_GO_REQUIRED": Verdict.ACTION_REQUIRED,
    "BLOCKED": Verdict.ACTION_REQUIRED,
    "WAITING_FOR_OPERATOR": Verdict.ACTION_REQUIRED,
    "MISSING": Verdict.ACTION_REQUIRED,
    "UNKNOWN": Verdict.ACTION_REQUIRED,
    "FAIL": Verdict.FAIL,
    "FAILED": Verdict.FAIL,
    "ERROR": Verdict.FAIL,
}


def normalize_status(status: object) -> Verdict:
    if isinstance(status, Verdict):
        return status
    text = str(status or "").strip().upper().replace("-", "_").replace(" ", "_")
    if not text:
        return Verdict.ACTION_REQUIRED
    if "MISSING" in text:
        return Verdict.ACTION_REQUIRED
    if text in _STATUS_ALIASES:
        return _STATUS_ALIASES[text]
    if text.endswith(".WARN") or text.startswith("WARN_"):
        return Verdict.PASS_WITH_WARNINGS
    if text.startswith("FAIL") or text.endswith("_FAIL"):
        return Verdict.FAIL
    return Verdict.ACTION_REQUIRED


def aggregate_verdict(items: Iterable[Verdict]) -> Verdict:
    values = list(items)
    if not values:
        return Verdict.ACTION_REQUIRED
    return min(values, key=lambda item: item.value)


def aggregate_statuses(statuses: Iterable[object]) -> Verdict:
    return aggregate_verdict(normalize_status(status) for status in statuses)


def is_passish_status(status: object) -> bool:
    return normalize_status(status) in {Verdict.PASS, Verdict.PASS_WITH_WARNINGS}
