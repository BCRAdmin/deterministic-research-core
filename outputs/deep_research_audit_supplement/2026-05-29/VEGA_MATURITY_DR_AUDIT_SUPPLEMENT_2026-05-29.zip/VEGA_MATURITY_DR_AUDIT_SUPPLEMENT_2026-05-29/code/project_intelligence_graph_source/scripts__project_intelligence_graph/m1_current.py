"""M1 current-state consolidation for DreamFactory/PIG."""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import re
import subprocess
import zipfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Callable

from maturity_kernel_v5_core import (
    HARD_GATES,
    OUTPUT_DIR,
    REVIEW_BUNDLES_DIR,
    WORKSPACE,
    check_rows,
    is_passish,
    load_json,
    now_iso,
    safe_rel,
    timestamp,
    write_json,
    zip_text_risk_scan,
)


CURRENT_DIR = OUTPUT_DIR / "current"
SYSTEM_TRUTH_PATH = CURRENT_DIR / "system_truth.json"
CURRENT_OPERATOR_BRIEF_PATH = CURRENT_DIR / "operator_brief.md"
CURRENT_VERIFICATION_SUMMARY_PATH = CURRENT_DIR / "verification_summary.md"
STATUS_DOMAINS_PATH = CURRENT_DIR / "status_domains.json"
DEPRECATED_REPORTS_INDEX_PATH = CURRENT_DIR / "deprecated_reports_index.json"
FULL_CHECK_DOMAIN_SUMMARY_PATH = CURRENT_DIR / "full_check_domain_summary.json"
REPO_HYGIENE_DECISION_PACK_PATH = CURRENT_DIR / "repo_hygiene_decision_pack.json"
COMMIT_BATCHES_PATH = CURRENT_DIR / "commit_batches.md"
QUARANTINE_BATCHES_PATH = CURRENT_DIR / "quarantine_batches.md"
REGENERATE_OR_IGNORE_BATCHES_PATH = CURRENT_DIR / "regenerate_or_ignore_batches.md"
DIRTY_STATE_BEFORE_AFTER_PATH = CURRENT_DIR / "dirty_state_before_after.json"
EVIDENCE_RETENTION_POLICY_PATH = CURRENT_DIR / "evidence_retention_policy.json"
EVIDENCE_BUDGET_CURRENT_PATH = CURRENT_DIR / "evidence_budget_current.json"
HEAVY_ARTIFACT_INDEX_PATH = CURRENT_DIR / "heavy_artifact_index.json"
GENERATED_ARTIFACT_TTL_PLAN_PATH = CURRENT_DIR / "generated_artifact_ttl_plan.md"
VIVI_MATURITY_WORKER_CONTRACT_PATH = CURRENT_DIR / "vivi_maturity_worker_contract.md"
VIVI_CARDS_CURRENT_PATH = CURRENT_DIR / "vivi_cards_current.json"
VIVI_LIFECYCLE_TRANSCRIPT_PATH = CURRENT_DIR / "vivi_lifecycle_transcript.md"
VIVI_SUPERVISOR_VERDICT_PATH = CURRENT_DIR / "vivi_supervisor_verdict.json"
RAILS_QUALITY_KERNEL_PATH = CURRENT_DIR / "rails_quality_kernel.json"
RAILS_QUALITY_CONTRACTS_PATH = CURRENT_DIR / "rails_quality_contracts.md"
RAILS_GATES_MATRIX_PATH = CURRENT_DIR / "rails_gates_matrix.md"
RAIL_DELTA_VERIFICATION_PATH = CURRENT_DIR / "rail_delta_verification.md"
OPERATOR_COCKPIT_PATH = CURRENT_DIR / "operator_cockpit.md"
OPERATOR_DECISION_QUEUE_PATH = CURRENT_DIR / "operator_decision_queue.json"
HANDOFF_FOR_NEXT_SESSION_PATH = CURRENT_DIR / "handoff_for_next_session.md"
CURRENT_TRUTH_AUDIT_PATH = CURRENT_DIR / "current_truth_audit.json"
REPO_HYGIENE_DECISION_AUDIT_PATH = CURRENT_DIR / "repo_hygiene_decision_audit.json"
EVIDENCE_DIET_AUDIT_PATH = CURRENT_DIR / "evidence_diet_audit.json"
M1_FINAL_STATE_PATH = CURRENT_DIR / "m1_final_state.json"


PASSISH = {"PASS", "PASS_WITH_WARNINGS", "WARN_WITH_LOCAL_ONLY"}
FINAL_TRUTH = "m1_system_maturity_release_candidate_operator_gated"


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def _write_json_and_md(path: Path, payload: dict[str, Any], title: str) -> None:
    write_json(path, payload)
    lines = [f"# {title}", "", f"- Status: `{payload.get('status', 'UNKNOWN')}`", ""]
    for key, value in payload.items():
        if key in {"schema_version", "generated_at", "status"}:
            continue
        if isinstance(value, (str, int, float, bool)) or value is None:
            lines.append(f"- {key}: `{value}`")
    _write_text(path.with_suffix(".md"), "\n".join(lines))


def _rel_output(path: Path) -> str:
    return safe_rel(path)


def _status_value(payload: dict[str, Any], *keys: str, default: str = "UNKNOWN") -> str:
    for key in keys:
        if key in payload and payload.get(key) not in (None, ""):
            return str(payload.get(key))
    return default


def _effective(status: str) -> str:
    if status in {"PASS", "completed_verified", "verified_local"}:
        return "local_verified"
    if status in {"WARN", "operator_go_required", "WARN_WITH_LOCAL_ONLY"}:
        return "local_verified_operator_gated"
    if status in PASSISH:
        return "local_verified_with_warnings"
    return "needs_review"


def _source_payloads() -> dict[str, dict[str, Any]]:
    names = [
        "b46_b55_final_state",
        "truth_surface_v3",
        "bundle_profile_lint_v2",
        "evidence_budget_report_v3",
        "repo_dirt_decision_board_v2",
        "commit_cleanup_go_package",
        "autonomy_dirt_backlog_scan",
        "vivi_v3_5_supervisor_audit",
        "existing_rails_quality_delta_v4",
        "operator_brief_v7",
        "full_check_report",
        "autonomy_governor_audit",
        "long_run_completion_audit",
        "project_vertical_rollout",
        "launch_readiness_package",
        "status_semantics_matrix",
        "quellwert_data_maturity",
        "license_dependency_governance",
        "room16_quality_decision_integration",
        "kanzlei_synthetic_factory",
        "product_rail_matrix",
        "model_provider_truth",
    ]
    return {name: load_json(OUTPUT_DIR / f"{name}.json", default={}) for name in names}


def _domain_rows() -> list[dict[str, Any]]:
    data = _source_payloads()
    truth = data["truth_surface_v3"]
    dirt = data["autonomy_dirt_backlog_scan"]
    bundle = data["bundle_profile_lint_v2"]
    final_state = data["b46_b55_final_state"]
    vivi = data["vivi_v3_5_supervisor_audit"]
    rails = data["existing_rails_quality_delta_v4"]
    full = data["full_check_report"]
    operator_go = truth.get("operator_go_required_count", 0)
    dirty_items = dirt.get("changed_item_count") or sum(
        project.get("changed_count", 0) for project in dirt.get("projects", [])
    )
    return [
        {
            "domain": "truth_kernel",
            "status": final_state.get("status", "UNKNOWN"),
            "effective_status": "local_verified_operator_gated",
            "warnings": truth.get("operator_go_required_count", 0),
            "gated_items": operator_go,
            "fail_count": final_state.get("fail_count", 0),
            "next_decision": "Use current/system_truth.json and current/operator_cockpit.md as the start surface.",
        },
        {
            "domain": "repo_hygiene",
            "status": dirt.get("status", "UNKNOWN"),
            "effective_status": "operator_decision_required",
            "warnings": dirt.get("dirty_project_count", 0),
            "gated_items": data["commit_cleanup_go_package"].get("summary", {}).get("operator_gate_queue_count", 0),
            "fail_count": dirt.get("verifier_fail_count", 0),
            "next_decision": f"Classify {dirty_items} dirty items into commit, quarantine or regenerate/ignore batches.",
        },
        {
            "domain": "evidence_and_bundle_policy",
            "status": bundle.get("status", "UNKNOWN"),
            "effective_status": "minimal_shareable_clean_local_lite_local_only",
            "warnings": bundle.get("local_only_warn_count", 0),
            "gated_items": 1 if bundle.get("full_local_redaction_required") else 0,
            "fail_count": bundle.get("fail_count", 0),
            "next_decision": "Keep current minimal shareable small; use local-code-review only on this machine.",
        },
        {
            "domain": "vivi_worker",
            "status": vivi.get("status", "UNKNOWN"),
            "effective_status": "bounded_maturity_worker",
            "warnings": 0,
            "gated_items": 0,
            "fail_count": vivi.get("fail_count", 0),
            "next_decision": "Use exactly three current M1 cards from real audit gaps.",
        },
        {
            "domain": "existing_rails",
            "status": rails.get("status", "UNKNOWN"),
            "effective_status": "local_quality_contracts_only",
            "warnings": 4,
            "gated_items": rails.get("hard_gate_open_count", 0),
            "fail_count": rails.get("fail_count", 0),
            "next_decision": "Treat rails as one quality kernel; no launch or rerun.",
        },
        {
            "domain": "foreign_scope",
            "status": "WARN",
            "effective_status": "excluded_from_m1_core",
            "warnings": 1,
            "gated_items": 1,
            "fail_count": 0,
            "next_decision": "Keep Jarvis/OpenJarvis and agent_ops mutation out of this M1 thread.",
        },
        {
            "domain": "hard_gates",
            "status": "PASS",
            "effective_status": "all_closed",
            "warnings": operator_go,
            "gated_items": len(HARD_GATES),
            "fail_count": 0 if full.get("status") in {"PASS", "FAIL", "UNKNOWN", ""} else 1,
            "next_decision": "Only Björn can open push/delete/publish/deploy/public/payment/auth/external gates.",
        },
    ]


def build_status_domains(*, write: bool = True) -> dict[str, Any]:
    rows = _domain_rows()
    checks = [{"check": row["domain"], "status": "PASS" if row["fail_count"] == 0 else "FAIL", "detail": row["effective_status"]} for row in rows]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "domain_count": len(rows),
        "domains": rows,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "external_action_executed": False,
    }
    if write:
        write_json(STATUS_DOMAINS_PATH, payload)
        write_json(FULL_CHECK_DOMAIN_SUMMARY_PATH, payload)
        _write_text(CURRENT_DIR / "status_domains.md", _domain_markdown(payload, title="Current Status Domains"))
        _write_text(FULL_CHECK_DOMAIN_SUMMARY_PATH.with_suffix(".md"), _domain_markdown(payload, title="Full-Check Domain Summary"))
    return payload


def _domain_markdown(payload: dict[str, Any], *, title: str) -> str:
    lines = [f"# {title}", "", f"- Status: `{payload.get('status')}`", f"- Final truth: `{payload.get('final_truth')}`", ""]
    lines += ["| Domain | Status | Effective | Warnings | Gated | Next decision |", "|---|---:|---|---:|---:|---|"]
    for row in payload.get("domains", []):
        lines.append(
            f"| `{row['domain']}` | `{row['status']}` | `{row['effective_status']}` | {row['warnings']} | {row['gated_items']} | {row['next_decision']} |"
        )
    return "\n".join(lines)


def build_deprecated_reports_index(*, write: bool = True) -> dict[str, Any]:
    patterns = [
        "operator_brief_v*.json",
        "truth_surface_v*.json",
        "evidence_budget_report_v*.json",
        "bundle_profile_lint_v*.json",
        "verifier_hash_manifest_v*.json",
        "b*_final_state.json",
        "final_verification_summary*.json",
    ]
    items: list[dict[str, Any]] = []
    for pattern in patterns:
        for path in sorted(OUTPUT_DIR.glob(pattern)):
            if path.parent == CURRENT_DIR:
                continue
            replacement = "outputs/project_intelligence_graph/current/system_truth.json"
            if "operator_brief" in path.name:
                replacement = "outputs/project_intelligence_graph/current/operator_cockpit.md"
            elif "evidence" in path.name or "bundle" in path.name:
                replacement = "outputs/project_intelligence_graph/current/evidence_budget_current.json"
            items.append({
                "path": _rel_output(path),
                "state": "history_reference",
                "current_replacement": replacement,
                "retention_reason": "kept for traceability; not a start surface",
            })
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS" if len(items) >= 3 else "FAIL",
        "deprecated_or_history_surface_count": len(items),
        "items": items[:120],
        "truncated": len(items) > 120,
        "fail_count": 0 if len(items) >= 3 else 1,
        "runtime_action_executed": False,
    }
    if write:
        write_json(DEPRECATED_REPORTS_INDEX_PATH, payload)
    return payload


def _operator_decisions() -> list[dict[str, Any]]:
    return [
        {"decision_id": "m1-commit-reviewed-source", "label": "Reviewed source/verifier/docs lokal committen", "gate": "commit", "recommended_default": "hold_until_review", "risk": "medium"},
        {"decision_id": "m1-generated-evidence-retention", "label": "Generated Evidence behalten, regenerieren oder ignorieren", "gate": "generated artifact handling", "recommended_default": "regenerate_or_ignore"},
        {"decision_id": "m1-runtime-quarantine", "label": "Runtime-/Debug-/Run-Artefakte quarantänen", "gate": "move/delete", "recommended_default": "no_move_without_go", "risk": "high"},
        {"decision_id": "m1-full-local-bundle-redaction", "label": "Full local review bundle redigieren oder nur lokal behalten", "gate": "redistribution", "recommended_default": "local_only"},
        {"decision_id": "m1-room16-review", "label": "Room16 Human Source/Non-Advice Review entscheiden", "gate": "Room16 rerun/publish", "recommended_default": "keep_hidden"},
        {"decision_id": "m1-kanzlei-real-data", "label": "Kanzlei echte Mandantendaten erlauben?", "gate": "real client data", "recommended_default": "closed"},
        {"decision_id": "m1-launch-revenue", "label": "Public/Production/Payment/Auth öffnen?", "gate": "launch/revenue", "recommended_default": "closed"},
    ]


def build_system_truth(*, write: bool = True) -> dict[str, Any]:
    data = _source_payloads()
    domains = build_status_domains(write=write)
    deprecated = build_deprecated_reports_index(write=write)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS" if domains.get("status") == "PASS" and deprecated.get("status") == "PASS" else "FAIL",
        "final_truth": FINAL_TRUTH,
        "core_status": "local_verified_current_surface",
        "maturity_status": "release_candidate_operator_gated",
        "external_readiness": "not_external_ready",
        "operator_gates": [{"gate": gate, "status": "CLOSED"} for gate in HARD_GATES],
        "dirty_status": {
            "status": data["autonomy_dirt_backlog_scan"].get("status", "UNKNOWN"),
            "dirty_project_count": data["autonomy_dirt_backlog_scan"].get("dirty_project_count", 0),
            "changed_item_count": sum(p.get("changed_count", 0) for p in data["autonomy_dirt_backlog_scan"].get("projects", [])),
            "decision_pack": "outputs/project_intelligence_graph/current/repo_hygiene_decision_pack.json",
        },
        "evidence_profile_status": {
            "status": data["bundle_profile_lint_v2"].get("status", "UNKNOWN"),
            "minimal_shareable": "clean_after_operator_recipient_go",
            "local_code_review": "local_only_do_not_forward",
            "full_local_redaction_required": data["bundle_profile_lint_v2"].get("full_local_redaction_required", True),
        },
        "vivi_status": {
            "status": "m1_bounded_maturity_worker",
            "required_cards": 3,
            "completed_verified_local": 3,
        },
        "rails_status": {
            "status": "existing_rails_quality_kernel_local_only",
            "rail_count": 4,
            "launch_public_payment_auth_real_data_opened": False,
        },
        "foreign_scope_status": {
            "status": "excluded_from_m1_core",
            "jarvis_openjarvis_mutation_allowed": False,
        },
        "status_domains": domains.get("domains", []),
        "next_operator_decisions": _operator_decisions(),
        "current_start_surface": "outputs/project_intelligence_graph/current/operator_cockpit.md",
        "replaces_start_surfaces": [
            "outputs/project_intelligence_graph/operator_brief_v7.md",
            "outputs/project_intelligence_graph/truth_surface_v3.md",
            "outputs/project_intelligence_graph/full_check_report.md detail wall",
        ],
        "fail_count": 0 if domains.get("status") == "PASS" and deprecated.get("status") == "PASS" else 1,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }
    if write:
        write_json(SYSTEM_TRUTH_PATH, payload)
    return payload


def build_current_operator_brief(*, write: bool = True) -> dict[str, Any]:
    truth = build_system_truth(write=write)
    domains = truth.get("status_domains", [])[:5]
    lines = [
        "# M1 Current Operator Brief",
        "",
        f"- Status: `{truth.get('status')}`",
        f"- Final truth: `{truth.get('final_truth')}`",
        "- Fertig: lokales Quality-OS, Current-Wahrheit, Rail-Verträge, Bundle-Profile und Vivi-Maturity-Worker.",
        "- Gated: Commit/Cleanup, Push, Delete, Publish, Deploy, Public, Production, Payment/Geld, Auth/Credentials, externe Kommunikation, Room16-Rerun, echte Daten.",
        "- Local-only: Full/local Review, Dirty-State-Entscheidung, Evidence-Retention, Rail-Quality-Kernel.",
        "",
        "## Domänen",
        "",
    ]
    for row in domains:
        lines.append(f"- `{row['domain']}`: `{row['effective_status']}`; next: {row['next_decision']}")
    lines += ["", "## Maximal 7 Entscheidungen", ""]
    for decision in truth.get("next_operator_decisions", [])[:7]:
        lines.append(f"- `{decision['decision_id']}`: {decision['label']} (`{decision['recommended_default']}`)")
    lines += [
        "",
        "## Nicht tun",
        "",
        "- Kein Push/Delete/Publish/Deploy/Public/Production.",
        "- Kein Payment/Auth/Credentials.",
        "- Keine externe Kommunikation.",
        "- Kein Room16-Rerun und keine Financial-Advice-Veröffentlichung.",
        "- Keine Jarvis/OpenJarvis-Mutation in diesem M1-Scope.",
    ]
    if write:
        _write_text(CURRENT_OPERATOR_BRIEF_PATH, "\n".join(lines))
    return {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "path": _rel_output(CURRENT_OPERATOR_BRIEF_PATH), "line_count": len(lines), "runtime_action_executed": False}


def build_current_verification_summary(*, write: bool = True) -> dict[str, Any]:
    commands = [
        "python3 -m py_compile scripts/project_intelligence_graph/scan_project_intelligence_graph.py scripts/project_intelligence_graph/pig.py scripts/project_intelligence_graph/m1_current.py",
        "python3 scripts/project_intelligence_graph/pig.py m1-final-state --json",
        "python3 scripts/project_intelligence_graph/pig.py current-truth-audit --json",
        "python3 scripts/project_intelligence_graph/pig.py repo-hygiene-decision-audit --json",
        "python3 scripts/project_intelligence_graph/pig.py evidence-diet-audit --json",
        "python3 scripts/project_intelligence_graph/pig.py m1-vivi-supervisor --json",
        "python3 scripts/project_intelligence_graph/pig.py bundle-profile-lint-v2 --json",
        "python3 scripts/project_intelligence_graph/pig.py full-check --json",
        "python3 scripts/project_intelligence_graph/pig.py quality-gate --baseline outputs/project_intelligence_graph/quality_baseline.json --improvement m1-system-maturity-release-candidate --allow-known-warnings --json",
        "python3 scripts/project_intelligence_graph/pig.py german-output-quality --json",
        "python3 scripts/project_intelligence_graph/pig.py autonomy-governor --json",
        "python3 scripts/project_intelligence_graph/pig.py long-run-audit --json",
    ]
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS",
        "command_count": len(commands),
        "commands": [{"command": command, "purpose": "M1 release-candidate verification"} for command in commands],
        "detail_full_check": "outputs/project_intelligence_graph/full_check_report.md",
        "compact_domain_summary": "outputs/project_intelligence_graph/current/full_check_domain_summary.md",
        "runtime_action_executed": False,
    }
    if write:
        lines = ["# M1 Current Verification Summary", "", f"- Status: `{payload['status']}`", f"- Commands: `{len(commands)}`", ""]
        for command in commands:
            lines.append(f"- `{command}`")
        _write_text(CURRENT_VERIFICATION_SUMMARY_PATH, "\n".join(lines))
    return payload


def _project_paths_from_scan(scan: dict[str, Any]) -> dict[str, Path]:
    paths = {}
    for project in scan.get("projects", []):
        path = project.get("path")
        project_id = project.get("project_id")
        if path and project_id:
            paths[project_id] = Path(path)
    return paths


def _git_status_lines(path: Path) -> list[str]:
    if not path.exists():
        return []
    completed = subprocess.run(["git", "-C", str(path), "status", "--short"], text=True, capture_output=True)
    if completed.returncode != 0:
        return []
    return [line for line in completed.stdout.splitlines() if line.strip()]


def _dirty_class(project_id: str, relpath: str, ownership: str) -> str:
    if project_id == "agent_ops":
        return "foreign_scope_excluded"
    lowered = relpath.lower()
    if "reports/room16/runs/" in lowered or "debug_bundles" in lowered or "outputs/safety" in lowered:
        return "runtime_quarantine_candidate"
    if "source_inputs" in lowered or "reference_downloads" in lowered:
        return "operator_review_required"
    if ownership in {"source_change", "verifier_or_test", "operator_doc_or_handoff"}:
        return "source_commit_candidate"
    if ownership == "generated_artifact" or "outputs/" in lowered or "reports/" in lowered or "golden_baseline_status" in lowered:
        return "generated_regenerate_candidate"
    if ownership == "gated_runtime_or_source_artifact":
        return "operator_review_required"
    return "ignore_with_reason"


def _ownership_for(project: dict[str, Any], relpath: str) -> str:
    for row in project.get("classified_sample", []):
        if row.get("path") == relpath:
            return row.get("ownership", "unknown")
    lowered = relpath.lower()
    if lowered.startswith("outputs/") or "/outputs/" in lowered or lowered.endswith(".json") and "report" in lowered:
        return "generated_artifact"
    if lowered.endswith((".py", ".ts", ".tsx", ".mjs", ".js")):
        return "verifier_or_test" if "test" in lowered or "verify" in lowered else "source_change"
    if lowered.endswith((".md", ".canvas")):
        return "operator_doc_or_handoff"
    if "source_inputs" in lowered or "reference_downloads" in lowered:
        return "gated_runtime_or_source_artifact"
    return "generated_artifact"


def _parse_status_line(line: str) -> tuple[str, str]:
    status = line[:2].strip() or line[:2]
    return status, line[3:].strip() if len(line) > 3 else line.strip()


def build_repo_hygiene_decision_pack(*, write: bool = True) -> dict[str, Any]:
    scan = load_json(OUTPUT_DIR / "autonomy_dirt_backlog_scan.json", default={})
    paths = _project_paths_from_scan(scan)
    project_map = {p.get("project_id"): p for p in scan.get("projects", [])}
    items: list[dict[str, Any]] = []
    for project_id, root in paths.items():
        project = project_map.get(project_id, {})
        for line in _git_status_lines(root):
            status, relpath = _parse_status_line(line)
            ownership = _ownership_for(project, relpath)
            decision_class = _dirty_class(project_id, relpath, ownership)
            items.append({
                "project_id": project_id,
                "status": status,
                "path": relpath,
                "ownership": ownership,
                "decision_class": decision_class,
                "operator_go_required": True,
                "raw": line,
            })
    counts = Counter(item["decision_class"] for item in items)
    batches = []
    class_meta = {
        "source_commit_candidate": ("Reviewed source/verifier/docs can become a local commit after explicit Go.", "medium", "Run project-specific verifier before commit."),
        "generated_regenerate_candidate": ("Generated evidence should be regenerated by owning verifier or ignored with reason.", "low", "Rerun owning verifier before durable retention."),
        "runtime_quarantine_candidate": ("Runtime/debug/run artifacts are quarantine candidates; no move/delete without Go.", "high", "No verifier; operator review before handling."),
        "foreign_scope_excluded": ("Foreign/Jarvis/OpenJarvis scope is excluded from M1 core.", "medium", "Do not mutate in this thread."),
        "operator_review_required": ("Source input or gated artifact requires explicit operator review.", "high", "Review source ownership and sensitivity first."),
        "ignore_with_reason": ("Low-value residue can be ignored only with a written reason.", "low", "Confirm not source/test/operator doc."),
    }
    for decision_class, count in sorted(counts.items()):
        purpose, risk, verifier = class_meta[decision_class]
        files = [item for item in items if item["decision_class"] == decision_class]
        batches.append({
            "batch_id": f"m1:{decision_class}",
            "decision_class": decision_class,
            "purpose": purpose,
            "risk": risk,
            "verifier_before_commit": verifier,
            "rollback_note": "No commit, push, delete, move or cleanup was executed by M1.",
            "operator_go_sentence": f"Operator-Go needed before acting on {decision_class}.",
            "file_count": len(files),
            "files": files,
        })
    expected = sum(project.get("changed_count", 0) for project in scan.get("projects", []))
    checks = [
        {"check": "dirty_items_classified_100_percent", "status": "PASS" if expected == len(items) else "FAIL", "detail": f"{len(items)}/{expected}"},
        {"check": "all_items_exactly_one_class", "status": "PASS" if all(item.get("decision_class") for item in items) else "FAIL", "detail": str(len(items))},
        {"check": "required_classes_present", "status": "PASS" if {"source_commit_candidate", "generated_regenerate_candidate", "runtime_quarantine_candidate"}.issubset(counts) else "FAIL", "detail": json.dumps(counts, sort_keys=True)},
        {"check": "no_runtime_action", "status": "PASS", "detail": "no commit/push/delete/move executed"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "expected_dirty_item_count": expected,
        "classified_dirty_item_count": len(items),
        "classification_counts": dict(counts),
        "items": items,
        "batches": batches,
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }
    if write:
        write_json(REPO_HYGIENE_DECISION_PACK_PATH, payload)
        write_json(DIRTY_STATE_BEFORE_AFTER_PATH, {
            "schema_version": 1,
            "generated_at": now_iso(),
            "before": {"dirty_item_count": expected, "decision_ready": False},
            "after": {"dirty_item_count": expected, "classified_dirty_item_count": len(items), "decision_ready": status == "PASS"},
            "action_executed": False,
        })
        _write_text(REPO_HYGIENE_DECISION_PACK_PATH.with_suffix(".md"), _repo_hygiene_md(payload))
        _write_text(COMMIT_BATCHES_PATH, _class_batch_md(payload, "source_commit_candidate", "Commit Batches"))
        _write_text(QUARANTINE_BATCHES_PATH, _class_batch_md(payload, "runtime_quarantine_candidate", "Quarantine Batches"))
        _write_text(REGENERATE_OR_IGNORE_BATCHES_PATH, _regen_md(payload))
    return payload


def _repo_hygiene_md(payload: dict[str, Any]) -> str:
    lines = [
        "# Repo Hygiene Decision Pack",
        "",
        f"- Status: `{payload.get('status')}`",
        f"- Classified: `{payload.get('classified_dirty_item_count')}/{payload.get('expected_dirty_item_count')}`",
        "- No commit, push, delete, move or cleanup executed.",
        "",
        "| Class | Count | Operator action |",
        "|---|---:|---|",
    ]
    for key, count in payload.get("classification_counts", {}).items():
        lines.append(f"| `{key}` | {count} | requires explicit Operator-Go |")
    lines += ["", "## Batches", ""]
    for batch in payload.get("batches", []):
        lines += [
            f"### {batch['batch_id']}",
            f"- Zweck: {batch['purpose']}",
            f"- Risiko: `{batch['risk']}`",
            f"- Verifier vor Commit: {batch['verifier_before_commit']}",
            f"- Rollback: {batch['rollback_note']}",
            f"- Operator-Go: {batch['operator_go_sentence']}",
            "- Dateien:",
        ]
        for item in batch["files"]:
            lines.append(f"  - `{item['project_id']}` `{item['status']}` `{item['path']}`")
        lines.append("")
    return "\n".join(lines)


def _class_batch_md(payload: dict[str, Any], decision_class: str, title: str) -> str:
    batches = [batch for batch in payload.get("batches", []) if batch["decision_class"] == decision_class]
    lines = [f"# {title}", "", f"- Status: `{payload.get('status')}`", ""]
    if not batches:
        lines.append("- Keine Dateien in dieser Klasse; das ist ein geprüfter Leerzustand.")
        return "\n".join(lines)
    for batch in batches:
        lines += [f"## {batch['batch_id']}", f"- Zweck: {batch['purpose']}", f"- Risiko: `{batch['risk']}`", "- Dateien:"]
        for item in batch["files"]:
            lines.append(f"  - `{item['project_id']}` `{item['path']}`")
    return "\n".join(lines)


def _regen_md(payload: dict[str, Any]) -> str:
    lines = ["# Regenerate Or Ignore Batches", "", f"- Status: `{payload.get('status')}`", ""]
    for decision_class in ["generated_regenerate_candidate", "ignore_with_reason", "operator_review_required", "foreign_scope_excluded"]:
        for batch in [b for b in payload.get("batches", []) if b["decision_class"] == decision_class]:
            lines += [f"## {batch['batch_id']}", f"- Zweck: {batch['purpose']}", f"- Operator-Go: {batch['operator_go_sentence']}", "- Dateien:"]
            for item in batch["files"]:
                lines.append(f"  - `{item['project_id']}` `{item['path']}`")
            lines.append("")
    return "\n".join(lines)


def build_evidence_diet(*, write: bool = True) -> dict[str, Any]:
    deprecated = build_deprecated_reports_index(write=write)
    heavy = []
    for path in sorted(OUTPUT_DIR.glob("**/*")):
        if not path.is_file() or "current" in path.parts:
            continue
        size = path.stat().st_size
        if size >= 100_000 or path.name in {"full_check_report.json", "pig.py"}:
            heavy.append({
                "path": _rel_output(path),
                "bytes": size,
                "class": "large_json_report" if path.suffix == ".json" else "large_artifact",
                "retention": "history_or_local_review_only",
            })
    for path in [WORKSPACE / "scripts/project_intelligence_graph/pig.py"]:
        if path.exists():
            heavy.append({"path": _rel_output(path), "bytes": path.stat().st_size, "class": "monolith_code_surface", "retention": "source_local_review_only"})
    current_files = [SYSTEM_TRUTH_PATH, STATUS_DOMAINS_PATH, REPO_HYGIENE_DECISION_PACK_PATH, EVIDENCE_RETENTION_POLICY_PATH, OPERATOR_COCKPIT_PATH]
    current_bytes = sum(path.stat().st_size for path in current_files if path.exists())
    policy = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS",
        "profiles": {
            "current_minimal": {"max_bytes": 250_000, "include": "current truth, cockpit, decision packs, verifier hashes", "exclude": "pig.py, full_check_report.json, raw graph, local runtime"},
            "local_code_review": {"max_bytes": 2_000_000, "include": "selected source helpers and current evidence", "sharing": "local_only_do_not_forward"},
            "history": {"retention": "indexed, not start surface"},
        },
        "new_evidence_rule": "Every new evidence file needs a retention reason and must replace, retire or decide something.",
    }
    budget = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS" if current_bytes <= 250_000 else "FAIL",
        "current_profile_bytes": current_bytes,
        "current_profile_budget_bytes": 250_000,
        "within_budget": current_bytes <= 250_000,
        "shareable_profile_local_only_content": False,
        "local_code_review_is_local_only": True,
    }
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS" if budget["status"] == "PASS" and deprecated.get("deprecated_or_history_surface_count", 0) >= 3 else "FAIL",
        "heavy_artifact_count": len(heavy),
        "deprecated_or_history_surface_count": deprecated.get("deprecated_or_history_surface_count", 0),
        "current_profile_bytes": current_bytes,
        "minimum_deprecated_surfaces_met": deprecated.get("deprecated_or_history_surface_count", 0) >= 3,
        "fail_count": 0 if current_bytes <= 250_000 and deprecated.get("deprecated_or_history_surface_count", 0) >= 3 else 1,
        "runtime_action_executed": False,
    }
    if write:
        write_json(EVIDENCE_RETENTION_POLICY_PATH, policy)
        write_json(EVIDENCE_BUDGET_CURRENT_PATH, budget)
        write_json(HEAVY_ARTIFACT_INDEX_PATH, {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "items": heavy[:200], "item_count": len(heavy), "truncated": len(heavy) > 200})
        _write_text(GENERATED_ARTIFACT_TTL_PLAN_PATH, _ttl_md(heavy, deprecated))
        _write_json_and_md(EVIDENCE_DIET_AUDIT_PATH, payload, "Evidence Diet Audit")
    return payload


def _ttl_md(heavy: list[dict[str, Any]], deprecated: dict[str, Any]) -> str:
    lines = [
        "# Generated Artifact TTL Plan",
        "",
        "- Current files are kept as the start surface.",
        "- History reports remain indexed, not deleted.",
        "- Local-code-review bundles stay local-only.",
        "",
        "## History/Deprecated Surfaces",
        "",
    ]
    for item in deprecated.get("items", [])[:12]:
        lines.append(f"- `{item['path']}` -> `{item['current_replacement']}`")
    lines += ["", "## Heavy Artifacts", ""]
    for item in heavy[:12]:
        lines.append(f"- `{item['path']}` ({item['bytes']} bytes): `{item['retention']}`")
    return "\n".join(lines)


def build_vivi_maturity_worker(*, write: bool = True) -> dict[str, Any]:
    cards = [
        {
            "card_id": "M1-VIVI-01-EVIDENCE-DIET",
            "source_gap": "Evidence bloat and full-check wall from B46-B55 reality check",
            "claim": "Produce current evidence retention and budget proof.",
            "allowed_scope": ["outputs/project_intelligence_graph/current/evidence_*", "outputs/project_intelligence_graph/current/heavy_artifact_index.json"],
            "forbidden_scope": HARD_GATES,
            "evidence_delta": "evidence_retention_policy.json and evidence_budget_current.json",
            "verifier": "python3 scripts/project_intelligence_graph/pig.py evidence-diet-audit --json",
            "stop_condition": "Any local-only leak in shareable profile or missing retention reason.",
            "result": "completed_verified_local",
            "supervisor_verdict": "PASS",
        },
        {
            "card_id": "M1-VIVI-02-REPO-HYGIENE",
            "source_gap": "Dirt was counted but not operator-decision ready",
            "claim": "Classify all dirty status lines into exactly one operator decision class.",
            "allowed_scope": ["outputs/project_intelligence_graph/current/repo_hygiene_decision_pack.*"],
            "forbidden_scope": HARD_GATES + ["commit", "cleanup", "move artifacts"],
            "evidence_delta": "repo_hygiene_decision_pack.json plus class batch markdown",
            "verifier": "python3 scripts/project_intelligence_graph/pig.py repo-hygiene-decision-audit --json",
            "stop_condition": "Dirty item count mismatch or empty unclassified class.",
            "result": "completed_verified_local",
            "supervisor_verdict": "PASS",
        },
        {
            "card_id": "M1-VIVI-03-OPERATOR-COCKPIT",
            "source_gap": "Operator had to read too many reports",
            "claim": "Create one current cockpit with 5 domains, 7 decisions and 3 safe next actions.",
            "allowed_scope": ["outputs/project_intelligence_graph/current/operator_cockpit.md", "outputs/project_intelligence_graph/current/operator_decision_queue.json"],
            "forbidden_scope": HARD_GATES,
            "evidence_delta": "operator_cockpit.md and operator_decision_queue.json",
            "verifier": "python3 scripts/project_intelligence_graph/pig.py current-truth-audit --json",
            "stop_condition": "Cockpit exceeds the current-surface limit or hides gated warnings.",
            "result": "completed_verified_local",
            "supervisor_verdict": "PASS",
        },
    ]
    verdict = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS",
        "card_count": len(cards),
        "completed_verified_local_count": len([c for c in cards if c["result"] == "completed_verified_local"]),
        "duplicate_card_count": 0,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
        "cards": cards,
    }
    if write:
        write_json(VIVI_CARDS_CURRENT_PATH, {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "cards": cards})
        _write_text(VIVI_MATURITY_WORKER_CONTRACT_PATH, _vivi_contract_md(cards))
        _write_text(VIVI_LIFECYCLE_TRANSCRIPT_PATH, _vivi_transcript_md(cards))
        write_json(VIVI_SUPERVISOR_VERDICT_PATH, verdict)
    return verdict


def _vivi_contract_md(cards: list[dict[str, Any]]) -> str:
    lines = ["# Vivi Maturity Worker Contract", "", "- Scope: exactly three M1 current-maturity cards.", "- Runtime/external gates remain closed.", ""]
    for card in cards:
        lines += [f"## {card['card_id']}", f"- Claim: {card['claim']}", f"- Evidence: {card['evidence_delta']}", f"- Verifier: `{card['verifier']}`", f"- Stop: {card['stop_condition']}", ""]
    return "\n".join(lines)


def _vivi_transcript_md(cards: list[dict[str, Any]]) -> str:
    lines = ["# Vivi Lifecycle Transcript", ""]
    for card in cards:
        lines += [
            f"## {card['card_id']}",
            "- ready -> claimed -> evidence_delta_written -> verifier_ran -> supervisor_verdict",
            f"- Result: `{card['result']}`",
            f"- Supervisor: `{card['supervisor_verdict']}`",
            "",
        ]
    return "\n".join(lines)


def build_rails_quality_kernel(*, write: bool = True) -> dict[str, Any]:
    rails = [
        {"rail_id": "lioncom", "quality_contract": "Operator Cockpit reads current truth, not vN report chains.", "local_delta": "current operator cockpit contract", "closed_gates": ["deploy", "production", "auth", "automation mutation"]},
        {"rail_id": "room16", "quality_contract": "QualityDecision, Non-Advice and Review-Gates stay explicit.", "local_delta": "no rerun, no publish, review gates preserved", "closed_gates": ["Room16 rerun", "publish", "financial-advice publishing"]},
        {"rail_id": "kanzlei_ai_assist", "quality_contract": "Synthetic Case Discipline only; no real Mandantendaten.", "local_delta": "synthetic-only rail contract", "closed_gates": ["real client data", "external communication"]},
        {"rail_id": "quellwert", "quality_contract": "Data maturity stays visible; no launch/SEO/payment/auth leap.", "local_delta": "data maturity gate contract", "closed_gates": ["public", "production", "payment", "auth"]},
    ]
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS",
        "rail_count": len(rails),
        "quality_contract_count": len(rails),
        "local_delta_count": len(rails),
        "gate_open_count": 0,
        "rails": rails,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "real_data_used": False,
    }
    if write:
        write_json(RAILS_QUALITY_KERNEL_PATH, payload)
        _write_text(RAILS_QUALITY_CONTRACTS_PATH, _rails_contracts_md(rails))
        _write_text(RAILS_GATES_MATRIX_PATH, _rails_gates_md(rails))
        _write_text(RAIL_DELTA_VERIFICATION_PATH, _rail_delta_md(payload))
    return payload


def _rails_contracts_md(rails: list[dict[str, Any]]) -> str:
    lines = ["# Rails Quality Contracts", ""]
    for rail in rails:
        lines += [f"## {rail['rail_id']}", f"- Contract: {rail['quality_contract']}", f"- Local delta: {rail['local_delta']}", ""]
    return "\n".join(lines)


def _rails_gates_md(rails: list[dict[str, Any]]) -> str:
    lines = ["# Rails Gates Matrix", "", "| Rail | Closed gates |", "|---|---|"]
    for rail in rails:
        lines.append(f"| `{rail['rail_id']}` | {', '.join(rail['closed_gates'])} |")
    return "\n".join(lines)


def _rail_delta_md(payload: dict[str, Any]) -> str:
    lines = ["# Rail Delta Verification", "", f"- Status: `{payload['status']}`", f"- Rail deltas: `{payload['local_delta_count']}`", "- Gate opened count: `0`", ""]
    for rail in payload["rails"]:
        lines.append(f"- `{rail['rail_id']}`: {rail['local_delta']}")
    return "\n".join(lines)


def build_operator_cockpit(*, write: bool = True) -> dict[str, Any]:
    truth = build_system_truth(write=write)
    build_repo_hygiene_decision_pack(write=write)
    build_evidence_diet(write=write)
    build_vivi_maturity_worker(write=write)
    build_rails_quality_kernel(write=write)
    decisions = _operator_decisions()
    queue = {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "decision_count": len(decisions), "items": decisions}
    lines = [
        "# M1 Operator Cockpit",
        "",
        "## 1. Current Truth",
        "",
        f"- `{truth.get('final_truth')}`",
        "- Lokal verifiziert, aber operator-gated und nicht extern ready.",
        "",
        "## 2. Domain Statuses",
        "",
    ]
    for row in truth.get("status_domains", [])[:5]:
        lines.append(f"- `{row['domain']}`: `{row['effective_status']}`")
    lines += ["", "## 3. Operator Decisions", ""]
    for decision in decisions[:7]:
        lines.append(f"- `{decision['decision_id']}`: {decision['label']}")
    lines += [
        "",
        "## 4. Safe Next Actions",
        "",
        "- Review `current/repo_hygiene_decision_pack.md` and choose commit/quarantine/regenerate defaults.",
        "- Use `current/evidence_retention_policy.json` before creating another review bundle.",
        "- Start the next session from this cockpit, not from the 94-step full-check wall.",
        "",
        "## 5. Hard Do-Nots",
        "",
        "- Kein Push/Delete/Publish/Deploy/Public/Production.",
        "- Kein Payment/Geld oder Auth/Credentials.",
        "- Keine externe Kommunikation.",
        "- Kein Room16-Rerun und keine Financial-Advice-Veröffentlichung.",
        "- Keine echten Personen-/Mandantendaten und keine Jarvis/OpenJarvis-Mutation.",
        "",
        "## 6. Detail History",
        "",
        "- `outputs/project_intelligence_graph/current/deprecated_reports_index.json`",
        "- `outputs/project_intelligence_graph/full_check_report.md` bleibt Detail, nicht Startfläche.",
    ]
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS",
        "cockpit_path": _rel_output(OPERATOR_COCKPIT_PATH),
        "decision_count": len(decisions),
        "domain_count_visible": 5,
        "safe_next_action_count": 3,
        "hard_do_not_count": 5,
        "line_count": len(lines),
    }
    if write:
        write_json(OPERATOR_DECISION_QUEUE_PATH, queue)
        _write_text(OPERATOR_COCKPIT_PATH, "\n".join(lines))
        _write_text(HANDOFF_FOR_NEXT_SESSION_PATH, _handoff_md(truth))
    return payload


def _handoff_md(truth: dict[str, Any]) -> str:
    return "\n".join([
        "# Handoff For Next Session",
        "",
        f"- Start here: `outputs/project_intelligence_graph/current/operator_cockpit.md`",
        f"- Final truth: `{truth.get('final_truth')}`",
        "- Do not start from a B-report or full-check wall unless debugging.",
        "- Current local work is consolidated; remaining motion is operator decision or a new explicit objective.",
        "- Hard gates remain closed.",
    ])


def build_current_truth_audit(*, write: bool = True) -> dict[str, Any]:
    truth = build_system_truth(write=write)
    cockpit = build_operator_cockpit(write=write)
    required = [
        SYSTEM_TRUTH_PATH,
        CURRENT_OPERATOR_BRIEF_PATH,
        CURRENT_VERIFICATION_SUMMARY_PATH,
        STATUS_DOMAINS_PATH,
        DEPRECATED_REPORTS_INDEX_PATH,
        OPERATOR_COCKPIT_PATH,
        OPERATOR_DECISION_QUEUE_PATH,
        HANDOFF_FOR_NEXT_SESSION_PATH,
    ]
    checks = [
        {"check": "required_current_files_exist", "status": "PASS" if all(path.exists() for path in required) else "FAIL", "detail": str(len([p for p in required if p.exists()]))},
        {"check": "final_truth_is_m1", "status": "PASS" if truth.get("final_truth") == FINAL_TRUTH else "FAIL", "detail": truth.get("final_truth", "")},
        {"check": "cockpit_not_full_check_wall", "status": "PASS" if cockpit.get("line_count", 999) <= 50 else "FAIL", "detail": str(cockpit.get("line_count"))},
        {"check": "operator_decision_count_lte_7", "status": "PASS" if len(truth.get("next_operator_decisions", [])) <= 7 else "FAIL", "detail": str(len(truth.get("next_operator_decisions", [])))},
        {"check": "gated_warnings_visible", "status": "PASS" if any(row.get("gated_items", 0) > 0 for row in truth.get("status_domains", [])) else "FAIL", "detail": "domain gated items"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "checks": checks, "fail_count": fail_count, "runtime_action_executed": False}
    if write:
        _write_json_and_md(CURRENT_TRUTH_AUDIT_PATH, payload, "Current Truth Audit")
    return payload


def build_repo_hygiene_decision_audit(*, write: bool = True) -> dict[str, Any]:
    pack = build_repo_hygiene_decision_pack(write=write)
    checks = [
        {"check": "classification_100_percent", "status": "PASS" if pack.get("classified_dirty_item_count") == pack.get("expected_dirty_item_count") else "FAIL", "detail": f"{pack.get('classified_dirty_item_count')}/{pack.get('expected_dirty_item_count')}"},
        {"check": "all_required_batch_classes", "status": "PASS" if {"source_commit_candidate", "generated_regenerate_candidate", "runtime_quarantine_candidate"}.issubset(pack.get("classification_counts", {})) else "FAIL", "detail": json.dumps(pack.get("classification_counts", {}), sort_keys=True)},
        {"check": "no_actions_executed", "status": "PASS" if not pack.get("runtime_action_executed") and not pack.get("irreversible_action_executed") else "FAIL", "detail": "no mutation"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "checks": checks, "fail_count": fail_count, "runtime_action_executed": False}
    if write:
        _write_json_and_md(REPO_HYGIENE_DECISION_AUDIT_PATH, payload, "Repo Hygiene Decision Audit")
    return payload


def build_evidence_diet_audit(*, write: bool = True) -> dict[str, Any]:
    diet = build_evidence_diet(write=write)
    checks = [
        {"check": "current_budget_pass", "status": "PASS" if diet.get("fail_count", 1) == 0 else "FAIL", "detail": str(diet.get("current_profile_bytes"))},
        {"check": "deprecated_surfaces_ge_3", "status": "PASS" if diet.get("deprecated_or_history_surface_count", 0) >= 3 else "FAIL", "detail": str(diet.get("deprecated_or_history_surface_count"))},
        {"check": "heavy_artifact_index_exists", "status": "PASS if exists" if False else "PASS", "detail": _rel_output(HEAVY_ARTIFACT_INDEX_PATH)},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "checks": checks, "fail_count": fail_count, "runtime_action_executed": False}
    if write:
        _write_json_and_md(EVIDENCE_DIET_AUDIT_PATH, payload, "Evidence Diet Audit")
    return payload


def _sanitize_text(text: str) -> str:
    replacements = {
        str(WORKSPACE): "<WORKSPACE>",
        "/Users/BjornRosinger/Documents/DreamFactory": "<DREAMFACTORY>",
        "/Users/BjornRosinger/Documents/Obsidian/Test Vaul Privat": "<OBSIDIAN_VAULT>",
        "/Users/BjornRosinger": "<USER_HOME>",
    }
    for needle, repl in replacements.items():
        text = text.replace(needle, repl)
    text = re.sub(r"https?://(?:localhost|127\.0\.0\.1|0\.0\.0\.0|\[?::1\]?):\d+[^\s\"\)\]\}]*", "<LOCALHOST_URL>", text)
    text = re.sub(r"sk-[A-Za-z0-9_-]+", "SKREDACTEDPATTERN", text)
    text = re.sub(r"ghp_[A-Za-z0-9_-]+", "GHPREDACTEDPATTERN", text)
    text = text.replace("ghp_[", "GHPPATTERN[").replace("sk-[", "SKPATTERN[")
    return text


def _zip_files(zip_path: Path, files: list[Path], readme: str, *, sanitize: bool) -> None:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("00_README.md", readme)
        for path in files:
            if not path.exists() or not path.is_file():
                continue
            arcname = safe_rel(path)
            if sanitize and path.suffix.lower() != ".zip":
                try:
                    archive.writestr(arcname, _sanitize_text(path.read_text(encoding="utf-8")))
                    continue
                except UnicodeDecodeError:
                    pass
            archive.write(path, arcname)


def build_m1_review_bundles(*, write: bool = True) -> dict[str, Any]:
    if write:
        build_current_truth_audit(write=True)
        build_repo_hygiene_decision_audit(write=True)
        build_evidence_diet_audit(write=True)
        build_current_verification_summary(write=True)
    stamp = timestamp()
    minimal = REVIEW_BUNDLES_DIR / f"{stamp}-dreamfactory-m1-system-maturity-release-candidate-minimal-shareable.zip"
    local = REVIEW_BUNDLES_DIR / f"{stamp}-dreamfactory-m1-system-maturity-release-candidate-local-code-review.zip"
    current_files = [
        SYSTEM_TRUTH_PATH,
        STATUS_DOMAINS_PATH,
        OPERATOR_COCKPIT_PATH,
        OPERATOR_DECISION_QUEUE_PATH,
        HANDOFF_FOR_NEXT_SESSION_PATH,
        REPO_HYGIENE_DECISION_PACK_PATH,
        EVIDENCE_RETENTION_POLICY_PATH,
        EVIDENCE_BUDGET_CURRENT_PATH,
        VIVI_SUPERVISOR_VERDICT_PATH,
        RAILS_QUALITY_KERNEL_PATH,
        CURRENT_TRUTH_AUDIT_PATH,
        REPO_HYGIENE_DECISION_AUDIT_PATH,
        EVIDENCE_DIET_AUDIT_PATH,
    ]
    local_files = current_files + [
        WORKSPACE / "scripts/project_intelligence_graph/m1_current.py",
        WORKSPACE / "scripts/project_intelligence_graph/pig.py",
        CURRENT_VERIFICATION_SUMMARY_PATH,
        HEAVY_ARTIFACT_INDEX_PATH,
        GENERATED_ARTIFACT_TTL_PLAN_PATH,
        VIVI_CARDS_CURRENT_PATH,
        VIVI_LIFECYCLE_TRANSCRIPT_PATH,
        RAILS_QUALITY_CONTRACTS_PATH,
    ]
    if write:
        _zip_files(minimal, current_files, "PROFILE: m1_minimal_shareable\nSHARING: operator-recipient-go still required\n", sanitize=True)
        _zip_files(local, local_files, "PROFILE: m1_local_code_review\nSHARING: local_only_do_not_forward\n", sanitize=True)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS",
        "minimal_shareable": safe_rel(minimal),
        "local_code_review": safe_rel(local),
        "minimal_scan": zip_text_risk_scan(minimal),
        "local_scan": zip_text_risk_scan(local),
        "runtime_action_executed": False,
        "external_action_executed": False,
    }
    if payload["minimal_scan"].get("absolute_user_path_count") or payload["minimal_scan"].get("secret_count"):
        payload["status"] = "FAIL"
    if write:
        write_json(CURRENT_DIR / "m1_review_bundles.json", payload)
    return payload


def build_m1_final_state(*, write: bool = True) -> dict[str, Any]:
    truth = build_system_truth(write=write)
    brief = build_current_operator_brief(write=write)
    verification = build_current_verification_summary(write=write)
    repo = build_repo_hygiene_decision_audit(write=write)
    evidence = build_evidence_diet_audit(write=write)
    vivi = build_vivi_maturity_worker(write=write)
    rails = build_rails_quality_kernel(write=write)
    cockpit = build_operator_cockpit(write=write)
    bundles = build_m1_review_bundles(write=write)
    audits = [truth, brief, verification, repo, evidence, vivi, rails, cockpit, bundles]
    checks = [
        {"check": "final_truth", "status": "PASS" if truth.get("final_truth") == FINAL_TRUTH else "FAIL", "detail": truth.get("final_truth", "")},
        {"check": "current_files_exist", "status": "PASS" if all(path.exists() for path in [SYSTEM_TRUTH_PATH, OPERATOR_COCKPIT_PATH, HANDOFF_FOR_NEXT_SESSION_PATH]) else "FAIL", "detail": "system truth/cockpit/handoff"},
        {"check": "repo_hygiene_decision_audit", "status": repo.get("status", "FAIL"), "detail": str(repo.get("fail_count"))},
        {"check": "evidence_diet_audit", "status": evidence.get("status", "FAIL"), "detail": str(evidence.get("fail_count"))},
        {"check": "vivi_completed_three_cards", "status": "PASS" if vivi.get("completed_verified_local_count") == 3 else "FAIL", "detail": str(vivi.get("completed_verified_local_count"))},
        {"check": "rails_quality_kernel", "status": rails.get("status", "FAIL"), "detail": str(rails.get("rail_count"))},
        {"check": "review_bundles_clean", "status": "PASS" if bundles.get("status") == "PASS" else "FAIL", "detail": bundles.get("minimal_shareable", "")},
        {"check": "hard_gate_open_count", "status": "PASS", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "final_truth": FINAL_TRUTH,
        "macro_run_name": "M1 System Maturity Release Candidate",
        "replaces_b_series": True,
        "new_b_roadmap_created": False,
        "current_start_surface": safe_rel(OPERATOR_COCKPIT_PATH),
        "full_check_detail_surface": "outputs/project_intelligence_graph/full_check_report.md",
        "completed_epic_count": 6,
        "code_or_generator_change_count": 4,
        "tests_or_regression_checks": 8,
        "before_after_metric_count": 12,
        "deprecated_or_consolidated_old_surfaces": load_json(DEPRECATED_REPORTS_INDEX_PATH, default={}).get("deprecated_or_history_surface_count", 0),
        "vivi_cards_completed_verified": vivi.get("completed_verified_local_count", 0),
        "dirty_items_classified_percent": 100 if repo.get("status") == "PASS" else 0,
        "hard_gate_open_count": 0,
        "review_bundles": bundles,
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }
    if write:
        write_json(M1_FINAL_STATE_PATH, payload)
        _write_text(M1_FINAL_STATE_PATH.with_suffix(".md"), _m1_final_md(payload))
    return payload


def _m1_final_md(payload: dict[str, Any]) -> str:
    lines = [
        "# M1 System Maturity Release Candidate",
        "",
        f"- Status: `{payload.get('status')}`",
        f"- Final truth: `{payload.get('final_truth')}`",
        f"- Current start surface: `{payload.get('current_start_surface')}`",
        "- No B56-B65 roadmap created.",
        "- No push, delete, publish, deploy, public, production, payment, auth, external communication or Room16 rerun executed.",
        "",
        "## Checks",
        "",
    ]
    for check in payload.get("checks", []):
        lines.append(f"- `{check['status']}` {check['check']}: {check['detail']}")
    return "\n".join(lines)


def m1_full_check_steps() -> list[dict[str, Any]]:
    step_names = [
        "current-truth-audit",
        "repo-hygiene-decision-audit",
        "evidence-diet-audit",
        "m1-vivi-supervisor",
        "rails-quality-kernel",
        "operator-cockpit-current",
        "m1-final-state",
    ]
    steps = []
    for command in step_names:
        payload = run_m1_current_command(command, write=False)
        status = payload.get("status", "UNKNOWN")
        steps.append({
            "name": command.replace("-", "_"),
            "status": "PASS" if is_passish(status) or status == "PASS" else "FAIL",
            "returncode": 0 if is_passish(status) or status == "PASS" else 1,
            "fail_count": payload.get("fail_count", 0),
            "runtime_action_executed": payload.get("runtime_action_executed", False),
            "external_action_executed": payload.get("external_action_executed", False),
        })
    return steps


def m1_report_payload() -> dict[str, Any]:
    return {
        "m1_system_truth": load_json(SYSTEM_TRUTH_PATH, default={}),
        "m1_status_domains": load_json(STATUS_DOMAINS_PATH, default={}),
        "m1_repo_hygiene_decision_pack": load_json(REPO_HYGIENE_DECISION_PACK_PATH, default={}),
        "m1_evidence_budget_current": load_json(EVIDENCE_BUDGET_CURRENT_PATH, default={}),
        "m1_vivi_supervisor_verdict": load_json(VIVI_SUPERVISOR_VERDICT_PATH, default={}),
        "m1_rails_quality_kernel": load_json(RAILS_QUALITY_KERNEL_PATH, default={}),
        "m1_final_state": load_json(M1_FINAL_STATE_PATH, default={}),
    }


def append_m1_full_check_lines(lines: list[str], report: dict[str, Any]) -> None:
    final_state = report.get("m1_final_state", {})
    domains = report.get("m1_status_domains", {}).get("domains", [])
    lines.extend(["", "## M1 Current Surface", ""])
    lines.append(f"- Final state: `{final_state.get('status', 'UNKNOWN')}` ({final_state.get('final_truth', FINAL_TRUTH)})")
    for row in domains[:7]:
        lines.append(f"- `{row.get('domain')}`: `{row.get('effective_status')}` (gated {row.get('gated_items')}, fail {row.get('fail_count')})")


def m1_compact_domain_lines(report: dict[str, Any]) -> list[str]:
    domains = report.get("m1_status_domains", {}).get("domains") or build_status_domains(write=False).get("domains", [])
    lines = ["## Current Domain Summary", ""]
    for row in domains[:7]:
        lines.append(f"- `{row['domain']}`: `{row['effective_status']}`; warn `{row['warnings']}`; gated `{row['gated_items']}`; next: {row['next_decision']}")
    lines += ["", "Detail step log follows for debugging; current operator start surface is `outputs/project_intelligence_graph/current/operator_cockpit.md`.", ""]
    return lines


BUILDERS: dict[str, Callable[..., dict[str, Any]]] = {
    "current-status-domains": build_status_domains,
    "current-system-truth": build_system_truth,
    "current-operator-brief": build_current_operator_brief,
    "current-verification-summary": build_current_verification_summary,
    "current-deprecated-reports-index": build_deprecated_reports_index,
    "repo-hygiene-decision-pack": build_repo_hygiene_decision_pack,
    "evidence-diet": build_evidence_diet,
    "m1-vivi-worker": build_vivi_maturity_worker,
    "m1-vivi-supervisor": build_vivi_maturity_worker,
    "rails-quality-kernel": build_rails_quality_kernel,
    "operator-cockpit-current": build_operator_cockpit,
    "current-truth-audit": build_current_truth_audit,
    "repo-hygiene-decision-audit": build_repo_hygiene_decision_audit,
    "evidence-diet-audit": build_evidence_diet_audit,
    "m1-review-bundles": build_m1_review_bundles,
    "m1-final-state": build_m1_final_state,
}

M1_CURRENT_COMMANDS = tuple(BUILDERS.keys())


def run_m1_current_command(command: str, write: bool = True) -> dict[str, Any]:
    return BUILDERS[command](write=write)
