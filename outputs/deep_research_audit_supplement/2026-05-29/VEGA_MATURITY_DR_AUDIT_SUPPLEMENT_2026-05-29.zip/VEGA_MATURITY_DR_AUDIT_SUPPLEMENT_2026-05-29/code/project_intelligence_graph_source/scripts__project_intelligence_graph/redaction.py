"""Redaction helpers for shareable local evidence."""

from __future__ import annotations

from pathlib import Path
from typing import Iterable


OPERATOR_IDENTITY_PATTERNS = [
    "Björn",
    "BjornRosinger",
    "Bjorn Rosinger",
]
GENERIC_PRIVATE_PATH_PREFIX = "/Users/"
GENERIC_PRIVATE_PATH_TOKEN = [REDACTED]


def _path_text(path: Path | str | None) -> str:
    if path is None:
        return ""
    return str(Path(path).expanduser().resolve())


def redaction_pairs(
    *,
    workspace: Path | str | None = None,
    vault: Path | str | None = None,
    home: Path | str | None = None,
) -> list[tuple[str, str]]:
    pairs = [
        (_path_text(workspace), "<WORKSPACE>"),
        (_path_text(vault), "<VAULT>"),
        (_path_text(home) if home is not None else _path_text(Path.home()), "<LOCAL_HOME>"),
    ]
    return sorted([(raw, token) for raw, token in pairs if raw], key=lambda item: len(item[0]), reverse=True)


def redact_text(
    text: str,
    *,
    workspace: Path | str | None = None,
    vault: Path | str | None = None,
    home: Path | str | None = None,
) -> str:
    redacted = text
    for raw, token in redaction_pairs(workspace=workspace, vault=vault, home=home):
        redacted = redacted.replace(raw, token)
    redacted = redacted.replace(GENERIC_PRIVATE_PATH_PREFIX, GENERIC_PRIVATE_PATH_TOKEN)
    for raw in OPERATOR_IDENTITY_PATTERNS:
        redacted = redacted.replace(raw, "<OPERATOR>")
    return redacted


def scan_private_path_hits(
    text: str,
    *,
    workspace: Path | str | None = None,
    vault: Path | str | None = None,
    home: Path | str | None = None,
) -> list[dict[str, str]]:
    hits: list[dict[str, str]] = []
    for raw, token in redaction_pairs(workspace=workspace, vault=vault, home=home):
        if raw in text:
            hits.append({"path": raw, "token": token})
    if GENERIC_PRIVATE_PATH_PREFIX in text and not hits:
        hits.append({"path": GENERIC_PRIVATE_PATH_PREFIX, "token": GENERIC_PRIVATE_PATH_TOKEN})
    return hits


def scan_operator_identity_hits(text: str) -> list[dict[str, str]]:
    hits: list[dict[str, str]] = []
    for raw in OPERATOR_IDENTITY_PATTERNS:
        if raw in text:
            hits.append({"pattern": raw, "token": "<OPERATOR>"})
    return hits


def scan_redaction_hits(
    text: str,
    *,
    workspace: Path | str | None = None,
    vault: Path | str | None = None,
    home: Path | str | None = None,
) -> dict[str, list[dict[str, str]]]:
    return {
        "private_path_hits": scan_private_path_hits(text, workspace=workspace, vault=vault, home=home),
        "operator_identity_hits": scan_operator_identity_hits(text),
    }


def redact_records(records: Iterable[str], **paths: Path | str | None) -> list[str]:
    return [redact_text(record, **paths) for record in records]
