"""Dirt status semantics helpers."""

from __future__ import annotations

from typing import Any


def derive_dirt_semantics(dirt_v2: dict[str, Any], repo_hygiene: dict[str, Any]) -> dict[str, Any]:
    unknown_dirty = int(dirt_v2.get("unknown_dirty_count", 0) or repo_hygiene.get("unknown_dirty_count", 0) or 0)
    residual_items = int(dirt_v2.get("residual_item_count", 0) or 0)
    non_foreign_dirty_reduced = bool(dirt_v2.get("non_foreign_dirty_reduced", False))
    residual_all_gated = bool(dirt_v2.get("residual_items_all_gated", False))
    classification_ok = unknown_dirty == 0 and residual_all_gated
    hard_actions_closed = not any([
        dirt_v2.get("hard_delete_executed"),
        dirt_v2.get("push_executed"),
        dirt_v2.get("commit_executed"),
    ])
    if non_foreign_dirty_reduced:
        reduction_status = "PASS"
        overall_burndown_status = "PASS"
    elif classification_ok and residual_items:
        reduction_status = "OPERATOR_GATED_NOT_REDUCED"
        overall_burndown_status = "WARN"
    else:
        reduction_status = "UNKNOWN"
        overall_burndown_status = "FAIL"
    return {
        "classification_status": "PASS" if classification_ok else "FAIL",
        "reduction_status": reduction_status,
        "overall_burndown_status": overall_burndown_status,
        "dirt_reduction_semantics_honest": True,
        "unknown_dirty_count": unknown_dirty,
        "residual_item_count": residual_items,
        "non_foreign_dirty_reduced": non_foreign_dirty_reduced,
        "residual_items_all_gated": residual_all_gated,
        "hard_actions_closed": hard_actions_closed,
    }
