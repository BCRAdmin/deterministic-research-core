"""Pack replay full-check mode with explicit dependency stubs."""

from __future__ import annotations

import datetime as dt
import json
from pathlib import Path
from typing import Any

from replay_pack import build_replay_report
from report_markdown import render_report_markdown


STUB_MANIFEST_RELATIVE_PATH = Path("pack_replay_stubs.json")
DEPENDENCY_MAP_RELATIVE_PATH = Path("outputs/project_intelligence_graph/full_check_dependency_map.json")
REPORT_JSON_NAME = "pack_replay_full_check_report.json"
REPORT_MD_NAME = "pack_replay_full_check_report.md"
SYSTEM_TRUTH_STATUS = "PASS_WITH_WARNINGS"
STUB_CATEGORY = "should_be_stubbed_for_pack_replay"
CONFIGURED_CATEGORY = "should_be_configured_next"
OPTIONAL_CATEGORY = "optional_runtime_input"
BLOCKED_CATEGORIES = {"should_remain_blocked", "original_workspace_only"}


def _read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _check(name: str, status: str, detail: str, **extra: Any) -> dict[str, Any]:
    return {"check": name, "status": status, "detail": detail, **extra}


def _dependencies(dependency_map: dict[str, Any], *, category: str | None = None, required_for_pack: bool | None = None) -> list[dict[str, Any]]:
    rows = [row for row in dependency_map.get("dependencies", []) if isinstance(row, dict)]
    if category is not None:
        rows = [row for row in rows if row.get("category") == category]
    if required_for_pack is not None:
        rows = [row for row in rows if bool(row.get("required_for_unpacked_pack_full_check")) is required_for_pack]
    return rows


def _ids(rows: list[dict[str, Any]]) -> set[str]:
    return {str(row.get("dependency_id")) for row in rows if row.get("dependency_id")}


def _manifest_ids(manifest: dict[str, Any], section: str) -> set[str]:
    ids: set[str] = set()
    for row in manifest.get(section, []):
        if isinstance(row, dict) and row.get("dependency_id"):
            ids.add(str(row["dependency_id"]))
    return ids


def _missing_stub_files(pack_root: Path, manifest: dict[str, Any]) -> list[str]:
    missing: list[str] = []
    for row in manifest.get("stubs", []):
        if not isinstance(row, dict):
            continue
        stub_path = row.get("stub_path")
        if not stub_path:
            missing.append(f"{row.get('dependency_id', 'unknown')}: missing stub_path")
            continue
        if not (pack_root / str(stub_path)).exists():
            missing.append(f"{row.get('dependency_id', 'unknown')}: {stub_path}")
    return missing


def _status_from_checks(checks: list[dict[str, Any]]) -> str:
    if any(check.get("status") == "FAIL" for check in checks):
        return "FAIL"
    if any(check.get("status") == "ACTION_REQUIRED" for check in checks):
        return "ACTION_REQUIRED"
    return "PASS"


def build_pack_replay_full_check(
    pack_root: Path,
    *,
    output_dir: Path | None = None,
    run_commands: bool = True,
    write: bool = True,
) -> dict[str, Any]:
    """Verify runnable-pack claims without executing original-workspace full-check dependencies."""

    pack_root = Path(pack_root).resolve()
    output_dir = Path(output_dir).resolve() if output_dir else pack_root / "outputs" / "project_intelligence_graph"
    manifest_path = pack_root / STUB_MANIFEST_RELATIVE_PATH
    dependency_map_path = pack_root / DEPENDENCY_MAP_RELATIVE_PATH
    checks: list[dict[str, Any]] = []

    manifest = _read_json(manifest_path, default={})
    if not manifest_path.exists():
        checks.append(_check("pack_replay_stub_manifest_present", "ACTION_REQUIRED", f"Missing {STUB_MANIFEST_RELATIVE_PATH}"))
    elif not isinstance(manifest, dict) or not manifest:
        checks.append(_check("pack_replay_stub_manifest_valid_json", "FAIL", f"Invalid or empty {STUB_MANIFEST_RELATIVE_PATH}"))
        manifest = {}
    else:
        checks.append(_check("pack_replay_stub_manifest_present", "PASS", f"Loaded {STUB_MANIFEST_RELATIVE_PATH}"))

    dependency_map = _read_json(dependency_map_path, default={})
    if not dependency_map_path.exists():
        checks.append(_check("full_check_dependency_map_present", "ACTION_REQUIRED", f"Missing {DEPENDENCY_MAP_RELATIVE_PATH}"))
    elif not isinstance(dependency_map, dict) or not dependency_map.get("dependencies"):
        checks.append(_check("full_check_dependency_map_valid", "FAIL", "Dependency map is invalid or has no dependencies"))
        dependency_map = {}
    else:
        checks.append(_check("full_check_dependency_map_present", "PASS", f"Loaded {len(dependency_map.get('dependencies', []))} dependencies"))

    replay_report = build_replay_report(pack_root, run_commands=run_commands)
    replay_status = replay_report.get("status", "FAIL")
    checks.append(_check(
        "runnable_root_replay",
        replay_status if replay_status in {"PASS", "FAIL"} else "ACTION_REQUIRED",
        f"replay_pack status={replay_status} fail={replay_report.get('fail_count', 0)} action_required={replay_report.get('action_required_count', 0)}",
        report=replay_report,
    ))

    required_stubs = _dependencies(dependency_map, category=STUB_CATEGORY, required_for_pack=True)
    missing_stub_coverage = sorted(_ids(required_stubs) - _manifest_ids(manifest, "stubs"))
    missing_stub_files = _missing_stub_files(pack_root, manifest)
    if missing_stub_coverage or missing_stub_files:
        details = []
        if missing_stub_coverage:
            details.append("missing dependency coverage: " + ", ".join(missing_stub_coverage))
        if missing_stub_files:
            details.append("missing stub files: " + ", ".join(missing_stub_files))
        checks.append(_check("required_pack_replay_stubs_covered", "ACTION_REQUIRED", "; ".join(details)))
    else:
        checks.append(_check("required_pack_replay_stubs_covered", "PASS", f"{len(required_stubs)} required stub dependencies covered"))

    required_configured = _dependencies(dependency_map, category=CONFIGURED_CATEGORY, required_for_pack=True)
    missing_configured = sorted(_ids(required_configured) - _manifest_ids(manifest, "configured_dependencies"))
    if missing_configured:
        checks.append(_check("configured_dependency_coverage", "ACTION_REQUIRED", "missing configured dependency handling: " + ", ".join(missing_configured)))
    else:
        checks.append(_check("configured_dependency_coverage", "PASS", f"{len(required_configured)} configured-next dependencies documented"))

    required_optional = _dependencies(dependency_map, category=OPTIONAL_CATEGORY, required_for_pack=True)
    missing_optional = sorted(_ids(required_optional) - _manifest_ids(manifest, "optional_runtime_inputs"))
    if missing_optional:
        checks.append(_check("optional_runtime_input_handling", "ACTION_REQUIRED", "missing optional input handling: " + ", ".join(missing_optional)))
    else:
        checks.append(_check("optional_runtime_input_handling", "PASS", f"{len(required_optional)} optional runtime inputs documented"))

    required_blocked = [
        row for row in _dependencies(dependency_map, required_for_pack=True)
        if row.get("category") in BLOCKED_CATEGORIES
    ]
    missing_blocked = sorted(_ids(required_blocked) - _manifest_ids(manifest, "blocked_original_workspace_only"))
    if missing_blocked:
        checks.append(_check("blocked_dependency_truth", "ACTION_REQUIRED", "missing blocked dependency truth: " + ", ".join(missing_blocked)))
    else:
        checks.append(_check("blocked_dependency_truth", "PASS", f"{len(required_blocked)} required blocked dependencies documented"))

    status = _status_from_checks(checks)
    report = {
        "schema_version": 1,
        "generated_at": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "status": status,
        "system_truth_status": SYSTEM_TRUTH_STATUS,
        "mode": "pack_replay_full_check",
        "pack_root": str(pack_root),
        "full_check_claim": "pack_replay_verified_not_original_workspace_full_check",
        "full_check_portability_status": "pack_replay_mode_with_explicit_stubs",
        "original_workspace_full_check_status": "ORIGINAL_WORKSPACE_ONLY_NOT_RUN",
        "original_workspace_full_check_claim_allowed": False,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "production_gate_opened": False,
        "forbidden_actions_observed": [],
        "stub_manifest_path": str(manifest_path),
        "dependency_map_path": str(dependency_map_path),
        "stub_count": len(manifest.get("stubs", [])) if isinstance(manifest.get("stubs"), list) else 0,
        "configured_dependency_count": len(manifest.get("configured_dependencies", [])) if isinstance(manifest.get("configured_dependencies"), list) else 0,
        "optional_runtime_input_count": len(manifest.get("optional_runtime_inputs", [])) if isinstance(manifest.get("optional_runtime_inputs"), list) else 0,
        "required_stub_dependency_count": len(required_stubs),
        "required_configured_dependency_count": len(required_configured),
        "required_optional_runtime_input_count": len(required_optional),
        "fail_count": sum(1 for check in checks if check.get("status") == "FAIL"),
        "action_required_count": sum(1 for check in checks if check.get("status") == "ACTION_REQUIRED"),
        "steps": checks,
        "checks": checks,
        "warnings": [
            "This mode proves runnable pack replay/help/tests plus explicit dependency stub coverage.",
            "It does not execute or claim original-workspace full-check portability.",
            "M12 remains PASS_WITH_WARNINGS until full-check is fully portable or intentionally kept original-workspace-only.",
        ],
    }
    if write:
        _write_json(output_dir / REPORT_JSON_NAME, report)
        (output_dir / REPORT_MD_NAME).write_text(render_report_markdown("Pack Replay Full Check", report), encoding="utf-8")
    return report
