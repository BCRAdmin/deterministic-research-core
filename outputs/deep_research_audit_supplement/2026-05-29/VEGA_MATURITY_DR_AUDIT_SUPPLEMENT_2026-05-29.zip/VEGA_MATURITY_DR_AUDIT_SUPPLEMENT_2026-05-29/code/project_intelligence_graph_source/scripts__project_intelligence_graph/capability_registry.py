#!/usr/bin/env python3
"""Capability registry for Thin Roles, Thick Rails."""

from __future__ import annotations

import datetime as dt
import json
from collections import Counter
from pathlib import Path
from typing import Any


ALLOWED_TYPES = {
    "sandbox",
    "capability",
    "benchmark",
    "gate",
    "review_mode",
    "report_gate",
    "policy_gate",
}

ALLOWED_AGENTIZATION_STATUS = {
    "capability",
    "candidate_agent",
    "agent_approved",
    "agent_rejected",
}

REQUIRED_RECORD_FIELDS = [
    "capability_id",
    "canonical_name",
    "aliases",
    "type",
    "runtime_classification",
    "source_repo_or_rule",
    "is",
    "is_not",
    "trigger",
    "when_not_to_use",
    "allowed_actions",
    "forbidden_actions",
    "evidence_note",
    "verifier",
    "fresh_session_budget",
    "agentization_status",
    "agentization_gate",
    "is_agent",
    "runtime_action_executed",
    "external_action_executed",
    "irreversible_action_executed",
]

REQUIRED_TELEMETRY_EVENT_FIELDS = [
    "event_id",
    "capability_id",
    "triggered_at",
    "trigger",
    "project",
    "outcome",
    "verifier",
    "evidence",
    "value_metrics",
    "value_note",
    "agent_candidate_signal",
]

TELEMETRY_METRIC_FIELDS = [
    "prevented_issue_count",
    "time_saved_estimate_minutes",
    "better_document_count",
    "risk_blocked_count",
    "verified_surface_count",
]


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def registry_paths(output_dir: Path) -> dict[str, Path]:
    return {
        "registry_json": output_dir / "capability_registry.json",
        "registry_md": output_dir / "capability_registry.md",
        "audit_json": output_dir / "capability_registry_audit.json",
        "audit_md": output_dir / "capability_registry_audit.md",
        "telemetry_json": output_dir / "capability_registry_telemetry.json",
        "telemetry_md": output_dir / "capability_registry_telemetry.md",
        "shannon_contract_json": output_dir / "shannon_security_sandbox_contract.json",
        "shannon_contract_md": output_dir / "shannon_security_sandbox_contract.md",
        "fresh_session_budget_json": output_dir / "fresh_session_context_budget.json",
        "fresh_session_budget_md": output_dir / "fresh_session_context_budget.md",
        "background_quality_gates_json": output_dir / "background_quality_gates.json",
        "background_quality_gates_md": output_dir / "background_quality_gates.md",
        "agentization_gate_json": output_dir / "agentization_decision_gate.json",
        "agentization_gate_md": output_dir / "agentization_decision_gate.md",
        "agent_product_contract_json": output_dir / "agent_product_maturity_contract.json",
        "agent_product_contract_md": output_dir / "agent_product_maturity_contract.md",
    }


def telemetry_schema_path(docs_dir: Path) -> Path:
    return docs_dir / "CAPABILITY_TELEMETRY_SCHEMA.json"


def telemetry_policy_path(docs_dir: Path) -> Path:
    return docs_dir / "CAPABILITY_TELEMETRY_POLICY.md"


def capability_usage_ledger_path(docs_dir: Path) -> Path:
    return docs_dir / "CAPABILITY_USAGE_LEDGER.json"


def agentization_gate_schema_path(docs_dir: Path) -> Path:
    return docs_dir / "AGENTIZATION_DECISION_GATE_SCHEMA.json"


def agentization_gate_policy_path(docs_dir: Path) -> Path:
    return docs_dir / "AGENTIZATION_DECISION_GATE_POLICY.md"


def agent_product_maturity_schema_path(docs_dir: Path) -> Path:
    return docs_dir / "AGENT_PRODUCT_MATURITY_CONTRACT_SCHEMA.json"


def agent_product_maturity_policy_path(docs_dir: Path) -> Path:
    return docs_dir / "AGENT_PRODUCT_MATURITY_CONTRACT_POLICY.md"


def default_capability_records() -> list[dict[str, Any]]:
    shared_budget = {
        "max_core_notes": 4,
        "entrypoints": [
            "VEGA_START_HERE.md",
            "Decision - Thin Roles Thick Rails",
            "capability_registry.json",
            "relevant project or rule note only",
        ],
        "detail_loading_rule": "Load detail reports only after the capability synopsis identifies the needed surface.",
    }
    return [
        {
            "capability_id": "shannon_security_sandbox",
            "canonical_name": "Shannon Security Sandbox",
            "aliases": ["Shannon", "Shanon", "KeygraphHQ/shannon"],
            "type": "sandbox",
            "runtime_classification": "sandbox_only",
            "source_repo_or_rule": {
                "kind": "github_repo",
                "ref": "KeygraphHQ/shannon",
                "license": "AGPL-3.0",
                "audit_note": "DreamFactory System/Agent Stack/GitHub Star Audit - 2026-05-28",
                "contract": "Canonical/Rules/Rule - Shannon Security Sandbox Contract",
            },
            "is": "A named security sandbox for authorized local exploit, PoC and scope-bound security learning.",
            "is_not": "Not a general security agent, not a live scanner, not a credentialed production worker.",
            "trigger": [
                "authorized security review",
                "local test app",
                "exploit or PoC verification",
                "security sandbox learning run",
            ],
            "when_not_to_use": [
                "live customer system",
                "third-party target without written authorization",
                "unclear scope",
                "credentialed or public network action",
            ],
            "allowed_actions": [
                "read documentation and prior audit notes",
                "prepare a sandbox plan",
                "check written scope and boundary gates",
                "run only isolated local tests after explicit operator go",
            ],
            "forbidden_actions": [
                "scan live, customer or third-party systems",
                "set up or use real credentials",
                "start Docker workers against external targets without operator go",
                "copy AGPL code into proprietary runtime without legal decision",
                "publish exploit findings without human verification",
            ],
            "evidence_note": "Canonical/Rules/Rule - Shannon Security Sandbox Contract; Canonical/Decisions/Decision - Thin Roles Thick Rails; Rule - External Repo Audit Standard",
            "verifier": [
                "capability_registry_audit.shannon_alias_unique",
                "capability_registry_audit.sandbox_gates_present",
                "capability_registry_audit.no_runtime_action_executed",
            ],
            "fresh_session_budget": shared_budget,
            "operator_gate_required": True,
            "agentization_status": "capability",
            "agentization_gate": {
                "eligible": False,
                "status": "not_agent",
                "reason": "Risk and licensing require sandbox rails, not a persistent autonomous agent.",
            },
            "maturity": "manual",
            "is_agent": False,
            "runtime_action_executed": False,
            "external_action_executed": False,
            "irreversible_action_executed": False,
        },
        {
            "capability_id": "codegraph_pig_lens",
            "canonical_name": "CodeGraph PIG Lens",
            "aliases": ["CodeGraph", "colbymchenry/codegraph"],
            "type": "capability",
            "runtime_classification": "pattern_harvest",
            "source_repo_or_rule": {"kind": "github_repo", "ref": "colbymchenry/codegraph", "license": "unknown"},
            "is": "A graph-analysis lens for improving PIG codebase understanding and dependency mapping.",
            "is_not": "Not a new agent, not a replacement for PIG, not a runtime dependency by default.",
            "trigger": ["large codebase navigation", "dependency map review", "PIG graph quality improvement"],
            "when_not_to_use": ["small single-file edits", "when existing PIG search is enough", "unverified external install path"],
            "allowed_actions": ["harvest concepts", "compare local graph outputs", "write adapter notes"],
            "forbidden_actions": ["install as global runtime by default", "replace PIG source of truth", "send private code externally"],
            "evidence_note": "DreamFactory System/Agent Stack/GitHub Star Audit - 2026-05-28",
            "verifier": ["capability_registry_audit.no_agent_confusion", "local graph output comparison before adoption"],
            "fresh_session_budget": shared_budget,
            "operator_gate_required": False,
            "agentization_status": "capability",
            "agentization_gate": {"eligible": False, "status": "not_agent", "reason": "Useful as a PIG lens, not as identity."},
            "maturity": "seed",
            "is_agent": False,
            "runtime_action_executed": False,
            "external_action_executed": False,
            "irreversible_action_executed": False,
        },
        {
            "capability_id": "codeneedle_model_benchmark",
            "canonical_name": "Codeneedle Model Benchmark",
            "aliases": ["Codeneedle", "alexziskind1/codeneedle"],
            "type": "benchmark",
            "runtime_classification": "benchmark_harness",
            "source_repo_or_rule": {"kind": "github_repo", "ref": "alexziskind1/codeneedle", "license": "unknown"},
            "is": "A model and coding-agent comparability harness for audits and LLM evaluation tasks.",
            "is_not": "Not an active product runtime and not something to embed into every project.",
            "trigger": ["LLM comparison", "coding-agent audit", "provider quality benchmark"],
            "when_not_to_use": ["normal feature work", "when a simple unit test answers the question", "without benchmark scope"],
            "allowed_actions": ["define evaluation cases", "run local shadow comparisons", "report model tradeoffs"],
            "forbidden_actions": ["treat benchmark score as production truth", "publish provider claims without evidence"],
            "evidence_note": "DreamFactory System/Agent Stack/GitHub Star Audit - 2026-05-28",
            "verifier": ["benchmark fixture present", "results include model/date/scope", "no production action executed"],
            "fresh_session_budget": shared_budget,
            "operator_gate_required": False,
            "agentization_status": "capability",
            "agentization_gate": {"eligible": False, "status": "not_agent", "reason": "Benchmark mode is sufficient."},
            "maturity": "seed",
            "is_agent": False,
            "runtime_action_executed": False,
            "external_action_executed": False,
            "irreversible_action_executed": False,
        },
        {
            "capability_id": "design_quality_gate",
            "canonical_name": "Design Quality Gate",
            "aliases": ["Design Gate", "Quality Design Gate"],
            "type": "gate",
            "runtime_classification": "background_quality_gate",
            "source_repo_or_rule": {"kind": "internal_rule", "ref": "Frontend guidance and project UI standards"},
            "is": "A background UI quality gate for density, domain fit, component choice, responsiveness and readability.",
            "is_not": "Not a Design agent, not a persona, not a marketing-page generator.",
            "trigger": ["frontend build", "UI audit", "dashboard or tool surface change"],
            "when_not_to_use": ["backend-only change", "throwaway internal script without UI"],
            "allowed_actions": ["check layout density", "check responsive fit", "flag generic AI UI", "request screenshot verifier"],
            "forbidden_actions": ["invent new brand persona", "replace product requirements with taste alone"],
            "evidence_note": "Decision - Thin Roles Thick Rails; frontend design instructions",
            "verifier": ["desktop screenshot", "mobile screenshot", "text overlap check", "domain-fit checklist"],
            "fresh_session_budget": shared_budget,
            "operator_gate_required": False,
            "agentization_status": "capability",
            "agentization_gate": {"eligible": False, "status": "not_agent", "reason": "Should run as background gate first."},
            "maturity": "gate",
            "is_agent": False,
            "runtime_action_executed": False,
            "external_action_executed": False,
            "irreversible_action_executed": False,
        },
        {
            "capability_id": "motion_quality_gate",
            "canonical_name": "Motion Quality Gate",
            "aliases": ["Motion Gate", "Animation Quality Gate"],
            "type": "gate",
            "runtime_classification": "background_quality_gate",
            "source_repo_or_rule": {"kind": "pattern", "ref": "design-motion-principles"},
            "is": "A motion review gate for purpose, frequency, reduced-motion behavior and performance.",
            "is_not": "Not an animation agent and not a reason to add motion where none is needed.",
            "trigger": ["animation added", "interactive transition", "video or motion-heavy UI"],
            "when_not_to_use": ["static admin surface", "performance-sensitive path without motion requirement"],
            "allowed_actions": ["check reduced-motion", "check frame stability", "remove decorative motion"],
            "forbidden_actions": ["add attention-grabbing motion without product purpose", "ignore reduced-motion"],
            "evidence_note": "Decision - Thin Roles Thick Rails; frontend motion guidance",
            "verifier": ["reduced-motion behavior described", "animation purpose documented", "browser/screenshot check when UI exists"],
            "fresh_session_budget": shared_budget,
            "operator_gate_required": False,
            "agentization_status": "capability",
            "agentization_gate": {"eligible": False, "status": "not_agent", "reason": "Gate semantics are enough."},
            "maturity": "gate",
            "is_agent": False,
            "runtime_action_executed": False,
            "external_action_executed": False,
            "irreversible_action_executed": False,
        },
        {
            "capability_id": "anti_slop_ui_review",
            "canonical_name": "Anti-Slop UI Review",
            "aliases": ["Anti-Slop", "Taste Review", "UI Slop Review"],
            "type": "review_mode",
            "runtime_classification": "review_mode",
            "source_repo_or_rule": {"kind": "pattern", "ref": "taste-skill"},
            "is": "A targeted review mode for generic AI UI, placeholder copy, card overuse and mismatched component choices.",
            "is_not": "Not a Taste agent and not a license to redesign unrelated surfaces.",
            "trigger": ["AI-looking UI", "too many decorative cards", "placeholder or vague copy", "visual polish request"],
            "when_not_to_use": ["no UI output", "pure data pipeline", "when design requirements already pass"],
            "allowed_actions": ["flag vague copy", "tighten component choices", "reduce decorative clutter"],
            "forbidden_actions": ["rewrite business scope", "hide missing product behavior behind polish"],
            "evidence_note": "Decision - Thin Roles Thick Rails; frontend design instructions",
            "verifier": ["before/after screenshot or explicit UI checklist", "no text overlap", "no placeholder copy"],
            "fresh_session_budget": shared_budget,
            "operator_gate_required": False,
            "agentization_status": "capability",
            "agentization_gate": {"eligible": False, "status": "not_agent", "reason": "Review mode, not independent worker."},
            "maturity": "manual",
            "is_agent": False,
            "runtime_action_executed": False,
            "external_action_executed": False,
            "irreversible_action_executed": False,
        },
        {
            "capability_id": "rowboat_ux_benchmark",
            "canonical_name": "Rowboat UX Benchmark",
            "aliases": ["Rowboat", "rowboatlabs/rowboat"],
            "type": "benchmark",
            "runtime_classification": "product_benchmark",
            "source_repo_or_rule": {"kind": "github_repo", "ref": "rowboatlabs/rowboat", "license": "unknown"},
            "is": "A product and UX benchmark for comparing agent workflow surfaces and collaboration patterns.",
            "is_not": "Not a Vega replacement and not an immediate runtime adoption target.",
            "trigger": ["agent UI comparison", "operator workflow review", "collaboration surface benchmark"],
            "when_not_to_use": ["local bugfix", "when current LION surface is not involved", "without comparison criteria"],
            "allowed_actions": ["compare interaction patterns", "harvest UI ideas", "write benchmark notes"],
            "forbidden_actions": ["copy product wholesale", "treat external UX as canonical Vega truth"],
            "evidence_note": "DreamFactory System/Agent Stack/GitHub Star Audit - 2026-05-28",
            "verifier": ["benchmark criteria present", "adoption decision separated from observation"],
            "fresh_session_budget": shared_budget,
            "operator_gate_required": False,
            "agentization_status": "capability",
            "agentization_gate": {"eligible": False, "status": "not_agent", "reason": "Benchmark, not role."},
            "maturity": "seed",
            "is_agent": False,
            "runtime_action_executed": False,
            "external_action_executed": False,
            "irreversible_action_executed": False,
        },
        {
            "capability_id": "readable_report_delivery_standard",
            "canonical_name": "Readable Report Delivery Standard",
            "aliases": ["Readable Report", "DR Report Layout", "PDF Report Standard"],
            "type": "report_gate",
            "runtime_classification": "background_quality_gate",
            "source_repo_or_rule": {
                "kind": "canonical_rule",
                "ref": "Canonical/Rules/Rule - Readable Report Delivery Standard",
            },
            "is": "A report-delivery gate that requires an evidence layer plus readable DR-style overview and PDF when document-like.",
            "is_not": "Not a PDF agent and not a replacement for source evidence.",
            "trigger": ["large audit", "DR report", "strategy review", "benchmark report", "document-like deliverable"],
            "when_not_to_use": ["tiny answer", "quick command output", "ephemeral status update"],
            "allowed_actions": ["create readable overview", "export PDF", "verify PDF text extraction"],
            "forbidden_actions": ["deliver only raw long markdown for document-like audits", "skip verification of generated file"],
            "evidence_note": "Canonical/Rules/Rule - Readable Report Delivery Standard",
            "verifier": ["PDF exists", "PDF has readable pages", "source evidence path is linked"],
            "fresh_session_budget": shared_budget,
            "operator_gate_required": False,
            "agentization_status": "capability",
            "agentization_gate": {"eligible": False, "status": "not_agent", "reason": "Delivery standard, not worker identity."},
            "maturity": "gate",
            "is_agent": False,
            "runtime_action_executed": False,
            "external_action_executed": False,
            "irreversible_action_executed": False,
        },
        {
            "capability_id": "external_repo_audit_standard",
            "canonical_name": "External Repo Audit Standard",
            "aliases": ["Repo Audit Standard", "Star Audit Standard"],
            "type": "policy_gate",
            "runtime_classification": "policy_gate",
            "source_repo_or_rule": {
                "kind": "canonical_rule",
                "ref": "Canonical/Rules/Rule - External Repo Audit Standard",
            },
            "is": "A policy gate for classifying external repos before any adoption or runtime activation.",
            "is_not": "Not a global installer and not a permission to run external code.",
            "trigger": ["GitHub star audit", "external repo review", "tool adoption question"],
            "when_not_to_use": ["internal-only change with no external source"],
            "allowed_actions": ["classify adoption mode", "separate benchmark from runtime", "record license/risk notes"],
            "forbidden_actions": ["global installs by default", "credential setup", "Docker worker activation", "active scanners"],
            "evidence_note": "Canonical/Rules/Rule - External Repo Audit Standard",
            "verifier": ["classification present", "license/risk checked", "runtime action false"],
            "fresh_session_budget": shared_budget,
            "operator_gate_required": False,
            "agentization_status": "capability",
            "agentization_gate": {"eligible": False, "status": "not_agent", "reason": "Governance gate, not agent."},
            "maturity": "gate",
            "is_agent": False,
            "runtime_action_executed": False,
            "external_action_executed": False,
            "irreversible_action_executed": False,
        },
        {
            "capability_id": "agentization_decision_gate",
            "canonical_name": "Agentization Decision Gate",
            "aliases": ["Agentisierungs-Gate", "Agent Gate"],
            "type": "policy_gate",
            "runtime_classification": "policy_gate",
            "source_repo_or_rule": {
                "kind": "canonical_decision",
                "ref": "Canonical/Decisions/Decision - Thin Roles Thick Rails",
            },
            "is": "A decision gate that requires lifecycle, outputs, verifier, handoff and memory proof before a capability becomes an agent.",
            "is_not": "Not a new agent and not a branding exercise.",
            "trigger": ["new agent name proposed", "capability wants own role", "productized agent discussion"],
            "when_not_to_use": ["ordinary capability addition", "one-off review mode"],
            "allowed_actions": ["score lifecycle readiness", "reject premature agentization", "record agent-approved exceptions"],
            "forbidden_actions": ["create persona before job cards exist", "increase session context without proven value"],
            "evidence_note": "Canonical/Decisions/Decision - Thin Roles Thick Rails",
            "verifier": ["trigger-job-artifact-verifier-handoff-memory lifecycle present", "usage telemetry supports agent_candidate"],
            "fresh_session_budget": shared_budget,
            "operator_gate_required": False,
            "agentization_status": "capability",
            "agentization_gate": {"eligible": False, "status": "not_agent", "reason": "It is itself the gate."},
            "maturity": "gate",
            "is_agent": False,
            "runtime_action_executed": False,
            "external_action_executed": False,
            "irreversible_action_executed": False,
        },
    ]


def summarize_records(records: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "record_count": len(records),
        "type_counts": dict(Counter(str(record.get("type", "")) for record in records)),
        "runtime_classification_counts": dict(Counter(str(record.get("runtime_classification", "")) for record in records)),
        "maturity_counts": dict(Counter(str(record.get("maturity", "")) for record in records)),
        "agentization_counts": dict(Counter(str(record.get("agentization_status", "")) for record in records)),
        "operator_gate_required_count": sum(1 for record in records if record.get("operator_gate_required") is True),
        "agent_count": sum(1 for record in records if record.get("is_agent") is True),
    }


def build_capability_registry(*, output_dir: Path, docs_dir: Path, write: bool = True) -> dict[str, Any]:
    records = default_capability_records()
    payload = {
        "schema_version": 1,
        "generated_at": utc_now(),
        "status": "PASS",
        "registry_id": "thin-roles-thick-rails-capability-registry",
        "decision": "Thin Roles, Thick Rails",
        "purpose": "Name and govern capabilities, gates, benchmarks and sandboxes without creating unnecessary agent roles.",
        "source_docs": [
            str(docs_dir / "CAPABILITY_REGISTRY_SCHEMA.json"),
            str(docs_dir / "CAPABILITY_REGISTRY_POLICY.md"),
            "Canonical/Decisions/Decision - Thin Roles Thick Rails",
            "DreamFactory System/Agent Stack/Agent Capability Naming Roadmap - 2026-05-28",
        ],
        "fresh_session_rule": "Start note -> canonical decision -> capability registry -> relevant detail note.",
        "records": records,
        "summary": summarize_records(records),
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
        "next_safe_step": "Run capability-registry audit before adding names or promoting a capability toward agent status.",
    }
    if write:
        paths = registry_paths(output_dir)
        write_json(paths["registry_json"], payload)
        paths["registry_md"].write_text(capability_registry_to_markdown(payload), encoding="utf-8")
    return payload


def validate_capability_registry(payload: dict[str, Any], *, docs_dir: Path | None = None) -> dict[str, Any]:
    records = payload.get("records", [])
    checks: list[dict[str, Any]] = []

    def check(name: str, ok: bool, detail: str, severity: str = "fail") -> None:
        checks.append({
            "name": name,
            "status": "PASS" if ok else ("WARN" if severity == "warn" else "FAIL"),
            "severity": severity,
            "detail": detail,
        })

    check("records_present", isinstance(records, list) and len(records) >= 8, f"records={len(records) if isinstance(records, list) else 0}")
    ids = [str(record.get("capability_id", "")) for record in records if isinstance(record, dict)]
    names = [str(record.get("canonical_name", "")) for record in records if isinstance(record, dict)]
    check("unique_ids", len(ids) == len(set(ids)) and all(ids), f"ids={len(ids)} unique={len(set(ids))}")
    check("unique_canonical_names", len(names) == len(set(names)) and all(names), f"names={len(names)} unique={len(set(names))}")

    missing_field_records = []
    invalid_type_records = []
    invalid_agent_records = []
    budget_violations = []
    runtime_violations = []
    weak_boundary_records = []
    for record in records if isinstance(records, list) else []:
        missing = [field for field in REQUIRED_RECORD_FIELDS if field not in record or record.get(field) in ("", [], {})]
        if missing:
            missing_field_records.append({"capability_id": record.get("capability_id", ""), "missing": missing})
        if record.get("type") not in ALLOWED_TYPES:
            invalid_type_records.append(record.get("capability_id", ""))
        if record.get("agentization_status") not in ALLOWED_AGENTIZATION_STATUS:
            invalid_agent_records.append(record.get("capability_id", ""))
        budget = record.get("fresh_session_budget", {})
        if not isinstance(budget, dict) or int(budget.get("max_core_notes", 99)) > 4 or len(budget.get("entrypoints", [])) > 4:
            budget_violations.append(record.get("capability_id", ""))
        if any(record.get(flag) is True for flag in ["runtime_action_executed", "external_action_executed", "irreversible_action_executed"]):
            runtime_violations.append(record.get("capability_id", ""))
        if not record.get("is_not") or not record.get("forbidden_actions") or not record.get("when_not_to_use"):
            weak_boundary_records.append(record.get("capability_id", ""))

    check("required_fields", not missing_field_records, f"missing={missing_field_records[:5]}")
    check("allowed_types", not invalid_type_records, f"invalid={invalid_type_records}")
    check("allowed_agentization_status", not invalid_agent_records, f"invalid={invalid_agent_records}")
    check("fresh_session_budget_small", not budget_violations, f"violations={budget_violations}")
    check("no_runtime_external_or_irreversible_action", not runtime_violations, f"violations={runtime_violations}")
    check("boundaries_present", not weak_boundary_records, f"weak={weak_boundary_records}")

    alias_map: dict[str, list[str]] = {}
    for record in records if isinstance(records, list) else []:
        for alias in record.get("aliases", []):
            alias_map.setdefault(str(alias).lower(), []).append(str(record.get("capability_id", "")))
    check("shannon_alias_unique", alias_map.get("shannon") == ["shannon_security_sandbox"], f"shannon={alias_map.get('shannon')}")
    shannon = next((record for record in records if record.get("capability_id") == "shannon_security_sandbox"), {})
    check(
        "sandbox_gates_present",
        shannon.get("type") == "sandbox"
        and shannon.get("runtime_classification") == "sandbox_only"
        and shannon.get("operator_gate_required") is True
        and len(shannon.get("forbidden_actions", [])) >= 5,
        f"type={shannon.get('type')} gates={len(shannon.get('forbidden_actions', []))}",
    )

    unapproved_agent_records = [
        record.get("capability_id")
        for record in records
        if record.get("is_agent") is True and record.get("agentization_status") != "agent_approved"
    ]
    check("no_unapproved_agent_roles", not unapproved_agent_records, f"agents={unapproved_agent_records}")
    design_like = {
        "design_quality_gate": "gate",
        "motion_quality_gate": "gate",
        "anti_slop_ui_review": "review_mode",
    }
    design_violations = [
        capability_id
        for capability_id, expected_type in design_like.items()
        if next((record for record in records if record.get("capability_id") == capability_id), {}).get("type") != expected_type
    ]
    check("quality_modes_not_agents", not design_violations, f"violations={design_violations}")

    if docs_dir is not None:
        check("schema_doc_present", (docs_dir / "CAPABILITY_REGISTRY_SCHEMA.json").exists(), str(docs_dir / "CAPABILITY_REGISTRY_SCHEMA.json"))
        check("policy_doc_present", (docs_dir / "CAPABILITY_REGISTRY_POLICY.md").exists(), str(docs_dir / "CAPABILITY_REGISTRY_POLICY.md"))
        check("shannon_contract_doc_present", (docs_dir / "SHANNON_SECURITY_SANDBOX_CONTRACT.md").exists(), str(docs_dir / "SHANNON_SECURITY_SANDBOX_CONTRACT.md"))
        check("telemetry_schema_doc_present", telemetry_schema_path(docs_dir).exists(), str(telemetry_schema_path(docs_dir)))
        check("telemetry_policy_doc_present", telemetry_policy_path(docs_dir).exists(), str(telemetry_policy_path(docs_dir)))
        check("usage_ledger_present", capability_usage_ledger_path(docs_dir).exists(), str(capability_usage_ledger_path(docs_dir)))
        check("agentization_gate_schema_doc_present", agentization_gate_schema_path(docs_dir).exists(), str(agentization_gate_schema_path(docs_dir)))
        check("agentization_gate_policy_doc_present", agentization_gate_policy_path(docs_dir).exists(), str(agentization_gate_policy_path(docs_dir)))
        check("agent_product_maturity_schema_doc_present", agent_product_maturity_schema_path(docs_dir).exists(), str(agent_product_maturity_schema_path(docs_dir)))
        check("agent_product_maturity_policy_doc_present", agent_product_maturity_policy_path(docs_dir).exists(), str(agent_product_maturity_policy_path(docs_dir)))
        check("fresh_session_budget_policy_doc_present", (docs_dir / "FRESH_SESSION_CONTEXT_BUDGET_POLICY.md").exists(), str(docs_dir / "FRESH_SESSION_CONTEXT_BUDGET_POLICY.md"))

    fail_count = sum(1 for item in checks if item["status"] == "FAIL")
    warn_count = sum(1 for item in checks if item["status"] == "WARN")
    return {
        "status": "PASS" if fail_count == 0 else "FAIL",
        "checks": checks,
        "fail_count": fail_count,
        "warn_count": warn_count,
    }


def build_capability_registry_audit(*, output_dir: Path, docs_dir: Path, write: bool = True) -> dict[str, Any]:
    registry = build_capability_registry(output_dir=output_dir, docs_dir=docs_dir, write=write)
    validation = validate_capability_registry(registry, docs_dir=docs_dir)
    records = registry.get("records", [])
    payload = {
        "schema_version": 1,
        "generated_at": utc_now(),
        "status": validation["status"],
        "registry_id": registry.get("registry_id", ""),
        "record_count": len(records),
        "sandbox_count": registry.get("summary", {}).get("type_counts", {}).get("sandbox", 0),
        "gate_count": registry.get("summary", {}).get("type_counts", {}).get("gate", 0)
        + registry.get("summary", {}).get("type_counts", {}).get("report_gate", 0)
        + registry.get("summary", {}).get("type_counts", {}).get("policy_gate", 0),
        "benchmark_count": registry.get("summary", {}).get("type_counts", {}).get("benchmark", 0),
        "agent_count": registry.get("summary", {}).get("agent_count", 0),
        "operator_gate_required_count": registry.get("summary", {}).get("operator_gate_required_count", 0),
        "capabilities": [
            {
                "capability_id": record.get("capability_id"),
                "canonical_name": record.get("canonical_name"),
                "type": record.get("type"),
                "runtime_classification": record.get("runtime_classification"),
                "agentization_status": record.get("agentization_status"),
                "operator_gate_required": record.get("operator_gate_required", False),
                "is_agent": record.get("is_agent", False),
            }
            for record in records
        ],
        "checks": validation["checks"],
        "fail_count": validation["fail_count"],
        "warn_count": validation["warn_count"],
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
        "next_safe_step": registry.get("next_safe_step", ""),
        "paths": {key: str(value) for key, value in registry_paths(output_dir).items()},
    }
    if write:
        paths = registry_paths(output_dir)
        write_json(paths["audit_json"], payload)
        paths["audit_md"].write_text(capability_registry_audit_to_markdown(payload), encoding="utf-8")
    return payload


def build_shannon_sandbox_contract(*, output_dir: Path, docs_dir: Path, write: bool = True) -> dict[str, Any]:
    registry = build_capability_registry(output_dir=output_dir, docs_dir=docs_dir, write=write)
    shannon = next(
        (record for record in registry.get("records", []) if record.get("capability_id") == "shannon_security_sandbox"),
        {},
    )
    checks: list[dict[str, Any]] = []

    def check(name: str, ok: bool, detail: str) -> None:
        checks.append({"name": name, "status": "PASS" if ok else "FAIL", "detail": detail})

    aliases = shannon.get("aliases", [])
    source = shannon.get("source_repo_or_rule", {})
    check("canonical_name", shannon.get("canonical_name") == "Shannon Security Sandbox", str(shannon.get("canonical_name", "")))
    check("aliases_cover_typo_and_repo", all(alias in aliases for alias in ["Shannon", "Shanon", "KeygraphHQ/shannon"]), str(aliases))
    check("sandbox_only", shannon.get("type") == "sandbox" and shannon.get("runtime_classification") == "sandbox_only", f"{shannon.get('type')} / {shannon.get('runtime_classification')}")
    check("agpl_license_visible", source.get("license") == "AGPL-3.0", str(source.get("license", "")))
    check("operator_gate_required", shannon.get("operator_gate_required") is True, str(shannon.get("operator_gate_required")))
    check("hard_forbidden_actions", len(shannon.get("forbidden_actions", [])) >= 5, str(len(shannon.get("forbidden_actions", []))))
    check("not_agent", shannon.get("is_agent") is False and shannon.get("agentization_gate", {}).get("status") == "not_agent", str(shannon.get("agentization_gate", {})))
    check("no_runtime_action", shannon.get("runtime_action_executed") is False and shannon.get("external_action_executed") is False and shannon.get("irreversible_action_executed") is False, "runtime/external/irreversible false")
    check("pig_contract_doc_present", (docs_dir / "SHANNON_SECURITY_SANDBOX_CONTRACT.md").exists(), str(docs_dir / "SHANNON_SECURITY_SANDBOX_CONTRACT.md"))

    fail_count = sum(1 for item in checks if item["status"] == "FAIL")
    payload = {
        "schema_version": 1,
        "generated_at": utc_now(),
        "status": "PASS" if fail_count == 0 else "FAIL",
        "contract_id": "shannon_security_sandbox_contract",
        "canonical_name": shannon.get("canonical_name", "Shannon Security Sandbox"),
        "aliases": aliases,
        "source_repo_or_rule": source,
        "allowed_actions": shannon.get("allowed_actions", []),
        "forbidden_actions": shannon.get("forbidden_actions", []),
        "hard_gates": [
            "written scope",
            "own test data",
            "no live/customer/third-party target",
            "isolated credentials",
            "Docker/worker only in sandbox after operator go",
            "AGPL license review before code adoption",
            "human verification of findings",
        ],
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
        "next_safe_step": "Treat any Shannon request as a sandbox-scope check first; do not run scans or workers until all hard gates are PASS.",
    }
    if write:
        paths = registry_paths(output_dir)
        write_json(paths["shannon_contract_json"], payload)
        paths["shannon_contract_md"].write_text(shannon_sandbox_contract_to_markdown(payload), encoding="utf-8")
    return payload


def load_capability_usage_ledger(docs_dir: Path) -> dict[str, Any]:
    path = capability_usage_ledger_path(docs_dir)
    if not path.exists():
        return {
            "schema_version": 1,
            "status": "WARN",
            "ledger_id": "capability-usage-ledger",
            "events": [],
            "missing_ledger": True,
        }
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return {
            "schema_version": 1,
            "status": "FAIL",
            "ledger_id": "capability-usage-ledger",
            "events": [],
            "load_error": str(exc),
        }


def _metric_value(metrics: dict[str, Any], field: str) -> int:
    value = metrics.get(field, 0)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return 0
    return int(value)


def _evidence_refs(event: dict[str, Any]) -> list[str]:
    evidence = event.get("evidence", [])
    if isinstance(evidence, str):
        return [evidence]
    if isinstance(evidence, list):
        return [str(item) for item in evidence if str(item)]
    return []


def _absolute_evidence_path_failures(events: list[dict[str, Any]]) -> list[dict[str, str]]:
    failures = []
    for event in events:
        if not isinstance(event, dict):
            continue
        for ref in _evidence_refs(event):
            path = Path(ref)
            if path.is_absolute() and not path.exists():
                failures.append({"event_id": str(event.get("event_id", "")), "path": ref})
    return failures


def _event_has_positive_value_metric(event: dict[str, Any]) -> bool:
    metrics = event.get("value_metrics", {})
    return isinstance(metrics, dict) and any(_metric_value(metrics, field) > 0 for field in TELEMETRY_METRIC_FIELDS)


def validate_capability_usage_events(events: list[dict[str, Any]], known_ids: set[str]) -> list[dict[str, Any]]:
    checks: list[dict[str, Any]] = []

    def check(name: str, ok: bool, detail: str) -> None:
        checks.append({"name": name, "status": "PASS" if ok else "FAIL", "detail": detail})

    event_ids = [str(event.get("event_id", "")) for event in events if isinstance(event, dict)]
    check("events_have_unique_ids", len(event_ids) == len(set(event_ids)) and all(event_ids), f"events={len(event_ids)} unique={len(set(event_ids))}")
    unknown_capabilities = sorted({
        str(event.get("capability_id", ""))
        for event in events
        if isinstance(event, dict) and str(event.get("capability_id", "")) not in known_ids
    })
    check("events_reference_known_capabilities", not unknown_capabilities, f"unknown={unknown_capabilities}")

    missing_records = []
    metric_violations = []
    evidence_violations = []
    no_value_events = []
    unsupported_agent_candidate_events = []
    for event in events:
        if not isinstance(event, dict):
            missing_records.append({"event_id": "not_object", "missing": REQUIRED_TELEMETRY_EVENT_FIELDS})
            continue
        missing = [field for field in REQUIRED_TELEMETRY_EVENT_FIELDS if event.get(field) in (None, "", [], {})]
        if missing:
            missing_records.append({"event_id": event.get("event_id", ""), "missing": missing})
        metrics = event.get("value_metrics", {})
        if not isinstance(metrics, dict):
            metric_violations.append({"event_id": event.get("event_id", ""), "reason": "metrics_not_object"})
        else:
            for field in TELEMETRY_METRIC_FIELDS:
                value = metrics.get(field, 0)
                if isinstance(value, bool) or not isinstance(value, (int, float)) or value < 0:
                    metric_violations.append({"event_id": event.get("event_id", ""), "metric": field, "value": value})
        if not _event_has_positive_value_metric(event):
            no_value_events.append(event.get("event_id", ""))
        if not event.get("verifier") or not event.get("evidence") or not event.get("value_note"):
            evidence_violations.append(event.get("event_id", ""))
        if event.get("agent_candidate_signal") is True:
            lifecycle_proof = event.get("lifecycle_proof", {})
            required_proof = ["trigger", "job_card", "artifact", "verifier", "handoff", "memory"]
            if not isinstance(lifecycle_proof, dict) or any(not lifecycle_proof.get(field) for field in required_proof):
                unsupported_agent_candidate_events.append(event.get("event_id", ""))

    check("events_have_required_fields", not missing_records, f"missing={missing_records[:5]}")
    check("metrics_are_nonnegative_numbers", not metric_violations, f"violations={metric_violations[:5]}")
    check("events_are_evidence_backed", not evidence_violations, f"violations={evidence_violations[:5]}")
    check("events_record_value_delta", not no_value_events, f"events_without_positive_metric={no_value_events[:8]}")
    check("absolute_evidence_paths_exist", not _absolute_evidence_path_failures(events), f"missing={_absolute_evidence_path_failures(events)[:5]}")
    check("agent_candidate_signals_have_lifecycle_proof", not unsupported_agent_candidate_events, f"unsupported={unsupported_agent_candidate_events[:8]}")
    return checks


def telemetry_maturity_for(record: dict[str, Any], usage_count: int, verified_value_count: int, agent_candidate_signal: bool) -> str:
    if agent_candidate_signal and usage_count >= 5 and verified_value_count >= 3:
        return "agent_candidate"
    if usage_count >= 5 and verified_value_count >= 3:
        return "semi_automated"
    if usage_count > 0 and record.get("type") in {"gate", "report_gate", "policy_gate"}:
        return "gate"
    if usage_count > 0:
        return "manual"
    return "seed_no_usage"


def telemetry_state_for(record: dict[str, Any], usage_count: int) -> str:
    if usage_count == 0:
        return "seed_no_usage"
    capability_type = str(record.get("type", ""))
    if capability_type == "sandbox":
        return "sandbox_recorded_usage"
    if capability_type in {"gate", "report_gate", "policy_gate"}:
        return "gate_recorded_usage"
    if capability_type == "benchmark":
        return "benchmark_recorded_usage"
    return "manual_recorded_usage"


def build_capability_telemetry(*, output_dir: Path, docs_dir: Path, write: bool = True) -> dict[str, Any]:
    registry = build_capability_registry(output_dir=output_dir, docs_dir=docs_dir, write=write)
    records = registry.get("records", [])
    known_ids = {str(record.get("capability_id", "")) for record in records}
    ledger = load_capability_usage_ledger(docs_dir)
    events = ledger.get("events", []) if isinstance(ledger.get("events", []), list) else []
    checks = validate_capability_usage_events(events, known_ids)
    if ledger.get("load_error"):
        checks.append({"name": "ledger_load", "status": "FAIL", "detail": str(ledger.get("load_error"))})
    if ledger.get("missing_ledger"):
        checks.append({"name": "ledger_present", "status": "FAIL", "detail": str(capability_usage_ledger_path(docs_dir))})
    else:
        checks.append({"name": "ledger_present", "status": "PASS", "detail": str(capability_usage_ledger_path(docs_dir))})
    checks.append({"name": "ledger_status_pass", "status": "PASS" if ledger.get("status") == "PASS" else "FAIL", "detail": str(ledger.get("status", "UNKNOWN"))})
    checks.append({"name": "telemetry_schema_present", "status": "PASS" if telemetry_schema_path(docs_dir).exists() else "FAIL", "detail": str(telemetry_schema_path(docs_dir))})
    checks.append({"name": "telemetry_policy_present", "status": "PASS" if telemetry_policy_path(docs_dir).exists() else "FAIL", "detail": str(telemetry_policy_path(docs_dir))})

    events_by_capability: dict[str, list[dict[str, Any]]] = {}
    for event in events:
        if isinstance(event, dict):
            events_by_capability.setdefault(str(event.get("capability_id", "")), []).append(event)

    items = []
    metric_totals = {field: 0 for field in TELEMETRY_METRIC_FIELDS}
    for record in records:
        capability_id = str(record.get("capability_id", ""))
        capability_events = events_by_capability.get(capability_id, [])
        usage_count = len(capability_events)
        verified_value_count = sum(1 for event in capability_events if event.get("verifier") and event.get("evidence") and event.get("outcome"))
        metric_sums = {
            field: sum(
                _metric_value(event.get("value_metrics", {}), field)
                for event in capability_events
                if isinstance(event.get("value_metrics", {}), dict)
            )
            for field in TELEMETRY_METRIC_FIELDS
        }
        for field, value in metric_sums.items():
            metric_totals[field] += value
        agent_candidate_signal = any(event.get("agent_candidate_signal") is True for event in capability_events)
        telemetry_maturity = telemetry_maturity_for(record, usage_count, verified_value_count, agent_candidate_signal)
        agent_candidate_ready = telemetry_maturity == "agent_candidate"
        last_event = max(capability_events, key=lambda item: str(item.get("triggered_at", "")), default={})
        items.append({
            "capability_id": capability_id,
            "canonical_name": record.get("canonical_name"),
            "declared_maturity": record.get("maturity", "seed"),
            "telemetry_maturity": telemetry_maturity,
            "usage_count": usage_count,
            "verified_value_count": verified_value_count,
            **metric_sums,
            "agent_candidate_signal": agent_candidate_signal,
            "agent_candidate_ready": agent_candidate_ready,
            "telemetry_state": telemetry_state_for(record, usage_count),
            "last_used_at": str(last_event.get("triggered_at", "")),
            "last_outcome": str(last_event.get("outcome", "")),
            "recent_events": [
                {
                    "event_id": event.get("event_id", ""),
                    "triggered_at": event.get("triggered_at", ""),
                    "trigger": event.get("trigger", ""),
                    "project": event.get("project", ""),
                    "outcome": event.get("outcome", ""),
                    "value_note": event.get("value_note", ""),
                }
                for event in sorted(capability_events, key=lambda item: str(item.get("triggered_at", "")), reverse=True)[:5]
            ],
        })
    fail_count = sum(1 for item in checks if item["status"] == "FAIL")
    warn_count = sum(1 for item in checks if item["status"] == "WARN")
    verified_value_total = sum(item["verified_value_count"] for item in items)
    recent_events = [
        {
            "event_id": event.get("event_id", ""),
            "capability_id": event.get("capability_id", ""),
            "triggered_at": event.get("triggered_at", ""),
            "project": event.get("project", ""),
            "outcome": event.get("outcome", ""),
        }
        for event in sorted((event for event in events if isinstance(event, dict)), key=lambda item: str(item.get("triggered_at", "")), reverse=True)[:8]
    ]
    payload = {
        "schema_version": 1,
        "generated_at": utc_now(),
        "status": "PASS" if fail_count == 0 else "FAIL",
        "source": "capability_registry_telemetry",
        "item_count": len(items),
        "usage_total": sum(item["usage_count"] for item in items),
        "ledger_event_count": len(events),
        "verified_value_total": verified_value_total,
        "prevented_issue_total": metric_totals["prevented_issue_count"],
        "time_saved_estimate_minutes": metric_totals["time_saved_estimate_minutes"],
        "better_document_total": metric_totals["better_document_count"],
        "risk_blocked_total": metric_totals["risk_blocked_count"],
        "verified_surface_total": metric_totals["verified_surface_count"],
        "agent_candidate_count": sum(1 for item in items if item["agent_candidate_ready"]),
        "agent_candidate_signal_count": sum(1 for item in items if item["agent_candidate_signal"]),
        "quality_metric_totals": metric_totals,
        "source_ledger": str(capability_usage_ledger_path(docs_dir)),
        "ledger_path": str(capability_usage_ledger_path(docs_dir)),
        "ledger_status": ledger.get("status", "UNKNOWN"),
        "events": events,
        "recent_events": recent_events,
        "items": items,
        "checks": checks,
        "fail_count": fail_count,
        "warn_count": warn_count,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
        "next_safe_step": "Record real usage only when a capability changes an artifact, blocks a risk or improves a verified outcome.",
    }
    if write:
        paths = registry_paths(output_dir)
        write_json(paths["telemetry_json"], payload)
        paths["telemetry_md"].write_text(capability_telemetry_to_markdown(payload), encoding="utf-8")
    return payload


def build_agentization_decision_gate(*, output_dir: Path, docs_dir: Path, write: bool = True) -> dict[str, Any]:
    registry = build_capability_registry(output_dir=output_dir, docs_dir=docs_dir, write=write)
    telemetry = build_capability_telemetry(output_dir=output_dir, docs_dir=docs_dir, write=write)
    telemetry_by_id = {item.get("capability_id"): item for item in telemetry.get("items", []) if isinstance(item, dict)}
    reserved_names = {"operator", "vega", "vivi", "codex", "vegapunk"}
    lifecycle_fields = ["trigger", "job_card", "artifact", "verifier", "handoff", "memory"]
    decisions = []
    checks = []

    def check(name: str, ok: bool, detail: str) -> None:
        checks.append({"name": name, "status": "PASS" if ok else "FAIL", "detail": detail})

    for record in registry.get("records", []):
        capability_id = str(record.get("capability_id", ""))
        item = telemetry_by_id.get(capability_id, {})
        usage_count = int(item.get("usage_count", 0))
        verified_value_count = int(item.get("verified_value_count", 0))
        missing_evidence = []
        if usage_count < 5:
            missing_evidence.append("five_recorded_uses")
        if verified_value_count < 3:
            missing_evidence.append("three_verified_value_events")
        if not item.get("agent_candidate_ready"):
            missing_evidence.append("agent_candidate_signal_with_lifecycle")
        if record.get("is_agent") is True and record.get("agentization_status") != "agent_approved":
            missing_evidence.append("agent_approved_status")
        name_collisions = [
            alias
            for alias in [record.get("canonical_name", ""), *record.get("aliases", [])]
            if str(alias).strip().lower() in reserved_names
        ]
        if name_collisions:
            missing_evidence.append("non_conflicting_name")
        lifecycle_proof = {
            "trigger": bool(record.get("trigger")),
            "job_card": item.get("agent_candidate_ready") is True,
            "artifact": verified_value_count >= 3,
            "verifier": bool(record.get("verifier")),
            "handoff": item.get("agent_candidate_ready") is True,
            "memory": bool(record.get("evidence_note")),
        }
        eligible = not missing_evidence and all(lifecycle_proof.values())
        decisions.append({
            "capability_id": capability_id,
            "canonical_name": record.get("canonical_name", ""),
            "current_status": record.get("agentization_status", "capability"),
            "decision": "candidate_agent" if eligible else "stay_capability",
            "eligible_for_agent": eligible,
            "usage_count": usage_count,
            "verified_value_count": verified_value_count,
            "telemetry_maturity": item.get("telemetry_maturity", "seed_no_usage"),
            "agent_candidate_ready": item.get("agent_candidate_ready", False),
            "lifecycle_proof": lifecycle_proof,
            "required_lifecycle_fields": lifecycle_fields,
            "missing_evidence": missing_evidence,
            "name_collisions": name_collisions,
            "operator_gate_required": record.get("operator_gate_required", False),
            "next_safe_step": "Keep as capability/gate/sandbox until the full lifecycle is proven." if not eligible else "Prepare a separate operator-reviewed agent contract before approval.",
        })

    decision_by_id = {item["capability_id"]: item for item in decisions}
    approved_agent_ids = [
        str(record.get("capability_id", ""))
        for record in registry.get("records", [])
        if record.get("is_agent") is True and record.get("agentization_status") == "agent_approved"
    ]
    approved_agents = [decision_by_id[capability_id] for capability_id in approved_agent_ids if capability_id in decision_by_id]
    candidate_agents = [item for item in decisions if item["decision"] == "candidate_agent"]
    unsupported_candidates = [item for item in decisions if item["current_status"] == "candidate_agent" and not item["eligible_for_agent"]]
    unsupported_approved_agents = [item for item in approved_agents if not item["eligible_for_agent"]]
    existing_agent_records = [
        record.get("capability_id")
        for record in registry.get("records", [])
        if record.get("is_agent") is True and record.get("agentization_status") != "agent_approved"
    ]
    runtime_violations = [
        record.get("capability_id")
        for record in registry.get("records", [])
        if any(record.get(flag) is True for flag in ["runtime_action_executed", "external_action_executed", "irreversible_action_executed"])
    ]
    check("gate_schema_present", agentization_gate_schema_path(docs_dir).exists(), str(agentization_gate_schema_path(docs_dir)))
    check("gate_policy_present", agentization_gate_policy_path(docs_dir).exists(), str(agentization_gate_policy_path(docs_dir)))
    check("telemetry_pass", telemetry.get("status") == "PASS", str(telemetry.get("status", "UNKNOWN")))
    check("no_existing_unapproved_agents", not existing_agent_records, f"agents={existing_agent_records}")
    check("no_runtime_external_irreversible_actions", not runtime_violations, f"violations={runtime_violations}")
    check("no_agent_candidates_without_lifecycle", not unsupported_candidates, f"unsupported={len(unsupported_candidates)}")
    check("no_agent_approval_without_lifecycle", not unsupported_approved_agents, f"unsupported={len(unsupported_approved_agents)}")

    fail_count = sum(1 for item in checks if item["status"] == "FAIL")
    payload = {
        "schema_version": 1,
        "generated_at": utc_now(),
        "status": "PASS" if fail_count == 0 else "FAIL",
        "gate_id": "agentization_decision_gate",
        "decision": "Thin Roles, Thick Rails",
        "required_lifecycle": "Trigger -> Job Card -> Work -> Artifact -> Verifier -> Handoff -> Memory",
        "approved_agent_count": len(approved_agents),
        "candidate_agent_count": len(candidate_agents),
        "unsupported_candidate_count": len(unsupported_candidates),
        "approved_agent_ids": approved_agent_ids,
        "candidate_agent_ids": [item["capability_id"] for item in candidate_agents],
        "stay_capability_count": len([item for item in decisions if item["decision"] == "stay_capability"]),
        "decisions": decisions,
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
        "next_safe_step": "Reject new agent roles by default; require telemetry plus lifecycle proof before drafting an agent contract.",
    }
    if write:
        paths = registry_paths(output_dir)
        write_json(paths["agentization_gate_json"], payload)
        paths["agentization_gate_md"].write_text(agentization_gate_to_markdown(payload), encoding="utf-8")
    return payload


def build_agent_product_maturity_contract(*, output_dir: Path, docs_dir: Path, write: bool = True) -> dict[str, Any]:
    agentization = build_agentization_decision_gate(output_dir=output_dir, docs_dir=docs_dir, write=write)
    candidate_decisions = [item for item in agentization.get("decisions", []) if item.get("decision") == "candidate_agent"]
    approved_agent_ids = list(agentization.get("approved_agent_ids", []))
    required_contract_fields = [
        "agent_id",
        "operator_problem",
        "target_user",
        "trigger",
        "job_card_contract",
        "artifact_contract",
        "verifier_contract",
        "handoff_contract",
        "memory_contract",
        "safety_and_scope_gates",
        "fresh_session_budget",
        "operator_surface",
        "support_and_rollback",
        "commercial_or_operational_role",
    ]
    candidate_contracts = [
        {
            "capability_id": item.get("capability_id", ""),
            "canonical_name": item.get("canonical_name", ""),
            "status": "requires_operator_review",
            "ready_for_productized_agent": False,
            "required_fields": required_contract_fields,
            "missing_fields": required_contract_fields,
            "next_safe_step": "Draft a separate product maturity contract before approving or shipping an agent role.",
        }
        for item in candidate_decisions
    ]
    readiness_dimensions = [
        {"dimension": "operator_problem", "required": True, "status": "template_ready"},
        {"dimension": "target_user_and_use_case", "required": True, "status": "template_ready"},
        {"dimension": "trigger_job_artifact_verifier_handoff_memory", "required": True, "status": "template_ready"},
        {"dimension": "safety_scope_and_rollback", "required": True, "status": "template_ready"},
        {"dimension": "fresh_session_context_budget", "required": True, "status": "template_ready"},
        {"dimension": "operator_surface_and_support", "required": True, "status": "template_ready"},
        {"dimension": "commercial_or_operational_role", "required": True, "status": "template_ready"},
    ]
    checks: list[dict[str, str]] = []

    def check(name: str, ok: bool, detail: str) -> None:
        checks.append({"name": name, "status": "PASS" if ok else "FAIL", "detail": detail})

    check("contract_schema_present", agent_product_maturity_schema_path(docs_dir).exists(), str(agent_product_maturity_schema_path(docs_dir)))
    check("contract_policy_present", agent_product_maturity_policy_path(docs_dir).exists(), str(agent_product_maturity_policy_path(docs_dir)))
    check("agentization_gate_pass", agentization.get("status") == "PASS", str(agentization.get("status", "UNKNOWN")))
    check("candidate_contracts_materialized", len(candidate_contracts) == len(candidate_decisions), f"candidates={len(candidate_decisions)} contracts={len(candidate_contracts)}")
    check("no_approved_agent_without_product_contract", not approved_agent_ids, f"approved_without_contract={approved_agent_ids}")
    check("no_runtime_external_irreversible_actions", agentization.get("runtime_action_executed") is not True and agentization.get("external_action_executed") is not True and agentization.get("irreversible_action_executed") is not True, "no runtime/external/irreversible action executed")

    fail_count = sum(1 for item in checks if item["status"] == "FAIL")
    payload = {
        "schema_version": 1,
        "generated_at": utc_now(),
        "status": "PASS" if fail_count == 0 else "FAIL",
        "contract_id": "agent_product_maturity_contract",
        "mode": "template_ready_no_productized_agents",
        "purpose": "Require a product maturity contract before any capability becomes an approved or sellable agent role.",
        "required_contract_fields": required_contract_fields,
        "readiness_dimensions": readiness_dimensions,
        "candidate_agent_count": len(candidate_decisions),
        "approved_agent_count": len(approved_agent_ids),
        "product_contract_ready_count": 0,
        "candidate_contracts": candidate_contracts,
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
        "next_safe_step": "Keep agent ideas as capabilities until a separate product maturity contract is complete and operator-reviewed.",
    }
    if write:
        paths = registry_paths(output_dir)
        write_json(paths["agent_product_contract_json"], payload)
        paths["agent_product_contract_md"].write_text(agent_product_maturity_contract_to_markdown(payload), encoding="utf-8")
    return payload


def capability_full_check_steps(*, output_dir: Path, docs_dir: Path) -> list[dict[str, Any]]:
    registry = build_capability_registry_audit(output_dir=output_dir, docs_dir=docs_dir, write=True)
    telemetry = build_capability_telemetry(output_dir=output_dir, docs_dir=docs_dir, write=True)
    agentization = build_agentization_decision_gate(output_dir=output_dir, docs_dir=docs_dir, write=True)
    product_contract = build_agent_product_maturity_contract(output_dir=output_dir, docs_dir=docs_dir, write=True)
    shannon = build_shannon_sandbox_contract(output_dir=output_dir, docs_dir=docs_dir, write=True)
    fresh = build_fresh_session_context_budget(output_dir=output_dir, docs_dir=docs_dir, write=True)
    background = build_background_quality_gates(output_dir=output_dir, docs_dir=docs_dir, write=True)
    return [
        {
            "name": "capability_registry",
            "status": "PASS" if registry.get("status") == "PASS" else "FAIL",
            "returncode": 0 if registry.get("status") == "PASS" else 1,
            "record_count": registry.get("record_count", 0),
            "agent_count": registry.get("agent_count", 0),
            "fail_count": registry.get("fail_count", 0),
            "runtime_action_executed": registry.get("runtime_action_executed", None),
        },
        {
            "name": "capability_telemetry",
            "status": "PASS" if telemetry.get("status") == "PASS" else "FAIL",
            "returncode": 0 if telemetry.get("status") == "PASS" else 1,
            "item_count": telemetry.get("item_count", 0),
            "usage_total": telemetry.get("usage_total", 0),
            "verified_value_total": telemetry.get("verified_value_total", 0),
            "risk_blocked_total": telemetry.get("risk_blocked_total", 0),
            "verified_surface_total": telemetry.get("verified_surface_total", 0),
            "agent_candidate_count": telemetry.get("agent_candidate_count", 0),
            "runtime_action_executed": telemetry.get("runtime_action_executed", None),
        },
        {
            "name": "agentization_decision_gate",
            "status": "PASS" if agentization.get("status") == "PASS" else "FAIL",
            "returncode": 0 if agentization.get("status") == "PASS" else 1,
            "candidate_agent_count": agentization.get("candidate_agent_count", 0),
            "approved_agent_count": agentization.get("approved_agent_count", 0),
            "stay_capability_count": agentization.get("stay_capability_count", 0),
            "fail_count": agentization.get("fail_count", 0),
            "runtime_action_executed": agentization.get("runtime_action_executed", None),
        },
        {
            "name": "agent_product_maturity_contract",
            "status": "PASS" if product_contract.get("status") == "PASS" else "FAIL",
            "returncode": 0 if product_contract.get("status") == "PASS" else 1,
            "candidate_agent_count": product_contract.get("candidate_agent_count", 0),
            "approved_agent_count": product_contract.get("approved_agent_count", 0),
            "product_contract_ready_count": product_contract.get("product_contract_ready_count", 0),
            "fail_count": product_contract.get("fail_count", 0),
            "runtime_action_executed": product_contract.get("runtime_action_executed", None),
        },
        {
            "name": "shannon_security_sandbox_contract",
            "status": "PASS" if shannon.get("status") == "PASS" else "FAIL",
            "returncode": 0 if shannon.get("status") == "PASS" else 1,
            "fail_count": shannon.get("fail_count", 0),
            "runtime_action_executed": shannon.get("runtime_action_executed", None),
            "external_action_executed": shannon.get("external_action_executed", None),
        },
        {
            "name": "fresh_session_context_budget",
            "status": "PASS" if fresh.get("status") == "PASS" else "FAIL",
            "returncode": 0 if fresh.get("status") == "PASS" else 1,
            "task_count": fresh.get("task_count", 0),
            "fail_count": fresh.get("fail_count", 0),
            "runtime_action_executed": fresh.get("runtime_action_executed", None),
        },
        {
            "name": "background_quality_gates",
            "status": "PASS" if background.get("status") == "PASS" else "FAIL",
            "returncode": 0 if background.get("status") == "PASS" else 1,
            "gate_count": background.get("gate_count", 0),
            "fail_count": background.get("fail_count", 0),
            "runtime_action_executed": background.get("runtime_action_executed", None),
        },
    ]


def capability_source_record_specs(*, output_dir: Path, docs_dir: Path) -> list[dict[str, Any]]:
    common = {
        "layer": "pig_quality_os",
        "provenance": "generated_local",
        "sensitivity": "internal_shareable_after_redaction",
        "sharing_status": "included",
        "citation_policy": "cite_path",
    }
    return [
        {"source_id": "pig:capability-registry-schema", "relative_path": "docs/project-intelligence-graph/CAPABILITY_REGISTRY_SCHEMA.json", "kind": "json", "actual_path": docs_dir / "CAPABILITY_REGISTRY_SCHEMA.json", "role": "Thin Roles capability registry schema", **common},
        {"source_id": "pig:capability-registry-policy", "relative_path": "docs/project-intelligence-graph/CAPABILITY_REGISTRY_POLICY.md", "kind": "markdown", "actual_path": docs_dir / "CAPABILITY_REGISTRY_POLICY.md", "role": "Thin Roles capability registry policy", **common},
        {"source_id": "pig:capability-telemetry-schema", "relative_path": "docs/project-intelligence-graph/CAPABILITY_TELEMETRY_SCHEMA.json", "kind": "json", "actual_path": telemetry_schema_path(docs_dir), "role": "capability telemetry schema", **common},
        {"source_id": "pig:capability-telemetry-policy", "relative_path": "docs/project-intelligence-graph/CAPABILITY_TELEMETRY_POLICY.md", "kind": "markdown", "actual_path": telemetry_policy_path(docs_dir), "role": "capability telemetry policy and agent-candidate guard", **common},
        {"source_id": "pig:capability-usage-ledger", "relative_path": "docs/project-intelligence-graph/CAPABILITY_USAGE_LEDGER.json", "kind": "json", "actual_path": capability_usage_ledger_path(docs_dir), "role": "absolute-path local capability usage ledger", "sensitivity": "internal_sensitive", "sharing_status": "needs_review", "exclusion_reason": "Ledger contains absolute local Vault, PIG and LIONCOM evidence paths.", "reinclude_gate": "Redact or relativize paths before external sharing.", **{k: v for k, v in common.items() if k not in {"sensitivity", "sharing_status"}}},
        {"source_id": "pig:agentization-decision-gate-schema", "relative_path": "docs/project-intelligence-graph/AGENTIZATION_DECISION_GATE_SCHEMA.json", "kind": "json", "actual_path": agentization_gate_schema_path(docs_dir), "role": "agentization decision gate schema", **common},
        {"source_id": "pig:agentization-decision-gate-policy", "relative_path": "docs/project-intelligence-graph/AGENTIZATION_DECISION_GATE_POLICY.md", "kind": "markdown", "actual_path": agentization_gate_policy_path(docs_dir), "role": "agentization decision gate policy", **common},
        {"source_id": "pig:agent-product-maturity-contract-schema", "relative_path": "docs/project-intelligence-graph/AGENT_PRODUCT_MATURITY_CONTRACT_SCHEMA.json", "kind": "json", "actual_path": agent_product_maturity_schema_path(docs_dir), "role": "agent product maturity contract schema", **common},
        {"source_id": "pig:agent-product-maturity-contract-policy", "relative_path": "docs/project-intelligence-graph/AGENT_PRODUCT_MATURITY_CONTRACT_POLICY.md", "kind": "markdown", "actual_path": agent_product_maturity_policy_path(docs_dir), "role": "agent product maturity contract policy", **common},
        {"source_id": "pig:shannon-security-sandbox-contract-doc", "relative_path": "docs/project-intelligence-graph/SHANNON_SECURITY_SANDBOX_CONTRACT.md", "kind": "markdown", "actual_path": docs_dir / "SHANNON_SECURITY_SANDBOX_CONTRACT.md", "role": "Shannon Security Sandbox PIG contract", **common},
        {"source_id": "pig:fresh-session-context-budget-policy", "relative_path": "docs/project-intelligence-graph/FRESH_SESSION_CONTEXT_BUDGET_POLICY.md", "kind": "markdown", "actual_path": docs_dir / "FRESH_SESSION_CONTEXT_BUDGET_POLICY.md", "role": "fresh-session context budget policy", **common},
        {"source_id": "pig:capability-registry", "relative_path": "outputs/project_intelligence_graph/capability_registry.json", "kind": "generated_evidence", "actual_path": output_dir / "capability_registry.json", "role": "machine-readable capability, gate, benchmark and sandbox registry", **common},
        {"source_id": "pig:capability-registry-audit", "relative_path": "outputs/project_intelligence_graph/capability_registry_audit.json", "kind": "generated_evidence", "actual_path": output_dir / "capability_registry_audit.json", "role": "capability registry verifier output", **common},
        {"source_id": "pig:capability-registry-telemetry", "relative_path": "outputs/project_intelligence_graph/capability_registry_telemetry.json", "kind": "generated_evidence", "actual_path": output_dir / "capability_registry_telemetry.json", "role": "capability usage and agent-candidate telemetry rollup", **common},
        {"source_id": "pig:agentization-decision-gate", "relative_path": "outputs/project_intelligence_graph/agentization_decision_gate.json", "kind": "generated_evidence", "actual_path": output_dir / "agentization_decision_gate.json", "role": "agentization decision verifier output", **common},
        {"source_id": "pig:agent-product-maturity-contract", "relative_path": "outputs/project_intelligence_graph/agent_product_maturity_contract.json", "kind": "generated_evidence", "actual_path": output_dir / "agent_product_maturity_contract.json", "role": "agent product maturity contract output", **common},
        {"source_id": "pig:shannon-security-sandbox-contract", "relative_path": "outputs/project_intelligence_graph/shannon_security_sandbox_contract.json", "kind": "generated_evidence", "actual_path": output_dir / "shannon_security_sandbox_contract.json", "role": "Shannon Security Sandbox verifier output", **common},
        {"source_id": "pig:fresh-session-context-budget", "relative_path": "outputs/project_intelligence_graph/fresh_session_context_budget.json", "kind": "generated_evidence", "actual_path": output_dir / "fresh_session_context_budget.json", "role": "fresh-session capability context budget", **common},
        {"source_id": "pig:background-quality-gates-policy", "relative_path": "docs/project-intelligence-graph/BACKGROUND_QUALITY_GATES_POLICY.md", "kind": "markdown", "actual_path": docs_dir / "BACKGROUND_QUALITY_GATES_POLICY.md", "role": "background quality gates policy", **common},
        {"source_id": "pig:background-quality-gates", "relative_path": "outputs/project_intelligence_graph/background_quality_gates.json", "kind": "generated_evidence", "actual_path": output_dir / "background_quality_gates.json", "role": "background design/motion/anti-slop/report gates verifier output", **common},
    ]


def build_fresh_session_context_budget(*, output_dir: Path, docs_dir: Path, write: bool = True) -> dict[str, Any]:
    tasks = [
        {
            "task_type": "external_repo_audit",
            "max_core_notes": 4,
            "core_notes": [
                "VEGA_START_HERE.md",
                "Rule - External Repo Audit Standard",
                "capability_registry.json",
                "relevant audit note or repo note",
            ],
            "detail_rule": "Do not load all starred repos; inspect only the specific candidate or report section needed.",
        },
        {
            "task_type": "design_review",
            "max_core_notes": 4,
            "core_notes": [
                "VEGA_START_HERE.md",
                "Decision - Thin Roles Thick Rails",
                "capability_registry.json#design_quality_gate",
                "project UI surface or screenshot",
            ],
            "detail_rule": "Use the Design Quality Gate entry, not a design-agent persona.",
        },
        {
            "task_type": "security_shannon",
            "max_core_notes": 4,
            "core_notes": [
                "VEGA_START_HERE.md",
                "Decision - Thin Roles Thick Rails",
                "capability_registry.json#shannon_security_sandbox",
                "Rule - Shannon Security Sandbox Contract",
            ],
            "detail_rule": "Stop at scope verification until all hard gates are PASS.",
        },
        {
            "task_type": "benchmark_or_llm_comparison",
            "max_core_notes": 4,
            "core_notes": [
                "VEGA_START_HERE.md",
                "capability_registry.json",
                "Codeneedle Model Benchmark entry",
                "current model/provider truth artifact",
            ],
            "detail_rule": "Load benchmark fixtures only after the comparison scope is explicit.",
        },
        {
            "task_type": "readable_report_delivery",
            "max_core_notes": 4,
            "core_notes": [
                "VEGA_START_HERE.md",
                "Rule - Readable Report Delivery Standard",
                "capability_registry.json#readable_report_delivery_standard",
                "source evidence layer",
            ],
            "detail_rule": "Produce evidence plus DR overview plus verified PDF for document-like reports.",
        },
        {
            "task_type": "new_agent_idea",
            "max_core_notes": 4,
            "core_notes": [
                "VEGA_START_HERE.md",
                "Decision - Thin Roles Thick Rails",
                "capability_registry.json#agentization_decision_gate",
                "capability telemetry artifact",
            ],
            "detail_rule": "Reject agentization unless telemetry proves the full lifecycle.",
        },
    ]
    checks = []
    for task in tasks:
        over_budget = len(task["core_notes"]) > task["max_core_notes"]
        checks.append({
            "task_type": task["task_type"],
            "status": "FAIL" if over_budget else "PASS",
            "core_note_count": len(task["core_notes"]),
            "max_core_notes": task["max_core_notes"],
            "detail": task["detail_rule"],
        })
    fail_count = sum(1 for item in checks if item["status"] == "FAIL")
    payload = {
        "schema_version": 1,
        "generated_at": utc_now(),
        "status": "PASS" if fail_count == 0 else "FAIL",
        "source": "fresh_session_context_budget",
        "budget_rule": "Start note -> canonical decision/rule -> capability registry -> one relevant detail surface.",
        "max_default_core_notes": 4,
        "overview_required_when": "If a task needs more than four core notes, create or update an overview note before continuing.",
        "task_count": len(tasks),
        "tasks": tasks,
        "checks": checks,
        "fail_count": fail_count,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
        "next_safe_step": "Use this budget before loading old reports, large attachments or multiple capability sources into a fresh session.",
    }
    if write:
        paths = registry_paths(output_dir)
        write_json(paths["fresh_session_budget_json"], payload)
        paths["fresh_session_budget_md"].write_text(fresh_session_context_budget_to_markdown(payload), encoding="utf-8")
    return payload


def build_background_quality_gates(*, output_dir: Path, docs_dir: Path, write: bool = True) -> dict[str, Any]:
    registry = build_capability_registry(output_dir=output_dir, docs_dir=docs_dir, write=write)
    records = {record.get("capability_id"): record for record in registry.get("records", [])}
    expected = {
        "design_quality_gate": {
            "checklist": [
                "screen matches product domain, not marketing by default",
                "layout density and scan paths fit repeated work",
                "text fits containers on mobile and desktop",
                "expected controls use familiar component patterns",
                "browser/screenshot verification exists for UI changes",
            ],
            "integration_points": ["frontend build", "UI audit", "operator surface review"],
        },
        "motion_quality_gate": {
            "checklist": [
                "motion has a product purpose",
                "animation frequency does not fight repeated use",
                "reduced-motion behavior is considered",
                "performance and layout stability are checked",
            ],
            "integration_points": ["frontend build", "interactive UI review", "video or motion-heavy surface"],
        },
        "anti_slop_ui_review": {
            "checklist": [
                "no placeholder or generic AI copy remains",
                "decorative cards do not replace real workflow controls",
                "visual polish does not hide missing behavior",
                "domain-specific information is visible in the first working view",
            ],
            "integration_points": ["UI polish request", "dashboard review", "landing/tool surface review"],
        },
        "readable_report_delivery_standard": {
            "checklist": [
                "evidence layer exists",
                "readable DR overview exists for larger audits",
                "PDF exists for document-like reports",
                "generated file is verified after export",
            ],
            "integration_points": ["repo audit", "benchmark report", "strategy or decision report"],
        },
    }
    gates = []
    checks = []
    for capability_id, gate_spec in expected.items():
        record = records.get(capability_id, {})
        ok = bool(record) and record.get("is_agent") is False and record.get("agentization_status") == "capability"
        ok = ok and bool(record.get("trigger")) and bool(record.get("forbidden_actions")) and bool(record.get("verifier"))
        gates.append({
            "gate_id": capability_id,
            "canonical_name": record.get("canonical_name", capability_id),
            "type": record.get("type", "missing"),
            "status": "PASS" if ok else "FAIL",
            "is_agent": record.get("is_agent", None),
            "runtime_classification": record.get("runtime_classification", ""),
            "trigger": record.get("trigger", []),
            "checklist": gate_spec["checklist"],
            "integration_points": gate_spec["integration_points"],
            "verifier": record.get("verifier", []),
        })
        checks.append({
            "check": capability_id,
            "status": "PASS" if ok else "FAIL",
            "detail": f"type={record.get('type', 'missing')} is_agent={record.get('is_agent', None)}",
        })
    fail_count = sum(1 for item in checks if item["status"] == "FAIL")
    payload = {
        "schema_version": 1,
        "generated_at": utc_now(),
        "status": "PASS" if fail_count == 0 else "FAIL",
        "source": "background_quality_gates",
        "gate_count": len(gates),
        "fail_count": fail_count,
        "gates": gates,
        "checks": checks,
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
        "next_safe_step": "Run the relevant gate checklist in the existing build/review flow; do not create a new agent for routine quality checks.",
    }
    if write:
        paths = registry_paths(output_dir)
        write_json(paths["background_quality_gates_json"], payload)
        paths["background_quality_gates_md"].write_text(background_quality_gates_to_markdown(payload), encoding="utf-8")
    return payload


def capability_registry_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Capability Registry",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Records: `{payload.get('summary', {}).get('record_count', 0)}`",
        f"- Fresh-session rule: {payload.get('fresh_session_rule', '')}",
        "",
        "## Records",
        "",
    ]
    for record in payload.get("records", []):
        lines.extend([
            f"### {record.get('canonical_name')}",
            "",
            f"- ID: `{record.get('capability_id')}`",
            f"- Type: `{record.get('type')}` / `{record.get('runtime_classification')}`",
            f"- Aliases: {', '.join(f'`{alias}`' for alias in record.get('aliases', []))}",
            f"- Ist: {record.get('is')}",
            f"- Ist nicht: {record.get('is_not')}",
            f"- Agent status: `{record.get('agentization_status')}`; is_agent `{record.get('is_agent')}`",
            f"- Operator gate: `{record.get('operator_gate_required')}`",
            f"- Verifier: {', '.join(f'`{item}`' for item in record.get('verifier', []))}",
            "",
        ])
    return "\n".join(lines) + "\n"


def capability_registry_audit_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Capability Registry Audit",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Records: `{payload.get('record_count', 0)}`",
        f"- Sandboxes: `{payload.get('sandbox_count', 0)}`",
        f"- Gates: `{payload.get('gate_count', 0)}`",
        f"- Benchmarks: `{payload.get('benchmark_count', 0)}`",
        f"- Agent count: `{payload.get('agent_count', 0)}`",
        f"- Fail: `{payload.get('fail_count', 0)}`",
        f"- Warn: `{payload.get('warn_count', 0)}`",
        "",
        "## Checks",
        "",
    ]
    for check in payload.get("checks", []):
        lines.append(f"- `{check.get('status')}` `{check.get('name')}`: {check.get('detail')}")
    lines.extend(["", "## Capabilities", ""])
    for item in payload.get("capabilities", []):
        lines.append(
            f"- `{item.get('type')}` `{item.get('canonical_name')}` "
            f"({item.get('runtime_classification')}, agent `{item.get('is_agent')}`)"
        )
    return "\n".join(lines) + "\n"


def capability_telemetry_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Capability Registry Telemetry",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Items: `{payload.get('item_count', 0)}`",
        f"- Usage total: `{payload.get('usage_total', 0)}`",
        f"- Ledger events: `{payload.get('ledger_event_count', 0)}`",
        f"- Verified value: `{payload.get('verified_value_total', 0)}`",
        f"- Risks blocked: `{payload.get('risk_blocked_total', 0)}`",
        f"- Better documents: `{payload.get('better_document_total', 0)}`",
        f"- Verified surfaces: `{payload.get('verified_surface_total', 0)}`",
        f"- Agent candidates: `{payload.get('agent_candidate_count', 0)}`",
        f"- Source ledger: `{payload.get('source_ledger', payload.get('ledger_path', ''))}`",
        "",
        "## Checks",
        "",
    ]
    for check in payload.get("checks", []):
        lines.append(f"- `{check.get('status')}` `{check.get('name')}`: {check.get('detail')}")
    lines.extend([
        "",
        "## Items",
        "",
    ])
    for item in payload.get("items", []):
        lines.append(
            f"- `{item.get('capability_id')}` {item.get('canonical_name')}: "
            f"{item.get('telemetry_state')} / usage `{item.get('usage_count')}` / "
            f"verified `{item.get('verified_value_count')}` / risk `{item.get('risk_blocked_count')}` / "
            f"candidate `{item.get('agent_candidate_ready')}`"
        )
    lines.extend(["", "## Recent Events", ""])
    for event in payload.get("recent_events", []):
        lines.append(
            f"- `{event.get('triggered_at')}` `{event.get('capability_id')}`: {event.get('outcome')}"
        )
    return "\n".join(lines) + "\n"


def agentization_gate_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Agentization Decision Gate",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Required lifecycle: {payload.get('required_lifecycle', '')}",
        f"- Approved agents: `{payload.get('approved_agent_count', 0)}`",
        f"- Candidate agents: `{payload.get('candidate_agent_count', 0)}`",
        f"- Stay capabilities: `{payload.get('stay_capability_count', 0)}`",
        f"- Unsupported candidates: `{payload.get('unsupported_candidate_count', 0)}`",
        "",
        "## Checks",
        "",
    ]
    for check in payload.get("checks", []):
        lines.append(f"- `{check.get('status')}` `{check.get('name')}`: {check.get('detail')}")
    lines.extend(["", "## Decisions", ""])
    for item in payload.get("decisions", []):
        missing = ", ".join(item.get("missing_evidence", [])) or "none"
        lines.append(
            f"- `{item.get('decision')}` `{item.get('capability_id')}` "
            f"usage `{item.get('usage_count')}` verified `{item.get('verified_value_count')}` "
            f"missing: {missing}"
        )
    return "\n".join(lines) + "\n"


def agent_product_maturity_contract_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Agent Product Maturity Contract",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Mode: `{payload.get('mode', '')}`",
        f"- Candidates: `{payload.get('candidate_agent_count', 0)}`",
        f"- Approved agents: `{payload.get('approved_agent_count', 0)}`",
        f"- Product-ready contracts: `{payload.get('product_contract_ready_count', 0)}`",
        "",
        "## Required Fields",
        "",
    ]
    for field in payload.get("required_contract_fields", []):
        lines.append(f"- `{field}`")
    lines.extend(["", "## Readiness Dimensions", ""])
    for item in payload.get("readiness_dimensions", []):
        lines.append(f"- `{item.get('status')}` `{item.get('dimension')}`")
    lines.extend(["", "## Candidate Contracts", ""])
    if not payload.get("candidate_contracts"):
        lines.append("- No agent candidates. All ideas remain capabilities, gates, benchmarks, sandboxes or review modes.")
    for item in payload.get("candidate_contracts", []):
        lines.append(
            f"- `{item.get('status')}` `{item.get('capability_id')}` ready `{item.get('ready_for_productized_agent')}`"
        )
    lines.extend(["", "## Checks", ""])
    for check in payload.get("checks", []):
        lines.append(f"- `{check.get('status')}` `{check.get('name')}`: {check.get('detail')}")
    return "\n".join(lines) + "\n"


def shannon_sandbox_contract_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Shannon Security Sandbox Contract",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Canonical name: `{payload.get('canonical_name', '')}`",
        f"- Aliases: {', '.join(f'`{alias}`' for alias in payload.get('aliases', []))}",
        f"- Runtime action executed: `{payload.get('runtime_action_executed')}`",
        f"- External action executed: `{payload.get('external_action_executed')}`",
        "",
        "## Hard Gates",
        "",
    ]
    for gate in payload.get("hard_gates", []):
        lines.append(f"- {gate}")
    lines.extend(["", "## Forbidden Actions", ""])
    for action in payload.get("forbidden_actions", []):
        lines.append(f"- {action}")
    lines.extend(["", "## Checks", ""])
    for check in payload.get("checks", []):
        lines.append(f"- `{check.get('status')}` `{check.get('name')}`: {check.get('detail')}")
    return "\n".join(lines) + "\n"


def fresh_session_context_budget_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Fresh Session Context Budget",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Max default core notes: `{payload.get('max_default_core_notes', 0)}`",
        f"- Rule: {payload.get('budget_rule', '')}",
        f"- Overview required when: {payload.get('overview_required_when', '')}",
        "",
        "## Task Budgets",
        "",
    ]
    for task in payload.get("tasks", []):
        lines.extend([
            f"### {task.get('task_type')}",
            "",
            f"- Max core notes: `{task.get('max_core_notes')}`",
            f"- Core notes: {', '.join(f'`{note}`' for note in task.get('core_notes', []))}",
            f"- Detail rule: {task.get('detail_rule')}",
            "",
        ])
    lines.extend(["## Checks", ""])
    for check in payload.get("checks", []):
        lines.append(
            f"- `{check.get('status')}` `{check.get('task_type')}`: "
            f"{check.get('core_note_count')}/{check.get('max_core_notes')} core notes"
        )
    return "\n".join(lines) + "\n"


def background_quality_gates_to_markdown(payload: dict[str, Any]) -> str:
    lines = [
        "# Background Quality Gates",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Gates: `{payload.get('gate_count', 0)}`",
        f"- Fail: `{payload.get('fail_count', 0)}`",
        "",
        "## Gates",
        "",
    ]
    for gate in payload.get("gates", []):
        lines.extend([
            f"### {gate.get('canonical_name')}",
            "",
            f"- Status: `{gate.get('status')}`",
            f"- Type: `{gate.get('type')}`",
            f"- Is agent: `{gate.get('is_agent')}`",
            f"- Integration: {', '.join(f'`{item}`' for item in gate.get('integration_points', []))}",
            "",
            "Checklist:",
        ])
        for item in gate.get("checklist", []):
            lines.append(f"- {item}")
        lines.append("")
    lines.extend(["## Checks", ""])
    for check in payload.get("checks", []):
        lines.append(f"- `{check.get('status')}` `{check.get('check')}`: {check.get('detail')}")
    return "\n".join(lines) + "\n"
