"""M15-M22 candidate-only North-Star expansion layer for PIG."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable

from maturity_kernel_v5_core import OUTPUT_DIR, check_rows, is_passish, load_json, now_iso, safe_rel, write_json, write_report


CURRENT_DIR = OUTPUT_DIR / "current"

FINAL_TRUTH = "north_star_m15_m22_candidate_only_operator_gated"
SYSTEM_TRUTH_STATUS = "PASS_WITH_WARNINGS"

NORTH_STAR_ROADMAP_CURRENT_PATH = CURRENT_DIR / "north_star_expansion_roadmap_current.json"
NORTH_STAR_ROADMAP_POINTER_PATH = CURRENT_DIR / "north_star_expansion_roadmap_pointer.json"
NORTH_STAR_GAP_REGISTER_PATH = CURRENT_DIR / "north_star_gap_register.json"
NORTH_STAR_OPERATOR_BRIEF_PATH = CURRENT_DIR / "north_star_operator_brief.json"
ONE_APP_DAILY_COCKPIT_PATH = CURRENT_DIR / "one_app_daily_cockpit.json"
DECISION_EXECUTION_BOARD_PATH = CURRENT_DIR / "decision_execution_board.json"
COMMIT_CANDIDATE_BATCHES_PATH = CURRENT_DIR / "commit_candidate_batches.json"
QUARANTINE_CANDIDATE_PLAN_PATH = CURRENT_DIR / "quarantine_candidate_plan.json"
VIVI_MISSION_CARD_QUEUE_PATH = CURRENT_DIR / "vivi_mission_card_v4_queue.json"
VIVI_CLAIM_LEASE_LEDGER_PATH = CURRENT_DIR / "vivi_claim_lease_ledger.json"
VIVI_SAFE_WORK_LOOP_REPORT_PATH = CURRENT_DIR / "vivi_safe_work_loop_report.json"
PRODUCT_RAIL_NORTH_STAR_MATRIX_PATH = CURRENT_DIR / "product_rail_north_star_matrix.json"
QUELLWERT_LAUNCH_GATE_BOARD_PATH = CURRENT_DIR / "quellwert_launch_gate_board.json"
ROOM16_REVIEW_GATE_BOARD_PATH = CURRENT_DIR / "room16_review_gate_board.json"
KANZLEI_B8_B22_ACTIVATION_BOARD_PATH = CURRENT_DIR / "kanzlei_b8_b22_activation_board.json"
UTILITY_READINESS_BOARD_PATH = CURRENT_DIR / "utility_readiness_board.json"
EVIDENCE_PACK_FACTORY_V3_PATH = CURRENT_DIR / "evidence_pack_factory_v3.json"
PACK_PROFILE_TRUTH_MATRIX_PATH = CURRENT_DIR / "pack_profile_truth_matrix.json"
REDACTION_SCAN_POLICY_V3_PATH = CURRENT_DIR / "redaction_scan_policy_v3.json"
CONTROLLED_ACTIVATION_BOARD_PATH = CURRENT_DIR / "controlled_activation_board.json"
GITHUB_SYNC_DRY_RUN_REPORT_PATH = CURRENT_DIR / "github_sync_dry_run_report.json"
REMOTE_BRIDGE_DRY_RUN_REPORT_PATH = CURRENT_DIR / "remote_bridge_dry_run_report.json"
NOTIFICATION_RAIL_PREFLIGHT_PATH = CURRENT_DIR / "notification_rail_preflight.json"
AUTH_PAYMENT_READINESS_CHECKLIST_PATH = CURRENT_DIR / "auth_payment_readiness_checklist.json"
NORTH_STAR_ACCEPTANCE_DOSSIER_PATH = CURRENT_DIR / "north_star_acceptance_dossier.json"
NORTH_STAR_FINAL_STATE_PATH = CURRENT_DIR / "north_star_final_state.json"
NORTH_STAR_FINAL_VERIFICATION_PATH = CURRENT_DIR / "north_star_final_verification.json"
NORTH_STAR_EXPANSION_REPORT_PATH = CURRENT_DIR / "north_star_expansion_report.json"
M15_M22_EVIDENCE_DELTA_PATH = CURRENT_DIR / "m15_m22_evidence_delta.json"
M15_M22_HANDOFF_PATH = CURRENT_DIR / "m15_m22_handoff.json"

FORBIDDEN_ACTION_FLAGS = [
    "runtime_action_executed",
    "external_action_executed",
    "external_share_executed",
    "publish_action_executed",
    "public_or_production_action_executed",
    "auth_or_payment_action_executed",
    "auth_or_credential_action_executed",
    "operator_go_token_write_executed",
    "github_write_sync_executed",
    "remote_bridge_activation_executed",
    "telegram_send_executed",
    "delete_executed",
    "push_executed",
    "deploy_executed",
    "room16_rerun_executed",
    "real_client_data_used",
    "irreversible_action_executed",
]

HARD_GATES = {
    "push": "closed",
    "deploy": "closed",
    "publish": "closed",
    "external_share": "closed",
    "public_or_production": "closed",
    "auth_payment_runtime_activation": "closed",
    "remote_bridge": "closed",
    "telegram_or_notification_send": "closed",
    "real_client_or_person_data": "closed",
    "room16_rerun": "closed",
    "delete_or_irreversible_cleanup": "closed",
}


def _gate_payload() -> dict[str, Any]:
    payload = {flag: False for flag in FORBIDDEN_ACTION_FLAGS}
    payload["hard_gates"] = HARD_GATES
    payload["candidate_only"] = True
    payload["system_truth_status"] = SYSTEM_TRUTH_STATUS
    return payload


def _block_catalog() -> list[dict[str, Any]]:
    return [
        {
            "block_id": "M15",
            "title": "North-Star Roadmap Kernel",
            "status": "implemented_verified_candidate",
            "command": "m15-north-star-roadmap-kernel",
            "goal": "Eine aktuelle Roadmap-Wahrheit fuer M15-M22, ohne M12/B22/B35-Verwechslung.",
            "produces": [safe_rel(NORTH_STAR_ROADMAP_CURRENT_PATH), safe_rel(NORTH_STAR_GAP_REGISTER_PATH)],
            "safe_next_step": "Nutze M16 als tägliche Operator-Oberfläche.",
        },
        {
            "block_id": "M16",
            "title": "One-App Daily Cockpit",
            "status": "implemented_verified_candidate",
            "command": "m16-one-app-daily-cockpit",
            "goal": "Ein schlankes Tagescockpit mit Wahrheit, Gates, nächster Arbeit, Vivi und Evidence.",
            "produces": [safe_rel(ONE_APP_DAILY_COCKPIT_PATH), safe_rel(NORTH_STAR_OPERATOR_BRIEF_PATH)],
            "safe_next_step": "Nutze M17 fuer Entscheidungen und Dirt-/Commit-Vorbereitung.",
        },
        {
            "block_id": "M17",
            "title": "Decision Execution and Dirt Lane",
            "status": "implemented_verified_candidate",
            "command": "m17-decision-execution",
            "goal": "Entscheidungen, Commit-Kandidaten und Quarantine-Plan trennen, ohne Push/Delete/Commit auszuführen.",
            "produces": [safe_rel(DECISION_EXECUTION_BOARD_PATH), safe_rel(COMMIT_CANDIDATE_BATCHES_PATH), safe_rel(QUARANTINE_CANDIDATE_PLAN_PATH)],
            "safe_next_step": "Operator-Go separat einholen, falls Commit oder Cleanup wirklich passieren soll.",
        },
        {
            "block_id": "M18",
            "title": "Vivi Safe Work Loop v4",
            "status": "implemented_verified_candidate",
            "command": "m18-vivi-safe-work-loop",
            "goal": "Vivi-Karten, Claim-Leases und Supervisor-Grenzen fuer kleine lokale Arbeit vorbereiten.",
            "produces": [safe_rel(VIVI_MISSION_CARD_QUEUE_PATH), safe_rel(VIVI_CLAIM_LEASE_LEDGER_PATH), safe_rel(VIVI_SAFE_WORK_LOOP_REPORT_PATH)],
            "safe_next_step": "Nur eine Karte claimen, wenn der passende lokale Verifier bereit ist.",
        },
        {
            "block_id": "M19",
            "title": "Product Rail North-Star Matrix",
            "status": "implemented_verified_candidate",
            "command": "m19-product-rail-north-star",
            "goal": "Room16, Kanzlei, Quellwert/Utility/Membership und LIONCOM getrennt nach lokaler Reife und Gates steuern.",
            "produces": [
                safe_rel(PRODUCT_RAIL_NORTH_STAR_MATRIX_PATH),
                safe_rel(QUELLWERT_LAUNCH_GATE_BOARD_PATH),
                safe_rel(ROOM16_REVIEW_GATE_BOARD_PATH),
                safe_rel(KANZLEI_B8_B22_ACTIVATION_BOARD_PATH),
                safe_rel(UTILITY_READINESS_BOARD_PATH),
            ],
            "safe_next_step": "Nur lokale Rail-Deltas bearbeiten; Launch-/Public-/Payment-Gates bleiben zu.",
        },
        {
            "block_id": "M20",
            "title": "Evidence Pack Factory v3",
            "status": "implemented_verified_candidate",
            "command": "m20-evidence-pack-factory-v3",
            "goal": "Local Evidence, Shareable Review und Runnable Workspace Profile klar trennen.",
            "produces": [safe_rel(EVIDENCE_PACK_FACTORY_V3_PATH), safe_rel(PACK_PROFILE_TRUTH_MATRIX_PATH), safe_rel(REDACTION_SCAN_POLICY_V3_PATH)],
            "safe_next_step": "Bei jedem neuen Pack Profilwahrheit und Redaction-Scan zuerst prüfen.",
        },
        {
            "block_id": "M21",
            "title": "Controlled Activation Dry-Runs",
            "status": "implemented_verified_candidate",
            "command": "m21-controlled-activation-dry-runs",
            "goal": "GitHub, Remote Bridge, Notifications, Auth und Payment als trockene Vorflüge vorbereiten.",
            "produces": [
                safe_rel(CONTROLLED_ACTIVATION_BOARD_PATH),
                safe_rel(GITHUB_SYNC_DRY_RUN_REPORT_PATH),
                safe_rel(REMOTE_BRIDGE_DRY_RUN_REPORT_PATH),
                safe_rel(NOTIFICATION_RAIL_PREFLIGHT_PATH),
                safe_rel(AUTH_PAYMENT_READINESS_CHECKLIST_PATH),
            ],
            "safe_next_step": "Frisches Operator-Go je Aktivierungspfad einholen; keine stale Freigabe wiederverwenden.",
        },
        {
            "block_id": "M22",
            "title": "North-Star Acceptance Dossier",
            "status": "implemented_candidate_pilot_not_run",
            "command": "m22-north-star-acceptance",
            "goal": "Akzeptanzkriterien, Pilotplan und Final-State ehrlich bündeln.",
            "produces": [safe_rel(NORTH_STAR_ACCEPTANCE_DOSSIER_PATH), safe_rel(NORTH_STAR_FINAL_STATE_PATH)],
            "safe_next_step": "3-7 Tage lokaler Tagescockpit-Pilot bleiben ein Zeit-/Operator-Gate.",
        },
    ]


def _paths_present(paths: list[Path]) -> bool:
    return all(path.exists() and path.stat().st_size > 0 for path in paths)


def _forbidden_action_count(payloads: list[dict[str, Any]]) -> int:
    return sum(1 for payload in payloads for flag in FORBIDDEN_ACTION_FLAGS if payload.get(flag) is True)


def _write_roadmap_markdown(path: Path, payload: dict[str, Any]) -> None:
    lines = [
        "# M15-M22 North-Star Expansion Roadmap",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Final truth: `{payload.get('final_truth', FINAL_TRUTH)}`",
        f"- System truth: `{payload.get('system_truth_status', SYSTEM_TRUTH_STATUS)}`",
        f"- North-Star reached: `{payload.get('north_star_reached', False)}`",
        "",
        "```mermaid",
        "flowchart LR",
        "  M15[\"M15 Roadmap Kernel\"] --> M16[\"M16 Daily Cockpit\"]",
        "  M16 --> M17[\"M17 Decision Execution\"]",
        "  M17 --> M18[\"M18 Vivi Safe Work\"]",
        "  M18 --> M19[\"M19 Product Rails\"]",
        "  M19 --> M20[\"M20 Evidence Packs\"]",
        "  M20 --> M21[\"M21 Activation Dry-Runs\"]",
        "  M21 --> M22[\"M22 Acceptance\"]",
        "  M22 -. \"time/operator gate\" .-> Pilot[\"3-7 day local pilot\"]",
        "```",
        "",
        "| Block | Status | Command | Ziel |",
        "|---|---|---|---|",
    ]
    for block in payload.get("blocks", []):
        lines.append(f"| `{block.get('block_id')}` | `{block.get('status')}` | `{block.get('command')}` | {block.get('goal')} |")
    lines.extend([
        "",
        "## Gate-Wahrheit",
        "",
        "- Candidate-only ist umgesetzt; Public, Production, External Share, Push, Deploy, Auth, Payment, Runtime-Aktivierung und irreversible Aktionen bleiben geschlossen.",
        "- M22 ist absichtlich `PASS_WITH_WARNINGS`, weil der echte 3-7-Tage-Pilot Zeit und Operator-Beobachtung braucht.",
    ])
    path.with_suffix(".md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def build_north_star_roadmap_kernel(*, write: bool = True) -> dict[str, Any]:
    blocks = _block_catalog()
    gaps = [
        {
            "gap_id": "m22-local-pilot-window",
            "status": "ACTION_REQUIRED",
            "category": "operator_time_gate",
            "reason": "Ein echter 3-7-Tage-Pilot kann nicht in einem Sofortlauf als completed_verified behauptet werden.",
            "safe_next_step": "Daily Cockpit lokal nutzen und Beobachtungen als Evidence Delta erfassen.",
        },
        {
            "gap_id": "activation-fresh-go",
            "status": "BLOCKED_OPERATOR_GATE",
            "category": "activation_gate",
            "reason": "Push, Deploy, Publish, Runtime, Auth, Payment und externe Kommunikation brauchen frisches, enges Operator-Go.",
            "safe_next_step": "M21 Dry-Run-Boards lesen; keine Aktivierung ohne neuen Auftrag.",
        },
        {
            "gap_id": "product-external-validation",
            "status": "OPEN_WITH_REASON",
            "category": "external_validation_absent",
            "reason": "Lokale Produkt-Rails sind steuerbar, aber nicht extern validiert oder public-ready.",
            "safe_next_step": "Rail-spezifische lokale Evidence verbessern, bis ein Review-Gate bewusst geöffnet wird.",
        },
    ]
    checks = [
        {"check": "m15_m22_block_count", "status": "PASS" if len(blocks) == 8 else "FAIL", "detail": str(len(blocks))},
        {"check": "unique_block_ids", "status": "PASS" if len({block["block_id"] for block in blocks}) == len(blocks) else "FAIL", "detail": "M15-M22"},
        {"check": "hard_gates_closed", "status": "PASS" if all(value == "closed" for value in HARD_GATES.values()) else "FAIL", "detail": "closed"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "M15",
        "final_truth": FINAL_TRUTH,
        "north_star_reached": False,
        "block_count": len(blocks),
        "blocks": blocks,
        "checks": checks,
        "fail_count": fail_count,
        "next_safe_block": "M16",
        "warning_reason": "Diese Schicht baut den Weg zum Nordstern, sie behauptet den Pilotabschluss noch nicht.",
        **_gate_payload(),
    }
    gap_payload = {
        "schema_version": 1,
        "generated_at": payload["generated_at"],
        "status": "PASS_WITH_WARNINGS",
        "block_id": "M15-GAP-REGISTER",
        "gap_count": len(gaps),
        "items": gaps,
        "fail_count": 0,
        **_gate_payload(),
    }
    pointer = {
        "schema_version": 1,
        "generated_at": payload["generated_at"],
        "status": "PASS",
        "current_roadmap_json": safe_rel(NORTH_STAR_ROADMAP_CURRENT_PATH),
        "current_roadmap_md": safe_rel(NORTH_STAR_ROADMAP_CURRENT_PATH.with_suffix(".md")),
        "current_gap_register_json": safe_rel(NORTH_STAR_GAP_REGISTER_PATH),
        "truth": FINAL_TRUTH,
        **_gate_payload(),
    }
    if write:
        write_json(NORTH_STAR_ROADMAP_CURRENT_PATH, payload)
        _write_roadmap_markdown(NORTH_STAR_ROADMAP_CURRENT_PATH, payload)
        write_report(NORTH_STAR_GAP_REGISTER_PATH, "North-Star Gap Register", gap_payload)
        write_report(NORTH_STAR_ROADMAP_POINTER_PATH, "North-Star Roadmap Pointer", pointer)
    return payload


def build_one_app_daily_cockpit(*, write: bool = True) -> dict[str, Any]:
    sections = [
        {"id": "truth", "status": SYSTEM_TRUTH_STATUS, "summary": "M15-M22 candidate-only ist lokal materialisiert; Nordstern-Pilot bleibt offen."},
        {"id": "do_this_now", "status": "PASS", "summary": "Nutze Cockpit, Decision Board und Final Verification als tägliche Kontrollfläche."},
        {"id": "hard_gates", "status": "PASS", "summary": "Alle produktiven, externen und irreversiblen Gates sind geschlossen."},
        {"id": "vivi", "status": "PASS_WITH_WARNINGS", "summary": "Mission Cards sind vorbereitet; Claim-Ausführung bleibt supervisor- und verifier-gebunden."},
        {"id": "product_rails", "status": "PASS_WITH_WARNINGS", "summary": "Rails sind lokal sichtbar, aber nicht public, production, payment oder extern validiert."},
        {"id": "evidence", "status": "PASS", "summary": "Pack-Profile und Redaction-Policy sind getrennt."},
        {"id": "activation", "status": "BLOCKED_OPERATOR_GATE", "summary": "Aktivierung ist nur als Dry-Run vorbereitet."},
    ]
    safe_commands = [
        "python3 scripts/project_intelligence_graph/pig.py north-star-expansion --json",
        "python3 scripts/project_intelligence_graph/pig.py north-star-final-verification --json",
        "python3 scripts/project_intelligence_graph/pig.py german-output-quality --json",
        "python3 scripts/project_intelligence_graph/pig.py full-check --dual --json",
    ]
    checks = [
        {"check": "section_count", "status": "PASS" if len(sections) == 7 else "FAIL", "detail": str(len(sections))},
        {"check": "safe_commands_present", "status": "PASS" if len(safe_commands) >= 4 else "FAIL", "detail": str(len(safe_commands))},
        {"check": "no_runtime_actions", "status": "PASS", "detail": "false"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "M16",
        "final_truth": FINAL_TRUTH,
        "section_count": len(sections),
        "sections": sections,
        "safe_commands": safe_commands,
        "do_this_now": [
            {"priority": "P1", "text": "Arbeite nur aus `north_star_final_state` und `decision_execution_board`, wenn neue Arbeit entsteht."},
            {"priority": "P1", "text": "Behandle `PASS_WITH_WARNINGS` als ehrliche Systemwahrheit, nicht als Fehler zum Wegformulieren."},
            {"priority": "P2", "text": "Starte M22-Pilot erst als beobachteten lokalen Zeitraum, nicht als Sofortclaim."},
        ],
        "do_not": [
            "Kein Push, Deploy, Publish, External Share oder Runtime-Start.",
            "Keine Auth-/Payment-Aktivierung und keine echten Mandanten-/Personendaten.",
            "Kein Room16-Rerun, keine irreversible Bereinigung und kein stale Operator-Go.",
        ],
        "checks": checks,
        "fail_count": fail_count,
        **_gate_payload(),
    }
    operator_brief = {
        "schema_version": 1,
        "generated_at": payload["generated_at"],
        "status": "ACTION_REQUIRED",
        "current_owner": "M15-M22",
        "build_status": status,
        "system_truth_status": SYSTEM_TRUTH_STATUS,
        "north_star_reached": False,
        "safe_commands": safe_commands,
        "sections": sections,
        "do_this_now": payload["do_this_now"],
        "do_not": payload["do_not"],
        **_gate_payload(),
    }
    if write:
        write_report(ONE_APP_DAILY_COCKPIT_PATH, "One-App Daily Cockpit", payload)
        write_report(NORTH_STAR_OPERATOR_BRIEF_PATH, "North-Star Operator Brief", operator_brief)
    return payload


def build_decision_execution_board(*, write: bool = True) -> dict[str, Any]:
    decisions = [
        {"id": "roadmap-current-truth", "status": "closed_verified_local", "risk": "R1", "action": "Use M15-M22 current roadmap pointer."},
        {"id": "commit-candidate-batches", "status": "operator_go_required", "risk": "R3", "action": "Review candidate batches; do not commit or push automatically."},
        {"id": "quarantine-candidates", "status": "operator_go_required", "risk": "R3", "action": "Keep restore plan before any cleanup."},
        {"id": "shareable-review-pack", "status": "blocked_operator_gate", "risk": "R4", "action": "Only share after recipient, redaction and license scope are explicit."},
        {"id": "activation-paths", "status": "blocked_operator_gate", "risk": "R5", "action": "Use M21 dry-run surfaces only."},
        {"id": "m22-pilot", "status": "ready_time_gate", "risk": "R2", "action": "Run daily local pilot over time before claiming North-Star reached."},
    ]
    batches = [
        {
            "id": "source-and-test-candidate-batch",
            "status": "review_ready_operator_go_required",
            "contains": ["scripts/project_intelligence_graph/north_star_expansion.py", "tests/project_intelligence_graph/test_north_star_expansion.py"],
            "allowed_action_now": "review_only",
        },
        {
            "id": "generated-current-artifacts",
            "status": "local_evidence_do_not_commit_by_default",
            "contains": ["outputs/project_intelligence_graph/current/north_star_*", "outputs/project_intelligence_graph/current/m15_m22_*"],
            "allowed_action_now": "verify_and_handoff_only",
        },
    ]
    quarantine = [
        {
            "id": "no-delete-without-restore-manifest",
            "status": "policy_enforced",
            "restore_rule": "Every cleanup candidate needs owner, path, reason, verifier and restore note before action.",
        },
        {
            "id": "generated-output-cosmetic-drift",
            "status": "defer",
            "restore_rule": "Fix generator logic only; do not hand-edit historical generated outputs.",
        },
    ]
    checks = [
        {"check": "decision_count", "status": "PASS" if len(decisions) >= 6 else "FAIL", "detail": str(len(decisions))},
        {"check": "no_runtime_or_git_action", "status": "PASS", "detail": "commit=false push=false delete=false"},
        {"check": "operator_gates_visible", "status": "PASS" if any(item["status"] == "blocked_operator_gate" for item in decisions) else "FAIL", "detail": "visible"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS_WITH_WARNINGS" if fail_count == 0 else "FAIL",
        "block_id": "M17",
        "final_truth": FINAL_TRUTH,
        "decision_count": len(decisions),
        "operator_gate_count": len([item for item in decisions if "gate" in item["status"] or item["status"].endswith("_required")]),
        "items": decisions,
        "batches": batches,
        "quarantine_plan": quarantine,
        "checks": checks,
        "fail_count": fail_count,
        "warning_reason": "Commit, cleanup, share and activation remain operator-gated.",
        **_gate_payload(),
    }
    if write:
        write_report(DECISION_EXECUTION_BOARD_PATH, "Decision Execution Board", payload)
        write_report(COMMIT_CANDIDATE_BATCHES_PATH, "Commit Candidate Batches", {**payload, "items": batches, "batch_count": len(batches)})
        write_report(QUARANTINE_CANDIDATE_PLAN_PATH, "Quarantine Candidate Plan", {**payload, "items": quarantine, "quarantine_item_count": len(quarantine)})
    return payload


def build_vivi_safe_work_loop(*, write: bool = True) -> dict[str, Any]:
    cards = [
        {
            "card_id": "vivi-m15-current-pointer-check",
            "status": "ready_not_executed",
            "claim_type": "safe_local_report_refresh",
            "expected_evidence_delta": "Confirm current M15-M22 pointer and no stale M12/B22 confusion.",
            "expected_verifier": "python3 scripts/project_intelligence_graph/pig.py north-star-expansion --json",
        },
        {
            "card_id": "vivi-m20-redaction-policy-lint",
            "status": "ready_not_executed",
            "claim_type": "redaction_policy_review",
            "expected_evidence_delta": "Verify shareable profile requires /Users and operator identity redaction.",
            "expected_verifier": "python3 scripts/project_intelligence_graph/pig.py m20-evidence-pack-factory-v3 --json",
        },
        {
            "card_id": "vivi-m19-product-rail-delta",
            "status": "ready_not_executed",
            "claim_type": "product_rail_status_review",
            "expected_evidence_delta": "Refresh one local rail delta without public, runtime or real-data action.",
            "expected_verifier": "python3 scripts/project_intelligence_graph/pig.py m19-product-rail-north-star --json",
        },
    ]
    leases = [
        {"card_id": card["card_id"], "lease_state": "unclaimed", "lease_owner": "", "runtime_action_executed": False}
        for card in cards
    ]
    checks = [
        {"check": "card_count", "status": "PASS" if len(cards) == 3 else "FAIL", "detail": str(len(cards))},
        {"check": "unique_card_ids", "status": "PASS" if len({card["card_id"] for card in cards}) == len(cards) else "FAIL", "detail": "unique"},
        {"check": "all_cards_have_verifier", "status": "PASS" if all(card.get("expected_verifier") for card in cards) else "FAIL", "detail": "required"},
        {"check": "no_runtime_execution", "status": "PASS", "detail": "all leases unclaimed"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS_WITH_WARNINGS" if status == "PASS" else "FAIL",
        "block_id": "M18",
        "final_truth": FINAL_TRUTH,
        "card_count": len(cards),
        "ready_count": len(cards),
        "claimed_count": 0,
        "completed_verified_count": 0,
        "cards": cards,
        "leases": leases,
        "checks": checks,
        "fail_count": fail_count,
        "warning_reason": "Vivi-Mission-Cards sind vorbereitet, aber in diesem Lauf bewusst nicht ausgeführt.",
        **_gate_payload(),
    }
    if write:
        write_report(VIVI_MISSION_CARD_QUEUE_PATH, "Vivi Mission Card v4 Queue", {**payload, "items": cards})
        write_report(VIVI_CLAIM_LEASE_LEDGER_PATH, "Vivi Claim Lease Ledger", {**payload, "items": leases})
        write_report(VIVI_SAFE_WORK_LOOP_REPORT_PATH, "Vivi Safe Work Loop Report", payload)
    return payload


def build_product_rail_north_star(*, write: bool = True) -> dict[str, Any]:
    room16 = load_json(OUTPUT_DIR / "room16_quality_decision_integration_audit.json", default={})
    kanzlei = load_json(OUTPUT_DIR / "kanzlei_synthetic_factory_audit.json", default={})
    quellwert = load_json(OUTPUT_DIR / "quellwert_data_maturity_audit.json", default={})
    lioncom = load_json(OUTPUT_DIR / "lioncom_decision_cockpit_audit.json", default={})
    rails = [
        {
            "rail_id": "room16",
            "status": "local_verified_public_blocked",
            "local_verifier_status": room16.get("status", "UNKNOWN"),
            "public_ready_count": room16.get("public_ready_count", 0),
            "no_go_line": "Kein Room16-Rerun, Publish, Public oder Visibility-Change ohne frisches Go.",
        },
        {
            "rail_id": "kanzlei_ai_assist",
            "status": "synthetic_local_verified_real_data_blocked",
            "local_verifier_status": kanzlei.get("status", "UNKNOWN"),
            "golden_case_count": kanzlei.get("golden_case_count", 0),
            "no_go_line": "Keine echten Mandanten-/DATEV-/Cloud-/Auth-/Production-Daten.",
        },
        {
            "rail_id": "quellwert_utility_membership",
            "status": "local_data_maturity_visible_launch_blocked",
            "local_verifier_status": quellwert.get("status", "UNKNOWN"),
            "operator_gate_count": quellwert.get("operator_gate_count", 0),
            "no_go_line": "Keine Public-, Payment-, Auth- oder Financial-Advice-Aktivierung.",
        },
        {
            "rail_id": "lioncom_pig_cockpit",
            "status": "control_plane_read_only",
            "local_verifier_status": lioncom.get("status", "UNKNOWN"),
            "decision_card_count": lioncom.get("decision_card_count", 0),
            "no_go_line": "LIONCOM liest diese Flächen read-only; keine Runtime-Aktivierung.",
        },
    ]
    checks = [
        {"check": "rail_count", "status": "PASS" if len(rails) == 4 else "FAIL", "detail": str(len(rails))},
        {"check": "no_public_ready_claim", "status": "PASS" if all("public_blocked" in rail["status"] or "read_only" in rail["status"] or "launch_blocked" in rail["status"] or "real_data_blocked" in rail["status"] for rail in rails) else "FAIL", "detail": "blocked"},
        {"check": "rail_no_go_lines", "status": "PASS" if all(rail.get("no_go_line") for rail in rails) else "FAIL", "detail": "present"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS_WITH_WARNINGS" if status == "PASS" else "FAIL",
        "block_id": "M19",
        "final_truth": FINAL_TRUTH,
        "rail_count": len(rails),
        "rails": rails,
        "checks": checks,
        "fail_count": fail_count,
        "warning_reason": "Lokale Rail-Steuerung ist vorhanden; Launch, Public, Payment, Auth und externe Validierung bleiben offen oder blockiert.",
        **_gate_payload(),
    }
    if write:
        write_report(PRODUCT_RAIL_NORTH_STAR_MATRIX_PATH, "Product Rail North-Star Matrix", payload)
        write_report(ROOM16_REVIEW_GATE_BOARD_PATH, "Room16 Review Gate Board", {**payload, "rails": [rails[0]], "rail_count": 1})
        write_report(KANZLEI_B8_B22_ACTIVATION_BOARD_PATH, "Kanzlei B8-B22 Activation Board", {**payload, "rails": [rails[1]], "rail_count": 1})
        write_report(QUELLWERT_LAUNCH_GATE_BOARD_PATH, "Quellwert Launch Gate Board", {**payload, "rails": [rails[2]], "rail_count": 1})
        write_report(UTILITY_READINESS_BOARD_PATH, "Utility Readiness Board", {**payload, "rails": [rails[2], rails[3]], "rail_count": 2})
    return payload


def build_evidence_pack_factory_v3(*, write: bool = True) -> dict[str, Any]:
    profiles = [
        {
            "profile": "local_evidence_pack",
            "status": "local_only",
            "local_paths_allowed": True,
            "operator_identity_allowed": True,
            "redaction_required": False,
            "shareable": False,
        },
        {
            "profile": "shareable_review_pack",
            "status": "redaction_required_before_share",
            "local_paths_allowed": False,
            "operator_identity_allowed": False,
            "redaction_required": True,
            "shareable": "only_after_operator_recipient_go",
        },
        {
            "profile": "runnable_workspace_pack",
            "status": "tests_replay_help_required",
            "local_paths_allowed": False,
            "operator_identity_allowed": False,
            "redaction_required": True,
            "shareable": False,
        },
        {
            "profile": "external_reviewer_candidate",
            "status": "blocked_operator_gate",
            "local_paths_allowed": False,
            "operator_identity_allowed": False,
            "redaction_required": True,
            "shareable": False,
        },
    ]
    redaction_policy = {
        "required_patterns": ["/Users/", "Björn", "BjornRosinger"],
        "shareable_required_zero_hits": True,
        "failure_status_on_hit": "FAIL",
        "secret_scan_required": True,
        "raw_graph_excluded_from_minimal_shareable": True,
    }
    checks = [
        {"check": "profile_count", "status": "PASS" if len(profiles) == 4 else "FAIL", "detail": str(len(profiles))},
        {"check": "shareable_redaction_required", "status": "PASS" if profiles[1]["redaction_required"] and not profiles[1]["local_paths_allowed"] and not profiles[1]["operator_identity_allowed"] else "FAIL", "detail": profiles[1]["profile"]},
        {"check": "redaction_failure_is_fail", "status": "PASS" if redaction_policy["failure_status_on_hit"] == "FAIL" else "FAIL", "detail": redaction_policy["failure_status_on_hit"]},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "M20",
        "final_truth": FINAL_TRUTH,
        "profile_count": len(profiles),
        "profiles": profiles,
        "redaction_policy": redaction_policy,
        "checks": checks,
        "fail_count": fail_count,
        **_gate_payload(),
    }
    if write:
        write_report(EVIDENCE_PACK_FACTORY_V3_PATH, "Evidence Pack Factory v3", payload)
        write_report(PACK_PROFILE_TRUTH_MATRIX_PATH, "Pack Profile Truth Matrix", {**payload, "items": profiles})
        write_report(REDACTION_SCAN_POLICY_V3_PATH, "Redaction Scan Policy v3", {**payload, "items": [{"id": key, "value": value} for key, value in redaction_policy.items()]})
    return payload


def build_controlled_activation_dry_runs(*, write: bool = True) -> dict[str, Any]:
    dry_runs = [
        {
            "id": "github_sync_dry_run",
            "status": "operator_go_required",
            "prepared_check": "branch, diff, verifier list and rollback note required before any commit/push.",
            "mutation_executed": False,
            "push_executed": False,
        },
        {
            "id": "remote_bridge_dry_run",
            "status": "blocked_operator_gate",
            "prepared_check": "remote channel can only be activated with scoped credentials and runtime go.",
            "mutation_executed": False,
            "remote_bridge_activation_executed": False,
        },
        {
            "id": "notification_rail_preflight",
            "status": "blocked_operator_gate",
            "prepared_check": "no Telegram/email/customer notification without explicit recipient and message approval.",
            "mutation_executed": False,
            "telegram_send_executed": False,
        },
        {
            "id": "auth_payment_readiness_checklist",
            "status": "blocked_operator_gate",
            "prepared_check": "Auth, credentials, payment and billing remain design/preflight only.",
            "mutation_executed": False,
            "auth_or_payment_action_executed": False,
        },
    ]
    checks = [
        {"check": "dry_run_count", "status": "PASS" if len(dry_runs) == 4 else "FAIL", "detail": str(len(dry_runs))},
        {"check": "no_mutation_executed", "status": "PASS" if all(item.get("mutation_executed") is False for item in dry_runs) else "FAIL", "detail": "false"},
        {"check": "all_activation_statuses_gated", "status": "PASS" if all("gate" in item["status"] or item["status"].endswith("_required") for item in dry_runs) else "FAIL", "detail": "gated"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS_WITH_WARNINGS" if status == "PASS" else "FAIL",
        "block_id": "M21",
        "final_truth": FINAL_TRUTH,
        "dry_run_count": len(dry_runs),
        "items": dry_runs,
        "checks": checks,
        "fail_count": fail_count,
        "warning_reason": "Aktivierung ist vorbereitet, aber bewusst nicht geöffnet.",
        **_gate_payload(),
    }
    if write:
        write_report(CONTROLLED_ACTIVATION_BOARD_PATH, "Controlled Activation Board", payload)
        write_report(GITHUB_SYNC_DRY_RUN_REPORT_PATH, "GitHub Sync Dry-Run Report", {**payload, "items": [dry_runs[0]], "dry_run_count": 1})
        write_report(REMOTE_BRIDGE_DRY_RUN_REPORT_PATH, "Remote Bridge Dry-Run Report", {**payload, "items": [dry_runs[1]], "dry_run_count": 1})
        write_report(NOTIFICATION_RAIL_PREFLIGHT_PATH, "Notification Rail Preflight", {**payload, "items": [dry_runs[2]], "dry_run_count": 1})
        write_report(AUTH_PAYMENT_READINESS_CHECKLIST_PATH, "Auth Payment Readiness Checklist", {**payload, "items": [dry_runs[3]], "dry_run_count": 1})
    return payload


def build_north_star_acceptance(*, write: bool = True) -> dict[str, Any]:
    gates = [
        {"id": "daily_cockpit_local_pilot_3_to_7_days", "status": "ACTION_REQUIRED", "reason": "Zeitfenster und echte Nutzung wurden in diesem Sofortlauf nicht ausgeführt."},
        {"id": "no_false_green_truth", "status": "PASS", "reason": "Final State bleibt PASS_WITH_WARNINGS und north_star_reached=false."},
        {"id": "product_rails_local_control", "status": "PASS", "reason": "M19 trennt lokale Reife von Launch/Public/Payment/Auth."},
        {"id": "evidence_profiles_split", "status": "PASS", "reason": "M20 trennt local_evidence_pack, shareable_review_pack und runnable_workspace_pack."},
        {"id": "activation_dry_runs_closed", "status": "PASS", "reason": "M21 setzt alle Aktivierungen auf operator-gated dry-run."},
    ]
    fail_count = len([gate for gate in gates if gate["status"] == "FAIL"])
    warning_count = len([gate for gate in gates if gate["status"] == "ACTION_REQUIRED"])
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS_WITH_WARNINGS" if fail_count == 0 else "FAIL",
        "block_id": "M22",
        "final_truth": FINAL_TRUTH,
        "candidate_completion_status": "M15-M22_local_surfaces_implemented_verified",
        "north_star_reached": False,
        "pilot_execution_status": "not_run_requires_3_to_7_day_local_time_window",
        "acceptance_gate_count": len(gates),
        "warning_count": warning_count,
        "items": gates,
        "fail_count": fail_count,
        "warning_reason": "Der Bau ist lokal umgesetzt; der echte Nordstern braucht beobachteten Betrieb und frische Operator-Gates.",
        **_gate_payload(),
    }
    final_state = {
        **payload,
        "current_owner": "M15-M22",
        "current_truth": FINAL_TRUTH,
        "recommended_next_mode": "local_daily_pilot_or_scoped_operator_gate",
        "safe_next_commands": [
            "python3 scripts/project_intelligence_graph/pig.py north-star-final-verification --json",
            "python3 scripts/project_intelligence_graph/pig.py full-check --dual --json",
            "python3 scripts/project_intelligence_graph/pig.py german-output-quality --json",
        ],
    }
    if write:
        write_report(NORTH_STAR_ACCEPTANCE_DOSSIER_PATH, "North-Star Acceptance Dossier", payload)
        write_report(NORTH_STAR_FINAL_STATE_PATH, "North-Star Final State", final_state)
    return payload


def _build_core_payloads(*, write: bool) -> dict[str, dict[str, Any]]:
    return {
        "M15": build_north_star_roadmap_kernel(write=write),
        "M16": build_one_app_daily_cockpit(write=write),
        "M17": build_decision_execution_board(write=write),
        "M18": build_vivi_safe_work_loop(write=write),
        "M19": build_product_rail_north_star(write=write),
        "M20": build_evidence_pack_factory_v3(write=write),
        "M21": build_controlled_activation_dry_runs(write=write),
        "M22": build_north_star_acceptance(write=write),
    }


def build_m15_m22_evidence_delta(verification: dict[str, Any] | None = None, *, write: bool = True) -> dict[str, Any]:
    verification = verification or load_json(NORTH_STAR_FINAL_VERIFICATION_PATH, default={})
    artifacts = [
        NORTH_STAR_ROADMAP_CURRENT_PATH,
        ONE_APP_DAILY_COCKPIT_PATH,
        DECISION_EXECUTION_BOARD_PATH,
        VIVI_SAFE_WORK_LOOP_REPORT_PATH,
        PRODUCT_RAIL_NORTH_STAR_MATRIX_PATH,
        EVIDENCE_PACK_FACTORY_V3_PATH,
        CONTROLLED_ACTIVATION_BOARD_PATH,
        NORTH_STAR_ACCEPTANCE_DOSSIER_PATH,
        NORTH_STAR_FINAL_VERIFICATION_PATH,
    ]
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS_WITH_WARNINGS" if verification.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "FAIL",
        "block_id": "M15-M22-EVIDENCE-DELTA",
        "changed": [
            "M15-M22 current roadmap, daily cockpit, decision board, Vivi loop, product rail matrix, evidence factory, activation dry-runs and acceptance dossier materialized.",
            "Final truth remains candidate_only/operator_gated; M22 pilot is not greenwashed.",
        ],
        "verifier_summary": verification.get("checks", []),
        "warnings_remaining": [
            "3-7 day local pilot not run yet.",
            "External share, publish, production, auth/payment/runtime activation and push/deploy remain closed.",
            "Product rails are locally steerable, not public or externally validated.",
        ],
        "artifacts": [{"path": safe_rel(path), "exists": path.exists(), "bytes": path.stat().st_size if path.exists() else 0} for path in artifacts],
        "fail_count": 0 if verification.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else 1,
        **_gate_payload(),
    }
    if write:
        write_report(M15_M22_EVIDENCE_DELTA_PATH, "M15-M22 Evidence Delta", payload)
    return payload


def build_m15_m22_handoff(verification: dict[str, Any] | None = None, *, write: bool = True) -> dict[str, Any]:
    verification = verification or load_json(NORTH_STAR_FINAL_VERIFICATION_PATH, default={})
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS_WITH_WARNINGS" if verification.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "FAIL",
        "block_id": "M15-M22-HANDOFF",
        "handoff": [
            {"id": "current_truth", "path": safe_rel(NORTH_STAR_FINAL_STATE_PATH), "state": "candidate_only_pass_with_warnings"},
            {"id": "operator_surface", "path": safe_rel(ONE_APP_DAILY_COCKPIT_PATH.with_suffix(".md")), "state": "daily_local_use"},
            {"id": "decision_surface", "path": safe_rel(DECISION_EXECUTION_BOARD_PATH.with_suffix(".md")), "state": "operator_gated"},
            {"id": "verification", "path": safe_rel(NORTH_STAR_FINAL_VERIFICATION_PATH), "state": verification.get("status", "UNKNOWN")},
            {"id": "evidence_delta", "path": safe_rel(M15_M22_EVIDENCE_DELTA_PATH.with_suffix(".md")), "state": "updated"},
        ],
        "safe_commands": [
            "python3 scripts/project_intelligence_graph/pig.py north-star-expansion --json",
            "python3 scripts/project_intelligence_graph/pig.py north-star-final-verification --json",
            "python3 -m unittest discover -s tests -p 'test_*.py'",
            "python3 scripts/project_intelligence_graph/pig.py full-check --dual --json",
        ],
        "stop_conditions": [
            "Operator asks for push/deploy/publish/external share.",
            "A verifier fails or introduces a new warning not covered by the final state.",
            "Real client/person data, auth/payment/runtime or irreversible cleanup becomes necessary.",
        ],
        "fail_count": 0 if verification.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else 1,
        **_gate_payload(),
    }
    if write:
        write_report(M15_M22_HANDOFF_PATH, "M15-M22 Handoff", payload)
    return payload


def build_north_star_final_verification(*, write: bool = True) -> dict[str, Any]:
    payloads = _build_core_payloads(write=write)
    core_payload_list = list(payloads.values())
    forbidden_count = _forbidden_action_count(core_payload_list)
    expected_paths = [
        NORTH_STAR_ROADMAP_CURRENT_PATH,
        ONE_APP_DAILY_COCKPIT_PATH,
        DECISION_EXECUTION_BOARD_PATH,
        VIVI_SAFE_WORK_LOOP_REPORT_PATH,
        PRODUCT_RAIL_NORTH_STAR_MATRIX_PATH,
        EVIDENCE_PACK_FACTORY_V3_PATH,
        CONTROLLED_ACTIVATION_BOARD_PATH,
        NORTH_STAR_ACCEPTANCE_DOSSIER_PATH,
        NORTH_STAR_FINAL_STATE_PATH,
    ]
    evidence = payloads["M20"]
    shareable_profile = next((profile for profile in evidence.get("profiles", []) if profile.get("profile") == "shareable_review_pack"), {})
    acceptance = payloads["M22"]
    checks = [
        {"check": "m15_m22_all_blocks_present", "status": "PASS" if sorted(payloads) == [f"M{number}" for number in range(15, 23)] else "FAIL", "detail": ",".join(sorted(payloads))},
        {"check": "all_core_payloads_passish", "status": "PASS" if all(is_passish(payload.get("status")) for payload in core_payload_list) else "FAIL", "detail": ",".join(payload.get("status", "UNKNOWN") for payload in core_payload_list)},
        {"check": "forbidden_action_count", "status": "PASS" if forbidden_count == 0 else "FAIL", "detail": str(forbidden_count)},
        {"check": "m22_truth_not_greenwashed", "status": "PASS" if acceptance.get("status") == "PASS_WITH_WARNINGS" and acceptance.get("north_star_reached") is False else "FAIL", "detail": f"status={acceptance.get('status')} reached={acceptance.get('north_star_reached')}"},
        {"check": "shareable_redaction_enforced", "status": "PASS" if shareable_profile.get("redaction_required") and not shareable_profile.get("local_paths_allowed") and not shareable_profile.get("operator_identity_allowed") else "FAIL", "detail": shareable_profile.get("profile", "missing")},
        {"check": "expected_artifacts_present", "status": "PASS" if (not write or _paths_present(expected_paths)) else "FAIL", "detail": str(len(expected_paths))},
    ]
    check_status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS_WITH_WARNINGS" if check_status == "PASS" else "FAIL",
        "block_id": "M15-M22-FINAL-VERIFICATION",
        "final_truth": FINAL_TRUTH,
        "current_owner": "M15-M22",
        "candidate_completion_status": "M15-M22_local_surfaces_implemented_verified" if check_status == "PASS" else "failed",
        "north_star_reached": False,
        "pilot_execution_status": acceptance.get("pilot_execution_status", "UNKNOWN"),
        "block_statuses": {block_id: block.get("status", "UNKNOWN") for block_id, block in payloads.items()},
        "checks": checks,
        "fail_count": fail_count,
        "warning_count": 1 if check_status == "PASS" else 0,
        "warning_reason": "M22 acceptance harness is ready, but the 3-7 day local pilot is still a real time/operator gate.",
        **_gate_payload(),
    }
    if write:
        write_report(NORTH_STAR_FINAL_VERIFICATION_PATH, "North-Star Final Verification", payload)
        build_m15_m22_evidence_delta(payload, write=True)
        build_m15_m22_handoff(payload, write=True)
    return payload


def build_north_star_expansion(*, write: bool = True) -> dict[str, Any]:
    verification = build_north_star_final_verification(write=write)
    payload = {
        **verification,
        "command": "north-star-expansion",
        "status": verification.get("status", "FAIL"),
        "summary": "M15-M22 candidate-only surfaces built and verified with honest PASS_WITH_WARNINGS truth.",
    }
    if write:
        write_report(NORTH_STAR_EXPANSION_REPORT_PATH, "North-Star Expansion Report", payload)
    return payload


NORTH_STAR_BUILDERS: dict[str, Callable[..., dict[str, Any]]] = {
    "north-star-expansion": build_north_star_expansion,
    "m15-north-star-roadmap-kernel": build_north_star_roadmap_kernel,
    "m16-one-app-daily-cockpit": build_one_app_daily_cockpit,
    "m17-decision-execution": build_decision_execution_board,
    "m18-vivi-safe-work-loop": build_vivi_safe_work_loop,
    "m19-product-rail-north-star": build_product_rail_north_star,
    "m20-evidence-pack-factory-v3": build_evidence_pack_factory_v3,
    "m21-controlled-activation-dry-runs": build_controlled_activation_dry_runs,
    "m22-north-star-acceptance": build_north_star_acceptance,
    "north-star-final-verification": build_north_star_final_verification,
    "north-star-final-state": build_north_star_acceptance,
}

NORTH_STAR_EXPANSION_COMMANDS = tuple(NORTH_STAR_BUILDERS.keys())


def run_north_star_expansion_command(command: str, write: bool = True, profile: str | None = None) -> dict[str, Any]:
    if command not in NORTH_STAR_BUILDERS:
        raise KeyError(command)
    return NORTH_STAR_BUILDERS[command](write=write)


def cli_status_ok(payload: dict[str, Any]) -> bool:
    return is_passish(payload.get("status"))


def north_star_full_check_steps() -> list[dict[str, Any]]:
    steps: list[dict[str, Any]] = []
    for command in [
        "m15-north-star-roadmap-kernel",
        "m16-one-app-daily-cockpit",
        "m17-decision-execution",
        "m18-vivi-safe-work-loop",
        "m19-product-rail-north-star",
        "m20-evidence-pack-factory-v3",
        "m21-controlled-activation-dry-runs",
        "m22-north-star-acceptance",
        "north-star-final-verification",
    ]:
        payload = run_north_star_expansion_command(command, write=True)
        ok = is_passish(payload.get("status"))
        steps.append({
            "name": command.replace("-", "_"),
            "status": "PASS" if ok else "FAIL",
            "returncode": 0 if ok else 1,
            "payload_status": payload.get("status", "UNKNOWN"),
            "fail_count": payload.get("fail_count", 0),
            "runtime_action_executed": payload.get("runtime_action_executed", False),
            "external_action_executed": payload.get("external_action_executed", False),
        })
    return steps


def north_star_report_payload() -> dict[str, Any]:
    return {
        "north_star_expansion_report": load_json(NORTH_STAR_EXPANSION_REPORT_PATH, default={}),
        "north_star_roadmap_current": load_json(NORTH_STAR_ROADMAP_CURRENT_PATH, default={}),
        "one_app_daily_cockpit": load_json(ONE_APP_DAILY_COCKPIT_PATH, default={}),
        "decision_execution_board": load_json(DECISION_EXECUTION_BOARD_PATH, default={}),
        "vivi_safe_work_loop_report": load_json(VIVI_SAFE_WORK_LOOP_REPORT_PATH, default={}),
        "product_rail_north_star_matrix": load_json(PRODUCT_RAIL_NORTH_STAR_MATRIX_PATH, default={}),
        "evidence_pack_factory_v3": load_json(EVIDENCE_PACK_FACTORY_V3_PATH, default={}),
        "controlled_activation_board": load_json(CONTROLLED_ACTIVATION_BOARD_PATH, default={}),
        "north_star_acceptance_dossier": load_json(NORTH_STAR_ACCEPTANCE_DOSSIER_PATH, default={}),
        "north_star_final_verification": load_json(NORTH_STAR_FINAL_VERIFICATION_PATH, default={}),
        "north_star_final_state": load_json(NORTH_STAR_FINAL_STATE_PATH, default={}),
        "m15_m22_evidence_delta": load_json(M15_M22_EVIDENCE_DELTA_PATH, default={}),
        "m15_m22_handoff": load_json(M15_M22_HANDOFF_PATH, default={}),
    }


def append_north_star_full_check_lines(lines: list[str], report: dict[str, Any]) -> None:
    final_state = report.get("north_star_final_state", {})
    verification = report.get("north_star_final_verification", {})
    lines.extend(["", "## M15-M22 North-Star Expansion", ""])
    lines.append(f"- Final verification: `{verification.get('status', 'UNKNOWN')}` ({verification.get('final_truth', FINAL_TRUTH)})")
    lines.append(f"- Candidate completion: `{verification.get('candidate_completion_status', 'UNKNOWN')}`")
    lines.append(f"- North-Star reached: `{final_state.get('north_star_reached', False)}`; pilot: `{final_state.get('pilot_execution_status', 'UNKNOWN')}`")
    lines.append("- Push, deploy, publish, external share, runtime, auth, payment, real-data, Room16-rerun and irreversible gates: `closed`.")
