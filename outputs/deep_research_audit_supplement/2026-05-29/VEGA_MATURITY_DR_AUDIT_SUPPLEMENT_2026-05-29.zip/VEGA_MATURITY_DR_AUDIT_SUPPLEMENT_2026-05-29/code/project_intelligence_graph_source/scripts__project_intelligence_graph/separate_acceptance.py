#!/usr/bin/env python3
"""Run separate acceptance profiles through a stable entrypoint."""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]

PROFILE_COMMANDS = {
    "capability-governance": {
        "description": "Capability governance, agentization, LION surface, vault memory, and full-check acceptance.",
        "script": ROOT / "scripts" / "project_intelligence_graph" / "capability_governance_separate_test.py",
        "supported_flags": {"--json", "--skip-full-check", "--skip-lion"},
    },
}


def list_profiles() -> None:
    for name, profile in sorted(PROFILE_COMMANDS.items()):
        print(f"{name}\t{profile['description']}")


def build_profile_command(args: argparse.Namespace) -> list[str]:
    profile = PROFILE_COMMANDS[args.profile]
    command = [sys.executable, str(profile["script"])]
    for flag in ["--json", "--skip-full-check", "--skip-lion"]:
        if getattr(args, flag.lstrip("-").replace("-", "_")) and flag in profile["supported_flags"]:
            command.append(flag)
    return command


def main() -> int:
    parser = argparse.ArgumentParser(description="Run separate acceptance profiles.")
    parser.add_argument("--profile", default="capability-governance", choices=sorted(PROFILE_COMMANDS))
    parser.add_argument("--list-profiles", action="store_true", help="List available profiles and exit.")
    parser.add_argument("--json", action="store_true", help="Print profile JSON when supported.")
    parser.add_argument("--skip-full-check", action="store_true", help="Skip slow umbrella full-check when supported.")
    parser.add_argument("--skip-lion", action="store_true", help="Skip LION verifier and TypeScript checks when supported.")
    args = parser.parse_args()

    if args.list_profiles:
        list_profiles()
        return 0

    result = subprocess.run(build_profile_command(args), cwd=ROOT)
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
