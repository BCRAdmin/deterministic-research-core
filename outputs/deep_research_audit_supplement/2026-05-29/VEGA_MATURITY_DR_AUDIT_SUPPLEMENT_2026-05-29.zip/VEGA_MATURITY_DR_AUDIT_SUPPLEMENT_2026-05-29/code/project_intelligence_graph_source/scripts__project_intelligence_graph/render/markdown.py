"""Markdown renderer facade for PIG reports."""

from __future__ import annotations

from typing import Any

from report_markdown import render_report_markdown


def render_markdown_report(title: str, payload: dict[str, Any]) -> str:
    return render_report_markdown(title, payload)
