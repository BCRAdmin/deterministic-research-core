#!/usr/bin/env python3
"""Shared helpers for separate acceptance profiles.

This module is intentionally small. It gives project-specific acceptance
profiles a common report shape, command runner, and section/result helpers
without turning them into a config framework.
"""

from __future__ import annotations

import datetime as dt
import json
import shlex
import subprocess
import time
from pathlib import Path
from typing import Any


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def load_json(path: Path, default: Any = None) -> Any:
    if default is None:
        default = {}
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return default


def text_tail(text: str, limit: int = 1800) -> str:
    if len(text) <= limit:
        return text
    return text[-limit:]


def _clean_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return str(value)


def run_command(command: list[str], *, cwd: Path, timeout: int = 180, capture: bool = True) -> dict[str, Any]:
    started = time.monotonic()
    try:
        if capture:
            result = subprocess.run(command, cwd=cwd, text=True, capture_output=True, timeout=timeout)
            stdout = _clean_text(result.stdout)
            stderr = _clean_text(result.stderr)
        else:
            result = subprocess.run(
                command,
                cwd=cwd,
                text=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                timeout=timeout,
            )
            stdout = ""
            stderr = _clean_text(result.stderr)
        return {
            "command": shlex.join(command),
            "cwd": str(cwd),
            "returncode": result.returncode,
            "duration_seconds": round(time.monotonic() - started, 3),
            "stdout": stdout,
            "stderr": stderr,
            "stdout_tail": text_tail(stdout),
            "stderr_tail": text_tail(stderr),
            "status": "PASS" if result.returncode == 0 else "FAIL",
        }
    except subprocess.TimeoutExpired as exc:
        stdout = _clean_text(exc.stdout)
        stderr = _clean_text(exc.stderr)
        return {
            "command": shlex.join(command),
            "cwd": str(cwd),
            "returncode": None,
            "duration_seconds": round(time.monotonic() - started, 3),
            "stdout": stdout,
            "stderr": stderr,
            "stdout_tail": text_tail(stdout),
            "stderr_tail": text_tail(stderr),
            "status": "FAIL",
            "timeout_seconds": timeout,
        }


def add_result(section: dict[str, Any], result_id: str, name: str, ok: bool, detail: str, observed: Any = None) -> None:
    section["tests"].append({
        "id": result_id,
        "name": name,
        "status": "PASS" if ok else "FAIL",
        "detail": detail,
        "observed": observed,
    })


def add_payload_checks(section: dict[str, Any], prefix: str, checks: list[dict[str, Any]]) -> None:
    for item in checks:
        status = str(item.get("status", "FAIL"))
        add_result(
            section,
            f"{prefix}.{item.get('name', 'check')}",
            str(item.get("name", "check")),
            status == "PASS",
            str(item.get("detail", "")),
            item,
        )


def section_status(section: dict[str, Any]) -> str:
    return "PASS" if all(item["status"] == "PASS" for item in section["tests"]) else "FAIL"


def finalize_sections(sections: list[dict[str, Any]]) -> None:
    for section in sections:
        section["status"] = section_status(section)


def command_result(section: dict[str, Any], result_id: str, name: str, command: dict[str, Any]) -> None:
    add_result(
        section,
        result_id,
        name,
        command.get("returncode") == 0,
        f"returncode={command.get('returncode')} duration={command.get('duration_seconds')}s",
        {"stdout_tail": command.get("stdout_tail", ""), "stderr_tail": command.get("stderr_tail", "")},
    )


def status_result(section: dict[str, Any], result_id: str, name: str, payload: dict[str, Any]) -> None:
    add_result(
        section,
        result_id,
        name,
        payload.get("status") == "PASS",
        f"status={payload.get('status', 'UNKNOWN')} fail_count={payload.get('fail_count', 0)}",
        {key: payload.get(key) for key in sorted(payload.keys()) if key.endswith("_count") or key in {"status", "mode"}},
    )


def _markdown_cell(value: Any, limit: int = 500) -> str:
    text = str(value).replace("\n", " ")[:limit]
    return text.replace("|", "\\|")


def render_markdown(report: dict[str, Any]) -> str:
    title = report.get("title", "Separate Acceptance Test Report")
    summary = report["summary"]
    report_paths = report.get("report_paths", {})
    lines = [
        f"# {title}",
        "",
        f"- Status: `{report['status']}`",
        f"- Generated at: `{report['generated_at']}`",
        f"- Total tests: `{summary['total']}`",
        f"- PASS: `{summary['pass']}`",
        f"- FAIL: `{summary['fail']}`",
        f"- JSON: `{report_paths.get('json', '')}`",
        "",
        "## Operator Summary",
        "",
        "| Item | Value |",
        "|---|---:|",
    ]
    for key, value in report.get("artifacts", {}).items():
        lines.append(f"| `{_markdown_cell(key)}` | `{_markdown_cell(value)}` |")
    lines.extend(["", "## Sections", "", "| Section | Status | Tests | Fails |", "|---|---|---:|---:|"])
    for section in report["sections"]:
        fail_count = sum(1 for item in section["tests"] if item["status"] != "PASS")
        lines.append(f"| {_markdown_cell(section['title'])} | `{section['status']}` | `{len(section['tests'])}` | `{fail_count}` |")
    for section in report["sections"]:
        lines.extend(["", f"## {section['title']}", "", "| Test | Status | Detail |", "|---|---|---|"])
        for item in section["tests"]:
            lines.append(f"| `{_markdown_cell(item['id'])}` | `{item['status']}` | {_markdown_cell(item.get('detail', ''))} |")
    return "\n".join(lines) + "\n"


def build_acceptance_report(
    *,
    title: str,
    sections: list[dict[str, Any]],
    artifacts: dict[str, Any],
    report_json_path: Path,
    report_md_path: Path,
    schema_version: int = 1,
) -> dict[str, Any]:
    finalize_sections(sections)
    tests = [item for section in sections for item in section["tests"]]
    fail_count = sum(1 for item in tests if item["status"] != "PASS")
    return {
        "schema_version": schema_version,
        "title": title,
        "generated_at": now_iso(),
        "status": "PASS" if fail_count == 0 else "FAIL",
        "summary": {
            "total": len(tests),
            "pass": sum(1 for item in tests if item["status"] == "PASS"),
            "fail": fail_count,
            "section_count": len(sections),
        },
        "artifacts": artifacts,
        "sections": sections,
        "report_paths": {
            "json": str(report_json_path),
            "markdown": str(report_md_path),
        },
        "runtime_action_executed": False,
        "external_action_executed": False,
        "irreversible_action_executed": False,
    }


def write_acceptance_report(report: dict[str, Any], *, report_json_path: Path, report_md_path: Path) -> None:
    report_json_path.parent.mkdir(parents=True, exist_ok=True)
    report_json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    report_md_path.write_text(render_markdown(report), encoding="utf-8")
