"""M10 controlled activation readiness kernel for DreamFactory/PIG."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Callable

import m9_efficiency as m9
from maturity_kernel_v5_core import OUTPUT_DIR, check_rows, is_passish, load_json, now_iso, safe_rel, write_json


CURRENT_DIR = OUTPUT_DIR / "current"

FINAL_TRUTH = "m10_controlled_activation_readiness_dry_run_operator_gated"
ROADMAP_TRUTH = m9.ROADMAP_TRUTH
PREVIOUS_TRUTH = m9.FINAL_TRUTH

RECOVERABLE_FULL_CHECK_SELF_REFERENCE_STEPS = set(getattr(m9, "RECOVERABLE_FULL_CHECK_SELF_REFERENCE_STEPS", set())) | set(
    "m10_activation_preconditions m10_github_sync_safe_mode m10_remote_bridge_dry_run "
    "m10_telegram_operator_rail m10_activation_review_board m10_read_only_audit "
    "m10_regression_suite m10_final_verification".split()
)

SYSTEM_TRUTH_PATH = CURRENT_DIR / "system_truth.json"
OPERATOR_COCKPIT_PATH = CURRENT_DIR / "operator_cockpit.md"
OPERATOR_DECISION_QUEUE_PATH = CURRENT_DIR / "operator_decision_queue.json"
NEXT_DECISION_BOARD_PATH = CURRENT_DIR / "next_operator_decision_board.json"
CURRENT_SURFACE_MANIFEST_PATH = CURRENT_DIR / "current_surface_manifest.json"
CURRENT_TRUTH_AUDIT_PATH = CURRENT_DIR / "current_truth_audit.json"
DOMAIN_SUMMARY_PATH = CURRENT_DIR / "domain_summary.json"
VERIFICATION_SUMMARY_PATH = CURRENT_DIR / "verification_summary.json"
WRITE_CONTRACT_PATH = CURRENT_DIR / "write_contract.json"
GRAND_ROADMAP_PATH = CURRENT_DIR / "grand_roadmap_m3r_to_m12.json"
OPERATOR_BRIEF_PATH = OUTPUT_DIR / "operator_brief.json"
OPERATOR_BRIEF_MD_PATH = OUTPUT_DIR / "operator_brief.md"

M10_PRECONDITIONS_PATH = CURRENT_DIR / "m10_activation_preconditions.json"
M10_GITHUB_SYNC_PATH = CURRENT_DIR / "m10_github_sync_safe_mode.json"
M10_REMOTE_BRIDGE_PATH = CURRENT_DIR / "m10_remote_bridge_dry_run.json"
M10_TELEGRAM_RAIL_PATH = CURRENT_DIR / "m10_telegram_operator_rail.json"
M10_REVIEW_BOARD_PATH = CURRENT_DIR / "m10_activation_review_board.json"
M10_CURRENT_SURFACE_PATH = CURRENT_DIR / "m10_current_surface.json"
M10_READ_ONLY_AUDIT_PATH = CURRENT_DIR / "m10_read_only_audit.json"
M10_REGRESSION_SUITE_PATH = CURRENT_DIR / "m10_regression_suite.json"
M10_FINAL_VERIFICATION_PATH = CURRENT_DIR / "m10_final_verification.json"
M10_FINAL_STATE_PATH = CURRENT_DIR / "m10_final_state.json"
M10_REPLAY_INSTRUCTIONS_PATH = CURRENT_DIR / "m10_replay_instructions.md"

M10_BLOCK_PATHS = {
    "M10-01": CURRENT_DIR / "m10-01_activation_preconditions.json",
    "M10-02": CURRENT_DIR / "m10-02_github_sync_safe_mode.json",
    "M10-03": CURRENT_DIR / "m10-03_remote_bridge_dry_run.json",
    "M10-04": CURRENT_DIR / "m10-04_telegram_operator_rail.json",
    "M10-05": CURRENT_DIR / "m10-05_activation_review_board.json",
}

BUILDER_COMMANDS = [
    "grand-roadmap",
    "m10-activation-preconditions",
    "m10-github-sync-safe-mode",
    "m10-remote-bridge-dry-run",
    "m10-telegram-operator-rail",
    "m10-activation-review-board",
    "m10-current-surface",
    "m10-final-state",
]

AUDITOR_COMMANDS = ["m10-read-only-audit", "m10-regression-suite", "m10-final-verification"]

FORBIDDEN_FLAGS = [
    "runtime_action_executed",
    "external_action_executed",
    "publish_action_executed",
    "public_or_production_action_executed",
    "auth_or_payment_action_executed",
    "auth_or_credential_action_executed",
    "github_write_sync_executed",
    "remote_bridge_activation_executed",
    "telegram_send_executed",
    "delete_executed",
    "push_executed",
    "deploy_executed",
    "room16_rerun_executed",
    "irreversible_action_executed",
]


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def _sha(path: Path) -> str:
    if not path.exists() or not path.is_file():
        return ""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _gate_payload() -> dict[str, bool]:
    return {
        "runtime_action_executed": False,
        "external_action_executed": False,
        "publish_action_executed": False,
        "public_or_production_action_executed": False,
        "auth_or_payment_action_executed": False,
        "auth_or_credential_action_executed": False,
        "github_write_sync_executed": False,
        "remote_bridge_activation_executed": False,
        "telegram_send_executed": False,
        "delete_executed": False,
        "push_executed": False,
        "deploy_executed": False,
        "room16_rerun_executed": False,
        "irreversible_action_executed": False,
    }


def _write_json_md(path: Path, payload: dict[str, Any], title: str) -> None:
    write_json(path, payload)
    lines = [
        f"# {title}",
        "",
        f"- Status: `{payload.get('status', 'UNKNOWN')}`",
        f"- Final truth: `{payload.get('final_truth', FINAL_TRUTH)}`",
        "",
    ]
    for key in [
        "precondition_count",
        "channel_count",
        "operator_gate_required_count",
        "activation_ready_count",
        "decision_count",
        "unexpected_mutation_count",
        "fail_count",
    ]:
        if key in payload:
            lines.append(f"- {key}: `{payload[key]}`")
    if payload.get("checks"):
        lines += ["", "## Checks", ""]
        for check in payload["checks"]:
            lines.append(f"- `{check.get('status', 'UNKNOWN')}` {check.get('check', '')}: {check.get('detail', '')}")
    _write_text(path.with_suffix(".md"), "\n".join(lines))


def _mirror(path: Path, payload: dict[str, Any], block_id: str, title: str) -> None:
    mirror = M10_BLOCK_PATHS[block_id]
    write_json(mirror, payload)
    source_md = path.with_suffix(".md")
    _write_text(mirror.with_suffix(".md"), source_md.read_text(encoding="utf-8") if source_md.exists() else f"# {title}\n")


def _snapshot(paths: list[Path]) -> dict[str, dict[str, Any]]:
    rows: dict[str, dict[str, Any]] = {}
    for path in paths:
        if path.exists() and path.is_file():
            rows[safe_rel(path)] = {"mtime_ns": path.stat().st_mtime_ns, "bytes": path.stat().st_size, "sha256": _sha(path)}
    return rows


def _active_files() -> list[Path]:
    paths = [
        SYSTEM_TRUTH_PATH,
        OPERATOR_COCKPIT_PATH,
        OPERATOR_DECISION_QUEUE_PATH,
        NEXT_DECISION_BOARD_PATH,
        NEXT_DECISION_BOARD_PATH.with_suffix(".md"),
        CURRENT_SURFACE_MANIFEST_PATH,
        CURRENT_SURFACE_MANIFEST_PATH.with_suffix(".md"),
        CURRENT_TRUTH_AUDIT_PATH,
        CURRENT_TRUTH_AUDIT_PATH.with_suffix(".md"),
        DOMAIN_SUMMARY_PATH,
        DOMAIN_SUMMARY_PATH.with_suffix(".md"),
        VERIFICATION_SUMMARY_PATH,
        VERIFICATION_SUMMARY_PATH.with_suffix(".md"),
        WRITE_CONTRACT_PATH,
        WRITE_CONTRACT_PATH.with_suffix(".md"),
        GRAND_ROADMAP_PATH,
        GRAND_ROADMAP_PATH.with_suffix(".md"),
        OPERATOR_BRIEF_PATH,
        OPERATOR_BRIEF_MD_PATH,
        M10_PRECONDITIONS_PATH,
        M10_GITHUB_SYNC_PATH,
        M10_REMOTE_BRIDGE_PATH,
        M10_TELEGRAM_RAIL_PATH,
        M10_REVIEW_BOARD_PATH,
        M10_CURRENT_SURFACE_PATH,
        M10_READ_ONLY_AUDIT_PATH,
        M10_REGRESSION_SUITE_PATH,
        M10_FINAL_VERIFICATION_PATH,
        M10_FINAL_STATE_PATH,
        M10_REPLAY_INSTRUCTIONS_PATH,
        *M10_BLOCK_PATHS.values(),
    ]
    return sorted(set([*paths, *[path.with_suffix(".md") for path in paths if path.suffix == ".json"]]))


def _forbidden_action_count(payloads: list[dict[str, Any]]) -> int:
    return sum(1 for payload in payloads for flag in FORBIDDEN_FLAGS if payload.get(flag) is True)


def _channels() -> list[dict[str, Any]]:
    return [
        {
            "id": "github_sync_safe_mode",
            "title": "GitHub sync safe mode",
            "readiness": "operator_gated_dry_run",
            "operator_gate": "fresh scoped Commit/Push approval",
            "allowed_now": ["inventory", "candidate pack", "verifier list"],
            "blocked_now": ["commit", "push", "remote branch mutation", "PR creation"],
        },
        {
            "id": "remote_bridge_dry_run",
            "title": "Remote bridge dry-run",
            "readiness": "operator_gated_dry_run",
            "operator_gate": "runtime/bridge activation approval",
            "allowed_now": ["route contract", "health checklist", "rollback note"],
            "blocked_now": ["listener start", "tunnel open", "external endpoint exposure"],
        },
        {
            "id": "telegram_operator_rail",
            "title": "Telegram operator rail",
            "readiness": "operator_gated_dry_run",
            "operator_gate": "auth/token plus external-send approval",
            "allowed_now": ["message schema", "redaction rule", "send checklist"],
            "blocked_now": ["token access", "bot configuration", "message send"],
        },
    ]


def build_activation_preconditions(*, write: bool = True) -> dict[str, Any]:
    channels = _channels()
    preconditions = [
        {"id": "contract_valid", "state": "met", "evidence": "M10 hardening contract exists and validates locally"},
        {"id": "verifiers_green_before_activation", "state": "required", "evidence": "full-check, quality-gate and german-output-quality must pass"},
        {"id": "operator_go_scoped", "state": "closed", "evidence": "no fresh scoped activation approval present"},
        {"id": "rollback_written", "state": "required", "evidence": "each activation channel must include rollback/disable note"},
        {"id": "no_external_side_effects", "state": "met", "evidence": "M10 is dry-run only"},
    ]
    activation_ready_count = sum(1 for item in preconditions if item["id"] == "operator_go_scoped" and item["state"] == "open")
    checks = [
        {"check": "precondition_count", "status": "PASS" if len(preconditions) == 5 else "FAIL", "detail": str(len(preconditions))},
        {"check": "channel_count", "status": "PASS" if len(channels) == 3 else "FAIL", "detail": str(len(channels))},
        {"check": "activation_ready_count", "status": "PASS" if activation_ready_count == 0 else "FAIL", "detail": str(activation_ready_count)},
        {"check": "all_channels_operator_gated", "status": "PASS" if all("operator_gate" in channel for channel in channels) else "FAIL", "detail": "required"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "M10-01",
        "final_truth": FINAL_TRUTH,
        "precondition_count": len(preconditions),
        "channel_count": len(channels),
        "operator_gate_required_count": len(channels),
        "activation_ready_count": activation_ready_count,
        "channels": channels,
        "preconditions": preconditions,
        "checks": checks,
        "fail_count": fail_count,
        **_gate_payload(),
    }
    if write:
        _write_json_md(M10_PRECONDITIONS_PATH, payload, "M10 Activation Preconditions")
        _mirror(M10_PRECONDITIONS_PATH, payload, "M10-01", "M10 Activation Preconditions")
    return payload


def build_github_sync_safe_mode(*, write: bool = True) -> dict[str, Any]:
    m5_pack = load_json(CURRENT_DIR / "m5_safe_commit_candidate_pack.json", default={})
    candidates = m5_pack.get("source_commit_candidates", []) or m5_pack.get("candidates", [])
    safe_mode = {
        "mode": "dry_run_manifest_only",
        "candidate_count_from_m5": len(candidates),
        "required_before_write": [
            "fresh scoped operator approval",
            "full-check PASS",
            "quality-gate PASS",
            "human-readable diff summary",
            "rollback command or restore note",
        ],
        "blocked_actions": ["git commit", "git push", "gh pr create", "remote mutation"],
    }
    checks = [
        {"check": "safe_mode_declared", "status": "PASS", "detail": safe_mode["mode"]},
        {"check": "github_write_sync_not_executed", "status": "PASS", "detail": "false"},
        {"check": "push_not_executed", "status": "PASS", "detail": "false"},
        {"check": "approval_required", "status": "PASS" if "fresh scoped operator approval" in safe_mode["required_before_write"] else "FAIL", "detail": "fresh scoped"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "M10-02",
        "final_truth": FINAL_TRUTH,
        "channel": "github_sync_safe_mode",
        "operator_gate_required_count": 1,
        "activation_ready_count": 0,
        "safe_mode": safe_mode,
        "checks": checks,
        "fail_count": fail_count,
        **_gate_payload(),
    }
    if write:
        _write_json_md(M10_GITHUB_SYNC_PATH, payload, "M10 GitHub Sync Safe Mode")
        _mirror(M10_GITHUB_SYNC_PATH, payload, "M10-02", "M10 GitHub Sync Safe Mode")
    return payload


def build_remote_bridge_dry_run(*, write: bool = True) -> dict[str, Any]:
    dry_run = {
        "mode": "route_contract_only",
        "route_classes": ["local health check", "read-only operator surface", "rollback/disable path"],
        "required_before_activation": ["operator approval", "auth review if credentials are touched", "current health probe", "disable procedure"],
        "blocked_actions": ["start bridge", "open tunnel", "change listener", "expose public endpoint"],
    }
    checks = [
        {"check": "dry_run_mode", "status": "PASS", "detail": dry_run["mode"]},
        {"check": "remote_bridge_activation_not_executed", "status": "PASS", "detail": "false"},
        {"check": "runtime_action_not_executed", "status": "PASS", "detail": "false"},
        {"check": "disable_procedure_required", "status": "PASS" if "disable procedure" in dry_run["required_before_activation"] else "FAIL", "detail": "required"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "M10-03",
        "final_truth": FINAL_TRUTH,
        "channel": "remote_bridge_dry_run",
        "operator_gate_required_count": 1,
        "activation_ready_count": 0,
        "dry_run": dry_run,
        "checks": checks,
        "fail_count": fail_count,
        **_gate_payload(),
    }
    if write:
        _write_json_md(M10_REMOTE_BRIDGE_PATH, payload, "M10 Remote Bridge Dry-run")
        _mirror(M10_REMOTE_BRIDGE_PATH, payload, "M10-03", "M10 Remote Bridge Dry-run")
    return payload


def build_telegram_operator_rail(*, write: bool = True) -> dict[str, Any]:
    rail = {
        "mode": "message_contract_only",
        "message_schema": ["title", "severity", "current_truth", "decision_required", "blocked_gates", "safe_commands"],
        "redaction_rules": ["no secrets", "no local absolute paths in outbound messages", "no real client/person data"],
        "required_before_send": ["operator approval", "credential/auth approval", "external communication approval", "test recipient confirmation"],
        "blocked_actions": ["read token", "configure bot", "send message", "external webhook"],
    }
    checks = [
        {"check": "message_contract_present", "status": "PASS" if len(rail["message_schema"]) >= 6 else "FAIL", "detail": str(len(rail["message_schema"]))},
        {"check": "telegram_send_not_executed", "status": "PASS", "detail": "false"},
        {"check": "auth_credentials_not_touched", "status": "PASS", "detail": "false"},
        {"check": "external_communication_not_executed", "status": "PASS", "detail": "false"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "M10-04",
        "final_truth": FINAL_TRUTH,
        "channel": "telegram_operator_rail",
        "operator_gate_required_count": 1,
        "activation_ready_count": 0,
        "rail": rail,
        "checks": checks,
        "fail_count": fail_count,
        **_gate_payload(),
    }
    if write:
        _write_json_md(M10_TELEGRAM_RAIL_PATH, payload, "M10 Telegram Operator Rail")
        _mirror(M10_TELEGRAM_RAIL_PATH, payload, "M10-04", "M10 Telegram Operator Rail")
    return payload


def build_activation_review_board(*, write: bool = True) -> dict[str, Any]:
    preconditions = build_activation_preconditions(write=False)
    github = build_github_sync_safe_mode(write=False)
    bridge = build_remote_bridge_dry_run(write=False)
    telegram = build_telegram_operator_rail(write=False)
    decisions = [
        {"id": "m10-review-github-sync", "risk": "R3_REMOTE_WRITE", "state": "operator_gated", "next_step": "review safe-mode pack; no commit/push"},
        {"id": "m10-review-remote-bridge", "risk": "R4_RUNTIME", "state": "operator_gated", "next_step": "review dry-run contract; no bridge start"},
        {"id": "m10-review-telegram-rail", "risk": "R4_EXTERNAL_SEND_AUTH", "state": "operator_gated", "next_step": "review message schema; no token or send"},
        {"id": "m10-review-activation-preconditions", "risk": "R3_ACTIVATION", "state": "operator_gated", "next_step": "only after M10 verifier pass"},
        {"id": "m10-continue-m11-audit-readiness", "risk": "R2_LOCAL_AUDIT", "state": "safe_next_local_block", "next_step": "build external audit readiness locally"},
    ]
    payloads = [preconditions, github, bridge, telegram]
    activation_ready_count = sum(item.get("activation_ready_count", 0) for item in payloads)
    gate_count = sum(item.get("operator_gate_required_count", 0) for item in payloads) + 1
    checks = [
        {"check": "decision_count", "status": "PASS" if len(decisions) == 5 else "FAIL", "detail": str(len(decisions))},
        {"check": "activation_ready_count", "status": "PASS" if activation_ready_count == 0 else "FAIL", "detail": str(activation_ready_count)},
        {"check": "operator_gate_required_count", "status": "PASS" if gate_count >= 4 else "FAIL", "detail": str(gate_count)},
        {"check": "forbidden_action_count", "status": "PASS" if _forbidden_action_count(payloads) == 0 else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "M10-05",
        "final_truth": FINAL_TRUTH,
        "decision_count": len(decisions),
        "channel_count": 3,
        "operator_gate_required_count": gate_count,
        "activation_ready_count": activation_ready_count,
        "decisions": decisions,
        "checks": checks,
        "fail_count": fail_count,
        **_gate_payload(),
    }
    if write:
        _write_json_md(M10_REVIEW_BOARD_PATH, payload, "M10 Activation Review Board")
        _mirror(M10_REVIEW_BOARD_PATH, payload, "M10-05", "M10 Activation Review Board")
    return payload


def build_write_contract(*, write: bool = True) -> dict[str, Any]:
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS",
        "block_id": "M10-WRITE-CONTRACT",
        "final_truth": FINAL_TRUTH,
        "single_writer": "m10_activation.py",
        "allowed_outputs": [safe_rel(path) for path in _active_files()],
        "auditor_commands": AUDITOR_COMMANDS,
        "builder_commands": BUILDER_COMMANDS,
        "forbidden_actions": FORBIDDEN_FLAGS,
        "fail_count": 0,
        **_gate_payload(),
    }
    if write:
        _write_json_md(WRITE_CONTRACT_PATH, payload, "M10 Write Contract")
    return payload


def build_domain_summary(*, write: bool = True) -> dict[str, Any]:
    preconditions = build_activation_preconditions(write=False)
    github = build_github_sync_safe_mode(write=False)
    bridge = build_remote_bridge_dry_run(write=False)
    telegram = build_telegram_operator_rail(write=False)
    board = build_activation_review_board(write=False)
    domains = [
        {"domain": "activation_preconditions", "status": preconditions.get("status", "UNKNOWN"), "summary": f"{preconditions.get('precondition_count', 0)} preconditions"},
        {"domain": "github_sync_safe_mode", "status": github.get("status", "UNKNOWN"), "summary": "write sync gated"},
        {"domain": "remote_bridge_dry_run", "status": bridge.get("status", "UNKNOWN"), "summary": "bridge activation gated"},
        {"domain": "telegram_operator_rail", "status": telegram.get("status", "UNKNOWN"), "summary": "external send and auth gated"},
        {"domain": "activation_review_board", "status": board.get("status", "UNKNOWN"), "summary": f"{board.get('decision_count', 0)} decisions"},
    ]
    fail_count = sum(1 for item in domains if item["status"] == "FAIL")
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "FAIL" if fail_count else "PASS_WITH_WARNINGS",
        "block_id": "M10-DOMAIN-SUMMARY",
        "final_truth": FINAL_TRUTH,
        "current_owner": "M10",
        "domains": domains,
        "fail_count": fail_count,
        "warning_reason": "M10 proves activation readiness only; channels remain operator-gated and inactive.",
        **_gate_payload(),
    }
    if write:
        _write_json_md(DOMAIN_SUMMARY_PATH, payload, "M10 Domain Summary")
    return payload


def build_current_surface(*, write: bool = True) -> dict[str, Any]:
    domain = build_domain_summary(write=False)
    board = build_activation_review_board(write=False)
    decisions = board.get("decisions", [])
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS" if domain.get("fail_count", 0) == 0 else "FAIL",
        "block_id": "M10-CURRENT-SURFACE",
        "final_truth": FINAL_TRUTH,
        "current_owner": "M10",
        "decision_count": len(decisions),
        "decisions": decisions,
        "fail_count": domain.get("fail_count", 0),
        **_gate_payload(),
    }
    if write:
        _write_json_md(M10_CURRENT_SURFACE_PATH, payload, "M10 Current Surface")
        write_json(OPERATOR_DECISION_QUEUE_PATH, {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "current_owner": "M10", "decisions": decisions, **_gate_payload()})
        write_json(NEXT_DECISION_BOARD_PATH, {"schema_version": 1, "generated_at": now_iso(), "status": "PASS", "decisions": decisions, **_gate_payload()})
        board_lines = ["# M10 Decision Board", "", "- Status: `PASS`", "- Activation readiness is prepared, but no activation channel is open.", "", "| ID | Risk | State | Next Step |", "|---|---|---|---|"]
        for item in decisions:
            board_lines.append(f"| `{item['id']}` | `{item['risk']}` | `{item['state']}` | {item['next_step']} |")
        _write_text(NEXT_DECISION_BOARD_PATH.with_suffix(".md"), "\n".join(board_lines))
        cockpit = [
            "# M10 Operator Cockpit",
            "",
            f"- Truth: `{FINAL_TRUTH}`",
            "- Zustand: Controlled Activation Readiness ist als Dry-Run-Surface materialisiert.",
            "- GitHub-Sync, Remote-Bridge und Telegram-Rail sind vorbereitet, aber nicht aktiviert.",
            "",
            "## Aktivierungsflächen",
        ]
        for item in decisions[:4]:
            cockpit.append(f"- `{item['id']}`: {item['state']} - {item['next_step']}.")
        cockpit += [
            "",
            "## Nächste sichere Aktion",
            "",
            "- M10-Verifikation lesen; danach M11 DreamFactory One App Experience lokal bauen.",
            "",
            "## Geschlossene Gates",
            "",
            "- Commit/Push, Bridge-/Runtime-Aktivierung, Telegram-Send, Auth/Credentials, Publish/Public/Production/Payment/Deploy und irreversible Aktionen bleiben geschlossen.",
        ]
        _write_text(OPERATOR_COCKPIT_PATH, "\n".join(cockpit))
    return payload


def build_grand_roadmap(*, write: bool = True) -> dict[str, Any]:
    roadmap = load_json(GRAND_ROADMAP_PATH, default={})
    if not roadmap:
        roadmap = m9.build_grand_roadmap(write=False)
    roadmap.update(
        {
            "schema_version": max(int(roadmap.get("schema_version", 7)), 8),
            "generated_at": now_iso(),
            "status": "PASS",
            "truth_state": ROADMAP_TRUTH,
            "active_current_truth": FINAL_TRUTH,
            "active_phase": "M10",
            "m10_status": "PASS_WITH_WARNINGS",
            "m11_next": "one_app_experience_local_reversible",
            "runtime_action_executed": False,
            "external_action_executed": False,
        }
    )
    lines = [
        "# Grand Roadmap M3R to M12",
        "",
        "- Status: `PASS`",
        f"- Active current truth: `{FINAL_TRUTH}`",
        "- M10 materialisiert Controlled Activation Readiness; M11 DreamFactory One App Experience ist der nächste lokale Block.",
        "",
        "| Phase | Title | Blocks |",
        "|---|---|---:|",
    ]
    for phase in roadmap.get("phases", []):
        lines.append(f"| `{phase.get('id')}` | {phase.get('title')} | {len(phase.get('blocks', []))} |")
    if write:
        write_json(GRAND_ROADMAP_PATH, roadmap)
        _write_text(GRAND_ROADMAP_PATH.with_suffix(".md"), "\n".join(lines))
    return roadmap


def build_current_manifest(*, write: bool = True) -> dict[str, Any]:
    files = [{"path": safe_rel(path), "exists": path.exists(), "sha256": _sha(path), "bytes": path.stat().st_size if path.exists() else 0} for path in _active_files()]
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS",
        "block_id": "M10-CURRENT-MANIFEST",
        "final_truth": FINAL_TRUTH,
        "current_owner": "M10",
        "file_count": len(files),
        "files": files,
        "fail_count": 0,
        **_gate_payload(),
    }
    if write:
        _write_json_md(CURRENT_SURFACE_MANIFEST_PATH, payload, "M10 Current Surface Manifest")
        write_json(CURRENT_TRUTH_AUDIT_PATH, payload)
        _write_text(CURRENT_TRUTH_AUDIT_PATH.with_suffix(".md"), "# M10 Current Truth Audit\n\n- Status: `PASS`\n- Current owner: `M10`\n")
    return payload


def build_read_only_audit(*, write: bool = True) -> dict[str, Any]:
    before = _snapshot(_active_files())
    build_regression_suite(write=False)
    build_domain_summary(write=False)
    build_current_surface(write=False)
    after = _snapshot(_active_files())
    changed = sorted(path for path, meta in before.items() if after.get(path) != meta)
    checks = [
        {"check": "unexpected_mutation_count", "status": "PASS" if not changed else "FAIL", "detail": str(len(changed))},
        {"check": "auditors_write_false", "status": "PASS", "detail": "regression/domain/current surface read only"},
    ]
    status, fail_count = check_rows(checks)
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": status,
        "block_id": "M10-READ-ONLY-AUDIT",
        "final_truth": FINAL_TRUTH,
        "unexpected_mutation_count": len(changed),
        "changed_files": changed,
        "checks": checks,
        "fail_count": fail_count,
        **_gate_payload(),
    }
    if write:
        _write_json_md(M10_READ_ONLY_AUDIT_PATH, payload, "M10 Read-only Audit")
    return payload


def build_regression_suite(*, write: bool = True) -> dict[str, Any]:
    preconditions = build_activation_preconditions(write=False)
    github = build_github_sync_safe_mode(write=False)
    bridge = build_remote_bridge_dry_run(write=False)
    telegram = build_telegram_operator_rail(write=False)
    board = build_activation_review_board(write=False)
    payloads = [preconditions, github, bridge, telegram, board]
    checks = [
        {"check": "activation_preconditions_pass", "status": preconditions.get("status", "FAIL"), "detail": str(preconditions.get("fail_count", 0))},
        {"check": "github_sync_safe_mode_pass", "status": github.get("status", "FAIL"), "detail": str(github.get("fail_count", 0))},
        {"check": "remote_bridge_dry_run_pass", "status": bridge.get("status", "FAIL"), "detail": str(bridge.get("fail_count", 0))},
        {"check": "telegram_operator_rail_pass", "status": telegram.get("status", "FAIL"), "detail": str(telegram.get("fail_count", 0))},
        {"check": "activation_review_board_pass", "status": board.get("status", "FAIL"), "detail": str(board.get("fail_count", 0))},
        {"check": "forbidden_action_count", "status": "PASS" if _forbidden_action_count(payloads) == 0 else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "block_id": "M10-REGRESSION-SUITE", "final_truth": FINAL_TRUTH, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M10_REGRESSION_SUITE_PATH, payload, "M10 Regression Suite")
    return payload


def build_final_verification(*, write: bool = True) -> dict[str, Any]:
    preconditions = build_activation_preconditions(write=False)
    github = build_github_sync_safe_mode(write=False)
    bridge = build_remote_bridge_dry_run(write=False)
    telegram = build_telegram_operator_rail(write=False)
    board = build_activation_review_board(write=False)
    contract = build_write_contract(write=False)
    domain = build_domain_summary(write=False)
    surface = build_current_surface(write=False)
    read_only = build_read_only_audit(write=False)
    regression = build_regression_suite(write=False)
    payloads = [preconditions, github, bridge, telegram, board, contract, domain, surface, read_only, regression]
    checks = [
        {"check": "final_truth_consistency", "status": "PASS", "detail": FINAL_TRUTH},
        {"check": "activation_preconditions", "status": preconditions.get("status", "FAIL"), "detail": str(preconditions.get("fail_count", 0))},
        {"check": "github_sync_safe_mode", "status": github.get("status", "FAIL"), "detail": str(github.get("fail_count", 0))},
        {"check": "remote_bridge_dry_run", "status": bridge.get("status", "FAIL"), "detail": str(bridge.get("fail_count", 0))},
        {"check": "telegram_operator_rail", "status": telegram.get("status", "FAIL"), "detail": str(telegram.get("fail_count", 0))},
        {"check": "activation_review_board", "status": board.get("status", "FAIL"), "detail": str(board.get("fail_count", 0))},
        {"check": "write_contract", "status": contract.get("status", "FAIL"), "detail": str(contract.get("fail_count", 0))},
        {"check": "domain_summary", "status": "PASS" if domain.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "FAIL", "detail": domain.get("status", "")},
        {"check": "current_surface", "status": surface.get("status", "FAIL"), "detail": str(surface.get("fail_count", 0))},
        {"check": "read_only_audit", "status": read_only.get("status", "FAIL"), "detail": str(read_only.get("unexpected_mutation_count", 0))},
        {"check": "regression_suite", "status": regression.get("status", "FAIL"), "detail": str(regression.get("fail_count", 0))},
        {"check": "forbidden_action_count", "status": "PASS" if _forbidden_action_count(payloads) == 0 else "FAIL", "detail": "0"},
    ]
    status, fail_count = check_rows(checks)
    payload = {"schema_version": 1, "generated_at": now_iso(), "status": status, "final_truth": FINAL_TRUTH, "checks": checks, "fail_count": fail_count, **_gate_payload()}
    if write:
        _write_json_md(M10_FINAL_VERIFICATION_PATH, payload, "M10 Final Verification")
        _write_json_md(VERIFICATION_SUMMARY_PATH, payload, "M10 Verification Summary")
    return payload


def build_final_state(*, write: bool = True) -> dict[str, Any]:
    if not write:
        return load_json(M10_FINAL_STATE_PATH, default={})
    build_grand_roadmap(write=True)
    preconditions = build_activation_preconditions(write=True)
    github = build_github_sync_safe_mode(write=True)
    bridge = build_remote_bridge_dry_run(write=True)
    telegram = build_telegram_operator_rail(write=True)
    board = build_activation_review_board(write=True)
    build_write_contract(write=True)
    build_domain_summary(write=True)
    build_current_surface(write=True)
    build_current_manifest(write=True)
    build_read_only_audit(write=True)
    build_regression_suite(write=True)
    verification = build_final_verification(write=True)
    _write_text(
        M10_REPLAY_INSTRUCTIONS_PATH,
        "# M10 Replay Instructions\n\n```bash\npython3 scripts/project_intelligence_graph/pig.py m10-final-state --json\npython3 scripts/project_intelligence_graph/pig.py m10-read-only-audit --json\npython3 scripts/project_intelligence_graph/pig.py m10-regression-suite --json\npython3 scripts/project_intelligence_graph/pig.py full-check --json\n```\n\nM10 ist ein lokaler Dry-Run-Kernel. Aktivierung, Send, Auth, Push und Runtime-Mutation bleiben geschlossen.",
    )
    payload = {
        "schema_version": 1,
        "generated_at": now_iso(),
        "status": "PASS_WITH_WARNINGS" if verification.get("status") == "PASS" else "FAIL",
        "final_truth": FINAL_TRUTH,
        "roadmap_truth": ROADMAP_TRUTH,
        "current_owner": "M10",
        "previous_truth": PREVIOUS_TRUTH,
        "m10_blocks_completed": 5,
        "m11_next": "one_app_experience_local_reversible",
        "activation_preconditions": safe_rel(M10_PRECONDITIONS_PATH),
        "github_sync_safe_mode": safe_rel(M10_GITHUB_SYNC_PATH),
        "remote_bridge_dry_run": safe_rel(M10_REMOTE_BRIDGE_PATH),
        "telegram_operator_rail": safe_rel(M10_TELEGRAM_RAIL_PATH),
        "activation_review_board": safe_rel(M10_REVIEW_BOARD_PATH),
        "precondition_count": preconditions.get("precondition_count", 0),
        "channel_count": preconditions.get("channel_count", 0),
        "operator_gate_required_count": board.get("operator_gate_required_count", 0),
        "activation_ready_count": board.get("activation_ready_count", 0),
        "decision_count": board.get("decision_count", 0),
        "checks": verification.get("checks", []),
        "fail_count": verification.get("fail_count", 1),
        **_gate_payload(),
    }
    write_json(SYSTEM_TRUTH_PATH, payload)
    _write_json_md(M10_FINAL_STATE_PATH, payload, "M10 Final State")
    build_current_manifest(write=True)
    build_operator_brief(write=True)
    return payload


def _operator_brief_md(payload: dict[str, Any]) -> str:
    lines = [
        "# Project Intelligence Graph Operator Brief",
        "",
        f"- Generated: `{payload.get('generated_at', '')}`",
        f"- Overall: `{payload.get('overall_status', 'UNKNOWN')}`",
        f"- Build: `{payload.get('build_status', 'UNKNOWN')}`",
        f"- Decisions: `{payload.get('decision_status', 'UNKNOWN')}`",
        "",
        "## Do This Now",
        "",
    ]
    for item in payload.get("do_this_now", []):
        lines.append(f"- `{item.get('priority', '-')}` {item.get('text', '')}")
    lines.extend(["", "## Do Not", ""])
    for item in payload.get("do_not", []):
        lines.append(f"- {item}")
    lines.extend(["", "## Safe Commands", ""])
    for command in payload.get("safe_commands", []):
        lines.append(f"- `{command}`")
    lines.extend(["", "## Status Lines", ""])
    for key, value in payload.get("status_lines", {}).items():
        lines.append(f"- `{key}`: `{value}`")
    return "\n".join(lines) + "\n"


def build_operator_brief(*, write: bool = True) -> dict[str, Any]:
    final_state = load_json(M10_FINAL_STATE_PATH, default={})
    verification = load_json(M10_FINAL_VERIFICATION_PATH, default={})
    payload = {
        "schema_version": 8,
        "generated_at": now_iso(),
        "overall_status": "ACTION_REQUIRED",
        "build_status": "PASS" if verification.get("status") == "PASS" and final_state.get("status") in {"PASS", "PASS_WITH_WARNINGS"} else "WARN",
        "decision_status": "OPERATOR_GATED",
        "current_owner": "M10",
        "final_truth": FINAL_TRUTH,
        "do_this_now": [
            {"priority": "P1", "text": "Treat M10 as dry-run readiness only; no activation channel is open."},
            {"priority": "P1", "text": "Review GitHub sync, remote bridge and Telegram rails only as operator-gated candidates."},
            {"priority": "P2", "text": "Continue with M11 DreamFactory One App Experience after M10 verifiers and long-run handoff pass."},
        ],
        "do_not": [
            "Do not commit, push, open a PR or mutate a remote from M10.",
            "Do not start a bridge, listener, tunnel or runtime channel from M10.",
            "Do not read credentials, configure Telegram or send external messages from M10.",
            "Do not open Public, Production, Payment, Auth, Room16 rerun, real-data or irreversible gates.",
        ],
        "safe_commands": [
            "python3 scripts/project_intelligence_graph/pig.py m10-final-state --json",
            "python3 scripts/project_intelligence_graph/pig.py m10-final-verification --json",
            "python3 scripts/project_intelligence_graph/pig.py m10-read-only-audit --json",
            "python3 scripts/project_intelligence_graph/pig.py m10-regression-suite --json",
            "python3 scripts/project_intelligence_graph/pig.py full-check --json",
            "python3 scripts/project_intelligence_graph/pig.py german-output-quality --json",
        ],
        "status_lines": {
            "m10_current_owner": final_state.get("current_owner", "M10"),
            "m10_final_truth": final_state.get("final_truth", FINAL_TRUTH),
            "m10_final_state_status": final_state.get("status", "UNKNOWN"),
            "m10_blocks_completed": final_state.get("m10_blocks_completed", 0),
            "m10_channel_count": final_state.get("channel_count", 0),
            "m10_activation_ready_count": final_state.get("activation_ready_count", 0),
            "m11_next": final_state.get("m11_next", "one_app_experience_local_reversible"),
            "hard_gates": "closed",
            **_gate_payload(),
        },
    }
    if write:
        write_json(OPERATOR_BRIEF_PATH, payload)
        _write_text(OPERATOR_BRIEF_MD_PATH, _operator_brief_md(payload))
    return payload


M10_BUILDERS: dict[str, Callable[..., dict[str, Any]]] = {
    "grand-roadmap": build_grand_roadmap,
    "m10-activation-preconditions": build_activation_preconditions,
    "m10-github-sync-safe-mode": build_github_sync_safe_mode,
    "m10-remote-bridge-dry-run": build_remote_bridge_dry_run,
    "m10-telegram-operator-rail": build_telegram_operator_rail,
    "m10-activation-review-board": build_activation_review_board,
    "m10-write-contract": build_write_contract,
    "m10-domain-summary": build_domain_summary,
    "m10-current-surface": build_current_surface,
    "m10-current-manifest": build_current_manifest,
    "m10-read-only-audit": build_read_only_audit,
    "m10-regression-suite": build_regression_suite,
    "m10-final-verification": build_final_verification,
    "m10-final-state": build_final_state,
}

M1_CURRENT_COMMANDS = tuple(dict.fromkeys([*m9.M1_CURRENT_COMMANDS, *M10_BUILDERS.keys()]))


def run_m1_current_command(command: str, write: bool = True, profile: str | None = None) -> dict[str, Any]:
    if command in M10_BUILDERS:
        effective_write = False if command in AUDITOR_COMMANDS else write
        return M10_BUILDERS[command](write=effective_write)
    return m9.run_m1_current_command(command, write=write, profile=profile)


def m1_full_check_steps() -> list[dict[str, Any]]:
    steps = m9.m1_full_check_steps()
    for command in [
        "m10-activation-preconditions",
        "m10-github-sync-safe-mode",
        "m10-remote-bridge-dry-run",
        "m10-telegram-operator-rail",
        "m10-activation-review-board",
        "m10-read-only-audit",
        "m10-regression-suite",
        "m10-final-verification",
        "m10-final-state",
    ]:
        payload = run_m1_current_command(command, write=False)
        ok = is_passish(payload.get("status", "UNKNOWN"))
        steps.append(
            {
                "name": command.replace("-", "_"),
                "status": "PASS" if ok else "FAIL",
                "returncode": 0 if ok else 1,
                "fail_count": payload.get("fail_count", 0),
                "runtime_action_executed": payload.get("runtime_action_executed", False),
                "external_action_executed": payload.get("external_action_executed", False),
            }
        )
    return steps


def m1_report_payload() -> dict[str, Any]:
    payload = m9.m1_report_payload()
    payload.update(
        {
            "m10_activation_preconditions": load_json(M10_PRECONDITIONS_PATH, default={}),
            "m10_github_sync_safe_mode": load_json(M10_GITHUB_SYNC_PATH, default={}),
            "m10_remote_bridge_dry_run": load_json(M10_REMOTE_BRIDGE_PATH, default={}),
            "m10_telegram_operator_rail": load_json(M10_TELEGRAM_RAIL_PATH, default={}),
            "m10_activation_review_board": load_json(M10_REVIEW_BOARD_PATH, default={}),
            "m10_final_verification": load_json(M10_FINAL_VERIFICATION_PATH, default={}),
            "m10_final_state": load_json(M10_FINAL_STATE_PATH, default={}),
        }
    )
    return payload


def m1_compact_domain_lines(report: dict[str, Any]) -> list[str]:
    final_state = report.get("m10_final_state") or load_json(M10_FINAL_STATE_PATH, default={})
    return [
        "## Current Kernel Summary",
        "",
        f"- M10 final: `{final_state.get('status', 'UNKNOWN')}` `{final_state.get('final_truth', FINAL_TRUTH)}`",
        "- Current owner: `M10`; M9 ist Vorgängerschicht, ältere Surfaces sind Provenance.",
        f"- Channels: `{final_state.get('channel_count', 0)}`; activation ready: `{final_state.get('activation_ready_count', 0)}`; hard gates: `closed`.",
        "- Operator cockpit: `outputs/project_intelligence_graph/current/operator_cockpit.md`.",
        "",
    ]


def append_m1_full_check_lines(lines: list[str], report: dict[str, Any]) -> None:
    final_state = report.get("m10_final_state", {})
    board = report.get("m10_activation_review_board", {})
    lines.extend(["", "## M10 Controlled Activation Readiness", ""])
    lines.append(f"- Final state: `{final_state.get('status', 'UNKNOWN')}` ({final_state.get('final_truth', FINAL_TRUTH)})")
    lines.append(f"- Channels: `{final_state.get('channel_count', 0)}`; activation-ready: `{final_state.get('activation_ready_count', 0)}`; decisions: `{board.get('decision_count', 0)}`.")
    lines.append("- GitHub write sync, remote bridge activation, Telegram send, auth, push, deploy and runtime actions: `false`.")
