"""JSON report rendering helpers."""

from __future__ import annotations

import json
from typing import Any


def render_json_report(payload: dict[str, Any]) -> str:
    return json.dumps(payload, indent=2, ensure_ascii=False) + "\n"
