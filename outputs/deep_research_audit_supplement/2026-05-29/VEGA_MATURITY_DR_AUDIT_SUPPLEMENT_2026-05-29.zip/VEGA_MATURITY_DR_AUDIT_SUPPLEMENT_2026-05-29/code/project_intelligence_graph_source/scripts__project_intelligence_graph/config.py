"""Environment-backed path configuration for portable PIG tooling."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping


class ConfigError(RuntimeError):
    pass


@dataclass(frozen=True)
class AppPaths:
    workspace: Path
    outputs: Path
    vault: Path | None
    lioncom: Path | None
    downloads: Path | None


def _optional_path(name: str, env: Mapping[str, str]) -> Path | None:
    value = env.get(name)
    if not value:
        return None
    return Path(value).expanduser().resolve()


def resolve_paths(env: Mapping[str, str] | None = None) -> AppPaths:
    source = os.environ if env is None else env
    raw_workspace = source.get("DF_WORKSPACE")
    if not raw_workspace:
        raise ConfigError("DF_WORKSPACE is required")
    workspace = Path(raw_workspace).expanduser().resolve()
    if workspace == Path(workspace.anchor):
        raise ConfigError("DF_WORKSPACE must not resolve to filesystem root")
    if not workspace.exists():
        raise ConfigError(f"DF_WORKSPACE does not exist: {workspace}")
    outputs = _optional_path("DF_OUTPUTS", source) or workspace / "outputs" / "project_intelligence_graph"
    return AppPaths(
        workspace=workspace,
        outputs=outputs,
        vault=_optional_path("DF_VAULT", source),
        lioncom=_optional_path("DF_LIONCOM", source),
        downloads=_optional_path("DF_DOWNLOADS", source),
    )


def resolve_runtime_paths(anchor_file: Path | str, env: Mapping[str, str] | None = None) -> AppPaths:
    """Resolve paths for repository-local CLIs without requiring shell env setup."""

    source = dict(os.environ if env is None else env)
    if not source.get("DF_WORKSPACE"):
        source["DF_WORKSPACE"] = str(Path(anchor_file).resolve().parents[2])
    return resolve_paths(source)
