"""Independent replay smoke checks for unpacked PIG review packs."""

from __future__ import annotations

import argparse
import ast
import hashlib
import importlib
import json
import py_compile
import subprocess
import sys
from pathlib import Path
from typing import Any


HELPERS = [
    "archive_reference_helpers.py",
    "dirt_status_helpers.py",
    "evidence_budget_helpers.py",
    "report_markdown.py",
]

RUNNABLE_ROOT_ARTIFACTS = [
    "pack_replay_stubs.json",
    "pack_replay_stubs",
    "status_semantics.yml",
    "tests/project_intelligence_graph",
    "tests/fixtures",
    "tests/fixtures/invalid_json/broken.json",
    "tests/fixtures/missing_inputs/minimal_valid/helper-size.json",
    "tests/fixtures/missing_inputs/minimal_valid/current-surface-manifest.json",
    "tests/fixtures/missing_inputs/minimal_valid/full-check.json",
]

EXPECTED_FIRST_PARTY_MODULES = [
    "m8_knowledge",
    "m12_release_candidate",
    "maturity_kernel_v4_helpers",
    "maturity_kernel_v5_ops",
    "report_markdown",
    "archive_reference_helpers",
    "scan_project_intelligence_graph",
    "pack_replay_mode",
]

ENTRYPOINTS = [
    "scripts/project_intelligence_graph/pig.py",
    "scripts/project_intelligence_graph/m9_efficiency.py",
]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _check(name: str, ok: bool, detail: str) -> dict[str, str]:
    return {"check": name, "status": "PASS" if ok else "FAIL", "detail": detail}


def _required_input_check(name: str, ok: bool, detail: str) -> dict[str, str]:
    return {"check": name, "status": "PASS" if ok else "ACTION_REQUIRED", "detail": detail}


def _tail(text: str, limit: int = 2000) -> str:
    return text[-limit:] if len(text) > limit else text


def _run_check(name: str, command: list[str], *, cwd: Path) -> dict[str, str]:
    completed = subprocess.run(command, cwd=cwd, capture_output=True, text=True)
    detail = {
        "returncode": completed.returncode,
        "stdout_tail": _tail(completed.stdout),
        "stderr_tail": _tail(completed.stderr),
    }
    return {
        "check": name,
        "status": "PASS" if completed.returncode == 0 else "FAIL",
        "detail": json.dumps(detail, ensure_ascii=False, sort_keys=True),
    }


def _module_path(script_dir: Path, module_name: str) -> Path:
    return script_dir.joinpath(*module_name.split(".")).with_suffix(".py")


def _module_exists(script_dir: Path, module_name: str) -> bool:
    if _module_path(script_dir, module_name).exists():
        return True
    package_dir = script_dir.joinpath(*module_name.split("."))
    return package_dir.is_dir()


def _imported_modules(path: Path) -> set[str]:
    modules: set[str] = set()
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            modules.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            modules.add(node.module)
    return modules


def _dependency_targets(pack_root: Path) -> list[Path]:
    targets = [pack_root / item for item in ENTRYPOINTS]
    tests_dir = pack_root / "tests" / "project_intelligence_graph"
    if tests_dir.exists():
        targets.extend(sorted(tests_dir.glob("*.py")))
    return targets


def _dependency_closure_check(pack_root: Path) -> dict[str, str]:
    script_dir = pack_root / "scripts" / "project_intelligence_graph"
    missing_files = [item for item in ENTRYPOINTS if not (pack_root / item).exists()]
    missing_modules: set[str] = set()
    direct_imports: dict[str, list[str]] = {}
    for target in _dependency_targets(pack_root):
        if not target.exists():
            continue
        try:
            imports = sorted(_imported_modules(target))
        except SyntaxError as exc:
            return _check("import_dependency_closure", False, f"{target.relative_to(pack_root)}: {exc}")
        direct_imports[str(target.relative_to(pack_root))] = imports
        for module in imports:
            root_name = module.split(".", 1)[0]
            if _module_exists(script_dir, module) or root_name in EXPECTED_FIRST_PARTY_MODULES:
                if not _module_exists(script_dir, module):
                    missing_modules.add(module)
    for module in EXPECTED_FIRST_PARTY_MODULES:
        if not _module_exists(script_dir, module):
            missing_modules.add(module)
    if missing_files or missing_modules:
        return {
            "check": "import_dependency_closure",
            "status": "ACTION_REQUIRED",
            "detail": json.dumps(
                {
                    "missing_files": missing_files,
                    "missing_modules": sorted(missing_modules),
                    "direct_imports": direct_imports,
                },
                ensure_ascii=False,
                sort_keys=True,
            ),
        }
    return {
        "check": "import_dependency_closure",
        "status": "PASS",
        "detail": json.dumps({"direct_imports": direct_imports}, ensure_ascii=False, sort_keys=True),
    }


def build_replay_report(pack_root: Path, *, run_commands: bool = True) -> dict[str, Any]:
    pack_root = pack_root.resolve()
    script_dir = pack_root / "scripts" / "project_intelligence_graph"
    helper_dir = pack_root / "profiles" / "generator_sources" / "scripts" / "project_intelligence_graph"
    manifest_path = pack_root / "profile_manifests" / "generator_sources.json"
    replay_manifest_path = pack_root / "independent_replay_pack.json"
    checks: list[dict[str, str]] = [_check("pack_root_exists", pack_root.exists(), str(pack_root))]
    checks.append(_required_input_check("manifest_presence", manifest_path.exists() and replay_manifest_path.exists(), "profile and replay manifests"))

    missing_runnable_root_artifacts = [item for item in RUNNABLE_ROOT_ARTIFACTS if not (pack_root / item).exists()]
    checks.append(
        _required_input_check(
            "runnable_root_artifacts_present",
            not missing_runnable_root_artifacts,
            "missing=" + json.dumps(missing_runnable_root_artifacts, ensure_ascii=False),
        )
    )

    helpers_present = all((helper_dir / name).exists() for name in HELPERS)
    checks.append(_required_input_check("helper_files_present", helpers_present, ", ".join(HELPERS)))

    compiled: list[str] = []
    compile_failures: list[str] = []
    if helpers_present:
        for name in HELPERS:
            path = helper_dir / name
            try:
                py_compile.compile(str(path), doraise=True)
                compiled.append(name)
            except py_compile.PyCompileError as exc:
                compile_failures.append(f"{name}: {exc}")
        checks.append(_check("py_compile", not compile_failures, "; ".join(compile_failures) or f"compiled={compiled}"))
    else:
        checks.append(_required_input_check("py_compile", False, "helper files missing"))

    import_failures: list[str] = []
    if helpers_present:
        if str(helper_dir) not in sys.path:
            sys.path.insert(0, str(helper_dir))
        for name in HELPERS:
            module_name = name.removesuffix(".py")
            try:
                importlib.import_module(module_name)
            except Exception as exc:  # pragma: no cover - detail is emitted for operator review.
                import_failures.append(f"{module_name}: {exc}")
        checks.append(_check("import_smoke", not import_failures, "; ".join(import_failures) or "all helpers import"))
    else:
        checks.append(_required_input_check("import_smoke", False, "helper files missing"))

    checks.append(_dependency_closure_check(pack_root))

    target_files = [pack_root / item for item in ENTRYPOINTS]
    target_files.extend(sorted((pack_root / "tests" / "project_intelligence_graph").glob("*.py")) if (pack_root / "tests" / "project_intelligence_graph").exists() else [])
    missing_compile_inputs = []
    compile_failures = []
    for path in target_files:
        if not path.exists():
            missing_compile_inputs.append(f"{path.relative_to(pack_root)}: missing")
            continue
        try:
            py_compile.compile(str(path), doraise=True)
        except py_compile.PyCompileError as exc:
            compile_failures.append(f"{path.relative_to(pack_root)}: {exc}")
    if missing_compile_inputs:
        checks.append(_required_input_check("entrypoint_py_compile", False, "; ".join(missing_compile_inputs)))
    else:
        checks.append(_check("entrypoint_py_compile", not compile_failures, "; ".join(compile_failures) or f"compiled={len(target_files)}"))

    if run_commands:
        tests_dir = pack_root / "tests"
        pig_path = script_dir / "pig.py"
        replay_path = script_dir / "replay_pack.py"
        checks.append(_required_input_check("tests_dir_present", tests_dir.exists(), "tests/"))
        checks.append(_required_input_check("pig_py_present", pig_path.exists(), "scripts/project_intelligence_graph/pig.py"))
        checks.append(_required_input_check("replay_pack_present", replay_path.exists(), "scripts/project_intelligence_graph/replay_pack.py"))
        if tests_dir.exists():
            checks.append(_run_check("unittest_discover", [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-p", "test_*.py"], cwd=pack_root))
        if pig_path.exists():
            checks.append(_run_check("pig_help", [sys.executable, str(pig_path), "--help"], cwd=pack_root))

    hash_mismatches: list[str] = []
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        for item in manifest.get("files", []):
            path = pack_root / item.get("path", "")
            if path.exists() and item.get("sha256") and _sha256(path) != item.get("sha256"):
                hash_mismatches.append(item.get("path", ""))
    checks.append(_check("hash_sidecars", not hash_mismatches, f"mismatches={hash_mismatches}"))

    required_inputs = [
        manifest_path,
        replay_manifest_path,
        *[pack_root / item for item in RUNNABLE_ROOT_ARTIFACTS],
        *[helper_dir / name for name in HELPERS],
        script_dir / "pig.py",
        script_dir / "m9_efficiency.py",
        script_dir / "replay_pack.py",
    ]
    missing_inputs = [str(path.relative_to(pack_root)) for path in required_inputs if not path.exists()]
    checks.append({
        "check": "missing_inputs_reported",
        "status": "PASS" if not missing_inputs else "ACTION_REQUIRED",
        "detail": f"missing={missing_inputs}",
    })
    fail_count = sum(1 for item in checks if item["status"] == "FAIL")
    action_required_count = sum(1 for item in checks if item["status"] == "ACTION_REQUIRED")
    return {
        "schema_version": 1,
        "status": "PASS" if fail_count == 0 and action_required_count == 0 else "ACTION_REQUIRED" if fail_count == 0 else "FAIL",
        "pack_root": str(pack_root),
        "checks": checks,
        "fail_count": fail_count,
        "action_required_count": action_required_count,
        "missing_inputs": missing_inputs,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pack-root", required=True)
    args = parser.parse_args(argv)
    report = build_replay_report(Path(args.pack_root))
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
