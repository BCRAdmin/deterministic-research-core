from pathlib import Path

from scripts.room16_report_quality_gate import (
    _artifact_consistency_report,
    _normalize_promotion_status,
    _score_bundle,
)


def test_markdown_first_qa_can_pass_without_public_readiness(tmp_path: Path):
    complete_md = tmp_path / "complete.md"
    internal_best = tmp_path / "internal_best_report.md"
    complete_md.write_text("# PLTR\n", encoding="utf-8")
    internal_best.write_text("# Internal\n", encoding="utf-8")
    promotion = _normalize_promotion_status(
        raw_status=None,
        generation_stage="draft_markdown_qa",
        render_mode="markdown_first_qa",
        final_documents_rendered=False,
        requested_visibility="internal_only",
        publish_report_exists=True,
        blocking_issues=[],
    )
    report = _artifact_consistency_report(
        generation_stage="draft_markdown_qa",
        render_mode="markdown_first_qa",
        review_status="qa_pass",
        publishable=False,
        public_ready=False,
        visibility="internal_only",
        artifacts={
            "complete_md": complete_md,
            "complete_docx": tmp_path / "missing.docx",
            "complete_pdf": tmp_path / "missing.pdf",
            "internal_best_report": internal_best,
        },
        promotion_status=promotion,
        metrics={"final_documents_rendered": False, "score_scope": "markdown_qa", "public_rating": None},
    )

    assert promotion["public_ready"] is False
    assert promotion["promotion_status"] == "not_run"
    assert "final_documents_not_rendered" in promotion["promotion_reasons"]
    assert report["artifact_consistency_status"] == "clean"


def test_public_final_requires_promotion_and_rendered_documents(tmp_path: Path):
    complete_md = tmp_path / "complete.md"
    complete_pdf = tmp_path / "complete.pdf"
    complete_docx = tmp_path / "complete.docx"
    internal_best = tmp_path / "internal_best_report.md"
    publish_report = tmp_path / "publish_report.md"
    for path in [complete_md, complete_pdf, complete_docx, internal_best, publish_report]:
        path.write_text("ok", encoding="utf-8")
    promotion = _normalize_promotion_status(
        raw_status={
            "public_ready": True,
            "reviewed_by": "operator",
            "approved_at": "2026-05-17T00:00:00",
            "requested_visibility": "public",
            "non_advice_confirmed": True,
            "sources_human_verified": True,
        },
        generation_stage="public_final",
        render_mode="final_public_documents",
        final_documents_rendered=True,
        requested_visibility="public",
        publish_report_exists=True,
        blocking_issues=[],
    )
    report = _artifact_consistency_report(
        generation_stage="public_final",
        render_mode="final_public_documents",
        review_status="public_ready",
        publishable=True,
        public_ready=True,
        visibility="public",
        artifacts={
            "complete_md": complete_md,
            "complete_docx": complete_docx,
            "complete_pdf": complete_pdf,
            "internal_best_report": internal_best,
            "publish_report": publish_report,
        },
        promotion_status=promotion,
        metrics={
            "final_documents_rendered": True,
            "score_scope": "public_final",
            "render_qa_status": "pass",
            "pdf_render_backend": "pymupdf",
            "rendered_page_count": 3,
        },
    )

    assert promotion["public_ready"] is True
    assert report["artifact_consistency_status"] == "clean"


def test_public_final_blocks_without_full_promotion_stack(tmp_path: Path):
    complete_md = tmp_path / "complete.md"
    complete_pdf = tmp_path / "complete.pdf"
    complete_docx = tmp_path / "complete.docx"
    internal_best = tmp_path / "internal_best_report.md"
    publish_report = tmp_path / "publish_report.md"
    for path in [complete_md, complete_pdf, complete_docx, internal_best, publish_report]:
        path.write_text("ok", encoding="utf-8")

    promotion = _normalize_promotion_status(
        raw_status={"public_ready": True, "reviewed_by": "operator", "requested_visibility": "public"},
        generation_stage="public_final",
        render_mode="final_public_documents",
        final_documents_rendered=True,
        requested_visibility="public",
        publish_report_exists=True,
        blocking_issues=[],
    )
    report = _artifact_consistency_report(
        generation_stage="public_final",
        render_mode="final_public_documents",
        review_status="blocked",
        publishable=False,
        public_ready=False,
        visibility="public_candidate",
        artifacts={
            "complete_md": complete_md,
            "complete_docx": complete_docx,
            "complete_pdf": complete_pdf,
            "internal_best_report": internal_best,
            "publish_report": publish_report,
        },
        promotion_status=promotion,
        metrics={
            "final_documents_rendered": True,
            "score_scope": "public_final",
            "public_rating": None,
            "render_qa_status": "pass",
            "pdf_render_backend": "pymupdf",
            "rendered_page_count": 3,
        },
    )

    assert promotion["public_ready"] is False
    assert promotion["promotion_status"] == "blocked"
    assert "approval_timestamp_missing" in promotion["promotion_reasons"]
    assert "non_advice_confirmation_missing" in promotion["promotion_reasons"]
    assert "sources_human_verification_missing" in promotion["promotion_reasons"]
    assert report["artifact_consistency_status"] == "blocked"


def test_markdown_score_scope_caps_publish_quality():
    scores = _score_bundle(
        base_score=100,
        generation_stage="draft_markdown_qa",
        verdict="pass",
        assessment_status="pass",
        final_documents_rendered=False,
        publish_report_exists=True,
        source_ledger_entries=[],
        research_integrity_verdict="pass",
        artifact_consistency_status="clean",
    )

    assert scores["total_score_legacy"] == 100
    assert scores["publish_quality_score"] <= 65
    assert scores["internal_research_quality_score"] == 100
