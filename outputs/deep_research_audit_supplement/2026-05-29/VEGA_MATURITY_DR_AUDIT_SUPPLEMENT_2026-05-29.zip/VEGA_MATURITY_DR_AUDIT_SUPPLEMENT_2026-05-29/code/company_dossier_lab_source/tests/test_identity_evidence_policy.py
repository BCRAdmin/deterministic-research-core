import json
from pathlib import Path

import pytest

from room16.core.evidence import build_evidence_store
from room16.core.identity import resolve_instrument_identity
from room16.core.source_policy import build_source_coverage, build_source_gap_report


FIXTURE_DIR = Path(__file__).parent / "fixtures" / "room16" / "sbx_status_drift"


def test_sbx_mu_identity_high_for_synbiotic_se():
    payload = json.loads((FIXTURE_DIR / "instrument_identity_if_exists.json").read_text(encoding="utf-8"))

    resolution = resolve_instrument_identity(
        "SBX.MU",
        payload,
        expected_company_name="SynBiotic SE",
        preferred_exchange="Munich",
    )

    assert resolution.blocked is False
    assert resolution.identity_confidence == "high"
    assert resolution.instrument_identity is not None
    assert resolution.instrument_identity.company_name == "SynBiotic SE"
    assert resolution.instrument_identity.exchange == "Munich"
    assert "SBX.F" in resolution.instrument_identity.aliases
    assert "Starbucks" not in " ".join(resolution.suppressed_aliases)


def test_ambiguous_ticker_fixture_blocks_final_report():
    ambiguous_candidates = {
        "candidates": [
            {"symbol": "ABC.MU", "longName": "Alpha Battery Corp", "exchange": "Munich", "score": 20001},
            {"symbol": "ABC.F", "longName": "Another Beverage Company", "exchange": "Frankfurt", "score": 20001},
        ]
    }

    resolution = resolve_instrument_identity(
        "ABC.MU",
        ambiguous_candidates,
        expected_company_name="Alpha Battery Corp",
        preferred_exchange="Munich",
    )

    assert resolution.blocked is True
    assert resolution.identity_confidence == "low"
    assert resolution.block_reason == "identity_confidence_not_high"
    assert resolution.instrument_identity is not None
    assert "same_ticker_root_conflicting_company_names" in resolution.instrument_identity.ambiguity_flags


def test_vendor_only_hard_metric_is_internal_but_not_public():
    evidence_store = build_evidence_store(
        [
            {
                "evidence_id": "ev-vendor-fcf",
                "evidence_type": "financial_metric",
                "title": "Vendor free cash flow",
                "source_id": "vendor-terminal-sbx",
                "source_tier": "vendor",
                "asof": "2026-05-20",
                "period_type": "ttm",
                "observed_value": -1.2,
                "unit": "EURm",
            }
        ]
    )

    coverage = build_source_coverage(evidence_store)
    report = build_source_gap_report(evidence_store, hard_financial_public_claim=True)

    assert coverage.vendor_checked is True
    assert coverage.primary_ir_checked is False
    assert coverage.eqs_checked is False
    assert coverage.bundesanzeiger_checked is False
    assert coverage.reputable_media_checked is False
    assert report.internal_allowed is True
    assert report.public_allowed is False
    assert "hard_financial_public_claim_requires_primary_ir_or_filing" in report.blocking_gaps


def test_financial_metric_missing_source_metadata_blocks_evidence_item():
    with pytest.raises(ValueError, match="financial_metric EvidenceItem requires"):
        build_evidence_store(
            [
                {
                    "evidence_id": "ev-missing-source",
                    "evidence_type": "financial_metric",
                    "title": "FCF without source metadata",
                    "source_tier": "primary_ir",
                }
            ]
        )


def test_primary_ir_hard_metric_is_public_allowed():
    evidence_store = build_evidence_store(
        [
            {
                "evidence_id": "ev-ir-fcf",
                "evidence_type": "financial_metric",
                "title": "IR free cash flow",
                "source_id": "issuer-fy2025-report",
                "source_tier": "primary_ir",
                "asof": "2025-12-31",
                "period_type": "fiscal_year",
                "observed_value": 4.2,
                "unit": "EURm",
            }
        ]
    )

    coverage = build_source_coverage(evidence_store)
    report = build_source_gap_report(evidence_store, hard_financial_public_claim=True)

    assert coverage.primary_ir_checked is True
    assert report.public_allowed is True
    assert report.blocking_gaps == ()
