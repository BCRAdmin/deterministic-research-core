# Room 16 Evidence Report

Tickers: `SBX.MU`
Review status: `quality_pass`
Publishable: `true`

## Source Ledger

| source_id | source_type | asof | period_type | formula_id |
| --- | --- | --- | --- | --- |
| callback:get_stock_data:sbx.mu:2026-05-20:ohlcv_vendor_raw | vendor:yfinance | 2026-05-20 | daily | ohlcv_vendor_raw |
| callback:get_news:sbx.mu:2026-05-20:get_news:raw | vendor:yfinance | 2026-05-20 | event_window | get_news:raw |

## Guard Issues

Fixture excerpt from the failed SBX.MU run. The source report did not surface the
final failed Quality Gate state in this header.
