import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any


FIXTURE_ROOT = Path(__file__).resolve().parents[1] / "fixtures" / "room16"


@dataclass(frozen=True)
class Room16StatusDriftFixture:
    root: Path
    quality_report: dict[str, Any]
    dashboard_status: dict[str, Any]
    artifact_consistency_report: dict[str, Any]
    bundle_manifest: dict[str, Any]
    instrument_identity: dict[str, Any]
    internal_best_report: str
    evidence_report: str
    latest_test_results: str


def load_sbx_status_drift_fixture() -> Room16StatusDriftFixture:
    root = FIXTURE_ROOT / "sbx_status_drift"
    return Room16StatusDriftFixture(
        root=root,
        quality_report=_read_json(root / "quality_report.json"),
        dashboard_status=_read_json(root / "dashboard_status.json"),
        artifact_consistency_report=_read_json(root / "artifact_consistency_report.json"),
        bundle_manifest=_read_json(root / "bundle_manifest.json"),
        instrument_identity=_read_json(root / "instrument_identity_if_exists.json"),
        internal_best_report=(root / "internal_best_report.md").read_text(encoding="utf-8"),
        evidence_report=(root / "evidence_report.md").read_text(encoding="utf-8"),
        latest_test_results=(root / "latest_test_results.txt").read_text(encoding="utf-8"),
    )


def detect_sbx_status_drift(fixture: Room16StatusDriftFixture) -> set[str]:
    codes: set[str] = set()
    quality_failed = (
        fixture.quality_report.get("verdict") == "fail"
        or fixture.quality_report.get("review_status") == "failed"
    )
    dashboard_item = fixture.dashboard_status["items"][0]
    internal_fields = parse_markdown_status_fields(fixture.internal_best_report)
    evidence_fields = parse_markdown_status_fields(fixture.evidence_report)

    if quality_failed and _is_true(internal_fields.get("publishable")):
        codes.add("internal_best_publishable_on_quality_fail")
    if quality_failed and internal_fields.get("review_status") == "quality_pass":
        codes.add("internal_best_quality_pass_on_quality_fail")
    if quality_failed and _is_true(evidence_fields.get("publishable")):
        codes.add("evidence_publishable_on_quality_fail")
    if quality_failed and evidence_fields.get("review_status") == "quality_pass":
        codes.add("evidence_quality_pass_on_quality_fail")
    if dashboard_item.get("public_ready") is False and internal_fields.get("public_rating"):
        codes.add("public_rating_present_when_public_not_ready")
    if "PyMuPDF/fitz missing" in fixture.latest_test_results:
        codes.add("pymupdf_missing_blocks_public_final")
    if (
        fixture.quality_report.get("render_mode") == "markdown_first_qa"
        or fixture.dashboard_status.get("render_mode") == "markdown_first_qa"
    ):
        codes.add("markdown_first_qa_remains_allowed_without_pdf_render")
    if "failed_quality_reports_are_rejected_or_hidden" in fixture.latest_test_results and (
        '"status": "internal_only"' in fixture.latest_test_results
        or "status: internal_only" in fixture.latest_test_results
    ):
        codes.add("failed_quality_library_internal_only")
    if (
        "SynBiotic" in fixture.instrument_identity.get("companyName", "")
        and dashboard_item.get("company_archetype") == "SEMICONDUCTOR_AI_INFRA"
    ):
        codes.add("suspicious_semiconductor_archetype_for_synbiotic")

    return codes


def parse_markdown_status_fields(markdown: str) -> dict[str, str]:
    fields: dict[str, str] = {}
    for raw_line in markdown.splitlines():
        line = raw_line.strip()
        match = re.match(r"^-?\s*([A-Za-z _-]+):\s*`?([^`]+?)`?\s*$", line)
        if not match:
            continue
        key = match.group(1).strip().lower().replace(" ", "_").replace("-", "_")
        fields[key] = match.group(2).strip()
    return fields


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _is_true(value: str | None) -> bool:
    return str(value).lower() == "true"
