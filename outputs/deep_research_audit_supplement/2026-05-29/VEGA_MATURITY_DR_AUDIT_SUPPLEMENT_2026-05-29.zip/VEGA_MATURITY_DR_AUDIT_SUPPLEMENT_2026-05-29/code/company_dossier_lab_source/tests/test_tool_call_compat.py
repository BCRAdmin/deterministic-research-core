from langchain_core.messages import AIMessage

from tradingagents.agents.utils.tool_call_compat import coerce_json_tool_calls


class FakeTool:
    def __init__(self, name):
        self.name = name


def test_coerces_json_tool_call_content():
    message = AIMessage(
        content='{"name": "get_news", "arguments": {"ticker": "PLTR"}}'
    )

    coerced = coerce_json_tool_calls(message, [FakeTool("get_news")])

    assert coerced.content == ""
    assert coerced.tool_calls[0]["name"] == "get_news"
    assert coerced.tool_calls[0]["args"] == {"ticker": "PLTR"}


def test_ignores_unknown_tool_name():
    message = AIMessage(
        content='{"name": "unknown_tool", "arguments": {"ticker": "PLTR"}}'
    )

    coerced = coerce_json_tool_calls(message, [FakeTool("get_news")])

    assert coerced is message


def test_keeps_native_tool_calls():
    message = AIMessage(
        content="",
        tool_calls=[
            {
                "name": "get_news",
                "args": {"ticker": "PLTR"},
                "id": "call_1",
                "type": "tool_call",
            }
        ],
    )

    coerced = coerce_json_tool_calls(message, [FakeTool("get_news")])

    assert coerced is message
