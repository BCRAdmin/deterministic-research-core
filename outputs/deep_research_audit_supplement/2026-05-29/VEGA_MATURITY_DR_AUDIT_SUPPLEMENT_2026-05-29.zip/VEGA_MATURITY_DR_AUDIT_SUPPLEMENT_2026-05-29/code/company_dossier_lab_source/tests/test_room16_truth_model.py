import pytest

from room16.core import (
    EvidenceItem,
    MetricDefinition,
    PeriodType,
    QualityDecision,
    QualityVerdict,
    ReviewStatus,
    SourceTier,
    Visibility,
)


def test_quality_decision_blocks_public_rating_when_not_publishable():
    with pytest.raises(ValueError, match="public_rating requires publishable=true"):
        QualityDecision(
            run_id="20260521-183940-sbx.mu-3fd7ba1d",
            ticker="SBX.MU",
            quality_verdict=QualityVerdict.FAIL,
            review_status=ReviewStatus.FAILED,
            publishable=False,
            public_ready=False,
            visibility=Visibility.HIDDEN,
            internal_rating="Sell",
            public_rating="Sell",
            score_scope="internal_research",
            failed_checks=("research_integrity_no_critical_contradictions",),
            high_findings=("fcf_definition_missing",),
            blocking_issues=("status_drift",),
            created_at="2026-05-21T19:10:00Z",
        )


def test_quality_decision_allows_internal_rating_when_not_publishable():
    decision = QualityDecision(
        run_id="20260521-183940-sbx.mu-3fd7ba1d",
        ticker="SBX.MU",
        quality_verdict="fail",
        review_status="failed",
        publishable=False,
        public_ready=False,
        visibility="hidden",
        internal_rating="Sell",
        public_rating=None,
        score_scope="internal_research",
        failed_checks=("research_integrity_no_critical_contradictions",),
        high_findings=("fcf_definition_missing",),
        blocking_issues=("status_drift",),
        created_at="2026-05-21T19:10:00Z",
    )

    assert decision.public_rating is None
    assert decision.internal_rating == "Sell"


def test_public_ready_requires_publishable_and_public_visibility():
    with pytest.raises(ValueError, match="public_ready requires publishable=true"):
        QualityDecision(
            run_id="run-1",
            ticker="MSFT",
            quality_verdict="pass",
            review_status="public_ready",
            publishable=False,
            public_ready=True,
            visibility="public",
            internal_rating="Hold",
            public_rating=None,
            score_scope="public_final",
            created_at="2026-05-21T19:10:00Z",
        )

    with pytest.raises(ValueError, match="public_ready requires visibility=public"):
        QualityDecision(
            run_id="run-2",
            ticker="MSFT",
            quality_verdict="pass",
            review_status="public_ready",
            publishable=True,
            public_ready=True,
            visibility="public_candidate",
            internal_rating="Hold",
            public_rating="Hold",
            score_scope="public_final",
            created_at="2026-05-21T19:10:00Z",
        )


def test_financial_metric_evidence_requires_source_period_and_tier():
    with pytest.raises(
        ValueError,
        match="financial_metric EvidenceItem requires source_id, asof, period_type, source_tier",
    ):
        EvidenceItem(
            evidence_id="ev-sbx-fcf",
            evidence_type="financial_metric",
            title="Free cash flow",
        )

    item = EvidenceItem(
        evidence_id="ev-msft-fcf",
        evidence_type="financial_metric",
        title="Free cash flow",
        source_id="msft-fy2025-10k",
        source_tier=SourceTier.SEC,
        asof="2025-06-30",
        period_type=PeriodType.FISCAL_YEAR,
        observed_value=74000000000,
        unit="USD",
    )

    assert item.source_id == "msft-fy2025-10k"
    assert item.period_type == PeriodType.FISCAL_YEAR


def test_fcf_metric_definition_can_store_formula():
    definition = MetricDefinition(
        metric_id="free_cash_flow",
        name="Free Cash Flow",
        formula="cash_flow_from_operations - capital_expenditures",
        required_evidence_tiers=(SourceTier.PRIMARY_IR, SourceTier.SEC),
        valid_period_types=(PeriodType.QUARTER, PeriodType.TTM, PeriodType.FISCAL_YEAR),
        unit="currency",
    )

    assert "capital_expenditures" in (definition.formula or "")
    assert SourceTier.SEC in definition.required_evidence_tiers
