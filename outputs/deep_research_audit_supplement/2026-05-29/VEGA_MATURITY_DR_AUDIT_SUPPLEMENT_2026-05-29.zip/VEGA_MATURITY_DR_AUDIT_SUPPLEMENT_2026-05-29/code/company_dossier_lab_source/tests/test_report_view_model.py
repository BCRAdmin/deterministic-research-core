from room16.core.report_view_model import (
    build_quality_decision_for_report_view,
    public_report_link_allowed,
    render_evidence_report,
    render_internal_best_report,
)


def _failed_quality_report() -> dict:
    return {
        "verdict": "fail",
        "generation_stage": "draft_markdown_qa",
        "render_mode": "markdown_first_qa",
        "publishable": False,
        "public_ready": False,
        "visibility": "hidden",
        "metrics": {
            "quality_verdict": "fail",
            "review_status": "failed",
            "research_integrity_verdict": "fail",
            "internal_rating": "Sell",
            "public_rating": None,
        },
        "checks": [
            {
                "name": "research_integrity_no_critical_contradictions",
                "status": "fail",
            }
        ],
    }


def test_render_internal_best_from_failed_quality_decision_is_not_publishable():
    decision = build_quality_decision_for_report_view(_failed_quality_report())
    markdown = render_internal_best_report(
        decision,
        existing_markdown=(
            "# SBX.MU Internal Best Report\n\n"
            "## Statusbox\n\n"
            "- review_status: `quality_pass`\n"
            "- publishable: `true`\n"
            "- public_rating: `Sell`\n\n"
            "## Analyst Note\nBody"
        ),
    )

    assert "- review_status: `failed`" in markdown
    assert "- quality_verdict: `fail`" in markdown
    assert "- publishable: `false`" in markdown
    assert "- public_ready: `false`" in markdown
    assert "- visibility: `hidden`" in markdown
    assert "- public_rating: `null`" in markdown
    assert "- failed_checks: `research_integrity_no_critical_contradictions" in markdown
    assert "quality_pass" not in markdown
    assert "publishable: `true`" not in markdown


def test_render_evidence_from_failed_quality_decision_has_null_public_rating():
    decision = build_quality_decision_for_report_view(_failed_quality_report())
    markdown = render_evidence_report(
        decision,
        existing_markdown=(
            "# Room 16 Evidence Report\n\n"
            "Review status: `quality_pass`\n"
            "- quality_verdict: `pass`\n"
            "Publishable: `true`\n"
            "- public_ready: `true`\n"
            "- public_rating: `Sell`\n\n"
            "## Source Ledger\n"
        ),
    )

    assert "- public_rating: `null`" in markdown
    assert "- publishable: `false`" in markdown
    assert "Review status: `quality_pass`" not in markdown
    assert "quality_verdict: `pass`" not in markdown
    assert "Publishable: `true`" not in markdown
    assert "public_ready: `true`" not in markdown
    assert "public_rating: `Sell`" not in markdown


def test_public_report_link_only_allowed_for_public_ready_quality_decision():
    failed = build_quality_decision_for_report_view(_failed_quality_report())
    assert public_report_link_allowed(failed) is False

    public = {
        **failed,
        "quality_verdict": "pass",
        "review_status": "public_ready",
        "publishable": True,
        "public_ready": True,
        "visibility": "public",
        "public_rating": "Hold",
    }
    assert public_report_link_allowed(public) is True
