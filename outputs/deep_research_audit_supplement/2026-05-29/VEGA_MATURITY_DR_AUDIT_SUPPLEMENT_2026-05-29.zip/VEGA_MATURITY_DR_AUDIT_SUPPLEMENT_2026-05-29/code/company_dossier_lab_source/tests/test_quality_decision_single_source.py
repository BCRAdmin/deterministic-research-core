from pathlib import Path

import pytest

from room16.core.quality_decision import (
    StatusDriftError,
    derive_quality_decision,
    enforce_quality_decision_in_statusbox,
    validate_no_status_drift,
)


def _failed_quality_report() -> dict:
    return {
        "verdict": "fail",
        "generation_stage": "draft_markdown_qa",
        "render_mode": "markdown_first_qa",
        "review_status": "failed",
        "publishable": False,
        "public_ready": False,
        "visibility": "hidden",
        "score_scope": "markdown_qa",
        "publish_gate_verdict": "not_run",
        "promotion_gate_verdict": "not_run",
        "metrics": {
            "status": "quality_pass",
            "analysis_publishable": True,
            "publishable": False,
            "public_ready": False,
            "analysis_review_status": "quality_pass",
            "review_status": "failed",
            "quality_verdict": "fail",
            "research_integrity_verdict": "fail",
            "internal_rating": "Sell",
            "public_rating": None,
        },
    }


def test_derived_quality_decision_for_failed_sbx_mu_is_hidden():
    decision = derive_quality_decision(
        _failed_quality_report(),
        dashboard_status={
            "review_status": "failed",
            "publishable": False,
            "public_ready": False,
            "visibility": "hidden",
        },
        artifact_consistency_report={
            "artifact_consistency_status": "clean",
            "lane": {
                "review_status": "qa_pass",
                "publishable": False,
                "public_ready": False,
                "visibility": "internal_only",
            },
        },
        promotion_status={"promotion_status": "not_run", "public_ready": False},
    )

    assert decision["quality_verdict"] == "fail"
    assert decision["review_status"] == "failed"
    assert decision["publishable"] is False
    assert decision["public_ready"] is False
    assert decision["visibility"] == "hidden"
    assert decision["public_rating"] is None
    assert "artifact_consistency_pre_final_status_ignored" in decision["warnings"]


def test_statusbox_uses_quality_decision_not_report_metadata():
    decision = derive_quality_decision(_failed_quality_report())
    statusbox = enforce_quality_decision_in_statusbox(
        decision,
        {
            "review_status": "quality_pass",
            "publishable": True,
            "public_ready": True,
            "public_rating": "Sell",
            "internal_rating": "Sell",
            "company_archetype": "SEMICONDUCTOR_AI_INFRA",
        },
    )

    assert statusbox["review_status"] == "failed"
    assert statusbox["publishable"] is False
    assert statusbox["public_ready"] is False
    assert statusbox["visibility"] == "hidden"
    assert statusbox["public_rating"] is None
    assert statusbox["internal_rating"] == "Sell"


def test_failed_quality_internal_best_publishable_true_is_status_drift(tmp_path: Path):
    decision = derive_quality_decision(_failed_quality_report())
    internal_best = tmp_path / "internal_best_report.md"
    internal_best.write_text(
        "\n".join(
            [
                "# SBX.MU Internal Best Report",
                "",
                "## Statusbox",
                "",
                "- review_status: `quality_pass`",
                "- publishable: `true`",
                "- public_ready: `true`",
                "- visibility: `public`",
                "- public_rating: `Sell`",
            ]
        ),
        encoding="utf-8",
    )

    result = validate_no_status_drift(decision, internal_best_report=internal_best)

    assert result["status"] == "fail"
    assert {finding["field"] for finding in result["findings"]} >= {
        "review_status",
        "publishable",
        "public_ready",
        "visibility",
        "public_rating",
    }
    with pytest.raises(StatusDriftError):
        validate_no_status_drift(decision, internal_best_report=internal_best, raise_on_drift=True)


def test_artifact_consistency_qa_pass_cannot_override_final_failed():
    decision = derive_quality_decision(
        _failed_quality_report(),
        artifact_consistency_report={
            "artifact_consistency_status": "clean",
            "lane": {
                "review_status": "qa_pass",
                "publishable": False,
                "public_ready": False,
                "visibility": "internal_only",
            },
        },
    )

    result = validate_no_status_drift(
        decision,
        artifact_consistency_report={
            "artifact_consistency_status": "clean",
            "lane": {
                "review_status": "qa_pass",
                "publishable": False,
                "public_ready": False,
                "visibility": "internal_only",
            },
        },
    )

    assert decision["review_status"] == "failed"
    assert result["status"] == "fail"
    assert any(finding["source"] == "artifact_consistency_report.json#lane" for finding in result["findings"])


def test_dashboard_item_cannot_be_publishable_when_decision_failed():
    decision = derive_quality_decision(_failed_quality_report())
    result = validate_no_status_drift(
        decision,
        dashboard_status={
            "review_status": "failed",
            "publishable": False,
            "public_ready": False,
            "visibility": "hidden",
            "items": [
                {
                    "ticker": "SBX.MU",
                    "review_status": "failed",
                    "quality_verdict": "fail",
                    "publishable": True,
                    "public_ready": True,
                    "visibility": "public",
                    "public_rating": "Sell",
                }
            ],
        },
    )

    assert result["status"] == "fail"
    assert any(finding["source"] == "dashboard_status.json#items[0]" for finding in result["findings"])
