from room16.core.claim_validators import (
    NewsContext,
    validate_archetype_claim,
    validate_fcf_claim_definition,
    validate_macro_vs_company_news,
    validate_no_news_claim,
    validate_rating_action_claim,
    validate_source_tier_for_hard_metric,
)
from room16.core.metric_definitions import DEFAULT_METRIC_DEFINITIONS
from room16.core.models import Claim, EvidenceItem, InstrumentIdentity, SourceTier


def test_vendor_empty_with_nvidia_macro_news_is_not_company_news_contradiction():
    claim = Claim(
        claim_id="cl-sbx-news-vendor-empty",
        statement="Der Vendor-Newsfeed lieferte keine Treffer.",
        claim_type="no_news",
    )
    context = NewsContext(
        vendor_news_empty=True,
        primary_sources_checked=False,
        macro_news_present=True,
        sector_news_present=True,
        company_news_present=False,
    )

    no_news_report = validate_no_news_claim(claim, context)
    macro_report = validate_macro_vs_company_news(claim, context)

    assert no_news_report.blockers == ()
    assert macro_report.blockers == ()


def test_no_company_news_requires_primary_source_check():
    claim = Claim(
        claim_id="cl-sbx-no-company-news",
        statement="Es gab keine Unternehmensnachrichten im Zeitraum.",
        claim_type="no_news",
    )
    context = NewsContext(
        vendor_news_empty=True,
        primary_sources_checked=False,
        company_news_checked_empty=False,
    )

    report = validate_no_news_claim(claim, context)

    assert report.validation_status == "blocked"
    assert "company_news_claim_requires_primary_source_check" in report.blockers


def test_fcf_claim_without_formula_is_blocked():
    claim = Claim(
        claim_id="cl-sbx-fcf",
        statement="FCF bleibt ein zentrales Risiko.",
        claim_type="financial_metric",
        metric_ids=("free_cash_flow",),
        evidence_ids=("ev-sbx-fcf",),
    )
    evidence = {
        "ev-sbx-fcf": EvidenceItem(
            evidence_id="ev-sbx-fcf",
            evidence_type="financial_metric",
            title="Vendor FCF",
            source_id="vendor-sbx-cashflow",
            source_tier=SourceTier.VENDOR,
            asof="2026-05-20",
            period_type="ttm",
            observed_value=-1.2,
            unit="EURm",
            metadata={"metric_id": "free_cash_flow"},
        )
    }

    report = validate_fcf_claim_definition(claim, evidence, metric_definitions=())

    assert report.validation_status == "blocked"
    assert "fcf_formula_missing" in report.blockers
    assert "fcf_operating_cash_flow_component_missing" in report.blockers
    assert "fcf_capex_component_missing" in report.blockers


def test_fcf_claim_with_formula_components_source_and_period_passes():
    claim = Claim(
        claim_id="cl-msft-fcf",
        statement="Free cash flow is supported by OCF minus capex.",
        claim_type="financial_metric",
        metric_ids=("free_cash_flow",),
        evidence_ids=("ev-msft-fcf", "ev-msft-ocf", "ev-msft-capex"),
    )
    evidence = {
        "ev-msft-fcf": EvidenceItem(
            evidence_id="ev-msft-fcf",
            evidence_type="financial_metric",
            title="Free cash flow",
            source_id="msft-10k",
            source_tier=SourceTier.SEC,
            asof="2025-06-30",
            period_type="fiscal_year",
            observed_value=74000000000,
            unit="USD",
            metadata={"metric_id": "free_cash_flow", "formula_id": "free_cash_flow.v1"},
        ),
        "ev-msft-ocf": EvidenceItem(
            evidence_id="ev-msft-ocf",
            evidence_type="financial_metric",
            title="Operating cash flow",
            source_id="msft-10k",
            source_tier=SourceTier.SEC,
            asof="2025-06-30",
            period_type="fiscal_year",
            observed_value=136000000000,
            unit="USD",
            metadata={"metric_id": "operating_cash_flow"},
        ),
        "ev-msft-capex": EvidenceItem(
            evidence_id="ev-msft-capex",
            evidence_type="financial_metric",
            title="Capital expenditures",
            source_id="msft-10k",
            source_tier=SourceTier.SEC,
            asof="2025-06-30",
            period_type="fiscal_year",
            observed_value=62000000000,
            unit="USD",
            metadata={"metric_id": "capital_expenditures"},
        ),
    }

    report = validate_fcf_claim_definition(claim, evidence, DEFAULT_METRIC_DEFINITIONS)

    assert report.blockers == ()
    assert report.public_allowed is True


def test_sbx_synbiotic_semiconductor_ai_infra_archetype_is_blocked():
    identity = InstrumentIdentity(
        ticker="SBX.MU",
        company_name="SynBiotic SE",
        instrument_name="Cannabis holding and investment company",
        exchange="Munich",
    )
    evidence = (
        EvidenceItem(
            evidence_id="ev-nvda-macro",
            evidence_type="macro_news",
            title="Nvidia and Marvell AI infrastructure earnings context",
            source_id="vendor-global-news",
            source_tier=SourceTier.VENDOR,
        ),
    )

    report = validate_archetype_claim(
        ticker="SBX.MU",
        company_archetype="SEMICONDUCTOR_AI_INFRA",
        identity=identity,
        evidence_items=evidence,
        archetype_confidence=0.2,
    )

    assert "archetype_identity_mismatch" in report.blockers
    assert "archetype_macro_news_unsupported" in report.blockers


def test_rating_sell_is_internal_only_when_public_not_ready():
    report = validate_rating_action_claim(
        internal_rating="Sell",
        public_rating=None,
        public_ready=False,
    )

    assert report.blockers == ()
    assert report.internal_allowed is True
    assert report.public_allowed is True


def test_public_rating_is_blocked_when_public_not_ready():
    report = validate_rating_action_claim(
        internal_rating="Sell",
        public_rating="Sell",
        public_ready=False,
    )

    assert report.validation_status == "blocked"
    assert "public_rating_requires_public_ready" in report.blockers


def test_vendor_only_hard_metric_blocks_public_claim():
    claim = Claim(
        claim_id="cl-vendor-fcf",
        statement="FCF is negative.",
        claim_type="financial_metric",
        metric_ids=("free_cash_flow",),
        evidence_ids=("ev-vendor-fcf",),
    )
    evidence = {
        "ev-vendor-fcf": EvidenceItem(
            evidence_id="ev-vendor-fcf",
            evidence_type="financial_metric",
            title="Vendor FCF",
            source_id="vendor-terminal",
            source_tier=SourceTier.VENDOR,
            asof="2026-05-20",
            period_type="ttm",
            observed_value=-1.2,
            unit="EURm",
            metadata={"metric_id": "free_cash_flow"},
        )
    }

    report = validate_source_tier_for_hard_metric(claim, evidence, public_claim=True)

    assert report.validation_status == "blocked"
    assert "hard_financial_public_claim_requires_primary_ir_or_filing" in report.blockers
