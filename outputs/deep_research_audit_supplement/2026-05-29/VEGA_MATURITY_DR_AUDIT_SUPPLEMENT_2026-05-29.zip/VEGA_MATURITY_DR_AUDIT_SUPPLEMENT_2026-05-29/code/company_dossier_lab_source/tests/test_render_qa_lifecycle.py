import pytest

from room16.core.render_qa import (
    RenderQABlockedError,
    require_visual_pdf_renderer_for_public_final,
    validate_render_backend_for_lifecycle,
)


def test_public_final_without_fitz_is_blocked():
    result = validate_render_backend_for_lifecycle(
        generation_stage="public_final",
        render_mode="final_public_documents",
        render_backend="unavailable",
        text_backend="unavailable",
        rendered_pages=["complete-page-1.png"],
        fitz_available=False,
    )

    assert result.status == "fail"
    assert "public_final_requires_fitz" in result.blockers
    assert result.public_ready_allowed is False
    with pytest.raises(RenderQABlockedError):
        require_visual_pdf_renderer_for_public_final(
            generation_stage="public_final",
            render_mode="final_public_documents",
            render_backend="unavailable",
            rendered_pages=["complete-page-1.png"],
            fitz_available=False,
        )


def test_markdown_first_qa_without_fitz_is_allowed():
    result = validate_render_backend_for_lifecycle(
        generation_stage="draft_markdown_qa",
        render_mode="markdown_first_qa",
        render_backend="unavailable",
        text_backend="pypdf",
        rendered_pages=[],
        fitz_available=False,
        allow_missing_rendered_documents=True,
    )

    assert result.status == "pass"
    assert result.public_ready_allowed is False
    assert "visual_pdf_renderer_unavailable_for_non_public_lane" in result.warnings


def test_internal_best_without_fitz_is_not_public_ready():
    result = validate_render_backend_for_lifecycle(
        generation_stage="internal_best",
        render_mode="internal_pdf",
        render_backend="unavailable",
        text_backend="pypdf",
        rendered_pages=[],
        fitz_available=False,
    )

    assert result.status == "pass"
    assert result.public_ready_allowed is False
    assert "internal_best_not_public_ready" in result.warnings
    assert "visual_pdf_renderer_unavailable_for_internal_best" in result.warnings


def test_public_final_requires_rendered_pages():
    result = validate_render_backend_for_lifecycle(
        generation_stage="public_final",
        render_mode="final_public_documents",
        render_backend="pymupdf",
        text_backend="pymupdf",
        rendered_pages=[],
        fitz_available=True,
    )

    assert result.status == "fail"
    assert "public_final_requires_rendered_pages" in result.blockers


def test_public_final_requires_render_backend_pymupdf():
    result = validate_render_backend_for_lifecycle(
        generation_stage="public_final",
        render_mode="final_public_documents",
        render_backend="unavailable",
        text_backend="pymupdf",
        rendered_pages=["complete-page-1.png"],
        fitz_available=True,
    )

    assert result.status == "fail"
    assert "public_final_requires_render_backend_pymupdf" in result.blockers


def test_pypdf_text_backend_is_not_enough_for_public_final():
    result = validate_render_backend_for_lifecycle(
        generation_stage="public_final",
        render_mode="final_public_documents",
        render_backend="pypdf",
        text_backend="pypdf",
        rendered_pages=["complete-page-1.png"],
        fitz_available=False,
    )

    assert result.status == "fail"
    assert "pypdf_text_backend_is_not_visual_render_qa" in result.blockers
    assert result.public_ready_allowed is False
