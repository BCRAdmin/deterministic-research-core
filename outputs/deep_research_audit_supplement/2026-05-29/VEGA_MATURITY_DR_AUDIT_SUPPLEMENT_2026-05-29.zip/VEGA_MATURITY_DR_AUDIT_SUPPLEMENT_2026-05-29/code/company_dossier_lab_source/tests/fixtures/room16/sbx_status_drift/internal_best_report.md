# SBX.MU Internal Best Report

## Statusbox

- review_status: `quality_pass`
- publishable: `true`
- internal_rating: `Sell`
- external_display_rating: `Sell`
- public_rating: `Sell`
- company_archetype: `SEMICONDUCTOR_AI_INFRA`

## Internal Analyst Note

Fixture excerpt from the failed SBX.MU run. The quality report verdict is `fail`,
but this display artifact still presents the internal analysis as publishable.
