from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from room16_text_safety import find_visible_reasoning_leaks, strip_visible_reasoning_artifacts


def test_visible_reasoning_leak_detection_blocks_recheck_language():
    text = "Die Lage ist bärisch. Oh nein, warte: das ist falsch. Let me recheck."

    assert "self_correction_nein_warte" in find_visible_reasoning_leaks(text)
    assert "visible_recheck_instruction" in find_visible_reasoning_leaks(text)


def test_visible_reasoning_artifact_strip_keeps_corrected_claim():
    text = (
        "Die 50 SMA fällt kontinuierlich (von ~19,62 Mitte März auf 16,63 Mitte Mai), "
        "ebenso die 200 SMA (von ~22,23 auf 22,99 — nein, warte: 200 SMA geht von "
        "22,23 auf 22,99? Das ist ein Anstieg. Let me recheck.\n\n"
        "Tatsächlich: 200 SMA am 16. März: 22,23 -> 14. Mai: 22,99. "
        "Die 200 SMA steigt leicht."
    )

    cleaned = strip_visible_reasoning_artifacts(text)

    assert "nein, warte" not in cleaned.lower()
    assert "let me recheck" not in cleaned.lower()
    assert "200 SMA am 16. März" in cleaned
    assert "Die 200 SMA steigt leicht" in cleaned
