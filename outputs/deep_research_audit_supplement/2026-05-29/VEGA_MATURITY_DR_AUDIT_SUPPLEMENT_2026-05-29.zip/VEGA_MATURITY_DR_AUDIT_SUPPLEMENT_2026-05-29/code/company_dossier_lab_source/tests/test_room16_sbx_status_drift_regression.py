from tests.helpers.room16_fixture_loader import (
    detect_sbx_status_drift,
    load_sbx_status_drift_fixture,
    parse_markdown_status_fields,
)


def test_fixture_preserves_quality_fail_vs_internal_best_publishable_drift():
    fixture = load_sbx_status_drift_fixture()
    drift_codes = detect_sbx_status_drift(fixture)

    assert fixture.quality_report["verdict"] == "fail"
    assert fixture.quality_report["publishable"] is False
    assert "internal_best_quality_pass_on_quality_fail" in drift_codes
    assert "internal_best_publishable_on_quality_fail" in drift_codes


def test_fixture_preserves_quality_fail_vs_evidence_report_publishable_drift():
    fixture = load_sbx_status_drift_fixture()
    drift_codes = detect_sbx_status_drift(fixture)

    assert "evidence_quality_pass_on_quality_fail" in drift_codes
    assert "evidence_publishable_on_quality_fail" in drift_codes


def test_failed_quality_report_library_status_is_not_normal_internal_only():
    fixture = load_sbx_status_drift_fixture()
    drift_codes = detect_sbx_status_drift(fixture)

    assert fixture.dashboard_status["items"][0]["visibility"] == "hidden"
    assert "failed_quality_library_internal_only" in drift_codes


def test_public_rating_is_null_when_public_ready_is_false():
    fixture = load_sbx_status_drift_fixture()
    internal_fields = parse_markdown_status_fields(fixture.internal_best_report)
    drift_codes = detect_sbx_status_drift(fixture)

    assert fixture.dashboard_status["items"][0]["public_ready"] is False
    assert fixture.dashboard_status["items"][0]["public_rating"] is None
    assert internal_fields["public_rating"] == "Sell"
    assert "public_rating_present_when_public_not_ready" in drift_codes


def test_pymupdf_missing_blocks_public_final_but_not_markdown_first_qa():
    fixture = load_sbx_status_drift_fixture()
    drift_codes = detect_sbx_status_drift(fixture)

    assert fixture.dashboard_status["render_mode"] == "markdown_first_qa"
    assert "pymupdf_missing_blocks_public_final" in drift_codes
    assert "markdown_first_qa_remains_allowed_without_pdf_render" in drift_codes


def test_synbiotic_semiconductor_archetype_is_suspicious():
    fixture = load_sbx_status_drift_fixture()
    drift_codes = detect_sbx_status_drift(fixture)

    assert fixture.instrument_identity["companyName"] == "SynBiotic SE"
    assert fixture.dashboard_status["items"][0]["company_archetype"] == "SEMICONDUCTOR_AI_INFRA"
    assert "suspicious_semiconductor_archetype_for_synbiotic" in drift_codes


def test_core_v2_quality_decision_adapter_will_hide_failed_artifacts(tmp_path):
    from room16.core.quality_decision import validate_no_status_drift
    from room16.core.report_view_model import (
        build_quality_decision_for_report_view,
        render_evidence_report,
        render_internal_best_report,
    )

    fixture = load_sbx_status_drift_fixture()
    decision = build_quality_decision_for_report_view(
        fixture.quality_report,
        dashboard_status=fixture.dashboard_status,
        artifact_consistency_report=fixture.artifact_consistency_report,
    )
    internal_best = render_internal_best_report(
        decision,
        existing_markdown=fixture.internal_best_report,
        metadata={
            "internal_rating": fixture.dashboard_status["items"][0]["internal_rating"],
            "company_archetype": fixture.dashboard_status["items"][0]["company_archetype"],
            "archetype_confidence": fixture.dashboard_status["items"][0]["archetype_confidence"],
        },
    )
    evidence_report = render_evidence_report(
        decision,
        existing_markdown=fixture.evidence_report,
    )
    internal_fields = parse_markdown_status_fields(internal_best)
    evidence_fields = parse_markdown_status_fields(evidence_report)

    assert decision["review_status"] == "failed"
    assert decision["publishable"] is False
    assert decision["public_ready"] is False
    assert decision["public_rating"] is None
    assert decision["visibility"] in {"hidden", "rejected", "debug_only"}

    assert internal_fields["review_status"] == "failed"
    assert internal_fields["publishable"] == "false"
    assert internal_fields["public_ready"] == "false"
    assert internal_fields["public_rating"] == "null"
    assert internal_fields["visibility"] in {"hidden", "rejected", "debug_only"}
    assert "quality_pass" not in internal_best
    assert "publishable: `true`" not in internal_best

    assert evidence_fields["review_status"] == "failed"
    assert evidence_fields["publishable"] == "false"
    assert evidence_fields["public_ready"] == "false"
    assert evidence_fields["public_rating"] == "null"
    assert evidence_fields["visibility"] in {"hidden", "rejected", "debug_only"}
    assert "quality_pass" not in evidence_report
    assert "Publishable: `true`" not in evidence_report

    internal_best_path = tmp_path / "internal_best_report.md"
    evidence_report_path = tmp_path / "evidence_report.md"
    internal_best_path.write_text(internal_best, encoding="utf-8")
    evidence_report_path.write_text(evidence_report, encoding="utf-8")
    status_drift = validate_no_status_drift(
        decision,
        internal_best_report=internal_best_path,
        evidence_report=evidence_report_path,
        dashboard_status=fixture.dashboard_status,
    )
    assert status_drift == {
        "schema_version": 1,
        "status": "pass",
        "drift_count": 0,
        "findings": [],
    }
