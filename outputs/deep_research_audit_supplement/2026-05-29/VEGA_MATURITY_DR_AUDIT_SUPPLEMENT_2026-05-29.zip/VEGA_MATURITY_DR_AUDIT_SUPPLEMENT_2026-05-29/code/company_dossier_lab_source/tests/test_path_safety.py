import os
import tempfile
import unittest
from pathlib import Path

import pytest

from tradingagents.dataflows.stockstats_utils import load_ohlcv
from tradingagents.graph.checkpointer import _db_path, thread_id
from tradingagents.symbols import normalize_path_symbol


@pytest.mark.unit
class PathSafetyTests(unittest.TestCase):
    def test_normalize_path_symbol_allows_common_exchange_suffixes(self):
        self.assertEqual(normalize_path_symbol(" bmw.de "), "BMW.DE")
        self.assertEqual(normalize_path_symbol("brk-b"), "BRK-B")

    def test_normalize_path_symbol_rejects_path_traversal(self):
        with self.assertRaises(ValueError):
            normalize_path_symbol("../AAPL")
        with self.assertRaises(ValueError):
            normalize_path_symbol("AAPL/../../tmp")

    def test_checkpointer_path_uses_sanitized_symbol(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = _db_path(tmp, "bmw.de")
            self.assertEqual(path, Path(tmp) / "checkpoints" / "BMW.DE.db")
            self.assertTrue(str(path).startswith(tmp))

    def test_thread_id_rejects_invalid_symbol(self):
        with self.assertRaises(ValueError):
            thread_id("../AAPL", "2026-01-15")

    def test_load_ohlcv_rejects_invalid_symbol_before_cache_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            old = os.environ.get("TRADINGAGENTS_CACHE_DIR")
            os.environ["TRADINGAGENTS_CACHE_DIR"] = tmp
            try:
                with self.assertRaises(ValueError):
                    load_ohlcv("../AAPL", "2026-01-15")
            finally:
                if old is None:
                    os.environ.pop("TRADINGAGENTS_CACHE_DIR", None)
                else:
                    os.environ["TRADINGAGENTS_CACHE_DIR"] = old
