"""Claim validation rules for Room 16 Core v2."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Iterable

from room16.core.claims import ClaimGraph
from room16.core.metric_definitions import (
    CAPEX_METRIC_ID,
    DEFAULT_METRIC_DEFINITIONS,
    FREE_CASH_FLOW_FORMULA_ID,
    OPERATING_CASH_FLOW_METRIC_ID,
    is_fcf_metric_id,
    metric_definition_by_id,
)
from room16.core.models import Claim, EvidenceItem, InstrumentIdentity, MetricDefinition, SourceTier
from room16.core.source_policy import build_source_gap_report


@dataclass(frozen=True)
class NewsContext:
    vendor_news_empty: bool = False
    company_news_checked_empty: bool = False
    primary_sources_checked: bool = False
    sector_news_present: bool = False
    macro_news_present: bool = False
    company_news_present: bool = False


@dataclass(frozen=True)
class ClaimValidationFinding:
    code: str
    message: str
    severity: str = "warning"
    claim_id: str | None = None
    blocker: bool = False

    def to_dict(self) -> dict[str, object]:
        return {
            "code": self.code,
            "message": self.message,
            "severity": self.severity,
            "claim_id": self.claim_id,
            "blocker": self.blocker,
        }


@dataclass(frozen=True)
class ClaimValidationReport:
    validation_status: str
    internal_allowed: bool
    public_allowed: bool
    findings: tuple[ClaimValidationFinding, ...] = field(default_factory=tuple)

    @property
    def blockers(self) -> tuple[str, ...]:
        return tuple(finding.code for finding in self.findings if finding.blocker)

    @property
    def warnings(self) -> tuple[str, ...]:
        return tuple(finding.code for finding in self.findings if not finding.blocker)

    def to_dict(self) -> dict[str, object]:
        return {
            "validation_status": self.validation_status,
            "internal_allowed": self.internal_allowed,
            "public_allowed": self.public_allowed,
            "blockers": self.blockers,
            "warnings": self.warnings,
            "findings": [finding.to_dict() for finding in self.findings],
        }


def _report_from_findings(findings: Iterable[ClaimValidationFinding]) -> ClaimValidationReport:
    frozen_findings = tuple(findings)
    blocked = any(finding.blocker for finding in frozen_findings)
    return ClaimValidationReport(
        validation_status="blocked" if blocked else "validated",
        internal_allowed=True,
        public_allowed=not blocked,
        findings=frozen_findings,
    )


def _text(value: str) -> str:
    return value.casefold()


def _claim_text(claim: Claim) -> str:
    return _text(claim.statement)


def _is_no_company_news_claim(claim: Claim) -> bool:
    text = _claim_text(claim)
    return (
        claim.claim_type in {"no_news", "company_news_absence", "news_absence"}
        or "keine unternehmensnachrichten" in text
        or "keine unternehmensspezifischen nachrichten" in text
        or "keine wesentlichen nachrichten" in text
        or "keine materiellen nachrichten" in text
        or "no company news" in text
        or "no material company news" in text
    )


def _is_vendor_empty_news_claim(claim: Claim) -> bool:
    text = _claim_text(claim)
    return (
        "vendor-newsfeed" in text
        or "vendor-news" in text
        or "vendor-basierten nachrichten" in text
        or "vendor based news" in text
        or "vendor newsfeed returned no" in text
    )


def _is_fcf_claim(claim: Claim) -> bool:
    text = _claim_text(claim)
    return (
        claim.claim_type in {"financial_metric", "fcf", "free_cash_flow"}
        and any(is_fcf_metric_id(metric_id) for metric_id in claim.metric_ids)
    ) or "free cash flow" in text or "fcf" in text or "freier cashflow" in text


def _tier_value(tier: SourceTier | str | None) -> str | None:
    if isinstance(tier, Enum):
        return tier.value
    return tier


def _evidence_metric_id(item: EvidenceItem) -> str:
    return str(item.metadata.get("metric_id") or item.metadata.get("metric") or "").strip().lower()


def _evidence_formula_id(item: EvidenceItem) -> str:
    return str(item.metadata.get("formula_id") or "").strip()


def _is_explicit_missing(item: EvidenceItem, metric_id: str) -> bool:
    return bool(item.metadata.get("explicit_missing")) and _evidence_metric_id(item) == metric_id


def validate_no_news_claim(claim: Claim, news_context: NewsContext) -> ClaimValidationReport:
    """Validate vendor-empty versus company-news absence wording."""

    findings: list[ClaimValidationFinding] = []
    vendor_empty = _is_vendor_empty_news_claim(claim)
    no_company_news = _is_no_company_news_claim(claim)
    if vendor_empty and news_context.vendor_news_empty:
        return _report_from_findings(findings)
    if no_company_news and news_context.company_news_present:
        findings.append(
            ClaimValidationFinding(
                code="company_news_absence_contradicted",
                message="Claim says there were no company news, but company-news evidence is present.",
                severity="critical",
                claim_id=claim.claim_id,
                blocker=True,
            )
        )
    if no_company_news and not (news_context.primary_sources_checked and news_context.company_news_checked_empty):
        findings.append(
            ClaimValidationFinding(
                code="company_news_claim_requires_primary_source_check",
                message="No-company-news claims require checked primary/company sources, not only an empty vendor feed.",
                severity="high",
                claim_id=claim.claim_id,
                blocker=True,
            )
        )
    return _report_from_findings(findings)


def validate_macro_vs_company_news(claim: Claim, news_context: NewsContext) -> ClaimValidationReport:
    """Keep macro/sector news separate from company-news contradictions."""

    findings: list[ClaimValidationFinding] = []
    if _is_vendor_empty_news_claim(claim) and not news_context.company_news_present:
        return _report_from_findings(findings)
    if _is_no_company_news_claim(claim) and news_context.company_news_present:
        findings.append(
            ClaimValidationFinding(
                code="company_news_contradiction",
                message="Company-specific news evidence contradicts a no-company-news claim.",
                severity="critical",
                claim_id=claim.claim_id,
                blocker=True,
            )
        )
    if _is_no_company_news_claim(claim) and (news_context.macro_news_present or news_context.sector_news_present):
        findings.append(
            ClaimValidationFinding(
                code="macro_news_not_company_news",
                message="Macro or sector news cannot prove company-news presence and must be labeled separately.",
                severity="info",
                claim_id=claim.claim_id,
                blocker=False,
            )
        )
    return _report_from_findings(findings)


def validate_fcf_claim_definition(
    claim: Claim,
    evidence_by_id: dict[str, EvidenceItem],
    metric_definitions: tuple[MetricDefinition, ...] = DEFAULT_METRIC_DEFINITIONS,
) -> ClaimValidationReport:
    """Require formula, component evidence, period, and source metadata for FCF claims."""

    if not _is_fcf_claim(claim):
        return _report_from_findings(())

    findings: list[ClaimValidationFinding] = []
    evidence_items = tuple(
        evidence_by_id[evidence_id]
        for evidence_id in claim.evidence_ids
        if evidence_id in evidence_by_id
    )
    fcf_definition = metric_definition_by_id("free_cash_flow", metric_definitions)
    has_formula = bool(fcf_definition and fcf_definition.formula) or any(
        _evidence_formula_id(item) == FREE_CASH_FLOW_FORMULA_ID for item in evidence_items
    )
    if not has_formula:
        findings.append(
            ClaimValidationFinding(
                code="fcf_formula_missing",
                message="FCF claims require a visible formula_id or metric definition.",
                severity="high",
                claim_id=claim.claim_id,
                blocker=True,
            )
        )
    component_ids = {_evidence_metric_id(item) for item in evidence_items}
    has_ocf = OPERATING_CASH_FLOW_METRIC_ID in component_ids or any(
        _is_explicit_missing(item, OPERATING_CASH_FLOW_METRIC_ID) for item in evidence_items
    )
    has_capex = CAPEX_METRIC_ID in component_ids or any(
        _is_explicit_missing(item, CAPEX_METRIC_ID) for item in evidence_items
    )
    if not has_ocf:
        findings.append(
            ClaimValidationFinding(
                code="fcf_operating_cash_flow_component_missing",
                message="FCF claims require operating cash flow evidence or an explicit missing marker.",
                severity="high",
                claim_id=claim.claim_id,
                blocker=True,
            )
        )
    if not has_capex:
        findings.append(
            ClaimValidationFinding(
                code="fcf_capex_component_missing",
                message="FCF claims require capex evidence or an explicit missing marker.",
                severity="high",
                claim_id=claim.claim_id,
                blocker=True,
            )
        )
    for item in evidence_items:
        if item.evidence_type != "financial_metric":
            continue
        if not item.source_id:
            findings.append(
                ClaimValidationFinding(
                    code="fcf_source_id_missing",
                    message="FCF financial evidence requires source_id.",
                    severity="high",
                    claim_id=claim.claim_id,
                    blocker=True,
                )
            )
        if not item.period_type:
            findings.append(
                ClaimValidationFinding(
                    code="fcf_period_type_missing",
                    message="FCF financial evidence requires period_type.",
                    severity="high",
                    claim_id=claim.claim_id,
                    blocker=True,
                )
            )
    if not evidence_items:
        findings.append(
            ClaimValidationFinding(
                code="fcf_evidence_missing",
                message="FCF claims require linked evidence.",
                severity="high",
                claim_id=claim.claim_id,
                blocker=True,
            )
        )
    return _report_from_findings(findings)


def validate_identity_consistency_claim(
    claim: Claim,
    identity: InstrumentIdentity | None,
) -> ClaimValidationReport:
    """Block claims that visibly name a different company than the resolved identity."""

    if identity is None:
        return _report_from_findings(())
    text = _claim_text(claim)
    findings: list[ClaimValidationFinding] = []
    if "starbucks" in text and "starbucks" not in identity.company_name.casefold():
        findings.append(
            ClaimValidationFinding(
                code="claim_company_identity_mismatch",
                message="Claim text references Starbucks while the resolved instrument identity is different.",
                severity="critical",
                claim_id=claim.claim_id,
                blocker=True,
            )
        )
    return _report_from_findings(findings)


def _identity_business_text(identity: InstrumentIdentity | None) -> str:
    if identity is None:
        return ""
    parts = [identity.company_name, identity.instrument_name or "", " ".join(identity.aliases)]
    return " ".join(parts).casefold()


def _has_business_evidence_for_archetype(archetype: str, evidence_items: tuple[EvidenceItem, ...]) -> bool:
    if archetype != "SEMICONDUCTOR_AI_INFRA":
        return True
    semantic_terms = ("semiconductor", "chip", "gpu", "ai infra", "ai infrastructure", "datacenter")
    for item in evidence_items:
        if item.evidence_type in {"macro_news", "sector_news"}:
            continue
        haystack = " ".join(
            [
                item.title,
                str(item.metadata.get("business_description") or ""),
                str(item.metadata.get("industry") or ""),
                str(item.metadata.get("sector") or ""),
            ]
        ).casefold()
        if any(term in haystack for term in semantic_terms):
            return True
    return False


def validate_archetype_claim(
    *,
    ticker: str,
    company_archetype: str,
    identity: InstrumentIdentity | None,
    evidence_items: tuple[EvidenceItem, ...] = (),
    archetype_confidence: float | None = None,
) -> ClaimValidationReport:
    """Validate that an archetype is grounded in company/business evidence."""

    findings: list[ClaimValidationFinding] = []
    archetype = company_archetype.strip().upper()
    business_text = _identity_business_text(identity)
    cannabis_like = any(term in business_text for term in ("synbiotic", "cannabis", "hemp", "cbd"))
    if archetype == "SEMICONDUCTOR_AI_INFRA" and cannabis_like and not _has_business_evidence_for_archetype(archetype, evidence_items):
        findings.append(
            ClaimValidationFinding(
                code="archetype_identity_mismatch",
                message=f"{ticker} resolved as SynBiotic/Cannabis-like identity cannot be classified as SEMICONDUCTOR_AI_INFRA without business evidence.",
                severity="critical" if (archetype_confidence or 0.0) < 0.75 else "high",
                claim_id=None,
                blocker=True,
            )
        )
    if archetype == "SEMICONDUCTOR_AI_INFRA" and evidence_items and not _has_business_evidence_for_archetype(archetype, evidence_items):
        if all(item.evidence_type in {"macro_news", "sector_news"} for item in evidence_items):
            findings.append(
                ClaimValidationFinding(
                    code="archetype_macro_news_unsupported",
                    message="Company archetype cannot be derived only from macro or sector news.",
                    severity="high",
                    claim_id=None,
                    blocker=True,
                )
            )
    return _report_from_findings(findings)


def validate_rating_action_claim(
    *,
    internal_rating: str | None,
    public_rating: str | None,
    public_ready: bool,
) -> ClaimValidationReport:
    """Allow internal ratings while blocking public ratings before public readiness."""

    findings: list[ClaimValidationFinding] = []
    if public_rating is not None and not public_ready:
        findings.append(
            ClaimValidationFinding(
                code="public_rating_requires_public_ready",
                message="A public rating cannot be exposed while public_ready=false.",
                severity="critical",
                claim_id=None,
                blocker=True,
            )
        )
    if internal_rating and public_rating is None and not public_ready:
        return _report_from_findings(findings)
    return _report_from_findings(findings)


def validate_source_tier_for_hard_metric(
    claim: Claim,
    evidence_by_id: dict[str, EvidenceItem],
    *,
    public_claim: bool = False,
) -> ClaimValidationReport:
    """Validate source tiers for hard financial metric claims."""

    if claim.claim_type != "financial_metric":
        return _report_from_findings(())
    evidence_items = tuple(
        evidence_by_id[evidence_id]
        for evidence_id in claim.evidence_ids
        if evidence_id in evidence_by_id
    )
    gap_report = build_source_gap_report(evidence_items, hard_financial_public_claim=public_claim)
    findings = [
        ClaimValidationFinding(
            code=code,
            message="Hard financial public claims require primary IR, filing, EQS, or Bundesanzeiger evidence.",
            severity="high",
            claim_id=claim.claim_id,
            blocker=True,
        )
        for code in gap_report.blocking_gaps
    ]
    findings.extend(
        ClaimValidationFinding(
            code=code,
            message="Vendor-only financial evidence is internal-only.",
            severity="warning",
            claim_id=claim.claim_id,
            blocker=False,
        )
        for code in gap_report.warnings
    )
    return _report_from_findings(findings)


def validate_claim_graph(
    claim_graph: ClaimGraph,
    *,
    news_context: NewsContext | None = None,
    public_claims: bool = False,
) -> ClaimValidationReport:
    """Run the focused Vega 3 validators over a ClaimGraph."""

    findings: list[ClaimValidationFinding] = []
    evidence_by_id = claim_graph.evidence_by_id
    metric_definitions = claim_graph.metric_definitions or DEFAULT_METRIC_DEFINITIONS
    for claim in claim_graph.claims:
        reports = [
            validate_identity_consistency_claim(claim, claim_graph.instrument_identity),
            validate_fcf_claim_definition(claim, evidence_by_id, metric_definitions),
            validate_source_tier_for_hard_metric(claim, evidence_by_id, public_claim=public_claims),
        ]
        if news_context is not None:
            reports.extend(
                [
                    validate_no_news_claim(claim, news_context),
                    validate_macro_vs_company_news(claim, news_context),
                ]
            )
        for report in reports:
            findings.extend(report.findings)
    return _report_from_findings(findings)
