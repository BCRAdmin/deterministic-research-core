"""QualityDecision single source of truth for Room 16 lifecycle status."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from .lifecycle import lifecycle_status_from_inputs, normalize_bool, normalize_optional_text

QUALITY_STATUS_KEYS = {
    "quality_verdict",
    "review_status",
    "publishable",
    "public_ready",
    "visibility",
    "public_rating",
}


class StatusDriftError(AssertionError):
    """Raised when a report artifact contradicts QualityDecision."""


def _load_json(payload: dict[str, Any] | str | Path | None) -> dict[str, Any]:
    if payload is None:
        return {}
    if isinstance(payload, dict):
        return payload
    path = Path(payload)
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def _read_text(payload: str | Path | None) -> str:
    if payload is None:
        return ""
    path = Path(payload)
    if path.exists():
        return path.read_text(encoding="utf-8", errors="replace")
    return str(payload)


def _pick(payload: dict[str, Any], key: str) -> Any:
    if key in payload:
        return payload.get(key)
    metrics = payload.get("metrics")
    if isinstance(metrics, dict) and key in metrics:
        return metrics.get(key)
    return None


def derive_quality_decision(
    quality_report: dict[str, Any] | str | Path,
    *,
    dashboard_status: dict[str, Any] | str | Path | None = None,
    artifact_consistency_report: dict[str, Any] | str | Path | None = None,
    promotion_status: dict[str, Any] | str | Path | None = None,
) -> dict[str, Any]:
    quality = _load_json(quality_report)
    dashboard = _load_json(dashboard_status)
    artifact_consistency = _load_json(artifact_consistency_report)
    promotion = _load_json(promotion_status)
    lifecycle = lifecycle_status_from_inputs(
        quality_report=quality,
        promotion_status=promotion,
        artifact_consistency_report=artifact_consistency,
    )

    metrics = quality.get("metrics") if isinstance(quality.get("metrics"), dict) else {}
    decision = {
        "schema_version": 1,
        "decision_type": "room16_quality_decision",
        "quality_verdict": lifecycle["quality_verdict"],
        "review_status": lifecycle["review_status"],
        "generation_stage": _pick(quality, "generation_stage") or dashboard.get("generation_stage"),
        "render_mode": _pick(quality, "render_mode") or dashboard.get("render_mode"),
        "publishable": lifecycle["publishable"],
        "public_ready": lifecycle["public_ready"],
        "visibility": lifecycle["visibility"],
        "score_scope": _pick(quality, "score_scope") or dashboard.get("score_scope"),
        "publish_gate_verdict": _pick(quality, "publish_gate_verdict") or dashboard.get("publish_gate_verdict"),
        "promotion_gate_verdict": _pick(quality, "promotion_gate_verdict") or dashboard.get("promotion_gate_verdict"),
        "internal_rating": normalize_optional_text(metrics.get("internal_rating") or quality.get("internal_rating")),
        "public_rating": lifecycle["public_rating"],
        "blockers": lifecycle["blockers"],
        "warnings": lifecycle["warnings"],
        "source_observations": {
            "dashboard_review_status": dashboard.get("review_status"),
            "artifact_consistency_status": artifact_consistency.get("artifact_consistency_status"),
            "promotion_status": promotion.get("promotion_status") or promotion.get("status"),
        },
    }
    if decision["quality_verdict"] == "fail":
        decision["publish_gate_verdict"] = decision["publish_gate_verdict"] or "not_run"
        decision["promotion_gate_verdict"] = decision["promotion_gate_verdict"] or "not_run"
    return decision


def enforce_quality_decision_in_statusbox(
    quality_decision: dict[str, Any],
    existing_report_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    metadata = dict(existing_report_metadata or {})
    statusbox = {
        "quality_verdict": quality_decision.get("quality_verdict"),
        "review_status": quality_decision.get("review_status"),
        "publishable": quality_decision.get("publishable"),
        "public_ready": quality_decision.get("public_ready"),
        "visibility": quality_decision.get("visibility"),
        "public_rating": quality_decision.get("public_rating"),
    }
    for key in ("internal_rating", "company_archetype", "archetype_confidence"):
        if key in metadata:
            statusbox[key] = metadata[key]
    return statusbox


_MARKDOWN_STATUS_PATTERN = re.compile(
    r"^\s*(?:[-*]\s*)?"
    r"(quality_verdict|review_status|publishable|public_ready|visibility|public_rating)"
    r"\s*:\s*`?([^`\n]+?)`?\s*$",
    re.IGNORECASE | re.MULTILINE,
)


def _normalize_status_value(value: Any) -> Any:
    boolean = normalize_bool(value)
    if boolean is not None:
        return boolean
    return normalize_optional_text(value)


def _extract_markdown_status(text: str) -> dict[str, Any]:
    extracted: dict[str, Any] = {}
    for match in _MARKDOWN_STATUS_PATTERN.finditer(text):
        extracted[match.group(1).lower()] = _normalize_status_value(match.group(2))
    return extracted


def _extract_json_status(payload: dict[str, Any]) -> dict[str, Any]:
    return {key: _normalize_status_value(payload.get(key)) for key in QUALITY_STATUS_KEYS if key in payload}


def _expected_status(decision: dict[str, Any]) -> dict[str, Any]:
    return {key: _normalize_status_value(decision.get(key)) for key in QUALITY_STATUS_KEYS}


def _compare_status(source: str, actual: dict[str, Any], expected: dict[str, Any]) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for key, actual_value in actual.items():
        if key not in expected:
            continue
        expected_value = expected[key]
        if actual_value != expected_value:
            findings.append(
                {
                    "source": source,
                    "field": key,
                    "expected": expected_value,
                    "actual": actual_value,
                    "severity": "blocking",
                }
            )
    return findings


def validate_no_status_drift(
    quality_decision: dict[str, Any],
    *,
    internal_best_report: str | Path | None = None,
    evidence_report: str | Path | None = None,
    dashboard_status: dict[str, Any] | str | Path | None = None,
    bundle_manifest: dict[str, Any] | str | Path | None = None,
    artifact_consistency_report: dict[str, Any] | str | Path | None = None,
    raise_on_drift: bool = False,
) -> dict[str, Any]:
    expected = _expected_status(quality_decision)
    findings: list[dict[str, Any]] = []

    if internal_best_report is not None:
        findings.extend(
            _compare_status(
                "internal_best_report.md",
                _extract_markdown_status(_read_text(internal_best_report)),
                expected,
            )
        )
    if evidence_report is not None:
        findings.extend(
            _compare_status(
                "evidence_report.md",
                _extract_markdown_status(_read_text(evidence_report)),
                expected,
            )
        )

    dashboard = _load_json(dashboard_status)
    if dashboard:
        findings.extend(_compare_status("dashboard_status.json", _extract_json_status(dashboard), expected))
        for index, item in enumerate(dashboard.get("items") or []):
            if isinstance(item, dict):
                findings.extend(
                    _compare_status(
                        f"dashboard_status.json#items[{index}]",
                        _extract_json_status(item),
                        expected,
                    )
                )

    manifest = _load_json(bundle_manifest)
    if manifest:
        findings.extend(_compare_status("bundle_manifest.json", _extract_json_status(manifest), expected))
        for index, item in enumerate(manifest.get("items") or manifest.get("reports") or []):
            if isinstance(item, dict):
                findings.extend(
                    _compare_status(
                        f"bundle_manifest.json#items[{index}]",
                        _extract_json_status(item),
                        expected,
                    )
                )

    artifact_consistency = _load_json(artifact_consistency_report)
    lane = artifact_consistency.get("lane") if isinstance(artifact_consistency.get("lane"), dict) else {}
    if lane:
        findings.extend(_compare_status("artifact_consistency_report.json#lane", _extract_json_status(lane), expected))

    result = {
        "schema_version": 1,
        "status": "pass" if not findings else "fail",
        "drift_count": len(findings),
        "findings": findings,
    }
    if findings and raise_on_drift:
        raise StatusDriftError(json.dumps(result, indent=2, ensure_ascii=False))
    return result
