"""Instrument identity resolution for Room 16 Core v2."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable

from room16.core.models import InstrumentIdentity


@dataclass(frozen=True)
class InstrumentCandidate:
    symbol: str
    company_name: str
    exchange: str | None = None
    quote_type: str | None = None
    score: int | float | None = None
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class IdentityResolution:
    instrument_identity: InstrumentIdentity | None
    identity_confidence: str
    candidates: tuple[InstrumentCandidate, ...]
    blocked: bool
    block_reason: str | None = None
    suppressed_aliases: tuple[str, ...] = field(default_factory=tuple)


def _normalize_text(value: str | None) -> str:
    return " ".join((value or "").strip().lower().split())


def _canonical_company_name(value: str | None) -> str:
    normalized = _normalize_text(value)
    for suffix in (" n", " registered share", " ordinary share"):
        if normalized.endswith(suffix):
            normalized = normalized[: -len(suffix)].strip()
    return normalized


def _ticker_root(symbol: str) -> str:
    return symbol.split(".", 1)[0].upper()


def _candidate_company_name(raw: dict[str, Any]) -> str:
    return str(
        raw.get("company_name")
        or raw.get("companyName")
        or raw.get("longName")
        or raw.get("shortName")
        or raw.get("name")
        or ""
    ).strip()


def normalize_instrument_candidates(raw_candidates: Iterable[dict[str, Any]] | dict[str, Any]) -> tuple[InstrumentCandidate, ...]:
    """Normalize provider-specific identity candidates into one shape."""

    if isinstance(raw_candidates, dict):
        candidates = raw_candidates.get("candidates", [])
    else:
        candidates = raw_candidates
    normalized: list[InstrumentCandidate] = []
    for raw in candidates:
        symbol = str(raw.get("symbol") or raw.get("ticker") or "").strip().upper()
        company_name = _candidate_company_name(raw)
        if not symbol or not company_name:
            continue
        normalized.append(
            InstrumentCandidate(
                symbol=symbol,
                company_name=company_name,
                exchange=str(raw.get("exchange") or "").strip() or None,
                quote_type=str(raw.get("quoteType") or raw.get("quote_type") or "").strip() or None,
                score=raw.get("score"),
                raw=dict(raw),
            )
        )
    return tuple(normalized)


def validate_identity_confidence(
    resolution: IdentityResolution,
    *,
    require_high: bool = True,
) -> IdentityResolution:
    """Return the resolution if confidence is acceptable, otherwise block it."""

    if require_high and resolution.identity_confidence != "high":
        return IdentityResolution(
            instrument_identity=resolution.instrument_identity,
            identity_confidence=resolution.identity_confidence,
            candidates=resolution.candidates,
            blocked=True,
            block_reason="identity_confidence_not_high",
            suppressed_aliases=resolution.suppressed_aliases,
        )
    return resolution


def resolve_instrument_identity(
    ticker: str,
    raw_candidates: Iterable[dict[str, Any]] | dict[str, Any],
    *,
    expected_company_name: str | None = None,
    preferred_exchange: str | None = None,
) -> IdentityResolution:
    """Resolve the intended instrument and block ambiguous final-report cases."""

    requested = ticker.strip().upper()
    candidates = normalize_instrument_candidates(raw_candidates)
    expected_name = _canonical_company_name(expected_company_name)
    preferred_exchange_norm = _normalize_text(preferred_exchange)
    exact_matches = [candidate for candidate in candidates if candidate.symbol == requested]
    same_root_matches = [
        candidate for candidate in candidates if _ticker_root(candidate.symbol) == _ticker_root(requested)
    ]
    selected = exact_matches[0] if exact_matches else (same_root_matches[0] if same_root_matches else None)
    if selected is None:
        return IdentityResolution(
            instrument_identity=None,
            identity_confidence="none",
            candidates=candidates,
            blocked=True,
            block_reason="requested_ticker_not_found",
        )

    selected_name = _canonical_company_name(selected.company_name)
    same_root_names = {_canonical_company_name(candidate.company_name) for candidate in same_root_matches}
    conflicting_names = {
        candidate.company_name
        for candidate in same_root_matches
        if _canonical_company_name(candidate.company_name) != selected_name
    }
    suppressed_aliases = tuple(
        candidate.company_name
        for candidate in candidates
        if _ticker_root(candidate.symbol) != _ticker_root(requested)
        or (expected_name and _canonical_company_name(candidate.company_name) != expected_name)
    )

    confidence = "medium"
    block_reason = None
    if exact_matches and (not expected_name or selected_name == expected_name):
        confidence = "high"
    if preferred_exchange_norm and _normalize_text(selected.exchange) != preferred_exchange_norm:
        confidence = "medium"
        block_reason = "preferred_exchange_mismatch"
    if len(same_root_names) > 1 and conflicting_names:
        confidence = "low"
        block_reason = "same_ticker_root_conflicting_company_names"
    if expected_name and selected_name != expected_name:
        confidence = "low"
        block_reason = "expected_company_mismatch"

    identity = InstrumentIdentity(
        ticker=selected.symbol,
        company_name=selected.company_name,
        instrument_name=selected.company_name,
        exchange=selected.exchange,
        aliases=tuple(candidate.symbol for candidate in same_root_matches if candidate.symbol != selected.symbol),
        ambiguity_flags=tuple([block_reason] if block_reason else []),
    )
    return validate_identity_confidence(
        IdentityResolution(
            instrument_identity=identity,
            identity_confidence=confidence,
            candidates=candidates,
            blocked=False,
            block_reason=block_reason,
            suppressed_aliases=suppressed_aliases,
        )
    )
