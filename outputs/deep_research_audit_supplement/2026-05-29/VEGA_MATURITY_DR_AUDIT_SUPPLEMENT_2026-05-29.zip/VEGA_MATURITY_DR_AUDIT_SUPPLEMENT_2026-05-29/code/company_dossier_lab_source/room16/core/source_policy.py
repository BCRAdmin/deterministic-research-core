"""Source coverage and public-use policy for Room 16 Core v2 evidence."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from room16.core.models import EvidenceItem, SourceTier


@dataclass(frozen=True)
class SourceCoverage:
    vendor_checked: bool = False
    primary_ir_checked: bool = False
    sec_checked: bool = False
    eqs_checked: bool = False
    bundesanzeiger_checked: bool = False
    reputable_media_checked: bool = False
    market_data_checked: bool = False
    evidence_ids_by_tier: dict[str, tuple[str, ...]] = field(default_factory=dict)


@dataclass(frozen=True)
class SourceGapReport:
    public_allowed: bool
    internal_allowed: bool
    blocking_gaps: tuple[str, ...] = field(default_factory=tuple)
    warnings: tuple[str, ...] = field(default_factory=tuple)


def _tier_value(tier: SourceTier | str | None) -> str | None:
    if isinstance(tier, Enum):
        return tier.value
    return tier


def build_source_coverage(evidence_items: tuple[EvidenceItem, ...]) -> SourceCoverage:
    evidence_ids_by_tier: dict[str, list[str]] = {}
    for item in evidence_items:
        tier = _tier_value(item.source_tier)
        if not tier:
            continue
        evidence_ids_by_tier.setdefault(tier, []).append(item.evidence_id)
    frozen_by_tier = {
        tier: tuple(evidence_ids) for tier, evidence_ids in evidence_ids_by_tier.items()
    }
    return SourceCoverage(
        vendor_checked=SourceTier.VENDOR.value in frozen_by_tier,
        primary_ir_checked=SourceTier.PRIMARY_IR.value in frozen_by_tier,
        sec_checked=SourceTier.SEC.value in frozen_by_tier,
        eqs_checked=SourceTier.EQS.value in frozen_by_tier,
        bundesanzeiger_checked=SourceTier.BUNDESANZEIGER.value in frozen_by_tier,
        reputable_media_checked=SourceTier.REPUTABLE_MEDIA.value in frozen_by_tier,
        market_data_checked=SourceTier.MARKET_DATA.value in frozen_by_tier,
        evidence_ids_by_tier=frozen_by_tier,
    )


def build_source_gap_report(
    evidence_items: tuple[EvidenceItem, ...],
    *,
    hard_financial_public_claim: bool = False,
) -> SourceGapReport:
    """Evaluate whether evidence coverage can support public hard financial claims."""

    coverage = build_source_coverage(evidence_items)
    blocking_gaps: list[str] = []
    warnings: list[str] = []
    authoritative_financial_source = (
        coverage.primary_ir_checked
        or coverage.sec_checked
        or coverage.eqs_checked
        or coverage.bundesanzeiger_checked
    )
    if hard_financial_public_claim and not authoritative_financial_source:
        blocking_gaps.append("hard_financial_public_claim_requires_primary_ir_or_filing")
    if coverage.vendor_checked and not authoritative_financial_source:
        warnings.append("vendor_only_financial_evidence_internal_only")
    return SourceGapReport(
        public_allowed=not blocking_gaps,
        internal_allowed=bool(evidence_items),
        blocking_gaps=tuple(blocking_gaps),
        warnings=tuple(warnings),
    )
