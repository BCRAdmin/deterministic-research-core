"""Evidence-store helpers for Room 16 Core v2."""

from __future__ import annotations

from typing import Any, Iterable

from room16.core.models import EvidenceItem


def _evidence_id_from(raw: dict[str, Any], index: int) -> str:
    return str(raw.get("evidence_id") or raw.get("id") or f"evidence-{index + 1:04d}")


def build_evidence_store(raw_items: Iterable[EvidenceItem | dict[str, Any]]) -> tuple[EvidenceItem, ...]:
    """Build a validated immutable evidence store from raw items."""

    evidence_items: list[EvidenceItem] = []
    for index, raw_item in enumerate(raw_items):
        if isinstance(raw_item, EvidenceItem):
            evidence_items.append(raw_item)
            continue
        evidence_items.append(
            EvidenceItem(
                evidence_id=_evidence_id_from(raw_item, index),
                evidence_type=str(raw_item.get("evidence_type") or raw_item.get("type") or ""),
                title=str(raw_item.get("title") or raw_item.get("name") or ""),
                source_id=raw_item.get("source_id"),
                source_tier=raw_item.get("source_tier"),
                url=raw_item.get("url"),
                asof=raw_item.get("asof") or raw_item.get("as_of_date"),
                period_type=raw_item.get("period_type"),
                period_label=raw_item.get("period_label"),
                observed_value=raw_item.get("observed_value") or raw_item.get("value"),
                unit=raw_item.get("unit"),
                metadata=dict(raw_item.get("metadata") or {}),
            )
        )
    return tuple(evidence_items)
