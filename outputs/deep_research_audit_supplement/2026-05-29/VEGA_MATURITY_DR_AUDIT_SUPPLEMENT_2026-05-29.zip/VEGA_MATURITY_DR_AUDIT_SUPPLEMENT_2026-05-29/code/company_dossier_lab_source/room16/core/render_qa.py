"""Render-QA lifecycle gates for Room 16 public-final artifacts."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


PUBLIC_FINAL_STAGES = {"public_final"}
PUBLIC_FINAL_RENDER_MODES = {"final_public_documents"}


class RenderQABlockedError(RuntimeError):
    """Raised when visual PDF render-QA is required but unavailable."""


@dataclass(frozen=True)
class RenderQAGateResult:
    status: str
    generation_stage: str | None
    render_mode: str | None
    render_backend: str
    text_backend: str | None
    rendered_pages: tuple[str, ...] = field(default_factory=tuple)
    blockers: tuple[str, ...] = field(default_factory=tuple)
    warnings: tuple[str, ...] = field(default_factory=tuple)
    checks: tuple[dict[str, Any], ...] = field(default_factory=tuple)

    @property
    def ok(self) -> bool:
        return self.status == "pass"

    @property
    def public_ready_allowed(self) -> bool:
        return self.ok and _is_public_final(self.generation_stage, self.render_mode)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": 1,
            "status": self.status,
            "generation_stage": self.generation_stage,
            "render_mode": self.render_mode,
            "render_backend": self.render_backend,
            "text_backend": self.text_backend,
            "rendered_pages": list(self.rendered_pages),
            "rendered_page_count": len(self.rendered_pages),
            "public_ready_allowed": self.public_ready_allowed,
            "blockers": list(self.blockers),
            "warnings": list(self.warnings),
            "checks": list(self.checks),
        }


def _normalize_backend(value: str | None) -> str:
    if value is None:
        return "unavailable"
    normalized = str(value).strip().lower()
    return normalized or "unavailable"


def _is_public_final(generation_stage: str | None, render_mode: str | None) -> bool:
    return generation_stage in PUBLIC_FINAL_STAGES or render_mode in PUBLIC_FINAL_RENDER_MODES


def _check(name: str, ok: bool, details: Any) -> dict[str, Any]:
    return {"name": name, "status": "pass" if ok else "fail", "details": details}


def validate_render_backend_for_lifecycle(
    *,
    generation_stage: str | None,
    render_mode: str | None,
    render_backend: str | None,
    text_backend: str | None = None,
    rendered_pages: list[str] | tuple[str, ...] | None = None,
    fitz_available: bool | None = None,
    allow_missing_rendered_documents: bool = False,
) -> RenderQAGateResult:
    """Validate whether the PDF render backend is sufficient for the lifecycle lane.

    Public-final output requires real visual page renders from PyMuPDF/fitz. Text
    extraction backends such as pypdf are useful for QA, but they are not visual
    render-QA and therefore cannot approve public-final reports.
    """

    backend = _normalize_backend(render_backend)
    text = _normalize_backend(text_backend) if text_backend is not None else None
    pages = tuple(str(page) for page in (rendered_pages or []) if str(page).strip())
    fitz_ok = backend == "pymupdf" if fitz_available is None else bool(fitz_available)
    public_final = _is_public_final(generation_stage, render_mode)
    markdown_first_qa = (
        generation_stage == "draft_markdown_qa"
        and render_mode == "markdown_first_qa"
        and allow_missing_rendered_documents
    )
    internal_best = generation_stage == "internal_best"
    blockers: list[str] = []
    warnings: list[str] = []
    checks: list[dict[str, Any]] = []

    if markdown_first_qa:
        checks.append(
            _check(
                "markdown_first_qa_missing_visual_render_allowed",
                True,
                {
                    "allow_missing_rendered_documents": allow_missing_rendered_documents,
                    "render_backend": backend,
                },
            )
        )
        if backend != "pymupdf":
            warnings.append("visual_pdf_renderer_unavailable_for_non_public_lane")
    elif internal_best:
        checks.append(
            _check(
                "internal_best_visual_render_not_public_gate",
                True,
                {"render_backend": backend, "public_ready_allowed": False},
            )
        )
        warnings.append("internal_best_not_public_ready")
        if backend != "pymupdf":
            warnings.append("visual_pdf_renderer_unavailable_for_internal_best")
    elif not public_final:
        checks.append(
            _check(
                "non_public_final_visual_render_not_required",
                True,
                {"generation_stage": generation_stage, "render_mode": render_mode},
            )
        )

    if public_final:
        requirements = [
            ("public_final_requires_fitz", fitz_ok, fitz_available),
            ("public_final_requires_render_backend_pymupdf", backend == "pymupdf", backend),
            ("public_final_requires_rendered_pages", bool(pages), list(pages)),
        ]
        if text == "pypdf" and backend != "pymupdf":
            requirements.append(("pypdf_text_backend_is_not_visual_render_qa", False, text))
        if not allow_missing_rendered_documents:
            requirements.append(
                (
                    "public_final_rendered_documents_required",
                    True,
                    {"allow_missing_rendered_documents": allow_missing_rendered_documents},
                )
            )
        else:
            requirements.append(
                (
                    "public_final_cannot_defer_rendered_documents",
                    False,
                    {"allow_missing_rendered_documents": allow_missing_rendered_documents},
                )
            )
        for name, ok, details in requirements:
            checks.append(_check(name, ok, details))
            if not ok:
                blockers.append(name)

    status = "pass" if not blockers else "fail"
    return RenderQAGateResult(
        status=status,
        generation_stage=generation_stage,
        render_mode=render_mode,
        render_backend=backend,
        text_backend=text,
        rendered_pages=pages,
        blockers=tuple(blockers),
        warnings=tuple(warnings),
        checks=tuple(checks),
    )


def require_visual_pdf_renderer_for_public_final(**kwargs: Any) -> RenderQAGateResult:
    result = validate_render_backend_for_lifecycle(**kwargs)
    if _is_public_final(result.generation_stage, result.render_mode) and not result.ok:
        raise RenderQABlockedError("; ".join(result.blockers))
    return result
