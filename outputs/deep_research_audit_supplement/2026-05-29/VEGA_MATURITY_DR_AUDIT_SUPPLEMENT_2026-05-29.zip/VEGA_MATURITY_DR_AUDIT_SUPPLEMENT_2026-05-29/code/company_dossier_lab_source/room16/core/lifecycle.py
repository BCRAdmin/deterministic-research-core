"""Lifecycle normalization for Room 16 quality decisions."""

from __future__ import annotations

from typing import Any


FAILED_REVIEW_STATUSES = {"failed", "qa_failed", "blocked"}
PUBLIC_REVIEW_STATUS = "public_ready"


def normalize_bool(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return bool(value)
    normalized = str(value).strip().lower()
    if normalized in {"true", "1", "yes", "y"}:
        return True
    if normalized in {"false", "0", "no", "n"}:
        return False
    return None


def normalize_optional_text(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip().strip("`").strip()
    if not text or text.lower() in {"none", "null", "n/a"}:
        return None
    return text


def is_quality_failed(quality_report: dict[str, Any]) -> bool:
    metrics = quality_report.get("metrics") if isinstance(quality_report.get("metrics"), dict) else {}
    verdicts = [
        quality_report.get("quality_verdict"),
        quality_report.get("verdict"),
        metrics.get("quality_verdict"),
        metrics.get("research_integrity_verdict"),
    ]
    statuses = [
        quality_report.get("review_status"),
        metrics.get("review_status"),
    ]
    return any(str(value).strip().lower() == "fail" for value in verdicts if value is not None) or any(
        str(value).strip().lower() in FAILED_REVIEW_STATUSES for value in statuses if value is not None
    )


def lifecycle_status_from_inputs(
    *,
    quality_report: dict[str, Any],
    promotion_status: dict[str, Any] | None = None,
    artifact_consistency_report: dict[str, Any] | None = None,
) -> dict[str, Any]:
    metrics = quality_report.get("metrics") if isinstance(quality_report.get("metrics"), dict) else {}
    promotion_status = promotion_status or {}
    artifact_consistency_report = artifact_consistency_report or {}
    artifact_consistency_status = artifact_consistency_report.get("artifact_consistency_status")
    quality_failed = is_quality_failed(quality_report)

    warnings: list[str] = []
    blockers: list[str] = []
    if quality_failed:
        blockers.append("quality_verdict_failed")
        if artifact_consistency_status == "clean":
            warnings.append("artifact_consistency_pre_final_status_ignored")
        return {
            "quality_verdict": "fail",
            "review_status": "failed",
            "publishable": False,
            "public_ready": False,
            "visibility": "hidden",
            "public_rating": None,
            "blockers": blockers,
            "warnings": warnings,
        }

    if artifact_consistency_status and artifact_consistency_status != "clean":
        blockers.append("artifact_consistency_not_clean")
        return {
            "quality_verdict": "pass",
            "review_status": "blocked",
            "publishable": False,
            "public_ready": False,
            "visibility": "hidden",
            "public_rating": None,
            "blockers": blockers,
            "warnings": warnings,
        }

    public_ready = normalize_bool(promotion_status.get("public_ready")) is True
    top_public_ready = normalize_bool(quality_report.get("public_ready"))
    metrics_public_ready = normalize_bool(metrics.get("public_ready"))
    if top_public_ready is False or metrics_public_ready is False:
        public_ready = False

    internal_rating = normalize_optional_text(metrics.get("internal_rating") or quality_report.get("internal_rating"))
    public_rating = internal_rating if public_ready else None
    review_status = PUBLIC_REVIEW_STATUS if public_ready else normalize_optional_text(
        quality_report.get("review_status") or metrics.get("review_status") or "qa_pass"
    )
    visibility = "public" if public_ready else normalize_optional_text(
        quality_report.get("visibility") or metrics.get("visibility") or "internal_only"
    )
    publishable = public_ready
    return {
        "quality_verdict": "pass",
        "review_status": review_status,
        "publishable": publishable,
        "public_ready": public_ready,
        "visibility": visibility,
        "public_rating": public_rating,
        "blockers": blockers,
        "warnings": warnings,
    }
