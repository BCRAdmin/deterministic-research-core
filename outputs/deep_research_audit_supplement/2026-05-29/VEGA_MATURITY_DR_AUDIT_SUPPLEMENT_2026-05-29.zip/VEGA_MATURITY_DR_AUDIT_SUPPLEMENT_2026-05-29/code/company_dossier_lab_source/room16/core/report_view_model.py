"""ReportViewModel rendering helpers backed by QualityDecision."""

from __future__ import annotations

import re
from typing import Any

from .quality_decision import derive_quality_decision, enforce_quality_decision_in_statusbox


STATUSBOX_KEYS = (
    "review_status",
    "quality_verdict",
    "publishable",
    "public_ready",
    "visibility",
    "internal_rating",
    "public_rating",
    "failed_checks",
)


def failed_checks_from_quality_report(quality_report: dict[str, Any]) -> list[str]:
    checks = quality_report.get("checks") if isinstance(quality_report.get("checks"), list) else []
    failed = [
        str(check.get("name"))
        for check in checks
        if isinstance(check, dict) and check.get("status") == "fail" and check.get("name")
    ]
    metrics = quality_report.get("metrics") if isinstance(quality_report.get("metrics"), dict) else {}
    if metrics.get("research_integrity_verdict") == "fail" and "research_integrity_failed" not in failed:
        failed.append("research_integrity_failed")
    return failed


def build_quality_decision_for_report_view(
    quality_report: dict[str, Any],
    *,
    dashboard_status: dict[str, Any] | None = None,
    artifact_consistency_report: dict[str, Any] | None = None,
    promotion_status: dict[str, Any] | None = None,
) -> dict[str, Any]:
    decision = derive_quality_decision(
        quality_report,
        dashboard_status=dashboard_status,
        artifact_consistency_report=artifact_consistency_report,
        promotion_status=promotion_status,
    )
    decision["failed_checks"] = failed_checks_from_quality_report(quality_report)
    return decision


def report_statusbox_from_quality_decision(
    quality_decision: dict[str, Any],
    existing_report_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    statusbox = enforce_quality_decision_in_statusbox(quality_decision, existing_report_metadata)
    statusbox["internal_rating"] = quality_decision.get("internal_rating") or statusbox.get("internal_rating")
    statusbox["failed_checks"] = list(quality_decision.get("failed_checks") or [])
    return {key: statusbox.get(key) for key in STATUSBOX_KEYS}


def render_statusbox(statusbox: dict[str, Any]) -> str:
    lines = ["## Statusbox", ""]
    for key in STATUSBOX_KEYS:
        value = statusbox.get(key)
        if isinstance(value, bool):
            rendered = str(value).lower()
        elif isinstance(value, list):
            rendered = ", ".join(str(item) for item in value) if value else "[]"
        elif value is None:
            rendered = "null"
        else:
            rendered = str(value)
        lines.append(f"- {key}: `{rendered}`")
    return "\n".join(lines)


_STATUSBOX_BLOCK = re.compile(
    r"\n?## Statusbox\n(?:\s*\n)?(?:[-*]\s*[A-Za-z0-9_ -]+\s*:\s*`?[^`\n]+`?\s*\n?)+",
    re.IGNORECASE,
)
_LOOSE_STATUS_LINE = re.compile(
    r"^\s*(?:[-*]\s*)?"
    r"(?:review[_ ]status|quality[_ ]verdict|publishable|public[_ ]ready|visibility|public[_ ]rating)"
    r"\s*:\s*`?[^`\n]+`?\s*$",
    re.IGNORECASE | re.MULTILINE,
)


def remove_existing_statusbox(markdown: str) -> str:
    without_statusbox = _STATUSBOX_BLOCK.sub("\n", markdown)
    return _LOOSE_STATUS_LINE.sub("", without_statusbox).strip()


def render_internal_best_report(
    quality_decision: dict[str, Any],
    *,
    existing_markdown: str = "",
    title: str = "Room 16 Internal Best Report",
    metadata: dict[str, Any] | None = None,
) -> str:
    statusbox = report_statusbox_from_quality_decision(quality_decision, metadata)
    body = remove_existing_statusbox(existing_markdown)
    parts = [f"# {title}", "", render_statusbox(statusbox)]
    if body:
        parts.extend(["", body])
    return "\n".join(parts).strip() + "\n"


def render_evidence_report(
    quality_decision: dict[str, Any],
    *,
    existing_markdown: str = "",
    title: str = "Room 16 Evidence Report",
    metadata: dict[str, Any] | None = None,
) -> str:
    statusbox = report_statusbox_from_quality_decision(quality_decision, metadata)
    body = remove_existing_statusbox(existing_markdown)
    parts = [f"# {title}", "", render_statusbox(statusbox)]
    if body:
        parts.extend(["", body])
    return "\n".join(parts).strip() + "\n"


def public_report_link_allowed(quality_decision: dict[str, Any]) -> bool:
    return quality_decision.get("public_ready") is True and quality_decision.get("publishable") is True
