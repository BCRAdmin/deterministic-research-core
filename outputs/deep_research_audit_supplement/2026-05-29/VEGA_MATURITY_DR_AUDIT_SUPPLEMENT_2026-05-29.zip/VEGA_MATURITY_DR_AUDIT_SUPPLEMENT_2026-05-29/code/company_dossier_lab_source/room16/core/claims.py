"""Claim graph helpers for Room 16 Core v2."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable

from room16.core.models import Claim, EvidenceItem, InstrumentIdentity, MetricDefinition


@dataclass(frozen=True)
class ClaimGraph:
    """Minimal immutable graph tying claims to evidence and metric definitions."""

    claims: tuple[Claim, ...]
    evidence_items: tuple[EvidenceItem, ...] = field(default_factory=tuple)
    metric_definitions: tuple[MetricDefinition, ...] = field(default_factory=tuple)
    instrument_identity: InstrumentIdentity | None = None

    @property
    def evidence_by_id(self) -> dict[str, EvidenceItem]:
        return {item.evidence_id: item for item in self.evidence_items}

    @property
    def metric_definition_by_id(self) -> dict[str, MetricDefinition]:
        return {item.metric_id: item for item in self.metric_definitions}


def _claim_id_from(raw: dict[str, Any], index: int) -> str:
    return str(raw.get("claim_id") or raw.get("id") or f"claim-{index + 1:04d}")


def claim_from_dict(raw: dict[str, Any], index: int = 0) -> Claim:
    """Build a canonical Claim from loose report/agent output."""

    return Claim(
        claim_id=_claim_id_from(raw, index),
        statement=str(raw.get("statement") or raw.get("text") or raw.get("claim") or ""),
        claim_type=str(raw.get("claim_type") or raw.get("type") or "unknown"),
        evidence_ids=tuple(str(item) for item in raw.get("evidence_ids") or ()),
        metric_ids=tuple(str(item) for item in raw.get("metric_ids") or ()),
        validation_status=str(raw.get("validation_status") or "candidate"),
        risk_flags=tuple(str(item) for item in raw.get("risk_flags") or ()),
    )


def build_claim_graph(
    claims: Iterable[Claim | dict[str, Any]],
    *,
    evidence_items: Iterable[EvidenceItem] = (),
    metric_definitions: Iterable[MetricDefinition] = (),
    instrument_identity: InstrumentIdentity | None = None,
) -> ClaimGraph:
    """Build a small claim graph without reaching into renderer or pipeline code."""

    normalized_claims: list[Claim] = []
    for index, claim in enumerate(claims):
        normalized_claims.append(claim if isinstance(claim, Claim) else claim_from_dict(claim, index))
    return ClaimGraph(
        claims=tuple(normalized_claims),
        evidence_items=tuple(evidence_items),
        metric_definitions=tuple(metric_definitions),
        instrument_identity=instrument_identity,
    )
