"""Canonical metric definitions used by Room 16 claim validation."""

from __future__ import annotations

from room16.core.models import MetricDefinition, PeriodType, SourceTier


FREE_CASH_FLOW_FORMULA_ID = "free_cash_flow.v1"
OPERATING_CASH_FLOW_METRIC_ID = "operating_cash_flow"
CAPEX_METRIC_ID = "capital_expenditures"


FREE_CASH_FLOW = MetricDefinition(
    metric_id="free_cash_flow",
    name="Free Cash Flow",
    formula="operating_cash_flow - capital_expenditures",
    required_evidence_tiers=(SourceTier.PRIMARY_IR, SourceTier.SEC, SourceTier.EQS, SourceTier.BUNDESANZEIGER),
    valid_period_types=(PeriodType.QUARTER, PeriodType.TTM, PeriodType.FISCAL_YEAR, PeriodType.CALENDAR_YEAR),
    unit="currency",
)

OPERATING_CASH_FLOW = MetricDefinition(
    metric_id=OPERATING_CASH_FLOW_METRIC_ID,
    name="Operating Cash Flow",
    required_evidence_tiers=(SourceTier.PRIMARY_IR, SourceTier.SEC, SourceTier.EQS, SourceTier.BUNDESANZEIGER),
    valid_period_types=(PeriodType.QUARTER, PeriodType.TTM, PeriodType.FISCAL_YEAR, PeriodType.CALENDAR_YEAR),
    unit="currency",
)

CAPITAL_EXPENDITURES = MetricDefinition(
    metric_id=CAPEX_METRIC_ID,
    name="Capital Expenditures",
    required_evidence_tiers=(SourceTier.PRIMARY_IR, SourceTier.SEC, SourceTier.EQS, SourceTier.BUNDESANZEIGER),
    valid_period_types=(PeriodType.QUARTER, PeriodType.TTM, PeriodType.FISCAL_YEAR, PeriodType.CALENDAR_YEAR),
    unit="currency",
)


DEFAULT_METRIC_DEFINITIONS: tuple[MetricDefinition, ...] = (
    FREE_CASH_FLOW,
    OPERATING_CASH_FLOW,
    CAPITAL_EXPENDITURES,
)


def metric_definition_by_id(
    metric_id: str,
    definitions: tuple[MetricDefinition, ...] = DEFAULT_METRIC_DEFINITIONS,
) -> MetricDefinition | None:
    """Return a canonical metric definition by id."""

    normalized = metric_id.strip().lower()
    for definition in definitions:
        if definition.metric_id.lower() == normalized:
            return definition
    return None


def is_fcf_metric_id(metric_id: str) -> bool:
    """Return whether a metric id refers to a free-cash-flow metric."""

    normalized = metric_id.strip().lower().replace("-", "_")
    return normalized in {"fcf", "free_cash_flow", FREE_CASH_FLOW_FORMULA_ID}


def required_fcf_component_ids() -> tuple[str, str]:
    """Return required component metric ids for an FCF claim."""

    return (OPERATING_CASH_FLOW_METRIC_ID, CAPEX_METRIC_ID)
