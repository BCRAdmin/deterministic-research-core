"""Room 16 core helpers."""
