"""Dataclasses for Room 16 Core v2 canonical truth artifacts.

These models are intentionally small and dependency-free so the pipeline,
renderers, and tests can share one status vocabulary before deeper orchestration
changes land.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any


class StrEnum(str, Enum):
    """String enum base that serializes naturally to JSON-compatible values."""

    def __str__(self) -> str:
        return self.value


class QualityVerdict(StrEnum):
    PASS = "pass"
    FAIL = "fail"


class ReviewStatus(StrEnum):
    QA_PASS = "qa_pass"
    QA_FAILED = "qa_failed"
    MANUAL_REVIEW = "manual_review"
    INTERNAL_READY = "internal_ready"
    PUBLIC_READY = "public_ready"
    BLOCKED = "blocked"
    FAILED = "failed"


class Visibility(StrEnum):
    INTERNAL_ONLY = "internal_only"
    HIDDEN = "hidden"
    PUBLIC_CANDIDATE = "public_candidate"
    PUBLIC = "public"
    REJECTED = "rejected"
    DEBUG_ONLY = "debug_only"


class SourceTier(StrEnum):
    PRIMARY_IR = "primary_ir"
    SEC = "sec"
    BUNDESANZEIGER = "bundesanzeiger"
    EQS = "eqs"
    MARKET_DATA = "market_data"
    REPUTABLE_MEDIA = "reputable_media"
    ANALYST = "analyst"
    VENDOR = "vendor"
    SOCIAL = "social"
    DERIVED = "derived"
    MANUAL = "manual"


class PeriodType(StrEnum):
    QUARTER = "quarter"
    TTM = "ttm"
    FISCAL_YEAR = "fiscal_year"
    CALENDAR_YEAR = "calendar_year"
    FORWARD = "forward"
    POINT_IN_TIME = "point_in_time"


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _enum_value(value: Any) -> Any:
    if isinstance(value, Enum):
        return value.value
    return value


@dataclass(frozen=True)
class InstrumentIdentity:
    ticker: str
    company_name: str
    instrument_name: str | None = None
    exchange: str | None = None
    isin: str | None = None
    cik: str | None = None
    lei: str | None = None
    country: str | None = None
    currency: str | None = None
    aliases: tuple[str, ...] = field(default_factory=tuple)
    ambiguity_flags: tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        if not self.ticker.strip():
            raise ValueError("InstrumentIdentity.ticker is required")
        if not self.company_name.strip():
            raise ValueError("InstrumentIdentity.company_name is required")


@dataclass(frozen=True)
class EvidenceItem:
    evidence_id: str
    evidence_type: str
    title: str
    source_id: str | None = None
    source_tier: SourceTier | str | None = None
    url: str | None = None
    asof: str | None = None
    period_type: PeriodType | str | None = None
    period_label: str | None = None
    observed_value: str | float | int | None = None
    unit: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.evidence_id.strip():
            raise ValueError("EvidenceItem.evidence_id is required")
        if self.evidence_type == "financial_metric":
            missing = [
                name
                for name, value in (
                    ("source_id", self.source_id),
                    ("asof", self.asof),
                    ("period_type", self.period_type),
                    ("source_tier", self.source_tier),
                )
                if value in (None, "")
            ]
            if missing:
                raise ValueError(
                    "financial_metric EvidenceItem requires "
                    + ", ".join(missing)
                )


@dataclass(frozen=True)
class Claim:
    claim_id: str
    statement: str
    claim_type: str
    evidence_ids: tuple[str, ...] = field(default_factory=tuple)
    metric_ids: tuple[str, ...] = field(default_factory=tuple)
    validation_status: str = "candidate"
    risk_flags: tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        if not self.claim_id.strip():
            raise ValueError("Claim.claim_id is required")
        if not self.statement.strip():
            raise ValueError("Claim.statement is required")


@dataclass(frozen=True)
class MetricDefinition:
    metric_id: str
    name: str
    formula: str | None = None
    description: str | None = None
    required_evidence_tiers: tuple[SourceTier | str, ...] = field(default_factory=tuple)
    valid_period_types: tuple[PeriodType | str, ...] = field(default_factory=tuple)
    unit: str | None = None

    def __post_init__(self) -> None:
        if not self.metric_id.strip():
            raise ValueError("MetricDefinition.metric_id is required")
        if not self.name.strip():
            raise ValueError("MetricDefinition.name is required")


@dataclass(frozen=True)
class QualityFinding:
    finding_id: str
    severity: str
    code: str
    message: str
    evidence_ids: tuple[str, ...] = field(default_factory=tuple)
    claim_ids: tuple[str, ...] = field(default_factory=tuple)
    blocking: bool = False

    def __post_init__(self) -> None:
        if not self.finding_id.strip():
            raise ValueError("QualityFinding.finding_id is required")
        if not self.code.strip():
            raise ValueError("QualityFinding.code is required")


@dataclass(frozen=True)
class QualityDecision:
    run_id: str
    ticker: str
    quality_verdict: QualityVerdict | str
    review_status: ReviewStatus | str
    publishable: bool
    public_ready: bool
    visibility: Visibility | str
    internal_rating: str | None
    public_rating: str | None
    score_scope: str
    failed_checks: tuple[str, ...] = field(default_factory=tuple)
    high_findings: tuple[QualityFinding | str, ...] = field(default_factory=tuple)
    blocking_issues: tuple[str, ...] = field(default_factory=tuple)
    created_at: str = field(default_factory=_utc_now_iso)

    def __post_init__(self) -> None:
        if not self.run_id.strip():
            raise ValueError("QualityDecision.run_id is required")
        if not self.ticker.strip():
            raise ValueError("QualityDecision.ticker is required")
        verdict = _enum_value(self.quality_verdict)
        review_status = _enum_value(self.review_status)
        visibility = _enum_value(self.visibility)
        if verdict not in {item.value for item in QualityVerdict}:
            raise ValueError(f"unsupported QualityVerdict: {verdict}")
        if review_status not in {item.value for item in ReviewStatus}:
            raise ValueError(f"unsupported ReviewStatus: {review_status}")
        if visibility not in {item.value for item in Visibility}:
            raise ValueError(f"unsupported Visibility: {visibility}")
        if not self.publishable and self.public_rating is not None:
            raise ValueError("public_rating requires publishable=true")
        if self.public_ready and not self.publishable:
            raise ValueError("public_ready requires publishable=true")
        if self.public_ready and visibility != Visibility.PUBLIC.value:
            raise ValueError("public_ready requires visibility=public")
        if visibility == Visibility.PUBLIC.value and not self.public_ready:
            raise ValueError("visibility=public requires public_ready=true")


@dataclass(frozen=True)
class ArtifactManifest:
    run_id: str
    artifacts: dict[str, str] = field(default_factory=dict)
    generated_at: str = field(default_factory=_utc_now_iso)
    consistency_status: str = "unknown"
    missing_artifacts: tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        if not self.run_id.strip():
            raise ValueError("ArtifactManifest.run_id is required")


@dataclass(frozen=True)
class PromotionDecision:
    run_id: str
    ticker: str
    promotion_status: str
    public_ready: bool
    requested_visibility: Visibility | str
    non_advice_confirmed: bool = False
    sources_human_verified: bool = False
    reviewed_by: str | None = None
    approved_at: str | None = None
    reasons: tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        visibility = _enum_value(self.requested_visibility)
        if visibility not in {item.value for item in Visibility}:
            raise ValueError(f"unsupported requested_visibility: {visibility}")
        if self.public_ready and visibility != Visibility.PUBLIC.value:
            raise ValueError("promotion public_ready requires requested_visibility=public")
        if self.public_ready and not self.non_advice_confirmed:
            raise ValueError("promotion public_ready requires non_advice_confirmed=true")
        if self.public_ready and not self.sources_human_verified:
            raise ValueError("promotion public_ready requires sources_human_verified=true")


@dataclass(frozen=True)
class ReportViewModel:
    run_id: str
    ticker: str
    title: str
    quality_decision: QualityDecision
    sections: tuple[dict[str, Any], ...] = field(default_factory=tuple)
    artifact_manifest: ArtifactManifest | None = None
    promotion_decision: PromotionDecision | None = None
    disclaimers: tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        if self.run_id != self.quality_decision.run_id:
            raise ValueError("ReportViewModel.run_id must match QualityDecision.run_id")
        if self.ticker != self.quality_decision.ticker:
            raise ValueError("ReportViewModel.ticker must match QualityDecision.ticker")
