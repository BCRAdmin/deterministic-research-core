"""Compatibility helpers for models that emit tool calls as JSON text."""

from __future__ import annotations

import json
from uuid import uuid4
from typing import Any, Iterable

from langchain_core.messages import AIMessage


def coerce_json_tool_calls(message: Any, tools: Iterable[Any]) -> Any:
    """Convert simple JSON-text tool calls into LangChain ``tool_calls``.

    Some OpenAI-compatible local models return content such as
    ``{"name": "get_news", "arguments": {...}}`` instead of populating the
    native ``AIMessage.tool_calls`` field. LangGraph's ToolNode only sees the
    native field, so this adapter keeps the normal graph path usable.
    """
    if getattr(message, "tool_calls", None):
        return message

    tool_names = {tool.name for tool in tools}
    calls = _extract_calls(getattr(message, "content", ""), tool_names)
    if not calls:
        return message

    return AIMessage(
        content="",
        additional_kwargs=getattr(message, "additional_kwargs", {}),
        response_metadata=getattr(message, "response_metadata", {}),
        id=getattr(message, "id", None),
        tool_calls=calls,
    )


def _extract_calls(content: Any, tool_names: set[str]) -> list[dict[str, Any]]:
    if isinstance(content, list):
        content = "\n".join(
            item.get("text", "") if isinstance(item, dict) else str(item)
            for item in content
        )
    if not isinstance(content, str):
        return []

    text = content.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if len(lines) >= 2:
            text = "\n".join(lines[1:-1]).strip()

    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return []

    raw_calls: list[Any]
    if isinstance(payload, dict) and isinstance(payload.get("tool_calls"), list):
        raw_calls = payload["tool_calls"]
    elif isinstance(payload, list):
        raw_calls = payload
    else:
        raw_calls = [payload]

    calls: list[dict[str, Any]] = []
    for index, raw_call in enumerate(raw_calls):
        if not isinstance(raw_call, dict):
            continue
        name = raw_call.get("name") or raw_call.get("tool") or raw_call.get("function")
        if isinstance(name, dict):
            name = name.get("name")
        if name not in tool_names:
            continue

        args = (
            raw_call.get("args")
            or raw_call.get("arguments")
            or raw_call.get("parameters")
            or {}
        )
        if isinstance(args, str):
            try:
                args = json.loads(args)
            except json.JSONDecodeError:
                continue
        if not isinstance(args, dict):
            continue

        calls.append(
            {
                "name": name,
                "args": args,
                "id": raw_call.get("id") or f"compat_{index}_{uuid4().hex[:8]}",
                "type": "tool_call",
            }
        )
    return calls
