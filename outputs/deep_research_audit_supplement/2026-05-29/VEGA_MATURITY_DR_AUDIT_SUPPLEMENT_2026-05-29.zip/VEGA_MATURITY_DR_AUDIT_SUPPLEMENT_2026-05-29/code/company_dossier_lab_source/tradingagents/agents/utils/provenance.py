"""Small provenance helpers for Room 16 research tools."""

from __future__ import annotations

import re
from typing import Any

from tradingagents.dataflows.interface import get_category_for_method, get_vendor


def _safe_id(value: Any) -> str:
    text = str(value or "unknown").strip().lower()
    text = re.sub(r"[^a-z0-9._:-]+", "-", text)
    return text.strip("-") or "unknown"


def configured_vendor(method: str) -> str:
    """Return the configured vendor label for a tool method."""
    try:
        return get_vendor(get_category_for_method(method), method)
    except Exception:
        return "unknown"


def prepend_tool_provenance(
    text: str,
    *,
    method: str,
    symbol: str,
    asof: str | None,
    period_type: str,
    formula_id: str | None = None,
) -> str:
    """Prefix a tool result with compact source metadata for downstream QA.

    The header is intentionally plain text so all model providers can copy it
    into their evidence ledger without needing hidden runtime state.
    """
    vendor = configured_vendor(method)
    source_id = f"{_safe_id(method)}:{_safe_id(symbol)}:{_safe_id(asof)}:{_safe_id(vendor)}"
    header = "\n".join(
        [
            "[Room16 Source Metadata]",
            f"source_id: {source_id}",
            f"source_type: vendor:{vendor}",
            f"asof: {asof or 'unknown'}",
            f"period_type: {period_type}",
            f"formula_id: {formula_id or 'n/a'}",
            "source_priority: SEC/IR > transcript > vendor > social; this tool output is vendor-level unless the source text states otherwise.",
            "[/Room16 Source Metadata]",
        ]
    )
    return f"{header}\n{text}"
