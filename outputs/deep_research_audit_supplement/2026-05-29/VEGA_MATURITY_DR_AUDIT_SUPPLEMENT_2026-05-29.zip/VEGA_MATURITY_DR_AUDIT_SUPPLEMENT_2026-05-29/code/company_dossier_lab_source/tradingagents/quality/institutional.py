"""Deterministic institutional QA primitives for Room 16.

The LLM agents can draft research prose. This module owns the mechanical
checks that must not be left to prose: period labels, source tiers, FCF/TTM
math, stop direction, news causality, rating/action consistency, and the
regression cases from the AMZN/NVDA/DDOG/MDB report review pack.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, datetime
from enum import Enum
from math import isclose
from typing import Any, Literal


class SourceTier(str, Enum):
    PRIMARY_IR = "primary_ir"
    SEC = "sec"
    TRANSCRIPT = "transcript"
    MARKET_DATA = "market_data"
    REPUTABLE_MEDIA = "reputable_media"
    ANALYST = "analyst"
    VENDOR = "vendor"
    SOCIAL = "social"
    DERIVED = "derived"


class PeriodType(str, Enum):
    QUARTER = "quarter"
    TTM = "ttm"
    FISCAL_YEAR = "fiscal_year"
    CALENDAR_YEAR = "calendar_year"
    FORWARD = "forward"
    POINT_IN_TIME = "point_in_time"


class AccountingBasis(str, Enum):
    GAAP = "GAAP"
    NON_GAAP = "non-GAAP"
    COMPANY_DEFINED = "company-defined"
    ADJUSTED = "adjusted"
    MARKET = "market"
    TECHNICAL = "technical"


class InstitutionalRating(str, Enum):
    STRONG_BUY = "Strong Buy"
    BUY = "Buy"
    ACCUMULATE = "Accumulate"
    HOLD = "Hold"
    TACTICAL_TRIM = "Tactical Trim"
    TACTICAL_UNDERWEIGHT = "Tactical Underweight"
    UNDERWEIGHT = "Underweight"
    SELL = "Sell"
    AVOID = "Avoid"


class CompanyArchetype(str, Enum):
    MEGA_CAP_PLATFORM = "MEGA_CAP_PLATFORM"
    SAAS_CONSUMPTION = "SAAS_CONSUMPTION"
    SEMICONDUCTOR_AI_INFRA = "SEMICONDUCTOR_AI_INFRA"
    SPECULATIVE_DEEP_TECH_EARLY_COMMERCIAL = "SPECULATIVE_DEEP_TECH_EARLY_COMMERCIAL"
    STANDARD_GROWTH = "STANDARD_GROWTH"
    UNKNOWN = "UNKNOWN"


SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE = "SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE"
MANUAL_REVIEW_DISPLAY_RATING = "Manual Review / Preliminary Underweight"
MANUAL_REVIEW_EVIDENCE_INCOMPLETE_DISPLAY_RATING = "Manual Review / Hold Pending Primary Evidence"
EVIDENCE_INCOMPLETE_FOR_GOLD = "EVIDENCE_INCOMPLETE_FOR_GOLD"


@dataclass(frozen=True)
class Source:
    source_id: str
    name: str
    tier: SourceTier
    accessed_at: datetime
    url: str | None = None
    publication_date: date | None = None


@dataclass(frozen=True)
class Metric:
    name: str
    value: float | str
    period_type: PeriodType
    accounting_basis: AccountingBasis
    source_id: str
    unit: str | None = None
    period_end: date | None = None
    formula: str | None = None


@dataclass(frozen=True)
class DataPacket:
    ticker: str
    company_name: str
    exchange: str
    currency: str
    as_of_date: date
    last_close: float
    last_close_date: date
    timezone: str
    sources: list[Source]
    metrics: list[Metric]
    fiscal_year_label: str | None = None
    fiscal_year_end: date | None = None
    next_earnings_date: date | None = None
    latest_filing_period: str | None = None
    indicators_calculated_through: date | None = None
    intraday_included: bool = False
    post_close_data_checked: bool = False


@dataclass(frozen=True)
class Claim:
    claim_id: str
    agent: str
    claim: str
    evidence_metric_ids: list[str]
    source_ids: list[str]
    confidence: Literal["low", "medium", "high"]
    source_tier: SourceTier
    counterargument: str | None = None
    investment_implication: str | None = None
    requires_validation: bool = True


@dataclass(frozen=True)
class RatingDecision:
    rating: InstitutionalRating
    action: str
    time_horizon: str
    position_sizing: str
    entry_rules: list[str]
    exit_rules: list[str]
    invalidation_rules: list[str]
    validated_claim_ids: list[str]


@dataclass(frozen=True)
class ReportIssue:
    code: str
    severity: Literal["blocker", "warning"]
    message: str
    details: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class QAResult:
    issues: list[ReportIssue]

    @property
    def blocked(self) -> bool:
        return any(issue.severity == "blocker" for issue in self.issues)

    def blocker_codes(self) -> list[str]:
        return [issue.code for issue in self.issues if issue.severity == "blocker"]


@dataclass(frozen=True)
class SpeculativeDeepTechAssessment:
    profile: str
    company_archetype: CompanyArchetype
    archetype_confidence: float
    archetype_triggered_rules: list[str]
    active: bool
    trigger_count: int
    triggers: dict[str, bool]
    issues: list[ReportIssue]
    status: str
    publishable: bool
    external_display_rating: str | None
    quality_score: int
    quality_score_caps: dict[str, int]
    counts: dict[str, int]

    def to_dict(self) -> dict[str, Any]:
        return {
            "profile": self.profile,
            "company_archetype": self.company_archetype.value,
            "archetype_confidence": self.archetype_confidence,
            "archetype_triggered_rules": self.archetype_triggered_rules,
            "active": self.active,
            "trigger_count": self.trigger_count,
            "triggers": self.triggers,
            "issues": [issue.__dict__ for issue in self.issues],
            "status": self.status,
            "publishable": self.publishable,
            "external_display_rating": self.external_display_rating,
            "quality_score": self.quality_score,
            "quality_score_caps": self.quality_score_caps,
            "counts": self.counts,
        }


def calculate_ttm(quarterly_values: list[float]) -> float:
    if len(quarterly_values) != 4:
        raise ValueError("TTM calculation requires exactly four quarterly values")
    return sum(quarterly_values)


def validate_ttm_sum(
    quarterly_values: list[float],
    reported_ttm: float,
    *,
    tolerance: float = 0.02,
) -> QAResult:
    calculated = calculate_ttm(quarterly_values)
    denominator = max(abs(reported_ttm), 1.0)
    relative_delta = abs(calculated - reported_ttm) / denominator
    if relative_delta > tolerance:
        return QAResult(
            [
                ReportIssue(
                    code="ttm_mismatch",
                    severity="blocker",
                    message="Reported TTM does not match the sum of four quarters.",
                    details={
                        "calculated": calculated,
                        "reported_ttm": reported_ttm,
                        "relative_delta": relative_delta,
                        "tolerance": tolerance,
                    },
                )
            ]
        )
    return QAResult([])


def calculate_fcf(
    operating_cash_flow: float,
    capex: float,
    *,
    finance_lease_principal: float = 0.0,
    company_defined_adjustments: float = 0.0,
) -> dict[str, Any]:
    value = operating_cash_flow - capex - finance_lease_principal + company_defined_adjustments
    formula_parts = ["Operating Cash Flow", "- CapEx"]
    if finance_lease_principal:
        formula_parts.append("- Principal Payments of Finance Leases")
    if company_defined_adjustments:
        formula_parts.append("+ company-defined adjustments")
    return {
        "value": value,
        "formula": " ".join(formula_parts),
        "company_definition_used": bool(finance_lease_principal or company_defined_adjustments),
    }


def calculate_sbc_ratios(
    *,
    sbc: float,
    revenue: float | None,
    fcf: float | None,
    non_gaap_operating_income: float | None,
) -> dict[str, float | None]:
    return {
        "sbc_to_revenue": _safe_ratio(sbc, revenue),
        "sbc_to_fcf": _safe_ratio(sbc, fcf),
        "sbc_to_non_gaap_operating_income": _safe_ratio(sbc, non_gaap_operating_income),
    }


def calculate_net_cash(
    *,
    cash_and_equivalents: float,
    debt: float,
    marketable_securities: float = 0.0,
) -> dict[str, Any]:
    return {
        "value": cash_and_equivalents + marketable_securities - debt,
        "formula": "Cash and Equivalents + Marketable Securities - Debt",
        "marketable_securities_included": True,
    }


def validate_data_packet(packet: DataPacket) -> QAResult:
    issues: list[ReportIssue] = []
    if not packet.ticker or not packet.exchange or not packet.currency:
        issues.append(ReportIssue("data_stamp_missing_identity", "blocker", "Ticker, exchange, and currency are required."))
    if packet.last_close <= 0:
        issues.append(ReportIssue("last_close_invalid", "blocker", "Last close must be positive."))
    if packet.indicators_calculated_through and packet.indicators_calculated_through != packet.last_close_date:
        issues.append(
            ReportIssue(
                "indicator_price_date_mismatch",
                "blocker",
                "Indicators must be calculated through the same date as the official close.",
                {
                    "last_close_date": packet.last_close_date.isoformat(),
                    "indicators_calculated_through": packet.indicators_calculated_through.isoformat(),
                },
            )
        )
    if packet.intraday_included:
        issues.append(ReportIssue("intraday_mixed_into_report", "blocker", "Room 16 data packet must not mix intraday data into the official close basis."))
    issues.extend(
        validate_price_basis(
            as_of_date=packet.as_of_date,
            last_close_date=packet.last_close_date,
            indicators_calculated_through=packet.indicators_calculated_through,
            post_close_data_checked=packet.post_close_data_checked,
        ).issues
    )
    source_ids = {source.source_id for source in packet.sources}
    for metric in packet.metrics:
        if metric.source_id not in source_ids:
            issues.append(
                ReportIssue(
                    "metric_source_missing",
                    "blocker",
                    "Every metric must reference a known source_id.",
                    {"metric": metric.name, "source_id": metric.source_id},
                )
            )
        if metric.period_type != PeriodType.POINT_IN_TIME and metric.period_end is None:
            issues.append(
                ReportIssue(
                    "metric_period_end_missing",
                    "blocker",
                    "Period-sensitive metrics need period_end.",
                    {"metric": metric.name, "period_type": metric.period_type.value},
                )
            )
    return QAResult(issues)


def validate_price_basis(
    *,
    as_of_date: date,
    last_close_date: date,
    indicators_calculated_through: date | None,
    post_close_data_checked: bool,
) -> QAResult:
    issues: list[ReportIssue] = []
    if indicators_calculated_through and indicators_calculated_through != last_close_date:
        issues.append(
            ReportIssue(
                "indicator_price_date_mismatch",
                "blocker",
                "Technical indicators and official close basis must use the same date.",
                {
                    "last_close_date": last_close_date.isoformat(),
                    "indicators_calculated_through": indicators_calculated_through.isoformat(),
                },
            )
        )
    if as_of_date > last_close_date and not post_close_data_checked:
        issues.append(
            ReportIssue(
                "price_basis_post_close_unchecked",
                "warning",
                "Report date is after the official close date; explicitly state whether later close/intraday data was checked or excluded.",
                {
                    "as_of_date": as_of_date.isoformat(),
                    "last_close_date": last_close_date.isoformat(),
                },
            )
        )
    return QAResult(issues)


def validate_stop_loss(
    *,
    position_type: Literal["long", "short"],
    current_price: float,
    stop_loss: float | None = None,
    profit_target: float | None = None,
    breakout_level: float | None = None,
) -> QAResult:
    issues: list[ReportIssue] = []
    if position_type == "long":
        if stop_loss is not None and stop_loss >= current_price:
            issues.append(ReportIssue("invalid_long_stop_loss", "blocker", "Long stop-loss must be below current price.", {"current_price": current_price, "stop_loss": stop_loss}))
        if profit_target is not None and profit_target <= current_price:
            issues.append(ReportIssue("invalid_long_profit_target", "blocker", "Long profit target must be above current price.", {"current_price": current_price, "profit_target": profit_target}))
        if breakout_level is not None and breakout_level <= current_price:
            issues.append(ReportIssue("invalid_long_breakout_level", "warning", "Long breakout level is usually above current price.", {"current_price": current_price, "breakout_level": breakout_level}))
    if position_type == "short":
        if stop_loss is not None and stop_loss <= current_price:
            issues.append(ReportIssue("invalid_short_stop_loss", "blocker", "Short stop-loss must be above current price.", {"current_price": current_price, "stop_loss": stop_loss}))
        if profit_target is not None and profit_target >= current_price:
            issues.append(ReportIssue("invalid_short_profit_target", "blocker", "Short profit target must be below current price.", {"current_price": current_price, "profit_target": profit_target}))
    return QAResult(issues)


def validate_news_causality(
    *,
    news_date: date,
    price_move_date: date,
    causality_claimed: bool,
    same_day_reaction_checked: bool = False,
    alternative_explanations_checked: bool = False,
) -> QAResult:
    if not causality_claimed:
        return QAResult([])
    if news_date != price_move_date or not same_day_reaction_checked or not alternative_explanations_checked:
        return QAResult(
            [
                ReportIssue(
                    "news_causality_not_verified",
                    "warning",
                    "Causal news/price language requires same-day reaction and alternative-explanation checks.",
                    {
                        "news_date": news_date.isoformat(),
                        "price_move_date": price_move_date.isoformat(),
                        "same_day_reaction_checked": same_day_reaction_checked,
                        "alternative_explanations_checked": alternative_explanations_checked,
                    },
                )
            ]
        )
    return QAResult([])


def validate_rating_action(rating: InstitutionalRating | str, action_text: str) -> QAResult:
    normalized_rating = rating.value if isinstance(rating, InstitutionalRating) else str(rating)
    lower = action_text.lower()
    issues: list[ReportIssue] = []
    if normalized_rating == InstitutionalRating.SELL.value and any(term in lower for term in ["hold core", "kern halten", "trim", "reduce 20", "reduce 30", "20%", "30%"]):
        issues.append(ReportIssue("rating_action_sell_vs_trim", "blocker", "Action is trim/hold-core, not Sell.", {"rating": normalized_rating, "action": action_text}))
    if normalized_rating == InstitutionalRating.UNDERWEIGHT.value and any(term in lower for term in ["hold core", "kern halten", "re-entry", "wieder aufstock", "reduce 20", "reduce 30", "20%", "30%"]):
        issues.append(
            ReportIssue(
                "rating_action_underweight_should_be_tactical",
                "warning",
                "Core-hold/partial-trim/re-entry language should use Tactical Underweight or Tactical Trim, not broad Underweight.",
                {"rating": normalized_rating, "action": action_text},
            )
        )
    if normalized_rating == InstitutionalRating.BUY.value and any(term in lower for term in ["wait", "abwarten", "only on pullback", "nur bei rücksetzer", "after confirmation", "nach bestätigung"]):
        issues.append(ReportIssue("rating_action_buy_vs_accumulate", "warning", "Conditional entry should usually be Accumulate, not Buy.", {"rating": normalized_rating, "action": action_text}))
    return QAResult(issues)


def validate_no_news_fallback(news_results: list[Any], fallback_sources_checked: list[str] | None) -> QAResult:
    if not news_results and not fallback_sources_checked:
        return QAResult([ReportIssue("no_news_without_fallback", "blocker", "No-news claim requires IR/SEC/media/vendor fallback checklist.")])
    return QAResult([])


def validate_scenario_probabilities(probabilities: list[float], *, qualitative: bool = False) -> QAResult:
    if qualitative:
        return QAResult([])
    total = sum(probabilities)
    if not isclose(total, 100.0, abs_tol=0.5):
        return QAResult([ReportIssue("scenario_probabilities_not_100", "warning", "Scenario probabilities must sum to 100% or be marked qualitative.", {"total": total})])
    return QAResult([])


def validate_company_defined_fcf(
    *,
    operating_cash_flow: float,
    capex: float,
    reported_fcf: float,
    finance_lease_principal: float = 0.0,
    company_definition_checked: bool,
    tolerance: float = 0.005,
) -> QAResult:
    if not company_definition_checked:
        return QAResult(
            [
                ReportIssue(
                    "fcf_company_definition_unchecked",
                    "blocker",
                    "FCF must check the company definition before using a custom formula.",
                )
            ]
        )
    calculated = calculate_fcf(
        operating_cash_flow,
        capex,
        finance_lease_principal=finance_lease_principal,
    )["value"]
    denominator = max(abs(reported_fcf), 1.0)
    relative_delta = abs(calculated - reported_fcf) / denominator
    if relative_delta > tolerance:
        return QAResult(
            [
                ReportIssue(
                    "company_fcf_definition_mismatch",
                    "blocker",
                    "Reported FCF does not match the company-defined FCF formula.",
                    {
                        "calculated": calculated,
                        "reported_fcf": reported_fcf,
                        "operating_cash_flow": operating_cash_flow,
                        "capex": capex,
                        "finance_lease_principal": finance_lease_principal,
                        "relative_delta": relative_delta,
                        "tolerance": tolerance,
                    },
                )
            ]
        )
    return QAResult([])


def validate_forward_valuation(
    *,
    forward_pe: float | None,
    forward_eps: float | None,
    eps_source_type: Literal["management_guidance", "consensus_provider", "company_ir", "unknown"] | None,
    eps_period: str | None,
    eps_basis: Literal["GAAP", "non-GAAP", "unknown"] | None,
    management_guidance_low: float | None = None,
    management_guidance_high: float | None = None,
    guidance_gap_discussed: bool = False,
    discrepancy_threshold: float = 0.10,
) -> QAResult:
    issues: list[ReportIssue] = []
    if forward_pe is not None and (forward_eps is None or not eps_source_type or not eps_period or not eps_basis):
        issues.append(
            ReportIssue(
                "forward_pe_missing_eps_basis",
                "blocker",
                "Forward P/E/KGV requires EPS value, source type, period, and GAAP/non-GAAP basis.",
                {
                    "forward_pe": forward_pe,
                    "forward_eps": forward_eps,
                    "eps_source_type": eps_source_type,
                    "eps_period": eps_period,
                    "eps_basis": eps_basis,
                },
            )
        )
    if (
        forward_eps is not None
        and management_guidance_low is not None
        and management_guidance_high is not None
        and not guidance_gap_discussed
    ):
        guidance_midpoint = (management_guidance_low + management_guidance_high) / 2
        relative_gap = abs(forward_eps - guidance_midpoint) / max(abs(guidance_midpoint), 1.0)
        if relative_gap > discrepancy_threshold:
            issues.append(
                ReportIssue(
                    "forward_eps_guidance_gap_undiscussed",
                    "warning",
                    "Consensus/provider EPS and management guidance diverge; the report must discuss the gap.",
                    {
                        "forward_eps": forward_eps,
                        "management_guidance_midpoint": guidance_midpoint,
                        "relative_gap": relative_gap,
                        "threshold": discrepancy_threshold,
                    },
                )
            )
    return QAResult(issues)


def validate_earnings_gap_explanation(
    *,
    price_move_pct: float,
    explanation_terms: list[str],
    threshold_pct: float = 20.0,
) -> QAResult:
    if abs(price_move_pct) < threshold_pct:
        return QAResult([])
    normalized_terms = {term.strip().lower() for term in explanation_terms}
    fundamental_terms = {"earnings", "guidance", "management", "leadership", "sector", "sentiment", "analyst"}
    if normalized_terms.isdisjoint(fundamental_terms):
        return QAResult(
            [
                ReportIssue(
                    "large_gap_missing_fundamental_explanation",
                    "warning",
                    "A 20%+ gap move must check earnings, guidance, management/leadership, sector, sentiment, and analyst explanations before calling it distribution.",
                    {"price_move_pct": price_move_pct, "explanation_terms": explanation_terms},
                )
            ]
        )
    return QAResult([])


def validate_reentry_ladder(
    *,
    current_price: float,
    tactical_reentry_level: float | None,
    strategic_reentry_level: float | None,
    max_tactical_gap: float = 0.15,
) -> QAResult:
    if tactical_reentry_level is not None or strategic_reentry_level is None:
        return QAResult([])
    strategic_gap = (strategic_reentry_level - current_price) / max(abs(current_price), 1.0)
    if strategic_gap > max_tactical_gap:
        return QAResult(
            [
                ReportIssue(
                    "reentry_ladder_too_late",
                    "warning",
                    "A strategic re-entry level far above spot needs an earlier tactical trigger to avoid a binary late re-entry rule.",
                    {
                        "current_price": current_price,
                        "strategic_reentry_level": strategic_reentry_level,
                        "strategic_gap": strategic_gap,
                        "max_tactical_gap": max_tactical_gap,
                    },
                )
            ]
        )
    return QAResult([])


def validate_sbc_quality(
    *,
    sbc: float,
    revenue: float | None,
    fcf: float | None,
    non_gaap_operating_income: float | None,
    diluted_share_count_yoy_change: float | None,
    buybacks_vs_sbc: float | None,
) -> QAResult:
    issues: list[ReportIssue] = []
    ratios = calculate_sbc_ratios(
        sbc=sbc,
        revenue=revenue,
        fcf=fcf,
        non_gaap_operating_income=non_gaap_operating_income,
    )
    missing = [key for key, value in ratios.items() if value is None]
    if diluted_share_count_yoy_change is None:
        missing.append("diluted_share_count_yoy_change")
    if buybacks_vs_sbc is None:
        missing.append("buybacks_vs_sbc")
    if missing:
        issues.append(
            ReportIssue(
                "sbc_quality_context_missing",
                "warning",
                "SBC critique needs ratios plus dilution and buyback context; do not reduce it to a cashflow slogan.",
                {"missing": missing, "ratios": ratios},
            )
        )
    return QAResult(issues)


def assess_speculative_deep_tech_profile(
    report_text: str,
    *,
    source_ledger_entries: list[dict[str, Any]] | None = None,
    rating_text: str | None = None,
) -> SpeculativeDeepTechAssessment:
    text = report_text or ""
    ledger_entries = source_ledger_entries or []
    rating_scope = rating_text or text
    has_sec_ir = _has_current_sec_ir_evidence(text, ledger_entries)
    vendor_only_hard_metrics = _has_vendor_only_hard_financial_metrics(text, ledger_entries, has_sec_ir)
    metric_parse_missing_or_invalid = _has_metric_parse_missing_or_invalid(text)
    triggers = {
        "market_cap_revenue_gt_100": _has_market_cap_revenue_ratio_over_100(text),
        "revenue_ttm_lt_50m": _has_revenue_under_50m(text),
        "operating_income_ttm_negative": _has_negative_operating_income(text),
        "free_cash_flow_ttm_negative": _has_negative_free_cash_flow(text),
        "sbc_to_revenue_gt_050": _has_sbc_to_revenue_over_50(text),
        "vendor_only_hard_financial_metrics": vendor_only_hard_metrics,
        "derivative_warrant_fair_value_effects_detected": _has_derivative_or_warrant_effects(text),
        "no_sec_ir_current_period_evidence": not has_sec_ir,
        "lumpy_revenue_non_scaled_adoption_language": _has_lumpy_or_non_scaled_adoption_language(text),
        "share_dilution_yoy_gt_010": _has_share_dilution_over_10(text),
        "technical_milestone_language_dominates_news": _has_technical_milestone_language_dominates_news(text),
        "high_volatility_or_beta_gt_15": _has_high_volatility_or_beta_over_15(text),
        "metric_parse_missing_or_invalid": metric_parse_missing_or_invalid,
    }
    classification_triggers = {key: value for key, value in triggers.items() if key != "metric_parse_missing_or_invalid"}
    trigger_count = sum(1 for active in classification_triggers.values() if active)
    triggered_rules = [name for name, active in triggers.items() if active]
    scale_gate_blocks_deeptech = _has_large_profitable_scale(text)
    company_archetype = (
        CompanyArchetype.SPECULATIVE_DEEP_TECH_EARLY_COMMERCIAL
        if trigger_count >= 3 and not scale_gate_blocks_deeptech
        else _infer_non_deeptech_archetype(text)
    )
    archetype_confidence = round(trigger_count / len(triggers), 3) if company_archetype == CompanyArchetype.SPECULATIVE_DEEP_TECH_EARLY_COMMERCIAL else 0.2
    profile_active = company_archetype == CompanyArchetype.SPECULATIVE_DEEP_TECH_EARLY_COMMERCIAL

    issues: list[ReportIssue] = []
    if profile_active:
        issues.append(
            ReportIssue(
                SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE,
                "warning",
                "Speculative deep-tech early-commercial company archetype requires manual review.",
                {"company_archetype": company_archetype.value, "trigger_count": trigger_count, "triggers": triggers},
            )
        )

    if vendor_only_hard_metrics and profile_active:
        issues.append(
            ReportIssue(
                "VENDOR_ONLY_HARD_METRICS",
                "warning",
                "Hard financial metrics rely on vendor/manual evidence without current-period SEC/IR support.",
                {"has_sec_ir_current_period_evidence": has_sec_ir},
            )
        )
    elif vendor_only_hard_metrics:
        issues.append(
            ReportIssue(
                EVIDENCE_INCOMPLETE_FOR_GOLD,
                "warning",
                "Hard financial metrics need current-period SEC/IR or IR evidence before Gold-v1 publication.",
                {"has_sec_ir_current_period_evidence": has_sec_ir},
            )
        )

    accounting_gain_relevant = triggers["derivative_warrant_fair_value_effects_detected"] and _has_net_income_improvement_claim(text)
    if accounting_gain_relevant and not _has_operating_turnaround_caveat(text):
        issues.append(
            ReportIssue(
                "ACCOUNTING_GAIN_NOT_OPERATING_TURNAROUND",
                "warning",
                "Net income improvement language needs a clear non-operating fair-value caveat.",
                {
                    "required_caveat": "GAAP net income was helped by non-operating fair-value effects and does not indicate an operating turnaround.",
                },
            )
        )

    if profile_active and _mentions_orders_contracts_or_roadmap(text) and not _has_order_materiality_section(text):
        issues.append(
            ReportIssue(
                "ORDER_MATERIALITY_MISSING",
                "warning",
                "Orders/contracts/roadmap milestones are mentioned without a contract materiality section.",
                {
                    "required_items": [
                        "contract value",
                        "expected delivery/revenue timing",
                        "contract value vs market cap",
                        "contract value vs annual revenue",
                        "recurring vs one-off",
                        "commercial vs government/research/prototype",
                        "valuation support assessment",
                    ]
                },
            )
        )

    technical_share = _technical_claim_share(rating_scope)
    if profile_active and technical_share > 0.30:
        issues.append(
            ReportIssue(
                "TECHNICAL_OVERWEIGHT_IN_FUNDAMENTAL_THESIS",
                "warning",
                "Technical analysis dominates the long-term/fundamental rating rationale for an early-commercial speculative deep-tech stock.",
                {"technical_claim_share": round(technical_share, 3), "max_allowed": 0.30},
            )
        )

    if profile_active and _has_clean_buy_or_accumulate(rating_scope):
        issues.append(
            ReportIssue(
                "CLEAN_BUY_ACCUMULATE_BLOCKED",
                "warning",
                "Clean Buy/Accumulate language is blocked while the speculative deep-tech manual-review profile is active.",
            )
        )

    if profile_active and _has_clean_hold(rating_scope):
        issues.append(
            ReportIssue(
                "CLEAN_HOLD_BLOCKED_FOR_SPECULATIVE_DEEP_TECH",
                "warning",
                "Clean Hold language must be reframed as Small Speculative Hold Only or Manual Review / Speculative Hold.",
            )
        )

    quality_score_caps: dict[str, int] = {}
    if profile_active and not has_sec_ir:
        quality_score_caps["SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE"] = 75
    if any(issue.code == "ACCOUNTING_GAIN_NOT_OPERATING_TURNAROUND" for issue in issues):
        quality_score_caps["ACCOUNTING_GAIN_NOT_OPERATING_TURNAROUND"] = 70
    if any(issue.code == "ORDER_MATERIALITY_MISSING" for issue in issues):
        quality_score_caps["ORDER_MATERIALITY_MISSING"] = 80
    if any(issue.code == "VENDOR_ONLY_HARD_METRICS" for issue in issues):
        quality_score_caps["VENDOR_ONLY_HARD_METRICS"] = 75
    if any(issue.code == EVIDENCE_INCOMPLETE_FOR_GOLD for issue in issues):
        quality_score_caps[EVIDENCE_INCOMPLETE_FOR_GOLD] = 75
    quality_score = min(quality_score_caps.values()) if quality_score_caps else 100

    blocking_profile_issue_codes = {
        "ACCOUNTING_GAIN_NOT_OPERATING_TURNAROUND",
        "ORDER_MATERIALITY_MISSING",
        "VENDOR_ONLY_HARD_METRICS",
        EVIDENCE_INCOMPLETE_FOR_GOLD,
        "CLEAN_BUY_ACCUMULATE_BLOCKED",
        "CLEAN_HOLD_BLOCKED_FOR_SPECULATIVE_DEEP_TECH",
    }
    publishable = not profile_active or (
        has_sec_ir and not any(issue.code in blocking_profile_issue_codes for issue in issues)
    )
    if any(issue.code in blocking_profile_issue_codes for issue in issues):
        publishable = False
    status = "manual_review" if profile_active or not publishable else "quality_pass"
    if status == "manual_review" and profile_active:
        external_display_rating = MANUAL_REVIEW_DISPLAY_RATING
    elif status == "manual_review":
        external_display_rating = MANUAL_REVIEW_EVIDENCE_INCOMPLETE_DISPLAY_RATING
    else:
        external_display_rating = None
    counts = {
        "speculative_deep_tech_profile_count": 1 if profile_active else 0,
        "accounting_gain_not_operating_turnaround_count": _issue_count(issues, "ACCOUNTING_GAIN_NOT_OPERATING_TURNAROUND"),
        "vendor_only_hard_metrics_count": _issue_count(issues, "VENDOR_ONLY_HARD_METRICS"),
        "order_materiality_missing_count": _issue_count(issues, "ORDER_MATERIALITY_MISSING"),
        "technical_overweight_in_thesis_count": _issue_count(issues, "TECHNICAL_OVERWEIGHT_IN_FUNDAMENTAL_THESIS"),
    }
    return SpeculativeDeepTechAssessment(
        profile=SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE,
        company_archetype=company_archetype,
        archetype_confidence=archetype_confidence,
        archetype_triggered_rules=triggered_rules,
        active=profile_active,
        trigger_count=trigger_count,
        triggers=triggers,
        issues=issues,
        status=status,
        publishable=publishable,
        external_display_rating=external_display_rating,
        quality_score=quality_score,
        quality_score_caps=quality_score_caps,
        counts=counts,
    )


def run_institutional_regression_suite() -> QAResult:
    issues: list[ReportIssue] = []
    regression_results = [
        validate_stop_loss(position_type="long", current_price=132, stop_loss=140),
        validate_ttm_sum([26.19, 13.47, 22.12, 34.90], 58.1),
        validate_news_causality(
            news_date=date(2026, 4, 23),
            price_move_date=date(2026, 4, 30),
            causality_claimed=True,
        ),
        validate_no_news_fallback([], []),
        validate_rating_action(InstitutionalRating.SELL, "Reduce 20-30% but hold core position"),
        validate_price_basis(
            as_of_date=date(2026, 5, 1),
            last_close_date=date(2026, 4, 30),
            indicators_calculated_through=date(2026, 4, 30),
            post_close_data_checked=False,
        ),
        validate_company_defined_fcf(
            operating_cash_flow=179.6,
            capex=1.1,
            finance_lease_principal=1.8,
            reported_fcf=178.5,
            company_definition_checked=True,
        ),
        validate_forward_valuation(
            forward_pe=37.48,
            forward_eps=7.05,
            eps_source_type="consensus_provider",
            eps_period="FY2027",
            eps_basis="non-GAAP",
            management_guidance_low=5.75,
            management_guidance_high=5.93,
            guidance_gap_discussed=False,
        ),
        validate_earnings_gap_explanation(price_move_pct=-24.0, explanation_terms=["distribution"]),
        validate_reentry_ladder(current_price=250.83, tactical_reentry_level=None, strategic_reentry_level=315.0),
    ]
    expected_codes = {
        "invalid_long_stop_loss",
        "ttm_mismatch",
        "news_causality_not_verified",
        "no_news_without_fallback",
        "rating_action_sell_vs_trim",
        "price_basis_post_close_unchecked",
        "company_fcf_definition_mismatch",
        "forward_eps_guidance_gap_undiscussed",
        "large_gap_missing_fundamental_explanation",
        "reentry_ladder_too_late",
    }
    observed_codes = {issue.code for result in regression_results for issue in result.issues}
    missing = sorted(expected_codes - observed_codes)
    if missing:
        issues.append(ReportIssue("institutional_regression_suite_incomplete", "blocker", "Institutional QA regression suite did not catch required cases.", {"missing": missing}))
    return QAResult(issues)


def _issue_count(issues: list[ReportIssue], code: str) -> int:
    return sum(1 for issue in issues if issue.code == code)


def _normalized_number(value: str) -> float | None:
    lowered = value.strip().lower()
    scale = 1.0
    if re.search(r"\b(?:billionen|bio\.?|trillion|tn|t)\b", lowered):
        scale = 1_000_000_000_000.0
    elif re.search(r"\b(?:mrd\.?|billion|bn|b)\b", lowered):
        scale = 1_000_000_000.0
    elif re.search(r"\b(?:mio\.?|million|mn|m)\b", lowered):
        scale = 1_000_000.0
    elif re.search(r"\b(?:thousand|tausend|k)\b", lowered):
        scale = 1_000.0
    match = re.search(r"[-−(]?\s*\d+(?:[.,]\d+)?", lowered)
    if not match:
        return None
    cleaned = match.group(0).strip().replace("−", "-").replace(" ", "").replace(",", ".")
    paren_negative = cleaned.startswith("(")
    cleaned = cleaned.replace("(", "").replace(")", "")
    try:
        number = float(cleaned)
    except ValueError:
        return None
    if paren_negative:
        number = -abs(number)
    return number * scale


def _extract_metric_value(text: str, aliases: list[str]) -> float | None:
    alias_pattern = "|".join(re.escape(alias) for alias in aliases)
    value_pattern = r"[-−(]?\s*\d+(?:[.,]\d+)?\s*(?:billionen|bio\.?|trillion|mrd\.?|billion|bn|mio\.?|million|mn|tausend|thousand|[tbmk])?"
    patterns = [
        rf"(?:{alias_pattern})[^.\n|]{{0,90}}?({value_pattern})",
        rf"({value_pattern})[^.\n|]{{0,90}}?(?:{alias_pattern})",
    ]
    for pattern in patterns:
        for match in re.finditer(pattern, text, re.IGNORECASE):
            value = _normalized_number(match.group(1))
            if value is not None:
                return value
    return None


def _has_metric_parse_missing_or_invalid(text: str) -> bool:
    lowered = text.lower()
    relevant_terms = [
        "market cap",
        "marktkapitalisierung",
        "revenue_ttm",
        "revenue ttm",
        "umsatz",
        "operating income",
        "operatives ergebnis",
        "free cash flow",
        "fcf",
    ]
    return any(term in lowered for term in relevant_terms) and all(
        _extract_metric_value(text, aliases) is None
        for aliases in [
            ["revenue_ttm", "revenue ttm", "ttm-revenue", "ttm-umsatz", "umsatz"],
            ["market cap", "marktkapitalisierung", "market capitalization"],
            ["operating_income_ttm", "operating income ttm", "operatives ergebnis", "operating income"],
            ["free_cash_flow_ttm", "free cash flow ttm", "free cash flow", "fcf"],
        ]
    )


def _has_current_sec_ir_evidence(text: str, ledger_entries: list[dict[str, Any]]) -> bool:
    for entry in ledger_entries:
        source_type = str(entry.get("source_type") or entry.get("tier") or "").upper()
        category = str(entry.get("category") or entry.get("source_id") or "").lower()
        if source_type in {"SEC", "IR", "PRIMARY_IR"} and any(term in category for term in ["financial", "fundamental", "filing", "10-q", "10-k", "ir"]):
            return True
    lowered = text.lower()
    if re.search(r"\b(?:sec|10-q|10-k|8-k|investor relations|ir release)\b", lowered):
        return not re.search(r"\b(?:no|keine|ohne)\s+(?:current[- ]period\s+)?(?:sec|ir|investor relations|primary)\b", lowered)
    return False


def _has_vendor_only_hard_financial_metrics(text: str, ledger_entries: list[dict[str, Any]], has_sec_ir: bool) -> bool:
    hard_terms = ["revenue", "umsatz", "cash", "fcf", "free cash flow", "sbc", "debt", "eps", "net income", "operating income"]
    hard_claims_present = any(term in text.lower() for term in hard_terms)
    if not hard_claims_present:
        return False
    hard_ledger_entries = [
        entry
        for entry in ledger_entries
        if any(term in str(entry.get("category") or entry.get("metric") or entry.get("title") or entry.get("source_id") or "").lower() for term in hard_terms)
    ]
    if hard_ledger_entries:
        source_types = {str(entry.get("source_type") or entry.get("tier") or "").upper() for entry in hard_ledger_entries}
        return all(
            source_type in {"VENDOR", "PRICE_VENDOR", "MANUAL", "DERIVED", "YFINANCE", "MARKET_DATA"}
            or source_type.startswith("VENDOR:")
            for source_type in source_types
        ) and not has_sec_ir
    lowered = text.lower()
    return not has_sec_ir and bool(re.search(r"\b(?:vendor|yfinance|manual fallback|vendor-only|nur vendor)\b", lowered))


def _has_market_cap_revenue_ratio_over_100(text: str) -> bool:
    lowered = text.lower()
    for match in re.finditer(r"(?:p/s|price[- ]?to[- ]?sales|market cap\s*/\s*revenue|marktkapitalisierung\s*/\s*umsatz)[^0-9]{0,40}([0-9]+(?:[.,][0-9]+)?)\s*x", lowered):
        value = _normalized_number(match.group(1))
        if value is not None and value > 100:
            return True
    market_cap = _extract_metric_value(text, ["market cap", "marktkapitalisierung", "market capitalization"]) or _extract_table_metric_with_units(text, ["market cap", "marktkapitalisierung", "market capitalization"])
    revenue = _extract_metric_value(text, ["revenue_ttm", "revenue ttm", "ttm-revenue", "ttm-umsatz", "umsatz ttm", "umsatz"])
    if (
        market_cap is not None
        and revenue is not None
        and abs(revenue) > 1_000_000
        and market_cap / max(abs(revenue), 1.0) > 100
    ):
        return True
    return bool(re.search(r"\b(?:600|894)\s*x\b", lowered) and re.search(r"\b(?:umsatz|revenue)\b", lowered))


def _has_revenue_under_50m(text: str) -> bool:
    lowered = text.lower()
    revenue = _extract_metric_value(text, ["revenue_ttm", "revenue ttm", "ttm-revenue", "ttm-umsatz", "umsatz ttm"])
    if revenue is not None:
        return revenue < 50_000_000
    for match in re.finditer(r"(?:revenue|umsatz)[^.\n]{0,80}?([0-9]+(?:[.,][0-9]+)?)\s*(?:mio\.?|million|m)\b", lowered):
        value = _normalized_number(match.group(1))
        if value is not None and value < 50_000_000:
            return True
    return bool(re.search(r"\brevenue_ttm\s*<\s*50m\b", lowered))


def _has_negative_operating_income(text: str) -> bool:
    lowered = text.lower()
    value = _extract_metric_value(text, ["operating_income_ttm", "operating income ttm", "operatives ergebnis ttm", "operatives ergebnis", "operating income"])
    if value is not None:
        return value < 0
    return bool(
        re.search(r"\b(?:operating income|operatives ergebnis|operating loss|operativer verlust)[^.\n]{0,120}\b(?:negative|negativ|loss|verlust|-)", lowered)
        or re.search(r"\b(?:negative|negativ|-)[^.\n]{0,80}\b(?:operating income|operatives ergebnis)\b", lowered)
    )


def _has_negative_free_cash_flow(text: str) -> bool:
    lowered = text.lower()
    value = _extract_metric_value(text, ["free_cash_flow_ttm", "free cash flow ttm", "free cash flow", "fcf"])
    if value is not None:
        return value < 0
    return bool(
        re.search(r"\b(?:fcf|free cash flow|freier cashflow)[^.\n]{0,80}\b(?:negative|negativ|-)", lowered)
        or re.search(r"\b(?:negative|negativ|-)[^.\n]{0,80}\b(?:fcf|free cash flow|freier cashflow)\b", lowered)
    )


def _has_large_profitable_scale(text: str) -> bool:
    revenue = _extract_metric_value(text, ["revenue_ttm", "revenue ttm", "ttm-revenue", "ttm-umsatz", "umsatz ttm"]) or _extract_billion_table_metric(text, ["umsatz"])
    market_cap = _extract_table_metric_with_units(text, ["market cap", "marktkapitalisierung", "market capitalization"]) or _extract_metric_value(text, ["market cap", "marktkapitalisierung", "market capitalization"])
    operating_income = _extract_metric_value(text, ["operating_income_ttm", "operating income ttm", "operatives ergebnis ttm", "operatives ergebnis", "operating income"]) or _extract_billion_table_metric(text, ["operatives ergebnis"])
    free_cash_flow = _extract_metric_value(text, ["free_cash_flow_ttm", "free cash flow ttm", "free cash flow", "fcf"]) or _extract_billion_table_metric(text, ["free cash flow", "fcf"])
    return (
        revenue is not None
        and market_cap is not None
        and operating_income is not None
        and free_cash_flow is not None
        and revenue > 1_000_000_000
        and market_cap > 100_000_000_000
        and operating_income > 0
        and free_cash_flow > 0
    )


def _extract_billion_table_metric(text: str, aliases: list[str]) -> float | None:
    alias_pattern = "|".join(re.escape(alias) for alias in aliases)
    for match in re.finditer(rf"\|\s*(?:\*\*)?(?:{alias_pattern})(?:\*\*)?\s*\|\s*(?:\*\*)?([-−]?\d+(?:[.,]\d+)?)(?:\*\*)?\s*\|", text, re.IGNORECASE):
        line_start = text.rfind("\n", 0, match.start())
        context_start = max(0, line_start - 600)
        context = text[context_start:match.start()].lower()
        if any(unit_marker in context for unit_marker in ["mrd", "billion", "ttm-wert", "ttm-cashflow", "quartalsweise, gaap"]):
            value = _normalized_number(match.group(1))
            return value * 1_000_000_000 if value is not None else None
    return None


def _extract_table_metric_with_units(text: str, aliases: list[str]) -> float | None:
    alias_pattern = "|".join(re.escape(alias) for alias in aliases)
    candidates: list[float] = []
    for match in re.finditer(
        rf"\|\s*(?:\*\*)?(?:{alias_pattern})(?:\*\*)?\s*\|\s*(?:\*\*)?([-−]?\d+(?:[.,]\d+)?\s*(?:billionen|bio\.?|trillion|mrd\.?|billion|bn|mio\.?|million|mn|[tbmk])?)",
        text,
        re.IGNORECASE,
    ):
        value = _normalized_number(match.group(1))
        if value is not None:
            candidates.append(value)
    return max(candidates, key=abs) if candidates else None


def _has_sbc_to_revenue_over_50(text: str) -> bool:
    lowered = text.lower()
    for match in re.finditer(r"(?:sbc[^%\n]{0,40}(?:revenue|umsatz)|(?:revenue|umsatz)[^%\n]{0,40}sbc)[^0-9%]{0,30}([0-9]+(?:[.,][0-9]+)?)\s*%", lowered):
        value = _normalized_number(match.group(1))
        if value is not None and value > 50:
            return True
    return bool(re.search(r"\bsbc[^.\n]{0,80}(?:>\s*50%|0\.5x|half of revenue|248)", lowered))


def _has_derivative_or_warrant_effects(text: str) -> bool:
    lowered = text.lower()
    return bool(re.search(r"\b(?:derivative|warrant|fair[- ]?value|fair value|beizulegender zeitwert|derivat|optionsschein)\b", lowered))


def _has_lumpy_or_non_scaled_adoption_language(text: str) -> bool:
    lowered = text.lower()
    terms = [
        "lumpy revenue",
        "project-based",
        "not scaled",
        "non-scaled",
        "early commercial",
        "limited commercial adoption",
        "begrenzte kommerzielle adoption",
        "nicht skaliert",
        "noch nicht skaliert",
        "fruehe kommerzielle",
        "frühe kommerzielle",
    ]
    return any(term in lowered for term in terms)


def _has_high_volatility_or_beta_over_15(text: str) -> bool:
    lowered = text.lower()
    for match in re.finditer(r"\bbeta[^0-9]{0,20}([0-9]+(?:[.,][0-9]+)?)", lowered):
        value = _normalized_number(match.group(1))
        if value is not None and value > 1.5:
            return True
    return bool(re.search(r"\b(?:high[- ]?volatility|hochvolatil|high volatility flag)\b", lowered))


def _has_share_dilution_over_10(text: str) -> bool:
    lowered = text.lower()
    for match in re.finditer(r"(?:share(?:s)?|aktienzahl|diluted share count|verwässerung|verwaesserung|dilution)[^%\n]{0,80}([0-9]+(?:[.,][0-9]+)?)\s*%", lowered):
        value = _normalized_number(match.group(1))
        if value is not None and value > 10:
            return True
    return bool(re.search(r"\bshare_dilution_yoy\s*>\s*0\.10\b", lowered))


def _has_technical_milestone_language_dominates_news(text: str) -> bool:
    lowered = text.lower()
    milestone_terms = re.findall(r"\b(?:milestone|roadmap|prototype|qubit|quantum|flight test|launch window|certification|robotics demo|technical milestone|meilenstein|prototyp|zertifizierung)\b", lowered)
    revenue_terms = re.findall(r"\b(?:revenue|umsatz|bookings|contract value|auftragswert|delivery revenue|commercial revenue)\b", lowered)
    return len(milestone_terms) >= 3 and len(milestone_terms) > max(2 * len(revenue_terms), 2)


def _has_net_income_improvement_claim(text: str) -> bool:
    lowered = text.lower()
    return bool(
        re.search(r"\b(?:net income|gaap net income|nettoergebnis|verlust|loss|profitability|profitabilit)[^.\n]{0,100}\b(?:improved|verbessert|narrowed|verringert|reduced|positive|positiv|profit)\b", lowered)
        or re.search(r"\b(?:loss narrowed|verlust verringerte|profitability improved|turnaround|net income improved)\b", lowered)
    )


def _has_operating_turnaround_caveat(text: str) -> bool:
    lowered = text.lower()
    exact = "gaap net income was helped by non-operating fair-value effects and does not indicate an operating turnaround"
    german_patterns = [
        r"\bgaap[- ]?nettoergebnis[^.\n]{0,160}(?:nicht|kein)[^.\n]{0,80}operativer turnaround\b",
        r"\b(?:fair[- ]?value|beizulegender zeitwert|derivat|warrant)[^.\n]{0,160}(?:nicht|kein)[^.\n]{0,80}(?:operativer turnaround|operative profitabilit)",
        r"\b(?:kein|keine|nicht)[^.\n]{0,80}(?:operativer turnaround|operative profitabilit)[^.\n]{0,160}(?:fair[- ]?value|derivat|warrant)",
    ]
    return exact in lowered or any(re.search(pattern, lowered) for pattern in german_patterns)


def _mentions_orders_contracts_or_roadmap(text: str) -> bool:
    lowered = text.lower()
    return bool(re.search(r"\b(?:contract|contracts|auftrag|aufträge|order|orders|roadmap|milestone|meilenstein|defense|quantum|afrl|c-dac)\b", lowered))


def _has_order_materiality_section(text: str) -> bool:
    lowered = text.lower()
    required_groups = [
        [r"contract value", r"auftragswert"],
        [r"delivery", r"revenue timing", r"umsatzzeit", r"liefer"],
        [r"market cap", r"marktkapitalisierung"],
        [r"annual revenue", r"jahresumsatz"],
        [r"recurring", r"one[- ]?off", r"non[- ]?recurring", r"wiederkehrend", r"einmalig"],
        [r"commercial", r"government", r"research", r"prototype", r"kommerziell", r"staatlich", r"forschung", r"prototyp"],
        [r"valuation support", r"bewertung st", r"stützt die bewertung", r"stutzt die bewertung"],
    ]
    return all(any(re.search(pattern, lowered) for pattern in group) for group in required_groups)


def _technical_claim_share(text: str) -> float:
    sentences = [sentence.strip() for sentence in re.split(r"(?<=[.!?])\s+|\n+", text) if len(sentence.strip()) > 30]
    rationale_sentences = [
        sentence
        for sentence in sentences
        if re.search(r"\b(?:rating|rationale|entscheidung|thesis|these|underweight|buy|sell|hold|halten|untergewichten|investment)\b", sentence, re.IGNORECASE)
    ]
    if not rationale_sentences:
        rationale_sentences = sentences[:12]
    if not rationale_sentences:
        return 0.0
    technical_terms = re.compile(r"\b(?:technical|chart|sma|rsi|macd|support|resistance|trend|momentum|moving average|death cross|golden cross|technisch|charttechnik|unterstützung|widerstand)\b", re.IGNORECASE)
    technical_count = sum(1 for sentence in rationale_sentences if technical_terms.search(sentence))
    return technical_count / len(rationale_sentences)


def _has_clean_buy_or_accumulate(text: str) -> bool:
    lowered = text.lower()
    if "manual review" in lowered or "preliminary" in lowered:
        return False
    return bool(re.search(r"\b(?:action|rating|recommendation|empfehlung)\s*[:=-]\s*(?:buy|kaufen|accumulate|aufstocken)\b", lowered))


def _has_clean_hold(text: str) -> bool:
    lowered = text.lower()
    if "manual review" in lowered or "speculative hold" in lowered or "small speculative hold only" in lowered:
        return False
    return bool(re.search(r"\b(?:action|rating|recommendation|empfehlung)\s*[:=-]\s*(?:hold|halten)\b", lowered))


def _infer_non_deeptech_archetype(text: str) -> CompanyArchetype:
    lowered = text.lower()
    if any(term in lowered for term in ["alphabet", "google", "microsoft", "amazon", "meta", "mega-cap", "mega cap", "platform"]):
        return CompanyArchetype.MEGA_CAP_PLATFORM
    if any(term in lowered for term in ["snowflake", "datadog", "mongodb", "saas", "consumption"]):
        return CompanyArchetype.SAAS_CONSUMPTION
    if any(term in lowered for term in ["semiconductor", "nvidia", "broadcom", "qcom", "micron", "ai infra", "gpu"]):
        return CompanyArchetype.SEMICONDUCTOR_AI_INFRA
    if any(term in lowered for term in ["growth", "revenue growth", "expansion"]):
        return CompanyArchetype.STANDARD_GROWTH
    return CompanyArchetype.UNKNOWN


def _safe_ratio(numerator: float, denominator: float | None) -> float | None:
    if denominator is None or denominator == 0:
        return None
    return numerator / denominator
