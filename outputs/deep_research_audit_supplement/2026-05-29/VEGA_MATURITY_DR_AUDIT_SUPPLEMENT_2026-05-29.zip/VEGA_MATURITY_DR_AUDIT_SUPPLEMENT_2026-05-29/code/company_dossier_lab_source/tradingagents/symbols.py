"""Ticker/symbol validation helpers.

The framework uses ticker symbols in local cache, checkpoint, and result paths.
Keep the accepted shape narrow enough for filenames while preserving common
exchange-qualified symbols such as ``BMW.DE`` and share-class forms like
``BRK-B``.
"""

from __future__ import annotations

import re

_PATH_SAFE_SYMBOL = re.compile(r"^[A-Z0-9][A-Z0-9._-]{0,31}$")


def normalize_path_symbol(symbol: str) -> str:
    """Return an uppercase, path-safe symbol or raise ``ValueError``."""
    normalized = str(symbol).strip().upper()
    if (
        not _PATH_SAFE_SYMBOL.fullmatch(normalized)
        or ".." in normalized
        or "/" in normalized
        or "\\" in normalized
    ):
        raise ValueError(
            "Invalid ticker symbol for local paths. Use letters, numbers, dot, "
            "underscore, or hyphen only."
        )
    return normalized
