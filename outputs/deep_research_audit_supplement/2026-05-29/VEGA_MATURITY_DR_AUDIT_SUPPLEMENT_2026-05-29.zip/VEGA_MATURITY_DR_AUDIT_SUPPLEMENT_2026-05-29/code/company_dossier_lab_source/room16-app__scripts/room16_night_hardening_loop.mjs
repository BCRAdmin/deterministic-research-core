import fs from "node:fs";
import path from "node:path";
import { spawn, spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const PROJECT_ROOT = path.resolve(APP_ROOT, "..");
const OUT_ROOT = path.join(PROJECT_ROOT, ".runtime", "room16-app", "hardening");

function argValue(name, fallback) {
  const index = process.argv.indexOf(name);
  return index >= 0 ? process.argv[index + 1] : fallback;
}

function hasFlag(name) {
  return process.argv.includes(name);
}

const cycles = Number(argValue("--cycles", "1"));
const intervalMs = Number(argValue("--interval-ms", "120000"));
const port = Number(argValue("--port", process.env.PORT || "4516"));
const baseUrl = process.env.ROOM16_APP_BASE_URL || `http://127.0.0.1:${port}`;
const screenshotsEnabled = !hasFlag("--no-screenshots");
const isLoopMode = cycles === 0;
const continueOnFail = hasFlag("--continue-on-fail") || (isLoopMode && !hasFlag("--stop-on-fail"));

let managedServer = null;

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function timestamp() {
  return new Date().toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
}

async function sleep(ms) {
  await new Promise((resolve) => setTimeout(resolve, ms));
}

async function healthOk() {
  try {
    const response = await fetch(`${baseUrl}/api/health`);
    if (!response.ok) return false;
    const json = await response.json();
    return Boolean(json.ok && json.preflight?.ok);
  } catch {
    return false;
  }
}

async function latestReaderUrl() {
  try {
    const response = await fetch(`${baseUrl}/api/state`);
    if (!response.ok) return `${baseUrl}?reader=latest`;
    const state = await response.json();
    const company = Array.isArray(state.companies)
      ? state.companies.find((item) => item.latestReport?.id)
      : null;
    return company ? `${baseUrl}?ticker=${encodeURIComponent(company.ticker)}&reader=latest` : baseUrl;
  } catch {
    return `${baseUrl}?reader=latest`;
  }
}

async function ensureServer() {
  if (await healthOk()) {
    return { started: false, detail: "existing server healthy" };
  }
  const logPath = path.join(PROJECT_ROOT, ".runtime", "room16-app", "managed-server.log");
  ensureDir(path.dirname(logPath));
  const log = fs.openSync(logPath, "a");
  managedServer = spawn(process.execPath, ["server.mjs", "--static", "--port", String(port)], {
    cwd: APP_ROOT,
    stdio: ["ignore", log, log],
    detached: false
  });
  for (let attempt = 0; attempt < 20; attempt += 1) {
    if (await healthOk()) {
      return { started: true, detail: `managed server pid ${managedServer.pid}` };
    }
    await sleep(500);
  }
  throw new Error(`Room 16 app server did not become healthy at ${baseUrl}`);
}

function runCommand(label, command, args, options = {}) {
  const startedAt = new Date().toISOString();
  const result = spawnSync(command, args, {
    cwd: options.cwd || APP_ROOT,
    env: { ...process.env, ROOM16_APP_BASE_URL: baseUrl, ...options.env },
    encoding: "utf8"
  });
  return {
    label,
    command: [command, ...args],
    startedAt,
    completedAt: new Date().toISOString(),
    exitCode: result.status,
    signal: result.signal,
    error: result.error?.message || null,
    stdout: result.stdout?.slice(-12000) || "",
    stderr: result.stderr?.slice(-12000) || ""
  };
}

function commandPassed(commandResult) {
  return commandResult.exitCode === 0;
}

async function runCycle(index) {
  const cycleId = `${timestamp()}-cycle-${String(index).padStart(2, "0")}`;
  const outDir = path.join(OUT_ROOT, cycleId);
  ensureDir(outDir);

  const server = await ensureServer();
  const commands = [];
  commands.push(runCommand("build", "npm", ["run", "build"]));
  commands.push(runCommand("verify", "npm", ["run", "verify"], {
    env: { ROOM16_VERIFY_SKIP_HARDENING_STATE: "1" }
  }));

  if (screenshotsEnabled) {
    const readerUrl = await latestReaderUrl();
    commands.push(
      runCommand("screenshot_desktop", "npx", [
        "playwright",
        "screenshot",
        "--viewport-size=1280,720",
        "--wait-for-timeout=1800",
        baseUrl,
        path.join(outDir, "desktop.png")
      ])
    );
    commands.push(
      runCommand("screenshot_medium_edge", "npx", [
        "playwright",
        "screenshot",
        "--viewport-size=1360,720",
        "--wait-for-timeout=1800",
        baseUrl,
        path.join(outDir, "medium-edge.png")
      ])
    );
    commands.push(
      runCommand("screenshot_rail_edge", "npx", [
        "playwright",
        "screenshot",
        "--viewport-size=1761,720",
        "--wait-for-timeout=1800",
        baseUrl,
        path.join(outDir, "rail-edge.png")
      ])
    );
    commands.push(
      runCommand("screenshot_reader_desktop", "npx", [
        "playwright",
        "screenshot",
        "--viewport-size=1280,720",
        "--wait-for-timeout=1800",
        readerUrl,
        path.join(outDir, "reader-desktop.png")
      ])
    );
    commands.push(
      runCommand("screenshot_mobile", "npx", [
        "playwright",
        "screenshot",
        "--viewport-size=390,844",
        "--wait-for-timeout=1800",
        baseUrl,
        path.join(outDir, "mobile.png")
      ])
    );
    commands.push(
      runCommand("screenshot_reader_mobile", "npx", [
        "playwright",
        "screenshot",
        "--viewport-size=390,844",
        "--wait-for-timeout=1800",
        readerUrl,
        path.join(outDir, "reader-mobile.png")
      ])
    );
    commands.push(runCommand("verify_layout", "npm", ["run", "verify:layout", "--", "--screenshot-dir", outDir]));
  } else {
    commands.push(runCommand("verify_layout", "npm", ["run", "verify:layout"]));
  }

  const verdict = commands.every(commandPassed) ? "pass" : "fail";
  const report = {
    cycleId,
    createdAt: new Date().toISOString(),
    baseUrl,
    server,
    screenshotsEnabled,
    verdict,
    commands
  };
  fs.writeFileSync(path.join(outDir, "report.json"), JSON.stringify(report, null, 2), "utf8");
  fs.writeFileSync(
    path.join(outDir, "report.md"),
    [
      `# Room 16 Night Hardening Cycle ${cycleId}`,
      "",
      `Created: ${report.createdAt}`,
      `Base URL: ${baseUrl}`,
      `Verdict: ${verdict}`,
      `Server: ${server.detail}`,
      "",
      "## Commands",
      "",
      ...commands.flatMap((command) => [
        `### ${command.label}`,
        "",
        `- Exit: ${command.exitCode}`,
        `- Command: \`${command.command.join(" ")}\``,
        command.stdout.trim() ? `- Stdout tail:\n\n\`\`\`text\n${command.stdout.trim()}\n\`\`\`` : "- Stdout tail: empty",
        command.stderr.trim() ? `- Stderr tail:\n\n\`\`\`text\n${command.stderr.trim()}\n\`\`\`` : "- Stderr tail: empty",
        ""
      ]),
      screenshotsEnabled
        ? "## Screenshots\n\n- `desktop.png`\n- `medium-edge.png`\n- `rail-edge.png`\n- `reader-desktop.png`\n- `mobile.png`\n- `reader-mobile.png`"
        : "## Screenshots\n\nDisabled for this run."
    ].join("\n"),
    "utf8"
  );
  fs.writeFileSync(path.join(OUT_ROOT, "latest-cycle.json"), JSON.stringify(report, null, 2), "utf8");
  fs.appendFileSync(
    path.join(OUT_ROOT, "HARDENING_LOG.md"),
    `\n- ${report.createdAt} ${cycleId}: ${verdict} (${commands.map((command) => `${command.label}=${command.exitCode}`).join(", ")})\n`,
    "utf8"
  );
  console.log(JSON.stringify({ cycleId, verdict, outDir }, null, 2));
  if (verdict !== "pass" && !continueOnFail) {
    process.exitCode = 1;
  }
  return verdict;
}

function cleanupManagedServer() {
  if (managedServer?.pid) {
    try {
      managedServer.kill();
    } catch {
      // Best effort cleanup only.
    }
  }
}

async function main() {
  ensureDir(OUT_ROOT);
  const total = isLoopMode ? Number.POSITIVE_INFINITY : Math.max(1, cycles);
  for (let index = 1; index <= total; index += 1) {
    const verdict = await runCycle(index);
    if (verdict !== "pass" && !continueOnFail) {
      break;
    }
    if (index < total) {
      await sleep(intervalMs);
    }
  }
}

process.on("exit", () => {
  cleanupManagedServer();
});

main()
  .finally(() => {
    if (!isLoopMode) {
      cleanupManagedServer();
    }
  })
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
