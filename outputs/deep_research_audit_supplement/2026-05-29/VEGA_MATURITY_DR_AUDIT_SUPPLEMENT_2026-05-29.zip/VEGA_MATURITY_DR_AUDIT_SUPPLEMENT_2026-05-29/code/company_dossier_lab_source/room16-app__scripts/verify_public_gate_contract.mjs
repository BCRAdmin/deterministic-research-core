import { evaluatePublicLibraryGate } from "../server-modules/public-library-gate.mjs";

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

const basePublicEntry = {
  pdfUrl: "/report.pdf",
  markdownUrl: "/report.md",
  internalBestReportUrl: "/internal.md",
  publishReportUrl: "/publish.md",
  qualityVerdict: "pass",
  qualityStatus: "pass",
  reviewStatusMetric: "pass",
  generationStage: "public_final",
  renderMode: "final_public_documents",
  finalDocumentsRendered: true,
  publicReady: true,
  promotionStatus: {
    public_ready: true,
    reviewed_by: "operator",
    approved_at: "2026-05-18T00:00:00Z",
    requested_visibility: "public",
    non_advice_confirmed: true,
    sources_human_verified: true,
    blocking_issues: [],
  },
  sourceStatus: "human_verified",
  reviewStatus: "reviewed",
  nonAdvice: true,
  visibility: "public",
};

const publicReady = evaluatePublicLibraryGate(basePublicEntry);
assert(publicReady.status === "public_ready", "fully promoted report should be public_ready");
assert(publicReady.effectiveVisibility === "public", "fully promoted public report should be effectively public");

const manualReview = evaluatePublicLibraryGate({
  ...basePublicEntry,
  qualityStatus: "manual_review",
  reviewStatusMetric: "manual_review",
});
assert(manualReview.status === "manual_review", "manual_review must not promote");
assert(manualReview.effectiveVisibility === "hidden", "manual_review must stay hidden");
assert(manualReview.blockers.includes("manual_review_required"), "manual_review blocker should be explicit");

const internalBest = evaluatePublicLibraryGate({
  ...basePublicEntry,
  generationStage: "internal_best",
  visibility: "public",
});
assert(internalBest.status === "internal_only", "internal_best must remain internal_only");
assert(internalBest.effectiveVisibility === "hidden", "internal_best must stay hidden even if requested public");
assert(internalBest.blockers.includes("internal_best_not_public"), "internal_best blocker should be explicit");

const missingPromotion = evaluatePublicLibraryGate({
  ...basePublicEntry,
  promotionStatus: { public_ready: true },
});
assert(missingPromotion.status === "rejected", "incomplete promotion stack should be rejected");
assert(missingPromotion.effectiveVisibility === "hidden", "incomplete promotion stack must stay hidden");
assert(missingPromotion.blockers.includes("promotion_non_advice_missing"), "non-advice blocker should be explicit");
assert(missingPromotion.blockers.includes("promotion_sources_human_verified_missing"), "source verification blocker should be explicit");

console.log("Public gate contract passed.");
