import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const PROJECT_ROOT = path.resolve(APP_ROOT, "..");
const runbookPath = path.join(PROJECT_ROOT, "docs", "ROOM16_REVIEW_OPERATIONS_RUNBOOK_2026-05-18.md");
const schemaPath = path.join(PROJECT_ROOT, "docs", "ROOM16_REVIEW_QUEUE_PACKET_SCHEMA_2026-05-18.md");
const reviewGateStatusPath = path.join(PROJECT_ROOT, "docs", "ROOM16_REVIEW_GATE_STATUS_PACKET_2026-05-23.md");
const manualReviewPacketsPath = path.join(PROJECT_ROOT, "docs", "ROOM16_MANUAL_REVIEW_PACKETS_2026-05-23.md");

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function readRequired(filePath, label) {
  assert(fs.existsSync(filePath), `${label} missing: ${filePath}`);
  return fs.readFileSync(filePath, "utf8");
}

function assertIncludes(source, needle, label) {
  assert(source.includes(needle), `${label} missing: ${needle}`);
}

function assertMatches(source, pattern, label) {
  assert(pattern.test(source), `${label} missing pattern: ${pattern}`);
}

const runbookSource = readRequired(runbookPath, "Review operations runbook");
const schemaSource = readRequired(schemaPath, "Review queue packet schema");
const reviewGateStatusSource = readRequired(reviewGateStatusPath, "Review gate status packet");
const manualReviewPacketsSource = readRequired(manualReviewPacketsPath, "Manual review packets doc");
const combinedSource = `${runbookSource}\n${schemaSource}\n${reviewGateStatusSource}\n${manualReviewPacketsSource}`;

[
  "Daily Review Ablauf",
  "Blocker Triage",
  "Status Definitionen",
  "Entscheidungsrechte",
  "Operator-Go Pflicht",
  "Non-Advice Bestätigung",
  "Human Source Verification",
  "Warum Public geschlossen bleibt"
].forEach((needle) => assertIncludes(runbookSource, needle, "runbook section"));

[
  "source",
  "audit",
  "render",
  "provider",
  "data",
  "promotion"
].forEach((category) => {
  assertIncludes(runbookSource, `\`${category}\``, "runbook blocker category");
  assertIncludes(schemaSource, `\`${category}\``, "schema blocker category");
});

[
  "ticker",
  "dossierId",
  "generationStage",
  "gateStatus",
  "blockers",
  "warnings",
  "nextManualAction",
  "reviewer",
  "sourceVerificationStatus",
  "nonAdviceStatus",
  "promotionStatus",
  "operatorGoRequired"
].forEach((field) => assertIncludes(schemaSource, `\`${field}\``, "schema field"));

[
  "manual_review_entries",
  "operator_gate_required",
  "runtime_action_executed",
  "next_safe_step",
  "stop_rule",
  "fail_count",
  "warn_count"
].forEach((field) => assertIncludes(reviewGateStatusSource, `\`${field}\``, "review gate status packet field"));

[
  "manual_review",
  "draft_markdown_qa",
  "internal_best",
  "public_ready",
  "approved_internal",
  "promotion_blocked"
].forEach((status) => assertIncludes(combinedSource, `\`${status}\``, "review status"));

[
  "Operator-Go",
  "operatorGoRequired",
  "Non-Advice",
  "Human Source Verification",
  "sourceVerificationStatus",
  "nonAdviceStatus"
].forEach((needle) => assertIncludes(combinedSource, needle, "operations guard"));

assertMatches(runbookSource, /Public bleibt geschlossen/i, "public closed rule");
assertMatches(runbookSource, /keine Public-Automation/i, "no public automation rule");
assertMatches(schemaSource, /keine Public-Automation/i, "schema no public automation rule");
assertMatches(combinedSource, /keine Anlageberatung/i, "non-advice policy guard");
assertMatches(combinedSource, /keine Provider-Aktion|kein Provider-Auftrag/i, "provider action guard");
assertIncludes(reviewGateStatusSource, "npm run verify:review-gate-status", "review gate status verifier");
assertIncludes(reviewGateStatusSource, "read-only", "review gate status read-only guard");
assertIncludes(reviewGateStatusSource, "keine doppelten Claims", "review gate status duplicate-claim guard");
assertIncludes(manualReviewPacketsSource, "npm run verify:manual-review-packets", "manual review packets verifier");
assertIncludes(manualReviewPacketsSource, "runtime_action_executed", "manual review packet runtime guard");
assertIncludes(manualReviewPacketsSource, "keine Freigabe", "manual review packet no-approval guard");

const forbiddenPublicAutomationPatterns = [
  /publicAutomation\s*[:=]\s*true/i,
  /publishing automation enabled/i,
  /public automation enabled/i,
  /automatisch\s+public_ready/i,
  /automatisch\s+public\s+setzen/i,
  /auto-?publish/i
];

for (const pattern of forbiddenPublicAutomationPatterns) {
  assert(!pattern.test(combinedSource), `docs must not describe public automation: ${pattern}`);
}

console.log("Review operations runbook verifier passed.");
