#!/usr/bin/env bash
set -euo pipefail

APP_ROOT="/Users/BjornRosinger/Documents/DreamFactory/Project-Intelligence-Graph/company-dossier-lab/room16-app"
BASE_URL="${ROOM16_APP_BASE_URL:-http://127.0.0.1:4516}"
LOG_DIR="/Users/BjornRosinger/Library/Logs"
SERVER_LOG="$LOG_DIR/room16-app-server.log"
SERVER_ERR="$LOG_DIR/room16-app-server.err.log"
PLIST="/Users/BjornRosinger/Library/LaunchAgents/com.room16.hardening.plist"
NODE_BIN="/opt/homebrew/bin/node"

health_ok() {
  /usr/bin/curl -fsS "$BASE_URL/api/health" | /usr/bin/grep -q '"ok":true'
}

if health_ok; then
  exit 0
fi

if [ -f "$PLIST" ]; then
  /bin/launchctl bootstrap "gui/$(/usr/bin/id -u)" "$PLIST" >/dev/null 2>&1 || true
  /bin/launchctl kickstart -k "gui/$(/usr/bin/id -u)/com.room16.hardening" >/dev/null 2>&1 || true
fi

for _ in $(/usr/bin/seq 1 20); do
  if health_ok; then
    exit 0
  fi
  /bin/sleep 0.35
done

/bin/mkdir -p "$LOG_DIR"
if [ ! -x "$NODE_BIN" ]; then
  NODE_BIN="$(/usr/bin/which node)"
fi

/usr/bin/nohup "$NODE_BIN" "$APP_ROOT/server.mjs" --static --port 4516 >>"$SERVER_LOG" 2>>"$SERVER_ERR" &

for _ in $(/usr/bin/seq 1 30); do
  if health_ok; then
    exit 0
  fi
  /bin/sleep 0.35
done

exit 1
