import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import path from "node:path";

const here = path.dirname(fileURLToPath(import.meta.url));
const appRoot = path.resolve(here, "..");
const repoRoot = path.resolve(appRoot, "..");
const workspaceRoot = path.resolve(repoRoot, "..");
const gateScript = path.join(workspaceRoot, "scripts", "project_intelligence_graph", "german_output_quality_gate.py");
const reportTargets = [
  path.join(repoRoot, "reports", "room16", "runs"),
  path.join(repoRoot, "reports", "room16", "complete"),
];
const jsonOut = path.join(repoRoot, "outputs", "german_output_quality", "room16_german_output_quality.json");
const mdOut = path.join(repoRoot, "outputs", "german_output_quality", "room16_german_output_quality.md");

const result = spawnSync("python3", [gateScript, ...reportTargets, "--json-out", jsonOut, "--md-out", mdOut, "--fail-only"], {
  cwd: workspaceRoot,
  encoding: "utf8",
});

if (result.stdout) process.stdout.write(result.stdout);
if (result.stderr) process.stderr.write(result.stderr);
if (result.status !== 0) {
  process.stderr.write(`German output quality gate failed. See ${mdOut}\n`);
  process.exit(result.status ?? 1);
}

process.stdout.write(`German output quality gate passed. Report: ${mdOut}\n`);
