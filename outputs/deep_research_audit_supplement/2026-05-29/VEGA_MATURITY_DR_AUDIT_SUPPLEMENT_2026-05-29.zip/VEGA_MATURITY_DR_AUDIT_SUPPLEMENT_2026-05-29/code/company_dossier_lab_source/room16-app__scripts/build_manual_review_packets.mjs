import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const PROJECT_ROOT = path.resolve(APP_ROOT, "..");
const DEFAULT_REPORTS_ROOT = path.join(os.homedir(), "Documents", "DreamFactory", "Room16", "Reports");
const REPORTS_ROOT = process.env.ROOM16_REPORTS_ROOT || DEFAULT_REPORTS_ROOT;
const RUNTIME_ROOT = path.join(PROJECT_ROOT, ".runtime", "room16-app");
const REVIEW_GATE_STATUS_PATH = path.join(RUNTIME_ROOT, "review-gate-status", "latest-review-gate-status.json");
const OUT_DIR = path.join(RUNTIME_ROOT, "manual-review-packets");
const OUT_JSON = path.join(OUT_DIR, "latest-manual-review-packets.json");
const OUT_MD = path.join(OUT_DIR, "latest-manual-review-packets.md");

const BLOCKERS = [
  {
    category: "audit",
    reason: "manual_review_required",
    severity: "blocking",
    note: "Pipeline or gate status requires a human review decision.",
  },
  {
    category: "source",
    reason: "human_source_verification_open",
    severity: "blocking",
    note: "Only pipeline source verification is visible in the library status packet.",
  },
  {
    category: "promotion",
    reason: "non_advice_confirmation_open",
    severity: "blocking",
    note: "Non-advice confirmation is not documented in the manual-review packet.",
  },
];

const POLICY_REFERENCES = [
  "docs/ROOM16_REVIEW_OPERATIONS_RUNBOOK_2026-05-18.md",
  "docs/ROOM16_REVIEW_QUEUE_PACKET_SCHEMA_2026-05-18.md",
  "docs/ROOM16_MANUAL_REVIEW_WORKBENCH_2026-05-18.md",
  "docs/ROOM16_QUELLWERT_PROMOTION_CONTRACT.md",
];

const REVIEW_EVIDENCE_CHECKLIST = [
  {
    id: "report_file_present",
    label: "Lokale Report-Datei vorhanden",
    requiredForInternalApproval: true,
  },
  {
    id: "human_source_verification",
    label: "Quellen menschlich gegen Report und Source-Paket geprüft",
    requiredForInternalApproval: true,
  },
  {
    id: "non_advice_review",
    label: "Keine Anlageberatung, Kauf-/Verkaufsempfehlung oder Renditegarantie bestätigt",
    requiredForInternalApproval: true,
  },
  {
    id: "risk_and_limits_visible",
    label: "Risiken, Unsicherheiten und Grenzen sind sichtbar",
    requiredForInternalApproval: true,
  },
  {
    id: "operator_visibility_go",
    label: "Operator-Go für Public/Member liegt vor",
    requiredForPublicOrMember: true,
  },
];

function buildManualDecisionContract(reportFileExists) {
  return {
    schema_version: 1,
    reviewer_required: true,
    allowed_decisions: ["keep_hidden", "approved_internal", "reject", "needs_more_evidence"],
    forbidden_decisions_without_operator_go: ["public", "member", "publish", "rerun", "push"],
    required_before_approved_internal: [
      "human_source_verification",
      "non_advice_confirmation",
      "risk_and_limits_review",
      "reviewer_name_or_role",
      "decision_timestamp",
    ],
    current_completion: {
      report_file_present: reportFileExists,
      human_source_verification: false,
      non_advice_confirmation: false,
      risk_and_limits_review: false,
      operator_visibility_go: false,
    },
  };
}

function buildPromotionReadiness(reportFileExists) {
  const checks = [
    { id: "report_file_present", status: reportFileExists ? "pass" : "fail" },
    { id: "human_source_verification", status: "missing" },
    { id: "non_advice_confirmation", status: "missing" },
    { id: "promotion_stack_complete", status: "missing" },
    { id: "operator_visibility_go", status: "blocked" },
  ];
  return {
    status: "blocked",
    checks,
    summary: "Public/Member bleibt blockiert, bis Human Source Verification, Non-Advice, Promotion-Stack und Operator-Go dokumentiert sind.",
  };
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function slug(value) {
  return String(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 120);
}

function readJson(filePath, label) {
  assert(fs.existsSync(filePath), `${label} missing: ${filePath}`);
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function walkFiles(dir) {
  if (!fs.existsSync(dir)) return [];
  const result = [];
  const stack = [dir];
  while (stack.length) {
    const current = stack.pop();
    for (const entry of fs.readdirSync(current, { withFileTypes: true })) {
      const fullPath = path.join(current, entry.name);
      if (entry.isDirectory()) stack.push(fullPath);
      if (entry.isFile()) result.push(fullPath);
    }
  }
  return result;
}

function findReportFile(reportName, reportFiles) {
  return reportFiles.find((filePath) => path.basename(filePath) === reportName) || "";
}

function buildPacket(entry, reportPath) {
  const stats = reportPath ? fs.statSync(reportPath) : null;
  const dossierId = slug(`${entry.ticker}-${entry.report}`);
  return {
    schema_version: 1,
    ticker: entry.ticker,
    dossierId,
    report: entry.report,
    reportPath,
    reportFileExists: Boolean(reportPath),
    reportFileSizeBytes: stats ? stats.size : 0,
    generationStage: "review_ready",
    gateStatus: entry.gate,
    blockers: BLOCKERS,
    warnings: [
      "manual_review_keeps_report_hidden",
      "public_member_visibility_not_allowed_from_packet",
    ],
    nextManualAction: "Report lokal lesen, Human Source Verification und Non-Advice prüfen, Entscheidung dokumentieren; Public bleibt geschlossen.",
    reviewer: "unassigned",
    sourceVerificationStatus: entry.sources === "human_verified" ? "human_verified" : "pipeline_verified",
    nonAdviceStatus: "missing",
    promotionStatus: "blocked",
    manualDecisionContract: buildManualDecisionContract(Boolean(reportPath)),
    promotionReadiness: buildPromotionReadiness(Boolean(reportPath)),
    reviewEvidenceChecklist: REVIEW_EVIDENCE_CHECKLIST,
    policyReferences: POLICY_REFERENCES,
    operatorGoRequired: false,
    requestedVisibility: entry.requested,
    effectiveVisibility: entry.effective,
    runtime_action_executed: false,
    stopRule: "Stop bei Public/Member-Sichtbarkeit, Rerun, Push, Publish, externer Kommunikation, Finanzpublishing, Production, Geld, Auth/Credentials oder Löschung.",
  };
}

function packetMarkdown(packet) {
  return [
    `# Room16 Manual Review Packet - ${packet.ticker}`,
    "",
    `- Dossier: \`${packet.dossierId}\``,
    `- Report: \`${packet.report}\``,
    `- Datei gefunden: \`${packet.reportFileExists}\``,
    `- Gate: \`${packet.gateStatus}\``,
    `- Effective Visibility: \`${packet.effectiveVisibility}\``,
    `- Source Verification: \`${packet.sourceVerificationStatus}\``,
    `- Non-Advice: \`${packet.nonAdviceStatus}\``,
    `- Promotion: \`${packet.promotionStatus}\``,
    `- Operator-Go erforderlich: \`${packet.operatorGoRequired}\``,
    "",
    "## Entscheidungsvertrag",
    "",
    `- Erlaubte Entscheidungen: ${packet.manualDecisionContract.allowed_decisions.map((item) => `\`${item}\``).join(", ")}`,
    `- Ohne Operator-Go verboten: ${packet.manualDecisionContract.forbidden_decisions_without_operator_go.map((item) => `\`${item}\``).join(", ")}`,
    `- Promotion-Readiness: \`${packet.promotionReadiness.status}\``,
    "",
    "## Review-Checkliste",
    "",
    ...packet.reviewEvidenceChecklist.map((item) => `- \`${item.id}\`: ${item.label}`),
    "",
    "## Nächster sicherer Schritt",
    "",
    packet.nextManualAction,
    "",
    "## Stop-Regel",
    "",
    packet.stopRule,
    "",
    "## Blocker",
    "",
    ...packet.blockers.map((blocker) => `- \`${blocker.category}\` / \`${blocker.reason}\`: ${blocker.note}`),
    "",
    "## Policy-Referenzen",
    "",
    ...packet.policyReferences.map((reference) => `- \`${reference}\``),
    "",
  ].join("\n");
}

function summaryMarkdown(payload) {
  const lines = [
    "# Room16 Manual Review Packets",
    "",
    `Generated: ${payload.generated_at}`,
    `Status: ${payload.status}`,
    "",
    "## Summary",
    "",
    `- Packets: ${payload.packet_count}`,
    `- Missing Files: ${payload.missing_file_count}`,
    `- Runtime Action Executed: ${payload.runtime_action_executed}`,
    `- Promotion Readiness: ${payload.promotion_readiness_status}`,
    "",
    "## Packets",
    "",
  ];
  if (payload.packets.length) {
    lines.push("| Ticker | Report | File | Gate | Next Action |");
    lines.push("| --- | --- | --- | --- | --- |");
    for (const packet of payload.packets) {
      lines.push(`| ${packet.ticker} | ${packet.report} | ${packet.reportFileExists ? "found" : "missing"} | ${packet.gateStatus} | ${packet.promotionReadiness.status}: ${packet.nextManualAction} |`);
    }
  } else {
    lines.push("- No manual-review packets generated.");
  }
  lines.push("", "## Stop-Regel", "", payload.stop_rule, "");
  return lines.join("\n");
}

const reviewGateStatus = readJson(REVIEW_GATE_STATUS_PATH, "Review gate status packet");
const manualEntries = Array.isArray(reviewGateStatus.manual_review_entries)
  ? reviewGateStatus.manual_review_entries
  : [];
const reportFiles = walkFiles(REPORTS_ROOT);
const packets = manualEntries.map((entry) => buildPacket(entry, findReportFile(entry.report, reportFiles)));
const missingFiles = packets.filter((packet) => !packet.reportFileExists);
const status = missingFiles.length ? "FAIL" : packets.length ? "WARN" : "PASS";
const payload = {
  schema_version: 1,
  generated_at: new Date().toISOString(),
  status,
  source_review_gate_status_path: REVIEW_GATE_STATUS_PATH,
  reports_root: REPORTS_ROOT,
  packet_count: packets.length,
  missing_file_count: missingFiles.length,
  promotion_readiness_status: packets.length ? "blocked" : "not_applicable",
  runtime_action_executed: false,
  packets,
  stop_rule: "Manual-review packets are local evidence only. They do not approve, publish, rerun, push, expose, send, delete or change Room16 visibility.",
};

fs.mkdirSync(OUT_DIR, { recursive: true });
fs.writeFileSync(OUT_JSON, JSON.stringify(payload, null, 2), "utf8");
fs.writeFileSync(OUT_MD, `${summaryMarkdown(payload)}\n`, "utf8");
for (const packet of packets) {
  fs.writeFileSync(path.join(OUT_DIR, `${packet.dossierId}.json`), JSON.stringify(packet, null, 2), "utf8");
  fs.writeFileSync(path.join(OUT_DIR, `${packet.dossierId}.md`), `${packetMarkdown(packet)}\n`, "utf8");
}

if (status === "FAIL") {
  console.error(`Room16 manual-review packet build failed. Output: ${OUT_JSON}`);
  process.exit(1);
}

console.log(`Room16 manual-review packets ${status}. Output: ${OUT_JSON}`);
