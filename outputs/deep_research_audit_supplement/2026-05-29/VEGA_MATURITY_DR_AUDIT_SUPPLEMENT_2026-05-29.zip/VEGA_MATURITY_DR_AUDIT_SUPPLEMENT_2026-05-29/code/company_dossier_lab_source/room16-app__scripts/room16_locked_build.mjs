import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const LOCK_DIR = path.join(APP_ROOT, ".runtime", "build.lock");
const LOCK_META = path.join(LOCK_DIR, "meta.json");
const DIST_DIR = path.join(APP_ROOT, "dist");
const BUILD_OUT_DIR = path.join(APP_ROOT, ".runtime", `dist-next-${process.pid}`);
const PREVIOUS_DIST_DIR = path.join(APP_ROOT, ".runtime", `dist-prev-${process.pid}`);
const MAX_WAIT_MS = 120000;
const STALE_MS = 10 * 60 * 1000;
const WAIT_STEP_MS = 250;

function sleep(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}

function readMeta() {
  try {
    return JSON.parse(fs.readFileSync(LOCK_META, "utf8"));
  } catch {
    return null;
  }
}

function isProcessAlive(pid) {
  if (!pid) return false;
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

function acquireLock() {
  const started = Date.now();
  fs.mkdirSync(path.dirname(LOCK_DIR), { recursive: true });

  while (Date.now() - started < MAX_WAIT_MS) {
    try {
      fs.mkdirSync(LOCK_DIR);
      fs.writeFileSync(
        LOCK_META,
        JSON.stringify({ pid: process.pid, createdAt: new Date().toISOString() }, null, 2),
        "utf8"
      );
      return;
    } catch (error) {
      if (error.code !== "EEXIST") throw error;
      const meta = readMeta();
      const age = meta?.createdAt ? Date.now() - Date.parse(meta.createdAt) : Number.POSITIVE_INFINITY;
      if (age > STALE_MS || (meta?.pid && !isProcessAlive(meta.pid))) {
        fs.rmSync(LOCK_DIR, { recursive: true, force: true });
        continue;
      }
      sleep(WAIT_STEP_MS);
    }
  }

  throw new Error(`Room 16 build lock timed out after ${MAX_WAIT_MS}ms: ${LOCK_DIR}`);
}

function releaseLock() {
  const meta = readMeta();
  if (meta?.pid === process.pid) {
    fs.rmSync(LOCK_DIR, { recursive: true, force: true });
  }
}

function swapBuiltDist() {
  if (!fs.existsSync(BUILD_OUT_DIR)) {
    throw new Error(`Vite build output missing: ${BUILD_OUT_DIR}`);
  }
  fs.rmSync(PREVIOUS_DIST_DIR, { recursive: true, force: true });
  if (fs.existsSync(DIST_DIR)) {
    fs.renameSync(DIST_DIR, PREVIOUS_DIST_DIR);
  }
  fs.renameSync(BUILD_OUT_DIR, DIST_DIR);
  fs.rmSync(PREVIOUS_DIST_DIR, { recursive: true, force: true });
}

function run(label, command, args) {
  const result = spawnSync(command, args, {
    cwd: APP_ROOT,
    stdio: "inherit",
    env: process.env
  });
  if (result.error) {
    throw result.error;
  }
  if (result.status !== 0) {
    process.exit(result.status ?? 1);
  }
}

process.on("exit", releaseLock);
process.on("SIGINT", () => {
  releaseLock();
  process.exit(130);
});
process.on("SIGTERM", () => {
  releaseLock();
  process.exit(143);
});

acquireLock();
fs.rmSync(BUILD_OUT_DIR, { recursive: true, force: true });
run("typescript", path.join(APP_ROOT, "node_modules", ".bin", "tsc"), ["-b"]);
run("vite", path.join(APP_ROOT, "node_modules", ".bin", "vite"), ["build", "--outDir", BUILD_OUT_DIR, "--emptyOutDir"]);
swapBuiltDist();
