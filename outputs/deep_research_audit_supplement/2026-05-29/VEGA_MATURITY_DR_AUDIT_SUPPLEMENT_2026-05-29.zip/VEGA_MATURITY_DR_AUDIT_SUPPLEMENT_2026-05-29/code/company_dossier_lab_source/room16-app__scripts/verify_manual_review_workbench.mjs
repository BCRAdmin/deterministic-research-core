import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { evaluatePublicLibraryGate } from "../server-modules/public-library-gate.mjs";

const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const PROJECT_ROOT = path.resolve(APP_ROOT, "..");
const appSource = fs.readFileSync(path.join(APP_ROOT, "src", "App.tsx"), "utf8");
const helperSource = fs.readFileSync(path.join(APP_ROOT, "src", "manual-review-workbench.ts"), "utf8");
const docSource = fs.readFileSync(path.join(PROJECT_ROOT, "docs", "ROOM16_MANUAL_REVIEW_WORKBENCH_2026-05-18.md"), "utf8");

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function assertIncludes(source, needle, label) {
  assert(source.includes(needle), `${label} missing: ${needle}`);
}

const requiredStatuses = [
  "ingested",
  "audit_failed",
  "review_ready",
  "manual_review",
  "approved_internal",
  "promotion_blocked",
  "public_ready"
];

for (const status of requiredStatuses) {
  assertIncludes(helperSource, status, "helper taxonomy");
  assertIncludes(docSource, `\`${status}\``, "docs taxonomy");
}

[
  "manualReviewWorkbenchBlock",
  "manualReviewReasonLines(entry)",
  "manualReviewNextAction(entry)",
  "manualReviewGateSummary(entry)",
  "MANUAL_REVIEW_STATUS_LABELS[workbenchStatus]",
  "entry.qualityGate.effectiveVisibility"
].forEach((needle) => assertIncludes(appSource, needle, "workbench UI"));

const workbenchBlock = appSource.slice(
  appSource.indexOf("manualReviewWorkbenchBlock"),
  appSource.indexOf("mainReportLibrary")
);
assert(workbenchBlock.length > 1000, "workbench UI block should be present");
assert(!workbenchBlock.includes("updateLibraryEntry"), "workbench must not mutate public-library review state");
assert(!workbenchBlock.includes('visibility: "public"'), "workbench must not expose a public action");
assertIncludes(helperSource, "Promotion-Status prüfen, dann Operator-Go dokumentieren", "public action guard");
assertIncludes(appSource, "Manual-Review-Gründe anzeigen", "manual review operator action");
assertIncludes(appSource, "Public-Freigabe blockiert", "blocked public action copy");
assertIncludes(appSource, "Keine Anlageberatung. Interner Entwurf. Nicht public freigegeben. manual_review nicht umgehen.", "non-public safety copy");

const basePublicEntry = {
  pdfUrl: "/report.pdf",
  markdownUrl: "/report.md",
  internalBestReportUrl: "/internal.md",
  publishReportUrl: "/publish.md",
  qualityVerdict: "pass",
  qualityStatus: "pass",
  reviewStatusMetric: "pass",
  generationStage: "public_final",
  renderMode: "final_public_documents",
  finalDocumentsRendered: true,
  publicReady: true,
  promotionStatus: {
    public_ready: true,
    reviewed_by: "operator",
    approved_at: "2026-05-18T00:00:00Z",
    requested_visibility: "public",
    non_advice_confirmed: true,
    sources_human_verified: true,
    blocking_issues: []
  },
  sourceStatus: "human_verified",
  reviewStatus: "reviewed",
  nonAdvice: true,
  visibility: "public"
};

const publicReady = evaluatePublicLibraryGate(basePublicEntry);
assert(publicReady.status === "public_ready", "complete promotion packet should be public_ready");
assert(publicReady.effectiveVisibility === "public", "complete public packet may be effectively public");

const manualReview = evaluatePublicLibraryGate({
  ...basePublicEntry,
  qualityStatus: "manual_review",
  reviewStatusMetric: "manual_review"
});
assert(manualReview.status === "manual_review", "manual_review must stay manual_review");
assert(manualReview.effectiveVisibility === "hidden", "manual_review must block public visibility");
assert(manualReview.blockers.includes("manual_review_required"), "manual_review blocker must be explicit");

const markdownFirstQa = evaluatePublicLibraryGate({
  ...basePublicEntry,
  generationStage: "draft_markdown_qa",
  renderMode: "markdown_first_qa",
  finalDocumentsRendered: false,
  publicReady: false,
  publishable: false,
  publishReportUrl: null
});
assert(markdownFirstQa.status !== "public_ready", "draft_markdown_qa must not become public_ready");
assert(markdownFirstQa.effectiveVisibility === "hidden", "draft_markdown_qa must stay hidden");
assert(markdownFirstQa.blockers.includes("markdown_first_qa_not_public"), "draft_markdown_qa blocker must be explicit");

const internalBest = evaluatePublicLibraryGate({
  ...basePublicEntry,
  generationStage: "internal_best",
  visibility: "public"
});
assert(internalBest.status === "internal_only", "internal_best must remain internal_only");
assert(internalBest.effectiveVisibility === "hidden", "internal_best must stay hidden");
assert(internalBest.blockers.includes("internal_best_not_public"), "internal_best blocker must be explicit");

const missingNonAdvice = evaluatePublicLibraryGate({
  ...basePublicEntry,
  nonAdvice: false,
  promotionStatus: {
    ...basePublicEntry.promotionStatus,
    non_advice_confirmed: false
  }
});
assert(missingNonAdvice.status !== "public_ready", "missing non-advice must block public_ready");
assert(missingNonAdvice.effectiveVisibility === "hidden", "missing non-advice must stay hidden");
assert(missingNonAdvice.blockers.includes("non_advice_policy_missing"), "non-advice policy blocker must be explicit");
assert(missingNonAdvice.blockers.includes("promotion_non_advice_missing"), "promotion non-advice blocker must be explicit");

const missingHumanSourceVerification = evaluatePublicLibraryGate({
  ...basePublicEntry,
  sourceStatus: "pipeline_verified",
  promotionStatus: {
    ...basePublicEntry.promotionStatus,
    sources_human_verified: false
  }
});
assert(missingHumanSourceVerification.status !== "public_ready", "missing human source verification must block public_ready");
assert(missingHumanSourceVerification.effectiveVisibility === "hidden", "missing human source verification must stay hidden");
assert(
  missingHumanSourceVerification.blockers.includes("promotion_sources_human_verified_missing"),
  "promotion source verification blocker must be explicit"
);

console.log("Manual review workbench verifier passed.");
