import fs from "node:fs";
import path from "node:path";
import { performance } from "node:perf_hooks";
import { fileURLToPath } from "node:url";

const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const PROJECT_ROOT = path.resolve(APP_ROOT, "..");
const OUT_DIR = path.join(PROJECT_ROOT, ".runtime", "room16-app", "verification");
const BASE_URL = process.env.ROOM16_APP_BASE_URL || "http://127.0.0.1:4516";
const TICKER_ALIAS_PATH = path.join(APP_ROOT, "src", "ticker-aliases.json");
const MODEL_PROFILE_PATH = path.join(APP_ROOT, "src", "model-profiles.json");
const HARDENING_MAX_AGE_MINUTES = Number(process.env.ROOM16_HARDENING_MAX_AGE_MINUTES || "30");
const SKIP_HARDENING_STATE_CHECKS = /^(1|true|yes)$/i.test(String(process.env.ROOM16_VERIFY_SKIP_HARDENING_STATE || ""));
const EXPECTED_WORKFLOW_STEPS = [
  "intake",
  "queue",
  "research",
  "source_ledger",
  "manifest",
  "dossier",
  "quality_gate",
  "shelf",
  "publish_gate"
];

const startedAt = new Date();
const checks = [];

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function addCheck(name, status, details = {}) {
  checks.push({
    name,
    status,
    details
  });
}

function assertCheck(name, condition, details = {}) {
  addCheck(name, condition ? "pass" : "fail", details);
  if (!condition) {
    throw new Error(`${name} failed`);
  }
}

function readJsonIfExists(relativePath) {
  const fullPath = path.join(PROJECT_ROOT, relativePath);
  if (!fs.existsSync(fullPath)) {
    return null;
  }
  return JSON.parse(fs.readFileSync(fullPath, "utf8"));
}

function artifactDeferred(value) {
  return value == null || value?.rendered === false;
}

async function timedFetch(url, options) {
  const started = performance.now();
  const response = await fetch(url, options);
  const elapsedMs = Math.round(performance.now() - started);
  return { response, elapsedMs };
}

async function fetchJson(route) {
  const { response, elapsedMs } = await timedFetch(`${BASE_URL}${route}`);
  const text = await response.text();
  let payload = null;
  try {
    payload = JSON.parse(text);
  } catch {
    // Keep payload null; the caller will fail with the raw prefix.
  }
  return { response, payload, text, elapsedMs };
}

async function main() {
  ensureDir(OUT_DIR);

  const aliasPairs = JSON.parse(fs.readFileSync(TICKER_ALIAS_PATH, "utf8"));
  const modelProfilesFromDisk = JSON.parse(fs.readFileSync(MODEL_PROFILE_PATH, "utf8"));
  const aliasMap = new Map(
    aliasPairs.map(([name, ticker]) => [
      String(name || "")
        .trim()
        .toUpperCase()
        .replace(/[^A-Z0-9._-]/g, ""),
      ticker
    ])
  );
  assertCheck("ticker_alias_shell_ok", aliasMap.get("SHELL") === "SHEL", {
    ticker: aliasMap.get("SHELL") || null
  });
  assertCheck("ticker_alias_palantir_ok", aliasMap.get("PALANTIR") === "PLTR", {
    ticker: aliasMap.get("PALANTIR") || null
  });
  assertCheck("ticker_alias_microsoft_ok", aliasMap.get("MICROSOFT") === "MSFT", {
    ticker: aliasMap.get("MICROSOFT") || null
  });
  assertCheck("ticker_alias_datadog_ok", aliasMap.get("DATADOG") === "DDOG", {
    ticker: aliasMap.get("DATADOG") || null
  });
  assertCheck("ticker_alias_mongodb_ok", aliasMap.get("MONGODB") === "MDB", {
    ticker: aliasMap.get("MONGODB") || null
  });
  const safeModelProfiles = modelProfilesFromDisk.filter((profile) => !profile.requiresPaidConfirmation);
  assertCheck("model_profiles_have_safe_compare_options", safeModelProfiles.length >= 2, {
    profiles: modelProfilesFromDisk.map((profile) => profile.id)
  });
  assertCheck("kimi_removed_from_active_model_profiles", !modelProfilesFromDisk.some((profile) => /kimi/i.test(`${profile.id} ${profile.label}`)), {
    profiles: modelProfilesFromDisk.map((profile) => profile.id)
  });
  assertCheck("deepseek_profile_is_ollama_cloud", modelProfilesFromDisk.some((profile) =>
    profile.id === "deepseek-v4-ollama" &&
    profile.provider === "ollama" &&
    String(profile.deepModel || "").endsWith(":cloud") &&
    /cloud/i.test(`${profile.label} ${profile.track} ${profile.badge} ${(profile.tags || []).join(" ")}`)
  ), {
    profile: modelProfilesFromDisk.find((profile) => profile.id === "deepseek-v4-ollama") || null
  });

  const health = await fetchJson("/api/health");
  assertCheck("health_http_ok", health.response.ok, {
    status: health.response.status,
    elapsedMs: health.elapsedMs
  });
  assertCheck("health_json_ok", Boolean(health.payload?.ok), {
    payloadPrefix: health.text.slice(0, 120)
  });
  assertCheck("preflight_ok", Boolean(health.payload?.preflight?.ok), {
    checks: health.payload?.preflight?.checks || []
  });
  assertCheck("preflight_exposes_runtime_timeouts", (health.payload?.preflight?.checks || []).some((check) =>
    check.name === "runtime_timeouts" && /llm=\d+s ticker=\d+s(?: stall=\d+s)? retries=\d+ retry_delay=\d+s/.test(String(check.detail || ""))
  ), {
    checks: health.payload?.preflight?.checks || []
  });
  if (SKIP_HARDENING_STATE_CHECKS) {
    addCheck("hardening_state_checks_skipped_for_cycle", "pass", {
      reason: "hardening loop verifies build/API first, then writes the new screenshot verdict"
    });
  } else {
    assertCheck("hardening_state_exposed", Boolean(health.payload?.hardening), {
      verdict: health.payload?.hardening?.verdict || null,
      latestCycleId: health.payload?.hardening?.latestCycleId || null
    });
    assertCheck("hardening_state_latest_verdict_pass", health.payload?.hardening?.verdict === "pass", {
      verdict: health.payload?.hardening?.verdict || null,
      latestCycleId: health.payload?.hardening?.latestCycleId || null
    });
    const hardeningCreatedAt = health.payload?.hardening?.createdAt ? new Date(health.payload.hardening.createdAt) : null;
    const hardeningAgeMinutes = hardeningCreatedAt
      ? Math.round((Date.now() - hardeningCreatedAt.getTime()) / 60000)
      : null;
    assertCheck("hardening_state_is_fresh", Boolean(hardeningCreatedAt) && hardeningAgeMinutes <= HARDENING_MAX_AGE_MINUTES, {
      latestCycleId: health.payload?.hardening?.latestCycleId || null,
      createdAt: health.payload?.hardening?.createdAt || null,
      ageMinutes: hardeningAgeMinutes,
      maxAgeMinutes: HARDENING_MAX_AGE_MINUTES
    });
  }
  assertCheck("health_exposes_library_summary", Number(health.payload?.reportLibrary?.summary?.totalReports || 0) >= 5, {
    summary: health.payload?.reportLibrary?.summary || null
  });
  assertCheck("admin_health_does_not_expose_membership_pricing", !health.text.includes("membershipScope") && !health.text.includes("monthlyPrice"), {
    exposedMembershipScope: Boolean(health.payload?.membershipScope),
    exposedMonthlyPrice: health.text.includes("monthlyPrice")
  });

  const state = await fetchJson("/api/state");
  assertCheck("state_http_ok", state.response.ok, {
    status: state.response.status,
    elapsedMs: state.elapsedMs
  });
  const companies = Array.isArray(state.payload?.companies) ? state.payload.companies : [];
  assertCheck("state_has_companies", companies.length > 0, { count: companies.length });
  assertCheck("state_has_jobs_array", Array.isArray(state.payload?.jobs), {
    jobCount: state.payload?.jobs?.length ?? null
  });
  const stateJobs = Array.isArray(state.payload?.jobs) ? state.payload.jobs : [];
  assertCheck("state_jobs_expose_report_workflow_checklists", stateJobs.length === 0 || stateJobs.every((job) => {
    const stepIds = Array.isArray(job.workflow) ? job.workflow.map((step) => step.id) : [];
    return EXPECTED_WORKFLOW_STEPS.every((stepId) => stepIds.includes(stepId)) &&
      Number.isFinite(Number(job.workflowProgress?.total));
  }), {
    jobCount: stateJobs.length,
    sample: stateJobs[0]
      ? {
          ticker: stateJobs[0].ticker,
          workflow: stateJobs[0].workflow?.map((step) => `${step.id}:${step.status}`),
          progress: stateJobs[0].workflowProgress
        }
      : null
  });
  assertCheck("state_exposes_ticker_alias_stats", Number(state.payload?.tickerAliases?.aliasEntries || 0) >= 30, {
    tickerAliases: state.payload?.tickerAliases || null
  });
  assertCheck("state_exposes_model_profiles", Array.isArray(state.payload?.modelProfiles) && state.payload.modelProfiles.length >= 3, {
    profiles: state.payload?.modelProfiles?.map((profile) => profile.id) || []
  });
  assertCheck("state_hides_kimi_from_model_profiles", !(state.payload?.modelProfiles || []).some((profile) => /kimi/i.test(`${profile.id} ${profile.label}`)), {
    profiles: state.payload?.modelProfiles?.map((profile) => profile.id) || []
  });
  assertCheck("state_exposes_default_model_profile", Boolean(state.payload?.defaults?.modelProfileId), {
    defaultModelProfileId: state.payload?.defaults?.modelProfileId || null
  });
  assertCheck("state_exposes_comparisons_array", Array.isArray(state.payload?.comparisons), {
    comparisonCount: state.payload?.comparisons?.length ?? null
  });
  assertCheck("state_comparisons_are_status_enriched", (state.payload?.comparisons || []).every((comparison) => comparison.status && comparison.counts), {
    comparisonCount: state.payload?.comparisons?.length ?? null
  });
  assertCheck("state_exposes_public_report_library", Number(state.payload?.reportLibrary?.summary?.totalReports || 0) >= 5, {
    summary: state.payload?.reportLibrary?.summary || null
  });
  assertCheck("admin_state_does_not_expose_membership_pricing", !state.text.includes("membershipScope") && !state.text.includes("monthlyPrice"), {
    exposedMembershipScope: Boolean(state.payload?.membershipScope),
    exposedMonthlyPrice: state.text.includes("monthlyPrice")
  });
  assertCheck("state_exposes_report_machine", typeof state.payload?.reportMachine?.ready === "boolean", {
    reportMachine: state.payload?.reportMachine || null
  });

  const reportMachine = await fetchJson("/api/report-machine");
  const machine = reportMachine.payload?.reportMachine || {};
  assertCheck("report_machine_http_ok", reportMachine.response.ok, {
    status: reportMachine.response.status,
    elapsedMs: reportMachine.elapsedMs
  });
  assertCheck("report_machine_policy_enforces_model_truth", Boolean(
    machine.policy?.activeModelsExcludeKimiAndGpt55 &&
    machine.policy?.deepseekIsOllamaCloud
  ), {
    policy: machine.policy || null
  });
  assertCheck("report_machine_policy_exposes_full_workflow", EXPECTED_WORKFLOW_STEPS.every((stepId) =>
    Array.isArray(machine.policy?.reportFlow) && machine.policy.reportFlow.includes(stepId)
  ), {
    reportFlow: machine.policy?.reportFlow || null,
    reportFlowLabels: machine.policy?.reportFlowLabels || null
  });
  assertCheck("report_machine_recovery_counts_available", Number.isFinite(Number(machine.recoverableJobs)), {
    recoverableJobs: machine.recoverableJobs ?? null,
    recoverableByTicker: machine.recoverableByTicker || null
  });

  const publicLibrary = await fetchJson("/api/public-library");
  const libraryEntries = Array.isArray(publicLibrary.payload?.reportLibrary?.entries)
    ? publicLibrary.payload.reportLibrary.entries
    : [];
  assertCheck("public_library_http_ok", publicLibrary.response.ok, {
    status: publicLibrary.response.status,
    elapsedMs: publicLibrary.elapsedMs
  });
  assertCheck("public_library_has_minimum_seed_reports", libraryEntries.length >= 5, {
    count: libraryEntries.length,
    tickers: [...new Set(libraryEntries.map((entry) => entry.ticker))]
  });
  assertCheck("public_library_entries_have_quality_gate", libraryEntries.every((entry) => entry.qualityGate?.status && entry.qualityGate?.effectiveVisibility), {
    sample: libraryEntries.slice(0, 3).map((entry) => ({
      ticker: entry.ticker,
      status: entry.qualityGate?.status || null,
      effectiveVisibility: entry.qualityGate?.effectiveVisibility || null
    }))
  });
  assertCheck("public_library_public_visibility_is_gate_locked", libraryEntries.every((entry) => {
    return entry.qualityGate?.effectiveVisibility !== "public" || entry.qualityGate?.status === "public_ready";
  }), {
    effectivePublic: libraryEntries.filter((entry) => entry.qualityGate?.effectiveVisibility === "public").length
  });
  assertCheck("public_library_member_visibility_is_gate_locked", libraryEntries.every((entry) => {
    return entry.qualityGate?.effectiveVisibility !== "member" || entry.qualityGate?.memberReady === true;
  }), {
    effectiveMember: libraryEntries.filter((entry) => entry.qualityGate?.effectiveVisibility === "member").length
  });
  const markdownQaEntries = libraryEntries.filter((entry) =>
    entry.generationStage === "draft_markdown_qa" || entry.renderMode === "markdown_first_qa"
  );
  assertCheck("markdown_first_qa_entries_are_not_public_ready", markdownQaEntries.every((entry) => {
    return entry.publicReady === false &&
      entry.publishable === false &&
      entry.finalDocumentsRendered === false &&
      entry.scoreScope === "markdown_qa" &&
      entry.publicRating == null &&
      entry.publishReportUrl == null &&
      entry.qualityGate?.status !== "public_ready" &&
      entry.qualityGate?.effectiveVisibility !== "public";
  }), {
    count: markdownQaEntries.length,
    sample: markdownQaEntries.slice(0, 3).map((entry) => ({
      ticker: entry.ticker,
      generationStage: entry.generationStage,
      renderMode: entry.renderMode,
      publishable: entry.publishable,
      publicReady: entry.publicReady,
      finalDocumentsRendered: entry.finalDocumentsRendered,
      scoreScope: entry.scoreScope,
      publicRating: entry.publicRating,
      publishReportUrl: entry.publishReportUrl,
      gate: entry.qualityGate
    }))
  });
  const pltrMarkdownSmoke = readJsonIfExists("outputs/release/MARKET_READY_PILOT_PACKAGE/SAMPLE_ARTIFACTS/PLTR_markdown_first_qa/quality_report.json") ||
    readJsonIfExists("outputs/review_bundles/room16_markdown_first_qa/smoke/quality_report.json");
  assertCheck("pltr_markdown_first_smoke_status_rules", Boolean(
    pltrMarkdownSmoke &&
    pltrMarkdownSmoke.generation_stage === "draft_markdown_qa" &&
    pltrMarkdownSmoke.render_mode === "markdown_first_qa" &&
    (pltrMarkdownSmoke.quality_verdict || pltrMarkdownSmoke.verdict) === "pass" &&
    (pltrMarkdownSmoke.score_scope || pltrMarkdownSmoke.metrics?.score_scope) === "markdown_qa" &&
    (pltrMarkdownSmoke.promotion_gate_verdict || pltrMarkdownSmoke.metrics?.promotion_gate_verdict) === "not_run" &&
    ["not_run", "not_applicable"].includes(pltrMarkdownSmoke.publish_gate_verdict || pltrMarkdownSmoke.metrics?.publish_gate_verdict) &&
    (pltrMarkdownSmoke.public_ready ?? pltrMarkdownSmoke.metrics?.public_ready) === false &&
    (pltrMarkdownSmoke.metrics?.final_documents_rendered) === false &&
    (pltrMarkdownSmoke.metrics?.public_rating ?? null) == null &&
    artifactDeferred(pltrMarkdownSmoke.artifacts?.complete_pdf) &&
    artifactDeferred(pltrMarkdownSmoke.artifacts?.complete_docx) &&
    Number(pltrMarkdownSmoke.metrics?.complete_pdf_words || 0) === 0 &&
    Number(pltrMarkdownSmoke.metrics?.complete_docx_words || 0) === 0
  ), {
    sample: pltrMarkdownSmoke
      ? {
          generationStage: pltrMarkdownSmoke.generation_stage,
          renderMode: pltrMarkdownSmoke.render_mode,
          qualityVerdict: pltrMarkdownSmoke.quality_verdict || pltrMarkdownSmoke.verdict,
          scoreScope: pltrMarkdownSmoke.score_scope || pltrMarkdownSmoke.metrics?.score_scope,
          publishGate: pltrMarkdownSmoke.publish_gate_verdict || pltrMarkdownSmoke.metrics?.publish_gate_verdict,
          promotionGate: pltrMarkdownSmoke.promotion_gate_verdict || pltrMarkdownSmoke.metrics?.promotion_gate_verdict,
          artifacts: {
            completePdf: pltrMarkdownSmoke.artifacts?.complete_pdf,
            completeDocx: pltrMarkdownSmoke.artifacts?.complete_docx
          }
        }
      : null
  });
  assertCheck("public_ready_requires_promotion_status", libraryEntries.every((entry) => {
    if (entry.qualityGate?.status !== "public_ready") return true;
    return entry.generationStage === "public_final" &&
      entry.finalDocumentsRendered === true &&
      Boolean(entry.publishReportUrl) &&
      entry.publicReady === true &&
      entry.promotionStatus?.public_ready === true &&
      Boolean(entry.promotionStatus?.reviewed_by) &&
      Boolean(entry.promotionStatus?.approved_at) &&
      entry.promotionStatus?.requested_visibility === "public" &&
      entry.promotionStatus?.non_advice_confirmed === true &&
      entry.promotionStatus?.sources_human_verified === true &&
      (!Array.isArray(entry.promotionStatus?.blocking_issues) || entry.promotionStatus.blocking_issues.length === 0);
  }), {
    publicReady: libraryEntries
      .filter((entry) => entry.qualityGate?.status === "public_ready")
      .map((entry) => ({
        ticker: entry.ticker,
        generationStage: entry.generationStage,
        finalDocumentsRendered: entry.finalDocumentsRendered,
        publicReady: entry.publicReady,
        publishReportUrl: entry.publishReportUrl,
        promotionStatus: entry.promotionStatus
      }))
  });
  assertCheck("public_library_does_not_expose_membership_pricing", !publicLibrary.text.includes("membershipScope") && !publicLibrary.text.includes("monthlyPrice"), {
    exposedMembershipScope: Boolean(publicLibrary.payload?.reportLibrary?.membershipScope),
    exposedMonthlyPrice: publicLibrary.text.includes("monthlyPrice")
  });
  const removedMembershipScope = await timedFetch(`${BASE_URL}/api/membership-scope`);
  assertCheck("admin_membership_scope_endpoint_removed", removedMembershipScope.response.status === 404, {
    status: removedMembershipScope.response.status
  });

  const palantirResolution = await fetchJson("/api/symbols/resolve?q=palantir");
  assertCheck("symbol_resolve_palantir_ok", palantirResolution.response.ok && palantirResolution.payload?.resolution?.ticker === "PLTR", {
    status: palantirResolution.response.status,
    resolution: palantirResolution.payload?.resolution || null
  });
  const datadogResolution = await fetchJson("/api/symbols/resolve?q=datadog");
  assertCheck("symbol_resolve_datadog_ok", datadogResolution.response.ok && datadogResolution.payload?.resolution?.ticker === "DDOG", {
    status: datadogResolution.response.status,
    resolution: datadogResolution.payload?.resolution || null
  });
  const mongodbResolution = await fetchJson("/api/symbols/resolve?q=mongodb");
  assertCheck("symbol_resolve_mongodb_ok", mongodbResolution.response.ok && mongodbResolution.payload?.resolution?.ticker === "MDB", {
    status: mongodbResolution.response.status,
    resolution: mongodbResolution.payload?.resolution || null
  });

  const jobs = Array.isArray(state.payload?.jobs) ? state.payload.jobs : [];
  const jobWithFailure = jobs.find((job) => job.failureReportId);
  if (jobWithFailure) {
    const failureReport = await timedFetch(`${BASE_URL}/api/failures/${jobWithFailure.failureReportId}`);
    const failureText = await failureReport.response.text();
    assertCheck("failure_report_endpoint_ok", failureReport.response.ok, {
      status: failureReport.response.status,
      ticker: jobWithFailure.ticker,
      chars: failureText.length
    });
    assertCheck("failure_report_endpoint_readable", failureText.includes("Fehlerbericht") && failureText.includes(jobWithFailure.ticker), {
      ticker: jobWithFailure.ticker
    });
  }

  const companiesWithReports = companies.filter((company) => company.latestReport?.id);
  assertCheck("companies_have_reports", companiesWithReports.length > 0, {
    count: companiesWithReports.length,
    tickers: companiesWithReports.map((company) => company.ticker)
  });
  const amazon = companies.find((company) => company.ticker === "AMZN");
  const amazonReports = Array.isArray(amazon?.reports) ? amazon.reports : [];
  const amazonReportNames = amazonReports.map((report) => report.fileName);
  assertCheck("amazon_reports_visible_in_company_payload", amazonReportNames.length >= 2, {
    reportCount: amazon?.reportCount || 0,
    reports: amazonReportNames
  });
  assertCheck(
    "amazon_model_reports_are_separate",
    amazonReportNames.some((name) => /DeepSeek V4/i.test(name)) && amazonReportNames.some((name) => /Kimi K2\.6/i.test(name)),
    { reports: amazonReportNames }
  );
  const amazonDeepSeekReport = amazonReports.find((report) => /DeepSeek V4/i.test(report.fileName || ""));
  const amazonKimiReport = amazonReports.find((report) => /Kimi K2\.6/i.test(report.fileName || ""));
  const amazonMarkdownUrls = [amazonDeepSeekReport?.markdownUrl, amazonKimiReport?.markdownUrl].filter(Boolean);
  const reportQualityVerdict = (report) => report?.qualityVerdict || report?.quality?.qualityVerdict || report?.quality?.qualityDecision?.quality_verdict || null;
  const amazonFailedReports = [amazonDeepSeekReport, amazonKimiReport].filter((report) => reportQualityVerdict(report) === "fail");
  assertCheck("amazon_report_markdown_urls_exist", amazonMarkdownUrls.length >= 1 && amazonFailedReports.every((report) => !report.markdownUrl), {
    reports: amazonReports.map((report) => ({
      fileName: report.fileName,
      qualityVerdict: reportQualityVerdict(report),
      markdownUrl: report.markdownUrl || null
    }))
  });
  assertCheck("amazon_report_markdown_urls_are_model_specific", new Set(amazonMarkdownUrls).size === amazonMarkdownUrls.length, {
    markdownUrls: amazonMarkdownUrls
  });
  const amazonDeepSeekMarkdown = amazonDeepSeekReport?.markdownUrl
    ? await timedFetch(new URL(amazonDeepSeekReport.markdownUrl, BASE_URL).toString())
    : null;
  const amazonDeepSeekMarkdownText = amazonDeepSeekMarkdown ? await amazonDeepSeekMarkdown.response.text() : "";
  const amazonKimiMarkdown = amazonKimiReport?.markdownUrl
    ? await timedFetch(new URL(amazonKimiReport.markdownUrl, BASE_URL).toString())
    : null;
  const amazonKimiMarkdownText = amazonKimiMarkdown ? await amazonKimiMarkdown.response.text() : "";
  assertCheck(
    "amazon_deepseek_markdown_is_report_specific",
    reportQualityVerdict(amazonDeepSeekReport) === "fail"
      ? !amazonDeepSeekReport.markdownUrl
      : Boolean(amazonDeepSeekMarkdown?.response.ok && /deepseek/i.test(amazonDeepSeekMarkdownText)),
    {
      qualityVerdict: reportQualityVerdict(amazonDeepSeekReport),
      status: amazonDeepSeekMarkdown?.response.status || null,
      chars: amazonDeepSeekMarkdownText.length
    }
  );
  assertCheck("amazon_kimi_markdown_is_report_specific", amazonKimiMarkdown?.response.ok && /kimi/i.test(amazonKimiMarkdownText), {
    status: amazonKimiMarkdown?.response.status || null,
    chars: amazonKimiMarkdownText.length
  });
  assertCheck("amazon_model_markdown_texts_are_distinct", !amazonDeepSeekMarkdownText || amazonDeepSeekMarkdownText !== amazonKimiMarkdownText, {
    deepSeekChars: amazonDeepSeekMarkdownText.length,
    kimiChars: amazonKimiMarkdownText.length
  });

  const latest = companiesWithReports[0];
  const latestReport = await fetchJson(`/api/reports/latest/${latest.ticker}`);
  assertCheck("latest_report_json_ok", latestReport.response.ok && latestReport.payload?.report?.id, {
    status: latestReport.response.status,
    ticker: latest.ticker,
    reportTitle: latestReport.payload?.report?.title || null
  });

  if (latest.latestReport?.url) {
    const latestPdf = await timedFetch(`${BASE_URL}/api/reports/latest/${latest.ticker}/pdf`);
    const latestPdfType = latestPdf.response.headers.get("content-type") || "";
    const latestPdfBytes = Buffer.from(await latestPdf.response.arrayBuffer()).length;
    assertCheck("latest_report_pdf_ok", latestPdf.response.ok, {
      status: latestPdf.response.status,
      ticker: latest.ticker,
      elapsedMs: latestPdf.elapsedMs
    });
    assertCheck("latest_report_pdf_type", latestPdfType.includes("application/pdf"), {
      contentType: latestPdfType
    });
    assertCheck("latest_report_pdf_nontrivial_size", latestPdfBytes > 10_000, {
      bytes: latestPdfBytes
    });
  } else {
    addCheck("latest_report_pdf_deferred_for_markdown_first_qa", "pass", {
      ticker: latest.ticker,
      reportTitle: latest.latestReport?.title || null
    });
  }

  const latestMarkdown = await timedFetch(`${BASE_URL}/api/reports/latest/${latest.ticker}/markdown`);
  const markdownText = await latestMarkdown.response.text();
  assertCheck("latest_report_markdown_ok", latestMarkdown.response.ok, {
    status: latestMarkdown.response.status,
    ticker: latest.ticker,
    elapsedMs: latestMarkdown.elapsedMs
  });
  assertCheck("latest_report_markdown_readable", markdownText.length > 10_000 && markdownText.includes(latest.ticker), {
    chars: markdownText.length,
    includesTicker: markdownText.includes(latest.ticker)
  });

  if (latest.latestReport?.url) {
    const reportUrl = `${BASE_URL}/api/reports/${latest.latestReport.id}`;
    const report = await timedFetch(reportUrl);
    const contentType = report.response.headers.get("content-type") || "";
    const bytes = Buffer.from(await report.response.arrayBuffer()).length;
    assertCheck("pdf_endpoint_ok", report.response.ok, {
      status: report.response.status,
      ticker: latest.ticker,
      elapsedMs: report.elapsedMs
    });
    assertCheck("pdf_content_type", contentType.includes("application/pdf"), {
      contentType
    });
    assertCheck("pdf_nontrivial_size", bytes > 10_000, { bytes });
  } else {
    addCheck("pdf_endpoint_deferred_for_markdown_first_qa", "pass", {
      ticker: latest.ticker,
      reportTitle: latest.latestReport?.title || null
    });
  }

  const outsideFileId = Buffer.from("/etc/passwd", "utf8").toString("base64url");
  const outsideFile = await timedFetch(`${BASE_URL}/api/reports/${outsideFileId}`);
  assertCheck("outside_report_path_rejected", outsideFile.response.status === 404, {
    status: outsideFile.response.status
  });

  const badJob = await timedFetch(`${BASE_URL}/api/jobs`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ticker: "" })
  });
  const badJobText = await badJob.response.text();
  assertCheck("invalid_job_rejected", badJob.response.status === 400, {
    status: badJob.response.status,
    bodyPrefix: badJobText.slice(0, 160)
  });

  const paidProviderJob = await timedFetch(`${BASE_URL}/api/jobs`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      ticker: "MSFT",
      provider: "openrouter",
      quickModel: "deepseek/deepseek-chat",
      deepModel: "deepseek/deepseek-chat"
    })
  });
  const paidProviderJobText = await paidProviderJob.response.text();
  assertCheck("paid_provider_requires_explicit_confirmation", paidProviderJob.response.status === 402, {
    status: paidProviderJob.response.status,
    bodyPrefix: paidProviderJobText.slice(0, 180)
  });

  const paidProfileJob = await timedFetch(`${BASE_URL}/api/jobs`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      ticker: "MSFT",
      modelProfileId: "openrouter-deepseek-chat"
    })
  });
  const paidProfileJobText = await paidProfileJob.response.text();
  assertCheck("paid_model_profile_requires_explicit_confirmation", paidProfileJob.response.status === 402, {
    status: paidProfileJob.response.status,
    bodyPrefix: paidProfileJobText.slice(0, 180)
  });

  const invalidComparison = await timedFetch(`${BASE_URL}/api/comparisons`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      ticker: "MSFT",
      modelProfileIds: ["deepseek-v4-ollama"]
    })
  });
  const invalidComparisonText = await invalidComparison.response.text();
  assertCheck("invalid_comparison_rejected", invalidComparison.response.status === 400, {
    status: invalidComparison.response.status,
    bodyPrefix: invalidComparisonText.slice(0, 160)
  });

  const missingComparison = await timedFetch(`${BASE_URL}/api/comparisons/does-not-exist`);
  const missingComparisonText = await missingComparison.response.text();
  assertCheck("missing_comparison_detail_rejected", missingComparison.response.status === 404, {
    status: missingComparison.response.status,
    bodyPrefix: missingComparisonText.slice(0, 160)
  });

  const missingComparisonEvaluation = await timedFetch(`${BASE_URL}/api/comparisons/does-not-exist/evaluate`, {
    method: "POST"
  });
  const missingComparisonEvaluationText = await missingComparisonEvaluation.response.text();
  assertCheck("missing_comparison_evaluation_rejected", missingComparisonEvaluation.response.status === 404, {
    status: missingComparisonEvaluation.response.status,
    bodyPrefix: missingComparisonEvaluationText.slice(0, 160)
  });

  const missingCancel = await timedFetch(`${BASE_URL}/api/jobs/does-not-exist/cancel`, {
    method: "POST"
  });
  const missingCancelText = await missingCancel.response.text();
  assertCheck("missing_job_cancel_rejected", missingCancel.response.status === 404, {
    status: missingCancel.response.status,
    bodyPrefix: missingCancelText.slice(0, 160)
  });

  const missingDelete = await timedFetch(`${BASE_URL}/api/jobs/does-not-exist`, {
    method: "DELETE"
  });
  const missingDeleteText = await missingDelete.response.text();
  assertCheck("missing_job_delete_rejected", missingDelete.response.status === 404, {
    status: missingDelete.response.status,
    bodyPrefix: missingDeleteText.slice(0, 160)
  });

  const missingLibraryDelete = await timedFetch(`${BASE_URL}/api/public-library/does-not-exist`, {
    method: "DELETE"
  });
  const missingLibraryDeleteText = await missingLibraryDelete.response.text();
  assertCheck("missing_public_library_delete_rejected", missingLibraryDelete.response.status === 404, {
    status: missingLibraryDelete.response.status,
    bodyPrefix: missingLibraryDeleteText.slice(0, 160)
  });

  const summary = {
    createdAt: new Date().toISOString(),
    baseUrl: BASE_URL,
    verdict: checks.every((check) => check.status === "pass") ? "pass" : "fail",
    elapsedMs: Date.now() - startedAt.getTime(),
    companyCount: companies.length,
    tickers: companies.map((company) => company.ticker),
    checks
  };

  const jsonPath = path.join(OUT_DIR, "last-verification.json");
  const mdPath = path.join(OUT_DIR, "last-verification.md");
  fs.writeFileSync(jsonPath, JSON.stringify(summary, null, 2), "utf8");
  fs.writeFileSync(
    mdPath,
    [
      "# Room 16 App Verification",
      "",
      `Created: ${summary.createdAt}`,
      `Base URL: ${summary.baseUrl}`,
      `Verdict: ${summary.verdict}`,
      `Companies: ${summary.companyCount} (${summary.tickers.join(", ")})`,
      "",
      "## Checks",
      "",
      ...checks.map((check) => `- ${check.status === "pass" ? "PASS" : "FAIL"} ${check.name}: ${JSON.stringify(check.details)}`)
    ].join("\n"),
    "utf8"
  );

  console.log(JSON.stringify(summary, null, 2));
  if (summary.verdict !== "pass") {
    process.exitCode = 1;
  }
}

main().catch((error) => {
  addCheck("verifier_exception", "fail", { message: error.message });
  ensureDir(OUT_DIR);
  const summary = {
    createdAt: new Date().toISOString(),
    baseUrl: BASE_URL,
    verdict: "fail",
    error: error.message,
    checks
  };
  fs.writeFileSync(path.join(OUT_DIR, "last-verification.json"), JSON.stringify(summary, null, 2), "utf8");
  console.error(error.message);
  process.exit(1);
});
