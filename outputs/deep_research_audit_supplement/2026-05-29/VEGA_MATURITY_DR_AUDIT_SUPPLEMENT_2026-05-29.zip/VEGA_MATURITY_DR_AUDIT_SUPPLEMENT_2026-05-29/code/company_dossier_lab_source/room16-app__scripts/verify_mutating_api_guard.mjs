import { createMutatingApiGuard, isNetworkHost } from "../server-modules/mutating-api-guard.mjs";

assertEqual(isNetworkHost("127.0.0.1"), false, "localhost is local");
assertEqual(isNetworkHost("localhost"), false, "localhost name is local");
assertEqual(isNetworkHost("0.0.0.0"), true, "0.0.0.0 is network host");

const localGuard = createMutatingApiGuard({ host: "127.0.0.1", env: {} });
assertEqual(localGuard(fakeReq({}), fakeRes()), true, "localhost without token remains usable");

const tokenGuard = createMutatingApiGuard({
  host: "127.0.0.1",
  env: { ROOM16_API_TOKEN: "secret-token" },
});
assertEqual(tokenGuard(fakeReq({}), fakeRes()), false, "token-enabled guard blocks missing token");
assertEqual(
  tokenGuard(fakeReq({ authorization: "Bearer secret-token" }), fakeRes()),
  true,
  "bearer token passes",
);
assertEqual(
  tokenGuard(fakeReq({ "x-room16-api-token": "secret-token" }), fakeRes()),
  true,
  "x-room16-api-token passes",
);

console.log("Room16 mutating API guard check passed.");

function fakeReq(headers) {
  return {
    get(name) {
      return headers[name.toLowerCase()] || "";
    },
  };
}

function fakeRes() {
  return {
    statusCode: 200,
    payload: null,
    status(code) {
      this.statusCode = code;
      return this;
    },
    json(payload) {
      this.payload = payload;
      return this;
    },
  };
}

function assertEqual(actual, expected, label) {
  if (actual !== expected) {
    throw new Error(`${label}: expected ${expected}, got ${actual}`);
  }
}
