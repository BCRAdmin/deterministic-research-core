import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const PROJECT_ROOT = path.resolve(APP_ROOT, "..");
const STYLES_PATH = path.join(APP_ROOT, "src", "styles.css");
const HARDENING_ROOT = path.join(PROJECT_ROOT, ".runtime", "room16-app", "hardening");
const LATEST_CYCLE_PATH = path.join(HARDENING_ROOT, "latest-cycle.json");

const REQUIRED_SCREENSHOTS = {
  "desktop.png": [1280, 720],
  "medium-edge.png": [1360, 720],
  "rail-edge.png": [1761, 720],
  "reader-desktop.png": [1280, 720],
  "mobile.png": [390, 844],
  "reader-mobile.png": [390, 844]
};

const checks = [];

function argValue(name, fallback = null) {
  const index = process.argv.indexOf(name);
  return index >= 0 ? process.argv[index + 1] : fallback;
}

function addCheck(name, status, details = {}) {
  checks.push({ name, status, details });
}

function assertCheck(name, condition, details = {}) {
  addCheck(name, condition ? "pass" : "fail", details);
  if (!condition) {
    throw new Error(`${name} failed`);
  }
}

function readPngSize(filePath) {
  const header = fs.readFileSync(filePath).subarray(0, 24);
  const pngSignature = "89504e470d0a1a0a";
  if (header.subarray(0, 8).toString("hex") !== pngSignature) {
    throw new Error(`${filePath} is not a PNG`);
  }
  return {
    width: header.readUInt32BE(16),
    height: header.readUInt32BE(20)
  };
}

function ruleBlock(css, selector, media = null) {
  const startAt = media ? css.indexOf(media) : 0;
  if (startAt < 0) return "";
  const selectorAt = css.indexOf(selector, startAt);
  if (selectorAt < 0) return "";
  const openAt = css.indexOf("{", selectorAt);
  if (openAt < 0) return "";
  let depth = 0;
  for (let index = openAt; index < css.length; index += 1) {
    const char = css[index];
    if (char === "{") depth += 1;
    if (char === "}") {
      depth -= 1;
      if (depth === 0) {
        return css.slice(openAt + 1, index);
      }
    }
  }
  return "";
}

function main() {
  const css = fs.readFileSync(STYLES_PATH, "utf8");
  const mobileMedia = "@media (max-width: 760px)";
  const mobileForm = ruleBlock(css, ".newReportForm", mobileMedia);
  const mobilePrimary = ruleBlock(css, ".primaryButton", mobileMedia);
  const mobileReader = ruleBlock(css, ".readerView", mobileMedia);
  const mobileReaderHeader = ruleBlock(css, ".readerHeader", mobileMedia);
  const mobileReaderHeaderButton = ruleBlock(css, ".readerHeader .ghostButton", mobileMedia);

  assertCheck("mobile_form_uses_two_column_grid", /display:\s*grid/.test(mobileForm) && /grid-template-columns:\s*minmax\(0,\s*1fr\)\s+minmax\(0,\s*1fr\)/.test(mobileForm), {
    block: mobileForm.trim()
  });
  assertCheck("mobile_submit_button_spans_form_width", /grid-column:\s*1\s*\/\s*-1/.test(mobilePrimary) && /width:\s*100%/.test(mobilePrimary), {
    block: mobilePrimary.trim()
  });
  assertCheck("mobile_reader_has_auto_header_row", /grid-template-rows:\s*auto\s+minmax\(0,\s*1fr\)/.test(mobileReader) && /min-height:\s*80vh/.test(mobileReader), {
    block: mobileReader.trim()
  });
  assertCheck("mobile_reader_header_is_single_column", /grid-template-columns:\s*minmax\(0,\s*1fr\)/.test(mobileReaderHeader), {
    block: mobileReaderHeader.trim()
  });
  assertCheck("mobile_reader_header_buttons_are_full_width", /width:\s*100%/.test(mobileReaderHeaderButton), {
    block: mobileReaderHeaderButton.trim()
  });

  const screenshotDirArg = argValue("--screenshot-dir");
  if (screenshotDirArg) {
    const screenshotDir = path.resolve(screenshotDirArg);
    for (const [fileName, [expectedWidth, expectedHeight]] of Object.entries(REQUIRED_SCREENSHOTS)) {
      const imagePath = path.join(screenshotDir, fileName);
      assertCheck(`screenshot_exists_${fileName}`, fs.existsSync(imagePath), { imagePath });
      const stat = fs.statSync(imagePath);
      const size = readPngSize(imagePath);
      assertCheck(`screenshot_shape_${fileName}`, size.width === expectedWidth && size.height === expectedHeight && stat.size > 10_000, {
        imagePath,
        expectedWidth,
        expectedHeight,
        ...size,
        bytes: stat.size
      });
    }
  } else if (fs.existsSync(LATEST_CYCLE_PATH)) {
    const latest = JSON.parse(fs.readFileSync(LATEST_CYCLE_PATH, "utf8"));
    const latestDir = path.join(HARDENING_ROOT, latest.cycleId || "");
    assertCheck("latest_hardening_cycle_passed", latest.verdict === "pass", {
      cycleId: latest.cycleId || null,
      verdict: latest.verdict || null
    });
    for (const [fileName, [expectedWidth, expectedHeight]] of Object.entries(REQUIRED_SCREENSHOTS)) {
      const imagePath = path.join(latestDir, fileName);
      assertCheck(`screenshot_exists_${fileName}`, fs.existsSync(imagePath), { imagePath });
      const stat = fs.statSync(imagePath);
      const size = readPngSize(imagePath);
      assertCheck(`screenshot_shape_${fileName}`, size.width === expectedWidth && size.height === expectedHeight && stat.size > 10_000, {
        imagePath,
        expectedWidth,
        expectedHeight,
        ...size,
        bytes: stat.size
      });
    }
  } else {
    addCheck("latest_hardening_cycle_missing", "warn", {
      path: LATEST_CYCLE_PATH
    });
  }

  const report = {
    generatedAt: new Date().toISOString(),
    status: checks.every((check) => check.status !== "fail") ? "pass" : "fail",
    checks
  };
  process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
}

try {
  main();
} catch (error) {
  const report = {
    generatedAt: new Date().toISOString(),
    status: "fail",
    error: error.message,
    checks
  };
  process.stderr.write(`${JSON.stringify(report, null, 2)}\n`);
  process.exit(1);
}
