import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const PROJECT_ROOT = path.resolve(APP_ROOT, "..");
const RUNTIME_ROOT = path.join(PROJECT_ROOT, ".runtime", "room16-app");

const REVIEW_GATE_STATUS_PATH = path.join(RUNTIME_ROOT, "review-gate-status", "latest-review-gate-status.json");
const MANUAL_REVIEW_PACKETS_PATH = path.join(RUNTIME_ROOT, "manual-review-packets", "latest-manual-review-packets.json");
const OUT_DIR = path.join(RUNTIME_ROOT, "publish-readiness");
const OUT_JSON = path.join(OUT_DIR, "latest-publish-readiness.json");
const OUT_MD = path.join(OUT_DIR, "latest-publish-readiness.md");

const REQUIRED_FORBIDDEN_DECISIONS = ["public", "member", "publish", "rerun", "push"];
const OPERATOR_GATES = [
  "Room16 rerun",
  "Push",
  "Publish",
  "Public-/Member-Sichtbarkeit",
  "Production",
  "Geld/Payment",
  "Auth/Credentials",
  "externe Kommunikation",
  "Financial-Advice-Publishing",
  "Löschung",
];

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function readJson(filePath, label) {
  assert(fs.existsSync(filePath), `${label} missing: ${filePath}`);
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function arrayValue(value) {
  return Array.isArray(value) ? value : [];
}

function hasAllForbiddenDecisions(packet) {
  const decisions = arrayValue(packet?.manualDecisionContract?.forbidden_decisions_without_operator_go);
  return REQUIRED_FORBIDDEN_DECISIONS.every((decision) => decisions.includes(decision));
}

function promotionChecks(packet) {
  return arrayValue(packet?.promotionReadiness?.checks);
}

function packetSummary(packet) {
  const checks = promotionChecks(packet);
  const missingChecks = checks
    .filter((check) => ["missing", "blocked", "fail"].includes(String(check.status)))
    .map((check) => check.id);
  return {
    ticker: packet.ticker || "",
    report: packet.report || "",
    report_file_exists: Boolean(packet.reportFileExists),
    source_verification_status: packet.sourceVerificationStatus || "unknown",
    non_advice_status: packet.nonAdviceStatus || "unknown",
    promotion_status: packet.promotionStatus || "unknown",
    promotion_readiness_status: packet?.promotionReadiness?.status || "unknown",
    forbidden_decisions_complete: hasAllForbiddenDecisions(packet),
    missing_or_blocked_checks: missingChecks,
    allowed_local_decisions: arrayValue(packet?.manualDecisionContract?.allowed_decisions),
  };
}

function buildMarkdown(report) {
  const lines = [
    "# Room16 Publish Readiness",
    "",
    `Generated: ${report.generated_at}`,
    `Status: ${report.status}`,
    "",
    "## Summary",
    "",
    `- Total Reports: ${report.summary.total_reports}`,
    `- Manual Review Entries: ${report.summary.manual_review_entries}`,
    `- Manual Review Packets: ${report.summary.manual_review_packets}`,
    `- Missing Files: ${report.summary.missing_file_count}`,
    `- Public Ready: ${report.summary.public_ready}`,
    `- Member Ready: ${report.summary.member_ready}`,
    `- Effective Public: ${report.summary.effective_public}`,
    `- Promotion Readiness: ${report.summary.promotion_readiness_status}`,
    `- Runtime Action Executed: ${report.runtime_action_executed}`,
    "",
    "## Operator Decision Package",
    "",
    `- Current Decision: ${report.operator_decision_package.current_decision}`,
    `- Next Safe Step: ${report.operator_decision_package.next_safe_step}`,
    `- Allowed Local Decisions: ${report.operator_decision_package.allowed_local_decisions.map((item) => `\`${item}\``).join(", ")}`,
    `- Forbidden Without Operator-Go: ${report.operator_decision_package.forbidden_without_operator_go.map((item) => `\`${item}\``).join(", ")}`,
    "",
    "## Packets",
    "",
  ];
  if (report.packets.length) {
    lines.push("| Ticker | Report | File | Source | Non-Advice | Promotion | Missing/Blocked |");
    lines.push("| --- | --- | --- | --- | --- | --- | --- |");
    for (const packet of report.packets) {
      lines.push(
        `| ${packet.ticker} | ${packet.report} | ${packet.report_file_exists ? "found" : "missing"} | ${packet.source_verification_status} | ${packet.non_advice_status} | ${packet.promotion_readiness_status} | ${packet.missing_or_blocked_checks.join(", ") || "none"} |`,
      );
    }
  } else {
    lines.push("- No manual-review packets are currently open.");
  }
  lines.push("", "## Findings", "");
  if (report.findings.length) {
    for (const finding of report.findings) lines.push(`- ${finding.severity}: ${finding.message}`);
  } else {
    lines.push("- No structural findings.");
  }
  lines.push("", "## Stop-Regel", "", report.stop_rule, "");
  return `${lines.join("\n")}\n`;
}

const reviewGate = readJson(REVIEW_GATE_STATUS_PATH, "Room16 review-gate status");
const manualPackets = readJson(MANUAL_REVIEW_PACKETS_PATH, "Room16 manual-review packets");

const findings = [];
const packets = arrayValue(manualPackets.packets).map(packetSummary);
const summary = {
  total_reports: Number(reviewGate?.summary?.total_reports || 0),
  manual_review_entries: arrayValue(reviewGate.manual_review_entries).length,
  manual_review_packets: Number(manualPackets.packet_count || 0),
  missing_file_count: Number(manualPackets.missing_file_count || 0),
  public_ready: Number(reviewGate?.summary?.public_ready || 0),
  member_ready: Number(reviewGate?.summary?.member_ready || 0),
  effective_public: Number(reviewGate?.summary?.effective_public || 0),
  hidden_by_gate: Number(reviewGate?.summary?.hidden_by_gate || 0),
  review_gate_status: reviewGate.status || "UNKNOWN",
  manual_review_packet_status: manualPackets.status || "UNKNOWN",
  promotion_readiness_status: manualPackets.promotion_readiness_status || "unknown",
};

if (reviewGate.runtime_action_executed !== false) {
  findings.push({ severity: "FAIL", message: "Review-gate status does not explicitly report runtime_action_executed=false." });
}
if (manualPackets.runtime_action_executed !== false) {
  findings.push({ severity: "FAIL", message: "Manual-review packets do not explicitly report runtime_action_executed=false." });
}
if (Number(reviewGate.fail_count || 0) > 0 || reviewGate.status === "FAIL") {
  findings.push({ severity: "FAIL", message: "Review-gate status contains failures." });
}
if (manualPackets.status === "FAIL" || summary.missing_file_count > 0) {
  findings.push({ severity: "FAIL", message: "Manual-review packet output has missing files or failed status." });
}
if (summary.manual_review_entries !== summary.manual_review_packets) {
  findings.push({
    severity: "FAIL",
    message: `Manual-review count mismatch: gate=${summary.manual_review_entries} packets=${summary.manual_review_packets}.`,
  });
}
if (summary.effective_public > 0) {
  findings.push({ severity: "FAIL", message: "Effective public exposure is present; publish readiness must stop." });
}
if (summary.public_ready > 0 || summary.member_ready > 0) {
  findings.push({ severity: "WARN", message: "Public/member-ready signals require a separate Operator Go/No-Go decision." });
}
if (summary.manual_review_entries > 0) {
  findings.push({ severity: "WARN", message: `${summary.manual_review_entries} manual-review packets remain blocked for Human Source Verification and Non-Advice confirmation.` });
}
if (summary.manual_review_packets > 0 && summary.promotion_readiness_status !== "blocked") {
  findings.push({ severity: "FAIL", message: "Manual-review packets exist, but promotion_readiness_status is not blocked." });
}
for (const packet of packets) {
  if (!packet.report_file_exists) {
    findings.push({ severity: "FAIL", message: `Report file missing for ${packet.ticker}: ${packet.report}` });
  }
  if (!packet.forbidden_decisions_complete) {
    findings.push({ severity: "FAIL", message: `Forbidden decision contract incomplete for ${packet.ticker}: ${packet.report}` });
  }
  if (packet.promotion_readiness_status !== "blocked") {
    findings.push({ severity: "FAIL", message: `Promotion readiness is not blocked for ${packet.ticker}: ${packet.report}` });
  }
}

const failCount = findings.filter((finding) => finding.severity === "FAIL").length;
const warnCount = findings.filter((finding) => finding.severity === "WARN").length;
const status = failCount ? "FAIL" : warnCount ? "WARN" : "PASS";

const report = {
  schema_version: 1,
  generated_at: new Date().toISOString(),
  status,
  source_review_gate_status_path: REVIEW_GATE_STATUS_PATH,
  source_manual_review_packets_path: MANUAL_REVIEW_PACKETS_PATH,
  output_path: OUT_JSON,
  runtime_action_executed: false,
  summary,
  packets,
  operator_gate_required: true,
  operator_gates: OPERATOR_GATES,
  operator_decision_package: {
    current_decision: status === "FAIL" ? "repair_local_evidence_before_review" : summary.manual_review_packets ? "keep_hidden_until_human_review" : "monitoring_no_publish_action",
    allowed_local_decisions: ["keep_hidden", "approved_internal_after_human_review", "reject", "needs_more_evidence"],
    forbidden_without_operator_go: ["public", "member", "publish", "rerun", "push", "external_send", "financial_advice_publish", "delete"],
    next_safe_step: summary.manual_review_packets
      ? "Operator kann die lokalen Review-Pakete lesen und intern entscheiden; Public/Member/Publish bleibt ohne separates Go geschlossen."
      : "Als lokale Evidence halten; keine Runtime-Aktion ableiten.",
  },
  findings,
  fail_count: failCount,
  warn_count: warnCount,
  stop_rule: "Readiness ist nur lokale Evidence. Stop bei Public/Member-Sichtbarkeit, Room16-Rerun, Push, Publish, externer Kommunikation, Finanzpublishing, Production, Geld, Auth/Credentials oder Löschung.",
};

fs.mkdirSync(OUT_DIR, { recursive: true });
fs.writeFileSync(OUT_JSON, JSON.stringify(report, null, 2), "utf8");
fs.writeFileSync(OUT_MD, buildMarkdown(report), "utf8");

if (status === "FAIL") {
  console.error(`Room16 publish readiness failed. Output: ${OUT_JSON}`);
  process.exit(1);
}

console.log(`Room16 publish readiness ${status}. Output: ${OUT_JSON}`);
