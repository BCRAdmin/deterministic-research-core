import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const PROJECT_ROOT = path.resolve(APP_ROOT, "..");
const OUT_DIR = path.join(PROJECT_ROOT, ".runtime", "room16-app", "report-machine");
const BASE_URL = process.env.ROOM16_APP_BASE_URL || "http://127.0.0.1:4516";
const EXPECTED_REPORT_TICKERS = ["AMZN", "DDOG", "MDB"];
const EXPECTED_WORKFLOW_STEPS = [
  "intake",
  "queue",
  "research",
  "source_ledger",
  "manifest",
  "dossier",
  "quality_gate",
  "shelf",
  "publish_gate"
];

const checks = [];

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function addCheck(name, condition, details = {}) {
  checks.push({
    name,
    status: condition ? "pass" : "fail",
    details
  });
}

async function fetchJson(route) {
  const response = await fetch(`${BASE_URL}${route}`, { signal: AbortSignal.timeout(15_000) });
  const text = await response.text();
  let payload = null;
  try {
    payload = JSON.parse(text);
  } catch {
    // The check using this payload will fail with the raw prefix below.
  }
  return { response, payload, text };
}

function runCommand(label, command, args, options = {}) {
  const result = spawnSync(command, args, {
    cwd: options.cwd || PROJECT_ROOT,
    encoding: "utf8",
    env: { ...process.env, ...options.env },
    timeout: options.timeoutMs || 60_000,
    maxBuffer: 1024 * 1024 * 10
  });
  const ok = result.status === 0 && !result.error;
  addCheck(label, ok, {
    command: [command, ...args].join(" "),
    exitCode: result.status,
    error: result.error?.message || null,
    stdoutTail: (result.stdout || "").slice(-2000),
    stderrTail: (result.stderr || "").slice(-2000)
  });
}

function byTicker(entries) {
  const map = new Map();
  for (const entry of entries) {
    const ticker = String(entry.ticker || "").toUpperCase();
    if (!map.has(ticker)) map.set(ticker, []);
    map.get(ticker).push(entry);
  }
  return map;
}

function readJsonIfExists(relativePath) {
  const fullPath = path.join(PROJECT_ROOT, relativePath);
  if (!fs.existsSync(fullPath)) {
    return null;
  }
  return JSON.parse(fs.readFileSync(fullPath, "utf8"));
}

function artifactDeferred(value) {
  return value == null || value?.rendered === false;
}

async function main() {
  ensureDir(OUT_DIR);

  const health = await fetchJson("/api/health");
  addCheck("health_ok", health.response.ok && health.payload?.ok === true, {
    status: health.response.status,
    ok: health.payload?.ok ?? null,
    prefix: health.text.slice(0, 160)
  });
  addCheck("hardening_verdict_pass", health.payload?.hardening?.verdict === "pass", {
    hardening: health.payload?.hardening || null
  });

  const state = await fetchJson("/api/state");
  const profiles = Array.isArray(state.payload?.modelProfiles) ? state.payload.modelProfiles : [];
  addCheck("state_ok", state.response.ok && Array.isArray(state.payload?.companies), {
    status: state.response.status,
    companyCount: state.payload?.companies?.length ?? null
  });
  const stateJobs = Array.isArray(state.payload?.jobs) ? state.payload.jobs : [];
  addCheck("state_jobs_expose_report_workflow_checklists", stateJobs.length === 0 || stateJobs.every((job) => {
    const stepIds = Array.isArray(job.workflow) ? job.workflow.map((step) => step.id) : [];
    return EXPECTED_WORKFLOW_STEPS.every((stepId) => stepIds.includes(stepId)) &&
      Number.isFinite(Number(job.workflowProgress?.total));
  }), {
    jobCount: stateJobs.length,
    sample: stateJobs[0]
      ? {
          ticker: stateJobs[0].ticker,
          workflow: stateJobs[0].workflow?.map((step) => `${step.id}:${step.status}`),
          progress: stateJobs[0].workflowProgress
        }
      : null
  });
  addCheck("active_model_picker_excludes_kimi_and_gpt55", profiles.every((profile) => !/kimi|gpt-5\.5/i.test(`${profile.id} ${profile.label}`)), {
    profiles: profiles.map((profile) => profile.id)
  });
  addCheck("deepseek_is_ollama_cloud_default", profiles.some((profile) =>
    profile.id === "deepseek-v4-ollama" &&
    profile.provider === "ollama" &&
    String(profile.deepModel || "").endsWith(":cloud") &&
    profile.default === true
  ), {
    profile: profiles.find((profile) => profile.id === "deepseek-v4-ollama") || null
  });

  const reportMachine = await fetchJson("/api/report-machine");
  const machine = reportMachine.payload?.reportMachine || {};
  addCheck("report_machine_status_ok", reportMachine.response.ok && typeof machine.ready === "boolean", {
    status: reportMachine.response.status,
    ready: machine.ready ?? null,
    nextAction: machine.nextAction || null
  });
  addCheck("report_machine_policy_enforces_model_truth", Boolean(
    machine.policy?.activeModelsExcludeKimiAndGpt55 &&
    machine.policy?.deepseekIsOllamaCloud
  ), {
    policy: machine.policy || null
  });
  addCheck("report_machine_policy_exposes_full_workflow", EXPECTED_WORKFLOW_STEPS.every((stepId) =>
    Array.isArray(machine.policy?.reportFlow) && machine.policy.reportFlow.includes(stepId)
  ), {
    reportFlow: machine.policy?.reportFlow || null,
    reportFlowLabels: machine.policy?.reportFlowLabels || null
  });
  addCheck("report_machine_exposes_recovery_counts", Number.isFinite(Number(machine.recoverableJobs)), {
    recoverableJobs: machine.recoverableJobs ?? null,
    recoverableByTicker: machine.recoverableByTicker || null
  });

  const library = await fetchJson("/api/public-library");
  const entries = Array.isArray(library.payload?.reportLibrary?.entries)
    ? library.payload.reportLibrary.entries
    : [];
  const summary = library.payload?.reportLibrary?.summary || {};
  const entriesByTicker = byTicker(entries);

  addCheck("public_library_ok", library.response.ok && entries.length > 0, {
    status: library.response.status,
    count: entries.length,
    summary
  });
  addCheck("public_library_exposes_deeptech_dashboard_counts", [
    "speculative_deep_tech_profile_count",
    "accounting_gain_not_operating_turnaround_count",
    "vendor_only_hard_metrics_count",
    "order_materiality_missing_count",
    "technical_overweight_in_thesis_count"
  ].every((key) => Number.isFinite(Number(summary[key]))), {
    summary
  });
  for (const ticker of EXPECTED_REPORT_TICKERS) {
    addCheck(`report_history_visible_${ticker.toLowerCase()}`, (entriesByTicker.get(ticker) || []).length > 0, {
      ticker,
      reports: (entriesByTicker.get(ticker) || []).map((entry) => entry.title)
    });
  }
  addCheck("public_surface_gate_keeps_unreviewed_reports_hidden", entries.every((entry) => {
    return entry.qualityGate?.effectiveVisibility !== "public" || entry.qualityGate?.status === "public_ready";
  }), {
    effectivePublic: summary.effectivePublic,
    offenders: entries
      .filter((entry) => entry.qualityGate?.effectiveVisibility === "public" && entry.qualityGate?.status !== "public_ready")
      .map((entry) => `${entry.ticker}:${entry.title}`)
  });
  addCheck("member_surface_gate_keeps_unreviewed_reports_hidden", entries.every((entry) => {
    return entry.qualityGate?.effectiveVisibility !== "member" || entry.qualityGate?.memberReady === true;
  }), {
    effectiveMember: summary.effectiveMember,
    offenders: entries
      .filter((entry) => entry.qualityGate?.effectiveVisibility === "member" && entry.qualityGate?.memberReady !== true)
      .map((entry) => `${entry.ticker}:${entry.title}`)
  });
  const markdownQaEntries = entries.filter((entry) =>
    entry.generationStage === "draft_markdown_qa" || entry.renderMode === "markdown_first_qa"
  );
  addCheck("markdown_first_qa_is_not_public_ready", markdownQaEntries.every((entry) => {
    return entry.publicReady === false &&
      entry.publishable === false &&
      entry.finalDocumentsRendered === false &&
      entry.scoreScope === "markdown_qa" &&
      entry.publicRating == null &&
      entry.publishReportUrl == null &&
      entry.qualityGate?.status !== "public_ready" &&
      entry.qualityGate?.effectiveVisibility !== "public";
  }), {
    count: markdownQaEntries.length,
    sample: markdownQaEntries.slice(0, 3).map((entry) => ({
      ticker: entry.ticker,
      generationStage: entry.generationStage,
      renderMode: entry.renderMode,
      publishable: entry.publishable,
      publicReady: entry.publicReady,
      finalDocumentsRendered: entry.finalDocumentsRendered,
      scoreScope: entry.scoreScope,
      publicRating: entry.publicRating,
      publishReportUrl: entry.publishReportUrl,
      gate: entry.qualityGate
    }))
  });
  const pltrMarkdownSmoke = readJsonIfExists("outputs/release/MARKET_READY_PILOT_PACKAGE/SAMPLE_ARTIFACTS/PLTR_markdown_first_qa/quality_report.json") ||
    readJsonIfExists("outputs/review_bundles/room16_markdown_first_qa/smoke/quality_report.json");
  addCheck("pltr_markdown_first_smoke_status_rules", Boolean(
    pltrMarkdownSmoke &&
    pltrMarkdownSmoke.generation_stage === "draft_markdown_qa" &&
    pltrMarkdownSmoke.render_mode === "markdown_first_qa" &&
    (pltrMarkdownSmoke.quality_verdict || pltrMarkdownSmoke.verdict) === "pass" &&
    (pltrMarkdownSmoke.score_scope || pltrMarkdownSmoke.metrics?.score_scope) === "markdown_qa" &&
    (pltrMarkdownSmoke.promotion_gate_verdict || pltrMarkdownSmoke.metrics?.promotion_gate_verdict) === "not_run" &&
    ["not_run", "not_applicable"].includes(pltrMarkdownSmoke.publish_gate_verdict || pltrMarkdownSmoke.metrics?.publish_gate_verdict) &&
    (pltrMarkdownSmoke.public_ready ?? pltrMarkdownSmoke.metrics?.public_ready) === false &&
    (pltrMarkdownSmoke.metrics?.final_documents_rendered) === false &&
    (pltrMarkdownSmoke.metrics?.public_rating ?? null) == null &&
    artifactDeferred(pltrMarkdownSmoke.artifacts?.complete_pdf) &&
    artifactDeferred(pltrMarkdownSmoke.artifacts?.complete_docx) &&
    Number(pltrMarkdownSmoke.metrics?.complete_pdf_words || 0) === 0 &&
    Number(pltrMarkdownSmoke.metrics?.complete_docx_words || 0) === 0
  ), {
    sample: pltrMarkdownSmoke
      ? {
          generationStage: pltrMarkdownSmoke.generation_stage,
          renderMode: pltrMarkdownSmoke.render_mode,
          qualityVerdict: pltrMarkdownSmoke.quality_verdict || pltrMarkdownSmoke.verdict,
          scoreScope: pltrMarkdownSmoke.score_scope || pltrMarkdownSmoke.metrics?.score_scope,
          publishGate: pltrMarkdownSmoke.publish_gate_verdict || pltrMarkdownSmoke.metrics?.publish_gate_verdict,
          promotionGate: pltrMarkdownSmoke.promotion_gate_verdict || pltrMarkdownSmoke.metrics?.promotion_gate_verdict,
          artifacts: {
            completePdf: pltrMarkdownSmoke.artifacts?.complete_pdf,
            completeDocx: pltrMarkdownSmoke.artifacts?.complete_docx
          }
        }
      : null
  });
  addCheck("failed_quality_reports_are_rejected_or_hidden", entries.every((entry) => {
    if (entry.qualityVerdict !== "fail") return true;
    return entry.qualityGate?.status === "rejected" && entry.qualityGate?.effectiveVisibility === "hidden";
  }), {
    failedReports: entries
      .filter((entry) => entry.qualityVerdict === "fail")
      .map((entry) => ({ ticker: entry.ticker, status: entry.qualityGate?.status, title: entry.title }))
  });
  addCheck("failed_quality_decision_blocks_public_artifacts", entries.every((entry) => {
    if (entry.qualityVerdict !== "fail") return true;
    return entry.qualityDecision?.review_status === "failed" &&
      entry.qualityDecision?.publishable === false &&
      entry.qualityDecision?.public_ready === false &&
      entry.qualityDecision?.visibility === "hidden" &&
      entry.qualityDecision?.public_rating == null &&
      entry.publishReportUrl == null &&
      entry.markdownUrl == null;
  }), {
    failedReports: entries
      .filter((entry) => entry.qualityVerdict === "fail")
      .map((entry) => ({
        ticker: entry.ticker,
        decision: entry.qualityDecision,
        markdownUrl: entry.markdownUrl,
        publishReportUrl: entry.publishReportUrl
      }))
  });
  const failedWithInternalBest = entries.find((entry) => entry.qualityVerdict === "fail" && entry.internalBestReportUrl);
  if (failedWithInternalBest) {
    const failedMarkdown = await fetch(`${BASE_URL}${failedWithInternalBest.internalBestReportUrl}`, { signal: AbortSignal.timeout(15_000) });
    const failedMarkdownText = await failedMarkdown.text();
    addCheck("failed_internal_best_statusbox_uses_quality_decision", Boolean(
      failedMarkdown.ok &&
      failedMarkdownText.includes("- review_status: `failed`") &&
      failedMarkdownText.includes("- quality_verdict: `fail`") &&
      failedMarkdownText.includes("- publishable: `false`") &&
      failedMarkdownText.includes("- public_ready: `false`") &&
      failedMarkdownText.includes("- visibility: `hidden`") &&
      failedMarkdownText.includes("- public_rating: `null`") &&
      !failedMarkdownText.includes("- review_status: `quality_pass`") &&
      !failedMarkdownText.includes("- publishable: `true`")
    ), {
      ticker: failedWithInternalBest.ticker,
      status: failedMarkdown.status,
      prefix: failedMarkdownText.slice(0, 600)
    });
  } else {
    addCheck("failed_internal_best_statusbox_uses_quality_decision", true, {
      reason: "no failed internal-best artifact exposed; failed reports are already rejected/hidden with no public markdown"
    });
  }
  addCheck("public_ready_requires_full_human_review_stack", entries.every((entry) => {
    if (entry.qualityGate?.status !== "public_ready") return true;
    return entry.qualityVerdict === "pass" &&
      entry.sourceStatus === "human_verified" &&
      entry.reviewStatus === "reviewed" &&
      entry.nonAdvice === true &&
      entry.generationStage === "public_final" &&
      entry.finalDocumentsRendered === true &&
      Boolean(entry.publishReportUrl) &&
      entry.publicReady === true &&
      entry.promotionStatus?.public_ready === true &&
      Boolean(entry.promotionStatus?.reviewed_by) &&
      Boolean(entry.promotionStatus?.approved_at) &&
      entry.promotionStatus?.requested_visibility === "public" &&
      entry.promotionStatus?.non_advice_confirmed === true &&
      entry.promotionStatus?.sources_human_verified === true &&
      (!Array.isArray(entry.promotionStatus?.blocking_issues) || entry.promotionStatus.blocking_issues.length === 0);
  }), {
    publicReady: entries
      .filter((entry) => entry.qualityGate?.status === "public_ready")
      .map((entry) => ({
        ticker: entry.ticker,
        sourceStatus: entry.sourceStatus,
        reviewStatus: entry.reviewStatus,
        nonAdvice: entry.nonAdvice,
        publishReportUrl: entry.publishReportUrl,
        promotionStatus: entry.promotionStatus
      }))
  });
  addCheck("pass_quality_reports_have_markdown_reader_urls", entries.every((entry) => {
    return entry.qualityVerdict !== "pass" || entry.publishable === false || Boolean(entry.markdownUrl);
  }), {
    missing: entries
      .filter((entry) => entry.qualityVerdict === "pass" && entry.publishable !== false && !entry.markdownUrl)
      .map((entry) => `${entry.ticker}:${entry.title}`)
  });
  const rgtiEntry = (entriesByTicker.get("RGTI") || [])[0] || null;
  addCheck("rgti_deeptech_regression_not_clean_publishable", Boolean(
    rgtiEntry &&
    rgtiEntry.generationStage === "internal_best" &&
    rgtiEntry.reviewStatusMetric === "manual_review" &&
    rgtiEntry.qualityGate?.status === "manual_review" &&
    rgtiEntry.qualityGate?.effectiveVisibility === "hidden" &&
    rgtiEntry.publishable === false &&
    rgtiEntry.publicReady === false &&
    rgtiEntry.publicRating == null &&
    rgtiEntry.externalDisplayRating === "Manual Review / Preliminary Underweight"
  ), {
    rgti: rgtiEntry
      ? {
          status: rgtiEntry.qualityGate?.status,
          effectiveVisibility: rgtiEntry.qualityGate?.effectiveVisibility,
          publishable: rgtiEntry.publishable,
          publicReady: rgtiEntry.publicReady,
          externalDisplayRating: rgtiEntry.externalDisplayRating,
          reviewStatusMetric: rgtiEntry.reviewStatusMetric,
          generationStage: rgtiEntry.generationStage,
          companyArchetype: rgtiEntry.companyArchetype,
          archetypeConfidence: rgtiEntry.archetypeConfidence,
          archetypeTriggeredRules: rgtiEntry.archetypeTriggeredRules,
          manualReviewReasons: rgtiEntry.manualReviewReasons,
          internalBestReportUrl: rgtiEntry.internalBestReportUrl,
          markdownUrl: rgtiEntry.markdownUrl,
          publicRating: rgtiEntry.publicRating
        }
      : null
  });
  const qcomOrRklbDisplayEntry = entries.find((entry) =>
    entry.ticker === "QCOM" || String(entry.externalDisplayRating || "").includes("Hold Pending FCF")
  );
  addCheck("qcom_display_rule_keeps_hold_pending_fcf_support", !qcomOrRklbDisplayEntry || (
    String(qcomOrRklbDisplayEntry.externalDisplayRating || "").includes("Hold Pending FCF") &&
    String(qcomOrRklbDisplayEntry.externalDisplayRating || "").trim() !== "Accumulate"
  ), {
    sample: qcomOrRklbDisplayEntry
      ? {
          ticker: qcomOrRklbDisplayEntry.ticker,
          externalDisplayRating: qcomOrRklbDisplayEntry.externalDisplayRating
        }
      : "no QCOM/RKLB display fixture exposed in public-library API"
  });
  const msftEntry = (entriesByTicker.get("MSFT") || [])[0] || null;
  addCheck("msft_artifact_consistency_mega_cap_not_deeptech_stale", !msftEntry || (
    msftEntry.companyArchetype === "MEGA_CAP_PLATFORM" &&
    !(msftEntry.riskProfiles || []).includes("SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE")
  ), {
    msft: msftEntry
      ? {
          companyArchetype: msftEntry.companyArchetype,
          riskProfiles: msftEntry.riskProfiles,
          artifactConsistency: msftEntry.artifactConsistency
        }
      : "no MSFT fixture exposed in public-library API"
  });
  addCheck("rgti_internal_best_report_available_but_not_public_markdown", Boolean(
    rgtiEntry &&
    rgtiEntry.internalBestReportUrl &&
    !rgtiEntry.markdownUrl &&
    rgtiEntry.publicRating == null
  ), {
    rgti: rgtiEntry
      ? {
          internalBestReportUrl: rgtiEntry.internalBestReportUrl,
          markdownUrl: rgtiEntry.markdownUrl,
          publicRating: rgtiEntry.publicRating,
          publishable: rgtiEntry.publishable
        }
      : null
  });
  addCheck("rgti_archetype_regression_detected", Boolean(
    rgtiEntry &&
    rgtiEntry.companyArchetype === "SPECULATIVE_DEEP_TECH_EARLY_COMMERCIAL" &&
    Number(rgtiEntry.archetypeConfidence) > 0 &&
    Array.isArray(rgtiEntry.archetypeTriggeredRules) &&
    rgtiEntry.archetypeTriggeredRules.includes("vendor_only_hard_financial_metrics")
  ), {
    rgti: rgtiEntry
      ? {
          companyArchetype: rgtiEntry.companyArchetype,
          archetypeConfidence: rgtiEntry.archetypeConfidence,
          archetypeTriggeredRules: rgtiEntry.archetypeTriggeredRules
        }
      : null
  });

  const readableCandidate = entries.find((entry) => entry.qualityVerdict === "pass" && entry.markdownUrl);
  if (readableCandidate) {
    const markdown = await fetch(`${BASE_URL}${readableCandidate.markdownUrl}`, { signal: AbortSignal.timeout(15_000) });
    const markdownText = await markdown.text();
    addCheck("sample_markdown_reader_opens", markdown.ok && markdownText.length > 10_000 && markdownText.includes(readableCandidate.ticker), {
      ticker: readableCandidate.ticker,
      status: markdown.status,
      chars: markdownText.length
    });
  } else {
    addCheck("sample_markdown_reader_opens", false, { reason: "no pass-quality markdown candidate found" });
  }

  runCommand("promotion_contract_self_test", "python3", ["scripts/room16_promotion_contract.py", "--self-test"]);

  const report = {
    createdAt: new Date().toISOString(),
    baseUrl: BASE_URL,
    verdict: checks.every((check) => check.status === "pass") ? "pass" : "fail",
    checks
  };
  const jsonPath = path.join(OUT_DIR, "last-report-machine-verification.json");
  const mdPath = path.join(OUT_DIR, "last-report-machine-verification.md");
  fs.writeFileSync(jsonPath, JSON.stringify(report, null, 2), "utf8");
  fs.writeFileSync(
    mdPath,
    [
      "# Room 16 Report Machine Verification",
      "",
      `Created: ${report.createdAt}`,
      `Base URL: ${report.baseUrl}`,
      `Verdict: ${report.verdict}`,
      "",
      "## Checks",
      "",
      ...checks.map((check) => `- ${check.status === "pass" ? "PASS" : "FAIL"} ${check.name}: ${JSON.stringify(check.details)}`)
    ].join("\n"),
    "utf8"
  );
  console.log(JSON.stringify(report, null, 2));
  if (report.verdict !== "pass") process.exitCode = 1;
}

main().catch((error) => {
  addCheck("verifier_exception", false, { message: error.message });
  ensureDir(OUT_DIR);
  const report = {
    createdAt: new Date().toISOString(),
    baseUrl: BASE_URL,
    verdict: "fail",
    checks
  };
  fs.writeFileSync(path.join(OUT_DIR, "last-report-machine-verification.json"), JSON.stringify(report, null, 2), "utf8");
  console.error(error.message);
  process.exit(1);
});
