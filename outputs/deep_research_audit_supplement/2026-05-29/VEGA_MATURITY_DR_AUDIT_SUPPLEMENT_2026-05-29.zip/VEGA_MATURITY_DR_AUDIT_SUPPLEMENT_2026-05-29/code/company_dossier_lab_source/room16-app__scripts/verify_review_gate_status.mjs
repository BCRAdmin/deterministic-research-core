import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const APP_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const PROJECT_ROOT = path.resolve(APP_ROOT, "..");
const RUNTIME_ROOT = path.join(PROJECT_ROOT, ".runtime", "room16-app");
const STATUS_PATH = path.join(RUNTIME_ROOT, "public-library", "latest-library-status.md");
const STATE_PATH = path.join(RUNTIME_ROOT, "public-library", "report-library-state.json");
const OUT_DIR = path.join(RUNTIME_ROOT, "review-gate-status");
const OUT_JSON = path.join(OUT_DIR, "latest-review-gate-status.json");
const OUT_MD = path.join(OUT_DIR, "latest-review-gate-status.md");

const OPERATOR_GATES = [
  "Room16 rerun/push/publish",
  "Public- oder Member-Sichtbarkeit ändern",
  "Finanzpublishing oder externe Kommunikation",
  "Production, Geld, Credentials/Auth oder Löschung",
];

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function readRequired(filePath, label) {
  assert(fs.existsSync(filePath), `${label} missing: ${filePath}`);
  return fs.readFileSync(filePath, "utf8");
}

function parseCount(summaryText, label) {
  const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const match = summaryText.match(new RegExp(`^- ${escaped}:\\s*(\\d+)\\s*$`, "m"));
  return match ? Number.parseInt(match[1], 10) : 0;
}

function parseEntries(markdown) {
  const rows = markdown
    .split(/\r?\n/)
    .filter((line) => line.startsWith("| ") && !line.includes("---"));
  const dataRows = rows.slice(1);
  return dataRows.map((row) => {
    const cells = row
      .split("|")
      .slice(1, -1)
      .map((cell) => cell.trim());
    return {
      ticker: cells[0] || "",
      report: cells[1] || "",
      model: cells[2] || "",
      requested: cells[3] || "",
      effective: cells[4] || "",
      gate: cells[5] || "",
      sources: cells[6] || "",
      review: cells[7] || "",
    };
  });
}

function reportSlug(entry) {
  return `${entry.ticker}:${entry.report}`.replace(/\s+/g, " ").trim();
}

function readStateSummary() {
  if (!fs.existsSync(STATE_PATH)) {
    return {
      present: false,
      entryCount: 0,
      humanVerifiedReviewed: 0,
      requestedMemberOrPublic: 0,
      dismissed: 0,
    };
  }
  const payload = JSON.parse(fs.readFileSync(STATE_PATH, "utf8"));
  const entries = payload && typeof payload === "object" && payload.entries && typeof payload.entries === "object"
    ? Object.values(payload.entries)
    : [];
  return {
    present: true,
    entryCount: entries.length,
    humanVerifiedReviewed: entries.filter((entry) =>
      entry?.sourceStatus === "human_verified" && entry?.reviewStatus === "reviewed"
    ).length,
    requestedMemberOrPublic: entries.filter((entry) => ["member", "public"].includes(entry?.visibility)).length,
    dismissed: entries.filter((entry) => Boolean(entry?.dismissedAt)).length,
  };
}

function buildMarkdown(report) {
  const lines = [
    "# Room16 Review-Gate Status",
    "",
    `Generated: ${report.generated_at}`,
    `Status: ${report.status}`,
    "",
    "## Summary",
    "",
    `- Total Reports: ${report.summary.total_reports}`,
    `- Manual Review: ${report.summary.manual_review}`,
    `- Rejected: ${report.summary.rejected}`,
    `- Public Ready: ${report.summary.public_ready}`,
    `- Member Ready: ${report.summary.member_ready}`,
    `- Effective Public: ${report.summary.effective_public}`,
    `- Hidden By Gate: ${report.summary.hidden_by_gate}`,
    `- Manual Review Entries: ${report.manual_review_entries.length}`,
    `- Findings: ${report.findings.length}`,
    "",
    "## Next Safe Step",
    "",
    report.next_safe_step,
    "",
    "## Manual Review Entries",
    "",
  ];
  if (report.manual_review_entries.length) {
    lines.push("| Ticker | Report | Model | Sources | Review | Next Safe Step |");
    lines.push("| --- | --- | --- | --- | --- | --- |");
    for (const entry of report.manual_review_entries) {
      lines.push(`| ${entry.ticker} | ${entry.report} | ${entry.model} | ${entry.sources} | ${entry.review} | ${entry.next_safe_step} |`);
    }
  } else {
    lines.push("- No manual-review entries found.");
  }
  lines.push("", "## Operator Gates", "");
  for (const gate of report.operator_gates) lines.push(`- ${gate}`);
  lines.push("", "## Findings", "");
  if (report.findings.length) {
    for (const finding of report.findings) lines.push(`- ${finding.severity}: ${finding.message}`);
  } else {
    lines.push("- No structural findings.");
  }
  return `${lines.join("\n")}\n`;
}

const markdown = readRequired(STATUS_PATH, "Room16 public-library status");
const entries = parseEntries(markdown);
const summary = {
  total_reports: parseCount(markdown, "Total Reports"),
  companies: parseCount(markdown, "Companies"),
  public_ready: parseCount(markdown, "Public Ready"),
  member_ready: parseCount(markdown, "Member Ready"),
  manual_review: parseCount(markdown, "Manual Review"),
  needs_human_review: parseCount(markdown, "Needs Human Review"),
  rejected: parseCount(markdown, "Rejected"),
  internal_only: parseCount(markdown, "Internal Only"),
  effective_public: parseCount(markdown, "Effective Public"),
  hidden_by_gate: parseCount(markdown, "Hidden By Gate"),
};
const stateSummary = readStateSummary();
const findings = [];

if (entries.length !== summary.total_reports) {
  findings.push({
    severity: "FAIL",
    message: `Entry count mismatch: summary=${summary.total_reports} table=${entries.length}`,
  });
}

const gateCounts = entries.reduce((acc, entry) => {
  acc[entry.gate] = (acc[entry.gate] || 0) + 1;
  return acc;
}, {});
for (const [label, expected] of [
  ["manual_review", summary.manual_review],
  ["rejected", summary.rejected],
  ["public_ready", summary.public_ready],
  ["member_ready", summary.member_ready],
  ["internal_only", summary.internal_only],
]) {
  if ((gateCounts[label] || 0) !== expected) {
    findings.push({
      severity: "FAIL",
      message: `Gate count mismatch for ${label}: summary=${expected} table=${gateCounts[label] || 0}`,
    });
  }
}

const effectivePublicEntries = entries.filter((entry) => entry.effective === "public");
if (effectivePublicEntries.length !== summary.effective_public) {
  findings.push({
    severity: "FAIL",
    message: `Effective public mismatch: summary=${summary.effective_public} table=${effectivePublicEntries.length}`,
  });
}

const hiddenEntries = entries.filter((entry) => entry.effective === "hidden");
if (hiddenEntries.length !== summary.hidden_by_gate) {
  findings.push({
    severity: "FAIL",
    message: `Hidden-by-gate mismatch: summary=${summary.hidden_by_gate} table=${hiddenEntries.length}`,
  });
}

for (const entry of entries) {
  if (["manual_review", "rejected", "internal_only"].includes(entry.gate) && entry.effective !== "hidden") {
    findings.push({
      severity: "FAIL",
      message: `Unsafe visibility for ${reportSlug(entry)}: gate=${entry.gate} effective=${entry.effective}`,
    });
  }
  if (["public_ready", "member_ready"].includes(entry.gate)) {
    findings.push({
      severity: "WARN",
      message: `Operator Go/No-Go package required for ${reportSlug(entry)} before any exposure change.`,
    });
  }
}

const manualReviewEntries = entries
  .filter((entry) => entry.gate === "manual_review")
  .map((entry) => ({
    ...entry,
    next_safe_step: "Lokales Review-Paket/Evidence prüfen; keine Sichtbarkeit ändern und keinen Room16-Rerun starten.",
    stop_rule: "Stop bei Public/Member, Rerun, Push, Publish, externer Kommunikation oder Finanzpublishing.",
  }));

if (manualReviewEntries.length) {
  findings.push({
    severity: "WARN",
    message: `${manualReviewEntries.length} manual-review reports need local evidence review while all publish gates stay closed.`,
  });
}

if (summary.public_ready > 0 || summary.member_ready > 0 || summary.effective_public > 0) {
  findings.push({
    severity: summary.effective_public > 0 ? "FAIL" : "WARN",
    message: "Public/member-ready signal found; this is an Operator-Gate, not an automation permission.",
  });
}

const failCount = findings.filter((finding) => finding.severity === "FAIL").length;
const warnCount = findings.filter((finding) => finding.severity === "WARN").length;
const status = failCount ? "FAIL" : warnCount ? "WARN" : "PASS";
const report = {
  schema_version: 1,
  generated_at: new Date().toISOString(),
  status,
  source_status_path: STATUS_PATH,
  source_state_path: STATE_PATH,
  summary,
  state_summary: stateSummary,
  entries,
  manual_review_entries: manualReviewEntries,
  operator_gate_required: summary.public_ready > 0 || summary.member_ready > 0 || summary.effective_public > 0,
  operator_gates: OPERATOR_GATES,
  runtime_action_executed: false,
  next_safe_step: manualReviewEntries.length
    ? "Manual-Review-Einträge lokal als Evidence prüfen; alle Public-/Member-Gates geschlossen lassen."
    : "Als Gate-Evidence verwenden; keine Runtime-Aktion aus diesem Verifier ableiten.",
  stop_rule: "Dieses Skript ist read-only. Es darf keine Sichtbarkeit ändern, keinen Rerun starten, nichts veröffentlichen und keine Reports löschen.",
  findings,
  fail_count: failCount,
  warn_count: warnCount,
};

fs.mkdirSync(OUT_DIR, { recursive: true });
fs.writeFileSync(OUT_JSON, JSON.stringify(report, null, 2), "utf8");
fs.writeFileSync(OUT_MD, buildMarkdown(report), "utf8");

if (status === "FAIL") {
  console.error(`Room16 review gate status failed. Output: ${OUT_JSON}`);
  process.exit(1);
}

console.log(`Room16 review gate status ${status}. Output: ${OUT_JSON}`);
