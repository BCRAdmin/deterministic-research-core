# Room16 Server Module Boundary

Stand: 2026-05-18

`server.mjs` remains the runtime entrypoint, but new server logic should move behind small modules before it grows further.

## Target Slices

- `config/` — env parsing, host/port/network policy, runtime paths
- `filesystem/` — allowlisted file reads, report IDs, path traversal guards
- `jobs/` — job store, runner, retry/cancel/delete lifecycle
- `library/` — public-library state, review gates, dismissal
- `routes/` — Express route registration by domain
- `providers/` — model profile and paid-provider confirmation policy
- `symbols/` — ticker resolver and alias state

## Current First Extraction

- `mutating-api-guard.mjs` owns network-binding policy and token enforcement for mutating API routes.
- `public-library-gate.mjs` owns the public/member promotion gate so `draft_markdown_qa`, `manual_review`, `internal_best` and incomplete promotion stacks remain hidden.

## Guardrail

No extraction may weaken the existing promotion gates: `draft_markdown_qa`, `manual_review` and `internal_best` must not become public/member-ready through route refactors.
