export function evaluatePublicLibraryGate(entry) {
  const hasPdf = Boolean(entry.pdfUrl);
  const hasMarkdown = Boolean(entry.markdownUrl || entry.internalBestReportUrl);
  const qualityPass = entry.qualityDecision?.quality_verdict === "pass" || entry.qualityVerdict === "pass";
  const qualityFail = entry.qualityDecision?.quality_verdict === "fail" || entry.qualityVerdict === "fail";
  const manualReview = entry.qualityStatus === "manual_review" || entry.reviewStatusMetric === "manual_review";
  const generationStage = entry.generationStage || entry.qualityMetrics?.generation_stage || null;
  const renderMode = entry.renderMode || entry.qualityMetrics?.render_mode || null;
  const finalDocumentsRendered = entry.finalDocumentsRendered === true || entry.qualityMetrics?.final_documents_rendered === true;
  const promotionPublicReady = entry.promotionStatus?.public_ready === true;
  const promotionReviewedBy = Boolean(entry.promotionStatus?.reviewed_by || entry.promotionStatus?.reviewedBy);
  const promotionApprovedAt = Boolean(entry.promotionStatus?.approved_at || entry.promotionStatus?.approvedAt);
  const promotionRequestedPublic =
    (entry.promotionStatus?.requested_visibility || entry.promotionStatus?.requestedVisibility) === "public";
  const promotionNonAdvice = entry.promotionStatus?.non_advice_confirmed === true || entry.promotionStatus?.nonAdviceConfirmed === true;
  const promotionSourcesVerified = entry.promotionStatus?.sources_human_verified === true || entry.promotionStatus?.sourcesHumanVerified === true;
  const promotionBlockingIssues = Array.isArray(entry.promotionStatus?.blocking_issues || entry.promotionStatus?.blockingIssues)
    ? (entry.promotionStatus?.blocking_issues || entry.promotionStatus?.blockingIssues)
    : [];
  const lifecyclePublicReady = entry.publicReady === true;
  const markdownFirstQa = generationStage === "draft_markdown_qa" || renderMode === "markdown_first_qa";
  const internalBest = generationStage === "internal_best";
  const hasPublishReport = Boolean(entry.publishReportUrl);
  const sourceHumanVerified = entry.sourceStatus === "human_verified";
  const sourcePipelineVerified = entry.sourceStatus === "pipeline_verified" || sourceHumanVerified;
  const reviewComplete = entry.reviewStatus === "reviewed";
  const nonAdvice = entry.nonAdvice === true;
  const blockers = [];
  const warnings = [];

  if (!hasPdf && !hasMarkdown) {
    blockers.push("pdf_missing");
  } else if (!hasPdf) {
    warnings.push("final_pdf_not_rendered");
  }
  if (markdownFirstQa) {
    blockers.push("markdown_first_qa_not_public");
    warnings.push("qa_pass_is_not_public_ready");
  }
  if (internalBest) blockers.push("internal_best_not_public");
  if (!finalDocumentsRendered) blockers.push("final_documents_not_rendered");
  if (generationStage !== "public_final") warnings.push("not_public_final_stage");
  if (!promotionPublicReady || !lifecyclePublicReady) blockers.push("promotion_not_public_ready");
  if (generationStage === "public_final" && !hasPublishReport) blockers.push("publish_report_missing");
  if (!promotionReviewedBy) blockers.push("promotion_reviewed_by_missing");
  if (!promotionApprovedAt) blockers.push("promotion_approved_at_missing");
  if (!promotionRequestedPublic) blockers.push("promotion_requested_visibility_not_public");
  if (!promotionNonAdvice) blockers.push("promotion_non_advice_missing");
  if (!promotionSourcesVerified) blockers.push("promotion_sources_human_verified_missing");
  if (promotionBlockingIssues.length) blockers.push("promotion_blocking_issues");
  if (qualityFail) {
    blockers.push("quality_failed");
    if (entry.qualityDecision) blockers.push("quality_decision_failed");
  }
  if (manualReview) {
    blockers.push("manual_review_required");
    warnings.push("not_publishable_without_manual_resolution");
  }
  if (!nonAdvice) blockers.push("non_advice_policy_missing");
  if (!hasMarkdown) warnings.push("markdown_missing");
  if (!qualityPass) warnings.push("pipeline_quality_not_passed");
  if (!sourcePipelineVerified) warnings.push("sources_not_pipeline_verified");
  if (!sourceHumanVerified) warnings.push("sources_not_human_verified");
  if (!reviewComplete) warnings.push("human_review_open");

  let status = "needs_human_review";
  if (qualityFail) {
    status = "rejected";
  } else if (manualReview) {
    status = "manual_review";
  } else if (markdownFirstQa || internalBest) {
    status = "internal_only";
  } else if (blockers.length) {
    status = blockers.includes("non_advice_policy_missing") && !blockers.includes("pdf_missing") && !blockers.includes("quality_failed")
      ? "internal_only"
      : "rejected";
  } else if (
    qualityPass &&
    hasPdf &&
    hasMarkdown &&
    finalDocumentsRendered &&
    generationStage === "public_final" &&
    hasPublishReport &&
    promotionPublicReady &&
    promotionReviewedBy &&
    promotionApprovedAt &&
    promotionRequestedPublic &&
    promotionNonAdvice &&
    promotionSourcesVerified &&
    promotionBlockingIssues.length === 0 &&
    lifecyclePublicReady &&
    reviewComplete &&
    sourceHumanVerified &&
    nonAdvice
  ) {
    status = "public_ready";
  } else if (qualityPass && hasPdf && hasMarkdown && finalDocumentsRendered && reviewComplete && sourcePipelineVerified && nonAdvice) {
    status = "needs_human_review";
  }

  const effectiveVisibility =
    entry.visibility === "public" && status === "public_ready"
      ? "public"
      : entry.visibility === "member" && ["member_ready", "public_ready"].includes(status)
        ? "member"
        : "hidden";

  return {
    status,
    effectiveVisibility,
    publicReady: status === "public_ready",
    memberReady: ["member_ready", "public_ready"].includes(status),
    blockers,
    warnings
  };
}
