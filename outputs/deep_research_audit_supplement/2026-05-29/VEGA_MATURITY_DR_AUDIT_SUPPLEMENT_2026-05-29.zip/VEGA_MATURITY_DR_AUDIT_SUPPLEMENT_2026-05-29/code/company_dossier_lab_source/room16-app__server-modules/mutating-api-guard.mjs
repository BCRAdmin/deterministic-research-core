const LOCAL_HOSTS = new Set(["127.0.0.1", "localhost", "::1"]);

export function isNetworkHost(host) {
  return !LOCAL_HOSTS.has(host);
}

export function enforceNetworkBindingPolicy({ host, env = process.env }) {
  if (!isNetworkHost(host)) return;

  if (env.ROOM16_ALLOW_NETWORK !== "1") {
    console.error(
      `Room16 refuses to bind to ${host}. Set ROOM16_ALLOW_NETWORK=1 and ROOM16_API_TOKEN for network access.`
    );
    process.exit(1);
  }

  if (!env.ROOM16_API_TOKEN) {
    console.error("Room16 network access requires ROOM16_API_TOKEN.");
    process.exit(1);
  }
}

export function createMutatingApiGuard({ host, env = process.env }) {
  const apiToken = env.ROOM16_API_TOKEN || "";
  const tokenRequired = Boolean(apiToken) || isNetworkHost(host);

  return function requireMutatingApiAccess(req, res) {
    if (!tokenRequired) return true;

    const authHeader = req.get("authorization") || "";
    const bearerToken = authHeader.startsWith("Bearer ") ? authHeader.slice("Bearer ".length) : "";
    const headerToken = req.get("x-room16-api-token") || "";

    if (bearerToken === apiToken || headerToken === apiToken) return true;

    res.status(401).json({ error: "Mutating Room16 API request requires a valid operator token." });
    return false;
  };
}
