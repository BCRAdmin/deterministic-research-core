#!/usr/bin/env python3
"""Build a Room 16 model capability and quick/deep pair matrix."""

from __future__ import annotations

import argparse
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]

OLLAMA_MODELS = [
    "qwen2.5-coder:3b",
    "qwen2.5-coder:7b",
    "kimi-k2.6:cloud",
    "glm-5.1:cloud",
    "deepseek-v4-pro:cloud",
]
OPENAI_MODELS = [
    "gpt-5.5",
    "gpt-5.4",
    "gpt-5.4-mini",
]


def _latest_smoke() -> Path:
    candidates = sorted((ROOT / ".runtime" / "room16-smokes").glob("model-smoke-*.json"))
    if not candidates:
        raise SystemExit("No model smoke JSON found. Run scripts/room16_model_smoke.py first.")
    return candidates[-1]


def _mode_ok(result: dict[str, Any], mode: str) -> bool:
    return bool(result.get(mode, {}).get("ok"))


def _capability_label(result: dict[str, Any] | None, provider: str) -> str:
    if result is None:
        if provider == "openai" and not os.getenv("OPENAI_API_KEY"):
            return "blocked: OPENAI_API_KEY missing"
        return "not tested"
    parts = []
    for mode in ["plain", "tool", "structured"]:
        parts.append(f"{mode}={'ok' if _mode_ok(result, mode) else 'fail'}")
    return ", ".join(parts)


def _pair_status(
    quick_result: dict[str, Any] | None,
    deep_result: dict[str, Any] | None,
    provider: str,
) -> tuple[str, str]:
    if provider == "openai" and not os.getenv("OPENAI_API_KEY"):
        return "blocked", "OPENAI_API_KEY is not available in this shell."
    if quick_result is None or deep_result is None:
        return "not_tested", "Missing smoke result."

    quick_ok = (
        _mode_ok(quick_result, "plain")
        and _mode_ok(quick_result, "tool")
        and _mode_ok(quick_result, "structured")
    )
    deep_ok = _mode_ok(deep_result, "plain") and _mode_ok(deep_result, "structured")

    if quick_ok and deep_ok:
        return "candidate", "Passes required Room 16 interface capabilities."
    if not quick_ok:
        return "reject", "Quick model lacks plain/tool/structured capability."
    return "reject", "Deep model lacks plain/structured capability."


def _markdown_table(headers: list[str], rows: list[list[Any]]) -> str:
    out = ["| " + " | ".join(headers) + " |"]
    out.append("| " + " | ".join("---" for _ in headers) + " |")
    for row in rows:
        out.append("| " + " | ".join(str(cell).replace("\n", " ") for cell in row) + " |")
    return "\n".join(out)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--smoke-json", default=None)
    parser.add_argument("--out-dir", default=str(ROOT / ".runtime" / "room16-model-matrix"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    smoke_path = Path(args.smoke_json) if args.smoke_json else _latest_smoke()
    smoke = json.loads(smoke_path.read_text(encoding="utf-8"))
    smoke_models = smoke.get("models", {})
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    created_at = datetime.now().isoformat(timespec="seconds")

    providers: dict[str, list[str]] = {
        "ollama": OLLAMA_MODELS,
        "openai": OPENAI_MODELS,
    }
    report: dict[str, Any] = {
        "created_at": created_at,
        "smoke_source": str(smoke_path),
        "providers": {},
        "pairs": [],
    }

    md: list[str] = [
        "# Room 16 Model Matrix",
        "",
        f"Created: `{created_at}`",
        f"Smoke source: `{smoke_path}`",
        "",
        "Scope: same-provider Quick/Deep pairs supported by the current Room 16 runner.",
        "",
    ]

    for provider, models in providers.items():
        capability_rows = []
        provider_results: dict[str, Any] = {}
        for model in models:
            result = smoke_models.get(model) if provider == "ollama" else None
            provider_results[model] = result
            capability_rows.append([provider, model, _capability_label(result, provider)])

        report["providers"][provider] = provider_results
        md.append(f"## {provider}")
        md.append("")
        md.append(_markdown_table(["Provider", "Model", "Capability"], capability_rows))
        md.append("")

        pair_rows = []
        for quick in models:
            for deep in models:
                quick_result = provider_results.get(quick)
                deep_result = provider_results.get(deep)
                status, reason = _pair_status(quick_result, deep_result, provider)
                row = {
                    "provider": provider,
                    "quick_model": quick,
                    "deep_model": deep,
                    "status": status,
                    "reason": reason,
                }
                report["pairs"].append(row)
                pair_rows.append([quick, deep, status, reason])
        md.append(_markdown_table(["Quick", "Deep", "Status", "Reason"], pair_rows))
        md.append("")

    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    json_path = out_dir / f"model-matrix-{stamp}.json"
    md_path = out_dir / f"model-matrix-{stamp}.md"
    json_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    md_path.write_text("\n".join(md), encoding="utf-8")
    print(json_path)
    print(md_path)


if __name__ == "__main__":
    main()
