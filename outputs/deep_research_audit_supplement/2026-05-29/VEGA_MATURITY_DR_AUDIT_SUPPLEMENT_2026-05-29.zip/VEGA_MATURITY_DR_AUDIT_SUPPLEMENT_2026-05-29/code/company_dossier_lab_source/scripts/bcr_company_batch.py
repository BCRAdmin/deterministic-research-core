#!/usr/bin/env python3
"""Run the original TradingAgents flow for a small company batch.

This keeps the upstream trading/research/risk blocks intact for the first
internal test. It only adds local runtime paths, a research-only banner, and a
batch manifest so results can be inspected consistently.
"""

from __future__ import annotations

import argparse
import json
import multiprocessing as mp
import os
import re
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from langchain_core.callbacks import BaseCallbackHandler

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tradingagents.default_config import DEFAULT_CONFIG
from tradingagents.graph.trading_graph import TradingAgentsGraph
from tradingagents.agents.utils.provenance import configured_vendor
from tradingagents.symbols import normalize_path_symbol


DEFAULT_TICKERS = ("AAPL", "MSFT", "NVDA", "TSLA")


def _project_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _build_config(args: argparse.Namespace, run_dir: Path) -> dict[str, Any]:
    config = DEFAULT_CONFIG.copy()
    config.update(
        {
            "llm_provider": args.provider,
            "deep_think_llm": args.deep_model,
            "quick_think_llm": args.quick_model,
            "backend_url": args.backend_url,
            "llm_timeout": args.llm_timeout,
            "llm_max_retries": args.llm_max_retries,
            "openai_reasoning_effort": args.openai_reasoning_effort,
            "output_language": args.output_language,
            "max_debate_rounds": args.debate_rounds,
            "max_risk_discuss_rounds": args.risk_rounds,
            "benchmark_ticker": args.benchmark,
            "checkpoint_enabled": args.checkpoint,
            "results_dir": str(run_dir / "results"),
            "data_cache_dir": str(run_dir / "cache"),
            "memory_log_path": str(run_dir / "memory" / "trading_memory.md"),
        }
    )
    return config


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")


def _extract_source_metadata_blocks(output: Any) -> list[dict[str, str]]:
    text = str(output or "")
    blocks = re.findall(
        r"\[Room16 Source Metadata\](.*?)\[/Room16 Source Metadata\]",
        text,
        flags=re.DOTALL,
    )
    entries: list[dict[str, str]] = []
    for block in blocks:
        entry: dict[str, str] = {}
        for line in block.splitlines():
            if ":" not in line:
                continue
            key, value = line.split(":", 1)
            key = key.strip()
            if key in {"source_id", "source_type", "asof", "period_type", "formula_id", "source_priority"}:
                entry[key] = value.strip()
        if entry.get("source_id"):
            entries.append(entry)
    return entries


def _safe_source_part(value: Any) -> str:
    text = str(value or "unknown").strip().lower()
    text = re.sub(r"[^a-z0-9._:-]+", "-", text)
    return text.strip("-") or "unknown"


def _tool_source_entry(tool_name: str, input_value: Any, fallback_ticker: str) -> dict[str, str]:
    """Build a deterministic ledger row from callback metadata.

    Some LangChain providers return tool outputs to callbacks without the raw
    text prefix we add in the tool implementation. The callback-level row keeps
    the ledger alive even when provider/tool transport strips those text blocks.
    """
    tool = str(tool_name or "tool")
    text = json.dumps(input_value, default=str) if isinstance(input_value, (dict, list)) else str(input_value or "")
    dates = re.findall(r"\d{4}-\d{2}-\d{2}", text)
    asof = dates[-1] if dates else "unknown"
    ticker_match = re.search(r"\b[A-Z][A-Z0-9.]{0,7}\b", text)
    symbol = ticker_match.group(0) if ticker_match else fallback_ticker
    source_type = f"vendor:{configured_vendor(tool)}"
    period_type = "mixed"
    formula_id = "tool_invocation"
    if tool == "get_stock_data":
        period_type = "daily"
        formula_id = "ohlcv_vendor_raw"
    elif tool == "get_indicators":
        period_type = "calculated"
        indicator_match = re.search(r"indicator['\"]?\s*[:=]\s*['\"]?([A-Za-z0-9_, -]+)", text)
        indicator = _safe_source_part(indicator_match.group(1).split(",")[0] if indicator_match else "technical")
        lookback_match = re.search(r"look_back_days['\"]?\s*[:=]\s*(\d+)", text)
        lookback = lookback_match.group(1) if lookback_match else "unknown"
        formula_id = f"technical_indicator:{indicator}:lookback_{lookback}"
    elif tool in {"get_news", "get_global_news", "get_insider_transactions"}:
        period_type = "event_window"
        formula_id = f"{tool}:raw"
    elif tool == "get_fundamentals":
        period_type = "mixed"
        formula_id = "fundamentals_vendor_raw"
    elif tool == "get_balance_sheet":
        period_type = "balance_sheet_spot"
        formula_id = "balance_sheet_vendor_raw"
    elif tool == "get_cashflow":
        period_type = "quarterly"
        formula_id = "cashflow_vendor_raw"
    elif tool == "get_income_statement":
        period_type = "quarterly"
        formula_id = "income_statement_vendor_raw"
    source_id = ":".join(
        [
            "callback",
            _safe_source_part(tool),
            _safe_source_part(symbol),
            _safe_source_part(asof),
            _safe_source_part(formula_id),
        ]
    )
    return {
        "source_id": source_id,
        "source_type": source_type,
        "asof": asof,
        "period_type": period_type,
        "formula_id": formula_id,
        "source_priority": "SEC/IR > transcript > vendor > social; callback row records actual tool invocation.",
    }


class Room16ProgressCallback(BaseCallbackHandler):
    """Write coarse LLM/tool progress events for long TradingAgents runs."""

    def __init__(self, ticker: str, progress_path: Path, source_ledger_path: Path):
        self.ticker = ticker
        self.progress_path = progress_path
        self.source_ledger_path = source_ledger_path
        self._ledger_seen: set[str] = set()
        self.progress_path.parent.mkdir(parents=True, exist_ok=True)
        self.source_ledger_path.parent.mkdir(parents=True, exist_ok=True)

    def _event(self, event: str, detail: str = "") -> None:
        payload = {
            "time": datetime.now().isoformat(timespec="seconds"),
            "ticker": self.ticker,
            "event": event,
            "detail": detail,
        }
        with self.progress_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, default=str) + "\n")
        if event.endswith("_start") or event.endswith("_error") or event.endswith("_end"):
            label = f"[{self.ticker}] {event}"
            if detail:
                label = f"{label}: {detail}"
            print(label, flush=True)

    def on_chat_model_start(self, serialized, messages, **kwargs):  # type: ignore[no-untyped-def]
        invocation = kwargs.get("invocation_params") or {}
        model = invocation.get("model") or invocation.get("model_name") or ""
        self._event("llm_start", str(model))

    def on_llm_start(self, serialized, prompts, **kwargs):  # type: ignore[no-untyped-def]
        invocation = kwargs.get("invocation_params") or {}
        model = invocation.get("model") or invocation.get("model_name") or ""
        self._event("llm_start", str(model))

    def on_llm_end(self, response, **kwargs):  # type: ignore[no-untyped-def]
        self._event("llm_end")

    def on_llm_error(self, error, **kwargs):  # type: ignore[no-untyped-def]
        self._event("llm_error", f"{type(error).__name__}: {error}")

    def on_tool_start(self, serialized, input_str, **kwargs):  # type: ignore[no-untyped-def]
        name = serialized.get("name", "tool") if isinstance(serialized, dict) else "tool"
        self._write_source_entry(_tool_source_entry(str(name), input_str, self.ticker))
        self._event("tool_start", str(name))

    def on_tool_end(self, output, **kwargs):  # type: ignore[no-untyped-def]
        for entry in _extract_source_metadata_blocks(output):
            self._write_source_entry(entry)
        self._event("tool_end")

    def on_tool_error(self, error, **kwargs):  # type: ignore[no-untyped-def]
        self._event("tool_error", f"{type(error).__name__}: {error}")

    def _write_source_entry(self, entry: dict[str, str]) -> None:
        source_id = entry.get("source_id")
        if not source_id or source_id in self._ledger_seen:
            return
        self._ledger_seen.add(source_id)
        payload = {
            "time": datetime.now().isoformat(timespec="seconds"),
            "ticker": self.ticker,
            **entry,
        }
        with self.source_ledger_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(payload, default=str) + "\n")


def _run_ticker_worker(
    ticker: str,
    trade_date: str,
    analysts: list[str],
    config: dict[str, Any],
    result_path: str,
    progress_path: str,
    debug: bool,
) -> None:
    started = time.monotonic()
    source_ledger_path = Path(progress_path).with_name("source-ledger.jsonl")
    progress = Room16ProgressCallback(ticker, Path(progress_path), source_ledger_path)
    try:
        print(f"[{ticker}] starting original TradingAgents flow", flush=True)
        graph = TradingAgentsGraph(
            selected_analysts=analysts,
            debug=debug,
            config=config,
            callbacks=[progress],
        )
        state, decision = graph.propagate(ticker, trade_date)
        result = {
            "ticker": ticker,
            "status": "ok",
            "elapsed_seconds": round(time.monotonic() - started, 2),
            "decision": decision,
            "log_file": str(
                Path(config["results_dir"])
                / ticker
                / "TradingAgentsStrategy_logs"
                / f"full_states_log_{trade_date}.json"
            ),
            "progress_file": progress_path,
            "source_ledger_file": str(source_ledger_path),
            "final_trade_decision": state.get("final_trade_decision"),
            "trader_investment_decision": state.get("trader_investment_plan"),
            "investment_plan": state.get("investment_plan"),
        }
        _write_json(Path(result_path), result)
        print(f"[{ticker}] completed in {result['elapsed_seconds']}s", flush=True)
    except Exception as exc:  # pragma: no cover - operational runner path
        result = {
            "ticker": ticker,
            "status": "error",
            "elapsed_seconds": round(time.monotonic() - started, 2),
            "error": f"{type(exc).__name__}: {exc}",
            "progress_file": progress_path,
            "source_ledger_file": str(source_ledger_path),
        }
        _write_json(Path(result_path), result)
        print(f"[{ticker}] error: {result['error']}", flush=True)


def _assert_runtime_ready(provider: str) -> None:
    provider = provider.lower()
    env_by_provider = {
        "openai": "OPENAI_API_KEY",
        "google": "GOOGLE_API_KEY",
        "anthropic": "ANTHROPIC_API_KEY",
        "xai": "XAI_API_KEY",
        "deepseek": "DEEPSEEK_API_KEY",
        "qwen": "DASHSCOPE_API_KEY",
        "glm": "ZHIPU_API_KEY",
        "openrouter": "OPENROUTER_API_KEY",
    }
    required = env_by_provider.get(provider)
    if required and not os.getenv(required):
        raise SystemExit(f"Missing {required} for provider={provider}.")


def _is_retryable_result(result: dict[str, Any]) -> bool:
    if result.get("status") == "ok":
        return False
    error = str(result.get("error", "")).lower()
    retry_markers = (
        "timeout",
        "overload",
        "server error",
        "internalservererror",
        "temporarily",
        "502",
        "503",
        "504",
        "rate limit",
    )
    return any(marker in error for marker in retry_markers)


def _watch_process(
    process: mp.Process,
    *,
    started: float,
    progress_path: Path,
    ticker_timeout_seconds: float,
    stall_timeout_seconds: float,
) -> str | None:
    """Wait for a ticker subprocess and return a timeout reason if killed."""
    while process.is_alive():
        process.join(5)
        if not process.is_alive():
            return None
        elapsed = time.monotonic() - started
        if elapsed >= ticker_timeout_seconds:
            return f"Ticker subprocess exceeded {ticker_timeout_seconds}s and was terminated."
        if stall_timeout_seconds > 0:
            last_progress_at = progress_path.stat().st_mtime if progress_path.exists() else time.time() - elapsed
            stale_for = time.time() - last_progress_at
            if stale_for >= stall_timeout_seconds:
                return (
                    "Ticker subprocess produced no progress for "
                    f"{stall_timeout_seconds}s and was terminated."
                )
    return None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--tickers",
        nargs="+",
        default=list(DEFAULT_TICKERS),
        help="Ticker symbols to run. Default: AAPL MSFT NVDA TSLA.",
    )
    parser.add_argument(
        "--date",
        default=datetime.now().strftime("%Y-%m-%d"),
        help="Analysis date in YYYY-MM-DD format.",
    )
    parser.add_argument("--provider", default=os.getenv("BCR_TA_PROVIDER", "ollama"))
    parser.add_argument(
        "--deep-model",
        default=os.getenv("BCR_TA_DEEP_MODEL", "deepseek-v4-pro:cloud"),
    )
    parser.add_argument(
        "--quick-model",
        default=os.getenv("BCR_TA_QUICK_MODEL", "deepseek-v4-pro:cloud"),
    )
    parser.add_argument(
        "--backend-url",
        default=os.getenv("BCR_TA_BACKEND_URL") or None,
    )
    parser.add_argument("--benchmark", default=os.getenv("BCR_TA_BENCHMARK", "SPY"))
    parser.add_argument("--output-language", default="German")
    parser.add_argument("--llm-timeout", type=float, default=300.0)
    parser.add_argument("--llm-max-retries", type=int, default=2)
    parser.add_argument(
        "--openai-reasoning-effort",
        default=os.getenv("BCR_TA_OPENAI_REASONING_EFFORT") or None,
        choices=[None, "none", "low", "medium", "high", "xhigh"],
    )
    parser.add_argument("--ticker-timeout-seconds", type=float, default=1800.0)
    parser.add_argument("--stall-timeout-seconds", type=float, default=600.0)
    parser.add_argument("--ticker-retries", type=int, default=2)
    parser.add_argument("--retry-delay-seconds", type=float, default=30.0)
    parser.add_argument(
        "--run-dir",
        default=None,
        help="Existing or new runtime directory. Reuse with --checkpoint to resume.",
    )
    parser.add_argument("--debate-rounds", type=int, default=1)
    parser.add_argument("--risk-rounds", type=int, default=1)
    parser.add_argument("--checkpoint", action="store_true")
    parser.add_argument("--debug", action="store_true")
    parser.add_argument(
        "--analysts",
        nargs="+",
        default=["market", "social", "news", "fundamentals"],
        choices=["market", "social", "news", "fundamentals"],
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate config and write a manifest without calling LLMs.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    tickers = [normalize_path_symbol(ticker) for ticker in args.tickers]

    if args.run_dir:
        run_dir = Path(args.run_dir).expanduser()
        if not run_dir.is_absolute():
            run_dir = (_project_root() / run_dir).resolve()
    else:
        run_dir = _project_root() / ".runtime" / "bcr-company-batches" / (
            datetime.now().strftime("%Y%m%d-%H%M%S")
        )
    run_dir.mkdir(parents=True, exist_ok=True)

    config = _build_config(args, run_dir)
    manifest: dict[str, Any] = {
        "status": "dry_run" if args.dry_run else "running",
        "research_only": True,
        "financial_advice": False,
        "upstream_flow": "TradingAgents v0.2.4 original analyst/researcher/trader/risk blocks",
        "tickers": tickers,
        "date": args.date,
        "provider": args.provider,
        "deep_model": args.deep_model,
        "quick_model": args.quick_model,
        "llm_timeout": args.llm_timeout,
        "llm_max_retries": args.llm_max_retries,
        "ticker_timeout_seconds": args.ticker_timeout_seconds,
        "stall_timeout_seconds": args.stall_timeout_seconds,
        "ticker_retries": args.ticker_retries,
        "retry_delay_seconds": args.retry_delay_seconds,
        "analysts": args.analysts,
        "run_dir": str(run_dir),
        "resumable": bool(args.checkpoint),
        "results": [],
    }

    print("BCR company batch: research-only internal test, not financial advice.")
    print(f"Tickers: {', '.join(tickers)}")
    print(f"Run dir: {run_dir}")

    _assert_runtime_ready(args.provider)

    if args.dry_run:
        _write_json(run_dir / "batch_manifest.json", manifest)
        print("Dry run OK. No LLM calls were made.")
        return

    manifest_path = run_dir / "batch_manifest.json"
    _write_json(manifest_path, manifest)

    ctx = mp.get_context("spawn")
    for ticker in tickers:
        ticker_dir = run_dir / "tickers" / ticker
        result_path = ticker_dir / "result.json"
        progress_path = ticker_dir / "progress.jsonl"
        result_item = {
            "ticker": ticker,
            "status": "running",
            "started_at": datetime.now().isoformat(timespec="seconds"),
            "progress_file": str(progress_path),
            "result_file": str(result_path),
            "attempts": [],
        }
        manifest["results"].append(result_item)
        _write_json(manifest_path, manifest)

        max_attempts = max(1, args.ticker_retries + 1)
        for attempt in range(1, max_attempts + 1):
            attempt_result_path = ticker_dir / f"result-attempt-{attempt}.json"
            attempt_progress_path = ticker_dir / f"progress-attempt-{attempt}.jsonl"
            print(f"[{ticker}] attempt {attempt}/{max_attempts}", flush=True)

            process = ctx.Process(
                target=_run_ticker_worker,
                args=(
                    ticker,
                    args.date,
                    list(args.analysts),
                    config,
                    str(attempt_result_path),
                    str(attempt_progress_path),
                    args.debug,
                ),
            )
            started = time.monotonic()
            process.start()
            timeout_reason = _watch_process(
                process,
                started=started,
                progress_path=attempt_progress_path,
                ticker_timeout_seconds=args.ticker_timeout_seconds,
                stall_timeout_seconds=args.stall_timeout_seconds,
            )

            if timeout_reason:
                process.terminate()
                process.join(10)
                attempt_result = {
                    "ticker": ticker,
                    "status": "timeout",
                    "attempt": attempt,
                    "elapsed_seconds": round(time.monotonic() - started, 2),
                    "progress_file": str(attempt_progress_path),
                    "result_file": str(attempt_result_path),
                    "error": timeout_reason,
                }
            elif attempt_result_path.exists():
                attempt_result = json.loads(
                    attempt_result_path.read_text(encoding="utf-8")
                )
                attempt_result["attempt"] = attempt
                attempt_result["result_file"] = str(attempt_result_path)
            else:
                attempt_result = {
                    "ticker": ticker,
                    "status": "error",
                    "attempt": attempt,
                    "elapsed_seconds": round(time.monotonic() - started, 2),
                    "progress_file": str(attempt_progress_path),
                    "result_file": str(attempt_result_path),
                    "error": f"ticker subprocess exited with code {process.exitcode}",
                }

            result_item["attempts"].append(attempt_result)
            result_item.update(attempt_result)
            if attempt_result_path.exists():
                result_path.write_text(
                    attempt_result_path.read_text(encoding="utf-8"),
                    encoding="utf-8",
                )
            if attempt_progress_path.exists():
                progress_path.write_text(
                    attempt_progress_path.read_text(encoding="utf-8"),
                    encoding="utf-8",
                )
            _write_json(manifest_path, manifest)

            if not _is_retryable_result(attempt_result) or attempt == max_attempts:
                break

            print(
                f"[{ticker}] retrying after {args.retry_delay_seconds}s: "
                f"{attempt_result.get('error')}",
                flush=True,
            )
            time.sleep(args.retry_delay_seconds)

    manifest["status"] = (
        "completed"
        if all(item["status"] == "ok" for item in manifest["results"])
        else "completed_with_errors"
    )
    _write_json(manifest_path, manifest)
    print(f"Batch status: {manifest['status']}")


if __name__ == "__main__":
    main()
