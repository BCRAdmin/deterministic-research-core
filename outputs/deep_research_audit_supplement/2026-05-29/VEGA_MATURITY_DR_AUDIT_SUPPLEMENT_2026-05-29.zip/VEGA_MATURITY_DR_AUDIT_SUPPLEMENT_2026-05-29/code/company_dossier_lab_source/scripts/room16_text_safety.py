#!/usr/bin/env python3
"""Shared visible-text safety helpers for Room 16 deliverables."""

from __future__ import annotations

import re


VISIBLE_REASONING_LEAK_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    (
        "self_correction_nein_warte",
        re.compile(r"\b(?:oh\s+)?nein,\s*warte\b", re.IGNORECASE),
    ),
    (
        "self_correction_wait",
        re.compile(r"\b(?:oh\s+)?(?:no,\s*)?wait\b", re.IGNORECASE),
    ),
    (
        "visible_recheck_instruction",
        re.compile(r"\blet\s+me\s+(?:recheck|check|think|verify)\b", re.IGNORECASE),
    ),
    (
        "visible_assistant_apology",
        re.compile(r"\b(?:sorry|entschuldigung)\b", re.IGNORECASE),
    ),
    (
        "chain_of_thought_label",
        re.compile(r"\b(?:chain[- ]of[- ]thought|reasoning_content|analysis\s+thoughts?)\b", re.IGNORECASE),
    ),
    (
        "first_person_draft_thought",
        re.compile(r"\blet'?s\s+(?:check|think|recheck|verify)\b", re.IGNORECASE),
    ),
]

_SPECIFIC_RECHECK_AFTER_COMPARISON_RE = re.compile(
    r",\s*ebenso\s+(?:die\s+)?(?:\d{2,3}\s*)?SMA\s*\([^.\n]*?"
    r"\b(?:oh\s+)?nein,\s*warte:[^\n]*?\blet\s+me\s+recheck\.\s*"
    r"\n\s*\n\s*Tatsächlich:\s*",
    re.IGNORECASE,
)
_INLINE_RECHECK_FRAGMENT_RE = re.compile(
    r"\s*[—-]\s*(?:oh\s+)?(?:nein,\s*warte|no,\s*wait|wait):?[^\n]{0,520}"
    r"(?:\blet\s+me\s+(?:recheck|check|think|verify)\.)?",
    re.IGNORECASE,
)
_STANDALONE_META_LINE_RE = re.compile(
    r"(?im)^\s*(?:let\s+me\s+(?:recheck|check|think|verify)|"
    r"i\s+(?:need\s+to\s+)?(?:recheck|check|think|verify)|"
    r"ich\s+(?:muss|werde|sollte)\s+(?:nochmal\s+)?(?:prüfen|nachprüfen|denken|rechnen))"
    r"[^\n]*$"
)


def find_visible_reasoning_leaks(text: str) -> list[str]:
    """Return machine-readable leak labels found in visible report text."""

    return [label for label, pattern in VISIBLE_REASONING_LEAK_PATTERNS if pattern.search(text)]


def strip_visible_reasoning_artifacts(text: str) -> str:
    """Remove visible draft/recheck artifacts while preserving corrected prose."""

    text = _SPECIFIC_RECHECK_AFTER_COMPARISON_RE.sub(". ", text)
    text = _INLINE_RECHECK_FRAGMENT_RE.sub("", text)
    text = _STANDALONE_META_LINE_RE.sub("", text)
    text = re.sub(r"[ \t]{2,}", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()
