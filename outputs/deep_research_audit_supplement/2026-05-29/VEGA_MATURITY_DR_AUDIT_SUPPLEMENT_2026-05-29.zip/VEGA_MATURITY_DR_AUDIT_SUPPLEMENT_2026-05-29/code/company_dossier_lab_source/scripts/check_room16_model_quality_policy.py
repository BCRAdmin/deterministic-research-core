#!/usr/bin/env python3
"""Verify the Room 16 model-quality policy stays enforceable.

This is a no-LLM smoke. It proves that new Room 16 company report generation
defaults to the proven DeepSeek lane, while local Qwen stays limited to
orchestration, QA and source-gate prep.
"""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXPECTED_PROVIDER = "ollama"
EXPECTED_MODEL = "deepseek-v4-pro:cloud"
KNOWN_RUN = ROOT / "reports" / "room16" / "runs" / "20260502-anet-ceg-vrt-be"


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore") if path.exists() else ""


def read_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def fail(message: str, failures: list[str]) -> None:
    failures.append(message)


def check_runner_defaults(failures: list[str]) -> None:
    runner = read_text(ROOT / "scripts" / "bcr_company_batch.py")
    if f'os.getenv("BCR_TA_PROVIDER", "{EXPECTED_PROVIDER}")' not in runner:
        fail("bcr_company_batch.py default provider is not the expected Ollama lane", failures)
    if f'os.getenv("BCR_TA_QUICK_MODEL", "{EXPECTED_MODEL}")' not in runner:
        fail("bcr_company_batch.py default quick model is not deepseek-v4-pro:cloud", failures)
    if f'os.getenv("BCR_TA_DEEP_MODEL", "{EXPECTED_MODEL}")' not in runner:
        fail("bcr_company_batch.py default deep model is not deepseek-v4-pro:cloud", failures)


def check_docs(failures: list[str]) -> None:
    standard = read_text(ROOT / "docs" / "ROOM16_REPORTING_STANDARD.md")
    if EXPECTED_MODEL not in standard:
        fail("ROOM16_REPORTING_STANDARD.md no longer names deepseek-v4-pro:cloud", failures)
    if "must not silently replace DeepSeek" not in standard:
        fail("ROOM16_REPORTING_STANDARD.md no longer blocks Qwen from replacing DeepSeek", failures)

    pipeline = read_text(
        Path.home()
        / "Library"
        / "Application Support"
        / "LIONCOM"
        / "runtime-workspace"
        / "mission-control-board"
        / "docs"
        / "quellwert-publication-pipeline.md"
    )
    if EXPECTED_MODEL not in pipeline:
        fail("quellwert-publication-pipeline.md no longer names the DeepSeek analysis lane", failures)
    if "Qwen" not in pipeline or "ersetzen" not in pipeline:
        fail("quellwert-publication-pipeline.md no longer separates Qwen from analysis generation", failures)


def check_known_run_manifests(failures: list[str]) -> None:
    if not KNOWN_RUN.exists():
        fail(f"known comparison run missing: {KNOWN_RUN}", failures)
        return
    manifests = sorted(KNOWN_RUN.glob("**/batch_manifest.json"))
    if not manifests:
        root_manifest = ROOT / ".runtime" / "bcr-company-batches" / "20260502-anet-ceg-vrt-be" / "batch_manifest.json"
        manifests = [root_manifest] if root_manifest.exists() else []
    if not manifests:
        fail("cannot find ANET/CEG/VRT/BE batch_manifest.json for DeepSeek provenance check", failures)
        return
    for manifest_path in manifests:
        manifest = read_json(manifest_path)
        if manifest.get("provider") != EXPECTED_PROVIDER:
            fail(f"{manifest_path} provider is not {EXPECTED_PROVIDER}: {manifest.get('provider')}", failures)
        if manifest.get("quick_model") != EXPECTED_MODEL:
            fail(f"{manifest_path} quick_model is not {EXPECTED_MODEL}: {manifest.get('quick_model')}", failures)
        if manifest.get("deep_model") != EXPECTED_MODEL:
            fail(f"{manifest_path} deep_model is not {EXPECTED_MODEL}: {manifest.get('deep_model')}", failures)


def main() -> int:
    failures: list[str] = []
    check_runner_defaults(failures)
    check_docs(failures)
    check_known_run_manifests(failures)

    result = {
        "ok": not failures,
        "expectedProvider": EXPECTED_PROVIDER,
        "expectedQuickModel": EXPECTED_MODEL,
        "expectedDeepModel": EXPECTED_MODEL,
        "runner": str(ROOT / "scripts" / "bcr_company_batch.py"),
        "failures": failures,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
