#!/usr/bin/env python3
"""Build readable Markdown and DOCX reports from Room 16 batch outputs."""

from __future__ import annotations

import argparse
import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any

try:
    from docx import Document
    from docx.enum.section import WD_SECTION
    from docx.enum.text import WD_BREAK
    from docx.shared import Inches, Pt, RGBColor
except ImportError:  # pragma: no cover - optional document dependency
    Document = None


ROOT = Path(__file__).resolve().parents[1]
REPORT_KEYS = [
    ("market_report", "Market / technische Lage"),
    ("sentiment_report", "Sentiment / Unternehmensstimmung"),
    ("news_report", "News / Makro-Kontext"),
    ("fundamentals_report", "Fundamentals"),
    ("trader_investment_decision", "Trader Output"),
    ("investment_plan", "Investment Plan"),
    ("final_trade_decision", "Final Trade Decision"),
]


def _clean_inline(text: str) -> str:
    text = re.sub(r"\*\*(.*?)\*\*", r"\1", text)
    text = re.sub(r"`([^`]+)`", r"\1", text)
    return text.replace("📊", "").replace("🔍", "").strip()


def _latest_completed_run() -> Path:
    base = ROOT / ".runtime" / "bcr-company-batches"
    manifests = sorted(base.glob("*/batch_manifest.json"))
    for manifest_path in reversed(manifests):
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("status") == "completed" and len(manifest.get("results", [])) >= 4:
            return manifest_path.parent
    raise SystemExit("No completed four-company Room 16 run found.")


def _load_run(run_dir: Path) -> tuple[dict[str, Any], dict[str, dict[str, Any]]]:
    manifest = json.loads((run_dir / "batch_manifest.json").read_text(encoding="utf-8"))
    states = {}
    for item in manifest.get("results", []):
        log_file = item.get("log_file")
        if not log_file:
            continue
        states[item["ticker"]] = json.loads(Path(log_file).read_text(encoding="utf-8"))
    return manifest, states


def _first_paragraph(markdown: str, max_chars: int = 900) -> str:
    blocks = [block.strip() for block in markdown.split("\n\n") if block.strip()]
    for block in blocks:
        if block.startswith("#") or block.startswith("|"):
            continue
        text = _clean_inline(block)
        if len(text) > 80:
            return text[:max_chars].rstrip() + ("..." if len(text) > max_chars else "")
    text = _clean_inline(markdown)
    return text[:max_chars].rstrip() + ("..." if len(text) > max_chars else "")


def _decision_line(text: str) -> str:
    for line in text.splitlines():
        cleaned = _clean_inline(line)
        if cleaned.startswith("Rating:") or cleaned.startswith("Recommendation:") or cleaned.startswith("Action:"):
            return cleaned
    return _clean_inline(text.splitlines()[0] if text.splitlines() else "")


def _build_markdown(
    manifest: dict[str, Any],
    states: dict[str, dict[str, Any]],
    matrix_path: str | None,
) -> str:
    created = datetime.now().strftime("%Y-%m-%d %H:%M")
    lines = [
        "# Room 16 - Vier Unternehmensreports",
        "",
        f"Erstellt: {created} Europe/Berlin",
        f"TradingAgents-Datum: {manifest.get('date')}",
        f"Run-Verzeichnis: `{manifest.get('run_dir')}`",
        "",
        "> Interner Research-Output. Keine Finanzberatung, keine Handelsanweisung, keine externe Veröffentlichung ohne Review.",
        "",
        "## Modell- und Laufkontext",
        "",
        f"- Provider: `{manifest.get('provider')}`",
        f"- Quick-Modell: `{manifest.get('quick_model')}`",
        f"- Deep-Modell: `{manifest.get('deep_model')}`",
        f"- Analysten: `{', '.join(manifest.get('analysts', []))}`",
        f"- Matrix: `{matrix_path or 'nicht angegeben'}`",
        "",
        "## Entscheidungsmatrix",
        "",
        "| Unternehmen | Status | Laufzeit | Processed decision | Final rating |",
        "| --- | ---: | ---: | --- | --- |",
    ]

    for item in manifest.get("results", []):
        ticker = item["ticker"]
        state = states.get(ticker, {})
        final_line = _decision_line(state.get("final_trade_decision", ""))
        lines.append(
            f"| `{ticker}` | {item.get('status')} | {item.get('elapsed_seconds')}s | "
            f"{item.get('decision')} | {final_line} |"
        )

    lines.extend(
        [
            "",
            "## Kurzübersicht",
            "",
        ]
    )
    for item in manifest.get("results", []):
        ticker = item["ticker"]
        state = states.get(ticker, {})
        lines.extend(
            [
                f"### {ticker}",
                "",
                f"**Finale Einordnung:** {_decision_line(state.get('final_trade_decision', ''))}",
                "",
                _first_paragraph(state.get("final_trade_decision", "")),
                "",
                f"**Trader:** {_decision_line(state.get('trader_investment_decision', ''))}",
                "",
                _first_paragraph(state.get("trader_investment_decision", ""), max_chars=700),
                "",
            ]
        )

    lines.extend(["<!-- PAGEBREAK -->", "", "# Detailreports", ""])
    for item in manifest.get("results", []):
        ticker = item["ticker"]
        state = states.get(ticker, {})
        lines.extend([f"## {ticker}", ""])
        for key, title in REPORT_KEYS:
            content = str(state.get(key, "")).strip()
            if not content:
                continue
            lines.extend([f"### {title}", "", content, ""])

    return "\n".join(lines)


def _build_company_markdown(
    manifest: dict[str, Any],
    item: dict[str, Any],
    state: dict[str, Any],
    matrix_path: str | None,
) -> str:
    ticker = item["ticker"]
    created = datetime.now().strftime("%Y-%m-%d %H:%M")
    lines = [
        f"# Room 16 - {ticker} Unternehmensreport",
        "",
        f"Erstellt: {created} Europe/Berlin",
        f"TradingAgents-Datum: {manifest.get('date')}",
        f"Run-Verzeichnis: `{manifest.get('run_dir')}`",
        "",
        "> Interner Research-Output. Keine Finanzberatung, keine Handelsanweisung, keine externe Veröffentlichung ohne Review.",
        "",
        "## Kontext",
        "",
        f"- Provider: `{manifest.get('provider')}`",
        f"- Quick-Modell: `{manifest.get('quick_model')}`",
        f"- Deep-Modell: `{manifest.get('deep_model')}`",
        f"- Matrix: `{matrix_path or 'nicht angegeben'}`",
        f"- Laufzeit: `{item.get('elapsed_seconds')}s`",
        "",
        "## Executive Summary",
        "",
        f"**Finale Einordnung:** {_decision_line(state.get('final_trade_decision', ''))}",
        "",
        _first_paragraph(state.get("final_trade_decision", ""), max_chars=1200),
        "",
        f"**Trader:** {_decision_line(state.get('trader_investment_decision', ''))}",
        "",
        _first_paragraph(state.get("trader_investment_decision", ""), max_chars=900),
        "",
        "<!-- PAGEBREAK -->",
        "",
        "## Detailreport",
        "",
    ]
    for key, title in REPORT_KEYS:
        content = str(state.get(key, "")).strip()
        if not content:
            continue
        lines.extend([f"### {title}", "", content, ""])
    return "\n".join(lines)


def _is_table_separator(line: str) -> bool:
    cells = [cell.strip() for cell in line.strip("|").split("|")]
    return bool(cells) and all(set(cell) <= {"-", ":"} and "-" in cell for cell in cells)


def _looks_like_table_row(line: str) -> bool:
    stripped = line.strip()
    return stripped.startswith("|") and stripped.endswith("|") and stripped.count("|") >= 2


def _add_table(document: Any, rows: list[list[str]]) -> None:
    if not rows:
        return
    width = max(len(row) for row in rows)
    table = document.add_table(rows=0, cols=width)
    table.style = "Table Grid"
    for row in rows:
        cells = table.add_row().cells
        for index in range(width):
            cells[index].text = _clean_inline(row[index]) if index < len(row) else ""
    document.add_paragraph()


def _add_markdown_to_docx(document: Any, markdown: str) -> None:
    lines = markdown.splitlines()
    index = 0
    while index < len(lines):
        raw_line = lines[index]
        line = raw_line.rstrip()
        if not line:
            index += 1
            continue
        if line == "<!-- PAGEBREAK -->":
            document.add_page_break()
            index += 1
            continue
        if line == "---":
            paragraph = document.add_paragraph()
            run = paragraph.add_run("─" * 32)
            run.font.color.rgb = RGBColor(180, 185, 190)
            index += 1
            continue
        if _looks_like_table_row(line):
            table_rows: list[list[str]] = []
            while index < len(lines):
                table_line = lines[index].rstrip()
                if not _looks_like_table_row(table_line):
                    break
                if not _is_table_separator(table_line):
                    table_rows.append([cell.strip() for cell in table_line.strip("|").split("|")])
                index += 1
            _add_table(document, table_rows)
            continue
        if line.startswith("# "):
            document.add_heading(_clean_inline(line[2:]), level=1)
        elif line.startswith("## "):
            document.add_heading(_clean_inline(line[3:]), level=2)
        elif line.startswith("### "):
            document.add_heading(_clean_inline(line[4:]), level=3)
        elif line.startswith("> "):
            paragraph = document.add_paragraph(_clean_inline(line[2:]))
            paragraph.style = "Intense Quote"
        elif line.startswith("- "):
            document.add_paragraph(_clean_inline(line[2:]), style="List Bullet")
        else:
            document.add_paragraph(_clean_inline(line))
        index += 1


def _build_docx(markdown: str, out_path: Path) -> None:
    if Document is None:
        raise RuntimeError("python-docx is not available")
    document = Document()
    section = document.sections[0]
    section.top_margin = Inches(0.8)
    section.bottom_margin = Inches(0.8)
    section.left_margin = Inches(0.85)
    section.right_margin = Inches(0.85)

    styles = document.styles
    styles["Normal"].font.name = "Arial"
    styles["Normal"].font.size = Pt(10.5)
    for style_name, size, color in [
        ("Heading 1", 18, RGBColor(24, 40, 56)),
        ("Heading 2", 14, RGBColor(24, 40, 56)),
        ("Heading 3", 12, RGBColor(55, 70, 85)),
    ]:
        style = styles[style_name]
        style.font.name = "Arial"
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = color

    _add_markdown_to_docx(document, markdown)
    document.save(out_path)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", default=None)
    parser.add_argument("--matrix", default=None)
    parser.add_argument("--out-dir", default=str(ROOT / "reports" / "room16"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    run_dir = Path(args.run_dir) if args.run_dir else _latest_completed_run()
    manifest, states = _load_run(run_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d")
    markdown = _build_markdown(manifest, states, args.matrix)

    md_path = out_dir / f"{stamp}-room16-four-company-report.md"
    docx_path = out_dir / f"{stamp}-room16-four-company-report.docx"
    md_path.write_text(markdown, encoding="utf-8")
    _build_docx(markdown, docx_path)
    for item in manifest.get("results", []):
        ticker = item["ticker"]
        state = states.get(ticker, {})
        company_markdown = _build_company_markdown(manifest, item, state, args.matrix)
        safe_ticker = ticker.replace(".", "_")
        company_md_path = out_dir / f"{stamp}-room16-{safe_ticker}-report.md"
        company_docx_path = out_dir / f"{stamp}-room16-{safe_ticker}-report.docx"
        company_md_path.write_text(company_markdown, encoding="utf-8")
        _build_docx(company_markdown, company_docx_path)
    print(md_path)
    print(docx_path)


if __name__ == "__main__":
    main()
