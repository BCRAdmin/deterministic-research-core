#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP_ROOT="${PROJECT_ROOT}/room16-app"
STAMP="$(date -u +"%Y%m%dT%H%M%SZ")"
REPORT_DIR="${PROJECT_ROOT}/.runtime/room16-app/cleanup"
LOG_PATH="${REPORT_DIR}/${STAMP}-safe-retention-apply.log"
LATEST_PATH="${REPORT_DIR}/latest-safe-retention-apply.log"

mkdir -p "${REPORT_DIR}"

port_status() {
  local port="$1"
  if command -v lsof >/dev/null 2>&1 && lsof -nP -iTCP:"${port}" -sTCP:LISTEN >/dev/null 2>&1; then
    echo "active"
  else
    echo "inactive"
  fi
}

(
  echo "Room 16 safe retention apply"
  echo "timestamp=${STAMP}"
  echo "project=${PROJECT_ROOT}"
  echo "port_4516=$(port_status 4516)"
  echo
  echo "[1/7] Runtime diagnostic retention without active app build deletion"
  bash "${PROJECT_ROOT}/scripts/clean_room16_runtime_artifacts.sh" \
    --apply \
    --skip-build-artifacts \
    --prune-runtime

  echo
  echo "[2/7] TypeScript lint"
  cd "${APP_ROOT}"
  npm run lint

  echo
  echo "[3/7] Locked build"
  npm run build

  echo
  echo "[4/7] App verifier"
  npm run verify

  echo
  echo "[5/7] Report-machine verifier"
  npm run verify:report-machine

  echo
  echo "[6/7] Local health smoke"
  if [[ "$(port_status 4516)" == "active" ]]; then
    curl -fsS "http://127.0.0.1:4516/api/state" >/dev/null
    curl -fsS "http://127.0.0.1:4516/api/report-machine" >/dev/null
    echo "4516 health ok"
  else
    echo "4516 not active; health smoke skipped"
  fi

  echo
  echo "[7/7] Post-verification diagnostic cap"
  bash "${PROJECT_ROOT}/scripts/clean_room16_runtime_artifacts.sh" \
    --apply \
    --skip-build-artifacts \
    --prune-runtime

  echo
  echo "Room 16 safe retention apply complete"
) 2>&1 | tee "${LOG_PATH}"
status=${PIPESTATUS[0]}
cp "${LOG_PATH}" "${LATEST_PATH}"
exit "${status}"
