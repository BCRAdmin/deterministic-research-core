#!/usr/bin/env python3
"""Build a complete Room 16 dossier with full analyst-report content."""

from __future__ import annotations

import argparse
import html
import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any

from docx import Document
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (
    BaseDocTemplate,
    CondPageBreak,
    Frame,
    KeepTogether,
    LongTable,
    PageBreak,
    PageTemplate,
    Paragraph,
    Spacer,
    TableStyle,
)

from room16_build_premium_report import (  # noqa: E402
    ACCENT,
    INK,
    MUTED,
    NAVY,
    REPORT_KEYS,
    RUN_DIR,
    _clean_markdown,
    _load_run,
    _polish_german,
    _prepare_records,
    _rating_de,
)
from room16_text_safety import strip_visible_reasoning_artifacts


ROOT = Path(__file__).resolve().parents[1]


def _safe_ticker(ticker: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", ticker).strip("_")


def _filter_records(records: list[dict[str, Any]], tickers: list[str] | None) -> list[dict[str, Any]]:
    if not tickers:
        return records
    requested = {ticker.upper() for ticker in tickers}
    return [record for record in records if str(record["ticker"]).upper() in requested]


def _artifact_stem(stamp: str, records: list[dict[str, Any]]) -> str:
    if len(records) == 1:
        return f"{stamp}-room16-{_safe_ticker(str(records[0]['ticker']))}-complete-dossier"
    return f"{stamp}-room16-complete-dossier"


def _clean_heading(text: str) -> str:
    replacements = {
        "Trader Output": "Trader-Sicht",
        "Investment Plan": "Investment-Plan",
        "Final Trade Decision": "Finale Entscheidung",
        "Market / technische Lage": "Markt- und Techniklage",
        "Sentiment / Unternehmensstimmung": "Sentiment und Marktstimmung",
        "News / Makro-Kontext": "Nachrichten- und Makrolage",
        "Fundamentals": "Fundamentale Lage",
    }
    for source, target in replacements.items():
        text = text.replace(source, target)
    return _strip_symbols(_polish_german(text))


def _strip_symbols(text: str) -> str:
    text = text.replace("ℹ", "")
    text = re.sub(r"[\U0001F300-\U0001FAFF]", "", text)
    text = re.sub(r"[\u2600-\u27BF\uFE0F✅⚠️🔴🟡🟢🟠🔵]", "", text)
    return re.sub(r"[ \t]{2,}", " ", text).strip()


def _clean_body(text: str) -> str:
    text = strip_visible_reasoning_artifacts(text)
    text = _strip_symbols(text)
    text = re.sub(r"(?m)^\s*```[A-Za-z0-9_-]*\s*$", "", text)
    text = re.sub(r"(?m)^[ \t]+(-\s+)", r"\1", text)
    text = text.replace("FINAL TRANSACTION PROPOSAL", "FINALE TRANSAKTIONSEINORDNUNG")
    text = re.sub(r"\*\*Action\*\*:", "**Umsetzung**:", text)
    text = re.sub(r"\*\*Reasoning\*\*:", "**Begründung**:", text)
    text = re.sub(r"\*\*Recommendation\*\*:", "**Einordnung**:", text)
    text = re.sub(r"\*\*Rationale\*\*:", "**Begründung**:", text)
    text = re.sub(r"\*\*Strategic Actions\*\*:", "**Operative Schritte**:", text)
    text = re.sub(r"\*\*Position Sizing\*\*:", "**Positionsgröße**:", text)
    text = re.sub(r"\*\*Stop Loss\*\*:", "**Stop-Loss**:", text)
    return strip_visible_reasoning_artifacts(_polish_german(text.strip()))


def _decision_line(text: str) -> str:
    for line in text.splitlines():
        cleaned = _clean_markdown(line)
        if cleaned.startswith(("Rating:", "Recommendation:", "Action:", "Einordnung:", "Umsetzung:")):
            return _clean_body(cleaned)
    return _clean_body(text.splitlines()[0] if text.splitlines() else "")


def _load_source_ledger(record: dict[str, Any]) -> list[dict[str, str]]:
    ledger_path = record.get("source_ledger_file")
    if not ledger_path:
        return []
    path = Path(str(ledger_path)).expanduser()
    if not path.exists():
        return []
    seen: set[str] = set()
    entries: list[dict[str, str]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue
        source_id = str(entry.get("source_id") or "").strip()
        if not source_id or source_id in seen:
            continue
        seen.add(source_id)
        entries.append(
            {
                "source_id": source_id,
                "source_type": str(entry.get("source_type") or ""),
                "asof": str(entry.get("asof") or ""),
                "period_type": str(entry.get("period_type") or ""),
                "formula_id": str(entry.get("formula_id") or ""),
            }
        )
    return entries


def _append_source_ledger(lines: list[str], record: dict[str, Any]) -> None:
    entries = _load_source_ledger(record)
    if not entries:
        return
    lines.extend(
        [
            "<!-- PAGEBREAK -->",
            "",
            "### Pipeline-Source-Ledger",
            "",
            "Deterministisch aus Tool-Ausgaben erfasst. Primärquellen bleiben stärker als Vendor-Daten; fehlende SEC/IR-Belege bleiben Review-Punkte.",
            "",
            "| source_id | source_type | asof | period_type | formula_id |",
            "| --- | --- | --- | --- | --- |",
        ]
    )
    for entry in entries[:60]:
        lines.append(
            "| {source_id} | {source_type} | {asof} | {period_type} | {formula_id} |".format(
                source_id=_clean_markdown(entry["source_id"]),
                source_type=_clean_markdown(entry["source_type"]),
                asof=_clean_markdown(entry["asof"]),
                period_type=_clean_markdown(entry["period_type"]),
                formula_id=_clean_markdown(entry["formula_id"]),
            )
        )
    if len(entries) > 60:
        lines.append(f"| ... | {len(entries) - 60} weitere Quellen | ... | ... | ... |")
    lines.append("")


def build_markdown(records: list[dict[str, Any]], manifest: dict[str, Any]) -> str:
    created = datetime.now().strftime("%Y-%m-%d %H:%M")
    lines = [
        "# ROOM 16 - Vollständiges Research-Dossier",
        "",
        f"Erstellt: {created} Europe/Berlin",
        f"TradingAgents-Datum: {manifest.get('date')}",
        f"Run-Verzeichnis: `{manifest.get('run_dir')}`",
        "",
        "> Interner Research-Output. Keine Finanzberatung, keine Handelsanweisung, keine externe Veröffentlichung ohne Review.",
        "",
        "## Laufkontext",
        "",
        f"- Provider: `{manifest.get('provider')}`",
        f"- Quick-Modell: `{manifest.get('quick_model')}`",
        f"- Deep-Modell: `{manifest.get('deep_model')}`",
        f"- Analysten: `{', '.join(manifest.get('analysts', []))}`",
        "",
        "## Entscheidungsmatrix",
        "",
        "| Unternehmen | Status | Laufzeit | Rating | Trader-Signal |",
        "| --- | ---: | ---: | --- | --- |",
    ]
    for record_index, record in enumerate(records):
        lines.append(
            f"| `{record['ticker']}` | {record.get('status')} | {record.get('runtime')}s | "
            f"{_rating_de(str(record.get('rating')))} | {record.get('trader_signal')} |"
        )

    lines.extend(
        [
            "",
            "<!-- PAGEBREAK -->",
            "",
            "# Detailreports",
            "",
        ]
    )
    for record_index, record in enumerate(records):
        lines.extend(
            [
                f"## {record['ticker']}",
                "",
                f"**Rating:** {_rating_de(str(record.get('rating')))}",
                f"**Trader-Signal:** {record.get('trader_signal')}",
                f"**Laufzeit:** {record.get('runtime')}s",
                "",
            ]
        )
        for section_index, (key, title) in enumerate(REPORT_KEYS):
            content = str(record["state"].get(key, "")).strip()
            if content:
                if section_index > 0:
                    lines.extend(["<!-- PAGEBREAK -->", ""])
                lines.extend([f"### {_clean_heading(title)}", "", _clean_body(content), ""])
        lines.extend(["<!-- PAGEBREAK -->", "", "### Trader-Sicht", "", _clean_body(record["trader_de"]), ""])
        lines.extend(["<!-- PAGEBREAK -->", "", "### Investment-Plan", "", _clean_body(record["plan_de"]), ""])
        lines.extend(
            [
                "<!-- PAGEBREAK -->",
                "",
                "### Finale Entscheidung",
                "",
                _clean_body(record["final"]),
                "",
            ]
        )
        _append_source_ledger(lines, record)
        if record_index < len(records) - 1:
            lines.extend(["<!-- PAGEBREAK -->", ""])
    return "\n".join(lines).strip() + "\n"


def _shade_cell(cell: Any, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def _set_docx_cell_text(cell: Any, text: str, bold: bool = False, color: str = INK, size: float = 8.5) -> None:
    cell.text = ""
    paragraph = cell.paragraphs[0]
    run = paragraph.add_run(_clean_markdown(text))
    run.bold = bold
    run.font.color.rgb = RGBColor.from_string(color)
    run.font.size = Pt(size)
    cell.vertical_alignment = WD_ALIGN_VERTICAL.TOP


def _is_table_separator(line: str) -> bool:
    cells = [cell.strip() for cell in line.strip("|").split("|")]
    return bool(cells) and all(set(cell) <= {"-", ":"} and "-" in cell for cell in cells)


def _looks_like_table_row(line: str) -> bool:
    stripped = line.strip()
    return stripped.startswith("|") and stripped.endswith("|") and stripped.count("|") >= 2


def _add_docx_table(document: Document, rows: list[list[str]]) -> None:
    if not rows:
        return
    width = max(len(row) for row in rows)
    table = document.add_table(rows=0, cols=width)
    table.style = "Table Grid"
    for row_index, row in enumerate(rows):
        cells = table.add_row().cells
        for index in range(width):
            if row_index == 0:
                _shade_cell(cells[index], NAVY)
                _set_docx_cell_text(cells[index], row[index] if index < len(row) else "", True, "FFFFFF", 8.2)
            else:
                _set_docx_cell_text(cells[index], row[index] if index < len(row) else "", False, INK, 8.0)
    document.add_paragraph()


def _add_docx_markdown(document: Document, markdown: str) -> None:
    lines = markdown.splitlines()
    index = 0
    while index < len(lines):
        line = lines[index].rstrip()
        if not line:
            index += 1
            continue
        if line == "<!-- PAGEBREAK -->":
            document.add_page_break()
            index += 1
            continue
        if line == "---":
            document.add_paragraph()
            index += 1
            continue
        if _looks_like_table_row(line):
            rows: list[list[str]] = []
            while index < len(lines) and _looks_like_table_row(lines[index].rstrip()):
                table_line = lines[index].rstrip()
                if not _is_table_separator(table_line):
                    rows.append([cell.strip() for cell in table_line.strip("|").split("|")])
                index += 1
            _add_docx_table(document, rows)
            continue
        if line.startswith("# "):
            document.add_heading(_clean_heading(_clean_markdown(line[2:])), level=1)
        elif line.startswith("## "):
            document.add_heading(_clean_heading(_clean_markdown(line[3:])), level=2)
        elif line.startswith("### "):
            document.add_heading(_clean_heading(_clean_markdown(line[4:])), level=3)
        elif line.startswith("> "):
            paragraph = document.add_paragraph(_clean_markdown(line[2:]))
            paragraph.style = "Intense Quote"
        elif line.startswith("- "):
            document.add_paragraph(_clean_markdown(line[2:]), style="List Bullet")
        else:
            paragraph = document.add_paragraph(_clean_markdown(line))
            paragraph.paragraph_format.space_after = Pt(4)
        index += 1


def build_docx(markdown: str, out_path: Path) -> None:
    document = Document()
    section = document.sections[0]
    section.top_margin = Inches(0.65)
    section.bottom_margin = Inches(0.65)
    section.left_margin = Inches(0.72)
    section.right_margin = Inches(0.72)

    styles = document.styles
    styles["Normal"].font.name = "Aptos"
    styles["Normal"].font.size = Pt(9.2)
    for style_name, size, color in [
        ("Title", 28, NAVY),
        ("Heading 1", 18, NAVY),
        ("Heading 2", 14, NAVY),
        ("Heading 3", 11, MUTED),
    ]:
        style = styles[style_name]
        style.font.name = "Aptos"
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor.from_string(color)

    title = document.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("ROOM 16")
    run.bold = True
    run.font.size = Pt(34)
    run.font.color.rgb = RGBColor.from_string(NAVY)
    subtitle = document.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub_run = subtitle.add_run("Vollständiges Research-Dossier")
    sub_run.font.size = Pt(14)
    sub_run.font.color.rgb = RGBColor.from_string(ACCENT)
    document.add_paragraph()
    _add_docx_markdown(document, markdown)
    document.save(out_path)


def _pdf_text(text: str) -> str:
    cleaned = html.escape(_strip_symbols(_clean_markdown(text)))
    cleaned = re.sub(r"\n{2,}", "<br/><br/>", cleaned)
    return cleaned.replace("\n", "<br/>")


def _pdf_styles() -> dict[str, ParagraphStyle]:
    styles = getSampleStyleSheet()
    return {
        "h1": ParagraphStyle(
            "room16_h1",
            parent=styles["Heading1"],
            fontName="Helvetica-Bold",
            fontSize=18,
            leading=22,
            textColor=colors.HexColor(f"#{NAVY}"),
            spaceBefore=12,
            spaceAfter=8,
            keepWithNext=1,
        ),
        "h2": ParagraphStyle(
            "room16_h2",
            parent=styles["Heading2"],
            fontName="Helvetica-Bold",
            fontSize=13,
            leading=16,
            textColor=colors.HexColor(f"#{NAVY}"),
            spaceBefore=10,
            spaceAfter=6,
            keepWithNext=1,
        ),
        "h3": ParagraphStyle(
            "room16_h3",
            parent=styles["Heading3"],
            fontName="Helvetica-Bold",
            fontSize=10.5,
            leading=13,
            textColor=colors.HexColor(f"#{MUTED}"),
            spaceBefore=8,
            spaceAfter=4,
            keepWithNext=1,
        ),
        "body": ParagraphStyle(
            "room16_body",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=8.1,
            leading=10.5,
            textColor=colors.HexColor(f"#{INK}"),
            spaceAfter=4.5,
            allowWidows=0,
            allowOrphans=0,
        ),
        "table_header": ParagraphStyle(
            "room16_table_header",
            parent=styles["BodyText"],
            fontName="Helvetica-Bold",
            fontSize=7.8,
            leading=9.5,
            textColor=colors.white,
        ),
        "quote": ParagraphStyle(
            "room16_quote",
            parent=styles["BodyText"],
            fontName="Helvetica-Oblique",
            fontSize=8.2,
            leading=10.5,
            textColor=colors.HexColor(f"#{MUTED}"),
            leftIndent=12,
            rightIndent=12,
            spaceAfter=7,
            allowWidows=0,
            allowOrphans=0,
        ),
    }


def _on_pdf_page(canvas: Any, doc: Any) -> None:
    width, height = A4
    canvas.saveState()
    canvas.setFillColor(colors.HexColor(f"#{NAVY}"))
    canvas.rect(0, height - 1.05 * cm, width, 1.05 * cm, stroke=0, fill=1)
    canvas.setFillColor(colors.HexColor(f"#{ACCENT}"))
    canvas.setFont("Helvetica-Bold", 7)
    canvas.drawString(1.15 * cm, height - 0.65 * cm, "ROOM 16 | Vollständiges Research-Dossier")
    canvas.setFillColor(colors.HexColor(f"#{MUTED}"))
    canvas.setFont("Helvetica", 7)
    canvas.drawRightString(width - 1.15 * cm, 0.65 * cm, f"Seite {doc.page}")
    canvas.restoreState()


def _pdf_table(rows: list[list[str]], available_width: float) -> LongTable:
    col_count = max(len(row) for row in rows)
    col_width = available_width / max(col_count, 1)
    styles = _pdf_styles()
    normalized = []
    for row_index, row in enumerate(rows):
        style = styles["table_header"] if row_index == 0 else styles["body"]
        normalized.append([Paragraph(_pdf_text(cell), style) for cell in row + [""] * (col_count - len(row))])
    table = LongTable(normalized, colWidths=[col_width] * col_count, repeatRows=1, hAlign="LEFT")
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor(f"#{NAVY}")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#D4D9E0")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 4),
                ("RIGHTPADDING", (0, 0), (-1, -1), 4),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ]
        )
    )
    return table


def _pdf_table_as_rows(rows: list[list[str]]) -> list[Any]:
    styles = _pdf_styles()
    if not rows:
        return []
    headers = rows[0]
    elements: list[Any] = []
    for row in rows[1:]:
        pairs = []
        for index, cell in enumerate(row):
            header = headers[index] if index < len(headers) else f"Spalte {index + 1}"
            pairs.append(f"{header}: {cell}")
        elements.append(Paragraph(_pdf_text(" | ".join(pairs)), styles["body"]))
    elements.append(Spacer(1, 4))
    return elements


def _pdf_heading(text: str, style: ParagraphStyle, min_space: float) -> list[Any]:
    return [CondPageBreak(min_space), Paragraph(_pdf_text(_clean_heading(text)), style)]


def _pdf_body_flowable(text: str, style: ParagraphStyle) -> Any:
    paragraph = Paragraph(_pdf_text(text), style)
    # Short paragraphs should move as a unit; this avoids one lonely line
    # becoming the visual tail of the previous page.
    if len(text) <= 900:
        return KeepTogether([paragraph])
    return paragraph


def _append_pdf_table(story: list[Any], rows: list[list[str]], available_width: float) -> None:
    col_count = max((len(row) for row in rows), default=0)
    max_cell_len = max((len(cell) for row in rows for cell in row), default=0)
    story.append(CondPageBreak(4.8 * cm))
    if col_count > 5 or max_cell_len > 260:
        row_elements = _pdf_table_as_rows(rows)
        if len(row_elements) <= 7:
            story.append(KeepTogether(row_elements))
        else:
            story.extend(row_elements)
    else:
        table = _pdf_table(rows, available_width)
        if len(rows) <= 8:
            story.append(KeepTogether([table]))
        else:
            story.append(table)
    story.append(Spacer(1, 6))


def _add_pdf_markdown(story: list[Any], markdown: str, available_width: float) -> None:
    styles = _pdf_styles()
    lines = markdown.splitlines()
    index = 0
    while index < len(lines):
        line = lines[index].rstrip()
        if not line:
            index += 1
            continue
        if line == "<!-- PAGEBREAK -->":
            story.append(PageBreak())
            index += 1
            continue
        if line == "---":
            story.append(Spacer(1, 4))
            index += 1
            continue
        if _looks_like_table_row(line):
            rows: list[list[str]] = []
            while index < len(lines) and _looks_like_table_row(lines[index].rstrip()):
                table_line = lines[index].rstrip()
                if not _is_table_separator(table_line):
                    rows.append([cell.strip() for cell in table_line.strip("|").split("|")])
                index += 1
            _append_pdf_table(story, rows, available_width)
            continue
        if line.startswith("# "):
            story.extend(_pdf_heading(line[2:], styles["h1"], 9.0 * cm))
        elif line.startswith("## "):
            story.extend(_pdf_heading(line[3:], styles["h2"], 7.5 * cm))
        elif line.startswith("### "):
            story.extend(_pdf_heading(line[4:], styles["h3"], 3.2 * cm))
        elif line.startswith("> "):
            story.append(_pdf_body_flowable(line[2:], styles["quote"]))
        elif line.startswith("- "):
            story.append(_pdf_body_flowable("• " + line[2:], styles["body"]))
        else:
            story.append(_pdf_body_flowable(line, styles["body"]))
        index += 1


def build_pdf(markdown: str, out_path: Path) -> None:
    doc = BaseDocTemplate(
        str(out_path),
        pagesize=A4,
        rightMargin=1.15 * cm,
        leftMargin=1.15 * cm,
        topMargin=1.45 * cm,
        bottomMargin=1.0 * cm,
    )
    frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="normal")
    doc.addPageTemplates([PageTemplate(id="room16", frames=[frame], onPage=_on_pdf_page)])
    story: list[Any] = []
    _add_pdf_markdown(story, markdown, doc.width)
    doc.build(story)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", default=str(RUN_DIR))
    parser.add_argument("--out-dir", default=str(ROOT / "reports" / "room16" / "complete"))
    parser.add_argument("--translate-model", default="deepseek-v4-pro:cloud")
    parser.add_argument("--date", default=None, help="Optional YYYY-MM-DD artifact date stamp.")
    parser.add_argument("--tickers", nargs="+", default=None, help="Optional ticker filter for one-company artifacts.")
    parser.add_argument(
        "--render-documents",
        action="store_true",
        help="Render DOCX/PDF final documents. Default is markdown-only for first-pass QA.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    run_dir = Path(args.run_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    premium_dir = ROOT / "reports" / "room16" / "premium"
    cache_path = premium_dir / "translation-cache.json"
    cache = json.loads(cache_path.read_text(encoding="utf-8")) if cache_path.exists() else {}
    manifest, states = _load_run(run_dir)
    records = _prepare_records(manifest, states, cache, args.translate_model)
    records = _filter_records(records, args.tickers)
    if not records:
        raise SystemExit(f"No records matched ticker filter: {args.tickers}")
    cache_path.write_text(json.dumps(cache, indent=2, ensure_ascii=False), encoding="utf-8")
    markdown = build_markdown(records, manifest)
    stamp = args.date or datetime.now().strftime("%Y-%m-%d")
    stem = _artifact_stem(stamp, records)
    md_path = out_dir / f"{stem}.md"
    docx_path = out_dir / f"{stem}.docx"
    pdf_path = out_dir / f"{stem}.pdf"
    md_path.write_text(markdown, encoding="utf-8")
    print(md_path)
    if args.render_documents:
        build_docx(markdown, docx_path)
        build_pdf(markdown, pdf_path)
        print(docx_path)
        print(pdf_path)


if __name__ == "__main__":
    main()
