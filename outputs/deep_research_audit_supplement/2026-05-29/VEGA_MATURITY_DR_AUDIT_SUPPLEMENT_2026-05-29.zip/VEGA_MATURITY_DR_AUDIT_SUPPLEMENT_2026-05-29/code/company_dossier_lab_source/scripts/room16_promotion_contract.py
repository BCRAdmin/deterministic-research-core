#!/usr/bin/env python3
"""Evaluate whether a Room 16 report can be promoted to Quellwert."""

from __future__ import annotations

import argparse
import json
import re
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / ".runtime" / "room16-promotion-contract"
CONTRACT_ID = "room16-quellwert-promotion-v1"
PRIMARY_SOURCE_TYPES = {"SEC", "IR"}
ALLOWED_SOURCE_TYPES = {"SEC", "IR", "TRANSCRIPT", "PRICE_VENDOR", "NEWSWIRE", "VENDOR", "SOCIAL"}
ALLOWED_PERIOD_TYPES = {"quarterly", "ttm", "spot", "run_rate", "range", "calculated", "qualitative"}
PUBLIC_DRAFT_REQUIRED_PATTERNS = {
    "non_advice_disclaimer": re.compile(r"keine\s+(?:anlageberatung|kauf-\s*oder\s+verkaufsempfehlung)", re.IGNORECASE),
    "sources_section": re.compile(r"(^|\n)#{1,3}\s*(?:quellen|source|sources)\b", re.IGNORECASE),
    "risks_section": re.compile(r"(^|\n)#{1,3}\s*(?:risiken|offene\s+prüfpunkte|risk|risks)\b", re.IGNORECASE),
}
PUBLIC_DRAFT_FORBIDDEN_PATTERNS = {
    "trading_action_label": re.compile(r"\b(?:Action|Recommendation|Final Transaction Proposal)\s*:", re.IGNORECASE),
    "position_sizing": re.compile(r"\b(?:position sizing|positionsgröße|positionsgroesse)\b", re.IGNORECASE),
    "stop_loss": re.compile(r"\bstop[- ]?loss\b", re.IGNORECASE),
    "price_target": re.compile(r"\b(?:price target|kursziel)\b", re.IGNORECASE),
    "raw_rating_label": re.compile(r"\b(?:strong buy|overweight|underweight|strong sell)\b", re.IGNORECASE),
}


def resolve_path(value: str | None) -> Path | None:
    if not value:
        return None
    if isinstance(value, dict):
        if value.get("rendered") is False:
            return None
        value = value.get("path") or value.get("file") or value.get("href")
        if not value:
            return None
    path = Path(value).expanduser()
    return path if path.is_absolute() else ROOT / path


def read_json(path: Path | None) -> dict[str, Any] | None:
    if not path or not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def read_text(path: Path | None) -> str:
    if not path or not path.exists():
        return ""
    return path.read_text(encoding="utf-8", errors="replace")


def check(checks: list[dict[str, Any]], name: str, condition: bool, severity: str, details: Any) -> None:
    checks.append(
        {
            "name": name,
            "status": "pass" if condition else "fail",
            "severity": severity,
            "details": details,
        }
    )


def infer_ticker(quality: dict[str, Any] | None, fact_ledger: dict[str, Any] | None) -> str | None:
    if fact_ledger and fact_ledger.get("ticker"):
        return str(fact_ledger["ticker"]).upper()
    for item in quality.get("checks", []) if quality else []:
        if item.get("name") == "manifest_has_tickers" and isinstance(item.get("details"), list) and item["details"]:
            return str(item["details"][0]).upper()
    return None


def artifact_path(quality: dict[str, Any] | None, key: str, explicit: str | None) -> Path | None:
    explicit_path = resolve_path(explicit)
    if explicit_path:
        return explicit_path
    value = (quality or {}).get("artifacts", {}).get(key)
    return resolve_path(value)


def strict_integrity_findings(quality: dict[str, Any] | None) -> list[dict[str, Any]]:
    findings = (quality or {}).get("metrics", {}).get("research_integrity_findings")
    return findings if isinstance(findings, list) else []


def strict_integrity_verdict(quality: dict[str, Any] | None) -> str | None:
    value = (quality or {}).get("metrics", {}).get("research_integrity_verdict")
    return str(value) if value is not None else None


def quality_manual_review_block(quality: dict[str, Any] | None) -> dict[str, Any]:
    metrics = (quality or {}).get("metrics", {})
    status = metrics.get("status")
    publishable = metrics.get("analysis_publishable")
    if publishable is None:
        publishable = metrics.get("publishable")
    external_display_rating = metrics.get("external_display_rating")
    reasons = metrics.get("manual_review_reasons") or []
    blocked = status == "manual_review" or publishable is False
    return {
        "blocked": blocked,
        "status": status,
        "publishable": publishable,
        "externalDisplayRating": external_display_rating,
        "manualReviewReasons": reasons,
    }


def validate_fact_ledger(fact_ledger: dict[str, Any] | None) -> tuple[bool, dict[str, Any]]:
    if not fact_ledger:
        return False, {"error": "missing fact ledger"}

    claims = fact_ledger.get("claims")
    sources = fact_ledger.get("sources") or []
    source_ids = {str(source.get("source_id")) for source in sources if source.get("source_id")}
    claim_errors: list[dict[str, Any]] = []
    source_errors: list[dict[str, Any]] = []

    if not isinstance(claims, list) or len(claims) < 5:
        claim_errors.append({"type": "claim_count", "count": len(claims) if isinstance(claims, list) else 0, "min": 5})
    else:
        for claim in claims:
            claim_id = str(claim.get("claim_id") or "unknown")
            required_missing = [
                field
                for field in ["claim_id", "label", "value", "unit", "period_type", "asof", "source_id"]
                if field not in claim or claim.get(field) in ("", None)
            ]
            if required_missing:
                claim_errors.append({"claim_id": claim_id, "type": "missing_fields", "fields": required_missing})
            if claim.get("period_type") not in ALLOWED_PERIOD_TYPES:
                claim_errors.append({"claim_id": claim_id, "type": "invalid_period_type", "value": claim.get("period_type")})
            if claim.get("source_id") and str(claim.get("source_id")) not in source_ids:
                claim_errors.append({"claim_id": claim_id, "type": "source_id_not_declared", "source_id": claim.get("source_id")})
            if claim.get("period_type") == "calculated" and not claim.get("formula_id"):
                claim_errors.append({"claim_id": claim_id, "type": "missing_formula_id_for_calculated_metric"})

    if not isinstance(sources, list) or len(sources) < 2:
        source_errors.append({"type": "source_count", "count": len(sources) if isinstance(sources, list) else 0, "min": 2})
    else:
        for source in sources:
            source_id = str(source.get("source_id") or "unknown")
            missing = [field for field in ["source_id", "source_type", "title", "asof"] if not source.get(field)]
            if missing:
                source_errors.append({"source_id": source_id, "type": "missing_fields", "fields": missing})
            if source.get("source_type") not in ALLOWED_SOURCE_TYPES:
                source_errors.append({"source_id": source_id, "type": "invalid_source_type", "value": source.get("source_type")})

    primary_count = sum(1 for source in sources if source.get("source_type") in PRIMARY_SOURCE_TYPES) if isinstance(sources, list) else 0
    if primary_count < 1:
        source_errors.append({"type": "primary_source_missing", "required_any": sorted(PRIMARY_SOURCE_TYPES)})

    ok = not claim_errors and not source_errors
    return ok, {
        "claims": len(claims) if isinstance(claims, list) else 0,
        "sources": len(sources) if isinstance(sources, list) else 0,
        "primarySources": primary_count,
        "claimErrors": claim_errors,
        "sourceErrors": source_errors,
    }


def public_draft_scan(text: str) -> dict[str, Any]:
    required = {name: bool(pattern.search(text)) for name, pattern in PUBLIC_DRAFT_REQUIRED_PATTERNS.items()}
    forbidden = {name: bool(pattern.search(text)) for name, pattern in PUBLIC_DRAFT_FORBIDDEN_PATTERNS.items()}
    return {
        "required": required,
        "forbidden": forbidden,
        "chars": len(text),
    }


def next_actions(checks: list[dict[str, Any]]) -> list[str]:
    failed = {item["name"] for item in checks if item["status"] == "fail"}
    actions: list[str] = []
    if "quality_verdict_pass" in failed or "strict_research_integrity_passed" in failed:
        actions.append("Run or repair strict Room 16 research integrity QA before any public rewrite.")
    if "fact_ledger_ready" in failed:
        actions.append("Create a fact ledger with source_id, period_type, asof, formula_id for calculated metrics, and SEC/IR primary sources.")
    if "quality_publishable_not_manual_review" in failed:
        actions.append("Keep this report internal/manual-review only; do not promote it to Quellwert/public until the quality profile is resolved.")
    if "public_draft_exists" in failed or "public_draft_required_sections" in failed or "public_draft_no_trading_language" in failed:
        actions.append("Write a separate Quellwert editorial draft with sources, risks, and non-advice wording; do not publish raw Room 16 text.")
    if "human_review_confirmed" in failed or "sources_human_verified" in failed or "non_advice_confirmed" in failed:
        actions.append("Complete human review, human source verification, and explicit non-advice confirmation.")
    if not actions:
        actions.append("Promote candidate into the Quellwert public catalog with publicationGate public_ready.")
    return actions


def evaluate(args: argparse.Namespace) -> dict[str, Any]:
    quality_report_path = resolve_path(args.quality_report)
    quality = read_json(quality_report_path)
    fact_ledger_path = resolve_path(args.fact_ledger)
    fact_ledger = read_json(fact_ledger_path)
    complete_markdown_path = artifact_path(quality, "complete_md", args.markdown)
    complete_pdf_path = artifact_path(quality, "complete_pdf", args.pdf)
    public_draft_path = resolve_path(args.public_draft)
    public_draft_text = read_text(public_draft_path)
    checks: list[dict[str, Any]] = []

    check(checks, "quality_report_exists", bool(quality_report_path and quality_report_path.exists()), "block", str(quality_report_path))
    check(checks, "quality_verdict_pass", (quality or {}).get("verdict") == "pass", "block", (quality or {}).get("verdict"))
    check(checks, "complete_markdown_exists", bool(complete_markdown_path and complete_markdown_path.exists()), "block", str(complete_markdown_path))
    check(checks, "complete_pdf_exists", bool(complete_pdf_path and complete_pdf_path.exists()), "block", str(complete_pdf_path))
    ledger_ok, ledger_details = validate_fact_ledger(fact_ledger)
    draft_scan = public_draft_scan(public_draft_text)
    draft_exists = bool(public_draft_path and public_draft_path.exists() and public_draft_text.strip())
    draft_has_required_sections = all(draft_scan["required"].values())
    draft_has_no_trading_language = not any(draft_scan["forbidden"].values())
    manual_review_block = quality_manual_review_block(quality)
    strict_quality_passed = strict_integrity_verdict(quality) == "pass" and not strict_integrity_findings(quality)
    promotion_package_integrity_passed = (
        (quality or {}).get("verdict") == "pass"
        and ledger_ok
        and draft_exists
        and draft_has_required_sections
        and draft_has_no_trading_language
    )
    check(
        checks,
        "strict_research_integrity_passed",
        strict_quality_passed or promotion_package_integrity_passed,
        "block",
        {
            "strictQualityVerdict": strict_integrity_verdict(quality),
            "strictQualityFindings": strict_integrity_findings(quality),
            "promotionPackageIntegrityPassed": promotion_package_integrity_passed,
            "note": "Legacy Room 16 reports may satisfy promotion integrity through a verified fact ledger plus separate Quellwert draft; raw Room 16 text is not public output.",
        },
    )

    check(checks, "fact_ledger_ready", ledger_ok, "block", ledger_details)
    check(
        checks,
        "quality_publishable_not_manual_review",
        not manual_review_block["blocked"],
        "block",
        manual_review_block,
    )

    check(checks, "public_draft_exists", draft_exists, "block", str(public_draft_path))
    check(checks, "public_draft_required_sections", draft_has_required_sections, "block", draft_scan["required"])
    check(checks, "public_draft_no_trading_language", draft_has_no_trading_language, "block", draft_scan["forbidden"])

    check(checks, "human_review_confirmed", bool(args.reviewed_by), "review", args.reviewed_by or None)
    check(checks, "sources_human_verified", bool(args.sources_human_verified), "review", args.sources_human_verified)
    check(checks, "non_advice_confirmed", bool(args.non_advice_confirmed), "review", args.non_advice_confirmed)

    failed_blockers = [item for item in checks if item["status"] == "fail" and item["severity"] == "block"]
    failed_review = [item for item in checks if item["status"] == "fail" and item["severity"] == "review"]
    if failed_blockers:
        status = "blocked"
    elif failed_review:
        status = "review_required"
    elif args.requested_visibility == "public":
        status = "public_ready"
    elif args.requested_visibility == "member":
        status = "member_ready"
    else:
        status = "review_required"

    public_ready = status == "public_ready"
    promotion_reasons = [item["name"] for item in failed_blockers + failed_review] or ["promotion_contract_passed"]
    return {
        "schemaVersion": 1,
        "schema_version": 1,
        "contractId": CONTRACT_ID,
        "contract_id": CONTRACT_ID,
        "createdAt": datetime.now().isoformat(timespec="seconds"),
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "status": status,
        "promotion_status": status,
        "public_ready": public_ready,
        "promotion_reasons": promotion_reasons,
        "reviewed_by": args.reviewed_by or None,
        "approved_at": datetime.now().isoformat(timespec="seconds") if public_ready else None,
        "requested_visibility": args.requested_visibility,
        "non_advice_confirmed": bool(args.non_advice_confirmed),
        "sources_human_verified": bool(args.sources_human_verified),
        "blocking_issues": [item["name"] for item in failed_blockers],
        "candidate": {
            "ticker": infer_ticker(quality, fact_ledger),
            "company": fact_ledger.get("company") if fact_ledger else None,
            "qualityReportPath": str(quality_report_path) if quality_report_path else "",
            "completeMarkdownPath": str(complete_markdown_path) if complete_markdown_path else None,
            "completePdfPath": str(complete_pdf_path) if complete_pdf_path else None,
            "factLedgerPath": str(fact_ledger_path) if fact_ledger_path else None,
            "publicDraftPath": str(public_draft_path) if public_draft_path else None,
            "requestedVisibility": args.requested_visibility,
            "reviewedBy": args.reviewed_by or None,
        },
        "checks": checks,
        "summary": {
            "failedBlockers": [item["name"] for item in failed_blockers],
            "failedReviewItems": [item["name"] for item in failed_review],
            "strictResearchIntegrityVerdict": strict_integrity_verdict(quality),
            "manualReview": manual_review_block,
            "factLedger": ledger_details,
            "publicDraft": draft_scan,
        },
        "nextActions": next_actions(checks),
    }


def write_report(report: dict[str, Any], out_dir: Path) -> tuple[Path, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    ticker = report["candidate"].get("ticker") or "UNKNOWN"
    stamp = datetime.now().strftime("%Y%m%dT%H%M%S")
    json_path = out_dir / f"{stamp}-{ticker}-promotion-contract.json"
    md_path = out_dir / f"{stamp}-{ticker}-promotion-contract.md"
    canonical_status_path = out_dir / "promotion_status.json"
    json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    canonical_status_path.write_text(
        json.dumps(
            {
                "schema_version": report.get("schema_version", 1),
                "promotion_status": report.get("promotion_status"),
                "public_ready": report.get("public_ready"),
                "promotion_reasons": report.get("promotion_reasons", []),
                "reviewed_by": report.get("reviewed_by"),
                "approved_at": report.get("approved_at"),
                "requested_visibility": report.get("requested_visibility"),
                "non_advice_confirmed": report.get("non_advice_confirmed", False),
                "sources_human_verified": report.get("sources_human_verified", False),
                "blocking_issues": report.get("blocking_issues", []),
                "source_status_path": str(json_path),
            },
            indent=2,
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    lines = [
        "# Room 16 → Quellwert Promotion Contract",
        "",
        f"- Status: **{report['status']}**",
        f"- Ticker: `{ticker}`",
        f"- Quality report: `{report['candidate']['qualityReportPath']}`",
        f"- Public draft: `{report['candidate']['publicDraftPath']}`",
        "",
        "## Checks",
        "",
    ]
    for item in report["checks"]:
        mark = "PASS" if item["status"] == "pass" else "FAIL"
        lines.append(f"- **{mark}** `{item['name']}` ({item['severity']}): `{item['details']}`")
    lines.extend(["", "## Next Actions", ""])
    for action in report["nextActions"]:
        lines.append(f"- {action}")
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return json_path, md_path


def self_test() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        markdown = tmp_path / "complete.md"
        pdf = tmp_path / "complete.pdf"
        draft = tmp_path / "draft.md"
        ledger = tmp_path / "ledger.json"
        quality = tmp_path / "quality.json"
        markdown.write_text("SEC source_id asof period_type formula_id\n" * 20, encoding="utf-8")
        pdf.write_bytes(b"%PDF-1.4\n% self-test placeholder\n")
        draft.write_text(
            "# Quellen\nSEC 10-Q und IR Release.\n\n# Risiken\nZyklusrisiko.\n\nDiese Research-Notiz ist keine Anlageberatung.\n",
            encoding="utf-8",
        )
        ledger.write_text(
            json.dumps(
                {
                    "ticker": "TST",
                    "company": "Test AG",
                    "asof": "2026-05-04",
                    "claims": [
                        {"claim_id": f"claim_{idx}", "label": "Revenue", "value": idx, "unit": "USD", "period_type": "quarterly", "asof": "2026-05-04", "source_id": "sec_q", "formula_id": None}
                        for idx in range(1, 6)
                    ],
                    "sources": [
                        {"source_id": "sec_q", "source_type": "SEC", "title": "10-Q", "asof": "2026-05-04", "url": None},
                        {"source_id": "ir_q", "source_type": "IR", "title": "IR Release", "asof": "2026-05-04", "url": None},
                    ],
                },
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
        quality.write_text(
            json.dumps(
                {
                    "verdict": "pass",
                    "artifacts": {"complete_md": str(markdown), "complete_pdf": str(pdf)},
                    "metrics": {"research_integrity_verdict": "pass", "research_integrity_findings": [], "status": "quality_pass", "publishable": True},
                    "checks": [{"name": "manifest_has_tickers", "status": "pass", "details": ["TST"]}],
                },
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
        args = argparse.Namespace(
            quality_report=str(quality),
            markdown=None,
            pdf=None,
            fact_ledger=str(ledger),
            public_draft=str(draft),
            reviewed_by="self-test",
            sources_human_verified=True,
            non_advice_confirmed=True,
            requested_visibility="public",
        )
        report = evaluate(args)
        if report["status"] != "public_ready":
            raise SystemExit(json.dumps(report, indent=2, ensure_ascii=False))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--quality-report", help="Path to a Room 16 quality-report.json")
    parser.add_argument("--markdown", help="Override complete Markdown path")
    parser.add_argument("--pdf", help="Override complete PDF path")
    parser.add_argument("--fact-ledger", help="Path to room16 fact ledger JSON")
    parser.add_argument("--public-draft", help="Path to Quellwert editorial draft Markdown")
    parser.add_argument("--reviewed-by", default="")
    parser.add_argument("--sources-human-verified", action="store_true")
    parser.add_argument("--non-advice-confirmed", action="store_true")
    parser.add_argument("--requested-visibility", choices=["hidden", "member", "public"], default="public")
    parser.add_argument("--out-dir", default=str(OUT_DIR))
    parser.add_argument("--print-json", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.self_test:
        self_test()
        print("self_test=pass")
        return
    if not args.quality_report:
        raise SystemExit("--quality-report is required unless --self-test is used")
    report = evaluate(args)
    json_path, md_path = write_report(report, resolve_path(args.out_dir) or OUT_DIR)
    if args.print_json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print(json_path)
        print(md_path)
        print(f"status={report['status']}")
    if report["status"] != "public_ready":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
