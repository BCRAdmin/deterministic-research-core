#!/usr/bin/env python3
"""Build the standard Room 16 report bundle and run the quality gate."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess  # nosec B404
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BUNDLE_STEP_TIMEOUT_SECONDS = int(os.environ.get("ROOM16_BUNDLE_STEP_TIMEOUT_SECONDS", "900"))


def _run(command: list[str]) -> subprocess.CompletedProcess[str]:
    print("+", " ".join(command))
    try:
        result = subprocess.run(  # nosec B603
            command,
            cwd=ROOT,
            check=False,
            text=True,
            capture_output=True,
            timeout=BUNDLE_STEP_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired as error:
        if error.stdout:
            print(str(error.stdout)[-4000:], end="")
        if error.stderr:
            print(str(error.stderr)[-4000:], end="", file=sys.stderr)
        raise SystemExit(
            f"Bundle step timed out after {BUNDLE_STEP_TIMEOUT_SECONDS}s: {' '.join(command)}"
        ) from error
    if result.stdout:
        print(result.stdout, end="")
    if result.stderr:
        print(result.stderr, end="", file=sys.stderr)
    result.check_returncode()
    return result


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _latest_complete_pdf(report_dir: Path) -> Path:
    complete_dir = report_dir / "complete"
    matches = sorted(complete_dir.glob("*-complete-dossier.pdf"))
    if not matches:
        raise SystemExit(f"No complete Room 16 PDF found in {complete_dir}")
    return matches[-1]


def _latest_complete_markdown(report_dir: Path) -> Path:
    complete_dir = report_dir / "complete"
    matches = sorted(complete_dir.glob("*-complete-dossier.md"))
    if not matches:
        raise SystemExit(f"No complete Room 16 markdown found in {complete_dir}")
    return matches[-1]


def _latest_quality_json(report_dir: Path) -> Path:
    quality_dir = report_dir / "quality"
    matches = sorted(quality_dir.glob("*-room16-quality-report.json"))
    if not matches:
        raise SystemExit(f"No Room 16 quality report found in {quality_dir}")
    return matches[-1]


def _write_bundle_manifest(report_dir: Path, *, ticker: str | None, quality_path: Path) -> Path:
    quality = json.loads(quality_path.read_text(encoding="utf-8"))
    metrics = quality.get("metrics", {})
    generation_stage = quality.get("generation_stage") or metrics.get("generation_stage")
    bundle_type = {
        "draft_markdown_qa": "markdown_qa_bundle",
        "internal_best": "internal_review_bundle",
        "public_final": "public_final_bundle",
    }.get(generation_stage, "internal_review_bundle")
    artifact_consistency = {}
    artifact_consistency_path = quality.get("artifacts", {}).get("artifact_consistency_report")
    if artifact_consistency_path and Path(artifact_consistency_path).exists():
        artifact_consistency = json.loads(Path(artifact_consistency_path).read_text(encoding="utf-8"))
    manifest = {
        "schema_version": 1,
        "ticker": ticker,
        "created_at": quality.get("created_at"),
        "generation_stage": generation_stage,
        "render_mode": quality.get("render_mode") or metrics.get("render_mode"),
        "review_status": quality.get("review_status") or metrics.get("review_status"),
        "quality_verdict": quality.get("quality_verdict") or metrics.get("quality_verdict") or quality.get("verdict"),
        "score_scope": quality.get("score_scope") or metrics.get("score_scope"),
        "bundle_type": bundle_type,
        "publishable": quality.get("publishable") if "publishable" in quality else metrics.get("publishable"),
        "public_ready": quality.get("public_ready") if "public_ready" in quality else metrics.get("public_ready"),
        "visibility": quality.get("visibility") or metrics.get("visibility"),
        "final_documents_rendered": metrics.get("final_documents_rendered"),
        "publish_gate_verdict": quality.get("publish_gate_verdict") or metrics.get("publish_gate_verdict"),
        "promotion_gate_verdict": quality.get("promotion_gate_verdict") or metrics.get("promotion_gate_verdict"),
        "artifact_consistency_status": artifact_consistency.get("artifact_consistency_status") or metrics.get("artifact_consistency_status"),
        "artifact_consistency_error_count": artifact_consistency.get("artifact_consistency_error_count") or metrics.get("artifact_consistency_error_count", 0),
        "clean_public_bundle": bool(
            (quality.get("generation_stage") or metrics.get("generation_stage")) == "public_final"
            and (quality.get("public_ready") if "public_ready" in quality else metrics.get("public_ready")) is True
            and metrics.get("final_documents_rendered") is True
            and (artifact_consistency.get("artifact_consistency_status") or metrics.get("artifact_consistency_status")) == "clean"
        ),
        "artifacts": quality.get("artifacts", {}),
    }
    path = report_dir / "bundle_manifest.json"
    path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return path


def _verify_shelf_publish(source_pdf: Path, publish_result: subprocess.CompletedProcess[str]) -> Path:
    target_line = publish_result.stdout.strip().splitlines()[-1] if publish_result.stdout.strip() else ""
    target = Path(target_line)
    if not target.exists():
        raise SystemExit(f"Shelf publish did not produce a readable target: {target_line}")
    if source_pdf.stat().st_size != target.stat().st_size or _sha256(source_pdf) != _sha256(target):
        raise SystemExit(f"Shelf publish mismatch: {source_pdf} -> {target}")
    print(f"Shelf verified: {target}")
    return target


def _safe_ticker(ticker: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", ticker).strip("_")


def _load_tickers(run_dir: Path) -> list[str]:
    manifest = json.loads((run_dir / "batch_manifest.json").read_text(encoding="utf-8"))
    return [result["ticker"] for result in manifest.get("results", []) if result.get("ticker")]


def _build_one(args: argparse.Namespace, python: str, ticker: str | None, out_root: Path) -> None:
    ticker_args = ["--tickers", ticker] if ticker else []
    complete_dir = out_root / "complete"
    if args.with_premium and args.render_final_documents:
        premium_dir = out_root / "premium"
        premium_cmd = [
            python,
            "scripts/room16_build_premium_report.py",
            "--run-dir",
            args.run_dir,
            "--out-dir",
            str(premium_dir),
            "--translate-model",
            args.translate_model,
            *ticker_args,
        ]
    else:
        premium_cmd = None
    complete_cmd = [
        python,
        "scripts/room16_build_complete_dossier.py",
        "--run-dir",
        args.run_dir,
        "--out-dir",
        str(complete_dir),
        "--translate-model",
        args.translate_model,
        *ticker_args,
    ]
    if args.date:
        complete_cmd.extend(["--date", args.date])
    if args.render_final_documents:
        complete_cmd.append("--render-documents")
    quality_cmd = [
        python,
        "scripts/room16_report_quality_gate.py",
        "--run-dir",
        args.run_dir,
        "--reports-dir",
        str(out_root),
        *ticker_args,
    ]
    if not args.render_final_documents:
        quality_cmd.append("--allow-missing-rendered-documents")
    if args.with_premium and args.render_final_documents:
        quality_cmd.append("--require-premium")
    if args.date:
        quality_cmd.extend(["--date", args.date])
    if args.generation_stage:
        quality_cmd.extend(["--generation-stage", args.generation_stage])
    if args.promotion_status:
        quality_cmd.extend(["--promotion-status", args.promotion_status])
    if args.requested_visibility:
        quality_cmd.extend(["--requested-visibility", args.requested_visibility])

    if premium_cmd:
        _run(premium_cmd)
    _run(complete_cmd)
    _latest_complete_markdown(out_root)
    _run(quality_cmd)
    quality_path = _latest_quality_json(out_root)
    bundle_manifest = _write_bundle_manifest(out_root, ticker=ticker, quality_path=quality_path)
    print(bundle_manifest)
    bundle_manifest_payload = json.loads(bundle_manifest.read_text(encoding="utf-8"))
    can_publish_shelf = bool(bundle_manifest_payload.get("clean_public_bundle"))
    if ticker and args.render_final_documents and can_publish_shelf and not args.no_shelf:
        source_pdf = _latest_complete_pdf(out_root)
        shelf_cmd = [
            python,
            "scripts/room16_publish_report_shelf.py",
            "--report-dir",
            str(out_root),
            "--ticker",
            ticker,
            "--shelf-dir",
            args.shelf_dir,
        ]
        publish_result = _run(shelf_cmd)
        _verify_shelf_publish(source_pdf, publish_result)
    elif ticker and args.render_final_documents:
        print("Shelf publish skipped: rendered documents are internal until promotion public_final passes.")
    elif ticker and not args.render_final_documents:
        print("Shelf publish skipped: first-pass QA mode renders markdown only.")
    if args.with_premium and not args.render_final_documents:
        print("Premium document render skipped: use --render-final-documents for final DOCX/PDF output.")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", required=True)
    parser.add_argument(
        "--out-root",
        default=None,
        help="Output root for the bundle. Default: reports/room16/runs/<RUN_ID>.",
    )
    parser.add_argument("--translate-model", default="deepseek-v4-pro:cloud")
    parser.add_argument("--date", default=None)
    parser.add_argument(
        "--combine",
        action="store_true",
        help="Explicitly build one combined multi-company bundle. Default is one completed/saved ticker bundle at a time.",
    )
    parser.add_argument(
        "--with-premium",
        action="store_true",
        help="Also build premium overview memo/PDF. Default builds only the complete long dossier.",
    )
    parser.add_argument(
        "--render-final-documents",
        action="store_true",
        help="Render DOCX/PDF and publish the final PDF to the shelf. Default is markdown-only first-pass QA.",
    )
    parser.add_argument(
        "--generation-stage",
        choices=["draft_markdown_qa", "internal_best", "public_final"],
        default=None,
        help="Lifecycle lane passed to the quality gate. Defaults to draft_markdown_qa or internal_best based on render mode.",
    )
    parser.add_argument(
        "--promotion-status",
        default=None,
        help="Optional promotion_status.json proving public_final approval.",
    )
    parser.add_argument(
        "--requested-visibility",
        choices=["internal_only", "hidden", "public_candidate", "public"],
        default="internal_only",
        help="Requested lifecycle visibility; public still requires a passing promotion status.",
    )
    parser.add_argument(
        "--shelf-dir",
        default=str(Path.home() / "Documents" / "DreamFactory" / "Room16" / "Reports"),
        help="Human reading shelf for final per-company PDFs.",
    )
    parser.add_argument(
        "--no-shelf",
        action="store_true",
        help="Do not mirror final PDFs into the human Room 16 Reports shelf.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    python = sys.executable
    run_dir = Path(args.run_dir)
    run_id = run_dir.resolve().name
    out_root = Path(args.out_root) if args.out_root else ROOT / "reports" / "room16" / "runs" / run_id
    if args.combine:
        _build_one(args, python, None, out_root / "combined")
        return

    for ticker in _load_tickers(run_dir):
        _build_one(args, python, ticker, out_root / _safe_ticker(ticker))


if __name__ == "__main__":
    main()
