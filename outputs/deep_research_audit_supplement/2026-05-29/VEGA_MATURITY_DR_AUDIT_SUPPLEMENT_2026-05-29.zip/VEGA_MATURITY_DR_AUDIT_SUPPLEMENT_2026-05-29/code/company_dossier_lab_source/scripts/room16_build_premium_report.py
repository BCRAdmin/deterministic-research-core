#!/usr/bin/env python3
"""Create premium German DOCX/PDF Room 16 reports from TradingAgents outputs."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import textwrap
import unicodedata
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Any

from docx import Document
from docx.enum.section import WD_SECTION_START
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4, landscape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfgen import canvas as pdf_canvas
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (
    BaseDocTemplate,
    Frame,
    PageBreak,
    PageTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
)

from room16_text_safety import strip_visible_reasoning_artifacts


ROOT = Path(__file__).resolve().parents[1]
RUN_DIR = ROOT / ".runtime" / "bcr-company-batches" / "20260501-233522"
ACCENT = "BFA46A"
NAVY = "0B1623"
INK = "17212B"
MUTED = "5D6B78"
PALE = "F5F7FA"

REPORT_KEYS = [
    ("market_report", "Markt- und Techniklage"),
    ("sentiment_report", "Sentiment und Marktstimmung"),
    ("news_report", "Nachrichten- und Makrolage"),
    ("fundamentals_report", "Fundamentale Lage"),
]


def _company_count_label(count: int) -> str:
    if count == 1:
        return "Ein Unternehmen"
    return f"{count} Unternehmen"


def _safe_ticker(ticker: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", ticker).strip("_")


def _filter_records(records: list[dict[str, Any]], tickers: list[str] | None) -> list[dict[str, Any]]:
    if not tickers:
        return records
    requested = {ticker.upper() for ticker in tickers}
    return [record for record in records if str(record["ticker"]).upper() in requested]


def _artifact_stem(stamp: str, records: list[dict[str, Any]]) -> str:
    if len(records) == 1:
        return f"{stamp}-room16-{_safe_ticker(str(records[0]['ticker']))}-premium-investment-memo"
    return f"{stamp}-room16-premium-investment-memo"


def _clean_markdown(text: str) -> str:
    text = strip_visible_reasoning_artifacts(text)
    text = text.replace("📊", "").replace("🔍", "").replace("🚨", "")
    text = re.sub(r"(?m)^\s*```[A-Za-z0-9_-]*\s*$", "", text)
    text = re.sub(r"\*\*(.*?)\*\*", r"\1", text)
    text = re.sub(r"`([^`]+)`", r"\1", text)
    text = re.sub(r"^#+\s*", "", text, flags=re.MULTILINE)
    return _polish_german(text.strip())


def _polish_german(text: str) -> str:
    text = unicodedata.normalize("NFC", text)
    text = strip_visible_reasoning_artifacts(text)
    render_safe_replacements = {
        "\u2080": "0",
        "\u2081": "1",
        "\u2082": "2",
        "\u2083": "3",
        "\u2084": "4",
        "\u2085": "5",
        "\u2086": "6",
        "\u2087": "7",
        "\u2088": "8",
        "\u2089": "9",
        "\u2212": "-",
        "\u2192": "->",
        "\u2190": "<-",
        "\u2191": " steigend",
        "\u2193": " fallend",
        "\u25b2": " steigend",
        "\u25bc": " fallend",
        "\u2b06": " steigend",
        "\u2264": "<=",
        "\u2265": ">=",
        "\u00d7": "x",
        "\u00b1": "+/-",
        "\u202f": " ",
        "\u2588": "=",
        "\u2591": ".",
        "\u03c3": "Sigma",
        "\u00d8": "Durchschnitt",
    }
    for source, target in render_safe_replacements.items():
        text = text.replace(source, target)
    replacements = {
        "Begruendung": "Begründung",
        "Positionsgroesse": "Positionsgröße",
        "Uebersetzung": "Übersetzung",
        "Uebersetze": "Übersetze",
        "Ueber": "Über",
        "ueber": "über",
        "Oeffentlich": "Öffentlich",
        "oeffentlich": "öffentlich",
        "zugaenglich": "zugänglich",
        "Ausschliesslich": "Ausschließlich",
        "Ausgewaehlte": "Ausgewählte",
        "Maerkte": "Märkte",
        "groessten": "größten",
        "groesste": "größte",
        "grossen": "großen",
        "grosse": "große",
        "geschaeft": "geschäft",
        "quellengestuetzt": "quellengestützt",
        "ungewoehnlich": "ungewöhnlich",
        "gegenueber": "gegenüber",
        "ungefaehr": "ungefähr",
        "fuer": "für",
        "moeglich": "möglich",
        "unmoeglich": "unmöglich",
        "vollstaendig": "vollständig",
        "vollstaendigen": "vollständigen",
        "vollstaendigem": "vollständigem",
        "Kapazitaet": "Kapazität",
        "Kapazitaets": "Kapazitäts",
        "Primaer": "Primär",
        "Pruef": "Prüf",
        "pruef": "prüf",
        "gruen": "grün",
        "naechster": "nächster",
        "naechste": "nächste",
        "naechsten": "nächsten",
        "haelt": "hält",
        "haengt": "hängt",
        "koennen": "können",
        "muessen": "müssen",
        "veraender": "veränder",
        "zurueck": "zurück",
        "Maerz": "März",
        "zaehlt": "zählt",
        "Staerke": "Stärke",
        "Rueck": "Rück",
        "Muenchener": "Münchener",
        "Abhaengigkeit": "Abhängigkeit",
        "Investitionsplaene": "Investitionspläne",
        "laesst": "lässt",
        "Lagerbestaende": "Lagerbestände",
        "Realitaet": "Realität",
        "Stabilitaet": "Stabilität",
        "Qualitaetsvergleich": "Qualitätsvergleich",
        "Qualitaet": "Qualität",
        "praezise": "präzise",
        "zusaetzlich": "zusätzlich",
        "Transaktionsausgabe: VERKAUF": "Transaktionsausgabe: VERKAUFEN",
        "VERKAUFENEN": "VERKAUFEN",
        "Executive Summary": "Kurzfazit",
        "Investment Thesis": "Investment-These",
        "Recommendation": "Einordnung",
        "Rationale": "Begründung",
        "Strategic Actions": "Operative Schritte",
    }
    for source, target in replacements.items():
        text = text.replace(source, target)
    return text


def _compact(text: str, max_chars: int = 1500) -> str:
    text = _clean_markdown(text)
    text = _cleanup_visible_english_labels(text)
    blocks = [block.strip() for block in re.split(r"\n\s*\n", text) if block.strip()]
    picked: list[str] = []
    for block in blocks:
        if block.startswith("|") or set(block) <= {"-", "|", ":", " "}:
            continue
        picked.append(block)
        if sum(len(item) for item in picked) > max_chars:
            break
    result = "\n\n".join(picked) if picked else text
    if len(result) > max_chars:
        return result[:max_chars].rstrip() + " ..."
    return result


def _cleanup_visible_english_labels(text: str) -> str:
    text = _polish_german(text)
    text = re.sub(r"\b(?:Underweight|Sell|Hold|Buy)\s+Kurzfazit:\s*", "Kurzfazit: ", text, flags=re.I)
    text = re.sub(r"\bAction:\s*", "Umsetzung: ", text)
    text = re.sub(r"\bReasoning:\s*", "Begründung: ", text)
    text = re.sub(r"\bPosition Sizing:\s*", "Positionsgröße: ", text)
    text = re.sub(r"\bStop Loss:\s*", "Stop-Loss: ", text)
    return text.strip()


def _extract_label(text: str, label: str) -> str:
    pattern = re.compile(rf"\*\*{re.escape(label)}\*\*:\s*(.+)")
    for line in text.splitlines():
        match = pattern.search(line)
        if match:
            return _clean_markdown(match.group(1))
    return ""


def _load_run(run_dir: Path) -> tuple[dict[str, Any], dict[str, dict[str, Any]]]:
    manifest = json.loads((run_dir / "batch_manifest.json").read_text(encoding="utf-8"))
    states = {}
    for item in manifest["results"]:
        states[item["ticker"]] = json.loads(Path(item["log_file"]).read_text(encoding="utf-8"))
    return manifest, states


def _cache_key(ticker: str, field: str, text: str) -> str:
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]
    return f"{ticker}:{field}:{digest}"


def _ollama_translate(
    ticker: str,
    field: str,
    text: str,
    cache: dict[str, str],
    model: str,
) -> str:
    key = _cache_key(ticker, field, text)
    if key in cache:
        return cache[key]

    prompt = f"""Übersetze und redigiere den folgenden TradingAgents-Abschnitt vollständig ins Deutsche.

Ziel: professioneller interner Hedge-Fund-Research-Stil, präzise, ruhig, keine Umgangssprache.
Pflicht:
- Zahlen, Ticker, Kurse, Prozentwerte, Stop-Loss und Position-Sizing exakt erhalten.
- Keine Inhalte erfinden, keine Daten aktualisieren.
- Keine zusätzliche Finanzberatungs-Disclaimer einfügen.
- Nutze echte deutsche Umlaute wie ä, ö, ü, Ä, Ö und Ü; keine ASCII-Ersatzschreibweise wie ae, oe oder ue.
- Übersetze Labels:
  Action = Umsetzung
  Reasoning = Begründung
  Stop Loss = Stop-Loss
  Position Sizing = Positionsgröße
  FINAL TRANSACTION PROPOSAL = Finale Transaktionsausgabe
  Recommendation = Einordnung
  Rationale = Begründung
  Strategic Actions = Operative Schritte
- Gib nur die deutsche Fassung aus.

Ticker: {ticker}
Abschnitt: {field}

TEXT:
{text}
"""
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "stream": False,
        "options": {"temperature": 0.1},
    }
    request = urllib.request.Request(
        "http://localhost:11434/api/chat",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=420) as response:  # nosec B310
            data = json.loads(response.read())
            translated = data.get("message", {}).get("content", "").strip()
    except (urllib.error.URLError, TimeoutError) as exc:
        translated = _fallback_translate(text)
        translated += f"\n\n[Hinweis: automatische Uebersetzung via Ollama fehlgeschlagen: {exc}]"
    translated = _polish_german(translated)
    cache[key] = translated
    return translated


def _fallback_translate(text: str) -> str:
    replacements = {
        "**Action**": "**Umsetzung**",
        "**Reasoning**": "**Begruendung**",
        "**Stop Loss**": "**Stop-Loss**",
        "**Position Sizing**": "**Positionsgroesse**",
        "FINAL TRANSACTION PROPOSAL": "Finale Transaktionsausgabe",
        "**Recommendation**": "**Einordnung**",
        "**Rationale**": "**Begruendung**",
        "**Strategic Actions**": "**Operative Schritte**",
                "Sell": "Reduzieren/Verkaufen",
        "Hold": "Halten",
        "Underweight": "Untergewichten",
    }
    for source, target in replacements.items():
        text = text.replace(source, target)
    return text


def _prepare_records(
    manifest: dict[str, Any],
    states: dict[str, dict[str, Any]],
    cache: dict[str, str],
    translate_model: str,
) -> list[dict[str, Any]]:
    records = []
    for item in manifest["results"]:
        ticker = item["ticker"]
        state = states[ticker]
        final_decision = state["final_trade_decision"]
        trader_de = _ollama_translate(
            ticker,
            "trader_investment_decision",
            state["trader_investment_decision"],
            cache,
            translate_model,
        )
        plan_de = _ollama_translate(
            ticker,
            "investment_plan",
            state["investment_plan"],
            cache,
            translate_model,
        )
        trader_signal = _derive_trader_signal(trader_de)
        records.append(
            {
                "ticker": ticker,
                "status": item.get("status"),
                "runtime": item.get("elapsed_seconds"),
                "decision": item.get("decision"),
                "source_ledger_file": item.get("source_ledger_file"),
                "rating": _extract_label(final_decision, "Rating") or item.get("decision"),
                "final": final_decision,
                "trader_de": trader_de,
                "trader_signal": trader_signal,
                "plan_de": plan_de,
                "state": state,
            }
        )
    return records


def _derive_trader_signal(translated_trader: str) -> str:
    translated_lower = _clean_markdown(translated_trader).lower()
    for line in translated_lower.splitlines():
        if line.startswith("umsetzung:"):
            value = line.split(":", 1)[1]
            if "halt" in value:
                return "Halten"
            if any(term in value for term in ["verkauf", "verkaufen", "reduzierung", "reduzieren"]):
                return "Reduzieren/Verkaufen"
    if "finale transaktionsausgabe: halten" in translated_lower:
        return "Halten"
    if any(term in translated_lower for term in ["finale transaktionsausgabe: verkauf", "umsetzung: verkauf"]):
        return "Reduzieren/Verkaufen"
    return "Halten"


def _shade_cell(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def _set_cell_text(cell, text: str, bold: bool = False, color: str = INK, size: int = 9) -> None:
    cell.text = ""
    paragraph = cell.paragraphs[0]
    run = paragraph.add_run(text)
    run.bold = bold
    run.font.color.rgb = RGBColor.from_string(color)
    run.font.size = Pt(size)
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER


def _add_docx_table(document: Document, rows: list[list[str]], widths: list[float] | None = None) -> None:
    table = document.add_table(rows=1, cols=len(rows[0]))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for index, value in enumerate(rows[0]):
        _shade_cell(table.rows[0].cells[index], NAVY)
        _set_cell_text(table.rows[0].cells[index], value, bold=True, color="FFFFFF", size=8)
    for row in rows[1:]:
        cells = table.add_row().cells
        for index, value in enumerate(row):
            _set_cell_text(cells[index], value, size=8)
    if widths:
        for row in table.rows:
            for index, width in enumerate(widths):
                row.cells[index].width = Inches(width)
    document.add_paragraph()


def _add_docx_paragraph(document: Document, text: str, style: str | None = None) -> None:
    for block in [part.strip() for part in text.split("\n\n") if part.strip()]:
        paragraph = document.add_paragraph(style=style)
        paragraph.paragraph_format.space_after = Pt(6)
        run = paragraph.add_run(_clean_markdown(block))
        run.font.size = Pt(9.5)


def build_docx(records: list[dict[str, Any]], manifest: dict[str, Any], out_path: Path) -> None:
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.65)
    section.bottom_margin = Inches(0.65)
    section.left_margin = Inches(0.72)
    section.right_margin = Inches(0.72)

    styles = doc.styles
    styles["Normal"].font.name = "Aptos"
    styles["Normal"].font.size = Pt(9.5)
    for name, size, color in [
        ("Title", 26, NAVY),
        ("Heading 1", 18, NAVY),
        ("Heading 2", 13, NAVY),
        ("Heading 3", 11, MUTED),
    ]:
        style = styles[name]
        style.font.name = "Aptos"
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor.from_string(color)

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("ROOM 16")
    run.bold = True
    run.font.size = Pt(34)
    run.font.color.rgb = RGBColor.from_string(NAVY)
    sub = doc.add_paragraph()
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub_run = sub.add_run(f"Investment-Komitee-Memorandum | {_company_count_label(len(records))}")
    sub_run.font.size = Pt(13)
    sub_run.font.color.rgb = RGBColor.from_string(ACCENT)
    meta = doc.add_paragraph()
    meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
    meta_run = meta.add_run(
        f"Erstellt am {datetime.now().strftime('%d.%m.%Y')} | TradingAgents-Datum {manifest.get('date')} | Interner Analyse-Output"
    )
    meta_run.font.size = Pt(9)
    meta_run.font.color.rgb = RGBColor.from_string(MUTED)
    doc.add_paragraph()

    _add_docx_table(
        doc,
        [
            ["Ticker", "Rating", "Trader-Signal", "Laufzeit", "Kernbotschaft"],
            *[
                [
                    record["ticker"],
                    str(record["rating"]),
                    record["trader_signal"],
                    f"{record['runtime']}s",
                    _compact(record["final"], 220),
                ]
                for record in records
            ],
        ],
        widths=[0.8, 1.05, 1.35, 0.85, 3.75],
    )

    warning = doc.add_paragraph()
    warning.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = warning.add_run(
        "Nur internes Research-Material. Keine Finanzberatung, keine Handelsanweisung, keine externe Veröffentlichung ohne Review."
    )
    run.italic = True
    run.font.size = Pt(8.5)
    run.font.color.rgb = RGBColor.from_string(MUTED)
    doc.add_page_break()

    for record in records:
        doc.add_heading(record["ticker"], level=1)
        _add_docx_table(
            doc,
            [
                ["Rating", "Trader-Signal", "Laufzeit", "Modell"],
                [
                    str(record["rating"]),
                    record["trader_signal"],
                    f"{record['runtime']}s",
                    f"{manifest.get('quick_model')} / {manifest.get('deep_model')}",
                ],
            ],
            widths=[1.4, 1.6, 1.0, 3.6],
        )
        doc.add_heading("Entscheidungskern", level=2)
        _add_docx_paragraph(doc, _compact(record["final"], 1800))
        doc.add_heading("Trader-Sicht", level=2)
        _add_docx_paragraph(doc, record["trader_de"])
        doc.add_heading("Investment-Plan", level=2)
        _add_docx_paragraph(doc, record["plan_de"])
        doc.add_heading("Analystenlage", level=2)
        analyst_rows = [["Baustein", "Kurzfazit"]]
        for key, title in REPORT_KEYS:
            analyst_rows.append([title, _compact(record["state"].get(key, ""), 300)])
        _add_docx_table(doc, analyst_rows, widths=[1.7, 5.8])
        doc.add_page_break()

    doc.save(out_path)


def _pdf_styles():
    styles = getSampleStyleSheet()
    return {
        "cover_title": ParagraphStyle(
            "cover_title",
            parent=styles["Title"],
            fontName="Helvetica-Bold",
            fontSize=34,
            leading=38,
            textColor=colors.white,
            alignment=TA_CENTER,
            spaceAfter=12,
        ),
        "cover_sub": ParagraphStyle(
            "cover_sub",
            parent=styles["Normal"],
            fontName="Helvetica",
            fontSize=14,
            leading=18,
            textColor=colors.HexColor("#D9C790"),
            alignment=TA_CENTER,
            spaceAfter=18,
        ),
        "h1": ParagraphStyle(
            "h1",
            parent=styles["Heading1"],
            fontName="Helvetica-Bold",
            fontSize=18,
            leading=22,
            textColor=colors.HexColor("#0B1623"),
            spaceBefore=12,
            spaceAfter=8,
        ),
        "h2": ParagraphStyle(
            "h2",
            parent=styles["Heading2"],
            fontName="Helvetica-Bold",
            fontSize=12,
            leading=15,
            textColor=colors.HexColor("#0B1623"),
            spaceBefore=9,
            spaceAfter=5,
        ),
        "body": ParagraphStyle(
            "body",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=8.6,
            leading=11.2,
            textColor=colors.HexColor("#17212B"),
            spaceAfter=6,
        ),
        "small": ParagraphStyle(
            "small",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=7.4,
            leading=9.3,
            textColor=colors.HexColor("#5D6B78"),
        ),
    }


def _on_cover(canvas, doc):
    width, height = A4
    canvas.saveState()
    canvas.setFillColor(colors.HexColor("#0B1623"))
    canvas.rect(0, 0, width, height, fill=1, stroke=0)
    canvas.setFillColor(colors.HexColor("#BFA46A"))
    canvas.rect(2.0 * cm, 2.2 * cm, width - 4.0 * cm, 0.08 * cm, fill=1, stroke=0)
    canvas.setStrokeColor(colors.HexColor("#BFA46A"))
    canvas.setLineWidth(0.7)
    canvas.rect(1.5 * cm, 1.5 * cm, width - 3.0 * cm, height - 3.0 * cm, fill=0, stroke=1)
    canvas.restoreState()


def _on_page(canvas, doc):
    width, height = A4
    canvas.saveState()
    canvas.setStrokeColor(colors.HexColor("#D6DAE0"))
    canvas.setLineWidth(0.4)
    canvas.line(1.4 * cm, height - 1.25 * cm, width - 1.4 * cm, height - 1.25 * cm)
    canvas.setFont("Helvetica", 7)
    canvas.setFillColor(colors.HexColor("#5D6B78"))
    canvas.drawString(1.4 * cm, height - 0.95 * cm, "ROOM 16 | Internal Research Memorandum")
    canvas.drawRightString(width - 1.4 * cm, 0.75 * cm, f"Seite {doc.page}")
    canvas.restoreState()


def _para(text: str, style: ParagraphStyle) -> Paragraph:
    safe = _clean_markdown(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    safe = safe.replace("\n", "<br/>")
    return Paragraph(safe, style)


def _pdf_table(rows: list[list[str]], col_widths: list[float]) -> Table:
    table = Table(
        [[_clean_markdown(cell) for cell in row] for row in rows],
        colWidths=[width * cm for width in col_widths],
        repeatRows=1,
        hAlign="LEFT",
    )
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0B1623")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
                ("FONTSIZE", (0, 0), (-1, -1), 7.2),
                ("LEADING", (0, 0), (-1, -1), 8.5),
                ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#D6DAE0")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F7F8FA")]),
                ("LEFTPADDING", (0, 0), (-1, -1), 5),
                ("RIGHTPADDING", (0, 0), (-1, -1), 5),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]
        )
    )
    return table


def build_pdf(records: list[dict[str, Any]], manifest: dict[str, Any], out_path: Path) -> None:
    _build_landscape_deck_pdf(records, manifest, out_path)


def _rating_de(value: str) -> str:
    mapping = {
        "Underweight": "Untergewichten",
        "Sell": "Verkaufen",
        "Hold": "Halten",
        "Buy": "Kaufen",
    }
    return mapping.get(value, value)


def _draw_bg(c, width: float, height: float, dark: bool = False) -> None:
    c.setFillColor(colors.HexColor("#07111D" if dark else "#F4F1E8"))
    c.rect(0, 0, width, height, stroke=0, fill=1)
    c.setStrokeColor(colors.HexColor("#BFA46A"))
    c.setLineWidth(1.1)
    c.rect(26, 26, width - 52, height - 52, stroke=1, fill=0)


def _draw_header(c, width: float, height: float, title: str, kicker: str = "ROOM 16") -> None:
    c.setFillColor(colors.HexColor("#07111D"))
    c.rect(0, height - 58, width, 58, stroke=0, fill=1)
    c.setFillColor(colors.HexColor("#BFA46A"))
    c.rect(0, height - 60, width, 2, stroke=0, fill=1)
    c.setFont("Helvetica-Bold", 9)
    c.drawString(36, height - 25, kicker)
    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 19)
    c.drawString(36, height - 49, title)


def _fit_lines(text: str, max_width: float, font: str, size: float) -> list[str]:
    text = _clean_markdown(text).replace(" ", " ")
    words = re.sub(r"\s+", " ", text).split()
    lines: list[str] = []
    line = ""
    for word in words:
        candidate = f"{line} {word}".strip()
        if pdfmetrics.stringWidth(candidate, font, size) <= max_width:
            line = candidate
        else:
            if line:
                lines.append(line)
            line = word
    if line:
        lines.append(line)
    return lines


def _draw_wrapped(
    c,
    text: str,
    x: float,
    y: float,
    max_width: float,
    font: str = "Helvetica",
    size: float = 8.7,
    leading: float = 11.0,
    color: str = "#17212B",
    max_lines: int | None = None,
) -> float:
    lines = _fit_lines(text, max_width, font, size)
    if max_lines is not None and len(lines) > max_lines:
        lines = lines[:max_lines]
        if lines:
            lines[-1] = lines[-1].rstrip(" .,;") + " ..."
    c.setFont(font, size)
    c.setFillColor(colors.HexColor(color))
    for line in lines:
        c.drawString(x, y, line)
        y -= leading
    return y


def _draw_card(
    c,
    x: float,
    y: float,
    w: float,
    h: float,
    title: str,
    body: str = "",
    accent: str = "#BFA46A",
    dark: bool = False,
) -> None:
    c.setFillColor(colors.HexColor("#0B1623" if dark else "#FFFFFF"))
    c.roundRect(x, y, w, h, 8, stroke=0, fill=1)
    c.setStrokeColor(colors.HexColor(accent))
    c.setLineWidth(0.8)
    c.roundRect(x, y, w, h, 8, stroke=1, fill=0)
    c.setFillColor(colors.HexColor(accent))
    c.rect(x, y + h - 4, w, 4, stroke=0, fill=1)
    c.setFont("Helvetica-Bold", 10)
    c.setFillColor(colors.HexColor("#FFFFFF" if dark else "#0B1623"))
    c.drawString(x + 12, y + h - 22, title)
    if body:
        _draw_wrapped(
            c,
            body,
            x + 12,
            y + h - 40,
            w - 24,
            size=8.2,
            leading=10,
            color="#E7ECF1" if dark else "#17212B",
            max_lines=int((h - 48) / 10),
        )


def _draw_badge(c, x: float, y: float, label: str, tone: str) -> None:
    palette = {
        "red": ("#7A1F1F", "#FBE9E9"),
        "amber": ("#8A6418", "#FFF3D1"),
        "green": ("#1E6B4B", "#E5F4ED"),
        "blue": ("#203D66", "#E6EEF8"),
    }
    stroke, fill = palette.get(tone, palette["blue"])
    c.setFillColor(colors.HexColor(fill))
    c.setStrokeColor(colors.HexColor(stroke))
    c.roundRect(x, y, 118, 25, 12, stroke=1, fill=1)
    c.setFont("Helvetica-Bold", 8.5)
    c.setFillColor(colors.HexColor(stroke))
    c.drawCentredString(x + 59, y + 8, label)


def _badge_row_start(page_width: float, count: int) -> float:
    badge_width = 118
    gap = 10
    total_width = count * badge_width + max(0, count - 1) * gap
    return page_width / 2 - total_width / 2


def _dashboard_layout(count: int, page_width: float) -> tuple[int, int, list[tuple[float, float]]]:
    if count <= 1:
        card_w, card_h = 560, 190
        return card_w, card_h, [(page_width / 2 - card_w / 2, 230)]
    if count == 2:
        card_w, card_h = 372, 190
        return card_w, card_h, [(36, 238), (434, 238)]
    if count == 3:
        card_w, card_h = 372, 166
        return card_w, card_h, [(36, 315), (434, 315), (page_width / 2 - card_w / 2, 118)]
    card_w, card_h = 372, 176
    return card_w, card_h, [(36, 315), (434, 315), (36, 112), (434, 112)]


def _tone(record: dict[str, Any]) -> str:
    value = str(record["rating"]).lower()
    if "sell" in value:
        return "red"
    if "under" in value:
        return "amber"
    if "hold" in value:
        return "blue"
    return "green"


def _short_exec(record: dict[str, Any], chars: int = 420) -> str:
    text = _compact(record["final"], chars)
    text = _cleanup_visible_english_labels(text)
    return re.sub(r"^(Rating|Kurzfazit|Investment-These):\s*", "", text).strip()


def _first_after_label(text: str, label: str, max_chars: int = 450) -> str:
    clean = _clean_markdown(text)
    match = re.search(rf"{re.escape(label)}:\s*(.+?)(?:\n[A-ZÄÖÜ][^:\n]{{2,40}}:|\Z)", clean, re.S)
    result = match.group(1).strip() if match else clean
    result = re.sub(r"\s+", " ", result)
    return result[:max_chars].rstrip() + (" ..." if len(result) > max_chars else "")


def _operative_lines(text: str, max_items: int = 4) -> list[str]:
    clean = _clean_markdown(text)
    items = re.findall(r"(?:^|\n)\s*(?:\d+\.|-)\s+(.+?)(?=(?:\n\s*(?:\d+\.|-)\s+)|\Z)", clean, re.S)
    if not items:
        items = [clean]
    result = []
    for item in items[:max_items]:
        item = re.sub(r"\s+", " ", item).strip()
        result.append(item[:230].rstrip() + (" ..." if len(item) > 230 else ""))
    return result


def _analyst_rows(record: dict[str, Any]) -> list[tuple[str, str]]:
    rows = []
    for key, title in REPORT_KEYS:
        rows.append((title, _compact(record["state"].get(key, ""), 210)))
    return rows


def _build_landscape_deck_pdf(records: list[dict[str, Any]], manifest: dict[str, Any], out_path: Path) -> None:
    width, height = landscape(A4)
    c = pdf_canvas.Canvas(str(out_path), pagesize=landscape(A4))

    # Cover
    _draw_bg(c, width, height, dark=True)
    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 48)
    c.drawCentredString(width / 2, height / 2 + 58, "ROOM 16")
    c.setFillColor(colors.HexColor("#D9C790"))
    c.setFont("Helvetica", 19)
    c.drawCentredString(width / 2, height / 2 + 22, "Investment-Komitee-Memo")
    c.setFont("Helvetica", 12)
    c.drawCentredString(
        width / 2,
        height / 2 - 12,
        f"{_company_count_label(len(records))} | {manifest.get('date')} | Interner Analyse-Output",
    )
    x = _badge_row_start(width, len(records))
    for record in records:
        _draw_badge(c, x, height / 2 - 68, record["ticker"], _tone(record))
        x += 128
    c.setStrokeColor(colors.HexColor("#BFA46A"))
    c.setLineWidth(2)
    c.line(70, 72, width - 70, 72)
    c.showPage()

    # Dashboard
    _draw_bg(c, width, height)
    _draw_header(c, width, height, "Entscheidungsübersicht")
    c.setFont("Helvetica", 8.5)
    c.setFillColor(colors.HexColor("#5D6B78"))
    c.drawString(36, height - 82, "Verdichtete Management-Sicht aus dem grünen TradingAgents-End-to-End-Lauf.")
    card_w, card_h, positions = _dashboard_layout(len(records), width)
    for record, (x, y) in zip(records, positions):
        _draw_card(c, x, y, card_w, card_h, record["ticker"], dark=False, accent="#BFA46A")
        _draw_badge(c, x + 15, y + card_h - 58, _rating_de(str(record["rating"])), _tone(record))
        c.setFont("Helvetica-Bold", 8.5)
        c.setFillColor(colors.HexColor("#5D6B78"))
        c.drawString(x + 150, y + card_h - 49, f"Signal: {record['trader_signal']}  |  Laufzeit: {record['runtime']}s")
        max_lines = max(6, int((card_h - 88) / 10.2))
        _draw_wrapped(c, _short_exec(record, 370), x + 15, y + card_h - 78, card_w - 30, size=8.4, leading=10.2, max_lines=max_lines)
    c.showPage()

    # Company pages
    for record in records:
        _draw_bg(c, width, height)
        _draw_header(c, width, height, f"{record['ticker']} | Investment-Sicht")
        _draw_badge(c, 36, height - 100, _rating_de(str(record["rating"])), _tone(record))
        _draw_badge(c, 166, height - 100, record["trader_signal"], _tone(record))
        c.setFont("Helvetica", 8.5)
        c.setFillColor(colors.HexColor("#5D6B78"))
        c.drawRightString(width - 36, height - 92, f"{manifest.get('quick_model')} / {manifest.get('deep_model')}")

        _draw_card(c, 36, 332, 360, 128, "Investment-These", _short_exec(record, 720), accent="#BFA46A")
        trader_body = _first_after_label(record["trader_de"], "Begründung", 720)
        _draw_card(c, 414, 332, 392, 128, "Trader-Sicht", trader_body, accent="#BFA46A")

        _draw_card(c, 36, 166, 360, 142, "Operative Schritte", accent="#BFA46A")
        y = 278
        for item in _operative_lines(record["plan_de"], max_items=4):
            c.setFillColor(colors.HexColor("#BFA46A"))
            c.circle(51, y + 2, 2.4, stroke=0, fill=1)
            y = _draw_wrapped(c, item, 62, y, 314, size=7.9, leading=9.3, max_lines=2)
            y -= 4

        _draw_card(c, 414, 166, 392, 142, "Analystenlage", accent="#BFA46A")
        y = 278
        for title, summary in _analyst_rows(record):
            c.setFont("Helvetica-Bold", 7.8)
            c.setFillColor(colors.HexColor("#0B1623"))
            c.drawString(430, y, title)
            y -= 9
            y = _draw_wrapped(c, summary, 430, y, 358, size=7.3, leading=8.2, max_lines=2)
            y -= 4

        _draw_card(c, 36, 68, 770, 70, "Portfolio-Kontext", accent="#BFA46A")
        context = (
            "Die Seite verdichtet das TradingAgents-Originalmaterial zu einer Komitee-Sicht. "
            "Die vollständigen Rohreports bleiben im Markdown-/DOCX-Archiv erhalten; diese PDF priorisiert Lesbarkeit, Vergleichbarkeit und Entscheidungsdisziplin."
        )
        _draw_wrapped(c, context, 54, 102, 735, size=8.1, leading=9.6, max_lines=4)
        c.showPage()

    # Appendix
    _draw_bg(c, width, height)
    _draw_header(c, width, height, "Methodik und Grenzen")
    method = (
        f"Quelle: TradingAgents-End-to-End-Lauf vom {manifest.get('date')} mit Analysten "
        f"{', '.join(manifest.get('analysts', []))}. Provider: {manifest.get('provider')}; "
        f"Quick/Deep: {manifest.get('quick_model')} / {manifest.get('deep_model')}. "
        "Die PDF ist ein redigiertes internes Leseartefakt und ersetzt nicht die Rohlogs."
    )
    _draw_card(c, 36, 354, 770, 122, "Laufkontext", method, accent="#BFA46A")
    _draw_card(
        c,
        36,
        206,
        770,
        122,
        "Wichtige Grenzen",
        "Kein Live-Trading, keine externe Finanzberatung, keine externe Verteilung ohne Review. "
        "GPT-5.5 ist als nächster Qualitätsvergleich vorgesehen, war in dieser Shell aber wegen fehlendem OPENAI_API_KEY nicht testbar.",
        accent="#BFA46A",
    )
    _draw_card(
        c,
        36,
        82,
        770,
        92,
        "Artefakte",
        "Rohdaten, Modellmatrix, konsolidierte Markdown-/DOCX-Reports und diese Premium-PDF liegen im lokalen Room-16-Reportordner. "
        "Die englischen Trader-/Investment-Plan-Abschnitte wurden für dieses Deck ins Deutsche redigiert.",
        accent="#BFA46A",
    )
    c.save()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", default=str(RUN_DIR))
    parser.add_argument("--out-dir", default=str(ROOT / "reports" / "room16" / "premium"))
    parser.add_argument("--translate-model", default="deepseek-v4-pro:cloud")
    parser.add_argument("--tickers", nargs="+", default=None, help="Optional ticker filter for one-company artifacts.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    run_dir = Path(args.run_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    cache_path = out_dir / "translation-cache.json"
    cache = json.loads(cache_path.read_text(encoding="utf-8")) if cache_path.exists() else {}
    manifest, states = _load_run(run_dir)
    records = _prepare_records(manifest, states, cache, args.translate_model)
    records = _filter_records(records, args.tickers)
    if not records:
        raise SystemExit(f"No records matched ticker filter: {args.tickers}")
    cache_path.write_text(json.dumps(cache, indent=2, ensure_ascii=False), encoding="utf-8")
    stamp = datetime.now().strftime("%Y-%m-%d")
    stem = _artifact_stem(stamp, records)
    docx_path = out_dir / f"{stem}.docx"
    pdf_path = out_dir / f"{stem}.pdf"
    build_docx(records, manifest, docx_path)
    build_pdf(records, manifest, pdf_path)
    print(docx_path)
    print(pdf_path)


if __name__ == "__main__":
    main()
