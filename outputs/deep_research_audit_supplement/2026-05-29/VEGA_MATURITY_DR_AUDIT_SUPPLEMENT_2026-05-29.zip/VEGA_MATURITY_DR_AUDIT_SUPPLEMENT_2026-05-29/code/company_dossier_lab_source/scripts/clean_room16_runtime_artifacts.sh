#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APPLY=false
PRUNE_REPORTS=false
PRUNE_RUNTIME=false
INCLUDE_NODE_MODULES=false
SKIP_BUILD_ARTIFACTS=false
RETENTION_DAYS="${RETENTION_DAYS:-30}"
KEEP_HARDENING_RUNS="${KEEP_HARDENING_RUNS:-120}"
ALLOW_ACTIVE_CLEAN="${ALLOW_ACTIVE_CLEAN:-false}"
ALLOW_REPORT_RETENTION_PRUNE="${ALLOW_REPORT_RETENTION_PRUNE:-false}"

usage() {
  cat <<'USAGE'
Usage:
  scripts/clean_room16_runtime_artifacts.sh [--apply] [--skip-build-artifacts] [--prune-reports] [--prune-runtime] [--include-node-modules]

Default is dry-run. Nothing is deleted unless --apply is passed.

Safe default targets:
  - .pytest_cache
  - room16-app/dist
  - room16-app/dist-macos
  - room16-app/.runtime-room16-mobile*.png

Optional retention targets:
  --skip-build-artifacts  Do not delete dist/dist-macos/screenshots. Use this while the local app is running.
  --prune-reports          Delete files under reports/ older than RETENTION_DAYS (default: 30)
  --prune-runtime          Delete files under selected .runtime diagnostic folders older than RETENTION_DAYS
                           and keep only the latest KEEP_HARDENING_RUNS generated hardening cycles
  --include-node-modules   Delete room16-app/node_modules too. Use only when reinstalling is acceptable.

Never deleted by default:
  - .runtime/bcr-company-batches
  - reports/
  - node_modules

Report pruning safety:
  Applying --prune-reports requires ALLOW_REPORT_RETENTION_PRUNE=true.
  This prevents silently deleting report evidence while Room 16 is still a project archive.
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --apply)
      APPLY=true
      ;;
    --skip-build-artifacts)
      SKIP_BUILD_ARTIFACTS=true
      ;;
    --prune-reports)
      PRUNE_REPORTS=true
      ;;
    --prune-runtime)
      PRUNE_RUNTIME=true
      ;;
    --include-node-modules)
      INCLUDE_NODE_MODULES=true
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown argument: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
  shift
done

if [[ "$PRUNE_REPORTS" == true && "$APPLY" == true && "$ALLOW_REPORT_RETENTION_PRUNE" != true ]]; then
  cat >&2 <<'MSG'
Refuse to prune Room 16 reports without ALLOW_REPORT_RETENTION_PRUNE=true.
Reports are evidence, not disposable build output. Set the env var only after a retention decision.
MSG
  exit 5
fi

real_path() {
  python3 -c 'import os,sys; print(os.path.realpath(sys.argv[1]))' "$1"
}

format_size() {
  local path="$1"
  if [[ -e "$path" ]]; then
    du -sh "$path" 2>/dev/null | awk '{print $1}'
  else
    echo "missing"
  fi
}

assert_app_not_running_for_apply() {
  if [[ "$APPLY" != true || "$ALLOW_ACTIVE_CLEAN" == true ]]; then
    return
  fi

  if command -v lsof >/dev/null 2>&1 && lsof -nP -iTCP:4516 -sTCP:LISTEN >/dev/null 2>&1; then
    cat >&2 <<'MSG'
Refuse to delete Room 16 build artifacts while port 4516 is active.
Stop the Room 16 server first, or set ALLOW_ACTIVE_CLEAN=true if you intentionally accept the risk.
MSG
    exit 4
  fi
}

safe_delete_path() {
  local rel_path="$1"
  local full_path
  full_path="$(real_path "$PROJECT_ROOT/$rel_path")"

  case "$full_path" in
    "$PROJECT_ROOT"/*) ;;
    *)
      echo "Refuse to delete outside project: $full_path" >&2
      exit 3
      ;;
  esac

  if [[ ! -e "$full_path" ]]; then
    echo "- skip missing: $rel_path"
    return
  fi

  if [[ "$APPLY" == true ]]; then
    echo "- delete $rel_path ($(format_size "$full_path"))"
    rm -rf "$full_path"
  else
    echo "- dry-run $rel_path ($(format_size "$full_path"))"
  fi
}

prune_files_older_than() {
  local rel_path="$1"
  local full_path="$PROJECT_ROOT/$rel_path"
  local real_full_path
  real_full_path="$(real_path "$full_path")"

  case "$real_full_path" in
    "$PROJECT_ROOT"/*) ;;
    *)
      echo "Refuse to prune outside project: $real_full_path" >&2
      exit 3
      ;;
  esac

  if [[ ! -d "$full_path" ]]; then
    echo "- skip missing: $rel_path"
    return
  fi

  if [[ "$APPLY" == true ]]; then
    echo "- delete files in $rel_path older than ${RETENTION_DAYS} days"
    find "$full_path" -type f -mtime +"$RETENTION_DAYS" -print -delete
  else
    echo "- dry-run files in $rel_path older than ${RETENTION_DAYS} days"
    find "$full_path" -type f -mtime +"$RETENTION_DAYS" -print
  fi
}

safe_delete_full_path() {
  local full_path="$1"
  local allowed_root="$2"
  local label="$3"
  local real_full_path
  local real_allowed_root
  real_full_path="$(real_path "$full_path")"
  real_allowed_root="$(real_path "$allowed_root")"

  case "$real_full_path" in
    "$real_allowed_root"/*) ;;
    *)
      echo "Refuse to delete outside allowed root: $real_full_path" >&2
      exit 3
      ;;
  esac

  if [[ ! -e "$real_full_path" ]]; then
    echo "- skip missing: $label"
    return
  fi

  if [[ "$APPLY" == true ]]; then
    echo "- delete $label ($(format_size "$real_full_path"))"
    rm -rf "$real_full_path"
  else
    echo "- dry-run $label ($(format_size "$real_full_path"))"
  fi
}

prune_dirs_keep_latest() {
  local rel_path="$1"
  local keep="$2"
  local full_path="$PROJECT_ROOT/$rel_path"
  local entries=()
  local entry
  local index=0
  local prune_count=0

  if [[ ! -d "$full_path" ]]; then
    echo "- skip missing: $rel_path"
    return
  fi

  while IFS= read -r entry; do
    entries+=("$entry")
  done < <(find "$full_path" -mindepth 1 -maxdepth 1 -type d -name '20*T*Z-cycle-*' | sort -r)

  echo "- detected ${#entries[@]} generated cycles in $rel_path; keeping latest $keep"

  for entry in "${entries[@]}"; do
    index=$((index + 1))
    if [[ "$index" -le "$keep" ]]; then
      continue
    fi
    prune_count=$((prune_count + 1))
    if [[ "$APPLY" == true ]]; then
      case "$entry" in
        "$full_path"/*) ;;
        *)
          echo "Refuse to delete outside diagnostic root: $entry" >&2
          exit 3
          ;;
      esac
      rm -rf "$entry"
    fi
  done

  if [[ "$APPLY" == true ]]; then
    echo "- deleted $prune_count generated cycles from $rel_path"
  else
    echo "- dry-run would delete $prune_count generated cycles from $rel_path"
  fi
}

echo "Room 16 runtime cleanup for: $PROJECT_ROOT"
if [[ "$APPLY" == true ]]; then
  echo "Mode: apply"
else
  echo "Mode: dry-run"
fi

echo
if [[ "$SKIP_BUILD_ARTIFACTS" == true ]]; then
  echo "Regenerable build/runtime artifacts skipped by --skip-build-artifacts."
else
  echo "Regenerable build/runtime artifacts:"
  assert_app_not_running_for_apply
  safe_delete_path ".pytest_cache"
  safe_delete_path "room16-app/dist"
  safe_delete_path "room16-app/dist-macos"

  shopt -s nullglob
  for screenshot in "$PROJECT_ROOT"/room16-app/.runtime-room16-mobile*.png; do
    safe_delete_path "${screenshot#$PROJECT_ROOT/}"
  done
fi

if [[ "$INCLUDE_NODE_MODULES" == true ]]; then
  echo
  echo "Dependency cache:"
  assert_app_not_running_for_apply
  safe_delete_path "room16-app/node_modules"
fi

if [[ "$PRUNE_REPORTS" == true ]]; then
  echo
  echo "Report retention:"
  prune_files_older_than "reports"
else
  echo
  echo "Report retention skipped. Use --prune-reports to prune old report files."
fi

if [[ "$PRUNE_RUNTIME" == true ]]; then
  echo
  echo "Runtime diagnostic retention:"
  prune_dirs_keep_latest ".runtime/room16-app/hardening" "$KEEP_HARDENING_RUNS"
  prune_files_older_than ".runtime/room16-app/hardening"
  prune_files_older_than ".runtime/room16-app/verification"
  prune_files_older_than ".runtime/room16-app/logs"
  prune_files_older_than ".runtime/room16-smokes"
  prune_files_older_than ".runtime/room16-model-matrix"
else
  echo
  echo "Runtime diagnostics skipped. Use --prune-runtime to prune old diagnostic files."
fi

echo
echo "Done."
