#!/usr/bin/env python3
"""Run shortened TradingAgents flow smokes for candidate Quick/Deep pairs."""

from __future__ import annotations

import argparse
import json
import subprocess  # nosec B404
import sys
from datetime import datetime
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]


def _slug(value: str) -> str:
    return (
        value.replace(":", "-")
        .replace("/", "-")
        .replace(".", "_")
        .replace(" ", "_")
    )


def _latest_matrix() -> Path:
    candidates = sorted((ROOT / ".runtime" / "room16-model-matrix").glob("model-matrix-*.json"))
    if not candidates:
        raise SystemExit("No model matrix found. Run scripts/room16_model_matrix.py first.")
    return candidates[-1]


def _write_markdown(report: dict[str, Any], path: Path) -> None:
    lines = [
        "# Room 16 Pair Flow Smoke",
        "",
        f"Created: `{report['created_at']}`",
        f"Ticker: `{report['ticker']}`",
        "",
        "| Provider | Quick | Deep | Status | Runtime | Run dir |",
        "| --- | --- | --- | ---: | ---: | --- |",
    ]
    for item in report["results"]:
        lines.append(
            f"| {item['provider']} | `{item['quick_model']}` | `{item['deep_model']}` | "
            f"{item['status']} | {item.get('elapsed_seconds', '')}s | `{item.get('run_dir', '')}` |"
        )
    path.write_text("\n".join(lines), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--matrix-json", default=None)
    parser.add_argument("--ticker", default="PACB")
    parser.add_argument("--max-pairs", type=int, default=0, help="0 means all candidates")
    parser.add_argument("--timeout-seconds", type=int, default=900)
    parser.add_argument("--out-dir", default=str(ROOT / ".runtime" / "room16-pair-flow-smokes"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    matrix_path = Path(args.matrix_json) if args.matrix_json else _latest_matrix()
    matrix = json.loads(matrix_path.read_text(encoding="utf-8"))
    pairs = [row for row in matrix["pairs"] if row["status"] == "candidate"]
    if args.max_pairs > 0:
        pairs = pairs[: args.max_pairs]

    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    out_dir = Path(args.out_dir) / stamp
    out_dir.mkdir(parents=True, exist_ok=True)
    report: dict[str, Any] = {
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "matrix_source": str(matrix_path),
        "ticker": args.ticker,
        "results": [],
    }

    for index, pair in enumerate(pairs, start=1):
        provider = pair["provider"]
        quick = pair["quick_model"]
        deep = pair["deep_model"]
        run_dir = out_dir / f"{index:02d}-{_slug(quick)}__{_slug(deep)}"
        print(f"[{index}/{len(pairs)}] {provider} quick={quick} deep={deep}", flush=True)
        cmd = [
            sys.executable,
            str(ROOT / "scripts" / "bcr_company_batch.py"),
            "--tickers",
            args.ticker,
            "--provider",
            provider,
            "--quick-model",
            quick,
            "--deep-model",
            deep,
            "--analysts",
            "market",
            "--debate-rounds",
            "0",
            "--risk-rounds",
            "0",
            "--ticker-timeout-seconds",
            str(args.timeout_seconds),
            "--llm-timeout",
            "300",
            "--llm-max-retries",
            "1",
            "--ticker-retries",
            "0",
            "--run-dir",
            str(run_dir),
        ]
        completed = subprocess.run(  # nosec B603
            cmd,
            cwd=ROOT,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=args.timeout_seconds + 120,
            env={**dict(**__import__("os").environ), "TRADINGAGENTS_DISABLE_ANNOUNCEMENTS": "1"},
        )
        manifest_path = run_dir / "batch_manifest.json"
        item: dict[str, Any] = {
            "provider": provider,
            "quick_model": quick,
            "deep_model": deep,
            "run_dir": str(run_dir),
            "returncode": completed.returncode,
            "stdout_tail": completed.stdout[-4000:],
        }
        if manifest_path.exists():
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            result = (manifest.get("results") or [{}])[-1]
            item.update(
                {
                    "status": result.get("status", manifest.get("status")),
                    "elapsed_seconds": result.get("elapsed_seconds"),
                    "decision": result.get("decision"),
                    "error": result.get("error"),
                    "log_file": result.get("log_file"),
                }
            )
        else:
            item.update({"status": "no_manifest"})
        report["results"].append(item)

        json_path = out_dir / "pair-flow-smoke.json"
        md_path = out_dir / "pair-flow-smoke.md"
        json_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
        _write_markdown(report, md_path)

    print(out_dir / "pair-flow-smoke.json")
    print(out_dir / "pair-flow-smoke.md")


if __name__ == "__main__":
    main()
