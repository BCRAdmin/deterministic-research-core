#!/usr/bin/env python3
"""Validate Room 16 report bundles against the reporting standard."""

from __future__ import annotations

import argparse
import json
import re
import sys
import zipfile
from datetime import datetime
from xml.etree import ElementTree
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
SCRIPT_DIR = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from tradingagents.quality import (
    MANUAL_REVIEW_DISPLAY_RATING,
    SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE,
    assess_speculative_deep_tech_profile,
    run_institutional_regression_suite,
)
from room16.core.render_qa import validate_render_backend_for_lifecycle
from room16_text_safety import find_visible_reasoning_leaks

try:
    from docx import Document
except ImportError:
    Document = None


GENERATION_STAGES = {"draft_markdown_qa", "internal_best", "public_final"}
RENDER_MODES = {"markdown_first_qa", "internal_pdf", "final_public_documents"}
VISIBILITY_STATES = {"internal_only", "hidden", "public_candidate", "public"}
REVIEW_STATUSES = {
    "qa_pass",
    "qa_failed",
    "manual_review",
    "internal_ready",
    "public_ready",
    "blocked",
    "failed",
}

REQUIRED_KEYS = [
    "market_report",
    "sentiment_report",
    "news_report",
    "fundamentals_report",
    "trader_investment_decision",
    "investment_plan",
    "final_trade_decision",
]
MIN_FIELD_CHARS = {
    "market_report": 1500,
    "sentiment_report": 1500,
    "news_report": 1500,
    "fundamentals_report": 1500,
    "trader_investment_decision": 300,
    "investment_plan": 300,
    "final_trade_decision": 300,
}
FORBIDDEN_VISIBLE_TERMS = [
    "Action:",
    "Reasoning:",
    "Recommendation:",
    "Rationale:",
    "Strategic Actions:",
    "FINAL TRANSACTION PROPOSAL",
    "Trader Output",
    "Investment View",
    "Investment Thesis",
    "Executive Summary",
    "Begruendung",
    "Positionsgroesse",
    "VERKAUFENEN",
]
GERMAN_ASCII_UMLAUT_PATTERNS = [
    ("fuer -> für", re.compile(r"\bfuer\b", re.IGNORECASE)),
    ("ueber -> über", re.compile(r"\bueber\b", re.IGNORECASE)),
    ("gegenueber -> gegenüber", re.compile(r"\bgegenueber\b", re.IGNORECASE)),
    ("oeffentlich -> öffentlich", re.compile(r"\boeffentlich\w*\b", re.IGNORECASE)),
    ("zugaenglich -> zugänglich", re.compile(r"\bzugaenglich\b", re.IGNORECASE)),
    ("Ausschliesslich -> Ausschließlich", re.compile(r"\bAusschliesslich\b")),
    ("Ausgewaehlte -> Ausgewählte", re.compile(r"\bAusgewaehlte\b")),
    ("Maerkte -> Märkte", re.compile(r"\bMaerkte\b")),
    ("Muenchener -> Münchener", re.compile(r"\bMuenchener\b")),
    ("Rueck -> Rück", re.compile(r"\b\w*Rueck\w*\b")),
    ("Pruef/pruef -> Prüf/prüf", re.compile(r"\b\w*[Pp]ruef\w*\b")),
    ("Primaer -> Primär", re.compile(r"\bPrimaer\w*\b")),
    ("Qualitaet -> Qualität", re.compile(r"\b\w*Qualitaet\w*\b")),
    ("Kapazitaet -> Kapazität", re.compile(r"\b\w*Kapazitaet\w*\b")),
    ("vollstaendig -> vollständig", re.compile(r"\bvollstaendig\w*\b", re.IGNORECASE)),
    ("gruen -> grün", re.compile(r"\bgruen\b", re.IGNORECASE)),
    ("ungefaehr -> ungefähr", re.compile(r"\bungefaehr\b", re.IGNORECASE)),
    ("naechst -> nächst", re.compile(r"\bnaechst\w*\b", re.IGNORECASE)),
    ("moeglich -> möglich", re.compile(r"\b\w*moeglich\w*\b", re.IGNORECASE)),
    ("haelt -> hält", re.compile(r"\bhaelt\b", re.IGNORECASE)),
    ("koennen -> können", re.compile(r"\bkoennen\b", re.IGNORECASE)),
    ("muessen -> müssen", re.compile(r"\bmuessen\b", re.IGNORECASE)),
    ("haengt -> hängt", re.compile(r"\bhaengt\b", re.IGNORECASE)),
    ("veraendern -> verändern", re.compile(r"\bveraender\w*\b", re.IGNORECASE)),
    ("laesst -> lässt", re.compile(r"\blaesst\b", re.IGNORECASE)),
    ("Staerke -> Stärke", re.compile(r"\bStaerke\b")),
    ("Stabilitaet -> Stabilität", re.compile(r"\b\w*Stabilitaet\w*\b")),
    ("Realitaet -> Realität", re.compile(r"\b\w*Realitaet\w*\b")),
]
VISIBLE_MARKDOWN_TOKENS = [REDACTED]
BROKEN_GLYPH_TOKENS = [REDACTED]
UNSUPPORTED_RENDER_TOKENS = [REDACTED]
    "\u2080",
    "\u2081",
    "\u2082",
    "\u2083",
    "\u2084",
    "\u2085",
    "\u2086",
    "\u2087",
    "\u2088",
    "\u2089",
    "\u2212",
    "\u2192",
    "\u2190",
    "\u2191",
    "\u2193",
    "\u25b2",
    "\u25bc",
    "\u2b06",
    "\u2264",
    "\u2265",
    "\u00d7",
    "\u00b1",
    "\u202f",
    "\u2588",
    "\u2591",
    "\u03c3",
    "\u00d8",
]
NO_COMPANY_NEWS_PATTERNS = [
    re.compile(r"\bkeine\s+(?:wesentlichen\s+|materiellen\s+)?(?:unternehmensspezifischen\s+)?(?:nachrichten|news)\b", re.IGNORECASE),
    re.compile(r"\bno\s+(?:material\s+|company[- ]specific\s+)?(?:news|events)\b", re.IGNORECASE),
]
MATERIAL_EVENT_PATTERNS = [
    ("earnings", re.compile(r"\b(?:earnings|quartalszahlen|quartalsergebnis|q[1-4][ -]?\d{4})\b", re.IGNORECASE)),
    ("filing", re.compile(r"\b(?:10-q|10-k|8-k|filing|sec|einreichung)\b", re.IGNORECASE)),
    ("guidance", re.compile(r"\b(?:guidance|ausblick|prognose)\b", re.IGNORECASE)),
]
SOURCE_LEDGER_TERMS = ["source_id", "asof", "formula_id", "period_type"]
STRICT_SOURCE_FINDING_TYPES = {
    "missing_source_ledger",
    "missing_period_metadata",
    "missing_source_priority_note",
}
INSTITUTIONAL_SOURCE_TERMS = ["source_id", "period_type", "asof", "formula_id"]
FORWARD_VALUATION_PATTERNS = [
    re.compile(r"\bforward\s+(?:p/e|pe)\b", re.IGNORECASE),
    re.compile(r"\bforward[- ]?kgv\b", re.IGNORECASE),
]
EPS_SOURCE_PATTERNS = [
    re.compile(r"\b(?:eps|gewinn je aktie)\b", re.IGNORECASE),
    re.compile(r"\b(?:consensus|konsens|guidance|ausblick|management)\b", re.IGNORECASE),
]
SBC_CASH_OUTFLOW_PATTERNS = [
    re.compile(r"\bsbc\b[^.\n]{0,80}\b(?:cash[- ]?outflow|cash outflow|zahlungswirksamer abfluss|cashflow frisst)\b", re.IGNORECASE),
    re.compile(r"\b(?:cash[- ]?outflow|zahlungswirksamer abfluss|cashflow frisst)\b[^.\n]{0,80}\bsbc\b", re.IGNORECASE),
]
SBC_CASH_OUTFLOW_NEGATION_PATTERN = re.compile(
    r"\b(?:kein(?:e[rsn]?)?|nicht|niemals|never|not|no|non[- ]?cash|nicht[- ]?(?:bar|monetär|monetar|monitär|monitar|zahlungswirksam))\b"
    r"[^.\n;]{0,120}\b(?:cash[- ]?outflow|cash outflow|zahlungswirksamer abfluss)\b"
    r"|"
    r"\b(?:cash[- ]?outflow|cash outflow|zahlungswirksamer abfluss)\b"
    r"[^.\n;]{0,120}\b(?:kein(?:e[rsn]?)?|nicht|niemals|never|not|no|non[- ]?cash)\b",
    re.IGNORECASE,
)
KNOWN_MATERIAL_EVENTS = {
    "AMZN": [
        {
            "event": "Amazon Q1 2026 Earnings Release",
            "date": "2026-04-29",
            "required_terms": ["q1", "quartal", "earnings", "10-q", "guidance", "ausblick"],
        }
    ]
}


def _company_count_label(count: int) -> str:
    if count == 1:
        return "Ein Unternehmen"
    return f"{count} Unternehmen"


def _safe_ticker(ticker: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", ticker).strip("_")


def _filter_results(results: list[dict[str, Any]], tickers: list[str] | None) -> list[dict[str, Any]]:
    if not tickers:
        return results
    requested = {ticker.upper() for ticker in tickers}
    return [result for result in results if str(result.get("ticker", "")).upper() in requested]


def _artifact_names(stamp: str, tickers: list[str]) -> dict[str, str]:
    if len(tickers) == 1:
        safe_ticker = _safe_ticker(tickers[0])
        return {
            "premium_docx": f"{stamp}-room16-{safe_ticker}-premium-investment-memo.docx",
            "premium_pdf": f"{stamp}-room16-{safe_ticker}-premium-investment-memo.pdf",
            "complete_md": f"{stamp}-room16-{safe_ticker}-complete-dossier.md",
            "complete_docx": f"{stamp}-room16-{safe_ticker}-complete-dossier.docx",
            "complete_pdf": f"{stamp}-room16-{safe_ticker}-complete-dossier.pdf",
        }
    return {
        "premium_docx": f"{stamp}-room16-premium-investment-memo.docx",
        "premium_pdf": f"{stamp}-room16-premium-investment-memo.pdf",
        "complete_md": f"{stamp}-room16-complete-dossier.md",
        "complete_docx": f"{stamp}-room16-complete-dossier.docx",
        "complete_pdf": f"{stamp}-room16-complete-dossier.pdf",
    }


def _latest_completed_run() -> Path:
    base = ROOT / ".runtime" / "bcr-company-batches"
    manifests = sorted(base.glob("*/batch_manifest.json"))
    for manifest_path in reversed(manifests):
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("status") == "completed":
            return manifest_path.parent
    raise SystemExit("No completed Room 16 run found.")


def _word_count(text: str) -> int:
    return len(re.findall(r"\b[\w.$€%/-]+\b", text, flags=re.UNICODE))


def _load_manifest(run_dir: Path) -> dict[str, Any]:
    return json.loads((run_dir / "batch_manifest.json").read_text(encoding="utf-8"))


def _load_state(log_file: str) -> dict[str, Any]:
    return json.loads(Path(log_file).read_text(encoding="utf-8"))


def _load_source_ledger(path: str | None) -> list[dict[str, Any]]:
    if not path:
        return []
    ledger_path = Path(path)
    if not ledger_path.exists():
        return []
    entries: list[dict[str, Any]] = []
    for line in ledger_path.read_text(encoding="utf-8", errors="replace").splitlines():
        if not line.strip():
            continue
        try:
            entries.append(json.loads(line))
        except json.JSONDecodeError:
            entries.append({"raw": line})
    return entries


def _extract_docx(path: Path) -> str:
    if Document is None:
        with zipfile.ZipFile(path) as archive:
            xml_text = archive.read("word/document.xml")
        root = ElementTree.fromstring(xml_text)
        namespace = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
        return "\n".join(node.text or "" for node in root.findall(".//w:t", namespace))
    document = Document(str(path))
    parts = [paragraph.text for paragraph in document.paragraphs]
    for table in document.tables:
        for row in table.rows:
            for cell in row.cells:
                parts.append(cell.text)
    return "\n".join(parts)


def _import_fitz():
    try:
        import fitz  # type: ignore

        return fitz
    except ImportError:
        fallback = Path("/tmp/room16-render-libs")  # nosec B108
        if fallback.exists():
            sys.path.insert(0, str(fallback))
            try:
                import fitz  # type: ignore

                return fitz
            except ImportError:
                return None
    return None


def _import_pypdf():
    try:
        from pypdf import PdfReader  # type: ignore

        return PdfReader
    except ImportError:
        return None


def _extract_pdf(path: Path) -> tuple[str, int]:
    fitz = _import_fitz()
    if fitz is not None:
        document = fitz.open(str(path))
        return "\n".join(page.get_text() for page in document), len(document)

    PdfReader = _import_pypdf()
    if PdfReader is None:
        raise RuntimeError("No PDF text backend available. Install PyMuPDF/fitz or pypdf.")
    reader = PdfReader(str(path))
    return "\n".join(page.extract_text() or "" for page in reader.pages), len(reader.pages)


def _pdf_text_backend() -> str:
    if _import_fitz() is not None:
        return "pymupdf"
    if _import_pypdf() is not None:
        return "pypdf"
    return "unavailable"


def _resolve_artifact(directory: Path, exact_name: str, fallback_glob: str, allow_fallback: bool = False) -> Path:
    exact = directory / exact_name
    if exact.exists():
        return exact
    matches = sorted(directory.glob(fallback_glob)) if allow_fallback else []
    if allow_fallback and matches:
        return matches[-1]
    return exact


def _render_pdf(path: Path, out_dir: Path, prefix: str, pages: list[int] | None = None) -> list[str]:
    fitz = _import_fitz()
    if fitz is None:
        return []
    out_dir.mkdir(parents=True, exist_ok=True)
    for stale_image in out_dir.glob(f"{prefix}-page-*.png"):
        try:
            stale_image.unlink()
        except FileNotFoundError:
            pass
    document = fitz.open(str(path))
    page_indexes = list(range(len(document))) if pages is None else [page for page in pages if 0 <= page < len(document)]
    outputs = []
    for page_index in page_indexes:
        pix = document[page_index].get_pixmap(matrix=fitz.Matrix(1.45, 1.45), alpha=False)
        target = out_dir / f"{prefix}-page-{page_index + 1}.png"
        pix.save(str(target))
        outputs.append(str(target))
    return outputs


def _scan_terms(text: str, terms: list[str]) -> list[str]:
    return [term for term in terms if term in text]


def _scan_patterns(text: str, patterns: list[tuple[str, re.Pattern[str]]]) -> list[str]:
    return [label for label, pattern in patterns if pattern.search(text)]


def _scan_named_patterns(text: str, patterns: list[tuple[str, re.Pattern[str]]]) -> list[str]:
    return [label for label, pattern in patterns if pattern.search(text)]


def _has_sbc_cash_outflow_misstatement(text: str) -> bool:
    for pattern in SBC_CASH_OUTFLOW_PATTERNS:
        for match in pattern.finditer(text):
            window = text[max(0, match.start() - 140) : min(len(text), match.end() + 140)]
            if SBC_CASH_OUTFLOW_NEGATION_PATTERN.search(window):
                continue
            return True
    return False


def _manifest_date(manifest: dict[str, Any]) -> str:
    return str(manifest.get("date") or "")[:10]


def _contains_any(text: str, needles: list[str]) -> bool:
    lowered = text.lower()
    return any(needle.lower() in lowered for needle in needles)


def _research_integrity_findings(text: str, tickers: list[str], manifest: dict[str, Any]) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    combined_text = text.lower()
    no_news_claims = [pattern.pattern for pattern in NO_COMPANY_NEWS_PATTERNS if pattern.search(text)]
    material_events = _scan_named_patterns(text, MATERIAL_EVENT_PATTERNS)

    if no_news_claims and material_events:
        findings.append(
            {
                "severity": "critical",
                "type": "no_news_contradiction",
                "message": "Report claims no material/company news while the same report contains earnings, filing, or guidance language.",
                "claims": no_news_claims,
                "event_terms": material_events,
            }
        )

    for ticker in tickers:
        for event in KNOWN_MATERIAL_EVENTS.get(str(ticker).upper(), []):
            if _manifest_date(manifest) >= event["date"] and not _contains_any(combined_text, event["required_terms"]):
                findings.append(
                    {
                        "severity": "critical",
                        "type": "known_material_event_missing",
                        "ticker": ticker,
                        "event": event["event"],
                        "date": event["date"],
                        "required_terms": event["required_terms"],
                    }
                )

    if not all(term in combined_text for term in SOURCE_LEDGER_TERMS):
        findings.append(
            {
                "severity": "high",
                "type": "missing_source_ledger",
                "message": "Report has no complete source ledger fields for numbers.",
                "required_terms": SOURCE_LEDGER_TERMS,
                "present_terms": [term for term in SOURCE_LEDGER_TERMS if term in combined_text],
            }
        )

    if re.search(r"\b(?:ttm|free cash flow|fcf|operating cash flow|ocf|quartal|quarter)\b", combined_text) and "period_type" not in combined_text:
        findings.append(
            {
                "severity": "high",
                "type": "missing_period_metadata",
                "message": "Report discusses period-sensitive metrics but does not expose period_type metadata.",
            }
        )

    has_primary_source_note = bool(re.search(r"\b(?:sec|ir|investor relations|10-q|10-k|8-k)\b", combined_text))
    if not has_primary_source_note and re.search(r"\b(?:fundamental|umsatz|cashflow|eps|bilanz)\b", combined_text):
        findings.append(
            {
                "severity": "high",
                "type": "missing_source_priority_note",
                "message": "Fundamental claims are present, but no SEC/IR source-priority note is visible.",
            }
        )

    price_over_sma = re.search(r"preis\s*\([^)]*\)\s*>\s*[^.\n]*(?:200[- ]?(?:tage)?[- ]?sma|200[- ]?day)", combined_text)
    under_200_sma_claim = re.search(
        r"\b(?:kurs|preis|aktie|papier|notiert)[^.:\n]{0,90}(?:unter|below|leicht unter)\s+(?:dem\s+)?200[- ]?(?:tage)?[- ]?(?:durchschnitt|sma|day)",
        combined_text,
    )
    if price_over_sma and under_200_sma_claim:
        findings.append(
            {
                "severity": "critical",
                "type": "price_sma_text_contradiction",
                "message": "Report states price is above the 200-day average but also narrates price as below the 200-day average.",
            }
        )

    if "action**: hold" in combined_text and "final transaction proposal: **hold**" in combined_text and "rating:** halten" in combined_text:
        # Explicit pass-through pattern for current TradingAgents raw labels after translation.
        pass

    return findings


def _institutional_quality_findings(text: str) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    combined_text = text.lower()

    if any(pattern.search(text) for pattern in FORWARD_VALUATION_PATTERNS) and not all(
        any(pattern.search(text) for pattern in pattern_group)
        for pattern_group in [EPS_SOURCE_PATTERNS[:1], EPS_SOURCE_PATTERNS[1:]]
    ):
        findings.append(
            {
                "severity": "high",
                "type": "forward_pe_missing_eps_source",
                "message": "Forward P/E/KGV is discussed without a visible EPS source and period/basis note.",
            }
        )

    if _has_sbc_cash_outflow_misstatement(text):
        findings.append(
            {
                "severity": "critical",
                "type": "sbc_cash_outflow_misstatement",
                "message": "SBC is described as a cash outflow. SBC is non-cash but economically dilutive.",
            }
        )

    if "fcf" in combined_text or "free cash flow" in combined_text or "freier cashflow" in combined_text:
        if not re.search(r"\b(?:fcf[- ]?definition|free cash flow\s*=|operating cash flow\s*[-–]\s*capex|operativer cashflow\s*[-–]\s*capex)\b", combined_text):
            findings.append(
                {
                    "severity": "high",
                    "type": "fcf_definition_missing",
                    "message": "FCF is discussed without a visible formula/definition.",
                }
            )

    if any(term in combined_text for term in ["ttm", "fy", "q4", "quartal", "forward", "kgv", "eps"]) and not all(
        term in combined_text for term in INSTITUTIONAL_SOURCE_TERMS[:2]
    ):
        findings.append(
            {
                "severity": "high",
                "type": "institutional_metric_metadata_missing",
                "message": "Period-sensitive metrics need source_id and period_type metadata.",
                "required_terms": INSTITUTIONAL_SOURCE_TERMS[:2],
                "present_terms": [term for term in INSTITUTIONAL_SOURCE_TERMS[:2] if term in combined_text],
            }
        )

    return findings


def _check(condition: bool, name: str, details: Any, checks: list[dict[str, Any]]) -> None:
    checks.append({"name": name, "status": "pass" if condition else "fail", "details": details})


def _write_reports(report: dict[str, Any], out_dir: Path, stamp: str) -> tuple[Path, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / f"{stamp}-room16-quality-report.json"
    md_path = out_dir / f"{stamp}-room16-quality-report.md"
    report.setdefault("artifacts", {})
    report["artifacts"]["quality_report"] = str(md_path)
    report["artifacts"]["quality_report_json"] = str(json_path)
    json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    lines = [
        "# Room 16 Quality Report",
        "",
        f"Created: `{report['created_at']}`",
        f"Run directory: `{report['run_dir']}`",
        f"Verdict: **{report['verdict']}**",
        "",
        "## Metrics",
        "",
    ]
    for key, value in report["metrics"].items():
        lines.append(f"- `{key}`: `{value}`")
    lines.extend(["", "## Checks", ""])
    for check in report["checks"]:
        mark = "PASS" if check["status"] == "pass" else "FAIL"
        lines.append(f"- **{mark}** `{check['name']}`: {check['details']}")
    lines.extend(["", "## Rendered Pages", ""])
    for rendered in report["rendered_pages"]:
        lines.append(f"- `{rendered}`")
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return json_path, md_path


def _write_text_artifact(path: Path, markdown: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(markdown.strip() + "\n", encoding="utf-8")
    return path


def _write_json_artifact(path: Path, payload: dict[str, Any]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return path


def _derived_generation_stage(args: argparse.Namespace, rendered_documents_required: bool) -> str:
    if args.generation_stage:
        return args.generation_stage
    return "internal_best" if rendered_documents_required else "draft_markdown_qa"


def _derived_render_mode(generation_stage: str, rendered_documents_required: bool) -> str:
    if generation_stage == "public_final":
        return "final_public_documents"
    if rendered_documents_required:
        return "internal_pdf"
    return "markdown_first_qa"


def _load_promotion_status(path_value: str | None) -> dict[str, Any] | None:
    if not path_value:
        return None
    path = Path(path_value).expanduser()
    if not path.is_absolute():
        path = ROOT / path
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def _normalize_promotion_status(
    *,
    raw_status: dict[str, Any] | None,
    generation_stage: str,
    render_mode: str,
    final_documents_rendered: bool,
    requested_visibility: str,
    publish_report_exists: bool,
    blocking_issues: list[str],
) -> dict[str, Any]:
    raw_status = raw_status or {}
    status_value = raw_status.get("status") or raw_status.get("promotion_status")
    reviewed_by = raw_status.get("reviewed_by") or raw_status.get("reviewedBy")
    approved_at = raw_status.get("approved_at") or raw_status.get("approvedAt")
    requested_status_visibility = (
        raw_status.get("requested_visibility")
        or raw_status.get("requestedVisibility")
        or requested_visibility
    )
    non_advice_confirmed = bool(raw_status.get("non_advice_confirmed") or raw_status.get("nonAdviceConfirmed"))
    sources_human_verified = bool(raw_status.get("sources_human_verified") or raw_status.get("sourcesHumanVerified"))
    raw_blocking_issues = raw_status.get("blocking_issues") or raw_status.get("blockingIssues") or []
    if not isinstance(raw_blocking_issues, list):
        raw_blocking_issues = [raw_blocking_issues]
    all_blocking_issues = [str(issue) for issue in [*blocking_issues, *raw_blocking_issues] if issue]
    requested_public_ready = bool(raw_status.get("public_ready")) or status_value == "public_ready"
    public_ready = bool(
        raw_status
        and requested_public_ready
        and generation_stage == "public_final"
        and render_mode == "final_public_documents"
        and final_documents_rendered
        and requested_status_visibility == "public"
        and publish_report_exists
        and reviewed_by
        and approved_at
        and non_advice_confirmed
        and sources_human_verified
        and not all_blocking_issues
    )
    reasons = list(raw_status.get("promotion_reasons") or raw_status.get("reasons") or [])
    if not public_ready:
        if generation_stage != "public_final":
            reasons.append("generation_stage_not_public_final")
        if not final_documents_rendered:
            reasons.append("final_documents_not_rendered")
        if not publish_report_exists:
            reasons.append("publish_report_missing")
        if requested_status_visibility != "public":
            reasons.append("public_visibility_not_requested")
        if not reviewed_by:
            reasons.append("human_approval_missing")
        if not approved_at:
            reasons.append("approval_timestamp_missing")
        if not non_advice_confirmed:
            reasons.append("non_advice_confirmation_missing")
        if not sources_human_verified:
            reasons.append("sources_human_verification_missing")
        if not raw_status:
            reasons.append("promotion_status_missing")
        reasons.extend(all_blocking_issues)
    promotion_status = "public_ready" if public_ready else "blocked"
    if not raw_status and generation_stage in {"draft_markdown_qa", "internal_best"}:
        promotion_status = "not_run"
    return {
        "schema_version": 1,
        "promotion_status": promotion_status,
        "public_ready": public_ready,
        "promotion_reasons": sorted(set(str(reason) for reason in reasons if reason)),
        "reviewed_by": reviewed_by,
        "approved_at": approved_at,
        "requested_visibility": requested_status_visibility,
        "non_advice_confirmed": non_advice_confirmed,
        "sources_human_verified": sources_human_verified,
        "blocking_issues": sorted(set(all_blocking_issues)),
        "source_status_path": raw_status.get("source_status_path") or raw_status.get("sourceStatusPath"),
    }


def _lifecycle_review_status(
    *,
    verdict: str,
    generation_stage: str,
    assessment_status: str,
    public_ready: bool,
) -> str:
    if verdict != "pass":
        return "failed"
    if public_ready:
        return "public_ready"
    if assessment_status == "manual_review":
        return "manual_review"
    if generation_stage == "internal_best":
        return "internal_ready"
    if generation_stage == "draft_markdown_qa":
        return "qa_pass"
    return "blocked"


def _visibility_for_lifecycle(
    *,
    generation_stage: str,
    review_status: str,
    public_ready: bool,
) -> str:
    if public_ready:
        return "public"
    if review_status in {"manual_review", "failed", "blocked"}:
        return "hidden"
    if generation_stage == "public_final":
        return "public_candidate"
    return "internal_only"


def _score_bundle(
    *,
    base_score: int | float | None,
    generation_stage: str,
    verdict: str,
    assessment_status: str,
    final_documents_rendered: bool,
    publish_report_exists: bool,
    source_ledger_entries: list[dict[str, Any]],
    research_integrity_verdict: str | None,
    artifact_consistency_status: str,
) -> dict[str, Any]:
    total = int(base_score if isinstance(base_score, (int, float)) else 70)
    publish_score = total
    internal_score = total
    data_score = 80
    if verdict != "pass":
        publish_score -= 30
        internal_score -= 20
    if generation_stage == "draft_markdown_qa":
        publish_score = min(publish_score, 65)
    if not final_documents_rendered:
        publish_score = min(publish_score, 65)
    if not publish_report_exists:
        publish_score = min(publish_score, 75)
    if assessment_status == "manual_review":
        publish_score = min(publish_score, 65)
        internal_score = max(internal_score, 75)
    if artifact_consistency_status != "clean":
        publish_score -= 20
        data_score -= 15
    primary_sources = sum(1 for item in source_ledger_entries if str(item.get("source_type", "")).upper() in {"SEC", "IR"})
    if primary_sources:
        data_score += min(primary_sources * 3, 12)
    else:
        data_score -= 20
    if research_integrity_verdict == "review_required":
        publish_score -= 10
        data_score -= 10
    elif research_integrity_verdict == "fail":
        publish_score -= 25
        data_score -= 25
        internal_score -= 10
    return {
        "total_score_legacy": max(0, min(100, total)),
        "publish_quality_score": max(0, min(100, int(round(publish_score)))),
        "internal_research_quality_score": max(0, min(100, int(round(internal_score)))),
        "data_confidence_score": max(0, min(100, int(round(data_score)))),
    }


def _artifact_consistency_report(
    *,
    generation_stage: str,
    render_mode: str,
    review_status: str,
    publishable: bool,
    public_ready: bool,
    visibility: str,
    artifacts: dict[str, Path],
    promotion_status: dict[str, Any],
    metrics: dict[str, Any],
) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []

    def add(name: str, condition: bool, details: Any) -> None:
        checks.append({"name": name, "status": "pass" if condition else "fail", "details": details})

    add("generation_stage_known", generation_stage in GENERATION_STAGES, generation_stage)
    add("render_mode_known", render_mode in RENDER_MODES, render_mode)
    add("review_status_known", review_status in REVIEW_STATUSES, review_status)
    add("visibility_known", visibility in VISIBILITY_STATES, visibility)
    add("complete_markdown_exists", artifacts["complete_md"].exists(), str(artifacts["complete_md"]))
    add("internal_best_report_exists", artifacts["internal_best_report"].exists(), str(artifacts["internal_best_report"]))
    if generation_stage == "draft_markdown_qa":
        add("markdown_qa_final_documents_not_required", not metrics.get("final_documents_rendered"), metrics.get("final_documents_rendered"))
        add("markdown_qa_public_ready_false", public_ready is False, public_ready)
        add("markdown_qa_not_publishable", publishable is False, publishable)
        add("markdown_qa_visibility_internal_or_hidden", visibility in {"internal_only", "hidden"}, visibility)
        add("markdown_qa_score_scope_markdown", metrics.get("score_scope") == "markdown_qa", metrics.get("score_scope"))
        add("markdown_qa_public_rating_null", metrics.get("public_rating") is None, metrics.get("public_rating"))
        add("markdown_qa_no_publish_report", artifacts.get("publish_report") is None, str(artifacts.get("publish_report")))
    if generation_stage == "internal_best":
        add("internal_best_public_ready_false", public_ready is False, public_ready)
        add("internal_best_visibility_not_public", visibility in {"internal_only", "hidden"}, visibility)
        add("internal_best_report_required", artifacts["internal_best_report"].exists(), str(artifacts["internal_best_report"]))
        add("internal_best_public_rating_null", metrics.get("public_rating") is None, metrics.get("public_rating"))
        add("internal_best_render_backend_recorded", bool(metrics.get("pdf_render_backend")), metrics.get("pdf_render_backend"))
    if generation_stage == "public_final":
        publish_report_path = artifacts.get("publish_report")
        blocking_issues = promotion_status.get("blocking_issues") or []
        add("public_final_pdf_exists", artifacts["complete_pdf"].exists(), str(artifacts["complete_pdf"]))
        add("public_final_docx_exists", artifacts["complete_docx"].exists(), str(artifacts["complete_docx"]))
        add("public_final_publish_report_exists", bool(publish_report_path and publish_report_path.exists()), str(publish_report_path))
        add("public_final_promotion_public_ready", promotion_status.get("public_ready") is True, promotion_status)
        add("public_final_promotion_reviewed_by", bool(promotion_status.get("reviewed_by")), promotion_status.get("reviewed_by"))
        add("public_final_promotion_approved_at", bool(promotion_status.get("approved_at")), promotion_status.get("approved_at"))
        add("public_final_requested_visibility_public", promotion_status.get("requested_visibility") == "public", promotion_status.get("requested_visibility"))
        add("public_final_non_advice_confirmed", promotion_status.get("non_advice_confirmed") is True, promotion_status.get("non_advice_confirmed"))
        add("public_final_sources_human_verified", promotion_status.get("sources_human_verified") is True, promotion_status.get("sources_human_verified"))
        add("public_final_no_blocking_issues", not blocking_issues, blocking_issues)
        add("public_final_publishable_true", publishable is True, publishable)
        add("public_final_visibility_public", visibility == "public", visibility)
        add("public_final_score_scope_public", metrics.get("score_scope") == "public_final", metrics.get("score_scope"))
        add("public_final_render_qa_pass", metrics.get("render_qa_status") == "pass", metrics.get("render_qa"))
        add("public_final_render_backend_pymupdf", metrics.get("pdf_render_backend") == "pymupdf", metrics.get("pdf_render_backend"))
        add("public_final_rendered_page_samples", int(metrics.get("rendered_page_count") or 0) > 0, metrics.get("rendered_page_count"))
    errors = [check for check in checks if check["status"] == "fail"]
    return {
        "schema_version": 1,
        "artifact_consistency_status": "clean" if not errors else "blocked",
        "artifact_consistency_error_count": len(errors),
        "counts": {"artifact_consistency_errors": len(errors)},
        "lane": {
            "generation_stage": generation_stage,
            "render_mode": render_mode,
            "review_status": review_status,
            "publishable": publishable,
            "public_ready": public_ready,
            "visibility": visibility,
        },
        "promotion_status": promotion_status,
        "checks": checks,
    }


def _report_artifacts(
    artifacts: dict[str, Path],
    *,
    final_documents_rendered: bool,
) -> dict[str, str | None]:
    payload: dict[str, str | None] = {}
    for name, path in artifacts.items():
        if name in {"complete_docx", "complete_pdf"} and not final_documents_rendered:
            payload[name] = None
        else:
            payload[name] = str(path)
    return payload


def _raw_room16_report(results: list[dict[str, Any]]) -> str:
    lines = ["# Raw Room 16 Report", ""]
    for result in results:
        ticker = str(result.get("ticker") or "UNKNOWN")
        lines.extend([f"## {ticker}", ""])
        log_file = result.get("log_file")
        state = _load_state(log_file) if log_file and Path(log_file).exists() else {}
        for key in REQUIRED_KEYS:
            lines.extend([f"### {key}", "", str(state.get(key, "")).strip(), ""])
        for key in ["decision", "trader_signal", "rating"]:
            if result.get(key) is not None:
                lines.extend([f"### manifest.{key}", "", str(result.get(key)), ""])
    return "\n".join(lines)


def _first_rating(results: list[dict[str, Any]]) -> str:
    for result in results:
        for key in ["decision", "rating", "final_trade_decision", "trader_signal"]:
            value = str(result.get(key) or "").strip()
            if value:
                return value
    return "Internal Review"


def _internal_rating(assessment: Any, results: list[dict[str, Any]]) -> str:
    if assessment.active:
        return "Preliminary Underweight"
    return _first_rating(results)


def _public_rating(assessment: Any, internal_rating: str) -> str | None:
    return internal_rating if assessment.publishable else None


def _deeptech_internal_best_report(
    *,
    ticker: str,
    assessment: Any,
    metrics: dict[str, Any],
    complete_md_text: str,
) -> str:
    issue_codes = [issue.code for issue in assessment.issues]
    return "\n".join(
        [
            f"# {ticker} Internal Best Report",
            "",
            "## Statusbox",
            "",
            f"- review_status: `{assessment.status}`",
            f"- publishable: `{str(assessment.publishable).lower()}`",
            "- internal_rating: `Preliminary Underweight`",
            f"- external_display_rating: `{assessment.external_display_rating}`",
            "- public_rating: `null`",
            f"- company_archetype: `{assessment.company_archetype.value}`",
            f"- archetype_confidence: `{assessment.archetype_confidence}`",
            f"- triggered_rules: `{', '.join(assessment.archetype_triggered_rules)}`",
            f"- manual_review_reasons: `{', '.join(issue_codes)}`",
            "",
            "## Executive Summary",
            "",
            f"{ticker} is not a normal investment story. It should be treated as a speculative technology option, not a proven compounder. "
            f"Klare Bewertung: {ticker} ist keine normale Investmentstory, sondern eine frühe Deep-Tech-Option mit manueller Prüfpflicht. "
            "No New Buy. Small speculative hold only if already owned. Reduce into strength is rational when position size is too large for the evidence base. "
            "SEC/IR confirmation required before any public or real investment conclusion.",
            "",
            "## Technology Reality Check",
            "",
            "The technology narrative can be interesting, but the report must separate technical milestones from economic proof. "
            "Prototype, quantum, roadmap, defense or research milestones are not the same as scaled commercial demand.",
            "",
            "## Commercial Adoption",
            "",
            "Commercial adoption is treated as limited until revenue scale, repeatability, customer concentration and delivery timing are confirmed through SEC/IR evidence. "
            "Contract wins are proof-of-concept unless they scale revenue.",
            "",
            "## Contract / Order Materiality",
            "",
            "Required before any upgrade: contract value, delivery / revenue timing, contract value vs market cap, contract value vs annual revenue, recurring vs one-off, and commercial vs government/research/prototype classification. "
            "The current guard marks `ORDER_MATERIALITY_MISSING` when this bridge is absent.",
            "",
            "## Financial Reality",
            "",
            "The extreme market-cap-vs-revenue disconnect dominates the investment framing. Extreme Market-Cap-vs-Revenue-Diskrepanz is the first-order risk. "
            "Q1-Umsatzsprung hilft der Story, aber Q1 revenue acceleration is not an operating turnaround. "
            "Revenue growth matters only if it becomes repeatable, margin-bearing commercial revenue.",
            "",
            "## Cash Runway",
            "",
            "Cash runway is a survival factor, not a valuation justification. A cash balance can reduce near-term financing risk, but it does not validate the equity valuation by itself.",
            "",
            "## Dilution / SBC Risk",
            "",
            "SBC and dilution risk must be treated as central to the internal case. If SBC/revenue remains elevated or share count expands, per-share economics can deteriorate even when the technology story improves.",
            "",
            "## Accounting Quality",
            "",
            "GAAP gains from warrant/fair-value effects are not operating profit. "
            "GAAP net income was helped by non-operating fair-value effects and does not indicate an operating turnaround.",
            "",
            "## Valuation Disconnect",
            "",
            "The equity must be valued as an option-like claim until revenue scale and operating leverage are proven. The burden of proof is high because small absolute revenue can create misleading growth percentages.",
            "",
            "## Technical Setup",
            "",
            "Technical analysis is allowed only for timing and risk management. It must not dominate the long-term thesis for an early-commercial speculative deep-tech company.",
            "",
            "## What Would Change the View",
            "",
            "- SEC/IR-confirmed current-period revenue, cash, FCF, SBC and debt figures.",
            "- Evidence that contracts convert into scaled, recurring commercial revenue.",
            "- Operating income improvement that is not driven by warrant or derivative fair-value gains.",
            "- Dilution/SBC moderation and a clear cash runway bridge.",
            "",
            "## Final Internal View",
            "",
            "Preliminary Underweight. This is an internal manual-review note, not a public recommendation. Technology option, not proven compounder.",
            "",
            "## Required Follow-Up",
            "",
            "- Pull SEC filing and company IR for the same current period.",
            "- Rebuild hard metrics only from primary evidence or clearly label vendor/manual fallback.",
            "- Quantify contract/order materiality before relying on any announcement.",
            "- Re-check accounting quality for derivative/warrant fair-value effects.",
            "- Confirm cash runway, SBC and dilution before any real investment decision.",
            "",
            "## Appendix",
            "",
            f"- quality_score: `{metrics.get('quality_score')}`",
            f"- quality_score_caps: `{metrics.get('quality_score_caps')}`",
            f"- source_limitations: `Vendor/SEC/IR limitations remain unresolved where primary current-period evidence is missing.`",
            "",
            "### Source Dossier Reference",
            "",
            complete_md_text[:4000],
        ]
    )


def _generic_internal_best_report(
    *,
    ticker: str,
    assessment: Any,
    metrics: dict[str, Any],
    complete_md_text: str,
    results: list[dict[str, Any]],
) -> str:
    internal_rating = _internal_rating(assessment, results)
    public_rating = _public_rating(assessment, internal_rating)
    return "\n".join(
        [
            f"# {ticker} Internal Best Report",
            "",
            "## Statusbox",
            "",
            f"- review_status: `{assessment.status}`",
            f"- publishable: `{str(assessment.publishable).lower()}`",
            f"- internal_rating: `{internal_rating}`",
            f"- external_display_rating: `{assessment.external_display_rating or internal_rating}`",
            f"- public_rating: `{public_rating if public_rating is not None else 'null'}`",
            f"- company_archetype: `{assessment.company_archetype.value}`",
            "",
            "## Internal Analyst Note",
            "",
            "This internal best report preserves the strongest available Room 16 analysis while keeping publication status separate from internal usefulness. "
            "Any data gaps, source limitations or manual-review reasons remain visible before public release.",
            "",
            "## Public Release Requirements",
            "",
            "- Quality gates must pass.",
            "- Source evidence must be sufficient for hard financial claims.",
            "- No manual-review blocker may remain.",
            "",
            "## Appendix",
            "",
            f"- quality_score: `{metrics.get('quality_score')}`",
            f"- manual_review_reasons: `{metrics.get('manual_review_reasons')}`",
            "",
            complete_md_text,
        ]
    )


def _internal_best_report(
    *,
    tickers: list[str],
    assessment: Any,
    metrics: dict[str, Any],
    complete_md_text: str,
    results: list[dict[str, Any]],
) -> str:
    ticker = tickers[0] if len(tickers) == 1 else "MULTI"
    if assessment.company_archetype.value == "SPECULATIVE_DEEP_TECH_EARLY_COMMERCIAL":
        return _deeptech_internal_best_report(
            ticker=ticker,
            assessment=assessment,
            metrics=metrics,
            complete_md_text=complete_md_text,
        )
    return _generic_internal_best_report(
        ticker=ticker,
        assessment=assessment,
        metrics=metrics,
        complete_md_text=complete_md_text,
        results=results,
    )


def _publish_report_text(complete_md_text: str, tickers: list[str], internal_rating: str) -> str:
    lines = []
    skip_prefixes = ("Run-Verzeichnis:", "> Interner Research-Output", "- Provider:", "- Quick-Modell:", "- Deep-Modell:")
    for line in complete_md_text.splitlines():
        if any(line.strip().startswith(prefix) for prefix in skip_prefixes):
            continue
        if line.strip() in {"## Laufkontext"}:
            continue
        lines.append(line)
    ticker_label = ", ".join(tickers)
    header = [
        f"# Room 16 Research Report - {ticker_label}",
        "",
        f"Public Rating: {internal_rating}",
        "",
        "This report passed the Room 16 publication gates.",
        "",
    ]
    return "\n".join(header + lines)


def _evidence_report_text(
    *,
    tickers: list[str],
    source_ledger_entries: list[dict[str, Any]],
    assessment: Any,
) -> str:
    lines = [
        "# Room 16 Evidence Report",
        "",
        f"Tickers: `{', '.join(tickers)}`",
        f"Review status: `{assessment.status}`",
        f"Publishable: `{str(assessment.publishable).lower()}`",
        "",
        "## Source Ledger",
        "",
    ]
    if not source_ledger_entries:
        lines.append("No source ledger entries available. SEC/IR confirmation required for hard metrics.")
    else:
        lines.extend(["| source_id | source_type | asof | period_type | formula_id |", "| --- | --- | --- | --- | --- |"])
        for entry in source_ledger_entries[:100]:
            lines.append(
                "| {source_id} | {source_type} | {asof} | {period_type} | {formula_id} |".format(
                    source_id=str(entry.get("source_id") or ""),
                    source_type=str(entry.get("source_type") or ""),
                    asof=str(entry.get("asof") or ""),
                    period_type=str(entry.get("period_type") or ""),
                    formula_id=str(entry.get("formula_id") or ""),
                )
            )
    lines.extend(["", "## Guard Issues", ""])
    for issue in assessment.issues:
        lines.append(f"- `{issue.code}`: {issue.message}")
    return "\n".join(lines)


def validate(args: argparse.Namespace) -> dict[str, Any]:
    stamp = args.date or datetime.now().strftime("%Y-%m-%d")
    run_dir = Path(args.run_dir) if args.run_dir else _latest_completed_run()
    manifest = _load_manifest(run_dir)
    results = _filter_results(manifest.get("results", []), args.tickers)
    tickers = [result.get("ticker") for result in results if result.get("ticker")]
    artifact_names = _artifact_names(stamp, tickers)
    reports_dir = Path(args.reports_dir)
    premium_dir = reports_dir / "premium"
    complete_dir = reports_dir / "complete"
    quality_dir = reports_dir / "quality"
    render_dir = quality_dir / "rendered" / f"{stamp}-{run_dir.name}"
    require_premium = bool(args.require_premium)
    rendered_documents_required = not bool(args.allow_missing_rendered_documents)
    generation_stage = _derived_generation_stage(args, rendered_documents_required)
    render_mode = _derived_render_mode(generation_stage, rendered_documents_required)

    premium_docx = (
        _resolve_artifact(
            premium_dir,
            artifact_names["premium_docx"],
            f"*-room16-{_safe_ticker(tickers[0])}-premium-investment-memo.docx" if len(tickers) == 1 else "*-room16-premium-investment-memo.docx",
            args.allow_artifact_fallback,
        )
        if require_premium
        else premium_dir / artifact_names["premium_docx"]
    )
    premium_pdf = (
        _resolve_artifact(
            premium_dir,
            artifact_names["premium_pdf"],
            f"*-room16-{_safe_ticker(tickers[0])}-premium-investment-memo.pdf" if len(tickers) == 1 else "*-room16-premium-investment-memo.pdf",
            args.allow_artifact_fallback,
        )
        if require_premium
        else premium_dir / artifact_names["premium_pdf"]
    )
    complete_md = _resolve_artifact(
        complete_dir,
        artifact_names["complete_md"],
        f"*-room16-{_safe_ticker(tickers[0])}-complete-dossier.md" if len(tickers) == 1 else "*-room16-complete-dossier.md",
        args.allow_artifact_fallback,
    )
    complete_docx = _resolve_artifact(
        complete_dir,
        artifact_names["complete_docx"],
        f"*-room16-{_safe_ticker(tickers[0])}-complete-dossier.docx" if len(tickers) == 1 else "*-room16-complete-dossier.docx",
        args.allow_artifact_fallback,
    )
    complete_pdf = _resolve_artifact(
        complete_dir,
        artifact_names["complete_pdf"],
        f"*-room16-{_safe_ticker(tickers[0])}-complete-dossier.pdf" if len(tickers) == 1 else "*-room16-complete-dossier.pdf",
        args.allow_artifact_fallback,
    )

    checks: list[dict[str, Any]] = []
    metrics: dict[str, Any] = {}

    _check(manifest.get("status") == "completed", "manifest_completed", manifest.get("status"), checks)
    ticker_statuses = [
        {
            "ticker": result.get("ticker"),
            "status": result.get("status"),
            "elapsed_seconds": result.get("elapsed_seconds"),
            "decision": result.get("decision"),
        }
        for result in results
    ]
    _check(bool(tickers), "manifest_has_tickers", tickers, checks)
    _check(all(result.get("status") == "ok" for result in results), "all_tickers_ok", ticker_statuses, checks)

    raw_source_words = 0
    source_ledger_entries: list[dict[str, Any]] = []
    rating_text_parts: list[str] = []
    for result in results:
        ticker = result.get("ticker", "UNKNOWN")
        log_file = result.get("log_file")
        source_ledger_entries.extend(_load_source_ledger(result.get("source_ledger_file")))
        for key in ["final_trade_decision", "trader_investment_decision", "investment_plan", "decision"]:
            value = str(result.get(key, "")).strip()
            if value:
                rating_text_parts.append(value)
        _check(bool(log_file and Path(log_file).exists()), f"{ticker}_log_exists", log_file, checks)
        if not log_file or not Path(log_file).exists():
            continue
        state = _load_state(log_file)
        for key in REQUIRED_KEYS:
            value = str(state.get(key, "")).strip()
            if key in {"trader_investment_decision", "investment_plan", "final_trade_decision"} and value:
                rating_text_parts.append(value)
            raw_source_words += _word_count(value)
            min_chars = MIN_FIELD_CHARS[key]
            _check(
                len(value) >= min_chars,
                f"{ticker}_{key}_has_content",
                {"chars": len(value), "min_chars": min_chars},
                checks,
            )

    artifact_paths = {
        "complete_md": complete_md,
        "complete_docx": complete_docx,
        "complete_pdf": complete_pdf,
    }
    if require_premium:
        artifact_paths.update({"premium_docx": premium_docx, "premium_pdf": premium_pdf})
    _check(complete_md.exists(), "complete_md_exists", str(complete_md), checks)
    if rendered_documents_required:
        for name, path in artifact_paths.items():
            if name == "complete_md":
                continue
            _check(path.exists(), f"{name}_exists", str(path), checks)
    else:
        _check(
            True,
            "rendered_documents_deferred",
            {
                "mode": "markdown_first_qa",
                "note": "DOCX/PDF are intentionally not produced until final publish/send render.",
            },
            checks,
        )

    complete_md_text = complete_md.read_text(encoding="utf-8") if complete_md.exists() else ""
    complete_docx_text = _extract_docx(complete_docx) if rendered_documents_required and complete_docx.exists() else ""
    complete_pdf_text, complete_pdf_pages = (
        _extract_pdf(complete_pdf) if rendered_documents_required and complete_pdf.exists() else ("", 0)
    )
    premium_docx_text = _extract_docx(premium_docx) if rendered_documents_required and require_premium and premium_docx.exists() else ""
    premium_pdf_text, premium_pdf_pages = (
        _extract_pdf(premium_pdf) if rendered_documents_required and require_premium and premium_pdf.exists() else ("", 0)
    )
    pdf_text_backend = _pdf_text_backend()
    pdf_render_backend = "pymupdf" if _import_fitz() is not None else "unavailable"

    complete_md_words = _word_count(complete_md_text)
    complete_docx_words = _word_count(complete_docx_text)
    complete_pdf_words = _word_count(complete_pdf_text)
    premium_docx_words = _word_count(premium_docx_text)
    premium_pdf_words = _word_count(premium_pdf_text)
    ticker_count = max(len(tickers), 1)

    metrics.update(
        {
            "ticker_count": ticker_count,
            "premium_required": require_premium,
            "generation_stage": generation_stage,
            "render_mode": render_mode,
            "final_documents_rendered": rendered_documents_required,
            "public_ready": False,
            "visibility": "internal_only" if generation_stage == "draft_markdown_qa" else "internal_only",
            "score_scope": (
                "markdown_qa"
                if generation_stage == "draft_markdown_qa"
                else "public_final"
                if generation_stage == "public_final"
                else "internal_best"
            ),
            "publish_gate_verdict": "not_run",
            "promotion_gate_verdict": "not_run",
            "raw_source_words": raw_source_words,
            "complete_md_words": complete_md_words,
            "complete_docx_words": complete_docx_words,
            "complete_pdf_words": complete_pdf_words,
            "complete_pdf_pages": complete_pdf_pages,
            "pdf_text_backend": pdf_text_backend,
            "pdf_render_backend": pdf_render_backend,
            "batch_id": args.batch_id or None,
        }
    )
    if require_premium:
        metrics.update(
            {
                "premium_docx_words": premium_docx_words,
                "premium_pdf_words": premium_pdf_words,
                "premium_pdf_pages": premium_pdf_pages,
            }
        )
    _check(generation_stage in GENERATION_STAGES, "generation_stage_valid", generation_stage, checks)
    _check(render_mode in RENDER_MODES, "render_mode_valid", render_mode, checks)
    _check(
        generation_stage != "public_final" or rendered_documents_required,
        "public_final_requires_rendered_documents",
        {"generation_stage": generation_stage, "final_documents_rendered": rendered_documents_required},
        checks,
    )

    rendered_pages: list[str] = []
    if rendered_documents_required and require_premium and premium_pdf.exists():
        rendered_pages.extend(_render_pdf(premium_pdf, render_dir, "premium", None))
    if rendered_documents_required and complete_pdf.exists():
        sample_pages = sorted(set([0, 1, 2, complete_pdf_pages // 2, max(0, complete_pdf_pages - 1)]))
        rendered_pages.extend(_render_pdf(complete_pdf, render_dir, "complete", sample_pages))
    render_qa = validate_render_backend_for_lifecycle(
        generation_stage=generation_stage,
        render_mode=render_mode,
        render_backend=pdf_render_backend,
        text_backend=pdf_text_backend,
        rendered_pages=rendered_pages,
        fitz_available=_import_fitz() is not None,
        allow_missing_rendered_documents=bool(args.allow_missing_rendered_documents),
    )
    metrics["rendered_page_count"] = len(rendered_pages)
    metrics["render_qa_status"] = render_qa.status
    metrics["render_qa_blockers"] = list(render_qa.blockers)
    metrics["render_qa_warnings"] = list(render_qa.warnings)
    metrics["render_qa"] = render_qa.to_dict()
    for render_check in render_qa.checks:
        checks.append(
            {
                "name": f"render_qa_{render_check['name']}",
                "status": render_check["status"],
                "details": render_check["details"],
            }
        )
    if render_qa.warnings:
        _check(
            True,
            "render_qa_warnings_recorded",
            {"warnings": list(render_qa.warnings), "render_backend": pdf_render_backend},
            checks,
        )

    expected_complete_min = 20000 if ticker_count >= 4 else 4500 * ticker_count
    min_complete_pages = 35 if ticker_count >= 4 else max(8, 8 * ticker_count)
    max_complete_pages = 120 if ticker_count >= 4 else max(30, 30 * ticker_count)
    min_premium_pages = 5 if ticker_count >= 4 else max(3, 2 + ticker_count)
    max_premium_pages = 14 if ticker_count >= 4 else max(6, 4 + ticker_count * 2)
    _check(
        complete_md_words >= expected_complete_min,
        "complete_markdown_word_count",
        {"words": complete_md_words, "min_words": expected_complete_min},
        checks,
    )
    _check(
        raw_source_words == 0 or complete_md_words >= raw_source_words * 0.70,
        "complete_markdown_source_coverage",
        {"complete_words": complete_md_words, "raw_source_words": raw_source_words, "min_ratio": 0.70},
        checks,
    )
    if rendered_documents_required:
        _check(
            complete_md_words == 0 or complete_docx_words >= complete_md_words * 0.75,
            "complete_docx_word_ratio",
            {"docx_words": complete_docx_words, "md_words": complete_md_words, "min_ratio": 0.75},
            checks,
        )
        _check(
            complete_md_words == 0 or complete_pdf_words >= complete_md_words * 0.75,
            "complete_pdf_word_ratio",
            {"pdf_words": complete_pdf_words, "md_words": complete_md_words, "min_ratio": 0.75},
            checks,
        )
        _check(
            min_complete_pages <= complete_pdf_pages <= max_complete_pages,
            "complete_pdf_page_range",
            {
                "pages": complete_pdf_pages,
                "allowed": f"{min_complete_pages}-{max_complete_pages}",
                "ticker_count": ticker_count,
            },
            checks,
        )
        if require_premium:
            _check(
                min_premium_pages <= premium_pdf_pages <= max_premium_pages,
                "premium_pdf_page_range",
                {
                    "pages": premium_pdf_pages,
                    "allowed": f"{min_premium_pages}-{max_premium_pages}",
                    "ticker_count": ticker_count,
                },
                checks,
            )

    user_texts = {"complete_md": complete_md_text}
    if rendered_documents_required:
        user_texts["complete_docx"] = complete_docx_text
    if rendered_documents_required:
        user_texts["complete_pdf"] = complete_pdf_text
    if require_premium and (rendered_documents_required or premium_docx.exists() or premium_pdf.exists()):
        user_texts.update({"premium_docx": premium_docx_text, "premium_pdf": premium_pdf_text})
    for name, text in user_texts.items():
        _check(not _scan_terms(text, FORBIDDEN_VISIBLE_TERMS), f"{name}_no_forbidden_labels", _scan_terms(text, FORBIDDEN_VISIBLE_TERMS), checks)
        reasoning_leaks = find_visible_reasoning_leaks(text)
        _check(
            not reasoning_leaks,
            f"{name}_no_visible_reasoning_leaks",
            reasoning_leaks,
            checks,
        )
        _check(
            not _scan_patterns(text, GERMAN_ASCII_UMLAUT_PATTERNS),
            f"{name}_uses_real_german_umlauts",
            _scan_patterns(text, GERMAN_ASCII_UMLAUT_PATTERNS),
            checks,
        )
        if name != "complete_md":
            _check(not _scan_terms(text, VISIBLE_MARKDOWN_TOKENS), f"{name}_no_markdown_tokens", _scan_terms(text, VISIBLE_MARKDOWN_TOKENS), checks)
        _check(not _scan_terms(text, BROKEN_GLYPH_TOKENS), f"{name}_no_broken_glyphs", _scan_terms(text, BROKEN_GLYPH_TOKENS), checks)
        _check(
            not _scan_terms(text, UNSUPPORTED_RENDER_TOKENS),
            f"{name}_no_unsupported_render_glyphs",
            _scan_terms(text, UNSUPPORTED_RENDER_TOKENS),
            checks,
        )
        missing_tickers = [ticker for ticker in tickers if ticker not in text]
        _check(not missing_tickers, f"{name}_contains_all_tickers", missing_tickers, checks)

    research_integrity_text = "\n".join(text for text in [complete_md_text, complete_docx_text, complete_pdf_text] if text)
    research_integrity_findings = _research_integrity_findings(research_integrity_text, tickers, manifest)
    institutional_quality_findings = _institutional_quality_findings(research_integrity_text)
    speculative_deep_tech_assessment = assess_speculative_deep_tech_profile(
        research_integrity_text,
        source_ledger_entries=source_ledger_entries,
        rating_text="\n".join(rating_text_parts),
    )
    deep_tech_findings = [
        {
            "severity": "high",
            "type": issue.code,
            "message": issue.message,
            "details": issue.details,
        }
        for issue in speculative_deep_tech_assessment.issues
    ]
    institutional_quality_findings.extend(deep_tech_findings)
    critical_research_findings = [
        finding for finding in research_integrity_findings if finding.get("severity") == "critical"
    ]
    critical_institutional_findings = [
        finding for finding in institutional_quality_findings if finding.get("severity") == "critical"
    ]
    strict_institutional_findings = [
        finding for finding in institutional_quality_findings if finding.get("severity") in {"critical", "high"}
    ]
    strict_research_findings = [
        finding for finding in research_integrity_findings if finding.get("type") in STRICT_SOURCE_FINDING_TYPES
    ]
    institutional_regression_result = run_institutional_regression_suite()
    metrics["research_integrity_verdict"] = (
        "fail"
        if critical_research_findings
        or critical_institutional_findings
        or institutional_regression_result.blocked
        or (args.strict_research_integrity and (strict_research_findings or strict_institutional_findings))
        else "review_required"
        if strict_research_findings or strict_institutional_findings
        else "pass"
    )
    metrics["research_integrity_findings"] = research_integrity_findings
    metrics["institutional_quality_findings"] = institutional_quality_findings
    metrics["institutional_regression_suite"] = {
        "blocked": institutional_regression_result.blocked,
        "issues": [issue.__dict__ for issue in institutional_regression_result.issues],
    }
    metrics["status"] = speculative_deep_tech_assessment.status
    metrics["analysis_publishable"] = speculative_deep_tech_assessment.publishable
    metrics["publishable"] = False
    metrics["external_display_rating"] = speculative_deep_tech_assessment.external_display_rating
    internal_rating = _internal_rating(speculative_deep_tech_assessment, results)
    public_rating = None
    metrics["internal_rating"] = internal_rating
    metrics["public_rating"] = public_rating
    metrics["analysis_review_status"] = speculative_deep_tech_assessment.status
    metrics["review_status"] = "manual_review" if speculative_deep_tech_assessment.status == "manual_review" else "blocked"
    metrics["risk_profiles"] = [SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE] if speculative_deep_tech_assessment.active else []
    metrics["company_archetype"] = speculative_deep_tech_assessment.company_archetype.value
    metrics["archetype_confidence"] = speculative_deep_tech_assessment.archetype_confidence
    metrics["archetype_triggered_rules"] = speculative_deep_tech_assessment.archetype_triggered_rules
    metrics["manual_review_reasons"] = [issue.code for issue in speculative_deep_tech_assessment.issues]
    metrics["quality_score"] = speculative_deep_tech_assessment.quality_score
    metrics["quality_score_caps"] = speculative_deep_tech_assessment.quality_score_caps
    metrics["speculative_deep_tech_assessment"] = speculative_deep_tech_assessment.to_dict()
    metrics.update(speculative_deep_tech_assessment.counts)

    generated_dir = reports_dir / "generated"
    raw_report = _write_text_artifact(generated_dir / "raw_room16_report.md", _raw_room16_report(results))
    internal_best_report = _write_text_artifact(
        generated_dir / "internal_best_report.md",
        _internal_best_report(
            tickers=tickers,
            assessment=speculative_deep_tech_assessment,
            metrics=metrics,
            complete_md_text=complete_md_text,
            results=results,
        ),
    )
    evidence_report = _write_text_artifact(
        generated_dir / "evidence_report.md",
        _evidence_report_text(
            tickers=tickers,
            source_ledger_entries=source_ledger_entries,
            assessment=speculative_deep_tech_assessment,
        ),
    )
    quality_report_md = quality_dir / f"{stamp}-room16-quality-report.md"
    quality_report_json = quality_dir / f"{stamp}-room16-quality-report.json"
    dashboard_status = reports_dir / "dashboard_status.json"
    artifact_paths.update(
        {
            "raw_report": raw_report,
            "raw_room16_report": raw_report,
            "internal_best_report": internal_best_report,
            "quality_report": quality_report_md,
            "quality_report_json": quality_report_json,
            "evidence_report": evidence_report,
            "dashboard_status": dashboard_status,
        }
    )
    if generation_stage != "draft_markdown_qa" and speculative_deep_tech_assessment.publishable:
        publish_report = _write_text_artifact(
            generated_dir / "publish_report.md",
            _publish_report_text(complete_md_text, tickers, internal_rating),
        )
        artifact_paths["publish_report"] = publish_report
    promotion_blocking_issues: list[str] = []
    if speculative_deep_tech_assessment.status == "manual_review":
        promotion_blocking_issues.append("manual_review_required")
    if metrics["research_integrity_verdict"] != "pass":
        promotion_blocking_issues.append(f"research_integrity_{metrics['research_integrity_verdict']}")
    if generation_stage == "public_final":
        promotion_blocking_issues.extend(render_qa.blockers)
    promotion_status = _normalize_promotion_status(
        raw_status=_load_promotion_status(args.promotion_status),
        generation_stage=generation_stage,
        render_mode=render_mode,
        final_documents_rendered=rendered_documents_required,
        requested_visibility=args.requested_visibility,
        publish_report_exists=bool(artifact_paths.get("publish_report") and artifact_paths["publish_report"].exists()),
        blocking_issues=promotion_blocking_issues,
    )
    public_ready = promotion_status["public_ready"]
    publishable = public_ready
    public_rating = internal_rating if public_ready else None
    metrics["publishable"] = publishable
    metrics["public_ready"] = public_ready
    metrics["public_rating"] = public_rating
    metrics["score_scope"] = (
        "markdown_qa"
        if generation_stage == "draft_markdown_qa"
        else "public_final"
        if generation_stage == "public_final"
        else "internal_best"
    )
    metrics["publish_gate_verdict"] = (
        "public_ready"
        if public_ready
        else "not_run"
        if promotion_status["promotion_status"] == "not_run"
        else "blocked_by_promotion_gate"
    )
    metrics["promotion_gate_verdict"] = promotion_status["promotion_status"]
    metrics["analysis_publishable_before_lifecycle_gate"] = speculative_deep_tech_assessment.publishable
    assessment_payload = speculative_deep_tech_assessment.to_dict()
    assessment_payload["analysis_publishable_before_lifecycle_gate"] = speculative_deep_tech_assessment.publishable
    assessment_payload["publishable"] = publishable
    if generation_stage == "draft_markdown_qa":
        assessment_payload["release_note"] = "Lifecycle gate overrides analysis-level pass in markdown_first_qa."
    metrics["speculative_deep_tech_assessment"] = assessment_payload
    promotion_status_path = _write_json_artifact(generated_dir / "promotion_status.json", promotion_status)
    artifact_paths["promotion_status"] = promotion_status_path
    _check(
        True,
        "speculative_deep_tech_profile_recorded",
        {
            "active": speculative_deep_tech_assessment.active,
            "status": speculative_deep_tech_assessment.status,
            "analysis_publishable_before_lifecycle_gate": speculative_deep_tech_assessment.publishable,
            "publishable": publishable,
            "external_display_rating": speculative_deep_tech_assessment.external_display_rating,
            "issue_codes": [issue.code for issue in speculative_deep_tech_assessment.issues],
            "release_note": "Not public-ready in markdown_first_qa." if generation_stage == "draft_markdown_qa" else None,
        },
        checks,
    )
    if speculative_deep_tech_assessment.status == "manual_review":
        _check(
            bool(speculative_deep_tech_assessment.external_display_rating)
            and not speculative_deep_tech_assessment.publishable,
            "manual_review_external_display_locked",
            {
                "external_display_rating": speculative_deep_tech_assessment.external_display_rating,
                "publishable": speculative_deep_tech_assessment.publishable,
            },
            checks,
        )
        _check(
            internal_best_report.exists() and not artifact_paths.get("publish_report"),
            "manual_review_has_internal_best_without_publish_report",
            {
                "internal_best_report": str(internal_best_report),
                "publish_report": str(artifact_paths.get("publish_report")) if artifact_paths.get("publish_report") else None,
            },
            checks,
        )
    else:
        _check(
            internal_best_report.exists(),
            "publishable_has_internal_best_report",
            str(internal_best_report),
            checks,
        )
    preliminary_review_status = _lifecycle_review_status(
        verdict="pass",
        generation_stage=generation_stage,
        assessment_status=speculative_deep_tech_assessment.status,
        public_ready=public_ready,
    )
    preliminary_visibility = _visibility_for_lifecycle(
        generation_stage=generation_stage,
        review_status=preliminary_review_status,
        public_ready=public_ready,
    )
    metrics["review_status"] = preliminary_review_status
    metrics["visibility"] = preliminary_visibility
    artifact_consistency = _artifact_consistency_report(
        generation_stage=generation_stage,
        render_mode=render_mode,
        review_status=preliminary_review_status,
        publishable=publishable,
        public_ready=public_ready,
        visibility=preliminary_visibility,
        artifacts=artifact_paths,
        promotion_status=promotion_status,
        metrics=metrics,
    )
    artifact_consistency_report = _write_json_artifact(
        generated_dir / "artifact_consistency_report.json",
        artifact_consistency,
    )
    artifact_paths["artifact_consistency_report"] = artifact_consistency_report
    metrics["artifact_consistency_status"] = artifact_consistency["artifact_consistency_status"]
    metrics["artifact_consistency_error_count"] = artifact_consistency["artifact_consistency_error_count"]
    metrics.update(artifact_consistency["counts"])
    _check(
        artifact_consistency["artifact_consistency_status"] == "clean",
        "artifact_consistency_lane_clean",
        artifact_consistency,
        checks,
    )
    _check(
        not critical_research_findings,
        "research_integrity_no_critical_contradictions",
        critical_research_findings,
        checks,
    )
    _check(
        not critical_institutional_findings,
        "institutional_quality_no_critical_blockers",
        critical_institutional_findings,
        checks,
    )
    _check(
        not institutional_regression_result.blocked,
        "institutional_regression_suite_passes",
        metrics["institutional_regression_suite"],
        checks,
    )
    if args.strict_research_integrity:
        _check(
            not (strict_research_findings or strict_institutional_findings),
            "research_integrity_strict_source_ledger_ready",
            {
                "research_findings": strict_research_findings,
                "institutional_findings": strict_institutional_findings,
            },
            checks,
        )
    else:
        _check(
            True,
            "research_integrity_source_ledger_review_recorded",
            {
                "strict_ready": not (strict_research_findings or strict_institutional_findings),
                "findings": strict_research_findings,
                "institutional_findings": strict_institutional_findings,
                "note": "Use --strict-research-integrity for publication/client-grade reports.",
            },
            checks,
        )

    if require_premium and rendered_documents_required:
        premium_combined_text = f"{premium_docx_text}\n{premium_pdf_text}"
        expected_count_label = _company_count_label(ticker_count)
        known_count_labels = ["Ein Unternehmen", "2 Unternehmen", "3 Unternehmen", "4 Unternehmen", "Vier Unternehmen"]
        wrong_count_labels = [
            label for label in known_count_labels if label != expected_count_label and label in premium_combined_text
        ]
        _check(
            expected_count_label in premium_combined_text,
            "premium_company_count_label",
            {"expected": expected_count_label, "ticker_count": ticker_count},
            checks,
        )
        _check(
            not wrong_count_labels,
            "premium_no_wrong_company_count_label",
            {"wrong_labels": wrong_count_labels, "expected": expected_count_label},
            checks,
        )

    verdict = "pass" if all(check["status"] == "pass" for check in checks) else "fail"
    final_review_status = _lifecycle_review_status(
        verdict=verdict,
        generation_stage=generation_stage,
        assessment_status=speculative_deep_tech_assessment.status,
        public_ready=public_ready,
    )
    final_visibility = _visibility_for_lifecycle(
        generation_stage=generation_stage,
        review_status=final_review_status,
        public_ready=public_ready,
    )
    score_bundle = _score_bundle(
        base_score=speculative_deep_tech_assessment.quality_score,
        generation_stage=generation_stage,
        verdict=verdict,
        assessment_status=speculative_deep_tech_assessment.status,
        final_documents_rendered=rendered_documents_required,
        publish_report_exists=bool(artifact_paths.get("publish_report") and artifact_paths["publish_report"].exists()),
        source_ledger_entries=source_ledger_entries,
        research_integrity_verdict=metrics.get("research_integrity_verdict"),
        artifact_consistency_status=metrics.get("artifact_consistency_status", "blocked"),
    )
    metrics.update(score_bundle)
    metrics["quality_verdict"] = verdict
    metrics["review_status"] = final_review_status
    metrics["visibility"] = final_visibility
    metrics["publishable"] = publishable
    metrics["public_ready"] = public_ready
    dashboard_artifacts = _report_artifacts(artifact_paths, final_documents_rendered=rendered_documents_required)
    dashboard_payload = {
        "batch_id": args.batch_id or Path(str(run_dir)).name,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "generation_stage": generation_stage,
        "render_mode": render_mode,
        "review_status": final_review_status,
        "publishable": publishable,
        "public_ready": public_ready,
        "visibility": final_visibility,
        "score_scope": metrics["score_scope"],
        "publish_gate_verdict": metrics["publish_gate_verdict"],
        "promotion_gate_verdict": metrics["promotion_gate_verdict"],
        "items": [
            {
                "ticker": ticker,
                "generation_stage": generation_stage,
                "render_mode": render_mode,
                "review_status": final_review_status,
                "quality_verdict": metrics["quality_verdict"],
                "publishable": publishable,
                "public_ready": public_ready,
                "final_documents_rendered": rendered_documents_required,
                "visibility": final_visibility,
                "publish_quality_score": metrics["publish_quality_score"],
                "internal_research_quality_score": metrics["internal_research_quality_score"],
                "data_confidence_score": metrics["data_confidence_score"],
                "total_score_legacy": metrics["total_score_legacy"],
                "score_scope": metrics["score_scope"],
                "publish_gate_verdict": metrics["publish_gate_verdict"],
                "promotion_gate_verdict": metrics["promotion_gate_verdict"],
                "internal_rating": internal_rating,
                "external_display_rating": speculative_deep_tech_assessment.external_display_rating,
                "public_rating": public_rating,
                "company_archetype": speculative_deep_tech_assessment.company_archetype.value,
                "archetype_confidence": speculative_deep_tech_assessment.archetype_confidence,
                "archetype_triggered_rules": speculative_deep_tech_assessment.archetype_triggered_rules,
                "artifacts": {
                    "raw_report": dashboard_artifacts.get("raw_report"),
                    "internal_best_report": dashboard_artifacts.get("internal_best_report"),
                    "publish_report": dashboard_artifacts.get("publish_report"),
                    "quality_report": dashboard_artifacts.get("quality_report"),
                    "evidence_report": dashboard_artifacts.get("evidence_report"),
                    "promotion_status": dashboard_artifacts.get("promotion_status"),
                    "artifact_consistency_report": dashboard_artifacts.get("artifact_consistency_report"),
                },
            }
            for ticker in tickers
        ],
    }
    _write_text_artifact(dashboard_status, json.dumps(dashboard_payload, indent=2, ensure_ascii=False))
    return {
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "run_dir": str(run_dir),
        "date": stamp,
        "verdict": verdict,
        "generation_stage": generation_stage,
        "review_status": final_review_status,
        "render_mode": render_mode,
        "publishable": publishable,
        "public_ready": public_ready,
        "visibility": final_visibility,
        "score_scope": metrics["score_scope"],
        "quality_verdict": metrics["quality_verdict"],
        "publish_gate_verdict": metrics["publish_gate_verdict"],
        "promotion_gate_verdict": metrics["promotion_gate_verdict"],
        "artifacts": _report_artifacts(artifact_paths, final_documents_rendered=rendered_documents_required),
        "metrics": metrics,
        "checks": checks,
        "rendered_pages": rendered_pages,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", default=None)
    parser.add_argument("--reports-dir", default=str(ROOT / "reports" / "room16"))
    parser.add_argument("--date", default=datetime.now().strftime("%Y-%m-%d"))
    parser.add_argument("--tickers", nargs="+", default=None, help="Optional ticker filter for one-company QA.")
    parser.add_argument("--batch-id", default="", help="Optional regression/check identifier stored in the quality metrics.")
    parser.add_argument(
        "--generation-stage",
        choices=sorted(GENERATION_STAGES),
        default=None,
        help="Lifecycle lane for this validation. Default is draft_markdown_qa for markdown-first QA and internal_best for rendered internal documents.",
    )
    parser.add_argument(
        "--promotion-status",
        default=None,
        help="Optional promotion_status.json or promotion contract output. Public-ready is only accepted when this file approves public_final.",
    )
    parser.add_argument(
        "--requested-visibility",
        choices=sorted(VISIBILITY_STATES),
        default="internal_only",
        help="Requested lifecycle visibility. Public requires a passing promotion status and final documents.",
    )
    parser.add_argument("--require-premium", action="store_true", help="Require and validate premium overview artifacts.")
    parser.add_argument(
        "--allow-artifact-fallback",
        action="store_true",
        help="Allow glob fallback when exact date/ticker artifacts are missing. Default is strict to prevent stale PDFs.",
    )
    parser.add_argument(
        "--strict-research-integrity",
        action="store_true",
        help="Fail if source-ledger/period/source-priority metadata is missing. Use for publication/client-grade reports.",
    )
    parser.add_argument(
        "--allow-missing-pdf-renderer",
        action="store_true",
        help="Debug escape hatch only: do not fail when PyMuPDF/fitz is unavailable for visual PDF rendering.",
    )
    parser.add_argument(
        "--allow-missing-rendered-documents",
        action="store_true",
        help="First-pass QA mode: validate markdown and defer DOCX/PDF/page-render checks until final publish/send render.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    report = validate(args)
    json_path, md_path = _write_reports(report, Path(args.reports_dir) / "quality", report["date"])
    print(json_path)
    print(md_path)
    if report["verdict"] != "pass":
        failed = [check["name"] for check in report["checks"] if check["status"] == "fail"]
        print("FAILED:", ", ".join(failed), file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
