#!/usr/bin/env python3
"""Smoke-test LLM capabilities required by the Room 16 TradingAgents flow."""

from __future__ import annotations

import argparse
import json
import multiprocessing as mp
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Literal

from langchain_core.tools import tool
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tradingagents.llm_clients import create_llm_client


DEFAULT_MODELS = (
    "qwen2.5-coder:7b",
    "kimi-k2.6:cloud",
    "glm-5.1:cloud",
    "deepseek-v4-pro:cloud",
)


class SmokeDecision(BaseModel):
    action: Literal["Buy", "Hold", "Sell"] = Field(
        description="One of Buy, Hold, or Sell."
    )
    reason: str = Field(description="Short explanation.")


@tool
def room16_lookup(symbol: str) -> str:
    """Return a fixed Room 16 marker for the supplied ticker symbol."""
    return f"ROOM16_TOOL_OK:{symbol}"


def _make_llm(
    provider: str,
    model: str,
    base_url: str | None,
    request_timeout: float,
    max_retries: int,
):
    return create_llm_client(
        provider=provider,
        model=model,
        base_url=base_url,
        timeout=request_timeout,
        max_retries=max_retries,
    ).get_llm()


def _worker(
    queue: mp.Queue,
    provider: str,
    model: str,
    base_url: str | None,
    mode: str,
    request_timeout: float,
    max_retries: int,
) -> None:
    started = time.monotonic()
    try:
        llm = _make_llm(provider, model, base_url, request_timeout, max_retries)
        if mode == "plain":
            response = llm.invoke("Reply with exactly: ROOM16_OK")
            content = getattr(response, "content", "")
            ok = "ROOM16_OK" in str(content)
            payload: dict[str, Any] = {"ok": ok, "content": str(content)[:500]}
        elif mode == "tool":
            response = llm.bind_tools([room16_lookup]).invoke(
                "Call the room16_lookup tool once with symbol PLTR. "
                "Do not answer directly."
            )
            tool_calls = getattr(response, "tool_calls", None) or []
            payload = {
                "ok": bool(tool_calls),
                "tool_calls": tool_calls,
                "content": str(getattr(response, "content", ""))[:500],
            }
        elif mode == "structured":
            structured = llm.with_structured_output(SmokeDecision)
            response = structured.invoke(
                "Return action Hold with reason 'Room 16 smoke test'."
            )
            if isinstance(response, SmokeDecision):
                data = response.model_dump()
            elif hasattr(response, "dict"):
                data = response.dict()
            else:
                data = response
            payload = {
                "ok": isinstance(data, dict) and data.get("action") == "Hold",
                "structured": data,
            }
        else:
            raise ValueError(f"unknown mode: {mode}")
        payload["elapsed_seconds"] = round(time.monotonic() - started, 2)
        queue.put(payload)
    except Exception as exc:  # pragma: no cover - smoke diagnostic path
        queue.put(
            {
                "ok": False,
                "error": f"{type(exc).__name__}: {exc}",
                "elapsed_seconds": round(time.monotonic() - started, 2),
            }
        )


def _run_one(
    provider: str,
    model: str,
    base_url: str | None,
    mode: str,
    process_timeout: float,
    request_timeout: float,
    max_retries: int,
) -> dict[str, Any]:
    ctx = mp.get_context("spawn")
    queue: mp.Queue = ctx.Queue()
    process = ctx.Process(
        target=_worker,
        args=(queue, provider, model, base_url, mode, request_timeout, max_retries),
    )
    started = time.monotonic()
    process.start()
    process.join(process_timeout)
    elapsed = round(time.monotonic() - started, 2)
    if process.is_alive():
        process.terminate()
        process.join(5)
        return {
            "ok": False,
            "error": f"process timeout after {process_timeout}s",
            "elapsed_seconds": elapsed,
        }
    if process.exitcode != 0:
        return {
            "ok": False,
            "error": f"process exited with code {process.exitcode}",
            "elapsed_seconds": elapsed,
        }
    if queue.empty():
        return {"ok": False, "error": "no result returned", "elapsed_seconds": elapsed}
    result = queue.get()
    result.setdefault("elapsed_seconds", elapsed)
    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--provider", default="ollama")
    parser.add_argument("--models", nargs="+", default=list(DEFAULT_MODELS))
    parser.add_argument("--base-url", default=None)
    parser.add_argument("--process-timeout", type=float, default=90.0)
    parser.add_argument("--request-timeout", type=float, default=60.0)
    parser.add_argument("--max-retries", type=int, default=0)
    parser.add_argument(
        "--modes",
        nargs="+",
        choices=["plain", "tool", "structured"],
        default=["plain", "tool", "structured"],
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    report: dict[str, Any] = {
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "provider": args.provider,
        "base_url": args.base_url,
        "process_timeout": args.process_timeout,
        "request_timeout": args.request_timeout,
        "max_retries": args.max_retries,
        "models": {},
    }

    for model in args.models:
        print(f"\n== {model} ==")
        report["models"][model] = {}
        for mode in args.modes:
            print(f"  {mode}...", flush=True)
            result = _run_one(
                provider=args.provider,
                model=model,
                base_url=args.base_url,
                mode=mode,
                process_timeout=args.process_timeout,
                request_timeout=args.request_timeout,
                max_retries=args.max_retries,
            )
            report["models"][model][mode] = result
            status = "ok" if result.get("ok") else "fail"
            detail = result.get("error") or result.get("content") or result.get("structured")
            print(f"  {mode}: {status} ({result.get('elapsed_seconds')}s) {detail}")

    out_dir = ROOT / ".runtime" / "room16-smokes"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"model-smoke-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
    out_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"\nWrote {out_path}")


if __name__ == "__main__":
    main()
