#!/usr/bin/env python3
"""Render an evidence report statusbox from QualityDecision."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from room16.core.report_view_model import build_quality_decision_for_report_view, render_evidence_report


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--quality-report", required=True)
    parser.add_argument("--existing-markdown")
    parser.add_argument("--output")
    args = parser.parse_args()

    quality = json.loads(Path(args.quality_report).read_text(encoding="utf-8"))
    existing = Path(args.existing_markdown).read_text(encoding="utf-8") if args.existing_markdown else ""
    decision = build_quality_decision_for_report_view(quality)
    rendered = render_evidence_report(decision, existing_markdown=existing)
    if args.output:
        Path(args.output).write_text(rendered, encoding="utf-8")
    else:
        print(rendered, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
