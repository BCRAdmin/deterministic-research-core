#!/usr/bin/env python3
"""Mirror final Room 16 PDFs into the human reading shelf."""

from __future__ import annotations

import argparse
import re
import shutil
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SHELF_DIR = Path.home() / "Documents" / "DreamFactory" / "Room16" / "Reports"

COMPANY_NAME_OVERRIDES = {
    "AAPL": "Apple",
    "ANET": "Arista Networks",
    "AMZN": "Amazon",
    "BE": "Bloom Energy",
    "CEG": "Constellation Energy",
    "GOOG": "Alphabet",
    "GOOGL": "Alphabet",
    "META": "Meta Platforms",
    "MU": "Micron Technology",
    "MSFT": "Microsoft",
    "NVDA": "NVIDIA",
    "ORCL": "Oracle",
    "PACB": "Pacific Biosciences",
    "PLTR": "Palantir",
    "RHM_DE": "Rheinmetall",
    "TSLA": "Tesla",
    "VRT": "Vertiv",
}


def _safe_ticker(ticker: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", ticker).strip("_").upper()


def _safe_filename(value: str) -> str:
    cleaned = re.sub(r"[/:*?\"<>|]+", "-", value)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned or "Room 16 Report"


def _extract_model_label(markdown_path: Path | None) -> str | None:
    if not markdown_path or not markdown_path.exists():
        return None
    text = markdown_path.read_text(encoding="utf-8", errors="ignore")[:20000]
    match = re.search(r"^- Deep-Modell:\s*`?([^`\n]+)`?", text, flags=re.MULTILINE)
    model = match.group(1).strip() if match else ""
    normalized = model.lower()
    labels = [
        ("deepseek-v4", "DeepSeek V4"),
        ("kimi-k2.6", "Kimi K2.6"),
        ("glm-5.1", "GLM-5.1"),
        ("gpt-5.5", "GPT-5.5"),
        ("gpt-5.4", "GPT-5.4"),
        ("qwen", "Qwen"),
    ]
    for marker, label in labels:
        if marker in normalized:
            return label
    if not model:
        return None
    cleaned = re.sub(r":cloud$", "", model, flags=re.IGNORECASE)
    cleaned = re.sub(r"[^A-Za-z0-9._+-]+", " ", cleaned).strip()
    return cleaned or None


def _extract_company_name(ticker: str, markdown_path: Path | None) -> str:
    safe_ticker = _safe_ticker(ticker)
    if safe_ticker in COMPANY_NAME_OVERRIDES:
        return COMPANY_NAME_OVERRIDES[safe_ticker]
    if not markdown_path or not markdown_path.exists():
        return ticker

    text = markdown_path.read_text(encoding="utf-8", errors="ignore")
    patterns = [
        rf"(?:Technische Analyse|Fundamentale Analyse|Markt- und Nachrichtenanalyse|Markt- und Handelsbericht):\s*([^#\n]+?)\s*\({re.escape(ticker)}\)",
        rf"#\s*{re.escape(ticker)}\s*\(([^)]+)\)",
        rf"#\s*([^#\n]+?)\s*\({re.escape(ticker)}\)",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            company = match.group(1).strip(" -–—")
            company = re.sub(r",?\s*(Inc\.|Corporation|Corp\.|AG|SE)$", "", company).strip()
            if company:
                return company
    return ticker


def _latest_complete_pdf(report_dir: Path) -> Path:
    complete_dir = report_dir / "complete"
    matches = sorted(complete_dir.glob("*-complete-dossier.pdf"))
    if not matches:
        raise SystemExit(f"No complete Room 16 PDF found in {complete_dir}")
    return matches[-1]


def _latest_complete_markdown(report_dir: Path) -> Path | None:
    complete_dir = report_dir / "complete"
    matches = sorted(complete_dir.glob("*-complete-dossier.md"))
    return matches[-1] if matches else None


def _date_from_pdf(pdf_path: Path) -> str:
    match = re.match(r"(\d{4}-\d{2}-\d{2})-", pdf_path.name)
    return match.group(1) if match else datetime.now().strftime("%Y-%m-%d")


def publish(report_dir: Path, ticker: str, shelf_dir: Path) -> Path:
    pdf_path = _latest_complete_pdf(report_dir)
    markdown_path = _latest_complete_markdown(report_dir)
    safe_ticker = _safe_ticker(ticker)
    company_name = _extract_company_name(ticker, markdown_path)
    company_dir = shelf_dir / _safe_filename(f"{company_name} ({safe_ticker})")
    company_dir.mkdir(parents=True, exist_ok=True)

    report_date = _date_from_pdf(pdf_path)
    model_label = _extract_model_label(markdown_path)
    model_part = f" {model_label}" if model_label else ""
    target = company_dir / _safe_filename(f"{report_date} Room 16 {safe_ticker}{model_part} Complete Dossier.pdf")
    shutil.copy2(pdf_path, target)
    _write_company_readme(company_dir, company_name, safe_ticker, target)
    _write_shelf_index(shelf_dir)
    return target


def _write_company_readme(company_dir: Path, company_name: str, ticker: str, latest_pdf: Path) -> None:
    pdfs = sorted(company_dir.glob("*.pdf"), reverse=True)
    lines = [
        f"# {company_name} ({ticker})",
        "",
        "Room 16 Leseregal fuer finale PDF-Reports.",
        "",
        f"Latest: `{latest_pdf.name}`",
        "",
        "## Reports",
        "",
    ]
    for pdf in pdfs:
        lines.append(f"- `{pdf.name}`")
    company_dir.joinpath("README.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def _write_shelf_index(shelf_dir: Path) -> None:
    shelf_dir.mkdir(parents=True, exist_ok=True)
    company_dirs = sorted(path for path in shelf_dir.iterdir() if path.is_dir() and not path.name.startswith("_"))
    lines = [
        "# Room 16 Reports",
        "",
        "Menschliches Leseregal fuer finale Room-16-PDFs.",
        "",
        "Regel: Room 16 baut weiter im Projekt-Run-Verzeichnis, aber final lesbare PDFs werden hier pro Unternehmen gespiegelt.",
        "",
        "## Unternehmen",
        "",
    ]
    for company_dir in company_dirs:
        pdfs = sorted(company_dir.glob("*.pdf"), reverse=True)
        if pdfs:
            lines.append(f"- `{company_dir.name}`: `{pdfs[0].name}`")
        else:
            lines.append(f"- `{company_dir.name}`")
    lines.extend(
        [
            "",
            "## Chat-Archive",
            "",
            "- `_Codex Chats/`: kurze Codex-/Vega-Arbeitsnotizen zu Report-Laeufen.",
            "- `_LION Vivi Analysis Chats/`: automatisch abgelegte LION/Vivi-Analyseauftraege.",
        ]
    )
    shelf_dir.joinpath("_INDEX.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report-dir", required=True, help="Ticker report directory, e.g. reports/room16/runs/<RUN_ID>/<TICKER>.")
    parser.add_argument("--ticker", required=True)
    parser.add_argument("--shelf-dir", default=str(DEFAULT_SHELF_DIR))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    target = publish(Path(args.report_dir), args.ticker, Path(args.shelf_dir).expanduser())
    print(target)


if __name__ == "__main__":
    main()
