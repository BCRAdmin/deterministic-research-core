# Room16 Manual Review Workbench 2026-05-18

## Zweck

Die Manual Review Workbench ist eine interne Operator-Ansicht für Room16-Dossiers. Sie macht Review-Status, Gate-Status, Blocker, Warnings, effektive Sichtbarkeit und die nächste manuelle Aktion sichtbar.

Sie ist keine Public-Freigabe, keine Publishing-Automation und keine Anlageberatung. Public bleibt nur nach explizitem Operator-Go, Non-Advice-Bestätigung, Human Source Verification und vollständigem Promotion-Stack möglich.

## Status-Taxonomie

| Status | Bedeutung | Public-Verhalten |
| --- | --- | --- |
| `ingested` | Dossier ist im Regal, aber noch nicht review-ready. | hidden |
| `audit_failed` | Quality- oder Source-Audit ist rot. | hidden |
| `review_ready` | Pipeline-Daten sind vorhanden und können manuell geprüft werden. | hidden |
| `manual_review` | Pipeline oder Archetype verlangt manuelle Entscheidung. | hidden |
| `approved_internal` | Human Review, Source Verification und Non-Advice sind intern bestätigt. | bleibt intern |
| `promotion_blocked` | Promotion-Stack ist unvollständig oder blockiert. | hidden |
| `public_ready` | Gate-Vertrag ist vollständig erfüllt. | erst mit Operator-Go public |

## Workbench-Felder

Die UI zeigt pro Dossier:

- Dossier / Ticker
- `generationStage`
- `qualityStatus` und Quality Verdict
- abgeleiteter Review-Status
- `gateStatus`
- Blocker und Warnings aus `evaluatePublicLibraryGate`
- `effectiveVisibility`
- `nextManualAction`

## Gate Reason Viewer

Der Reason Viewer liest direkt aus `qualityGate.blockers` und `qualityGate.warnings`.

Wichtige Gründe:

- `manual_review_required`: manuelle Review ist bindend.
- `markdown_first_qa_not_public`: Markdown-first QA ist kein Public-Artefakt.
- `internal_best_not_public`: Internal Best bleibt intern.
- `promotion_non_advice_missing`: Non-Advice-Bestätigung fehlt.
- `promotion_sources_human_verified_missing`: menschliche Quellenprüfung fehlt.
- `promotion_reviewed_by_missing`: Operator-Review fehlt.
- `promotion_blocking_issues`: Promotion-Stack enthält blockierende Punkte.
- `quality_failed`: Quality-Audit ist rot.

## Public-/Non-Advice-Schutz

Die Workbench nutzt die bestehende Funktion `evaluatePublicLibraryGate` als Wahrheit. Sie führt keinen neuen Public-Schalter ein.

Blockierend bleiben insbesondere:

- `manual_review`
- `draft_markdown_qa`
- `internal_best`
- fehlende Non-Advice-Bestätigung
- fehlende Human Source Verification
- fehlender Promotion-Reviewer
- fehlende Approval-Zeit
- Promotion Blocking Issues

## Verifier

Der Script `room16-app/scripts/verify_manual_review_workbench.mjs` prüft:

- Status-Taxonomie und Dokumentation existieren.
- Workbench UI verwendet Gate-Reasons, Blocker, Warnings und Next Action.
- `manual_review` blockiert Public.
- `draft_markdown_qa` blockiert Public.
- `internal_best` blockiert Public.
- fehlende Non-Advice- und Source-Verification blockieren Public.
- Public-ready bleibt an den vollständigen Gate-Vertrag gebunden.
- Die Workbench enthält keine Public-Aktion ohne Operator-Go.

Ausführung:

```bash
cd "/Users/BjornRosinger/Documents/DreamFactory/Project-Intelligence-Graph/company-dossier-lab/room16-app"
npm run verify:manual-review-workbench
```
