# Room16 Publish Readiness Packet 2026-05-25

## Zweck

Dieses Paket fasst Review-Gate-Status und Manual-Review-Packets zu einer lokalen Publish-Readiness-Entscheidungsvorlage zusammen. Es öffnet keine Public-/Member-Sichtbarkeit und ist keine Freigabe.

## Verifier

```bash
cd company-dossier-lab/room16-app && npm run verify:publish-readiness
```

Der Verifier liest nur lokale Runtime-Evidence:

- `company-dossier-lab/.runtime/room16-app/review-gate-status/latest-review-gate-status.json`
- `company-dossier-lab/.runtime/room16-app/manual-review-packets/latest-manual-review-packets.json`

Er schreibt:

- `company-dossier-lab/.runtime/room16-app/publish-readiness/latest-publish-readiness.json`
- `company-dossier-lab/.runtime/room16-app/publish-readiness/latest-publish-readiness.md`

## Statuslogik

- `PASS`: keine offenen Manual-Review-Packets, keine strukturellen Findings, keine Runtime-Aktion.
- `WARN`: lokale Evidence ist konsistent, aber Manual Review, Non-Advice, Human Source Verification oder Operator-Go fehlen noch.
- `FAIL`: ein Strukturbruch, fehlende Datei, unvollständiger Stop-Vertrag oder effektive Public-Sichtbarkeit wurde gefunden.

## Stop-Regel

Dieses Paket ist nur Evidence. Stop bei Public/Member-Sichtbarkeit, Room16-Rerun, Push, Publish, externer Kommunikation, Finanzpublishing, Production, Geld, Credentials/Auth oder Löschung.

## Operator-Entscheidung

Lokal erlaubt sind nur:

- `keep_hidden`
- `approved_internal_after_human_review`
- `reject`
- `needs_more_evidence`

Ohne separates Operator-Go verboten bleiben:

- `public`
- `member`
- `publish`
- `rerun`
- `push`
- `external_send`
- `financial_advice_publish`
- `delete`
