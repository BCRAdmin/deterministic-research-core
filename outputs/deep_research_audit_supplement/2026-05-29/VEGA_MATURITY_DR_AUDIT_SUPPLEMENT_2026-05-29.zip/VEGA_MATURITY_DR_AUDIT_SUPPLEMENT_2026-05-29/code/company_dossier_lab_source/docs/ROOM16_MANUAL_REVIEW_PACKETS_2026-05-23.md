# Room16 Manual Review Packets

## Zweck

Manual Review Packets übersetzen offene Room16-Manual-Review-Einträge in konkrete lokale Prüfkarten. Sie helfen Vega, Vivi und dem Operator, die nächsten sicheren Review-Schritte zu sehen, ohne Public-/Member-Sichtbarkeit zu ändern.

## Verifier

```bash
cd company-dossier-lab/room16-app && npm run verify:manual-review-packets
```

Der Verifier liest das aktuelle Review-Gate-Statuspaket und sucht die betroffenen PDFs unter `/Users/BjornRosinger/Documents/DreamFactory/Room16/Reports`. Er schreibt nur lokale Evidence.

## Outputs

- `company-dossier-lab/.runtime/room16-app/manual-review-packets/latest-manual-review-packets.json`
- `company-dossier-lab/.runtime/room16-app/manual-review-packets/latest-manual-review-packets.md`
- ein JSON/Markdown-Packet pro `manual_review`-Eintrag

## Packet-Felder

- `ticker`
- `dossierId`
- `report`
- `reportPath`
- `reportFileExists`
- `generationStage`
- `gateStatus`
- `blockers`
- `warnings`
- `nextManualAction`
- `reviewer`
- `sourceVerificationStatus`
- `nonAdviceStatus`
- `promotionStatus`
- `manualDecisionContract`
- `promotionReadiness`
- `reviewEvidenceChecklist`
- `policyReferences`
- `operatorGoRequired`
- `requestedVisibility`
- `effectiveVisibility`
- `runtime_action_executed`
- `stopRule`

## Statuslogik

- `PASS`: keine offenen Manual-Review-Packets.
- `WARN`: Packets wurden erzeugt und lokale Review-Arbeit ist offen.
- `FAIL`: Ein im Review-Gate-Status gelisteter Report wurde lokal nicht gefunden oder die Struktur ist unlesbar.

## Stop-Regel

Diese Packets sind Evidence und Prüfliste, keine Freigabe. Stop bei Public/Member-Sichtbarkeit, Room16-Rerun, Push, Publish, externer Kommunikation, Finanzpublishing, Production, Geld, Credentials/Auth oder Löschung.

## Entscheidungsvertrag

Jedes Packet enthält jetzt explizit, welche Entscheidungen lokal erlaubt sind und was ohne Operator-Go verboten bleibt:

- erlaubt: `keep_hidden`, `approved_internal`, `reject`, `needs_more_evidence`
- ohne Operator-Go verboten: `public`, `member`, `publish`, `rerun`, `push`

`promotionReadiness.status` bleibt `blocked`, bis Report-Datei, Human Source Verification, Non-Advice, Promotion-Stack und Operator-Go sauber dokumentiert sind. Das verhindert, dass ein lokales Review-Paket wie eine Public-Freigabe wirkt.
