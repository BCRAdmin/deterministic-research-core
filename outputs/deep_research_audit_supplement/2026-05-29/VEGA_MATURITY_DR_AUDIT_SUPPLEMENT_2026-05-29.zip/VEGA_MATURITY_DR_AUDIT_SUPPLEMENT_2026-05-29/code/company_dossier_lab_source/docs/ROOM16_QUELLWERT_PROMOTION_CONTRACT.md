# Room 16 → Quellwert Promotion Contract v1

Status: binding bridge between internal Room 16 reports and public Quellwert publication.

## Purpose

Room 16 may produce useful internal analysis, but Quellwert must only publish
reviewed, source-ledgered, non-advice editorial notes. This contract prevents
the shortcut “PDF exists → publish it”.

## Contract States

- `blocked`: a hard requirement is missing; the report cannot become a public
  Quellwert post.
- `review_required`: hard files exist, but human/source/editorial confirmation
  is still missing.
- `member_ready`: allowed only for a future member surface; not enough for
  Quellwert public SEO.
- `public_ready`: eligible to be converted into the Quellwert public catalog.

## Public-Ready Requirements

All of these must pass:

1. Room 16 quality report verdict is `pass`.
2. Strict research integrity has passed, or a legacy Room 16 report is promoted
   only through a verified fact ledger plus a separate Quellwert editorial draft.
3. Complete Markdown and PDF artifacts exist.
4. Fact ledger exists and each material claim has `source_id`, `period_type`,
   `asof`, and `formula_id` for calculated metrics.
5. At least two primary sources are present, with at least one `SEC` or `IR`
   source.
6. A separate Quellwert editorial draft exists; raw Room 16 output is not the
   public article.
7. Public draft contains sources, risks, and a visible non-advice disclaimer.
8. Public draft does not contain trading-action, price-target, stop-loss, or
   raw recommendation language.
9. Human review, human source verification, and non-advice confirmation are
   explicitly marked.

## Canonical Command

```bash
python scripts/room16_promotion_contract.py \
  --quality-report reports/room16/runs/<RUN_ID>/<TICKER>/quality/YYYY-MM-DD-room16-quality-report.json \
  --fact-ledger reports/room16/runs/<RUN_ID>/<TICKER>/quality/YYYY-MM-DD-room16-fact-ledger.json \
  --public-draft reports/quellwert-drafts/<TICKER>/<slug>.md \
  --reviewed-by operator \
  --sources-human-verified \
  --non-advice-confirmed \
  --requested-visibility public
```

The command writes JSON and Markdown reports to:

```text
.runtime/room16-promotion-contract/
```

## Operating Rule

If this contract returns anything other than `public_ready`, the report can stay
internal in Room 16, but it must not be routed into Quellwert public pages.

Legacy reports with normal Room 16 QA may become public only if the public
artifact is the separate Quellwert draft and the fact ledger is complete. The
raw Room 16 dossier remains internal.

The next manual work after a `review_required` result is not UI polish. It is:

1. repair fact ledger,
2. rewrite the public draft,
3. verify sources,
4. run the contract again.
