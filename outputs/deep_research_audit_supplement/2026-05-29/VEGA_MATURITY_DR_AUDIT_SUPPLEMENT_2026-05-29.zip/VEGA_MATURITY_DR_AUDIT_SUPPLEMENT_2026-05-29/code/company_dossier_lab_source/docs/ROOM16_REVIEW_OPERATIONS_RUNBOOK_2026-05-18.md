# Room16 Review Operations Runbook 2026-05-18

## Zweck

Dieses Runbook beschreibt, wie ein Operator die Room16 Manual Review Workbench im Tagesbetrieb nutzt. Es erweitert die Workbench um ein operatives Review-Modell, nicht um neue Publishing-Funktionen.

Grundregel: Public bleibt geschlossen. `manual_review`, `draft_markdown_qa` und `internal_best` sind interne Zustände. Eine Public-Freigabe ist nur nach Operator-Go, Non-Advice-Bestätigung, Human Source Verification und vollständigem Promotion-Stack zulässig. Dieses Runbook beschreibt keine Public-Automation und keine Provider-Aktion.

## Daily Review Ablauf

1. Workbench öffnen und die Queue nach `manual_review`, `audit_failed`, `promotion_blocked` und `review_ready` priorisieren.
2. Pro Dossier `ticker`, `dossierId`, `generationStage`, `gateStatus`, Blocker, Warnings und `nextManualAction` erfassen.
3. Gate-Reasons aus `evaluatePublicLibraryGate` als Wahrheit behandeln. UI-Labels sind nur Leseschicht.
4. Blocker in eine der Triage-Kategorien `source`, `audit`, `render`, `provider`, `data` oder `promotion` einordnen.
5. Non-Advice prüfen und das Ergebnis im Queue Packet als `nonAdviceStatus` dokumentieren.
6. Human Source Verification prüfen und das Ergebnis im Queue Packet als `sourceVerificationStatus` dokumentieren.
7. Wenn alle internen Prüfungen bestanden sind, nur `approved_internal` oder `promotion_blocked` empfehlen. Public bleibt bis zum expliziten Operator-Go geschlossen.
8. Review-Entscheidung, Reviewer, offene Blocker und nächste manuelle Aktion im Queue Packet aktualisieren.

## Blocker Triage

| Kategorie | Typische Gate-Reasons | Operative Bedeutung | Erlaubte Aktion |
| --- | --- | --- | --- |
| `source` | `promotion_sources_human_verified_missing`, `sources_not_human_verified`, `sources_not_pipeline_verified` | Quellen sind nicht menschlich verifiziert oder nicht ausreichend nachvollziehbar. | Quellen prüfen, Evidenz notieren, bei Unsicherheit hidden halten. |
| `audit` | `quality_failed`, `manual_review_required`, `pipeline_quality_not_passed` | Audit oder Review-Profil verlangt eine manuelle Entscheidung. | Auditbefund lesen, Reviewer-Entscheidung dokumentieren, Public geschlossen lassen. |
| `render` | `final_documents_not_rendered`, `final_pdf_not_rendered`, `publish_report_missing`, `pdf_missing` | Finale Artefakte fehlen oder sind nicht konsistent gerendert. | Render-Status dokumentieren, keinen Public-Status setzen. |
| `provider` | Provider-Timeout, unvollständige Provider-Antwort, Provider-Ratelimit | Externe Datengrundlage ist nicht stabil genug. | Nur klassifizieren und Engineering/Provider-Issue anlegen; keine Provider-Aktion aus dem Runbook. |
| `data` | fehlende Kennzahlen, widersprüchliche Unternehmensdaten, `markdown_missing` | Dossier-Daten sind unvollständig oder widersprüchlich. | Datenlücke notieren und Dossier intern halten. |
| `promotion` | `promotion_not_public_ready`, `promotion_non_advice_missing`, `promotion_reviewed_by_missing`, `promotion_approved_at_missing`, `promotion_requested_visibility_not_public`, `promotion_blocking_issues` | Promotion-Stack ist unvollständig oder widerspricht Public-Readiness. | Promotion-Blocker dokumentieren; Public bleibt geschlossen. |

## Status Definitionen

| Status | Bedeutung | Public-Verhalten |
| --- | --- | --- |
| `ingested` | Dossier wurde erfasst, ist aber nicht review-ready. | hidden |
| `audit_failed` | Quality-, Source- oder Daten-Audit ist rot. | hidden |
| `review_ready` | Pipeline-Daten sind für manuelle Prüfung vorhanden. | hidden |
| `manual_review` | Pipeline oder Archetype verlangt menschliche Entscheidung. | hidden |
| `approved_internal` | Reviewer hat Human Review, Non-Advice und Human Source Verification intern bestätigt. | bleibt intern |
| `promotion_blocked` | Promotion-Stack ist unvollständig, widersprüchlich oder blockiert. | hidden |
| `public_ready` | Gate-Vertrag ist technisch vollständig erfüllt. | weiterhin nur mit Operator-Go public |

`public_ready` ist kein automatischer Publish-Befehl. Der Status bedeutet nur, dass alle Gate-Bedingungen erfüllt sein können; die tatsächliche Public-Freigabe bleibt eine separate Operator-Entscheidung.

## Entscheidungsrechte

| Rolle | Darf entscheiden | Darf nicht entscheiden |
| --- | --- | --- |
| Pipeline | Vorläufige Gate-Reasons, Warnings und Render-/Datenstatus liefern. | Public setzen, Non-Advice final bestätigen, Human Source Verification final bestätigen. |
| Reviewer | Quellenprüfung, Non-Advice, Auditbefund und `nextManualAction` dokumentieren. | Public freigeben oder Publishing-Automation starten. |
| Operator | Operator-Go erteilen, Dossier intern halten, Review erneut anfordern oder Promotion blockieren. | Gate-Vertrag umgehen oder fehlende Evidenz überstimmen. |
| Engineering | Gate-/UI-/Verifier-Fehler beheben und neue Prüfungen einbauen. | Dossier fachlich freigeben oder Provider-Aktionen aus diesem Runbook ableiten. |

## Operator-Go Pflicht

Operator-Go ist erforderlich, bevor irgendeine Public-Aktion stattfinden darf. Das gilt auch dann, wenn `gateStatus` oder `qualityGate.status` bereits `public_ready` meldet.

Operator-Go darf nur dokumentiert werden, wenn alle Punkte erfüllt sind:

- `sourceVerificationStatus` ist `human_verified`.
- `nonAdviceStatus` ist `confirmed`.
- `promotionStatus` ist `public_ready`.
- `operatorGoRequired` wurde bewusst bewertet.
- Es gibt keine offenen Blocker in `source`, `audit`, `render`, `provider`, `data` oder `promotion`.
- `reviewer` und Zeitpunkt der Prüfung sind im Review Packet nachvollziehbar.

Ohne Operator-Go bleibt die nächste manuelle Aktion "hold internal" oder "clear blockers". Es gibt keine Public-Automation.

## Non-Advice Bestätigung

Non-Advice wird durch einen Menschen bestätigt. Der Reviewer prüft, dass das Dossier keine Anlageberatung, keine Kauf-/Verkaufsempfehlung, keine garantierten Renditeaussagen und keine irreführende Handlungsaufforderung enthält.

Dokumentation im Queue Packet:

- `nonAdviceStatus: "confirmed"` nur nach manueller Prüfung.
- `nonAdviceStatus: "missing"` bei fehlender oder unklarer Policy-Bestätigung.
- `nonAdviceStatus: "rejected"` bei Advice-Risiko.

Fehlende Non-Advice-Bestätigung blockiert Promotion und Public. Relevante Gate-Reasons sind `promotion_non_advice_missing` und `non_advice_policy_missing`.

## Human Source Verification

Human Source Verification ist eine menschliche Quellenprüfung, nicht nur ein Pipeline-Flag. Der Reviewer prüft, ob die zentralen Quellen erreichbar, plausibel, dem Dossier zuordenbar und für die Aussage ausreichend sind.

Dokumentation im Queue Packet:

- `sourceVerificationStatus: "human_verified"` nur nach manueller Quellenprüfung.
- `sourceVerificationStatus: "pipeline_verified"` wenn nur Pipeline-Evidenz vorliegt.
- `sourceVerificationStatus: "missing"` wenn Quellen fehlen oder nicht nachvollziehbar sind.
- `sourceVerificationStatus: "rejected"` wenn Quellen die Aussage nicht tragen.

Fehlende Human Source Verification blockiert Promotion und Public. Relevante Gate-Reasons sind `promotion_sources_human_verified_missing`, `sources_not_human_verified` und `sources_not_pipeline_verified`.

## Warum Public geschlossen bleibt

Die Workbench ist eine interne Review-Oberfläche. Sie nutzt `evaluatePublicLibraryGate` als Gate-Wahrheit, führt aber keinen neuen Public-Schalter ein und beschreibt keine Public-Automation.

Public bleibt geschlossen, weil:

- `manual_review`, `draft_markdown_qa` und `internal_best` keine Public-Artefakte sind.
- Non-Advice und Human Source Verification menschlich dokumentiert werden müssen.
- Promotion-Blocker nicht durch UI-Labels oder Pipeline-Warnings überstimmt werden dürfen.
- `public_ready` ohne Operator-Go nur ein Gate-Ergebnis ist, keine Veröffentlichung.
- Dieses Runbook keine Publishing-Automation, keine Provider-Aktion und keine Anlageberatung erlaubt.

## Abschlusskriterium pro Review

Ein Review ist abgeschlossen, wenn das Queue Packet den aktuellen Status, die Triage-Kategorie, offene Blocker, Non-Advice-Status, Source-Verification-Status, Reviewer, nächste manuelle Aktion und Operator-Go-Pflicht enthält.

Wenn Zweifel bestehen, bleibt das Dossier intern und die nächste Aktion lautet: Blocker klären, Quellen prüfen oder Operator-Entscheidung anfordern.
