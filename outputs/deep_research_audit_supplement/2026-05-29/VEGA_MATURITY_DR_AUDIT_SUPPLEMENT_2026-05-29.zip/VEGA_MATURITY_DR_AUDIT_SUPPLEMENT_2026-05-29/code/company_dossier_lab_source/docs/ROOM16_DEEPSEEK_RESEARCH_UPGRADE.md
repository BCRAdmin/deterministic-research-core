# Room 16 DeepSeek Research Upgrade

Status: active implementation standard.
Created: 2026-05-04.
Scope: make DeepSeek-based Room 16 reports materially closer to a verified premium research workflow.

## Why This Exists

The AMZN model comparison showed that report quality is no longer mainly a prose problem.
The weak points are research-machine problems:

- material events can be missed or contradicted
- quarter, TTM, spot and run-rate metrics can drift
- secondary narrative can outrank SEC/IR truth
- multiple agent sections can disagree with the final verdict
- reports can look complete while still lacking auditable source provenance

Room 16 must therefore move from a one-pass agent report to a three-pass workflow:

```text
Draft -> Verify -> Adjudicate
```

## Target Workflow

| Pass | Owner | Purpose | Output |
| --- | --- | --- | --- |
| Draft | DeepSeek V4 via Ollama Cloud / selected enabled profile | create the complete research draft from the TradingAgents flow | long internal dossier |
| Verify | deterministic gates plus stronger model or human review when available | check sources, metrics, events, period logic, rating consistency | quality and integrity report |
| Adjudicate | human / trusted reviewer | final investment wording, client-grade judgment, publication decision | approved report or review queue |

## Operator Default Card

This is the short future-facing rule for new agents:

```text
DeepSeek-Agent auf ChatGPT-Niveau:

1-pass is not enough.
Use 3-pass:
Draft: DeepSeek V4 Pro via Ollama Cloud.
Verify: strict validator, later GPT-5.4 or equivalent verifier when explicitly enabled.
Final: Human or explicitly enabled trusted adjudicator.

Main failure modes:
- hallucination
- metric drift
- source bias

Source priority:
SEC / company IR / slides > transcript > trusted vendor > newswire > social.

Every number needs:
source_id, asof, period_type, formula_id if calculated.

Prompt seed:
task: equity_report
must_cite: [SEC, IR]
output: [claims, sources, ranges, risks]
forbid: [social_only, uncited_metrics]

QA:
- primary-source reconciliation
- unit tests
- red-team
- TTM vs quarter consistency
- reproducible TradingAgents snapshot
- persist DeepSeek tool-call reasoning_content where the provider exposes it
```

Model-cost notes from chat are not adopted as verified pricing truth. Treat any
cost table as `assumption_open` until refreshed from official provider pricing.

```mermaid
flowchart LR
    A[SEC/IR] --> B[Normalize]
    B --> C[TradingAgents service]
    C --> D[DeepSeek draft]
    D --> E[Strict verify]
    E --> F[Human adjudication]
```

## Source Priority

All future client-grade or publication-grade reports must use this hierarchy:

1. SEC filings and company IR: 10-Q, 10-K, 8-K, earnings release, slides, webcast transcript.
2. Official exchange or trusted price data vendor for OHLCV and indicators.
3. Top-tier news wires for event context.
4. Vendor/analyst summaries for secondary interpretation.
5. Social or retail sources only as sentiment context, never as sole evidence for a numeric or fundamental claim.

## Required Fact Metadata

Every numeric claim in the future source ledger should carry:

```json
{
  "claim": "AWS revenue",
  "value": 37.6,
  "unit": "USD bn",
  "ticker": "AMZN",
  "period_type": "quarterly",
  "asof": "2026-03-31",
  "source_id": "amazon-q1-2026-release-aws-revenue",
  "formula_id": null
}
```

For calculated values:

```json
{
  "claim": "free cash flow",
  "value": 1.232,
  "unit": "USD bn",
  "period_type": "ttm",
  "asof": "2026-03-31",
  "source_id": "amazon-q1-2026-release-cash-flow",
  "formula_id": "operating_cash_flow_minus_capex"
}
```

## Mandatory Integrity Gates

The normal build gate stays responsible for artifact quality: files, length, PDF rendering, German labels and copy readability.

The research integrity layer is responsible for truth risk:

| Gate | Blocks normal QA | Strict/client-grade |
| --- | ---: | ---: |
| no company-news contradiction while material events are present | yes | yes |
| known material event missing for configured ticker/date | yes | yes |
| price/SMA narrative contradiction | yes | yes |
| missing source ledger fields | no | yes |
| missing `period_type` on period-sensitive metrics | no | yes |
| missing visible SEC/IR source-priority note on fundamentals | no | yes |

Run strict mode for publication/client-grade output:

```bash
python scripts/room16_report_quality_gate.py \
  --run-dir .runtime/bcr-company-batches/<RUN_ID> \
  --reports-dir reports/room16/runs/<RUN_ID>/<TICKER> \
  --tickers <TICKER> \
  --strict-research-integrity
```

## AMZN Findings Adopted As Regression Seeds

The user-supplied AMZN audit becomes a regression seed, not a blindly trusted fact database.

Stable design findings adopted:

- Report 1 is the better style/structure seed.
- Report 2 is a useful negative QA seed because it turns weak fact hygiene into a harder portfolio consequence.
- Official SEC/IR event detection must outrank generic macro/news summaries.
- A report must never say there were no material company events if earnings, filings or guidance are in the window.
- Free cash flow, operating cash flow, capex, balance sheet values and moving-average claims need deterministic calculation or source IDs.
- Final recommendation, trader signal, staged plan and section ratings must be reconciled before the report is considered client-grade.

Unverified until separately refreshed:

- model pricing claims
- third-party citation handles from pasted ChatGPT output
- any market-data value not present in Room 16 local source artifacts or primary filings

## Implementation Roadmap

### P0: Now

- Add research integrity checks to `room16_report_quality_gate.py`.
- Record strict/publication mode separately from internal file QA.
- Preserve AMZN DeepSeek vs Kimi as regression reports for model comparison.

### P1: Next

- Add SEC/IR ingestion snapshots per ticker.
- Create a `fact_ledger.json` next to each report bundle.
- Add deterministic technical indicator manifest: vendor, calendar, adjusted/unadjusted, formulas.
- Add event-window detector before the LLM draft.

### P2: Later

- Add stronger verifier model profile when paid/API providers are explicitly enabled.
- Add human review queue and adjudication screen in Room 16.
- Add chart/table generator from the fact ledger instead of asking the LLM to invent tables.

## Operating Rule

DeepSeek is allowed to draft. It is not allowed to be the only truth layer for client-grade output.

Client-grade Room 16 reports require:

```text
LLM draft + deterministic fact checks + source ledger + final adjudication
```
