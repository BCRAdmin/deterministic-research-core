# Room 16 Reporting Standard

Status: binding for all future Room 16 report generations.
Owner: internal BCR/Quellwert workflow.
Last updated: 2026-05-02.

This document defines the fixed Room 16 workflow, brand system, artifact bundle,
quality gates, and delivery rules. Future agents must follow this standard
without asking the operator to choose between polish and completeness.

## Core Principle

Every Room 16 company analysis produces its own report bundle, not a shared
multi-company file.

Each company bundle has one default user-facing layer:

1. Complete dossier: long, auditable, full analyst material.

Premium memo generation is optional and disabled by default. Generate premium
overviews only when the operator explicitly asks for them or when
`--with-premium` is passed. The complete dossier is never allowed to look like
an unformatted raw dump.

## Model Quality Rule

Room 16 company analysis is a quality-first workflow. The current proven default
for new stock report generation is `ollama` with `deepseek-v4-pro:cloud` for
both quick and deep models. This is an Ollama Cloud lane, not a local model.
Local Qwen lanes such as `qwen3.5-vivi:9b` may
orchestrate, inspect, summarize, prepare source gates, draft checklists, and run
bounded QA, but they must not silently replace DeepSeek for fresh company
analysis, final investment reasoning, or new Room 16 dossier generation.

If a future run uses a different model, the manifest and quality report must
show it explicitly. Do not describe a Qwen-prepared handoff as a DeepSeek-quality
Room 16 analysis unless the underlying Room 16 run itself used the approved
analysis model lane.

Verify this policy with:

```bash
python scripts/check_room16_model_quality_policy.py
```

## Research Integrity Upgrade

The current DeepSeek/TradingAgents layer is a draft engine, not the sole truth
layer for client-grade research. The target workflow is:

```text
Draft -> Verify -> Adjudicate
```

Details live in:

```text
docs/ROOM16_DEEPSEEK_RESEARCH_UPGRADE.md
schemas/room16_fact_ledger.schema.json
```

For internal Room 16 reading, the standard quality gate must at least block
critical contradictions: material event missed, `no company news` while earnings
or filings are present, and price/SMA narrative contradictions.

For publication, paid pilots, Quellwert-facing output, or anything that should
read at ChatGPT/GPT-5 review quality, run strict research integrity mode:

```bash
python scripts/room16_report_quality_gate.py \
  --run-dir .runtime/bcr-company-batches/<RUN_ID> \
  --reports-dir reports/room16/runs/<RUN_ID>/<TICKER> \
  --tickers <TICKER> \
  --strict-research-integrity
```

Strict mode requires source-ledger readiness: numeric claims must be traceable by
`source_id`, `asof`, `formula_id` where calculated, and `period_type`.

## Quellwert Promotion Contract

Room 16 reports are internal raw material. A passed Room 16 PDF is not enough to
publish on Quellwert.

Before a report can become a public Quellwert post, run the promotion contract:

```bash
python scripts/room16_promotion_contract.py \
  --quality-report reports/room16/runs/<RUN_ID>/<TICKER>/quality/YYYY-MM-DD-room16-quality-report.json \
  --fact-ledger reports/room16/runs/<RUN_ID>/<TICKER>/quality/YYYY-MM-DD-room16-fact-ledger.json \
  --public-draft reports/quellwert-drafts/<TICKER>/<slug>.md \
  --reviewed-by operator \
  --sources-human-verified \
  --non-advice-confirmed \
  --requested-visibility public
```

The contract is documented in:

```text
docs/ROOM16_QUELLWERT_PROMOTION_CONTRACT.md
schemas/room16_quellwert_promotion_contract.schema.json
```

Only `public_ready` may be routed into the Quellwert public catalog. `blocked`
and `review_required` reports may stay in Room 16, but must not become SEO or
public Quellwert content. Legacy Room 16 reports with normal QA may pass only
when the public artifact is a separate Quellwert draft backed by a complete fact
ledger; the raw Room 16 dossier remains internal.

Multi-company input is allowed for data collection, but report generation is
sequential and company-isolated: finish one ticker, write its files, run its QA,
then move to the next ticker. Do not create a combined multi-company report
unless the operator explicitly asks for a combined package.

## Sequential Single-Company Rule

This is a hard operating rule.

When the operator provides multiple tickers, the system may run data collection
for the requested tickers, but report generation must be serialized:

1. Build complete dossier and quality report for ticker 1.
2. Save ticker 1 under `reports/room16/runs/<RUN_ID>/<TICKER>/`.
3. Render and inspect ticker 1 QA pages.
4. Only then continue with ticker 2.

Do not create one report file containing several companies. Do not use a
multi-company complete dossier as the default output. Do not create premium
overview reports by default. A combined package or premium overview is allowed
only when the operator explicitly says to combine, merge, bundle together,
create one multi-company report, or create a premium overview.

## Required Artifact Bundle

For every completed Room 16 ticker, create all of these files:

```text
reports/room16/runs/<RUN_ID>/<TICKER>/complete/YYYY-MM-DD-room16-<TICKER>-complete-dossier.md
reports/room16/runs/<RUN_ID>/<TICKER>/complete/YYYY-MM-DD-room16-<TICKER>-complete-dossier.docx
reports/room16/runs/<RUN_ID>/<TICKER>/complete/YYYY-MM-DD-room16-<TICKER>-complete-dossier.pdf

reports/room16/runs/<RUN_ID>/<TICKER>/quality/YYYY-MM-DD-room16-quality-report.json
reports/room16/runs/<RUN_ID>/<TICKER>/quality/YYYY-MM-DD-room16-quality-report.md
```

Optional premium files, only when explicitly requested:

```text
reports/room16/runs/<RUN_ID>/<TICKER>/premium/YYYY-MM-DD-room16-<TICKER>-premium-investment-memo.docx
reports/room16/runs/<RUN_ID>/<TICKER>/premium/YYYY-MM-DD-room16-<TICKER>-premium-investment-memo.pdf
```

The run- and ticker-specific path is mandatory. Do not write only to shared
date-level folders, and do not save several companies into one final report
file by default.

Final PDF reading copies must also be mirrored into the human shelf:

```text
~/Documents/DreamFactory/Room16/Reports/<Company> (<TICKER>)/YYYY-MM-DD Room 16 <TICKER> Complete Dossier.pdf
```

The shelf is for reading and retrieval. It is not the canonical source of the
run; the run directory remains authoritative for Markdown, DOCX, PDFs, quality
reports, rendered QA pages, and raw state logs.

Combined artifacts are allowed only on explicit operator instruction, and must
live under:

```text
reports/room16/runs/<RUN_ID>/combined/
```

## Canonical Commands

Use the bundle builder unless debugging one specific layer:

```bash
TRADINGAGENTS_DISABLE_ANNOUNCEMENTS=1 python scripts/bcr_company_batch.py \
  --checkpoint \
  --tickers PLTR PACB MSFT RHM.DE \
  --quick-model deepseek-v4-pro:cloud \
  --deep-model deepseek-v4-pro:cloud \
  --ticker-timeout-seconds 1800 \
  --llm-timeout 300 \
  --llm-max-retries 2 \
  --ticker-retries 2 \
  --retry-delay-seconds 30
```

Then:

```bash
python scripts/room16_build_report_bundle.py \
  --run-dir .runtime/bcr-company-batches/<RUN_ID>
```

This command builds one ticker at a time. For a four-ticker run it must finish,
save, and QA ticker 1 before starting ticker 2. It must not build one combined
four-company report. It also must not build premium overview memos by default.
Default output is markdown-first QA: it builds the complete Markdown dossier,
generated review artifacts, dashboard status, and quality reports only. It does
not render DOCX/PDF and does not mirror anything to
`~/Documents/DreamFactory/Room16/Reports/`.

Markdown-first QA lifecycle fields must read:

```json
{
  "generation_stage": "draft_markdown_qa",
  "render_mode": "markdown_first_qa",
  "quality_verdict": "qa_pass",
  "score_scope": "markdown_qa",
  "publishable": false,
  "public_ready": false,
  "final_documents_rendered": false,
  "visibility": "internal_only"
}
```

`qa_pass` means the markdown QA lane passed. It does not mean public-ready,
publishable, final, or shelf-routable.

Final document rendering requires an explicit final pass:

```bash
python scripts/room16_build_report_bundle.py \
  --run-dir .runtime/bcr-company-batches/<RUN_ID> \
  --render-final-documents
```

Only this final pass renders DOCX/PDF and mirrors the final complete PDF to
`~/Documents/DreamFactory/Room16/Reports/` unless `--no-shelf` is explicitly passed.
The final pass may still be internal. Shelf publish remains blocked unless the
bundle manifest is a clean public bundle with `generation_stage=public_final`
and `promotion_status.public_ready=true`.

Combined report packages require the explicit flag:

```bash
python scripts/room16_build_report_bundle.py \
  --run-dir .runtime/bcr-company-batches/<RUN_ID> \
  --combine
```

Premium overview memos require the explicit flag:

```bash
python scripts/room16_build_report_bundle.py \
  --run-dir .runtime/bcr-company-batches/<RUN_ID> \
  --with-premium \
  --render-final-documents
```

The default bundle output root is:

```text
reports/room16/runs/<RUN_ID>/
```

OpenAI/API quality comparison is currently disabled in Room 16. Do not expose
GPT-based profiles in the app until credentials, cost guardrails, and an
operator gate are explicitly configured. Never claim that an OpenAI model was
tested unless the run manifest and quality report show the OpenAI provider and
the exact model id.

## Source Truth

The source of truth is the completed Room 16 run directory:

```text
.runtime/bcr-company-batches/<RUN_ID>/batch_manifest.json
.runtime/bcr-company-batches/<RUN_ID>/<TICKER>/TradingAgentsStrategy_logs/full_states_log_YYYY-MM-DD.json
```

Each ticker must contain these seven state fields:

```text
market_report
sentiment_report
news_report
fundamentals_report
trader_investment_decision
investment_plan
final_trade_decision
```

Minimum content posture:

- `market_report`: non-empty, normally > 1,500 characters.
- `sentiment_report`: non-empty, normally > 1,500 characters.
- `news_report`: non-empty, normally > 1,500 characters.
- `fundamentals_report`: non-empty, normally > 1,500 characters.
- `trader_investment_decision`: non-empty, normally > 300 characters.
- `investment_plan`: non-empty, normally > 300 characters.
- `final_trade_decision`: non-empty, normally > 300 characters.

If a field is missing or thin, do not hide it in formatting. Mark the run as
incomplete and repair or rerun the source workflow.

## Brand System

### Name

Use `ROOM 16` on covers and running headers.

Use `Room 16` in prose.

Do not rename the project in report artifacts.

### Language

Default output language is German.

English is allowed only for:

- ticker symbols
- provider/model IDs
- stable finance terms where translation would be less clear
- direct artifact path names
- raw source names in method notes

German public copy and final reports must use real German umlauts. Do not ship
ASCII fallback spellings such as `fuer`, `ueber`, `oeffentlich`, `Pruefung`,
`Maerkte`, `Muenchener Rueck`, `Qualitaet` or `Kapazitaet` in visible user-facing
text. Correct examples are `für`, `über`, `öffentlich`, `Prüfung`, `Märkte`,
`Münchener Rück`, `Qualität` and `Kapazität`.

Visible report labels must be German:

| Raw label | Final visible label |
| --- | --- |
| `Action` | `Umsetzung` |
| `Reasoning` | `Begründung` |
| `Recommendation` | `Einordnung` |
| `Rationale` | `Begründung` |
| `Strategic Actions` | `Operative Schritte` |
| `Position Sizing` | `Positionsgröße` |
| `Stop Loss` | `Stop-Loss` |
| `FINAL TRANSACTION PROPOSAL` | `Finale Transaktionseinordnung` |
| `Trader Output` | `Trader-Sicht` |
| `Investment Plan` | `Investment-Plan` |
| `Final Trade Decision` | `Finale Entscheidung` |
| `Executive Dashboard` | `Entscheidungsübersicht` |
| `Investment View` | `Investment-Sicht` |
| `Investment Thesis` | `Investment-These` |

Forbidden visible labels in final DOCX/PDF/Markdown:

```text
Action:
Reasoning:
Recommendation:
Rationale:
Strategic Actions:
FINAL TRANSACTION PROPOSAL
Trader Output
Investment View
Investment Thesis
Executive Summary
```

Visible analyst draft thoughts are forbidden in final deliverables. The final
Markdown, DOCX and PDF must not contain self-correction or chain-of-thought
phrases such as:

```text
nein, warte
oh nein
wait
Let me recheck
let me think
sorry
Entschuldigung
chain-of-thought
reasoning_content
analysis thoughts
```

If a raw analyst block contains a correction, keep only the corrected
professional claim. Do not expose the drafting process.

### Brand Palette

Use this palette consistently:

| Token | Hex | Use |
| --- | --- | --- |
| `NAVY` | `#0B1623` | headers, cover background, table header |
| `DEEP_NAVY` | `#07111D` | premium deck background |
| `GOLD` | `#BFA46A` | dividers, borders, accent rules |
| `SOFT_GOLD` | `#D9C790` | cover subtitle, secondary accent |
| `INK` | `#17212B` | primary body text |
| `MUTED` | `#5D6B78` | captions, metadata, subheads |
| `PAPER` | `#F4F1E8` | premium deck content background |
| `CARD` | `#FFFFFF` | card/table surfaces |
| `GRID` | `#D4D9E0` | table lines |
| `SELL_RED` | `#7A1F1F` | sell/reduce badges |
| `HOLD_BLUE` | `#203D66` | hold badges |
| `BUY_GREEN` | `#1E6B4B` | buy/constructive badges |

Avoid new palettes unless the standard is deliberately revised. Do not use
purple gradients, decorative blobs, cartoon styling, or generic startup visuals.

### Typography

PDF:

- Use Helvetica or bundled-safe equivalent.
- Cover title: 44-52 pt, bold.
- Deck page title: 28-34 pt, bold.
- Card title: 10-12 pt, bold.
- Premium body: 7.3-8.7 pt, only in cards with strict line limits.
- Complete dossier body: 8.0-8.3 pt with 10.3-10.8 leading.
- Complete dossier H1: 18 pt.
- Complete dossier H2: 13 pt.
- Complete dossier H3: 10.5-11 pt.

DOCX:

- Use Aptos if available, otherwise Arial.
- Body: 9.0-9.5 pt for long dossiers.
- Body: 9.5-10.5 pt for shorter memos.
- Heading 1: 18 pt, bold, navy.
- Heading 2: 13-14 pt, bold, navy.
- Heading 3: 11-12 pt, bold, muted.

No font may be so small that the report becomes a token-compression artifact.

## Artifact Rules

### Premium Memo

Purpose: decision briefing.

Required shape:

- Landscape A4 PDF.
- 5-14 pages for a four-company batch.
- Dark navy/gold cover.
- Dynamic company-count label on cover and DOCX subtitle: `Ein Unternehmen`
  for one ticker, otherwise `<ticker_count> Unternehmen`. Never hard-code
  `Vier Unternehmen` unless the visible count actually matches the run.
- One decision dashboard.
- One company page per ticker.
- One method/limits page.
- DOCX companion generated from the same prepared records.

Each company page must show:

- ticker
- rating badge
- trader signal badge
- model pair
- investment thesis
- trader view
- operative steps
- analyst summary
- portfolio context

Premium memo must be concise. It may summarize analyst reports, but it must
never be presented as the full source.

### Complete Dossier

Purpose: full reading and audit trail.

Required shape:

- Markdown, DOCX, and PDF.
- Full analyst body included for each ticker.
- All four analyst blocks included:
  - market/technical
  - sentiment/social
  - news/macro
  - fundamentals
- Trader-Sicht, Investment-Plan, and Finale Entscheidung included.
- Germanized section headings.
- Tables preserved where they fit.
- Very wide tables converted into readable row blocks rather than clipped.
- Major company sections start on clean section pages where practical:
  - `Sentiment und Marktstimmung`
  - `Nachrichten- und Makrolage`
  - `Fundamentale Lage`
  - `Trader-Sicht`
  - `Investment-Plan`
  - `Finale Entscheidung`
- PDF headings must use keep-with-next/minimum-rest-space behavior so a major
  heading or opening paragraph is not stranded at the bottom of a prior page.
- Short body paragraphs and compact tables should stay together instead of
  splitting one or two residual lines across page boundaries.
- No markdown control tokens visible in DOCX/PDF.

Completeness thresholds for a four-company run:

- Complete Markdown normally > 20,000 words.
- Complete DOCX extracted text must be at least 75% of Complete Markdown words.
- Complete PDF extracted text must be at least 75% of Complete Markdown words.
- Complete PDF normally between 35 and 120 pages.

For smaller tests, the quality gate scales thresholds by ticker count:

- One ticker complete PDF: normally at least 8 pages.
- One ticker premium PDF, when explicitly requested: normally 3-6 pages.
- Minimum complete Markdown words: `4,500 * ticker_count`, capped by the
  four-company threshold once the batch has four or more tickers.

If a complete dossier is shorter than its threshold, treat it as a failed build
unless there is a documented reason.

### Raw/Readable Reports

Raw/readable Markdown may preserve source wording for debugging. It is not a
final branded deliverable unless it passes the same label and layout QA.

## Quality Gates

Run this after every bundle build:

```bash
python scripts/room16_report_quality_gate.py \
  --run-dir .runtime/bcr-company-batches/<RUN_ID> \
  --reports-dir reports/room16/runs/<RUN_ID>/<TICKER> \
  --tickers <TICKER>
```

The quality gate must check:

- run manifest exists
- run status is completed
- every requested ticker has status `ok`
- every ticker log file exists
- all seven state fields are non-empty
- complete MD/DOCX/PDF exist
- complete word-count ratios pass
- complete page count is in range
- all tickers appear in every user-facing artifact
- premium DOCX/PDF exist and premium page count is in range only when
  `--require-premium` is passed
- premium memo company-count label matches the manifest ticker count only when
  premium is required
- forbidden English/raw labels are absent
- German umlauts are real characters, not ASCII fallback spellings like
  `fuer`, `ueber`, `oeffentlich`, `Pruefung`, `Qualitaet` or `Kapazitaet`
- visible markdown tokens, including code fences, are absent
- emoji placeholders or missing-glyph boxes are absent
- render-risk characters such as subscript digits, block-chart glyphs,
  unsupported arrows, narrow nonbreaking spaces, and single mathematical
  symbols are normalized before DOCX/PDF generation
- visible analyst draft thoughts and self-correction phrases are absent
- PDFs can be parsed and rendered; missing visual renderer is a blocker for
  green reports
- research-integrity contradictions are absent:
  - no `keine unternehmensspezifischen Nachrichten` claim when the report also
    contains earnings, filing, or guidance language
  - known material events configured for ticker/date are not missing
  - price-vs-moving-average narrative does not contradict its own numbers
- source-ledger readiness is recorded, and can be made blocking with
  `--strict-research-integrity`

Rendered QA outputs go to:

```text
reports/room16/runs/<RUN_ID>/<TICKER>/quality/rendered/YYYY-MM-DD-<bundle-id>/
```

The agent must visually inspect:

- complete dossier page 1
- complete dossier first company opening page
- one mid-document page
- one table-heavy page if present
- final page
- every premium PDF page only when premium was explicitly requested

The quality gate can render pages and validate text mechanically, but the agent
still has to inspect rendered images before saying the report is ready.

## Delivery Rules

When reporting completion to the operator, give the long-report links:

1. Complete PDF
2. Complete DOCX
3. Complete Markdown, when useful for inspection

Mention the quality status in one line:

```text
QA: Quality-Gate grün, Complete-PDF stichprobenhaft gerendert, keine sichtbaren Raw-Labels/Markdown-Tokens.
```

Never deliver only:

- a Markdown file
- only a DOCX without PDF/render QA
- only a PDF without the complete dossier

## Human Reading Shelf

The operator-facing reading shelf is:

```text
/Users/BjornRosinger/Documents/DreamFactory/Room16/Reports
```

Every completed ticker report must have a PDF reading copy there, grouped by
company. The bundle builder does this through
`scripts/room16_publish_report_shelf.py`.

LION/Vivi analysis requests that come through the Vivi chat are archived under:

```text
/Users/BjornRosinger/Documents/DreamFactory/Room16/Reports/_LION Vivi Analysis Chats/
```

Codex/Vega work notes for important Room 16 report runs can be placed under:

```text
/Users/BjornRosinger/Documents/DreamFactory/Room16/Reports/_Codex Chats/
```

## Standard Runbook

1. Confirm or discover the completed run directory.
2. If model capability is unknown, run:

```bash
python scripts/room16_model_smoke.py
python scripts/room16_model_matrix.py
```

3. Build the ticker-isolated report bundles in markdown-first QA mode:

```bash
python scripts/room16_build_report_bundle.py --run-dir <RUN_DIR>
```

4. Inspect each ticker quality report and Markdown dossier:

```bash
cat reports/room16/runs/<RUN_ID>/<TICKER>/quality/YYYY-MM-DD-room16-quality-report.md
```

5. Rendered images are listed in the quality report. Open them before final
delivery.
6. If any issue exists:
   - fix builder or source issue
   - rebuild bundle
   - rerun quality gate
   - re-render and reinspect
7. Update `BCR_REPORT_LAB.md`.
8. Update Obsidian `Project - Quellwert.md` and `Latest Session Context.md` for
durable changes.
9. Confirm that the final PDF reading copy exists in
   `~/Documents/DreamFactory/Room16/Reports/<Company> (<TICKER>)/`.

## Failure Modes And Required Fixes

### Premium Looks Good But Is Incomplete

Cause: premium memo is condensed by design.

Fix: deliver complete dossier alongside it. Do not expand premium into a 60-page
deck.

### Premium Built Without Request

Cause: the old bundle workflow generated overview memos automatically.

Fix:

- treat this as process drift, even if the premium file looks good
- rebuild with `scripts/room16_build_report_bundle.py --run-dir <RUN_DIR>`
  without `--with-premium`
- validate with the quality report metric `premium_required: False`
- deliver only the complete PDF/DOCX/Markdown unless the operator asks for a
  premium overview

### PDF Worse Than Markdown

Cause: report was not rendered/inspected, or portrait layout was used for a deck.

Fix:

- use landscape A4 for premium memo
- render all pages
- inspect every page
- reduce text density per card
- move full content to complete dossier

### DOCX Seems To Miss Information

Cause: a builder uses `_compact`, `_first_paragraph`, or max-character snippets.

Fix:

- classify the file as premium/summary, or
- rebuild with complete dossier builder
- verify word-count ratio against complete Markdown

### Tables Break PDF Layout

Cause: wide markdown tables cannot fit portrait PDF width.

Fix:

- preserve normal tables up to 5 columns
- convert wider or huge-cell tables into row blocks
- never clip table text

### Major Section Starts At Page Bottom

Cause: PDF flowables were allowed to continue compactly even when only a small
amount of page space remained.

Fix:

- add page breaks before major company sections where that improves reading
- use `keepWithNext` for headings
- use conditional page breaks before headings and compact tables
- keep short paragraphs/tables together to avoid orphaned one-line page tails
- accept a slightly longer complete dossier when it materially improves reading

### Markdown Syntax Visible In PDF

Cause: markdown parser missed headings, separators, or table rows.

Fix:

- treat `#`, `##`, `###` as headings
- treat `---` as spacing/rule, not body text
- convert markdown tables structurally
- rerun quality gate text scan

### English Raw Labels Visible

Cause: raw TradingAgents output passed through.

Fix:

- apply the required label mapping
- rerun language QA
- do not deliver until forbidden-label scan is clean

### Wrong Company Count On Cover

Cause: premium memo copy was hard-coded for the first four-company test.

Fix:

- derive cover and DOCX subtitle counts from the run manifest
- use `Ein Unternehmen` for one ticker and `<ticker_count> Unternehmen` for all
  larger batches
- rerun the quality gate and inspect the rendered premium cover before delivery

### Combined Report Built Without Explicit Request

Cause: a prior workflow treated a multi-ticker run as one bundled report.

Fix:

- delete or ignore the combined deliverable
- rebuild with `scripts/room16_build_report_bundle.py --run-dir <RUN_DIR>`
  without `--combine`
- verify each ticker folder independently
- deliver per-company links only

## Standard Definitions

`premium`: polished committee memo; concise.

`complete`: full analyst dossier; auditable.

`raw`: original TradingAgents logs and state fields; not a final deliverable.

`green`: completed run, artifacts exist, quality gate passes, rendered pages
exist and have been inspected by the agent.

`blocked`: missing model credentials, missing run data, missing renderer, failed
quality gate, or known layout defect.

## Institutional QA Layer

Room 16 now treats LLM output as draft material. Deterministic Python/rules own
all arithmetic, period/source metadata checks, date logic, stop/target direction
and rating/action consistency.

Implemented v1 artifacts:

- `tradingagents/quality/institutional.py`
- `tradingagents/quality/prompts.py`
- `tests/test_institutional_quality.py`
- `docs/ROOM16_INSTITUTIONAL_QA_UPGRADE.md`

Binding rules:

- every final report has exactly one official course/price basis
- every hard metric needs `source_id`, `period_type`, accounting basis and
  period end where applicable
- FCF must expose a formula and company-definition status
- Forward P/E/KGV requires EPS source, period and basis
- provider/consensus EPS and management guidance must be separated and compared
- large earnings gaps need earnings/guidance/management/sector explanation, not
  just distribution language
- vendor/social claims are sentiment only, never hard-fact evidence
- no-news claims require IR/SEC/media/vendor fallback checks
- long stops must be below current price, short stops above current price
- `Sell` cannot be used for a trim/core-hold action; use Tactical Trim or
  Tactical Underweight
- re-entry plans need tactical and strategic triggers; a 200-SMA-only re-entry
  far above spot is too late for nuanced risk management

Publication/client-grade runs should use:

```bash
python3 scripts/room16_report_quality_gate.py \
  --run-dir <RUN_DIR> \
  --reports-dir <REPORT_DIR> \
  --tickers <TICKER> \
  --strict-research-integrity
```

## Room 16 App Standard

The Room 16 UI is a separate local app, not part of LION:

`/Users/BjornRosinger/Documents/DreamFactory/Project-Intelligence-Graph/company-dossier-lab/room16-app`

Binding UI rules:

- read final PDFs from `/Users/BjornRosinger/Documents/DreamFactory/Room16/Reports`
- treat first-pass Markdown-only dossiers as valid QA report artifacts
- read canonical quality metadata from `reports/room16/runs/<RUN_ID>/<TICKER>/`
- create one queued ticker job per click
- never start multiple ticker builds in parallel
- never generate premium memos unless an explicit operator option enables them
- run `scripts/bcr_company_batch.py` first, then
  `scripts/room16_build_report_bundle.py`
- use Complete-only, markdown-first bundle defaults
- mirror successful final PDFs into the human shelf only after `--render-final-documents`
- show error reports only when a run fails
- write failure reports under `.runtime/room16-app/failures/`
- keep the UI quiet, table/list oriented, and free of tiny card grids
- use real German umlauts in visible German UI copy
- render PDFs inside the app with the Room 16 reader instead of relying on a
  browser PDF plugin
- expose the latest hardening cycle verdict in the app UI
- keep a dedicated hardening loop available through
  `room16-app/npm run hardening:once` and `room16-app/npm run hardening:loop`
- create unique report job IDs with a random suffix so accidental fast
  resubmits cannot collide
- serve report and failure files only after resolving real filesystem paths
  inside the allowed Room 16 roots

Verification before handoff:

- `npm run build` in `room16-app`
- `npm run verify` in `room16-app`
- `npm run hardening:once` in `room16-app`
- `/api/health` returns `ok: true`
- `/api/state` lists the shelf companies and latest quality metadata
- at least one PDF opens in the internal reader
- desktop and narrow mobile screenshots show no overlap or clipped controls

Hardening loop contract:

- one cycle runs build, API/PDF verification, desktop screenshot, and mobile
  screenshot
- artifacts live under `.runtime/room16-app/hardening/<CYCLE_ID>/`
- `.runtime/room16-app/hardening/latest-cycle.json` is the machine truth for
  the latest verdict
- the UI must show the latest hardening verdict even when the right run rail is
  hidden on narrower desktop widths
- generated path handling must use `fileURLToPath(import.meta.url)`; raw URL
  pathnames create broken `%20` filesystem paths when folders contain spaces
- verifier coverage must include API health, preflight, state, company/report
  presence, PDF serving, invalid job rejection, hardening status exposure, and
  outside-path rejection for report endpoints
