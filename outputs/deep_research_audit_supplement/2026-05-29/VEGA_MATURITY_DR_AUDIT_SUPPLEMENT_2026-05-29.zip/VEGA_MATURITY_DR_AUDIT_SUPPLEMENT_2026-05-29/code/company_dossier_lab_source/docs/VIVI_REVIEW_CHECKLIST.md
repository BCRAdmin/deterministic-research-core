# Vivi Review Checklist

Status: operational checklist for short Vivi reviews of Quellwert / Room 16
artifacts.

## Review Mode

- Review only the provided artifacts.
- Keep the output short.
- Do not implement.
- Do not propose new features unless the problem is systemic.
- Use `manual_human_review` when data is missing or ambiguous.

## Input Bundle Checklist

Confirm review metadata:

- [ ] `reviewer` is present.
- [ ] `schema_version` is present.
- [ ] `reviewed_at` is present.
- [ ] `bundle_id`, `ticker`, and `batch_id` are included when available.

Confirm presence and readability:

- [ ] `dashboard_status.json`
- [ ] `report_manifest.json`
- [ ] `quality_score.json`
- [ ] `decision_packet.json`
- [ ] `publish_report.md`
- [ ] `final_report.md`
- [ ] `evidence_report.md`
- [ ] `current_period_reconciliation_summary.md`
- [ ] `metrics_packet.json`
- [ ] `canonical_financials.json`
- [ ] `artifact_consistency_report.json`, if present

If a mandatory artifact is missing, record a blocking issue or
`manual_human_review`. Do not fill gaps from memory.

## Category Checks

### 1. Artifact Consistency

- [ ] Ticker, batch id, report id, price basis date, model/profile, and status
  agree across manifest, dashboard, quality, decision, and publish artifacts.
- [ ] `publishable`, `public_ready`, `manual_review`, and visibility labels do
  not conflict.
- [ ] Side artifacts are not stale relative to the manifest.
- [ ] `artifact_consistency_report.json` is either clean or its issues are
  reflected in the review output.

### 2. Evidence Coverage

- [ ] Material hard claims map to evidence.
- [ ] Current-period KPI claims are backed by current-period evidence.
- [ ] Primary evidence is present where required.
- [ ] Vendor-only hard metrics do not become publish-ready evidence.
- [ ] Missing evidence blocks publication even when prose is strong.

### 3. Financial Sanity

- [ ] Periods, units, TTM/quarter/YTD labels, denominators, and signs are sane.
- [ ] FCF, OCF, revenue, operating income, SBC, cash/debt, and guidance values
  do not contradict canonical financials.
- [ ] True anomalies are marked as review items rather than silently passed.
- [ ] Side-artifact staleness is not treated as a financial logic change.

### 4. Archetype Correctness

- [ ] Speculative deep-tech / early commercial companies do not pass cleanly
  without primary evidence and hard metric support.
- [ ] Mega-cap platforms are not incorrectly treated as speculative microcaps.
- [ ] Archetype labels and triggered rules match the underlying metrics.
- [ ] Guard outcomes are consistent across dashboard, quality, decision, and
  publish artifacts.

### 5. Rating Consistency

- [ ] Internal rating, public rating, external display rating, and decision
  packet agree.
- [ ] Manual-review display policy masks ratings where required.
- [ ] QCOM-style `Hold Pending FCF Support` stays visible when FCF support is
  missing.
- [ ] No public surface shows a stronger action than the gate permits.

### 6. Publish Report Quality

- [ ] `publish_report.md` is readable editorial prose, not system chatter.
- [ ] It avoids raw claim IDs, internal packet language, and implementation
  terminology in the main body.
- [ ] It includes current-period context, risks, non-advice framing, and
  evidence appendix where required.
- [ ] Weak writing with correct data is a writing-quality issue, not a reason to
  change financial logic.

### 7. Manual Review Correctness

- [ ] Missing data, missing primary evidence, stale side artifacts, and ambiguous
  gate states are not passed.
- [ ] Manual-review reasons are specific and mapped to artifacts.
- [ ] No guard is loosened simply because a report fails.
- [ ] False block candidates identify the precise stale artifact or guard input.

### 8. Staleness / Data Freshness

- [ ] Price basis date, report date, current-period evidence date, and manifest
  timestamps are coherent.
- [ ] Dashboard and publish stubs are not older than the reviewed bundle.
- [ ] Stale side artifacts are called out as Artifact Consistency issues.
- [ ] Staleness does not trigger investment-logic changes by itself.

### 9. False Pass / False Block Detection

- [ ] Any `passed` or `public_ready` item with missing evidence is listed in
  `false_pass_candidates`.
- [ ] Any `manual_review` item with complete evidence and consistent artifacts
  is listed in `false_block_candidates`.
- [ ] Each candidate includes the artifact evidence, expected status, and
  `confidence`.

## Output Checklist

- [ ] Output is valid JSON matching `docs/VIVI_REVIEW_OUTPUT_SCHEMA.json`.
- [ ] Output contains no markdown prose outside JSON.
- [ ] `review_metadata` contains `reviewer`, `schema_version`, and
  `reviewed_at`.
- [ ] Runtime validators enforce `reviewed_at` as `format: date-time`; Python
  validation uses `jsonschema.FormatChecker()`.
- [ ] Every `review_issue` contains `severity` and `confidence`.
- [ ] Every false pass / false block candidate contains `confidence`.
- [ ] `fix_list_for_codex` contains precise file/module, issue, expected
  behavior, acceptance test, do-not-touch boundaries, and `priority`.
- [ ] `do_not_change` protects correct guards and validated artifacts.
- [ ] `human_review_required` matches the review status and issues.

## Minimal Review Length

Preferred length is one compact JSON object. Avoid narrative explanations unless
they are inside an issue field.
