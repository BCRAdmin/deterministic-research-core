# Room16 Review-Gate Status Packet

## Zweck

Dieses Paket macht die Room16 Public-/Member-Gates maschinenlesbar, ohne die Library zu verändern. Es ist die führende lokale Evidence dafür, welche Reports offen in `manual_review` stehen, ob Public-/Member-Signale existieren und warum ein Lauf stoppen muss.

## Quelle

- Input: `company-dossier-lab/.runtime/room16-app/public-library/latest-library-status.md`
- Optionaler Kontext: `company-dossier-lab/.runtime/room16-app/public-library/report-library-state.json`
- Output JSON: `company-dossier-lab/.runtime/room16-app/review-gate-status/latest-review-gate-status.json`
- Output Markdown: `company-dossier-lab/.runtime/room16-app/review-gate-status/latest-review-gate-status.md`

## Verifier

```bash
cd company-dossier-lab/room16-app && npm run verify:review-gate-status
```

Der Verifier ist read-only. Er darf keine Sichtbarkeit ändern, keinen Room16-Rerun starten, keine Reports veröffentlichen, nichts löschen und keine externe Kommunikation auslösen.

## Statuslogik

- `PASS`: Struktur konsistent, keine offenen Manual-Review- oder Public-/Member-Signale.
- `WARN`: Struktur konsistent, aber es gibt offene lokale Review-Arbeit oder ein Go/No-Go-Signal.
- `FAIL`: Zählungen widersprechen sich, Gate/Effective-Visibility ist unsicher oder Public-Sichtbarkeit ist nicht sauber belegt.

## Pflichtfelder

- `schema_version`
- `generated_at`
- `status`
- `summary`
- `state_summary`
- `entries`
- `manual_review_entries`
- `operator_gate_required`
- `operator_gates`
- `runtime_action_executed`
- `next_safe_step`
- `stop_rule`
- `findings`
- `fail_count`
- `warn_count`

## PIG-Integration

PIG liest das JSON als Fresh-Data-Quelle `room16_review_gate_status`. Wenn `manual_review_entries` vorhanden sind, entsteht genau eine sichere Vivi Job Card. Der ältere Public-Library-Aggregatstatus bleibt Evidence, damit keine doppelten Claims für denselben Review-Block entstehen.

## Stop-Regel

Stop bei Public/Member-Sichtbarkeit, Room16-Rerun, Push, Publish, externer Kommunikation, Finanzpublishing, Production, Geld, Credentials/Auth oder Löschung. In diesen Fällen wird nur ein Go/No-Go-Paket vorbereitet; die Entscheidung bleibt beim Operator.
