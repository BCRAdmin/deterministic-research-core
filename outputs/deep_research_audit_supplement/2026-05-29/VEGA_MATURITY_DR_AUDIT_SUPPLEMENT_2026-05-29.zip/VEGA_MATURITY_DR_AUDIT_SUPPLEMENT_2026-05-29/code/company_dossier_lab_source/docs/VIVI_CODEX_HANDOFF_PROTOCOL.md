# Vivi to Codex Handoff Protocol

Status: binding handoff format for Vivi review findings.
Scope: Quellwert / Room 16 artifact reviews.

## Purpose

Vivi reviews. Codex fixes. Vega integrates and verifies when needed.

This protocol keeps Vivi from drifting into implementation while making Codex
fixes precise enough to execute without reinterpreting the whole report.

## Roles

### Vivi

- Reviews artifacts, reports, gates, and consistency.
- Produces short JSON output using `docs/VIVI_REVIEW_OUTPUT_SCHEMA.json`.
- Names false pass and false block candidates.
- Creates bounded fix lists for Codex.
- Protects correct guards through `do_not_change`.
- Escalates missing or ambiguous data to manual human review.

### Codex

- Implements the fix list.
- Changes only files/modules named in the fix item unless a new blocker is
  discovered.
- Preserves do-not-touch boundaries.
- Adds or runs acceptance tests named by the handoff.
- Reports which fix items were completed and which remain blocked.

### Vega

- Uses Vivi review output as a control input.
- Verifies Codex fixes against artifacts and gates.
- Does not treat a Vivi pass as publication approval unless the relevant
  Quellwert / Room 16 promotion gates also pass.

## Handoff Object

Every Codex-facing fix item must contain:

- precise file/module
- issue
- expected behavior
- acceptance test
- do-not-touch boundaries
- priority (`P0`, `P1`, `P2`, or `P3`)

Preferred item shape:

```json
{
  "file_or_module": "path/or/module",
  "issue": "Short issue statement.",
  "expected_behavior": "Observable corrected behavior.",
  "acceptance_test": "Command, artifact check, or review condition that proves the fix.",
  "do_not_touch_boundaries": [
    "Guard or artifact that must not be changed."
  ],
  "priority": "P1"
}
```

Every full Vivi review output also includes `review_metadata`, issue
`severity`, issue `confidence`, and candidate `confidence` as defined in
`docs/VIVI_REVIEW_OUTPUT_SCHEMA.json`.

The examples below are `codex_fix` items and validate against the schema's
`codex_fix` definition.

## Handoff Rules

- One issue per fix item.
- No vague fixes like `improve quality`.
- No broad refactors unless the same defect affects multiple artifacts through
  one shared module.
- No guard relaxation unless a human explicitly changes the product policy.
- If data is missing, ask for data or mark manual review; do not generate data.
- If Vivi output is machine-validated in Python, use
  `jsonschema.Draft202012Validator(schema, format_checker=jsonschema.FormatChecker())`
  so `review_metadata.reviewed_at` actually enforces `format: date-time`.
- If only a side artifact is stale, fix artifact generation or sync; do not
  change investment logic.
- If publish prose is good but evidence is missing, fix evidence coverage or
  block publication.
- If data is correct but prose is weak, fix writing quality only.

## Codex Acceptance

Codex may close a Vivi fix item only when all acceptance criteria are true:

1. The named file/module or artifact path was updated or regenerated.
2. The expected behavior is visible in the target artifact.
3. The acceptance test passes.
4. The do-not-touch boundaries were preserved.
5. No new false pass or false block candidate was introduced.

## Examples

### RGTI Deep-Tech Manual Review

Vivi output should protect the guard:

```json
{
  "file_or_module": "quality/deeptech_manual_review.py",
  "issue": "Do not convert RGTI-style speculative deep-tech manual review into pass.",
  "expected_behavior": "RGTI remains manual_human_review unless primary evidence and hard metrics support publication.",
  "acceptance_test": "RGTI review still lists SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE and publishable=false.",
  "do_not_touch_boundaries": [
    "Do not loosen speculative deep-tech guard.",
    "Do not mark vendor-only hard metrics as primary evidence."
  ],
  "priority": "P1"
}
```

### MSFT Stale Artifact Consistency

Vivi output should target stale artifacts, not financial logic:

```json
{
  "file_or_module": "outputs/<batch>/MSFT/dashboard_status.json",
  "issue": "Dashboard status still shows an older display/archetype label after the decision artifacts were corrected.",
  "expected_behavior": "Dashboard, quality score, decision packet, and publish stub show the same MSFT status and display rating.",
  "acceptance_test": "Artifact consistency review reports zero MSFT status/display mismatches.",
  "do_not_touch_boundaries": [
    "Do not change MSFT mega-cap financial sanity rule.",
    "Do not loosen evidence requirements."
  ],
  "priority": "P2"
}
```

### QCOM Hold Pending FCF Support

Vivi output should preserve the external display policy:

```json
{
  "file_or_module": "batch/display_policy.py",
  "issue": "Manual-review QCOM must not show plain Accumulate externally when FCF support is missing.",
  "expected_behavior": "External display remains Manual Review / Hold Pending FCF Support.",
  "acceptance_test": "QCOM dashboard and publish status both show Hold Pending FCF Support while FCF support is missing.",
  "do_not_touch_boundaries": [
    "Do not remove MISSING_FCF_SUPPORT_FOR_ACCUMULATE.",
    "Do not expose stronger public action labels during manual review."
  ],
  "priority": "P1"
}
```

### GOOGL Gold-v1 Pass

Vivi output should protect the Gold-v1 standard:

```json
{
  "file_or_module": "publish_report.md",
  "issue": "GOOGL pass requires publish prose, evidence appendix, current-period KPIs, and rating rationale to stay aligned.",
  "expected_behavior": "GOOGL remains pass only when all Gold-v1 artifact checks are consistent.",
  "acceptance_test": "Vivi review returns pass with no blocking issues and no false pass candidates.",
  "do_not_touch_boundaries": [
    "Do not remove current-period KPI requirements.",
    "Do not remove non-advice framing."
  ],
  "priority": "P3"
}
```

### SNOW Gold-v1 Pass

Vivi output should protect wording consistency:

```json
{
  "file_or_module": "publish_report.md",
  "issue": "SNOW publish language must not contradict its decision packet or external display status.",
  "expected_behavior": "Publish prose, decision packet, dashboard status, and evidence report use one consistent hold/underweight-bias framing.",
  "acceptance_test": "Vivi review returns pass and artifact consistency shows no SNOW rating/display mismatch.",
  "do_not_touch_boundaries": [
    "Do not weaken evidence mapping.",
    "Do not change the rating solely for writing polish."
  ],
  "priority": "P3"
}
```
