# Room16 Review Queue Packet Schema 2026-05-18

## Zweck

Das Queue Packet ist das operative Review-Protokoll für ein Room16-Dossier. Es macht sichtbar, warum ein Dossier intern bleibt, welche manuelle Aktion als nächstes ansteht und ob Operator-Go erforderlich ist.

Das Schema ist keine Public-Freigabe, keine Publishing-Automation und keine Anlageberatung. Es dokumentiert Review-Entscheidungen für die interne Workbench.

## Schema

| Feld | Typ | Pflicht | Bedeutung |
| --- | --- | --- | --- |
| `ticker` | string | ja | Börsenkürzel oder internes Symbol des Dossiers. |
| `dossierId` | string | ja | Stabile Dossier-ID oder Report-ID. |
| `generationStage` | string | ja | Pipeline-Stufe, zum Beispiel `ingested`, `draft_markdown_qa`, `internal_best` oder `public_final`. |
| `gateStatus` | string | ja | Ergebnis aus `evaluatePublicLibraryGate`, zum Beispiel `manual_review`, `internal_only`, `rejected`, `needs_human_review` oder `public_ready`. |
| `blockers` | array | ja | Liste offener Blocker mit Kategorie `source`, `audit`, `render`, `provider`, `data` oder `promotion`. |
| `warnings` | array | ja | Nicht-blockierende Hinweise aus Gate, Pipeline oder Review. |
| `nextManualAction` | string | ja | Konkreter nächster manueller Schritt für Reviewer oder Operator. |
| `reviewer` | string | ja | Menschlicher Reviewer oder `unassigned`. |
| `sourceVerificationStatus` | string | ja | `missing`, `pipeline_verified`, `human_verified` oder `rejected`. |
| `nonAdviceStatus` | string | ja | `missing`, `confirmed` oder `rejected`. |
| `promotionStatus` | string | ja | `not_ready`, `blocked`, `approved_internal` oder `public_ready`. |
| `operatorGoRequired` | boolean | ja | `true`, wenn eine Public-Entscheidung möglich oder angefragt ist; bis dahin bleibt Public geschlossen. |

## Blocker Objekt

Jeder Eintrag in `blockers` sollte diese Struktur nutzen:

```json
{
  "category": "promotion",
  "reason": "promotion_non_advice_missing",
  "severity": "blocking",
  "note": "Non-advice confirmation is missing."
}
```

Erlaubte Kategorien sind:

- `source`
- `audit`
- `render`
- `provider`
- `data`
- `promotion`

## Statuswerte

`sourceVerificationStatus`:

- `missing`: keine ausreichende Quellenprüfung dokumentiert.
- `pipeline_verified`: Pipeline hat Quellen erkannt, aber kein Mensch hat sie final geprüft.
- `human_verified`: Menschliche Quellenprüfung ist dokumentiert.
- `rejected`: Quellen tragen die Aussage nicht.

`nonAdviceStatus`:

- `missing`: Non-Advice wurde nicht bestätigt.
- `confirmed`: Non-Advice wurde menschlich bestätigt.
- `rejected`: Advice-Risiko oder unzulässige Handlungsempfehlung.

`promotionStatus`:

- `not_ready`: Promotion-Stack ist noch nicht vollständig.
- `blocked`: Ein Promotion-Blocker ist offen.
- `approved_internal`: Interne Review ist bestanden, Public bleibt aber geschlossen.
- `public_ready`: Promotion-Stack kann vollständig sein; Operator-Go bleibt separat erforderlich.

## Invarianten

- `operatorGoRequired` bleibt `true`, sobald `promotionStatus` oder `gateStatus` `public_ready` ist.
- `gateStatus: "public_ready"` erzeugt keine Public-Automation.
- `generationStage: "draft_markdown_qa"` bleibt intern.
- `generationStage: "internal_best"` bleibt intern.
- `gateStatus: "manual_review"` bleibt hidden.
- `sourceVerificationStatus` muss `human_verified` sein, bevor Public überhaupt entschieden werden darf.
- `nonAdviceStatus` muss `confirmed` sein, bevor Public überhaupt entschieden werden darf.
- Offene `source`, `audit`, `render`, `provider`, `data` oder `promotion` Blocker verhindern Public.

## Beispiel

```json
{
  "ticker": "RGTI",
  "dossierId": "room16-rgti-2026-05-18",
  "generationStage": "internal_best",
  "gateStatus": "internal_only",
  "blockers": [
    {
      "category": "promotion",
      "reason": "internal_best_not_public",
      "severity": "blocking",
      "note": "Internal-best artifact is not public."
    },
    {
      "category": "source",
      "reason": "promotion_sources_human_verified_missing",
      "severity": "blocking",
      "note": "Human Source Verification is still open."
    }
  ],
  "warnings": [
    "not_public_final_stage"
  ],
  "nextManualAction": "Complete human source verification and keep internal.",
  "reviewer": "unassigned",
  "sourceVerificationStatus": "missing",
  "nonAdviceStatus": "missing",
  "promotionStatus": "blocked",
  "operatorGoRequired": true
}
```

Dieses Beispiel bleibt hidden. Es ist kein Public-Release, kein Provider-Auftrag und keine Anlageberatung.
