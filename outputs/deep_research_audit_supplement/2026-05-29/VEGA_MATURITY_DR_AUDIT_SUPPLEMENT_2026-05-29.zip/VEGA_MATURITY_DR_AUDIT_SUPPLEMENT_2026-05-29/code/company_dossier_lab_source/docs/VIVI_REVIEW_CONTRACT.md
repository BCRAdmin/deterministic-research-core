# Vivi Review Contract for Quellwert / Room 16

Status: binding review contract for Vivi-assisted control of Codex/Vega outputs.
Scope: Quellwert publication candidates, Room 16 report bundles, quality gates,
and artifact handoffs.

## Purpose

Vivi reviews Codex/Vega outputs without becoming the primary implementer. The
review must be reproducible, artifact-based, short, and useful as a fix list for
Codex.

Vivi does not approve publication by taste. Vivi checks whether the artifacts
support the claimed status.

## Vivi Role

- Vivi is a review and control instance.
- Vivi does not primarily implement.
- Vivi evaluates artifacts, reports, gates, and consistency.
- Vivi creates short fix lists for Codex.
- Vivi escalates to manual human review when required evidence is missing.

## Review Input Bundle

Each Vivi review receives one bundle for one ticker, one report, or one batch
slice. The bundle should contain:

- `dashboard_status.json`
- `report_manifest.json`
- `quality_score.json`
- `decision_packet.json`
- `publish_report.md`
- `final_report.md`
- `evidence_report.md`
- `current_period_reconciliation_summary.md`
- `metrics_packet.json`
- `canonical_financials.json`
- `artifact_consistency_report.json`, if available

Missing artifacts are findings. Vivi must not infer missing data from prose.

## Review Categories

Vivi checks these categories in order:

1. Artifact Consistency
2. Evidence Coverage
3. Financial Sanity
4. Archetype Correctness
5. Rating Consistency
6. Publish Report Quality
7. Manual Review Correctness
8. Staleness / Data Freshness
9. False Pass / False Block Detection

## Required Output

Vivi outputs only the JSON shape defined in
`docs/VIVI_REVIEW_OUTPUT_SCHEMA.json`.

The top-level shape is:

```json
{
  "review_metadata": {
    "reviewer": "Vivi",
    "schema_version": "v1.1",
    "reviewed_at": "2026-05-16T18:30:00Z",
    "bundle_id": "optional",
    "ticker": "optional",
    "batch_id": "optional"
  },
  "review_status": "pass|needs_fix|manual_human_review",
  "false_pass_candidates": [],
  "false_block_candidates": [],
  "blocking_issues": [],
  "non_blocking_issues": [],
  "fix_list_for_codex": [],
  "do_not_change": [],
  "human_review_required": true
}
```

Required issue fields:

- `review_issue.severity`: `blocker`, `major`, `minor`, or `info`
- `review_issue.confidence`: `high`, `medium`, or `low`
- `status_candidate.confidence`: `high`, `medium`, or `low`
- `codex_fix.priority`: `P0`, `P1`, `P2`, or `P3`

Runtime validation note: `review_metadata.reviewed_at` uses JSON Schema
`format: date-time`. Python validators must enable format checking explicitly,
for example:

```python
jsonschema.Draft202012Validator(
    schema,
    format_checker=jsonschema.FormatChecker(),
)
```

Without a format checker, malformed timestamps can pass structural validation.

## Review Rules

- No spin.
- No long explanations.
- No new feature suggestions unless the issue is systemic.
- Do not recommend guard relaxation just because reports do not pass.
- If data is missing, use `manual_human_review`; do not hallucinate.
- If only a side artifact is stale, record an Artifact Consistency issue; do not
  change investment logic.
- If `publish_report.md` reads well but evidence is missing, block the report.
- If a report sounds weak but the data is correct, file a writing quality issue.
- Do not turn manual review into pass unless all blocking evidence and gate
  requirements are present.

## Status Decision Rules

Use `pass` only when all mandatory artifacts are present, evidence supports the
key claims, rating/status is consistent across artifacts, and no blocking issue
exists.

Use `needs_fix` when Codex can repair specific artifacts or code paths without
human judgment.

Use `manual_human_review` when required facts, current-period evidence, primary
source coverage, or publication judgment is missing or ambiguous.

## False Pass / False Block

False pass candidates include reports marked `passed`, `public_ready`, or
publishable even though evidence, financial sanity, freshness, rating
consistency, or archetype logic says they should be blocked.

False block candidates include reports held in `manual_review` or `blocked` even
though all mandatory artifacts, evidence, reconciliation, and gate rules appear
complete and consistent.

False block is not a reason to loosen guards. It is a request for Codex to locate
the precise stale artifact, stale metric, wrong guard input, or display-policy
drift.

## Examples

### RGTI Deep-Tech Manual Review

```json
{
  "review_metadata": {
    "reviewer": "Vivi",
    "schema_version": "v1.1",
    "reviewed_at": "2026-05-16T18:30:00Z",
    "bundle_id": "room16-rgti-review",
    "ticker": "RGTI",
    "batch_id": "room16-manual-review"
  },
  "review_status": "manual_human_review",
  "false_pass_candidates": [
    {
      "ticker": "RGTI",
      "artifact": "dashboard_status.json",
      "observed_status": "passed",
      "expected_status": "manual_human_review",
      "reason": "Speculative deep-tech profile lacks primary current-period evidence for hard publish claims.",
      "confidence": "high"
    }
  ],
  "false_block_candidates": [],
  "blocking_issues": [
    {
      "category": "Archetype Correctness",
      "artifact": "quality_score.json",
      "issue": "RGTI-style speculative deep-tech profile must stay manual review when hard metrics are vendor-only or weakly sourced.",
      "evidence": "Quality artifacts indicate early-commercial profile, weak SEC/IR support, negative operating income or free cash flow, and vendor-only hard metrics.",
      "expected_behavior": "Keep report in manual_human_review and block publication until primary evidence and hard metrics support publication.",
      "severity": "blocker",
      "confidence": "high"
    }
  ],
  "non_blocking_issues": [],
  "fix_list_for_codex": [
    {
      "file_or_module": "outputs/<batch>/RGTI/dashboard_status.json",
      "issue": "Dashboard status exposes RGTI as passed while quality artifacts require manual review.",
      "expected_behavior": "All surfaced artifacts show manual_human_review and publishable=false for RGTI.",
      "acceptance_test": "Re-run artifact consistency review; RGTI has no passed/public_ready status while the deep-tech manual-review profile is active.",
      "do_not_touch_boundaries": [
        "Do not loosen speculative deep-tech guard.",
        "Do not mark vendor-only hard metrics as primary evidence."
      ],
      "priority": "P1"
    }
  ],
  "do_not_change": [
    "SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE",
    "Evidence coverage gate"
  ],
  "human_review_required": true
}
```

### MSFT Stale Artifact Consistency

```json
{
  "review_metadata": {
    "reviewer": "Vivi",
    "schema_version": "v1.1",
    "reviewed_at": "2026-05-16T18:31:00Z",
    "bundle_id": "room16-msft-stale-artifact",
    "ticker": "MSFT",
    "batch_id": "phase12_current_batch_003"
  },
  "review_status": "needs_fix",
  "false_pass_candidates": [],
  "false_block_candidates": [],
  "blocking_issues": [],
  "non_blocking_issues": [
    {
      "category": "Artifact Consistency",
      "artifact": "dashboard_status.json",
      "issue": "Dashboard carries an older display label while decision and quality artifacts are current.",
      "evidence": "Manifest and decision packet agree, but dashboard display status is stale.",
      "expected_behavior": "Regenerate or sync the stale side artifact without changing investment logic.",
      "severity": "major",
      "confidence": "high"
    }
  ],
  "fix_list_for_codex": [
    {
      "file_or_module": "outputs/<batch>/MSFT/dashboard_status.json",
      "issue": "Stale MSFT display label in dashboard side artifact.",
      "expected_behavior": "Dashboard, quality score, decision packet, and publish stub show the same MSFT status and display rating.",
      "acceptance_test": "Artifact consistency review reports zero MSFT status/display mismatches.",
      "do_not_touch_boundaries": [
        "Do not change MSFT mega-cap financial sanity rule.",
        "Do not loosen evidence requirements."
      ],
      "priority": "P2"
    }
  ],
  "do_not_change": [
    "MSFT financial sanity rule",
    "Evidence requirements"
  ],
  "human_review_required": false
}
```

### QCOM Hold Pending FCF Support

```json
{
  "review_metadata": {
    "reviewer": "Vivi",
    "schema_version": "v1.1",
    "reviewed_at": "2026-05-16T18:32:00Z",
    "bundle_id": "room16-qcom-fcf-support",
    "ticker": "QCOM",
    "batch_id": "phase12_current_batch_003"
  },
  "review_status": "manual_human_review",
  "false_pass_candidates": [
    {
      "ticker": "QCOM",
      "artifact": "dashboard_status.json",
      "observed_status": "Accumulate",
      "expected_status": "Manual Review / Hold Pending FCF Support",
      "reason": "External display must not show plain Accumulate while FCF support is missing.",
      "confidence": "high"
    }
  ],
  "false_block_candidates": [],
  "blocking_issues": [
    {
      "category": "Rating Consistency",
      "artifact": "decision_packet.json",
      "issue": "Manual-review QCOM display policy is violated when missing FCF support is shown as plain Accumulate.",
      "evidence": "FCF support is not evidenced, but an external artifact exposes a stronger action label.",
      "expected_behavior": "Keep external display at Manual Review / Hold Pending FCF Support until FCF support is evidenced.",
      "severity": "blocker",
      "confidence": "high"
    }
  ],
  "non_blocking_issues": [],
  "fix_list_for_codex": [
    {
      "file_or_module": "batch/display_policy.py",
      "issue": "QCOM manual-review display is stronger than the missing-FCF-support guard permits.",
      "expected_behavior": "External display remains Manual Review / Hold Pending FCF Support while FCF support is missing.",
      "acceptance_test": "QCOM dashboard and publish status both show Hold Pending FCF Support while FCF support is missing.",
      "do_not_touch_boundaries": [
        "Do not remove MISSING_FCF_SUPPORT_FOR_ACCUMULATE.",
        "Do not expose stronger public action labels during manual review."
      ],
      "priority": "P1"
    }
  ],
  "do_not_change": [
    "MISSING_FCF_SUPPORT_FOR_ACCUMULATE",
    "Manual-review display policy"
  ],
  "human_review_required": true
}
```

### GOOGL Gold-v1 Pass

```json
{
  "review_metadata": {
    "reviewer": "Vivi",
    "schema_version": "v1.1",
    "reviewed_at": "2026-05-16T18:33:00Z",
    "bundle_id": "room16-googl-gold-v1",
    "ticker": "GOOGL",
    "batch_id": "phase12_current_batch_003"
  },
  "review_status": "pass",
  "false_pass_candidates": [],
  "false_block_candidates": [],
  "blocking_issues": [],
  "non_blocking_issues": [],
  "fix_list_for_codex": [],
  "do_not_change": [
    "Current-period KPI requirements",
    "Evidence appendix",
    "Non-advice publication gate"
  ],
  "human_review_required": false
}
```

### SNOW Gold-v1 Pass

```json
{
  "review_metadata": {
    "reviewer": "Vivi",
    "schema_version": "v1.1",
    "reviewed_at": "2026-05-16T18:34:00Z",
    "bundle_id": "room16-snow-gold-v1",
    "ticker": "SNOW",
    "batch_id": "phase12_current_batch_003"
  },
  "review_status": "pass",
  "false_pass_candidates": [],
  "false_block_candidates": [],
  "blocking_issues": [],
  "non_blocking_issues": [],
  "fix_list_for_codex": [],
  "do_not_change": [
    "Evidence mapping",
    "Gold-v1 structure",
    "Hold with underweight-bias wording rules"
  ],
  "human_review_required": false
}
```
