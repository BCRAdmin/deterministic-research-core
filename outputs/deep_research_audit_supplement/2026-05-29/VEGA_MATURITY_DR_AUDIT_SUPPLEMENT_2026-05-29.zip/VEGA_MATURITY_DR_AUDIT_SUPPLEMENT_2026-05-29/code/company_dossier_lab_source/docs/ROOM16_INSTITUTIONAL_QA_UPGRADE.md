# Room 16 Institutional QA Upgrade

Source pack: `/Users/BjornRosinger/Documents/DreamFactory/Room16/research-agent-ops/outputs/source_inputs/stock_agent_codex_pack_2026-05-05/`

Date ingested: 2026-05-05

## Adopted Operating Model

Room 16 treats DeepSeek/Ollama reports as draft-producing analyst material, not
as final truth. The hard split is:

- LLM agents interpret and draft claims.
- Python/rules calculate and validate numbers, dates, source tiers, period
  labels, and logic.
- A future committee/reviewer layer may synthesize only validated claims.

## Implemented v1 Scope

- `tradingagents/quality/institutional.py` defines the core Room 16 QA
  primitives: source tiers, period types, accounting basis, data packets,
  metrics, claims, institutional ratings, rating decisions, report issues, and
  deterministic validators.
- `tradingagents/quality/prompts.py` adds shared institutional guardrails for
  analyst/trader prompts.
- `scripts/room16_report_quality_gate.py` now runs the institutional regression
  suite and scans final report text for critical institutional QA failures:
  SBC-as-cash-outflow, missing FCF definition, Forward P/E without EPS source,
  and missing source/period metadata in period-sensitive reports.
- `tests/test_institutional_quality.py` covers the report-review regression
  cases from the pack.

## Regression Cases Now Locked

- DDOG: long position at 132 with stop-loss 140 blocks.
- NVDA: FCF quarters `[26.19, 13.47, 22.12, 34.90]` vs reported `58.1` blocks.
- MDB: news dated `2026-04-23` claimed as cause of `2026-04-30` price move warns
  until same-day reaction and alternatives are checked.
- MDB: report date `2026-05-01` with `2026-04-30` close basis warns unless later
  close/intraday data is explicitly checked or excluded.
- MDB: provider/consensus EPS around `7.05` vs management FY2027 non-GAAP EPS
  guidance `5.75-5.93` warns unless the source/basis gap is discussed.
- MDB: company-defined FCF blocks if finance-lease principal payments are ignored.
- MDB: a 20%+ earnings gap cannot be explained as pure distribution without
  earnings/guidance/management/sector checks.
- MDB: a re-entry rule only near the 200-SMA/315 USD zone warns if no earlier
  tactical trigger exists.
- AMZN class: no-news claims require fallback checks before final prose.
- Sell vs trim/core-hold mismatch blocks.

## Remaining v2 Work

- Build a real Data Packet Builder that emits `DataPacket` JSON before LLM
  drafting.
- Move TTM/FCF/SBC/net-cash calculations from prose/tool output into a Metric
  Engine artifact.
- Force JSON claim ledgers from each sub-agent instead of relying on prose scans.
- Add a final committee renderer that can only consume validated claims.
