const deskSignals = [
  ["Heute", "3 Ticker fertig"],
  ["Queue", "1 Lauf aktiv"],
  ["Quality", "alle grün"],
  ["Shelf", "finale PDFs"],
];

const queueRows = [
  ["MU", "fertig", "Dossier + QA"],
  ["ANET", "wartet", "nächster Lauf"],
  ["CEG", "wartet", "nach ANET"],
];

const dossierFacts = [
  ["Urteil", "Underweight"],
  ["Signal", "Vorsicht"],
  ["Modell", "DeepSeek V4 Pro"],
  ["PDF", "19 Seiten"],
];

export function Room16Mockups() {
  return (
    <main className="room16Mockups">
      <section className="rmHero">
        <div>
          <p className="rmKicker">Room 16 Mockups</p>
          <h1>Research Desk statt Board.</h1>
          <div className="rmNav">
            <a href="#desk">Desk</a>
            <a href="#run">Run</a>
            <a href="#dossier">Dossier</a>
          </div>
        </div>
        <aside className="rmHeroMeta">
          <div className="rmTinyCard">
            <span>Modus</span>
            <strong>Mockups only</strong>
          </div>
          <div className="rmTinyCard">
            <span>Ziel</span>
            <strong>Room 16 App</strong>
          </div>
        </aside>
      </section>

      <section id="desk" className="rmSection">
        <div className="rmSectionHead">
          <div>
            <p className="rmEyebrow">Mockup 01</p>
            <h2>Desk</h2>
          </div>
          <small>ruhiger Überblick</small>
        </div>

        <div className="rmSignalGrid">
          {deskSignals.map(([label, value]) => (
            <article key={label} className="rmSignalCard">
              <span>{label}</span>
              <strong>{value}</strong>
            </article>
          ))}
        </div>

        <div className="rmDeskLayout">
          <section className="rmShelfPanel">
            <div className="rmPanelHead">
              <span>Research Shelf</span>
              <strong>Lesen statt suchen</strong>
            </div>
            <div className="rmShelfList">
              <article className="rmShelfRow">
                <strong>Micron Technology</strong>
                <small>vollständig · QA grün</small>
              </article>
              <article className="rmShelfRow">
                <strong>Microsoft</strong>
                <small>fertig · im Regal</small>
              </article>
              <article className="rmShelfRow">
                <strong>Palantir</strong>
                <small>fertig · im Regal</small>
              </article>
            </div>
          </section>

          <aside className="rmSideStack">
            <article className="rmSideCard">
              <span>Neuer Lauf</span>
              <strong>1 Ticker</strong>
              <small>kein Sammelreport</small>
            </article>
            <article className="rmSideCard">
              <span>Reader</span>
              <strong>PDF direkt im Tool</strong>
              <small>kein Tab-Chaos</small>
            </article>
          </aside>
        </div>
      </section>

      <section id="run" className="rmSection">
        <div className="rmSectionHead">
          <div>
            <p className="rmEyebrow">Mockup 02</p>
            <h2>Run</h2>
          </div>
          <small>ein Ticker pro Lauf</small>
        </div>

        <div className="rmRunShell">
          <div className="rmRunTop">
            <div className="rmInputMock">Ticker: MU</div>
            <button type="button">Run starten</button>
          </div>
          <div className="rmQueueTable">
            {queueRows.map(([ticker, status, note]) => (
              <article key={ticker} className="rmQueueRow">
                <strong>{ticker}</strong>
                <span>{status}</span>
                <small>{note}</small>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="dossier" className="rmSection">
        <div className="rmSectionHead">
          <div>
            <p className="rmEyebrow">Mockup 03</p>
            <h2>Dossier</h2>
          </div>
          <small>reader first</small>
        </div>

        <div className="rmDossierLayout">
          <section className="rmReaderFrame">
            <div className="rmReaderTop">
              <strong>Micron Technology · MU</strong>
              <span>Complete Dossier</span>
            </div>
            <div className="rmReaderBody">
              <div className="rmReaderPage">PDF / Inhaltsseite / Kernaussage</div>
            </div>
          </section>

          <aside className="rmFactRail">
            {dossierFacts.map(([label, value]) => (
              <article key={label} className="rmFactCard">
                <span>{label}</span>
                <strong>{value}</strong>
              </article>
            ))}
          </aside>
        </div>
      </section>
    </main>
  );
}
