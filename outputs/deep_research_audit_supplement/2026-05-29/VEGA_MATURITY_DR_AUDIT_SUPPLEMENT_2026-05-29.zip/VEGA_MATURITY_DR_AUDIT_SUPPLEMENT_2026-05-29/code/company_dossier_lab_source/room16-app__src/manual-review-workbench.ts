export type ManualReviewWorkbenchStatus =
  | "ingested"
  | "audit_failed"
  | "review_ready"
  | "manual_review"
  | "approved_internal"
  | "promotion_blocked"
  | "public_ready";

type ManualReviewGate = {
  status?: string | null;
  effectiveVisibility?: string | null;
  blockers?: string[];
  warnings?: string[];
};

export type ManualReviewWorkbenchEntry = {
  qualityVerdict?: string | null;
  qualityStatus?: string | null;
  reviewStatusMetric?: string | null;
  generationStage?: string | null;
  renderMode?: string | null;
  finalDocumentsRendered?: boolean | null;
  publicReady?: boolean | null;
  publishable?: boolean | null;
  manualReviewReasons?: string[];
  promotionGateVerdict?: string | null;
  publishGateVerdict?: string | null;
  sourceStatus?: string | null;
  reviewStatus?: string | null;
  visibility?: string | null;
  nonAdvice?: boolean | null;
  qualityGate: ManualReviewGate;
};

export const MANUAL_REVIEW_STATUS_LABELS: Record<ManualReviewWorkbenchStatus, string> = {
  ingested: "Eingang prüfen",
  audit_failed: "Audit-Fund prüfen",
  review_ready: "Review abschließen",
  manual_review: "Manual Review bearbeiten",
  approved_internal: "Intern freigegeben",
  promotion_blocked: "Promotion blockiert",
  public_ready: "Public Final geprüft"
};

export const MANUAL_REVIEW_STATUS_ORDER: Record<ManualReviewWorkbenchStatus, number> = {
  manual_review: 0,
  audit_failed: 1,
  promotion_blocked: 2,
  review_ready: 3,
  approved_internal: 4,
  ingested: 5,
  public_ready: 6
};

const GATE_REASON_LABELS: Record<string, string> = {
  final_documents_not_rendered: "Final-PDF/DOCX fehlen",
  human_review_open: "Human Review offen",
  internal_best_not_public: "Internal Best ist intern, nicht public",
  manual_review_required: "Manual Review ist bindend",
  markdown_first_qa_not_public: "Markdown-QA ist kein Public-Artefakt",
  non_advice_policy_missing: "Non-Advice-Bestätigung fehlt",
  pdf_missing: "PDF fehlt",
  promotion_approved_at_missing: "Promotion-Freigabedatum fehlt",
  promotion_blocking_issues: "Promotion hat offene Blocker",
  promotion_non_advice_missing: "Promotion ohne Non-Advice-Bestätigung",
  promotion_not_public_ready: "Promotion ist nicht public-ready",
  promotion_requested_visibility_not_public: "Promotion-Sichtbarkeit ist nicht public",
  promotion_reviewed_by_missing: "Promotion Reviewer fehlt",
  promotion_sources_human_verified_missing: "Human Source Verification fehlt",
  publish_report_missing: "Publish Report fehlt",
  quality_failed: "Quality Gate rot",
  qa_pass_is_not_public_ready: "QA-Pass ist keine Public-Freigabe",
  sources_not_human_verified: "Quellen nicht human-verifiziert",
  sources_not_pipeline_verified: "Quellen nicht pipeline-verifiziert",
  final_pdf_not_rendered: "Final-PDF fehlt",
  markdown_missing: "Markdown fehlt",
  not_public_final_stage: "Pipeline ist nicht Public Final",
  not_publishable_without_manual_resolution: "Manuelle Klärung erforderlich",
  pipeline_quality_not_passed: "Pipeline-Qualität nicht bestanden"
};

export function gateReasonLabel(reason: string) {
  return GATE_REASON_LABELS[reason] || reason.replace(/_/g, " ");
}

function hasPromotionBlocker(entry: ManualReviewWorkbenchEntry) {
  return (entry.qualityGate.blockers || []).some((blocker) => blocker.startsWith("promotion_")) ||
    entry.promotionGateVerdict === "blocked";
}

export function manualReviewStatusFor(entry: ManualReviewWorkbenchEntry): ManualReviewWorkbenchStatus {
  if (entry.qualityGate.status === "public_ready") {
    return "public_ready";
  }
  if (entry.qualityGate.status === "manual_review" || entry.reviewStatusMetric === "manual_review") {
    return "manual_review";
  }
  if (entry.qualityVerdict === "fail" || entry.sourceStatus === "qa_failed") {
    return "audit_failed";
  }
  if (hasPromotionBlocker(entry)) {
    return "promotion_blocked";
  }
  if (entry.reviewStatus === "reviewed" && entry.sourceStatus === "human_verified" && entry.nonAdvice === true) {
    return "approved_internal";
  }
  if (entry.qualityGate.status === "needs_human_review" || entry.sourceStatus === "pipeline_verified") {
    return "review_ready";
  }
  return "ingested";
}

export function manualReviewReasonLines(entry: ManualReviewWorkbenchEntry) {
  const blockers = entry.qualityGate.blockers || [];
  const warnings = entry.qualityGate.warnings || [];
  const manualReasons = (entry.manualReviewReasons || [])
    .filter(Boolean)
    .map((reason) => `manual_review_reasons: ${reason}`);
  const reasons = [...manualReasons, ...blockers.map(gateReasonLabel), ...warnings.map(gateReasonLabel)];
  return Array.from(new Set(reasons));
}

export function manualReviewGateSummary(entry: ManualReviewWorkbenchEntry) {
  const blockers = entry.qualityGate.blockers?.length || 0;
  const warnings = entry.qualityGate.warnings?.length || 0;
  return `${blockers} Blocker / ${warnings} Hinweise`;
}

export function manualReviewNextAction(entry: ManualReviewWorkbenchEntry) {
  const blockers = new Set(entry.qualityGate.blockers || []);
  const warnings = new Set(entry.qualityGate.warnings || []);

  if (entry.qualityGate.status === "public_ready") {
    return "Promotion-Status prüfen, dann Operator-Go dokumentieren";
  }
  if (blockers.has("manual_review_required")) {
    return "Manual-Review-Gründe bearbeiten; Public bleibt hidden";
  }
  if (blockers.has("quality_failed")) {
    return "Quality-Report prüfen; Public bleibt gesperrt";
  }
  if (blockers.has("markdown_first_qa_not_public")) {
    return "Markdown öffnen und QA-Artefakte prüfen";
  }
  if (blockers.has("internal_best_not_public")) {
    return "Internal Best öffnen; Promotion separat prüfen";
  }
  if (blockers.has("promotion_non_advice_missing") || blockers.has("non_advice_policy_missing")) {
    return "Non-Advice bestätigen, bevor Promotion möglich ist";
  }
  if (blockers.has("promotion_sources_human_verified_missing") || warnings.has("sources_not_human_verified")) {
    return "Human Source Verification abschließen";
  }
  if (blockers.has("promotion_reviewed_by_missing") || warnings.has("human_review_open")) {
    return "Operator Review abschließen";
  }
  if (blockers.has("final_documents_not_rendered") || warnings.has("final_pdf_not_rendered")) {
    return "Finaldokumente rendern, bevor Public möglich ist";
  }
  if (hasPromotionBlocker(entry)) {
    return "Promotion-Stack-Blocker klären";
  }
  return "Intern halten, bis Review Packet vollständig ist";
}
