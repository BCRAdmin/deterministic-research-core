import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  ArrowLeft,
  Copy,
  ExternalLink,
  FileText,
  Play,
  RefreshCw,
  Search,
  StopCircle,
  Trash2
} from "lucide-react";
import { Room16Mockups } from "./Room16Mockups";
import {
  MANUAL_REVIEW_STATUS_LABELS,
  MANUAL_REVIEW_STATUS_ORDER,
  manualReviewGateSummary,
  manualReviewNextAction,
  manualReviewReasonLines,
  manualReviewStatusFor,
  type ManualReviewWorkbenchStatus
} from "./manual-review-workbench";
import tickerAliasPairs from "./ticker-aliases.json";

type ReportFile = {
  id: string;
  title: string;
  fileName: string;
  url: string | null;
  markdownUrl?: string | null;
  internalBestReportUrl?: string | null;
  rawReportUrl?: string | null;
  publishReportUrl?: string | null;
  qualityReportUrl?: string | null;
  evidenceReportUrl?: string | null;
  quality?: QualityRun | null;
  localPath: string;
  hasFinalDocument?: boolean;
  sizeBytes: number;
  createdAt: string;
  modifiedAt: string;
};

type QualityRun = {
  ticker: string;
  createdAt: string;
  verdict: string;
  metrics: Record<string, unknown>;
  status?: string | null;
  artifacts?: Record<string, string | null>;
  artifactLinks?: {
    raw_report?: string | null;
    internal_best_report?: string | null;
    publish_report?: string | null;
    quality_report?: string | null;
    evidence_report?: string | null;
  };
  publishable?: boolean | null;
  publicReady?: boolean | null;
  generationStage?: string | null;
  renderMode?: string | null;
  finalDocumentsRendered?: boolean | null;
  lifecycleVisibility?: string | null;
  scoreScope?: string | null;
  qualityVerdict?: string | null;
  publishGateVerdict?: string | null;
  promotionGateVerdict?: string | null;
  publishQualityScore?: number | null;
  internalResearchQualityScore?: number | null;
  dataConfidenceScore?: number | null;
  totalScoreLegacy?: number | null;
  internalRating?: string | null;
  externalDisplayRating?: string | null;
  publicRating?: string | null;
  reviewStatus?: string | null;
  rating: string | null;
  traderSignal: string | null;
  provider: string | null;
  quickModel: string | null;
  deepModel: string | null;
  tradingAgentsDate: string | null;
  generatedAtLabel: string | null;
  latestClose: string | null;
  rsi: string | null;
  atr: string | null;
  elapsedSeconds: number | null;
};

type Company = {
  ticker: string;
  companyName: string;
  reportCount: number;
  latestReport: ReportFile | null;
  reports: ReportFile[];
  qualityRuns: QualityRun[];
  latestQuality: QualityRun | null;
};

type ReportWorkflowStatus = "done" | "active" | "pending" | "failed" | "blocked" | "canceled";

type ReportWorkflowStep = {
  id: string;
  label: string;
  status: ReportWorkflowStatus;
  detail: string;
  timestamp: string | null;
};

type ReportWorkflowProgress = {
  completed: number;
  total: number;
  currentStepId: string | null;
  currentLabel: string;
  currentStatus: ReportWorkflowStatus;
};

type Job = {
  id: string;
  ticker: string;
  status: "queued" | "running" | "completed" | "error" | "canceled";
  stage: string;
  createdAt: string;
  startedAt: string | null;
  completedAt: string | null;
  updatedAt: string;
  analysisDate: string;
  provider: string;
  quickModel: string;
  deepModel: string;
  modelProfileId: string | null;
  modelProfileLabel: string | null;
  comparisonId: string | null;
  runDir: string;
  logPath: string;
  error: string | null;
  requestedInput: string | null;
  tickerResolution: {
    source: string;
    input: string;
    provider?: string;
    companyName?: string | null;
    exchange?: string | null;
  } | null;
  cancelRequestedAt: string | null;
  canceledAt: string | null;
  failureReportId: string | null;
  latestProgress: string;
  workflow: ReportWorkflowStep[];
  workflowProgress: ReportWorkflowProgress;
  artifacts: {
    latestReport?: ReportFile | null;
    latestQuality?: QualityRun | null;
    reportCount?: number;
  } | null;
};

type ModelProfile = {
  id: string;
  label: string;
  provider: string;
  quickModel: string;
  deepModel: string;
  default: boolean;
  requiresPaidConfirmation: boolean;
  track: string;
  badge: string;
  summary: string;
  tags: string[];
};

type Comparison = {
  id: string;
  ticker: string;
  requestedInput: string;
  analysisDate: string;
  createdAt: string;
  updatedAt: string;
  status?: string;
  counts?: Record<string, number>;
  evaluation?: {
    status: string;
    createdAt: string;
    winnerProfileId: string | null;
    winnerProfileLabel: string | null;
    warningCount?: number;
    markdownId?: string;
    markdownUrl?: string;
    markdown?: string;
    rows?: Array<{
      profileId: string;
      profileLabel: string;
      score: number;
      verdict: string | null;
      rating: string | null;
      traderSignal: string | null;
      words: number;
      sourceWords: number;
      pages: number;
      elapsedSeconds: number | null;
      pdfUrl: string | null;
      markdownUrl: string | null;
    }>;
    warnings?: string[];
  } | null;
  results: Array<{
    profileId: string;
    profileLabel: string;
    status: "queued" | "blocked";
    jobId: string | null;
    error: string | null;
    statusCode?: number;
    job?: Job | null;
    quality?: QualityRun | null;
    artifacts?: {
      pdfUrl: string | null;
      markdownUrl: string | null;
    } | null;
  }>;
};

type PublicReportEntry = {
  id: string;
  ticker: string;
  companyName: string;
  title: string;
  fileName: string;
  reportDate: string | null;
  modelLabel: string;
  pdfUrl: string | null;
  markdownUrl: string | null;
  internalBestReportUrl?: string | null;
  rawReportUrl?: string | null;
  publishReportUrl?: string | null;
  qualityReportUrl?: string | null;
  evidenceReportUrl?: string | null;
  sizeBytes: number;
  modifiedAt: string;
  qualityVerdict: string;
  lifecycleQualityVerdict?: string | null;
  generationStage?: string | null;
  renderMode?: string | null;
  finalDocumentsRendered?: boolean | null;
  publicReady?: boolean | null;
  lifecycleVisibility?: string | null;
  scoreScope?: string | null;
  publishGateVerdict?: string | null;
  promotionGateVerdict?: string | null;
  qualityStatus?: string | null;
  publishable?: boolean | null;
  internalRating?: string | null;
  externalDisplayRating?: string | null;
  publicRating?: string | null;
  reviewStatusMetric?: string | null;
  qualityScore?: number | null;
  publishQualityScore?: number | null;
  internalResearchQualityScore?: number | null;
  dataConfidenceScore?: number | null;
  totalScoreLegacy?: number | null;
  companyArchetype?: string | null;
  archetypeConfidence?: number | null;
  archetypeTriggeredRules?: string[];
  riskProfiles?: string[];
  manualReviewReasons?: string[];
  promotionStatus?: {
    promotion_status?: string | null;
    public_ready?: boolean | null;
    promotion_reasons?: string[];
    reviewed_by?: string | null;
    approved_at?: string | null;
    requested_visibility?: string | null;
    non_advice_confirmed?: boolean | null;
    sources_human_verified?: boolean | null;
    blocking_issues?: string[];
  } | null;
  sourceStatus: "unmatched_pdf" | "pipeline_verified" | "human_verified" | "qa_failed";
  reviewStatus: "unreviewed" | "reviewed" | "rejected";
  visibility: "hidden" | "member" | "public";
  nonAdvice: boolean;
  dismissedAt?: string | null;
  dismissedBy?: string | null;
  qualityGate: {
    status: "manual_review" | "needs_human_review" | "internal_only" | "rejected" | "member_ready" | "public_ready";
    effectiveVisibility: "hidden" | "member" | "public";
    publicReady: boolean;
    memberReady: boolean;
    blockers: string[];
    warnings: string[];
  };
};

type ReportLibrary = {
  version: string;
  generatedAt: string;
  shelfDir: string;
  summary: {
    totalReports: number;
    companies: number;
    publicReady: number;
    memberReady: number;
    manualReview: number;
    needsHumanReview: number;
    rejected: number;
    internalOnly: number;
    hiddenByGate: number;
    effectivePublic: number;
    effectiveMember: number;
    speculative_deep_tech_profile_count: number;
    accounting_gain_not_operating_turnaround_count: number;
    vendor_only_hard_metrics_count: number;
    order_materiality_missing_count: number;
    technical_overweight_in_thesis_count: number;
  };
  entries: PublicReportEntry[];
};

type TextReader = {
  title: string;
  markdown: string;
  badge: string;
};

type ReportMachineStatus = {
  generatedAt: string;
  ready: boolean;
  activeJobId: string | null;
  runningJobs: number;
  queuedJobs: number;
  failedJobs: number;
  canceledJobs: number;
  recoverableJobs: number;
  recoverableByTicker: Record<string, number>;
  nextAction: string;
  policy: {
    activeModelsExcludeKimiAndGpt55: boolean;
    deepseekIsOllamaCloud: boolean;
    publicReadyRequires: string[];
    manualReviewProfiles?: string[];
    failedQualityVisibility: string;
    reportFlow: string[];
    reportFlowLabels?: Array<{ id: string; label: string }>;
  };
};

type AppState = {
  companies: Company[];
  jobs: Job[];
  comparisons: Comparison[];
  reportMachine: ReportMachineStatus;
  reportLibrary: ReportLibrary;
  modelProfiles: ModelProfile[];
  tickerAliases?: {
    aliasEntries: number;
    uniqueTickers: number;
  };
  defaults: {
    analysisDate: string;
    provider: string;
    quickModel: string;
    deepModel: string;
    modelProfileId: string;
    shelfDir: string;
  };
  preflight: {
    ok: boolean;
    checks: Array<{ name: string; ok: boolean; detail: string }>;
  };
  hardening: {
    available: boolean;
    verdict: string;
    latestCycleId: string | null;
    createdAt: string | null;
    commands?: Array<{ label: string; exitCode: number | null }>;
  };
};

const emptyState: AppState = {
  companies: [],
  jobs: [],
  comparisons: [],
  reportMachine: {
    generatedAt: "",
    ready: false,
    activeJobId: null,
    runningJobs: 0,
    queuedJobs: 0,
    failedJobs: 0,
    canceledJobs: 0,
    recoverableJobs: 0,
    recoverableByTicker: {},
    nextAction: "Report-Maschine wird geladen.",
    policy: {
      activeModelsExcludeKimiAndGpt55: false,
      deepseekIsOllamaCloud: false,
      publicReadyRequires: [],
      manualReviewProfiles: [],
      failedQualityVisibility: "",
      reportFlow: []
    }
  },
  reportLibrary: {
    version: "public-report-library-v1",
    generatedAt: "",
    shelfDir: "",
    summary: {
      totalReports: 0,
      companies: 0,
      publicReady: 0,
      memberReady: 0,
      manualReview: 0,
      needsHumanReview: 0,
      rejected: 0,
      internalOnly: 0,
      hiddenByGate: 0,
      effectivePublic: 0,
      effectiveMember: 0,
      speculative_deep_tech_profile_count: 0,
      accounting_gain_not_operating_turnaround_count: 0,
      vendor_only_hard_metrics_count: 0,
      order_materiality_missing_count: 0,
      technical_overweight_in_thesis_count: 0
    },
    entries: []
  },
  modelProfiles: [],
  defaults: {
    analysisDate: "",
    provider: "ollama",
    quickModel: "deepseek-v4-pro:cloud",
    deepModel: "deepseek-v4-pro:cloud",
    modelProfileId: "deepseek-v4-ollama",
    shelfDir: ""
  },
  preflight: {
    ok: false,
    checks: []
  },
  hardening: {
    available: false,
    verdict: "not_run",
    latestCycleId: null,
    createdAt: null
  }
};

async function fetchJson<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, init);
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.error || `${response.status} ${response.statusText}`);
  }
  return response.json() as Promise<T>;
}

function cleanTicker(value: string) {
  return value.trim().toUpperCase().replace(/[^A-Z0-9._-]/g, "");
}

const tickerAliases = new Map(
  (tickerAliasPairs as [string, string][]).map(([name, ticker]) => [cleanTicker(name), ticker])
);

function resolveTickerInput(value: string) {
  const normalized = cleanTicker(value);
  return tickerAliases.get(normalized) || normalized;
}

function formatDate(value?: string | null) {
  if (!value) {
    return "—";
  }
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return value;
  }
  return date.toLocaleString("de-DE", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
}

function timestamp(value?: string | null) {
  if (!value) {
    return 0;
  }
  const parsed = Date.parse(value);
  return Number.isNaN(parsed) ? 0 : parsed;
}

function reportEntryTimestamp(entry: PublicReportEntry) {
  return Math.max(timestamp(entry.modifiedAt), timestamp(entry.reportDate));
}

function compareReportEntriesNewest(left: PublicReportEntry, right: PublicReportEntry) {
  const byTime = reportEntryTimestamp(right) - reportEntryTimestamp(left);
  if (byTime !== 0) {
    return byTime;
  }
  return left.ticker.localeCompare(right.ticker) || left.title.localeCompare(right.title);
}

function companyTimestamp(company: Company) {
  const reportTimes = company.reports.map((report) => timestamp(report.modifiedAt));
  return Math.max(
    timestamp(company.latestReport?.modifiedAt),
    timestamp(company.latestQuality?.createdAt),
    ...reportTimes,
    0
  );
}

function compareCompaniesNewest(left: Company, right: Company) {
  const byTime = companyTimestamp(right) - companyTimestamp(left);
  if (byTime !== 0) {
    return byTime;
  }
  return left.ticker.localeCompare(right.ticker);
}

function jobTimestamp(job: Job) {
  return Math.max(
    timestamp(job.updatedAt),
    timestamp(job.completedAt),
    timestamp(job.startedAt),
    timestamp(job.createdAt)
  );
}

function compareJobsNewest(left: Job, right: Job) {
  const byTime = jobTimestamp(right) - jobTimestamp(left);
  if (byTime !== 0) {
    return byTime;
  }
  return left.ticker.localeCompare(right.ticker);
}

function comparisonTimestamp(comparison: Comparison) {
  return Math.max(timestamp(comparison.updatedAt), timestamp(comparison.createdAt));
}

function compareComparisonsNewest(left: Comparison, right: Comparison) {
  const byTime = comparisonTimestamp(right) - comparisonTimestamp(left);
  if (byTime !== 0) {
    return byTime;
  }
  return left.ticker.localeCompare(right.ticker);
}

function formatSeconds(value?: number | null) {
  if (!value && value !== 0) {
    return "—";
  }
  const minutes = Math.floor(value / 60);
  const seconds = Math.round(value % 60);
  return `${minutes}m ${seconds}s`;
}

function formatBytes(value?: number | null) {
  if (!value) {
    return "—";
  }
  const mb = value / 1024 / 1024;
  return `${mb.toFixed(1)}MB`;
}

function stripReportTitle(title: string) {
  return title
    .replace(/^\d{4}-\d{2}-\d{2}\s+Room 16\s+/i, "")
    .replace(/\s+Complete Dossier$/i, "")
    .trim();
}

function reportModelLabel(report: ReportFile) {
  const source = `${report.fileName} ${report.title}`.toLowerCase();
  if (source.includes("deepseek")) {
    return "DeepSeek V4";
  }
  if (source.includes("kimi")) {
    return "Kimi K2.6";
  }
  if (source.includes("glm")) {
    return "GLM-5.1";
  }
  if (source.includes("gpt-5.5")) {
    return "GPT-5.5";
  }
  if (source.includes("gpt-5.4")) {
    return "GPT-5.4";
  }
  return stripReportTitle(report.title);
}

function qualityText(verdict?: string | null) {
  if (!verdict) {
    return "—";
  }
  if (verdict === "pass") {
    return "Bestanden";
  }
  if (verdict === "fail") {
    return "Review erforderlich";
  }
  return verdict;
}

function reportQualityText(report: ReportFile) {
  if (!report.quality?.verdict) {
    return "Offen";
  }
  if (report.quality.verdict === "pass") {
    return "Grün";
  }
  if (report.quality.verdict === "fail") {
    return "Review erforderlich";
  }
  return report.quality.verdict;
}

function libraryGateText(value?: string | null) {
  const labels: Record<string, string> = {
    public_ready: "Public Final freigegeben",
    member_ready: "Member intern freigegeben",
    manual_review: "Manual Review blockiert",
    needs_human_review: "Human Review offen",
    internal_only: "Intern blockiert",
    rejected: "Gesperrt"
  };
  return labels[value || ""] || value || "—";
}

function generationStageText(value?: string | null) {
  const labels: Record<string, string> = {
    draft_markdown_qa: "Markdown-QA intern",
    internal_best: "Internal Best",
    public_final: "Public Final"
  };
  return labels[value || ""] || value || "—";
}

function renderModeText(value?: string | null) {
  const labels: Record<string, string> = {
    markdown_first_qa: "Markdown-QA ohne Finaldokumente",
    internal_pdf: "Interne PDF-Fassung",
    final_public_documents: "Finaldokumente public"
  };
  return labels[value || ""] || value || "—";
}

function visibilityText(value?: string | null) {
  const labels: Record<string, string> = {
    public: "Public",
    member: "Member",
    hidden: "Hidden",
    internal_only: "Nur intern",
    public_candidate: "Public-Kandidat"
  };
  return labels[value || ""] || value || "—";
}

function sourceStatusText(value?: string | null) {
  const labels: Record<string, string> = {
    human_verified: "Quellen human-verifiziert",
    pipeline_verified: "Quellen pipeline-verifiziert",
    unmatched_pdf: "PDF ohne Quellenabgleich",
    qa_failed: "QA rot"
  };
  return labels[value || ""] || value || "—";
}

function reviewStatusText(value?: string | null) {
  const labels: Record<string, string> = {
    reviewed: "Review abgeschlossen",
    unreviewed: "Review offen",
    rejected: "Review abgelehnt"
  };
  return labels[value || ""] || value || "—";
}

function lifecycleReviewText(value?: string | null) {
  const labels: Record<string, string> = {
    qa_pass: "QA bestanden",
    qa_failed: "QA rot",
    manual_review: "Manual Review blockiert",
    internal_ready: "Intern bereit",
    public_ready: "Public Final bereit",
    blocked: "Blockiert",
    failed: "Fehlgeschlagen"
  };
  return labels[value || ""] || value || "—";
}

function boolText(value?: boolean | null) {
  return value === true ? "Ja" : "Nein";
}

function isPublicPublishAvailable(entry: PublicReportEntry) {
  return Boolean(entry.qualityGate.status === "public_ready" &&
    entry.generationStage === "public_final" &&
    entry.publicReady === true &&
    entry.finalDocumentsRendered === true &&
    entry.publishReportUrl);
}

function laneBadgeText(entry: PublicReportEntry) {
  if (entry.qualityGate.status === "public_ready") {
    return "Public Final geprüft";
  }
  if (entry.reviewStatusMetric === "manual_review" || entry.qualityGate.status === "manual_review") {
    return "Manual Review blockiert";
  }
  return generationStageText(entry.generationStage);
}

function laneBadgeClass(entry: PublicReportEntry) {
  if (entry.qualityGate.status === "public_ready") {
    return "qaBadge isPass";
  }
  if (entry.reviewStatusMetric === "manual_review" || entry.qualityGate.status === "manual_review" || entry.qualityGate.status === "rejected") {
    return "qaBadge isFail";
  }
  return "qaBadge";
}

function manualReviewStatusClass(status: ManualReviewWorkbenchStatus) {
  if (["manual_review", "audit_failed", "promotion_blocked"].includes(status)) {
    return "qaBadge isFail";
  }
  if (["approved_internal", "public_ready"].includes(status)) {
    return "qaBadge isPass";
  }
  return "qaBadge";
}

type OperatorStatusKey = "markdown_first_qa" | "manual_review" | "internal_best" | "public_final" | "gate_pending";

function isMarkdownFirstQaEntry(entry: PublicReportEntry) {
  return entry.generationStage === "draft_markdown_qa" || entry.renderMode === "markdown_first_qa";
}

function isManualReviewEntry(entry: PublicReportEntry) {
  return entry.qualityGate.status === "manual_review" || entry.reviewStatusMetric === "manual_review";
}

function isInternalBestEntry(entry: PublicReportEntry) {
  return entry.generationStage === "internal_best";
}

function isPublicFinalEntry(entry: PublicReportEntry) {
  return entry.generationStage === "public_final" && entry.qualityGate.status === "public_ready";
}

function operatorStatusKey(entry: PublicReportEntry): OperatorStatusKey {
  if (isMarkdownFirstQaEntry(entry)) {
    return "markdown_first_qa";
  }
  if (isManualReviewEntry(entry)) {
    return "manual_review";
  }
  if (isPublicFinalEntry(entry)) {
    return "public_final";
  }
  if (isInternalBestEntry(entry)) {
    return "internal_best";
  }
  return "gate_pending";
}

function operatorStatusCopy(entry: PublicReportEntry) {
  const status = operatorStatusKey(entry);
  if (status === "markdown_first_qa") {
    return {
      status,
      badge: "Markdown-QA intern",
      title: "Markdown-QA bestanden",
      explanation: "Markdown-QA bestanden. Noch keine finalen Dokumente. Keine Public-Freigabe.",
      allowed: ["Markdown öffnen", "QA-Artefakte prüfen", "Internal Best erzeugen"],
      blocked: ["PDF/DOCX final", "Public Library"]
    };
  }
  if (status === "manual_review") {
    return {
      status,
      badge: "Manual Review blockiert",
      title: "Review-Gate offen",
      explanation: "Report ist blockiert, weil mindestens ein Review-Gate offen ist.",
      allowed: ["Internal Best öffnen", "Evidence prüfen", "Manual Review bearbeiten"],
      blocked: ["Public Publish"]
    };
  }
  if (status === "internal_best") {
    return {
      status,
      badge: "Internal Best",
      title: "Interne Lesefassung vorhanden",
      explanation: "Interne Lesefassung vorhanden. Nicht public.",
      allowed: ["PDF intern öffnen", "Review abschließen", "Promotion prüfen"],
      blocked: ["Public ohne Promotion"]
    };
  }
  if (status === "public_final") {
    return {
      status,
      badge: "Public Final",
      title: "Promotion bestanden",
      explanation: "Promotion bestanden. Finaldokumente verfügbar.",
      allowed: ["Final-PDF öffnen", "Promotion-Status prüfen", "Operator-Go dokumentieren"],
      blocked: []
    };
  }
  return {
    status,
    badge: "Gate offen",
    title: "Public-Freigabe blockiert",
    explanation: "Report ist noch kein Public Final. Die vorhandenen Gate-Daten verlangen interne Prüfung vor jeder Ausleitung.",
    allowed: ["Evidence prüfen", "Quality-Report öffnen", "Review-Status klären"],
    blocked: ["Public Publish"]
  };
}

function primaryArtifactLabel(entry: PublicReportEntry) {
  const status = operatorStatusKey(entry);
  if (status === "public_final" && entry.pdfUrl) {
    return "Final-PDF öffnen";
  }
  if (status === "manual_review" && entry.internalBestReportUrl) {
    return "Internal Best öffnen";
  }
  if (status === "internal_best" && entry.internalBestReportUrl) {
    return "Internal Best öffnen";
  }
  if (status === "markdown_first_qa") {
    return "Markdown öffnen";
  }
  if (entry.evidenceReportUrl) {
    return "Evidence prüfen";
  }
  return "Report-Artefakt öffnen";
}

function primaryArtifactUrl(entry: PublicReportEntry) {
  if (operatorStatusKey(entry) === "public_final" && entry.pdfUrl) {
    return entry.pdfUrl;
  }
  return entry.internalBestReportUrl || entry.markdownUrl || entry.evidenceReportUrl || entry.qualityReportUrl || entry.rawReportUrl || "";
}

function operatorStatusActionLabel(entry: PublicReportEntry) {
  const status = operatorStatusKey(entry);
  if (status === "manual_review") {
    return "Manual-Review-Gründe anzeigen";
  }
  if (status === "markdown_first_qa") {
    return "QA-Artefakte prüfen";
  }
  if (status === "internal_best" || status === "public_final") {
    return "Promotion-Status prüfen";
  }
  return "Evidence prüfen";
}

function nonPublicSafetyCopy(entry: PublicReportEntry) {
  if (isPublicPublishAvailable(entry)) {
    return "Promotion bestanden; trotzdem Operator-Go vor sichtbarer Public-Aktion prüfen.";
  }
  return "Keine Anlageberatung. Interner Entwurf. Nicht public freigegeben. manual_review nicht umgehen.";
}

function decisionText(value?: string | null) {
  if (!value) {
    return "—";
  }
  const normalized = value.trim().toLowerCase();
  if (["overweight", "uebergewichten", "übergewichten"].includes(normalized)) {
    return "Übergewichten";
  }
  if (["underweight", "untergewichten"].includes(normalized)) {
    return "Untergewichten";
  }
  if (["hold", "halten"].includes(normalized)) {
    return "Halten";
  }
  if (["buy", "kaufen"].includes(normalized)) {
    return "Kaufen";
  }
  if (["sell", "verkaufen"].includes(normalized)) {
    return "Verkaufen";
  }
  return value;
}

function statusText(status: Job["status"]) {
  const labels: Record<Job["status"], string> = {
    queued: "Wartet",
    running: "Läuft",
    completed: "Fertig",
    error: "Fehler",
    canceled: "Gestoppt"
  };
  return labels[status];
}

function workflowStatusText(status: ReportWorkflowStatus) {
  const labels: Record<ReportWorkflowStatus, string> = {
    done: "Erledigt",
    active: "Aktiv",
    pending: "Offen",
    failed: "Fehler",
    blocked: "Blockiert",
    canceled: "Gestoppt"
  };
  return labels[status];
}

function verdictText(value?: string | null) {
  if (value === "pass") {
    return "Grün";
  }
  if (value === "fail") {
    return "Rot";
  }
  if (value === "not_run") {
    return "Nicht gelaufen";
  }
  return value || "—";
}

function comparisonStatusText(value?: string | null) {
  const labels: Record<string, string> = {
    running: "Läuft",
    evaluated: "Ausgewertet",
    ready_for_evaluation: "Bereit zur Auswertung",
    partial_ready: "Teilweise auswertbar",
    waiting_for_more_reports: "Wartet auf weitere Reports",
    blocked: "Blockiert",
    empty: "Keine Modellreports"
  };
  return labels[value || ""] || value || "—";
}

function metric(run: QualityRun | null, key: string) {
  const value = run?.metrics?.[key];
  if (value === null || value === undefined || value === "") {
    return "—";
  }
  return String(value);
}

function PdfDocument({ report }: { report: ReportFile }) {
  if (!report.url) {
    return (
      <div className="pdfError">
        <AlertTriangle size={17} />
        <span>PDF/DOCX ist für diesen internen QA-Draft noch nicht gerendert; Markdown und QA-Artefakte prüfen.</span>
      </div>
    );
  }
  return (
    <div className="pdfNativeFrame">
      <iframe title={report.title} src={`${report.url}#view=FitH`} />
    </div>
  );
}

type MarkdownBlock =
  | { type: "heading"; level: number; text: string }
  | { type: "paragraph"; text: string }
  | { type: "list"; items: string[] }
  | { type: "quote"; text: string }
  | { type: "table"; rows: string[][] }
  | { type: "rule" };

function cleanMarkdownText(value: string) {
  return value
    .replace(/\*\*/g, "")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/\\\[/g, "[")
    .replace(/\\\]/g, "]")
    .trim();
}

function parseTableLine(line: string) {
  return line
    .trim()
    .replace(/^\|/, "")
    .replace(/\|$/, "")
    .split("|")
    .map((cell) => cleanMarkdownText(cell));
}

function isTableSeparator(line: string) {
  return /^\s*\|?[\s:|-]+\|[\s:|-]+\|?\s*$/.test(line);
}

function parseMarkdown(markdown: string): MarkdownBlock[] {
  const lines = markdown.split(/\r?\n/);
  const blocks: MarkdownBlock[] = [];
  let index = 0;
  while (index < lines.length) {
    const line = lines[index];
    const trimmed = line.trim();
    if (!trimmed) {
      index += 1;
      continue;
    }
    if (/^---+$/.test(trimmed)) {
      blocks.push({ type: "rule" });
      index += 1;
      continue;
    }
    const heading = trimmed.match(/^(#{1,4})\s+(.+)$/);
    if (heading) {
      blocks.push({ type: "heading", level: Math.min(heading[1].length, 3), text: cleanMarkdownText(heading[2]) });
      index += 1;
      continue;
    }
    if (trimmed.startsWith("|") && trimmed.includes("|")) {
      const rows: string[][] = [];
      while (index < lines.length && lines[index].trim().startsWith("|")) {
        if (!isTableSeparator(lines[index])) {
          rows.push(parseTableLine(lines[index]));
        }
        index += 1;
      }
      if (rows.length) {
        blocks.push({ type: "table", rows });
      }
      continue;
    }
    if (/^[-*]\s+/.test(trimmed)) {
      const items: string[] = [];
      while (index < lines.length && /^[-*]\s+/.test(lines[index].trim())) {
        items.push(cleanMarkdownText(lines[index].trim().replace(/^[-*]\s+/, "")));
        index += 1;
      }
      blocks.push({ type: "list", items });
      continue;
    }
    if (/^>\s?/.test(trimmed)) {
      const quoteLines: string[] = [];
      while (index < lines.length && /^>\s?/.test(lines[index].trim())) {
        quoteLines.push(lines[index].trim().replace(/^>\s?/, ""));
        index += 1;
      }
      blocks.push({ type: "quote", text: cleanMarkdownText(quoteLines.join(" ")) });
      continue;
    }
    const paragraphLines = [trimmed];
    index += 1;
    while (
      index < lines.length &&
      lines[index].trim() &&
      !lines[index].trim().startsWith("|") &&
      !/^(#{1,4})\s+/.test(lines[index].trim()) &&
      !/^[-*]\s+/.test(lines[index].trim())
    ) {
      paragraphLines.push(lines[index].trim());
      index += 1;
    }
    blocks.push({ type: "paragraph", text: cleanMarkdownText(paragraphLines.join(" ")) });
  }
  return blocks;
}

function MarkdownArticle({ markdown }: { markdown: string }) {
  const blocks = parseMarkdown(markdown);
  return (
    <article className="markdownReader">
      {blocks.map((block, index) => {
        if (block.type === "heading") {
          const Tag = block.level === 1 ? "h2" : block.level === 2 ? "h3" : "h4";
          return <Tag key={index}>{block.text}</Tag>;
        }
        if (block.type === "list") {
          return (
            <ul key={index}>
              {block.items.map((item, itemIndex) => (
                <li key={itemIndex}>{item}</li>
              ))}
            </ul>
          );
        }
        if (block.type === "table") {
          const [head, ...body] = block.rows;
          return (
            <div className="markdownTableWrap" key={index}>
              <table>
                {head ? (
                  <thead>
                    <tr>
                      {head.map((cell, cellIndex) => (
                        <th key={cellIndex}>{cell}</th>
                      ))}
                    </tr>
                  </thead>
                ) : null}
                <tbody>
                  {body.map((row, rowIndex) => (
                    <tr key={rowIndex}>
                      {row.map((cell, cellIndex) => (
                        <td key={cellIndex}>{cell}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          );
        }
        if (block.type === "rule") {
          return <hr key={index} />;
        }
        if (block.type === "quote") {
          return <blockquote key={index}>{block.text}</blockquote>;
        }
        return <p key={index}>{block.text}</p>;
      })}
    </article>
  );
}

function MarkdownDocument({ ticker, report }: { ticker: string; report: ReportFile }) {
  const [markdown, setMarkdown] = useState("");
  const [status, setStatus] = useState("Dossier wird geladen.");
  const [markdownError, setMarkdownError] = useState("");
  const [copyStatus, setCopyStatus] = useState("");

  useEffect(() => {
    let cancelled = false;
    setStatus("Dossier wird geladen.");
    setMarkdownError("");
    setMarkdown("");
    setCopyStatus("");
    fetch(report.markdownUrl || `/api/reports/latest/${encodeURIComponent(ticker)}/markdown`)
      .then(async (response) => {
        const text = await response.text();
        if (!response.ok) {
          throw new Error(text || "Markdown-Dossier nicht gefunden.");
        }
        return text;
      })
      .then((text) => {
        if (!cancelled) {
          setMarkdown(text);
          setStatus("");
        }
      })
      .catch((errorValue) => {
        if (!cancelled) {
          setMarkdownError(errorValue instanceof Error ? errorValue.message : String(errorValue));
          setStatus("");
        }
      });
    return () => {
      cancelled = true;
    };
  }, [report.id, report.markdownUrl, ticker]);

  async function copyMarkdown() {
    try {
      await navigator.clipboard.writeText(markdown);
      setCopyStatus("Text kopiert");
    } catch {
      setCopyStatus("Kopieren nicht erlaubt");
    }
  }

  if (status) {
    return <div className="readerStatus">{status}</div>;
  }
  if (markdownError) {
    return (
      <div className="readerFallback">
        <div className="pdfError">
          <AlertTriangle size={17} />
          <span>{markdownError}</span>
        </div>
        <PdfDocument report={report} />
      </div>
    );
  }

  return (
    <div className="readerDocument">
      <div className="readerTools">
        <button className="ghostButton" type="button" onClick={copyMarkdown}>
          <Copy size={15} />
          <span>Text kopieren</span>
        </button>
        <span>{copyStatus || "Text ist markierbar"}</span>
      </div>
      <MarkdownArticle markdown={markdown} />
    </div>
  );
}

function JobWorkflowChecklist({ job }: { job: Job }) {
  const steps = Array.isArray(job.workflow) ? job.workflow : [];
  if (!steps.length) {
    return null;
  }
  const progress = job.workflowProgress || {
    completed: steps.filter((step) => step.status === "done").length,
    total: steps.length,
    currentStepId: null,
    currentLabel: "Workflow",
    currentStatus: "pending" as ReportWorkflowStatus
  };
  const currentStep =
    steps.find((step) => step.id === progress.currentStepId) ||
    steps.find((step) => ["active", "failed", "blocked", "canceled"].includes(step.status)) ||
    null;
  const currentDetail = currentStep
    ? [currentStep.detail, currentStep.timestamp ? formatDate(currentStep.timestamp) : ""].filter(Boolean).join(" · ")
    : "";

  return (
    <div className="jobWorkflow" aria-label={`Workflow-Checkliste ${job.ticker}`}>
      <div className="workflowSummary">
        <strong>{progress.completed}/{progress.total}</strong>
        <span>
          {progress.currentLabel} · {workflowStatusText(progress.currentStatus)}
        </span>
      </div>
      {currentDetail ? <div className="workflowCurrentDetail">{currentDetail}</div> : null}
      <ol className="workflowChecklist">
        {steps.map((step) => (
          <li
            className={`workflowStep ${step.status} ${step.id === progress.currentStepId ? "isCurrent" : ""}`}
            key={step.id}
            title={[step.label, step.detail, step.timestamp ? formatDate(step.timestamp) : ""].filter(Boolean).join(" · ")}
          >
            <span className="workflowDot" aria-hidden="true" />
            <span className="workflowLabel">{step.label}</span>
          </li>
        ))}
      </ol>
    </div>
  );
}

function ComparisonDetailView({
  comparison,
  evaluating,
  jobActionId,
  onBack,
  onEvaluate,
  onCancelJob,
  onRetryJob,
  onRemoveJob,
  onOpenFailureReport,
  onOpenMarkdown
}: {
  comparison: Comparison;
  evaluating: boolean;
  jobActionId: string | null;
  onBack: () => void;
  onEvaluate: () => void;
  onCancelJob: (job: Job) => void;
  onRetryJob: (job: Job) => void;
  onRemoveJob: (job: Job) => void;
  onOpenFailureReport: (job: Job) => void;
  onOpenMarkdown: (title: string, url: string) => void;
}) {
  const completed = comparison.results.filter((result) => result.job?.status === "completed").length;
  const total = comparison.results.length;
  const canEvaluate = completed >= 2 && !evaluating;
  return (
    <section className="comparisonDetailView">
      <div className="readerHeader">
        <button className="ghostButton" type="button" onClick={onBack}>
          <ArrowLeft size={16} />
          <span>Zurück</span>
        </button>
        <div className="readerTitle">
          Modellvergleich {comparison.ticker} · {comparisonStatusText(comparison.status)}
        </div>
        <button className="ghostButton" type="button" disabled={!canEvaluate} onClick={onEvaluate}>
          {evaluating ? <RefreshCw className="spin" size={16} /> : <FileText size={16} />}
          <span>{comparison.evaluation ? "Modellvergleich neu auswerten" : "Modellvergleich auswerten"}</span>
        </button>
      </div>

      <div className="comparisonSummaryGrid">
        <div>
          <span>Ticker</span>
          <strong>{comparison.ticker}</strong>
        </div>
        <div>
          <span>Datum</span>
          <strong>{comparison.analysisDate}</strong>
        </div>
        <div>
          <span>Reports</span>
          <strong>{completed}/{total}</strong>
        </div>
        <div>
          <span>Gewinner</span>
          <strong>{comparison.evaluation?.winnerProfileLabel || "offen"}</strong>
        </div>
      </div>

      <div className="comparisonResultGrid">
        {comparison.results.map((result) => {
          const job = result.job || null;
          const status = job?.status || result.status;
          const progressLine = job?.latestProgress
            ?.split(/\r?\n/)
            .map((line) => line.trim())
            .filter(Boolean)
            .slice(-1)[0];
          return (
            <article className={`comparisonResultCard ${status}`} key={result.profileId}>
              <div className="jobTopline">
                <span>{result.profileLabel}</span>
                <em>{job ? statusText(job.status) : status}</em>
              </div>
              <div className="comparisonMetricLine">
                <span>Rating</span>
                <strong>{decisionText(result.quality?.rating)}</strong>
              </div>
              <div className="comparisonMetricLine">
                <span>Signal</span>
                <strong>{decisionText(result.quality?.traderSignal)}</strong>
              </div>
              <div className="comparisonMetricLine">
                <span>Umfang</span>
                <strong>{metric(result.quality || null, "complete_pdf_words")} Wörter</strong>
              </div>
              <div className="comparisonMetricLine">
                <span>Laufzeit</span>
                <strong>{formatSeconds(result.quality?.elapsedSeconds)}</strong>
              </div>
              {progressLine ? <pre className="jobProgressTail">{progressLine}</pre> : null}
              {job ? <JobWorkflowChecklist job={job} /> : null}
              {result.error ? <p className="comparisonErrorText">{result.error}</p> : null}
              <div className="jobActions">
                {job?.status === "running" ? (
                  <button
                    className="jobActionButton danger"
                    type="button"
                    disabled={jobActionId === job.id}
                    onClick={() => onCancelJob(job)}
                  >
                    <StopCircle size={14} />
                    <span>{jobActionId === job.id ? "Stoppt" : "Stoppen"}</span>
                  </button>
                ) : null}
                {job?.status === "queued" ? (
                  <button
                    className="jobActionButton danger"
                    type="button"
                    disabled={jobActionId === job.id}
                    onClick={() => onCancelJob(job)}
                  >
                    <Trash2 size={14} />
                    <span>{jobActionId === job.id ? "Entfernt" : "Entfernen"}</span>
                  </button>
                ) : null}
                {job?.status === "error" ? (
                  <button
                    className="jobActionButton"
                    type="button"
                    disabled={jobActionId === job.id}
                    onClick={() => onRetryJob(job)}
                  >
                    <Play size={14} />
                    <span>{jobActionId === job.id ? "Startet" : "Neu starten"}</span>
                  </button>
                ) : null}
                {job?.status === "error" && job.failureReportId ? (
                  <button
                    className="jobActionButton"
                    type="button"
                    disabled={jobActionId === job.id}
                    onClick={() => onOpenFailureReport(job)}
                  >
                    <FileText size={14} />
                    <span>Fehlerbericht</span>
                  </button>
                ) : null}
                {job?.status === "error" ? (
                  <button
                    className="jobActionButton"
                    type="button"
                    disabled={jobActionId === job.id}
                    onClick={() => onRemoveJob(job)}
                  >
                    <Trash2 size={14} />
                    <span>{jobActionId === job.id ? "Blendet aus" : "Ausblenden"}</span>
                  </button>
                ) : null}
                {result.artifacts?.pdfUrl ? (
                  <button className="jobActionButton" type="button" onClick={() => window.open(result.artifacts?.pdfUrl || "", "_blank")}>
                    <ExternalLink size={14} />
                    <span>Final-PDF öffnen</span>
                  </button>
                ) : null}
                {result.artifacts?.markdownUrl ? (
                  <button
                    className="jobActionButton"
                    type="button"
                    onClick={() => onOpenMarkdown(`${comparison.ticker} · ${result.profileLabel}`, result.artifacts?.markdownUrl || "")}
                  >
                    <FileText size={14} />
                    <span>Markdown öffnen</span>
                  </button>
                ) : null}
              </div>
            </article>
          );
        })}
      </div>

      {comparison.evaluation?.markdown ? (
        <div className="comparisonEvaluation">
          <MarkdownArticle markdown={comparison.evaluation.markdown} />
        </div>
      ) : (
        <div className="quietState">
          Keine Vergleichsauswertung, weil weniger als zwei Profil-Reports fertig sind. Erwarteter Zustand während der Läufe; nächster Schritt: Reports fertig laufen lassen oder blockierte Jobs prüfen.
        </div>
      )}
    </section>
  );
}

function OperatorStatusModal({
  entry,
  onClose,
  onOpenMarkdown
}: {
  entry: PublicReportEntry;
  onClose: () => void;
  onOpenMarkdown: (title: string, url: string) => void;
}) {
  const copy = operatorStatusCopy(entry);
  const manualReasons = entry.manualReviewReasons?.length
    ? entry.manualReviewReasons
    : manualReviewReasonLines(entry);
  const promotionStatus = entry.promotionStatus || {};
  const promotionRows = [
    ["Promotion Reviewer", promotionStatus.reviewed_by || "nicht im Promotion-Status"],
    ["Approval Date", formatDate(promotionStatus.approved_at || null)],
    ["Visibility", promotionStatus.requested_visibility || visibilityText(entry.qualityGate.effectiveVisibility)]
  ];
  const evidenceUrl = entry.evidenceReportUrl || entry.qualityReportUrl || "";
  const primaryUrl = primaryArtifactUrl(entry);

  function openMarkdown(label: string, url?: string | null) {
    if (!url) {
      return;
    }
    onOpenMarkdown(`${entry.ticker} · ${label}`, url);
    onClose();
  }

  function openExternal(url?: string | null) {
    if (!url) {
      return;
    }
    window.open(url, "_blank");
    onClose();
  }

  return (
    <div className="operatorModalBackdrop" role="presentation" onClick={onClose}>
      <section
        className="operatorStatusModal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="operator-status-title"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="operatorModalHeader">
          <span className={laneBadgeClass(entry)}>{copy.badge}</span>
          <button className="ghostButton" type="button" onClick={onClose}>
            Schließen
          </button>
        </div>
        <h2 id="operator-status-title">{entry.ticker}: {copy.title}</h2>
        <p>{copy.explanation}</p>

        {copy.status !== "public_final" ? (
          <div className="operatorSafetyBox">{nonPublicSafetyCopy(entry)}</div>
        ) : null}

        <div className="operatorModalGrid">
          <div>
            <h3>Erlaubte nächste Aktionen</h3>
            <ul>
              {copy.allowed.map((item) => <li key={item}>{item}</li>)}
            </ul>
          </div>
          <div>
            <h3>Blockiert</h3>
            <ul>
              {copy.blocked.length ? copy.blocked.map((item) => <li key={item}>{item}</li>) : (
                <li>Kein Public-Blocker im Promotion-Status; Operator-Go bleibt separat zu dokumentieren.</li>
              )}
            </ul>
          </div>
        </div>

        {copy.status === "manual_review" ? (
          <div className="operatorReasonPanel">
            <h3>manual_review_reasons</h3>
            {manualReasons.length ? (
              <ul>
                {manualReasons.map((reason) => <li key={reason}>{reason}</li>)}
              </ul>
            ) : (
              <p>Keine manual_review_reasons im Quality Report; Gate-Blocker und Evidence trotzdem prüfen.</p>
            )}
          </div>
        ) : null}

        {copy.status === "public_final" ? (
          <div className="operatorPromotionFacts">
            {promotionRows.map(([label, value]) => (
              <div key={label}>
                <span>{label}</span>
                <strong>{value}</strong>
              </div>
            ))}
          </div>
        ) : null}

        <div className="operatorModalActions">
          <button
            className="tableButton"
            type="button"
            disabled={!primaryUrl}
            onClick={() => {
              if (copy.status === "public_final" && entry.pdfUrl) {
                openExternal(entry.pdfUrl);
                return;
              }
              openMarkdown(primaryArtifactLabel(entry), primaryUrl);
            }}
          >
            {primaryArtifactLabel(entry)}
          </button>
          {copy.status === "internal_best" ? (
            <button
              className="tableButton"
              type="button"
              disabled={!entry.pdfUrl}
              onClick={() => openExternal(entry.pdfUrl)}
            >
              PDF intern öffnen
            </button>
          ) : null}
          {copy.status === "public_final" ? (
            <button
              className="tableButton"
              type="button"
              disabled={!entry.pdfUrl}
              onClick={() => openExternal(entry.pdfUrl)}
            >
              Final-PDF öffnen
            </button>
          ) : null}
          <button
            className="tableButton"
            type="button"
            disabled={!evidenceUrl}
            onClick={() => openMarkdown(copy.status === "markdown_first_qa" ? "QA-Artefakte" : "Evidence", evidenceUrl)}
          >
            {copy.status === "markdown_first_qa" ? "QA-Artefakte prüfen" : "Evidence prüfen"}
          </button>
        </div>
      </section>
    </div>
  );
}

export default function App() {
  const mockupView =
    typeof window !== "undefined" &&
    new URLSearchParams(window.location.search).get("view") === "mockups";

  if (mockupView) {
    return <Room16Mockups />;
  }

  const [state, setState] = useState<AppState>(emptyState);
  const [selectedTicker, setSelectedTicker] = useState("");
  const [query, setQuery] = useState("");
  const [draftTicker, setDraftTicker] = useState("");
  const [reader, setReader] = useState<ReportFile | null>(null);
  const [textReader, setTextReader] = useState<TextReader | null>(null);
  const [comparisonDetail, setComparisonDetail] = useState<Comparison | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [refreshing, setRefreshing] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [jobActionId, setJobActionId] = useState<string | null>(null);
  const [selectedModelProfileId, setSelectedModelProfileId] = useState("deepseek-v4-ollama");
  const [comparisonProfileIds, setComparisonProfileIds] = useState<string[]>([]);
  const [comparisonSubmitting, setComparisonSubmitting] = useState(false);
  const [comparisonActionId, setComparisonActionId] = useState<string | null>(null);
  const [libraryActionId, setLibraryActionId] = useState<string | null>(null);
  const [operatorModalEntry, setOperatorModalEntry] = useState<PublicReportEntry | null>(null);
  const deepLinkAppliedRef = useRef(false);
  const pendingOpenJobIdRef = useRef<string | null>(null);

  const syncRoute = useCallback((ticker?: string, report?: "latest" | ReportFile | null) => {
    if (typeof window === "undefined") {
      return;
    }
    const params = new URLSearchParams(window.location.search);
    params.delete("view");
    if (ticker) {
      params.set("ticker", ticker);
    } else {
      params.delete("ticker");
    }
    if (report) {
      params.set("reader", report === "latest" ? "latest" : report.id);
    } else {
      params.delete("reader");
    }
    const next = `${window.location.pathname}${params.toString() ? `?${params.toString()}` : ""}`;
    window.history.replaceState(null, "", next);
  }, []);

  const loadState = useCallback(async () => {
    const data = await fetchJson<AppState>("/api/state");
    setState(data);
    const pendingJobId = pendingOpenJobIdRef.current;
    const pendingJob = pendingJobId ? data.jobs.find((job) => job.id === pendingJobId) : null;
    if (pendingJob?.status === "completed" && pendingJob.artifacts?.latestReport) {
      pendingOpenJobIdRef.current = null;
      setSelectedTicker(pendingJob.ticker);
      setReader(pendingJob.artifacts.latestReport);
      setTextReader(null);
      syncRoute(pendingJob.ticker, "latest");
      return;
    }
    if (pendingJob?.status === "error") {
      pendingOpenJobIdRef.current = null;
    }
    if (pendingJob?.status === "canceled") {
      pendingOpenJobIdRef.current = null;
    }
    if (!deepLinkAppliedRef.current && typeof window !== "undefined") {
      deepLinkAppliedRef.current = true;
      const params = new URLSearchParams(window.location.search);
      const requestedTicker = resolveTickerInput(params.get("ticker") || "");
      const requestedReader = params.get("reader") || "";
      const company = data.companies.find((item) => item.ticker === requestedTicker) || null;
      if (!company && requestedTicker) {
        setSelectedTicker(requestedTicker);
        setTextReader(null);
        return;
      }
      if (company) {
        setSelectedTicker(company.ticker);
        setTextReader(null);
        if (requestedReader === "latest" && company.latestReport) {
          setReader(company.latestReport);
        } else if (requestedReader) {
          setReader(company.reports.find((report) => report.id === requestedReader) || null);
        }
        return;
      }
    }
  }, [syncRoute]);

  useEffect(() => {
    loadState().catch((loadError) => setError(loadError.message));
    const timer = window.setInterval(() => {
      loadState().catch((loadError) => setError(loadError.message));
    }, 8000);
    return () => window.clearInterval(timer);
  }, [loadState]);

  async function refreshState() {
    if (refreshing) {
      return;
    }
    setRefreshing(true);
    setError("");
    try {
      await loadState();
      setNotice(`Übersicht aktualisiert (${new Date().toLocaleTimeString("de-DE", {
        hour: "2-digit",
        minute: "2-digit"
      })}).`);
    } catch (refreshError) {
      setError(refreshError instanceof Error ? refreshError.message : String(refreshError));
    } finally {
      setRefreshing(false);
    }
  }

  useEffect(() => {
    const comparisonId = comparisonDetail?.id;
    if (!comparisonId) {
      return;
    }
    let cancelled = false;
    fetchJson<{ comparison: Comparison }>(`/api/comparisons/${comparisonId}`)
      .then(({ comparison }) => {
        if (!cancelled) {
          setComparisonDetail(comparison);
        }
      })
      .catch(() => {
        // The main polling loop already surfaces global API errors.
      });
    return () => {
      cancelled = true;
    };
  }, [state.comparisons, comparisonDetail?.id]);

  const runnableProfiles = useMemo(() => {
    return state.modelProfiles.filter((profile) => !profile.requiresPaidConfirmation);
  }, [state.modelProfiles]);

  const selectedModelProfile = useMemo(() => {
    return (
      runnableProfiles.find((profile) => profile.id === selectedModelProfileId) ||
      runnableProfiles[0] ||
      null
    );
  }, [runnableProfiles, selectedModelProfileId]);

  useEffect(() => {
    if (!runnableProfiles.length) {
      return;
    }
    const defaultProfileId = runnableProfiles.some((profile) => profile.id === state.defaults.modelProfileId)
      ? state.defaults.modelProfileId
      : runnableProfiles[0]?.id || "";
    const selectedStillExists = runnableProfiles.some((profile) => profile.id === selectedModelProfileId);
    if (defaultProfileId && !selectedStillExists) {
      setSelectedModelProfileId(defaultProfileId);
    }
    setComparisonProfileIds((current) => {
      const available = runnableProfiles.map((profile) => profile.id);
      const kept = current.filter((profileId) => available.includes(profileId));
      if (kept.length >= 2) {
        return kept;
      }
      return available.slice(0, 3);
    });
  }, [runnableProfiles, selectedModelProfileId, state.defaults.modelProfileId]);

  const selectedCompany = useMemo(() => {
    return selectedTicker ? state.companies.find((company) => company.ticker === selectedTicker) || null : null;
  }, [selectedTicker, state.companies]);

  const selectedLibraryEntries = useMemo(() => {
    return state.reportLibrary.entries
      .filter((entry) => entry.ticker === selectedCompany?.ticker)
      .sort(compareReportEntriesNewest);
  }, [selectedCompany?.ticker, state.reportLibrary.entries]);

  const sortedReportLibraryEntries = useMemo(() => {
    return [...state.reportLibrary.entries].sort(compareReportEntriesNewest);
  }, [state.reportLibrary.entries]);

  const manualReviewWorkbenchEntries = useMemo(() => {
    return [...sortedReportLibraryEntries].sort((left, right) => {
      const byTime = reportEntryTimestamp(right) - reportEntryTimestamp(left);
      if (byTime !== 0) {
        return byTime;
      }
      const leftStatus = manualReviewStatusFor(left);
      const rightStatus = manualReviewStatusFor(right);
      return MANUAL_REVIEW_STATUS_ORDER[leftStatus] - MANUAL_REVIEW_STATUS_ORDER[rightStatus] ||
        left.ticker.localeCompare(right.ticker);
    });
  }, [sortedReportLibraryEntries]);

  const manualReviewStatusCounts = useMemo(() => {
    const counts: Record<ManualReviewWorkbenchStatus, number> = {
      ingested: 0,
      audit_failed: 0,
      review_ready: 0,
      manual_review: 0,
      approved_internal: 0,
      promotion_blocked: 0,
      public_ready: 0
    };
    for (const entry of state.reportLibrary.entries) {
      counts[manualReviewStatusFor(entry)] += 1;
    }
    return counts;
  }, [state.reportLibrary.entries]);

  const filteredCompanies = useMemo(() => {
    const term = query.trim().toLowerCase();
    const companies = [...state.companies].sort(compareCompaniesNewest);
    if (!term) {
      return companies;
    }
    return companies.filter((company) => {
      return (
        company.ticker.toLowerCase().includes(term) ||
        company.companyName.toLowerCase().includes(term)
      );
    });
  }, [query, state.companies]);

  const activeJobs = useMemo(() => {
    return state.jobs
      .filter((job) => ["queued", "running", "error", "canceled"].includes(job.status))
      .sort(compareJobsNewest)
      .slice(0, 8);
  }, [state.jobs]);

  const sortedComparisons = useMemo(() => {
    return [...state.comparisons].sort(compareComparisonsNewest);
  }, [state.comparisons]);

  const latestRun = selectedCompany?.latestQuality || null;
  const facts = [
    ["Unternehmen", selectedCompany?.companyName || "—"],
    ["Ticker", selectedCompany?.ticker || "—"],
    ["Letztes Rating", decisionText(latestRun?.rating)],
    ["Internal Rating", decisionText(latestRun?.internalRating || latestRun?.rating)],
    ["Public Rating", decisionText(latestRun?.publicRating)],
    ["Review-Status", decisionText(latestRun?.reviewStatus || latestRun?.status)],
    ["Lifecycle", generationStageText(latestRun?.generationStage || String(latestRun?.metrics?.generation_stage || ""))],
    ["Publishable", latestRun?.publishable === true ? "Ja" : "Nein"],
    ["Public Ready", latestRun?.publicReady === true || latestRun?.metrics?.public_ready === true ? "Ja" : "Nein"],
    ["Visibility", visibilityText(latestRun?.lifecycleVisibility || String(latestRun?.metrics?.visibility || ""))],
    ["Trader-Signal", decisionText(latestRun?.traderSignal)],
    ["TradingAgents-Datum", latestRun?.tradingAgentsDate || state.defaults.analysisDate || "—"],
    ["Kurs im Report", latestRun?.latestClose || "—"],
    ["RSI im Report", latestRun?.rsi || "—"],
    ["ATR im Report", latestRun?.atr || "—"],
    ["Render-Modus", renderModeText(latestRun?.renderMode || String(latestRun?.metrics?.render_mode || ""))],
    ["Score Scope", String(latestRun?.scoreScope || latestRun?.metrics?.score_scope || "—")],
    ["Promotion Gate", String(latestRun?.promotionGateVerdict || latestRun?.metrics?.promotion_gate_verdict || "—")],
    ["Publish Gate", String(latestRun?.publishGateVerdict || latestRun?.metrics?.publish_gate_verdict || "—")],
    ["Publish Score", metric(latestRun, "publish_quality_score")],
    ["Internal Score", metric(latestRun, "internal_research_quality_score")],
    ["Data Confidence", metric(latestRun, "data_confidence_score")],
    ["Final-PDF-Seiten", metric(latestRun, "complete_pdf_pages")],
    ["Final-PDF-Wörter", metric(latestRun, "complete_pdf_words")],
    ["Quellwörter", metric(latestRun, "raw_source_words")],
    ["Qualität", qualityText(latestRun?.verdict)],
    ["Laufzeit", formatSeconds(latestRun?.elapsedSeconds)],
    ["Modell", latestRun?.deepModel || state.defaults.deepModel || "—"]
  ];

  async function startReport() {
    const requestedInput = draftTicker.trim();
    if (!requestedInput) {
      setError("Bitte einen Ticker oder Firmennamen eingeben.");
      return;
    }
    setSubmitting(true);
    setError("");
    setNotice("");
    try {
      const { job } = await fetchJson<{ job: Job }>("/api/jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ticker: requestedInput,
          analysisDate: state.defaults.analysisDate,
          modelProfileId: selectedModelProfile?.id || state.defaults.modelProfileId
        })
      });
      setNotice(`${job.ticker} startet mit ${job.modelProfileLabel || selectedModelProfile?.label || "Modellprofil"}.`);
      pendingOpenJobIdRef.current = job.id;
      setSelectedTicker("");
      setDraftTicker(job.ticker);
      setReader(null);
      setTextReader(null);
      setComparisonDetail(null);
      syncRoute(undefined, null);
      await loadState();
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : String(submitError));
    } finally {
      setSubmitting(false);
    }
  }

  async function startComparison() {
    const requestedInput = draftTicker.trim();
    if (!requestedInput) {
      setError("Bitte einen Ticker oder Firmennamen für den Vergleich eingeben.");
      return;
    }
    const profileIds = comparisonProfileIds.filter((profileId) =>
      runnableProfiles.some((profile) => profile.id === profileId)
    );
    if (profileIds.length < 2) {
      setError("Bitte mindestens zwei freie Modellprofile für den Vergleich wählen.");
      return;
    }
    setComparisonSubmitting(true);
    setError("");
    setNotice("");
    try {
      const { comparison } = await fetchJson<{ comparison: Comparison }>("/api/comparisons", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ticker: requestedInput,
          analysisDate: state.defaults.analysisDate,
          modelProfileIds: profileIds
        })
      });
      const queued = comparison.results.filter((result) => result.status === "queued").length;
      const blocked = comparison.results.filter((result) => result.status === "blocked").length;
      setNotice(`Vergleich ${comparison.ticker}: ${queued} gestartet, ${blocked} blockiert.`);
      setSelectedTicker(comparison.ticker);
      setDraftTicker(comparison.ticker);
      setReader(null);
      setTextReader(null);
      setComparisonDetail(comparison);
      syncRoute(comparison.ticker, null);
      await loadState();
    } catch (comparisonError) {
      setError(comparisonError instanceof Error ? comparisonError.message : String(comparisonError));
    } finally {
      setComparisonSubmitting(false);
    }
  }

  async function retryJob(job: Job) {
    setJobActionId(job.id);
    setError("");
    setNotice("");
    try {
      const { job: retry } = await fetchJson<{ job: Job }>(`/api/jobs/${job.id}/retry`, {
        method: "POST"
      });
      pendingOpenJobIdRef.current = retry.id;
      setSelectedTicker("");
      setDraftTicker(retry.ticker);
      setReader(null);
      setTextReader(null);
      setComparisonDetail(null);
      syncRoute(undefined, null);
      await loadState();
    } catch (retryError) {
      setError(retryError instanceof Error ? retryError.message : String(retryError));
    } finally {
      setJobActionId(null);
    }
  }

  async function retryFailedJobs(ticker?: string) {
    setJobActionId("retry-failed");
    setError("");
    setNotice("");
    try {
      const result = await fetchJson<{ queued: number; blocked: number; ticker: string | null }>("/api/jobs/retry-failed", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ticker: ticker || selectedCompany?.ticker || "",
          limit: 6
        })
      });
      setNotice(`${result.queued} Läufe neu gestartet${result.blocked ? `, ${result.blocked} blockiert` : ""}.`);
      await loadState();
    } catch (retryError) {
      setError(retryError instanceof Error ? retryError.message : String(retryError));
    } finally {
      setJobActionId(null);
    }
  }

  async function cancelJob(job: Job) {
    setJobActionId(job.id);
    setError("");
    try {
      await fetchJson<{ job: Job }>(`/api/jobs/${job.id}/cancel`, {
        method: "POST"
      });
      if (pendingOpenJobIdRef.current === job.id) {
        pendingOpenJobIdRef.current = null;
      }
      await loadState();
    } catch (cancelError) {
      setError(cancelError instanceof Error ? cancelError.message : String(cancelError));
    } finally {
      setJobActionId(null);
    }
  }

  async function removeJob(job: Job) {
    setJobActionId(job.id);
    setError("");
    setNotice("");
    try {
      await fetchJson<{ removed: boolean; job: Job }>(`/api/jobs/${job.id}`, {
        method: "DELETE"
      });
      if (pendingOpenJobIdRef.current === job.id) {
        pendingOpenJobIdRef.current = null;
      }
      setNotice(`${job.ticker}: Lauf aus der Übersicht entfernt.`);
      await loadState();
    } catch (removeError) {
      setError(removeError instanceof Error ? removeError.message : String(removeError));
    } finally {
      setJobActionId(null);
    }
  }

  async function openFailureReport(job: Job) {
    if (!job.failureReportId) {
      setError("Für diesen Lauf gibt es keinen Fehlerbericht.");
      return;
    }
    setJobActionId(job.id);
    setError("");
    try {
      const response = await fetch(`/api/failures/${job.failureReportId}`);
      const markdown = await response.text();
      if (!response.ok) {
        throw new Error(markdown || "Fehlerbericht nicht gefunden.");
      }
      setReader(null);
      setComparisonDetail(null);
      setTextReader({
        title: `Fehlerbericht: ${job.ticker}`,
        markdown,
        badge: "Fehleranalyse"
      });
      syncRoute(selectedCompany?.ticker || selectedTicker, null);
    } catch (failureError) {
      setError(failureError instanceof Error ? failureError.message : String(failureError));
    } finally {
      setJobActionId(null);
    }
  }

  async function openMarkdownArtifact(title: string, url: string) {
    if (!url) {
      setError("Für diesen Report gibt es keine Markdown-Ansicht.");
      return;
    }
    setError("");
    setNotice("");
    try {
      const response = await fetch(url);
      const markdown = await response.text();
      if (!response.ok) {
        throw new Error(markdown || "Markdown-Report nicht gefunden.");
      }
      setReader(null);
      setComparisonDetail(null);
      setTextReader({
        title,
        markdown,
        badge: "Report"
      });
      syncRoute(selectedCompany?.ticker || selectedTicker, null);
    } catch (markdownError) {
      setError(markdownError instanceof Error ? markdownError.message : String(markdownError));
    }
  }

  async function copyTextReaderMarkdown() {
    if (!textReader?.markdown) {
      return;
    }
    try {
      await navigator.clipboard.writeText(textReader.markdown);
      setNotice("Text wurde kopiert.");
    } catch {
      setError("Kopieren ist in diesem Browser-Kontext nicht erlaubt.");
    }
  }

  async function openComparison(comparisonId: string) {
    setComparisonActionId(comparisonId);
    setError("");
    setNotice("");
    try {
      const { comparison } = await fetchJson<{ comparison: Comparison }>(`/api/comparisons/${comparisonId}`);
      setComparisonDetail(comparison);
      setReader(null);
      setTextReader(null);
      setSelectedTicker(comparison.ticker);
      setDraftTicker(comparison.ticker);
      syncRoute(comparison.ticker, null);
    } catch (comparisonError) {
      setError(comparisonError instanceof Error ? comparisonError.message : String(comparisonError));
    } finally {
      setComparisonActionId(null);
    }
  }

  async function evaluateComparison(comparisonId: string) {
    setComparisonActionId(comparisonId);
    setError("");
    setNotice("");
    try {
      const { comparison } = await fetchJson<{ comparison: Comparison }>(`/api/comparisons/${comparisonId}/evaluate`, {
        method: "POST"
      });
      setComparisonDetail(comparison);
      setNotice(`Vergleich ${comparison.ticker} wurde ausgewertet.`);
      await loadState();
    } catch (comparisonError) {
      setError(comparisonError instanceof Error ? comparisonError.message : String(comparisonError));
    } finally {
      setComparisonActionId(null);
    }
  }

  async function updateLibraryEntry(entry: PublicReportEntry, patch: Partial<PublicReportEntry>) {
    setLibraryActionId(entry.id);
    setError("");
    setNotice("");
    try {
      await fetchJson<{ entry: PublicReportEntry; reportLibrary: ReportLibrary }>(`/api/public-library/${entry.id}/review`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patch)
      });
      setNotice(`${entry.ticker}: Library-Status aktualisiert.`);
      await loadState();
    } catch (libraryError) {
      setError(libraryError instanceof Error ? libraryError.message : String(libraryError));
    } finally {
      setLibraryActionId(null);
    }
  }

  async function dismissLibraryEntry(entry: PublicReportEntry) {
    const confirmed = window.confirm(
      `${entry.ticker} aus der Übersicht entfernen? Die Report-Dateien bleiben erhalten.`
    );
    if (!confirmed) {
      return;
    }
    setLibraryActionId(entry.id);
    setError("");
    setNotice("");
    try {
      await fetchJson<{ dismissed: boolean; entry: PublicReportEntry; reportLibrary: ReportLibrary }>(`/api/public-library/${entry.id}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dismissedBy: "operator" })
      });
      setNotice(`${entry.ticker}: Report aus der Übersicht entfernt.`);
      await loadState();
    } catch (libraryError) {
      setError(libraryError instanceof Error ? libraryError.message : String(libraryError));
    } finally {
      setLibraryActionId(null);
    }
  }

  function openPrimaryLibraryArtifact(entry: PublicReportEntry) {
    const url = primaryArtifactUrl(entry);
    if (!url) {
      setError("Für diesen Report gibt es kein öffnbares Artefakt.");
      return;
    }
    if (operatorStatusKey(entry) === "public_final" && entry.pdfUrl) {
      window.open(entry.pdfUrl, "_blank");
      return;
    }
    openMarkdownArtifact(`${entry.ticker} · ${primaryArtifactLabel(entry)}`, url);
  }

  function handleReviewAction(entry: PublicReportEntry) {
    const status = operatorStatusKey(entry);
    if (status === "manual_review" || status === "markdown_first_qa" || status === "public_final") {
      setOperatorModalEntry(entry);
      return;
    }
    updateLibraryEntry(entry, {
      reviewStatus: "reviewed",
      sourceStatus: "human_verified",
      visibility: "member",
      nonAdvice: true
    });
  }

  function toggleComparisonProfile(profileId: string) {
    setComparisonProfileIds((current) => {
      if (current.includes(profileId)) {
        return current.filter((item) => item !== profileId);
      }
      return [...current, profileId];
    });
  }

  const focusedWorkspace = Boolean(reader || textReader || comparisonDetail);
  const isMainPage = !selectedCompany && !focusedWorkspace;

  return (
    <div className={`appShell ${isMainPage ? "isMainPage" : selectedCompany && !focusedWorkspace ? "isCompanyPage" : ""}`}>
      <aside className="libraryPane">
        <div className="brand">
          <div className="brandMark">16</div>
          <div>
            <div className="brandName">Room 16</div>
            <div className="brandSubline">Research Desk</div>
          </div>
        </div>

        <button
          className={`mainNavRow ${isMainPage ? "isSelected" : ""}`}
          type="button"
          onClick={() => {
            setSelectedTicker("");
            setReader(null);
            setTextReader(null);
            setComparisonDetail(null);
            syncRoute(undefined, null);
          }}
        >
          <span className="rowTicker">MAIN</span>
          <span className="rowName">Reports & Pipeline</span>
          <span className="rowMeta">
            {state.reportLibrary.summary.totalReports} Reports · {state.reportMachine.runningJobs} läuft
          </span>
        </button>

        <label className="searchBox">
          <Search size={16} aria-hidden="true" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Ticker oder Unternehmen"
          />
        </label>

        <div className="companyList" aria-label="Unternehmen">
          {filteredCompanies.map((company) => {
            const isSelected = company.ticker === selectedCompany?.ticker;
            return (
              <button
                className={`companyRow ${isSelected ? "isSelected" : ""}`}
                key={company.ticker}
                onClick={() => {
                  setSelectedTicker(company.ticker);
                  setReader(null);
                  setTextReader(null);
                  setComparisonDetail(null);
                  syncRoute(company.ticker, null);
                }}
              >
                <span className="rowTicker">{company.ticker}</span>
                <span className="rowName">{company.companyName}</span>
                <span className="rowMeta">{company.reportCount} Reports</span>
              </button>
            );
          })}
        </div>
      </aside>

      <main className={`workspace ${focusedWorkspace ? "isFocusedWorkspace" : ""}`}>
        <header className="topBar">
          <div className="selectedTitle">
            <div className="eyebrow">{isMainPage ? "Report Hub" : "Interner Research-Output"}</div>
            <h1>{isMainPage ? "Reports & Pipeline" : selectedCompany ? selectedCompany.companyName : "Room 16"}</h1>
          </div>

          <div className="topActions">
            {selectedCompany?.latestReport && !focusedWorkspace ? (
              <button
                className="readButton"
                type="button"
                onClick={() => {
                  setReader(selectedCompany.latestReport);
                  setComparisonDetail(null);
                  setTextReader(null);
                  syncRoute(selectedCompany.ticker, "latest");
                }}
              >
                <FileText size={16} />
                <span>Letzten Report öffnen</span>
              </button>
            ) : null}
            <form
              className="newReportForm"
              onSubmit={(event) => {
                event.preventDefault();
                startReport();
              }}
            >
              <input
                value={draftTicker}
                onChange={(event) => setDraftTicker(event.target.value)}
                placeholder="Ticker oder Firmenname"
                aria-label="Ticker oder Firmenname"
              />
              <select
                className="profileSelect"
                value={selectedModelProfile?.id || selectedModelProfileId}
                onChange={(event) => setSelectedModelProfileId(event.target.value)}
                aria-label="Modellprofil"
              >
                {runnableProfiles.map((profile) => (
                  <option
                    key={profile.id}
                    value={profile.id}
                  >
                    {profile.label}
                  </option>
                ))}
              </select>
              <button className="primaryButton" type="submit" disabled={submitting}>
                {submitting ? <RefreshCw className="spin" size={16} /> : <Play size={16} />}
                <span>Report erstellen</span>
              </button>
            </form>
          </div>
        </header>

        <div className="statusStrip" aria-label="Systemstatus">
          <span>
            Datum <strong>{state.defaults.analysisDate || "—"}</strong>
          </span>
          <span>
            Pipeline <strong>{state.preflight.ok ? "Bereit" : "Prüfen"}</strong>
          </span>
          <span>
            Hardening <strong>{verdictText(state.hardening.verdict)}</strong>
          </span>
          <span>
            Modell <strong>{selectedModelProfile?.label || state.defaults.deepModel}</strong>
          </span>
          <span>
            Shelf <strong>{state.companies.length} Unternehmen</strong>
          </span>
          <span>
            Maschine <strong>{state.reportMachine.ready ? "Bereit" : "Prüfen"}</strong>
          </span>
          <span>
            Library{" "}
            <strong>
              {state.reportLibrary.summary.publicReady}/{state.reportLibrary.summary.totalReports} Public Final geprüft
            </strong>
          </span>
          <span>
            Namensliste{" "}
            <strong>
              {state.tickerAliases?.uniqueTickers ?? 0} Ticker / {state.tickerAliases?.aliasEntries ?? 0} Namen
            </strong>
          </span>
        </div>

        {runnableProfiles.length >= 2 && isMainPage ? (
          <section className="comparisonPanel" aria-label="Modellvergleich">
            <div className="comparisonCopy">
              <strong>Modellvergleich</strong>
            </div>
            <div className="profileChips">
              {runnableProfiles.map((profile) => {
                const checked = comparisonProfileIds.includes(profile.id);
                return (
                  <button
                    className={`profileChip ${checked ? "isChecked" : ""}`}
                    key={profile.id}
                    type="button"
                    onClick={() => toggleComparisonProfile(profile.id)}
                    aria-pressed={checked}
                  >
                    <span>{profile.label}</span>
                    <em>{profile.badge || profile.provider}</em>
                  </button>
                );
              })}
            </div>
            <button
              className="compareButton"
              type="button"
              disabled={comparisonSubmitting || comparisonProfileIds.length < 2}
              onClick={() => startComparison()}
            >
              {comparisonSubmitting ? <RefreshCw className="spin" size={15} /> : <Play size={15} />}
              <span>Vergleich starten</span>
            </button>
          </section>
        ) : null}

        {isMainPage && activeJobs.length ? (
          <section className="inlineJobsPanel isMainPipeline" aria-label="Aktive Läufe">
            <div className="inlineJobsHeader">
              <strong>Aktive Läufe</strong>
              <button
                className="iconButton"
                type="button"
                disabled={refreshing}
                onClick={refreshState}
                aria-label="Übersicht aktualisieren"
                title="Übersicht neu laden"
              >
                <RefreshCw className={refreshing ? "spin" : ""} size={16} />
              </button>
            </div>
            <div className="inlineJobList">
              {activeJobs.map((job) => (
                <div className={`jobRow ${job.status}`} key={job.id}>
                  <div className="jobTopline">
                    <span>{job.ticker}</span>
                    <em>{statusText(job.status)}</em>
                  </div>
                  <div className="jobStage">{job.stage}</div>
                  <div className="jobMeta">
                    {[job.modelProfileLabel, formatDate(job.updatedAt)].filter(Boolean).join(" · ")}
                  </div>
                  <JobWorkflowChecklist job={job} />
                  <div className="jobActions">
                    {job.status === "running" ? (
                      <button
                        className="jobActionButton danger"
                        type="button"
                        disabled={jobActionId === job.id}
                        onClick={() => cancelJob(job)}
                      >
                        <StopCircle size={14} />
                        <span>{jobActionId === job.id ? "Stoppt" : "Stoppen"}</span>
                      </button>
                    ) : null}
                    {job.status === "queued" ? (
                      <button
                        className="jobActionButton danger"
                        type="button"
                        disabled={jobActionId === job.id}
                        onClick={() => removeJob(job)}
                      >
                        <Trash2 size={14} />
                        <span>{jobActionId === job.id ? "Entfernt" : "Entfernen"}</span>
                      </button>
                    ) : null}
                    {job.status === "error" ? (
                      <button
                        className="jobActionButton"
                        type="button"
                        disabled={jobActionId === job.id}
                        onClick={() => retryJob(job)}
                      >
                        <Play size={14} />
                        <span>{jobActionId === job.id ? "Startet" : "Neu starten"}</span>
                      </button>
                    ) : null}
                    {job.status === "error" ? (
                      job.failureReportId ? (
                        <button
                          className="jobActionButton"
                          type="button"
                          disabled={jobActionId === job.id}
                          onClick={() => openFailureReport(job)}
                        >
                          <FileText size={14} />
                          <span>Fehlerbericht</span>
                        </button>
                      ) : null
                    ) : null}
                    {["error", "canceled"].includes(job.status) ? (
                      <button
                        className="jobActionButton"
                        type="button"
                        disabled={jobActionId === job.id}
                        onClick={() => removeJob(job)}
                      >
                        <Trash2 size={14} />
                        <span>{jobActionId === job.id ? "Blendet aus" : "Ausblenden"}</span>
                      </button>
                    ) : null}
                  </div>
                </div>
              ))}
            </div>
          </section>
        ) : null}

        {isMainPage && state.reportMachine.recoverableJobs > 0 ? (
          <section className="machineRecoveryPanel" aria-label="Report-Maschine Recovery">
            <div>
              <strong>Report-Maschine</strong>
              <span>{state.reportMachine.recoverableJobs} fehlgeschlagene/gestoppte Läufe können neu gestartet werden.</span>
            </div>
            <button
              className="jobActionButton"
              type="button"
              disabled={jobActionId === "retry-failed"}
              onClick={() => retryFailedJobs()}
            >
              <Play size={14} />
              <span>{jobActionId === "retry-failed" ? "Startet" : "Fehler neu starten"}</span>
            </button>
          </section>
        ) : null}

        {error ? (
          <div className="inlineError" role="alert">
            <AlertTriangle size={17} />
            <span>{error}</span>
          </div>
        ) : null}

        {notice ? (
          <div className="inlineNotice" role="status">
            <span>{notice}</span>
          </div>
        ) : null}

        {comparisonDetail ? (
          <ComparisonDetailView
            comparison={comparisonDetail}
            evaluating={comparisonActionId === comparisonDetail.id}
            jobActionId={jobActionId}
            onBack={() => setComparisonDetail(null)}
            onEvaluate={() => evaluateComparison(comparisonDetail.id)}
            onCancelJob={cancelJob}
            onRetryJob={retryJob}
            onRemoveJob={removeJob}
            onOpenFailureReport={openFailureReport}
            onOpenMarkdown={openMarkdownArtifact}
          />
        ) : textReader ? (
          <section className="readerView">
            <div className="readerHeader">
              <button
                className="ghostButton"
                type="button"
                onClick={() => setTextReader(null)}
              >
                <ArrowLeft size={16} />
                <span>Zurück</span>
              </button>
              <div className="readerTitle">{textReader.title}</div>
              <span className="readerBadge">{textReader.badge}</span>
            </div>
            <div className="readerDocument">
              <div className="readerTools">
                <button className="ghostButton" type="button" onClick={copyTextReaderMarkdown}>
                  <Copy size={15} />
                  <span>Text kopieren</span>
                </button>
                <span>Interner Arbeitsbereich: kein Public-Publish aus der Leseansicht.</span>
              </div>
              <MarkdownArticle markdown={textReader.markdown} />
            </div>
          </section>
        ) : reader ? (
          <section className="readerView">
            <div className="readerHeader">
              <button
                className="ghostButton"
                type="button"
                onClick={() => {
                  setReader(null);
                  syncRoute(selectedCompany?.ticker, null);
                }}
              >
                <ArrowLeft size={16} />
                <span>Zurück</span>
              </button>
              <div className="readerTitle">{reader.title}</div>
              <button className="ghostButton" type="button" disabled={!reader.url} onClick={() => window.open(reader.url || "", "_blank")}>
                <ExternalLink size={16} />
                <span>PDF extern öffnen</span>
              </button>
            </div>
            <MarkdownDocument ticker={selectedCompany?.ticker || selectedTicker} report={reader} />
          </section>
        ) : isMainPage ? (
          <section className="mainPage" aria-label="Main Page Reports und Pipeline">
            <div className="mainMetricGrid" aria-label="Report-Übersicht">
              <div>
                <span>Reports</span>
                <strong>{state.reportLibrary.summary.totalReports}</strong>
              </div>
              <div>
                <span>Unternehmen</span>
                <strong>{state.reportLibrary.summary.companies || state.companies.length}</strong>
              </div>
              <div>
                <span>Manual Review</span>
                <strong>{state.reportLibrary.summary.manualReview}</strong>
              </div>
              <div>
                <span>Pipeline</span>
                <strong>{state.reportMachine.ready ? "Bereit" : "Prüfen"}</strong>
              </div>
            </div>

            <div className="mainPipelineGrid">
              <section className="pipelineBlock" aria-label="Report-Pipeline">
                <div className="sectionHeader">
                  <div>
                    <h2>Pipeline</h2>
                    <p>{state.reportMachine.nextAction}</p>
                  </div>
                  <span>{state.reportMachine.queuedJobs} wartend · {state.reportMachine.runningJobs} läuft</span>
                </div>
                <div className="pipelineFlow" aria-label="Report-Entstehungspunkte">
                  {(state.reportMachine.policy.reportFlowLabels || []).map((step, index) => (
                    <span key={step.id}>
                      <strong>{index + 1}</strong>
                      {step.label}
                    </span>
                  ))}
                </div>
              </section>

              <section className="pipelineBlock" aria-label="Report-Maschine Status">
                <div className="sectionHeader">
                  <div>
                    <h2>Maschine</h2>
                    <p>Aktueller Produktionszustand und Recovery-Kante.</p>
                  </div>
                  <span>{formatDate(state.reportMachine.generatedAt)}</span>
                </div>
                <div className="machineMetricGrid">
                  <div>
                    <span>Läuft</span>
                    <strong>{state.reportMachine.runningJobs}</strong>
                  </div>
                  <div>
                    <span>Wartend</span>
                    <strong>{state.reportMachine.queuedJobs}</strong>
                  </div>
                  <div>
                    <span>Re-Run</span>
                    <strong>{state.reportMachine.recoverableJobs}</strong>
                  </div>
                  <div>
                    <span>Public-ready</span>
                    <strong>{state.reportLibrary.summary.publicReady}</strong>
                  </div>
                </div>
              </section>
            </div>

            <div className="libraryGateBlock manualReviewWorkbenchBlock" aria-label="Manual Review Workbench">
              <div className="sectionHeader">
                <div>
                  <h2>Manual Review Workbench</h2>
                  <p>Interner Operator-Blick: zeigt, warum Dossiers hidden bleiben, welche Review-Gates offen sind und welche nächste Aktion erlaubt ist.</p>
                </div>
                <div className="sectionHeaderActions">
                  <span>{manualReviewStatusCounts.manual_review} Manual Review · {manualReviewStatusCounts.promotion_blocked} Promotion blockiert</span>
                  <button
                    className="iconButton"
                    type="button"
                    disabled={refreshing}
                    onClick={refreshState}
                    aria-label="Workbench aktualisieren"
                    title="Workbench neu laden"
                  >
                    <RefreshCw className={refreshing ? "spin" : ""} size={16} />
                  </button>
                </div>
              </div>
              <div className="workbenchSummaryGrid">
                <div>
                  <span>Manual Review offen</span>
                  <strong>{manualReviewStatusCounts.manual_review}</strong>
                </div>
                <div>
                  <span>Promotion blockiert</span>
                  <strong>{manualReviewStatusCounts.promotion_blocked}</strong>
                </div>
                <div>
                  <span>Review abschließen</span>
                  <strong>{manualReviewStatusCounts.review_ready}</strong>
                </div>
                <div>
                  <span>Intern freigegeben</span>
                  <strong>{manualReviewStatusCounts.approved_internal}</strong>
                </div>
              </div>
              <div className="tableWrap manualReviewWorkbenchTableWrap">
                <table>
                  <thead>
                    <tr>
                      <th>Dossier</th>
                      <th>Status</th>
                      <th>QA</th>
                      <th>Review-Gate</th>
                      <th>Gate</th>
                      <th>Gründe</th>
                      <th>Effective</th>
                      <th>Nächste Aktion</th>
                    </tr>
                  </thead>
                  <tbody>
                    {manualReviewWorkbenchEntries.map((entry) => {
                      const workbenchStatus = manualReviewStatusFor(entry);
                      const reasons = manualReviewReasonLines(entry);
                      return (
                        <tr key={entry.id}>
                          <td>
                            <div className="reportName">
                              <FileText size={16} />
                              <span>{entry.ticker} · {stripReportTitle(entry.title)}</span>
                            </div>
                          </td>
                          <td>
                            <span className="modelBadge">{generationStageText(entry.generationStage)}</span>
                            <small>{renderModeText(entry.renderMode)}</small>
                          </td>
                          <td>
                            <span className={entry.qualityVerdict === "fail" ? "qaBadge isFail" : "qaBadge"}>
                              {verdictText(entry.qualityVerdict)}
                            </span>
                            <small>{entry.qualityStatus || "Kein Quality-Status im Report"}</small>
                          </td>
                          <td>
                            <span className={manualReviewStatusClass(workbenchStatus)}>
                              {MANUAL_REVIEW_STATUS_LABELS[workbenchStatus]}
                            </span>
                            <small>{reviewStatusText(entry.reviewStatus)} · {sourceStatusText(entry.sourceStatus)}</small>
                          </td>
                          <td>
                            <span className={`qaBadge ${["rejected", "manual_review"].includes(entry.qualityGate.status) ? "isFail" : ""}`}>
                              {libraryGateText(entry.qualityGate.status)}
                            </span>
                            <small>{manualReviewGateSummary(entry)}</small>
                          </td>
                          <td>
                            {reasons.length ? (
                              <ul className="reasonList">
                                {reasons.slice(0, 4).map((reason) => (
                                  <li key={reason}>{reason}</li>
                                ))}
                              </ul>
                            ) : (
                              <span className="modelBadge">Keine Gate-Gründe im Quality Report</span>
                            )}
                          </td>
                          <td><span className="modelBadge">{visibilityText(entry.qualityGate.effectiveVisibility)}</span></td>
                          <td className="nextActionCell">
                            <strong>{manualReviewNextAction(entry)}</strong>
                            <div className="workbenchActions">
                              <button
                                className="tableButton"
                                type="button"
                                disabled={!primaryArtifactUrl(entry)}
                                onClick={() => openPrimaryLibraryArtifact(entry)}
                              >
                                {primaryArtifactLabel(entry)}
                              </button>
                              <button
                                className="tableButton"
                                type="button"
                                onClick={() => setOperatorModalEntry(entry)}
                              >
                                {operatorStatusActionLabel(entry)}
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                    {!manualReviewWorkbenchEntries.length ? (
                      <tr>
                        <td colSpan={8} className="emptyCell">
                          Keine Workbench-Einträge, weil die Public-Library-API aktuell keine Dossiers liefert. Erwartet bei leerem Shelf; wenn Reports vorhanden sein müssten, Report-Scan und `npm run verify` prüfen.
                        </td>
                      </tr>
                    ) : null}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="libraryGateBlock mainReportLibrary" aria-label="Alle Reports">
              <div className="sectionHeader">
                <div>
                  <h2>Reports</h2>
                  <p>Gesamtes Report-Regal mit Quality-Gate, Sichtbarkeit, Quellenstatus und erlaubten Operator-Aktionen. Nicht-public-ready bleibt intern.</p>
                </div>
                <div className="sectionHeaderActions">
                  <span>{state.reportLibrary.summary.totalReports} Reports · {state.reportLibrary.summary.hiddenByGate} Public-Freigaben blockiert</span>
                  <button
                    className="iconButton"
                    type="button"
                    disabled={refreshing}
                    onClick={refreshState}
                    aria-label="Übersicht aktualisieren"
                    title="Übersicht neu laden"
                  >
                    <RefreshCw className={refreshing ? "spin" : ""} size={16} />
                  </button>
                </div>
              </div>
              <div className="librarySummaryGrid">
                <div>
                  <span>Public Final freigegeben</span>
                  <strong>{state.reportLibrary.summary.publicReady}</strong>
                </div>
                <div>
                  <span>Member intern freigegeben</span>
                  <strong>{state.reportLibrary.summary.memberReady}</strong>
                </div>
                <div>
                  <span>Human Review offen</span>
                  <strong>{state.reportLibrary.summary.needsHumanReview}</strong>
                </div>
                <div>
                  <span>Gate gesperrt</span>
                  <strong>{state.reportLibrary.summary.rejected}</strong>
                </div>
              </div>
              <div className="tableWrap libraryTableWrap mainReportTableWrap">
                <table>
                  <thead>
                    <tr>
                      <th>Report</th>
                      <th>Ticker</th>
                      <th>Status</th>
                      <th>Requested</th>
                      <th>Effective</th>
                      <th>Gate</th>
                      <th>Sources</th>
                      <th>Review-Gate</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {sortedReportLibraryEntries.map((entry) => {
                      const publicPublishAvailable = isPublicPublishAvailable(entry);
                      return (
                      <tr key={entry.id}>
                        <td>
                          <div className="reportName">
                            <FileText size={16} />
                            <span>{stripReportTitle(entry.title)}</span>
                          </div>
                        </td>
                        <td><span className="modelBadge">{entry.ticker}</span></td>
                        <td>
                          <span className={laneBadgeClass(entry)}>{laneBadgeText(entry)}</span>
                          <small>{renderModeText(entry.renderMode)}</small>
                          <small>{lifecycleReviewText(entry.reviewStatusMetric)} · {entry.scoreScope || "Score-Scope fehlt"}</small>
                        </td>
                        <td><span className="modelBadge">{visibilityText(entry.visibility)}</span></td>
                        <td><span className="modelBadge">{visibilityText(entry.qualityGate.effectiveVisibility)}</span></td>
                        <td>
                          <span className={`qaBadge ${["rejected", "manual_review"].includes(entry.qualityGate.status) ? "isFail" : ""}`}>
                            {libraryGateText(entry.qualityGate.status)}
                          </span>
                          {entry.promotionGateVerdict ? <small>{entry.promotionGateVerdict}</small> : null}
                          <small>publishable: {boolText(entry.publishable)} · public_ready: {boolText(entry.publicReady)}</small>
                          <small>final docs: {boolText(entry.finalDocumentsRendered)}</small>
                          {!entry.finalDocumentsRendered ? <small>Final-PDF/DOCX fehlen; Public-Freigabe blockiert</small> : null}
                          {!publicPublishAvailable ? <small>{nonPublicSafetyCopy(entry)}</small> : null}
                          {entry.externalDisplayRating ? <small>{entry.externalDisplayRating}</small> : null}
                        </td>
                        <td>{sourceStatusText(entry.sourceStatus)}</td>
                        <td>{reviewStatusText(entry.reviewStatus)}</td>
                        <td className="actionsCell libraryActionsCell">
                          <button
                            className="tableButton"
                            type="button"
                            disabled={!primaryArtifactUrl(entry)}
                            onClick={() => openPrimaryLibraryArtifact(entry)}
                          >
                            {primaryArtifactLabel(entry)}
                          </button>
                          <button
                            className="tableButton"
                            type="button"
                            onClick={() => setOperatorModalEntry(entry)}
                          >
                            {operatorStatusActionLabel(entry)}
                          </button>
                          {publicPublishAvailable ? (
                            <button
                              className="tableButton"
                              type="button"
                              disabled={libraryActionId === entry.id}
                              onClick={() => updateLibraryEntry(entry, { visibility: "public" })}
                            >
                              Public-Freigabe setzen
                            </button>
                          ) : (
                            <span className="modelBadge">Public-Freigabe blockiert</span>
                          )}
                          <button
                            className="iconButton"
                            type="button"
                            disabled={!entry.pdfUrl}
                            onClick={() => window.open(entry.pdfUrl || "", "_blank")}
                            aria-label="Final-PDF öffnen"
                            title={entry.pdfUrl ? "Final-PDF öffnen" : "PDF/DOCX noch nicht final gerendert"}
                          >
                            <ExternalLink size={16} />
                          </button>
                          <button
                            className="iconButton dangerIcon"
                            type="button"
                            disabled={libraryActionId === entry.id}
                            onClick={() => dismissLibraryEntry(entry)}
                            aria-label="Report aus Übersicht entfernen"
                            title="Aus Übersicht entfernen"
                          >
                            <Trash2 size={15} />
                          </button>
                        </td>
                      </tr>
                      );
                    })}
                    {!sortedReportLibraryEntries.length ? (
                      <tr>
                        <td colSpan={9} className="emptyCell">
                          Report-Regal leer, weil der Server keine Library-Einträge liefert. Erwartet bei frischer Installation; wenn Reports im Shelf liegen, Report-Scan und `npm run verify` prüfen.
                        </td>
                      </tr>
                    ) : null}
                  </tbody>
                </table>
              </div>
            </div>
          </section>
        ) : selectedCompany ? (
          <section className="companyDetail">
            <div className="factsTable" aria-label="Key Daten">
              {facts.map(([label, value]) => (
                <div className="factRow" key={label}>
                  <span>{label}</span>
                  <strong>{value}</strong>
                </div>
              ))}
            </div>

            <div className="libraryGateBlock" aria-label="Public Report Library">
              <div className="sectionHeader">
                <div>
                  <h2>Public Report Library</h2>
                  <p>Operator-Regal mit harter Sichtbarkeitsbremse: Public erst nach Promotion, Non-Advice, Human Source Verification und Operator-Go.</p>
                </div>
                <span>{state.reportLibrary.summary.totalReports} Reports · {state.reportLibrary.summary.manualReview} Manual Review blockiert</span>
              </div>
              <div className="librarySummaryGrid">
                <div>
                  <span>Public Final freigegeben</span>
                  <strong>{state.reportLibrary.summary.publicReady}</strong>
                </div>
                <div>
                  <span>Manual Review offen</span>
                  <strong>{state.reportLibrary.summary.manualReview}</strong>
                </div>
                <div>
                  <span>Gate gesperrt</span>
                  <strong>{state.reportLibrary.summary.rejected}</strong>
                </div>
                <div>
                  <span>Member intern freigegeben</span>
                  <strong>{state.reportLibrary.summary.memberReady}</strong>
                </div>
                <div>
                  <span>Deep-Tech Guard</span>
                  <strong>{state.reportLibrary.summary.speculative_deep_tech_profile_count}</strong>
                </div>
              </div>
              <div className="tableWrap libraryTableWrap">
                <table>
                  <thead>
                    <tr>
                      <th>Report</th>
                      <th>Status</th>
                      <th>Requested</th>
                      <th>Effective</th>
                      <th>Gate</th>
                      <th>Sources</th>
                      <th>Review-Gate</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedLibraryEntries.map((entry) => {
                      const publicPublishAvailable = isPublicPublishAvailable(entry);
                      return (
                      <tr key={entry.id}>
                        <td>
                          <div className="reportName">
                            <FileText size={16} />
                            <span>{stripReportTitle(entry.title)}</span>
                          </div>
                        </td>
                        <td>
                          <span className={laneBadgeClass(entry)}>{laneBadgeText(entry)}</span>
                          <small>{renderModeText(entry.renderMode)}</small>
                          <small>{lifecycleReviewText(entry.reviewStatusMetric)} · {entry.scoreScope || "Score-Scope fehlt"}</small>
                        </td>
                        <td><span className="modelBadge">{visibilityText(entry.visibility)}</span></td>
                        <td><span className="modelBadge">{visibilityText(entry.qualityGate.effectiveVisibility)}</span></td>
                        <td>
                          <span className={`qaBadge ${["rejected", "manual_review"].includes(entry.qualityGate.status) ? "isFail" : ""}`}>
                            {libraryGateText(entry.qualityGate.status)}
                          </span>
                          {entry.promotionGateVerdict ? <small>{entry.promotionGateVerdict}</small> : null}
                          <small>publishable: {boolText(entry.publishable)} · public_ready: {boolText(entry.publicReady)}</small>
                          <small>final docs: {boolText(entry.finalDocumentsRendered)}</small>
                          {!entry.finalDocumentsRendered ? <small>Final-PDF/DOCX fehlen; Public-Freigabe blockiert</small> : null}
                          {!publicPublishAvailable ? <small>{nonPublicSafetyCopy(entry)}</small> : null}
                          {entry.externalDisplayRating ? <small>{entry.externalDisplayRating}</small> : null}
                          {entry.companyArchetype ? <small>{entry.companyArchetype}</small> : null}
                        </td>
                        <td>{sourceStatusText(entry.sourceStatus)}</td>
                        <td>{reviewStatusText(entry.reviewStatus)}</td>
                        <td className="actionsCell libraryActionsCell">
                          <button
                            className="tableButton"
                            type="button"
                            disabled={libraryActionId === entry.id}
                            onClick={() => handleReviewAction(entry)}
                          >
                            {operatorStatusKey(entry) === "manual_review" ? "Manual-Review-Gründe anzeigen" : operatorStatusKey(entry) === "markdown_first_qa" ? "QA-Artefakte prüfen" : operatorStatusKey(entry) === "public_final" ? "Promotion-Status prüfen" : "Review abschließen"}
                          </button>
                          <button
                            className="tableButton"
                            type="button"
                            disabled={!primaryArtifactUrl(entry)}
                            onClick={() => openPrimaryLibraryArtifact(entry)}
                          >
                            {primaryArtifactLabel(entry)}
                          </button>
                          {publicPublishAvailable ? (
                            <button
                              className="tableButton"
                              type="button"
                              disabled={libraryActionId === entry.id}
                              onClick={() => updateLibraryEntry(entry, { visibility: "public" })}
                            >
                              Public-Freigabe setzen
                            </button>
                          ) : (
                            <span className="modelBadge">Public-Freigabe blockiert</span>
                          )}
                          <button
                            className="iconButton dangerIcon"
                            type="button"
                            disabled={libraryActionId === entry.id}
                            onClick={() => dismissLibraryEntry(entry)}
                            aria-label="Report aus Übersicht entfernen"
                            title="Aus Übersicht entfernen"
                          >
                            <Trash2 size={15} />
                          </button>
                        </td>
                      </tr>
                      );
                    })}
                    {!selectedLibraryEntries.length ? (
                      <tr>
                        <td colSpan={8} className="emptyCell">
                          Kein Library-Gate-Eintrag für dieses Unternehmen, weil kein gescanntes Report-Artefakt mit Gate-Metadaten gefunden wurde. Erwartet bei neuem Ticker; nächster Schritt: Report erstellen oder Report-Machine prüfen.
                        </td>
                      </tr>
                    ) : null}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="historyBlock">
              <div className="sectionHeader">
                <h2>Report-Historie</h2>
                <span>{selectedCompany?.reportCount || 0} Dateien</span>
              </div>
              <div className="tableWrap">
                <table>
                  <thead>
                    <tr>
                      <th>Report</th>
                      <th>Modell</th>
                      <th>QA</th>
                      <th>Geändert</th>
                      <th>Größe</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedCompany?.reports.map((report) => (
                      <tr key={report.id}>
                        <td>
                          <div className="reportName">
                            <FileText size={16} />
                            <span>{stripReportTitle(report.title)}</span>
                          </div>
                        </td>
                        <td><span className="modelBadge">{reportModelLabel(report)}</span></td>
                        <td>
                          <span className={`qaBadge ${report.quality?.verdict === "fail" ? "isFail" : ""}`}>
                            {reportQualityText(report)}
                          </span>
                        </td>
                        <td>{formatDate(report.modifiedAt)}</td>
                        <td>{formatBytes(report.sizeBytes)}</td>
                        <td className="actionsCell">
                          <button
                            className="tableButton"
                            type="button"
                            onClick={() => {
                              setReader(report);
                              setComparisonDetail(null);
                              setTextReader(null);
                              syncRoute(selectedCompany?.ticker, report);
                            }}
                          >
                            Report im Reader öffnen
                          </button>
                          <button
                            className="tableButton"
                            type="button"
                            disabled={!report.internalBestReportUrl}
                            onClick={() => openMarkdownArtifact(`${report.quality?.ticker || selectedCompany?.ticker} · Internal Best`, report.internalBestReportUrl || "")}
                          >
                            Internal Best öffnen
                          </button>
                          <button
                            className="iconButton"
                            type="button"
                            disabled={!report.url}
                            onClick={() => window.open(report.url || "", "_blank")}
                            aria-label="PDF extern öffnen"
                            title={report.url ? "PDF extern öffnen" : "PDF/DOCX noch nicht final gerendert"}
                          >
                            <ExternalLink size={16} />
                          </button>
                        </td>
                      </tr>
                    ))}
                    {!selectedCompany?.reports.length ? (
                      <tr>
                        <td colSpan={6} className="emptyCell">
                          Keine Report-Artefakte, weil für diesen Ticker noch kein Lauf im Shelf liegt. Erwarteter Zustand vor dem ersten Lauf; nächster Schritt: Report erstellen.
                        </td>
                      </tr>
                    ) : null}
                  </tbody>
                </table>
              </div>
            </div>
          </section>
        ) : (
          <section className="companyDetail">
            <div className="quietState">Keine Detailansicht geöffnet, weil kein Unternehmen ausgewählt ist. Erwartet nach Start; wähle links einen Ticker oder öffne Reports & Pipeline.</div>
          </section>
        )}
      </main>

      <aside className="jobsPane">
        <div className="jobsHeader">
          <h2>Läufe</h2>
          <button
            className="iconButton"
            type="button"
            disabled={refreshing}
            onClick={refreshState}
            aria-label="Übersicht aktualisieren"
            title="Übersicht neu laden"
          >
            <RefreshCw className={refreshing ? "spin" : ""} size={16} />
          </button>
        </div>

        <div className="jobList">
          {activeJobs.length ? (
            activeJobs.map((job) => (
              <div className={`jobRow ${job.status}`} key={job.id}>
                <div className="jobTopline">
                  <span>{job.ticker}</span>
                  <em>{statusText(job.status)}</em>
                </div>
                <div className="jobStage">{job.stage}</div>
                <div className="jobMeta">
                  {[job.modelProfileLabel, formatDate(job.updatedAt)].filter(Boolean).join(" · ")}
                </div>
                <JobWorkflowChecklist job={job} />
                {job.status === "error" ? (
                  <div className="jobError">
                    <div>{job.error}</div>
                  </div>
                ) : null}
                <div className="jobActions">
                  {job.status === "running" ? (
                    <button
                      className="jobActionButton danger"
                      type="button"
                      disabled={jobActionId === job.id}
                      onClick={() => cancelJob(job)}
                    >
                      <StopCircle size={14} />
                      <span>{jobActionId === job.id ? "Stoppt" : "Stoppen"}</span>
                    </button>
                  ) : null}
                  {job.status === "queued" ? (
                    <button
                      className="jobActionButton danger"
                      type="button"
                      disabled={jobActionId === job.id}
                      onClick={() => removeJob(job)}
                    >
                      <Trash2 size={14} />
                      <span>{jobActionId === job.id ? "Entfernt" : "Entfernen"}</span>
                    </button>
                  ) : null}
                  {job.status === "error" ? (
                    <button
                      className="jobActionButton"
                      type="button"
                      disabled={jobActionId === job.id}
                      onClick={() => retryJob(job)}
                    >
                      <Play size={14} />
                      <span>{jobActionId === job.id ? "Startet" : "Neu starten"}</span>
                    </button>
                  ) : null}
                  {job.status === "error" ? (
                    job.failureReportId ? (
                      <button
                        className="jobActionButton"
                        type="button"
                        disabled={jobActionId === job.id}
                        onClick={() => openFailureReport(job)}
                      >
                        <FileText size={14} />
                        <span>Fehlerbericht</span>
                      </button>
                    ) : null
                  ) : null}
                  {["error", "canceled"].includes(job.status) ? (
                    <button
                      className="jobActionButton"
                      type="button"
                      disabled={jobActionId === job.id}
                      onClick={() => removeJob(job)}
                    >
                      <Trash2 size={14} />
                      <span>{jobActionId === job.id ? "Blendet aus" : "Ausblenden"}</span>
                    </button>
                  ) : null}
                </div>
              </div>
            ))
          ) : (
            <div className="quietState">Keine aktiven Läufe, weil aktuell nichts queued, running, error oder canceled ist. Erwarteter Ruhezustand; nächster Schritt: Ticker starten oder Recovery prüfen.</div>
          )}
        </div>

        {sortedComparisons.length ? (
          <div className="comparisonList">
            <h3>Vergleiche</h3>
            {sortedComparisons.slice(0, 4).map((comparison) => {
              const completed = comparison.counts?.completed || 0;
              const blocked = comparison.results.filter((result) => result.status === "blocked").length;
              return (
                <button
                  className="comparisonRow"
                  key={comparison.id}
                  type="button"
                  disabled={comparisonActionId === comparison.id}
                  onClick={() => openComparison(comparison.id)}
                >
                  <div>
                    <strong>{comparison.ticker}</strong>
                    <span>{completed} fertig · {blocked} blockiert</span>
                  </div>
                  <em>{comparisonStatusText(comparison.status)} · {formatDate(comparison.createdAt)}</em>
                </button>
              );
            })}
          </div>
        ) : null}

        <div className="systemBlock">
          <div className="systemRow">
            <span>Report-Maschine</span>
            <strong>{state.reportMachine.ready ? "Bereit" : "Prüfen"}</strong>
          </div>
          <div className="systemRow">
            <span>Wartend / Läuft</span>
            <strong>{state.reportMachine.queuedJobs} / {state.reportMachine.runningJobs}</strong>
          </div>
          <div className="systemRow">
            <span>Re-Run möglich</span>
            <strong>{state.reportMachine.recoverableJobs}</strong>
          </div>
          {state.reportMachine.recoverableJobs > 0 ? (
            <button
              className="jobActionButton wide"
              type="button"
              disabled={jobActionId === "retry-failed"}
              onClick={() => retryFailedJobs(selectedCompany?.ticker)}
            >
              <Play size={14} />
              <span>{jobActionId === "retry-failed" ? "Startet" : "Fehler neu starten"}</span>
            </button>
          ) : null}
          <div className="systemRow">
            <span>Standard-Datum</span>
            <strong>{state.defaults.analysisDate || "—"}</strong>
          </div>
          <div className="systemRow">
            <span>Provider</span>
            <strong>{state.defaults.provider}</strong>
          </div>
          <div className="systemRow">
            <span>Modellprofil</span>
            <strong>{selectedModelProfile?.label || "—"}</strong>
          </div>
          <div className="systemRow">
            <span>Pipeline</span>
            <strong>{state.preflight.ok ? "Bereit" : "Prüfen"}</strong>
          </div>
          <div className="systemRow">
            <span>Hardening</span>
            <strong>{verdictText(state.hardening.verdict)}</strong>
          </div>
          <div className="systemRow">
            <span>Report-Shelf</span>
            <strong>{state.companies.length} Unternehmen</strong>
          </div>
        </div>
      </aside>
      {operatorModalEntry ? (
        <OperatorStatusModal
          entry={operatorModalEntry}
          onClose={() => setOperatorModalEntry(null)}
          onOpenMarkdown={openMarkdownArtifact}
        />
      ) : null}
    </div>
  );
}
