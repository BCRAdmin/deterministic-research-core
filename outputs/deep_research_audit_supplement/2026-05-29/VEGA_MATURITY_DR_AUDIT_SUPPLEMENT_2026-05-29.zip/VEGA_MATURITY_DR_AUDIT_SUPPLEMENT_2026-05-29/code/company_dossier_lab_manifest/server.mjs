import express from "express";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { spawn, spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { createServer as createViteServer } from "vite";
import { createMutatingApiGuard, enforceNetworkBindingPolicy } from "./server-modules/mutating-api-guard.mjs";
import { evaluatePublicLibraryGate as evaluatePublicLibraryGateContract } from "./server-modules/public-library-gate.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const APP_ROOT = __dirname;
const PROJECT_ROOT = path.resolve(APP_ROOT, "..");
const DEFAULT_ROOM16_SHELF_DIR = path.join(os.homedir(), "Documents", "DreamFactory", "Room16", "Reports");
const SHELF_DIR =
  process.env.ROOM16_SHELF_DIR ||
  process.env.ROOM16_REPORTS_ROOT ||
  DEFAULT_ROOM16_SHELF_DIR;
const RUNTIME_ROOT = path.join(PROJECT_ROOT, ".runtime", "room16-app");
const JOB_DIR = path.join(RUNTIME_ROOT, "jobs");
const LOG_DIR = path.join(RUNTIME_ROOT, "logs");
const FAILURE_DIR = path.join(RUNTIME_ROOT, "failures");
const COMPARISON_DIR = path.join(RUNTIME_ROOT, "comparisons");
const PUBLIC_LIBRARY_DIR = path.join(RUNTIME_ROOT, "public-library");
const PUBLIC_LIBRARY_STATE_PATH = path.join(PUBLIC_LIBRARY_DIR, "report-library-state.json");
const PUBLIC_LIBRARY_SNAPSHOT_PATH = path.join(PUBLIC_LIBRARY_DIR, "latest-library-status.md");
const REPORT_RUNS_DIR = path.join(PROJECT_ROOT, "reports", "room16", "runs");
const BATCH_RUNS_DIR = path.join(PROJECT_ROOT, ".runtime", "bcr-company-batches");
const HARDENING_LATEST_PATH = path.join(RUNTIME_ROOT, "hardening", "latest-cycle.json");
// Compatibility only: rebase stale persisted artifact IDs to the canonical project root.
const LEGACY_PROJECT_ROOTS = [
  "/Users/BjornRosinger/Documents/New project/company-dossier-lab",
  "/Users/BjornRosinger/Documents/New project/company-dossier-lab-pr11-premerge",
  "/Users/BjornRosinger/Documents/New project/company-dossier-lab-core-v2-final",
  "/Users/BjornRosinger/Documents/New project/company-dossier-lab-room16-publish-readiness"
];
const DEFAULT_BATCH_PYTHON = path.join(PROJECT_ROOT, ".venv", "bin", "python");
const DEFAULT_BUNDLE_PYTHON = path.join(
  os.homedir(),
  ".cache",
  "codex-runtimes",
  "codex-primary-runtime",
  "dependencies",
  "python",
  "bin",
  "python3"
);
const ROOM16_LLM_TIMEOUT_SECONDS = Number(process.env.ROOM16_LLM_TIMEOUT_SECONDS || 300);
const ROOM16_TICKER_TIMEOUT_SECONDS = Number(process.env.ROOM16_TICKER_TIMEOUT_SECONDS || 1800);
const ROOM16_STALL_TIMEOUT_SECONDS = Number(process.env.ROOM16_STALL_TIMEOUT_SECONDS || 600);
const ROOM16_TICKER_RETRIES = Number(process.env.ROOM16_TICKER_RETRIES || 2);
const ROOM16_RETRY_DELAY_SECONDS = Number(process.env.ROOM16_RETRY_DELAY_SECONDS || 30);

const args = new Set(process.argv.slice(2));
const devMode = args.has("--dev") || (!args.has("--static") && process.env.NODE_ENV !== "production");
const portArgIndex = process.argv.indexOf("--port");
const hostArgIndex = process.argv.indexOf("--host");
const PORT = Number(process.env.PORT || (portArgIndex >= 0 ? process.argv[portArgIndex + 1] : "") || 4316);
const HOST = process.env.HOST || (hostArgIndex >= 0 ? process.argv[hostArgIndex + 1] : "") || "127.0.0.1";
enforceNetworkBindingPolicy({ host: HOST, env: process.env });
const requireMutatingApiAccess = createMutatingApiGuard({ host: HOST, env: process.env });

const jobs = new Map();
const activeChildren = new Map();
const activeRecoveryJobIds = new Set();
let activeJobId = null;
let bundleDependencyPreflightCache = null;
let httpServer = null;

const REPORT_WORKFLOW_TEMPLATE = [
  { id: "intake", label: "Auftrag angelegt" },
  { id: "queue", label: "Warteschlange" },
  { id: "research", label: "TradingAgents Research" },
  { id: "source_ledger", label: "Source-Ledger" },
  { id: "manifest", label: "Research-Manifest" },
  { id: "dossier", label: "Markdown-Dossier" },
  { id: "quality_gate", label: "Quality Gate" },
  { id: "shelf", label: "Report-Shelf" },
  { id: "publish_gate", label: "Review-/Publish-Gate" }
];

class JobCanceledError extends Error {
  constructor(message = "Job wurde vom Operator gestoppt.") {
    super(message);
    this.name = "JobCanceledError";
  }
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function nowIso() {
  return new Date().toISOString();
}

function pad(value) {
  return String(value).padStart(2, "0");
}

function localDateStamp(date = new Date()) {
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}`;
}

function localTimeStamp(date = new Date()) {
  return `${localDateStamp(date)}-${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}`;
}

function localDateString(date = new Date()) {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function previousBusinessDateString(reference = new Date()) {
  const date = new Date(reference);
  date.setDate(date.getDate() - 1);
  while (date.getDay() === 0 || date.getDay() === 6) {
    date.setDate(date.getDate() - 1);
  }
  return localDateString(date);
}

function readJson(filePath, fallback = null) {
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch {
    return fallback;
  }
}

function writeJson(filePath, payload) {
  ensureDir(path.dirname(filePath));
  fs.writeFileSync(filePath, JSON.stringify(payload, null, 2), "utf8");
}

function rebaseLegacyProjectPath(value) {
  const raw = String(value || "");
  for (const legacyRoot of LEGACY_PROJECT_ROOTS) {
    if (raw === legacyRoot || raw.startsWith(`${legacyRoot}/`)) {
      return path.join(PROJECT_ROOT, path.relative(legacyRoot, raw));
    }
  }
  return raw;
}

function encodeId(value) {
  return Buffer.from(rebaseLegacyProjectPath(value), "utf8").toString("base64url");
}

function decodeId(value) {
  return Buffer.from(value, "base64url").toString("utf8");
}

function isInside(childPath, parentPath) {
  const relative = path.relative(path.resolve(parentPath), path.resolve(childPath));
  return relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative));
}

function resolveAllowedFile(id, allowedRoots) {
  const decoded = path.resolve(rebaseLegacyProjectPath(decodeId(id)));
  if (!fs.existsSync(decoded)) {
    return null;
  }
  let realDecoded = null;
  try {
    realDecoded = fs.realpathSync(decoded);
  } catch {
    return null;
  }
  const allowed = allowedRoots.some((root) => {
    if (!fs.existsSync(root)) {
      return false;
    }
    const realRoot = fs.realpathSync(root);
    return isInside(realDecoded, realRoot);
  });
  return allowed ? decoded : null;
}

function normalizeTicker(input) {
  return String(input || "")
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9._-]/g, "");
}

const TICKER_ALIAS_PAIRS = readJson(path.join(APP_ROOT, "src", "ticker-aliases.json"), []);
const TICKER_ALIASES = new Map(
  TICKER_ALIAS_PAIRS.map(([name, ticker]) => [normalizeTicker(name), ticker])
);
const MODEL_PROFILE_CONFIG = readJson(path.join(APP_ROOT, "src", "model-profiles.json"), []);
const PAID_PROVIDER_CONFIRMATION_REQUIRED = new Set([
  "anthropic",
  "azure",
  "deepseek",
  "google",
  "openai",
  "openrouter",
  "qwen",
  "xai"
]);

function normalizeReportTicker(input) {
  const normalized = normalizeTicker(input);
  return TICKER_ALIASES.get(normalized) || normalized;
}

function tickerAliasStats() {
  return {
    aliasEntries: TICKER_ALIAS_PAIRS.length,
    uniqueTickers: new Set(TICKER_ALIAS_PAIRS.map(([, ticker]) => ticker)).size
  };
}

function publicModelProfile(profile) {
  return {
    id: profile.id,
    label: profile.label,
    provider: normalizeProvider(profile.provider),
    quickModel: profile.quickModel,
    deepModel: profile.deepModel,
    default: Boolean(profile.default),
    requiresPaidConfirmation: Boolean(profile.requiresPaidConfirmation),
    track: profile.track || "",
    badge: profile.badge || "",
    summary: profile.summary || "",
    tags: Array.isArray(profile.tags) ? profile.tags : []
  };
}

function modelProfiles() {
  return MODEL_PROFILE_CONFIG.filter((profile) => profile?.id && profile?.provider).map(publicModelProfile);
}

function defaultModelProfile() {
  const profiles = modelProfiles();
  return profiles.find((profile) => profile.default) || profiles[0] || {
    id: "deepseek-v4-ollama",
    label: "DS V4 Cloud",
    provider: "ollama",
    quickModel: "deepseek-v4-pro:cloud",
    deepModel: "deepseek-v4-pro:cloud",
    default: true,
    requiresPaidConfirmation: false,
    track: "Ollama Cloud Default",
    badge: "Cloud",
    summary: "",
    tags: []
  };
}

function resolveModelProfile(payload = {}) {
  const profiles = modelProfiles();
  const requestedId = String(payload?.modelProfileId || "").trim();
  if (requestedId) {
    const profile = profiles.find((item) => item.id === requestedId);
    if (!profile) {
      const error = new Error(`Modellprofil "${requestedId}" ist nicht bekannt.`);
      error.statusCode = 400;
      throw error;
    }
    return profile;
  }
  if (payload?.provider || payload?.quickModel || payload?.deepModel) {
    const provider = normalizeProvider(payload?.provider || defaultModelProfile().provider);
    const quickModel = payload?.quickModel || defaultModelProfile().quickModel;
    const deepModel = payload?.deepModel || defaultModelProfile().deepModel;
    return {
      id: "custom",
      label: `${provider}/${deepModel}`,
      provider,
      quickModel,
      deepModel,
      default: false,
      requiresPaidConfirmation: PAID_PROVIDER_CONFIRMATION_REQUIRED.has(provider),
      track: "Custom",
      badge: "API",
      summary: "",
      tags: []
    };
  }
  return defaultModelProfile();
}

function normalizeProvider(input) {
  return String(input || "ollama").trim().toLowerCase();
}

function assertPaidProviderAllowed(provider, payload) {
  if (!PAID_PROVIDER_CONFIRMATION_REQUIRED.has(provider)) {
    return;
  }
  if (payload?.confirmPaidProvider === true) {
    return;
  }
  const error = new Error(
    `Kosten-Schutz aktiv: Provider "${provider}" wird nicht automatisch gestartet. Paid/API-Provider brauchen eine explizite confirmPaidProvider-Freigabe.`
  );
  error.statusCode = 402;
  throw error;
}

function shouldTrustAsTicker(input, normalized) {
  const raw = String(input || "").trim();
  return Boolean(normalized && raw === normalized && /^[A-Z0-9._-]{1,16}$/.test(raw));
}

function preferredQuoteScore(quote) {
  const exchange = String(quote.exchange || "").toUpperCase();
  const exchangeBonus = ["NMS", "NYQ", "ASE", "NCM", "NGM", "NAS"].includes(exchange) ? 100_000 : 0;
  return exchangeBonus + Number(quote.score || 0);
}

async function lookupTickerOnline(input) {
  const query = String(input || "").trim();
  if (!query) {
    return null;
  }
  const url = `https://query1.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(query)}&quotesCount=8&newsCount=0`;
  const response = await fetch(url, {
    headers: {
      "Accept": "application/json",
      "User-Agent": "Mozilla/5.0 Room16SymbolResolver/1.0"
    },
    signal: AbortSignal.timeout(5000)
  });
  if (!response.ok) {
    throw new Error(`Symbolsuche nicht erreichbar (${response.status}).`);
  }
  const payload = await response.json();
  const quotes = Array.isArray(payload?.quotes) ? payload.quotes : [];
  const candidates = quotes
    .filter((quote) => quote?.symbol && String(quote.quoteType || "").toUpperCase() === "EQUITY")
    .map((quote) => ({
      symbol: normalizeTicker(quote.symbol),
      shortName: quote.shortname || quote.longname || "",
      longName: quote.longname || quote.shortname || "",
      exchange: quote.exchDisp || quote.exchange || "",
      quoteType: quote.quoteType || "",
      score: Number(quote.score || 0),
      source: "Yahoo Finance Search"
    }))
    .filter((quote) => quote.symbol && quote.symbol.length <= 16);
  if (!candidates.length) {
    return null;
  }
  candidates.sort((a, b) => preferredQuoteScore(b) - preferredQuoteScore(a));
  const best = candidates[0];
  return {
    ticker: best.symbol,
    source: "online",
    provider: "Yahoo Finance Search",
    input: query,
    companyName: best.longName || best.shortName || null,
    exchange: best.exchange || null,
    candidates: candidates.slice(0, 4)
  };
}

async function resolveReportTicker(input) {
  const raw = String(input || "").trim();
  const normalized = normalizeTicker(raw);
  const aliasTicker = TICKER_ALIASES.get(normalized);
  if (aliasTicker) {
    return {
      ticker: aliasTicker,
      source: "alias",
      input: raw,
      candidates: []
    };
  }
  if (!normalized || normalized.length > 16) {
    const error = new Error("Ticker fehlt oder ist ungültig.");
    error.statusCode = 400;
    throw error;
  }
  if (shouldTrustAsTicker(raw, normalized)) {
    return {
      ticker: normalized,
      source: "direct",
      input: raw,
      candidates: []
    };
  }
  try {
    const online = await lookupTickerOnline(raw);
    if (online?.ticker) {
      return online;
    }
  } catch (error) {
    const failed = new Error(`Symbolsuche fehlgeschlagen: ${error.message || String(error)}`);
    failed.statusCode = 502;
    throw failed;
  }
  const error = new Error(`Keine eindeutige Aktie für "${raw}" gefunden. Bitte Ticker eingeben oder Alias ergänzen.`);
  error.statusCode = 422;
  throw error;
}

function walkFiles(dir, predicate, out = []) {
  if (!fs.existsSync(dir)) {
    return out;
  }
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      walkFiles(fullPath, predicate, out);
    } else if (predicate(fullPath)) {
      out.push(fullPath);
    }
  }
  return out;
}

function fileStatPayload(filePath) {
  const stat = fs.statSync(filePath);
  return {
    sizeBytes: stat.size,
    createdAt: stat.birthtime.toISOString(),
    modifiedAt: stat.mtime.toISOString()
  };
}

function dateValue(value) {
  const parsed = Date.parse(value || "");
  return Number.isFinite(parsed) ? parsed : 0;
}

function companyLatestTimestamp(company) {
  const reportTimes = Array.isArray(company.reports)
    ? company.reports.map((report) => dateValue(report.modifiedAt))
    : [];
  return Math.max(
    dateValue(company.latestReport?.modifiedAt),
    dateValue(company.latestQuality?.createdAt),
    ...reportTimes,
    0
  );
}

function readTail(filePath, maxLines = 80) {
  if (!filePath || !fs.existsSync(filePath)) {
    return "";
  }
  const text = fs.readFileSync(filePath, "utf8");
  const lines = text.split(/\r?\n/);
  return lines.slice(Math.max(0, lines.length - maxLines)).join("\n").trim();
}

function processExists(pid) {
  if (!pid) {
    return false;
  }
  try {
    process.kill(Number(pid), 0);
    return true;
  } catch {
    return false;
  }
}

function closeFd(fd) {
  if (typeof fd !== "number") {
    return;
  }
  try {
    fs.closeSync(fd);
  } catch {
    // The child may already have closed the descriptor.
  }
}

function stripPdfName(fileName) {
  return fileName.replace(/\.(pdf|md)$/i, "");
}

function modelLabelFromName(value) {
  const source = String(value || "").toLowerCase();
  if (source.includes("deepseek-v4") || source.includes("deepseek v4")) {
    return "DeepSeek V4";
  }
  if (source.includes("kimi-k2.6") || source.includes("kimi k2.6")) {
    return "Kimi K2.6";
  }
  if (source.includes("glm-5.1") || source.includes("glm 5.1")) {
    return "GLM-5.1";
  }
  if (source.includes("gpt-5.5") || source.includes("gpt 5.5")) {
    return "GPT-5.5";
  }
  if (source.includes("gpt-5.4") || source.includes("gpt 5.4")) {
    return "GPT-5.4";
  }
  return null;
}

function dateFromReportName(fileName) {
  return String(fileName || "").match(/^(\d{4}-\d{2}-\d{2})/)?.[1] || null;
}

function qualityForShelfReport(reportFileName, qualityRuns) {
  const reportModelLabel = modelLabelFromName(reportFileName);
  const reportDate = dateFromReportName(reportFileName);
  return qualityRuns.find((qualityRun) => {
    const qualityModelLabel = modelLabelFromName(qualityRun?.deepModel);
    const qualityPdfPath = resolveProjectArtifactPath(qualityRun?.artifacts?.complete_pdf);
    const qualityPdfName = path.basename(String(qualityPdfPath || ""));
    const qualityDate = dateFromReportName(qualityPdfName);
    const modelMatches = !reportModelLabel || !qualityModelLabel || reportModelLabel === qualityModelLabel;
    const dateMatches = !reportDate || !qualityDate || reportDate === qualityDate;
    return modelMatches && dateMatches;
  }) || null;
}

function reportPayloadForPath(reportPath) {
  if (!reportPath || !fs.existsSync(reportPath)) {
    return null;
  }
  const id = encodeId(reportPath);
  const isPdf = reportPath.toLowerCase().endsWith(".pdf");
  const isMarkdown = reportPath.toLowerCase().endsWith(".md");
  return {
    id,
    title: stripPdfName(path.basename(reportPath)),
    fileName: path.basename(reportPath),
    url: isPdf ? `/api/reports/${id}` : null,
    markdownId: isMarkdown ? id : null,
    markdownUrl: isMarkdown ? `/api/artifacts/${id}/markdown` : null,
    hasFinalDocument: isPdf,
    localPath: reportPath,
    ...fileStatPayload(reportPath)
  };
}

function preferredMarkdownArtifactPath(qualityRun) {
  const publicFinalReady =
    qualityRun?.generationStage === "public_final" &&
    qualityRun?.publicReady === true &&
    qualityRun?.publishable === true &&
    qualityRun?.finalDocumentsRendered === true;
  const candidates = [
    publicFinalReady ? qualityRun?.artifacts?.publish_report : null,
    qualityRun?.artifacts?.internal_best_report,
    qualityRun?.artifacts?.complete_md,
    qualityRun?.artifacts?.raw_report,
    qualityRun?.artifacts?.raw_room16_report
  ];
  for (const candidate of candidates) {
    const resolved = resolveProjectArtifactPath(candidate);
    if (resolved && fs.existsSync(resolved) && resolved.toLowerCase().endsWith(".md")) {
      return resolved;
    }
  }
  return null;
}

function reportPayloadForQualityRun(qualityRun) {
  const pdfPath = resolveProjectArtifactPath(qualityRun?.artifacts?.complete_pdf);
  if (pdfPath && fs.existsSync(pdfPath)) {
    return null;
  }
  const markdownPath = preferredMarkdownArtifactPath(qualityRun);
  if (!markdownPath) {
    return null;
  }
  const payload = reportPayloadForPath(markdownPath);
  if (!payload) {
    return null;
  }
  const publicMarkdownUrl =
    qualityRun?.qualityDecision?.public_ready === true && qualityRun?.qualityDecision?.publishable === true
      ? payload.markdownUrl
      : qualityRun?.qualityDecision?.quality_verdict === "fail"
        ? null
        : payload.markdownUrl;
  return {
    ...payload,
    title: stripPdfName(path.basename(markdownPath)) || `${qualityRun.ticker} Markdown QA Dossier`,
    markdownUrl: publicMarkdownUrl,
    markdownId: publicMarkdownUrl ? payload.markdownId : null,
    internalBestReportUrl: qualityRun?.artifactLinks?.internal_best_report || null,
    rawReportUrl: qualityRun?.artifactLinks?.raw_report || null,
    publishReportUrl: qualityRun?.artifactLinks?.publish_report || null,
    qualityReportUrl: qualityRun?.artifactLinks?.quality_report || null,
    evidenceReportUrl: qualityRun?.artifactLinks?.evidence_report || null,
    qualityId: qualityRun?.qualityId || null,
    quality: qualityRun || null
  };
}

function resolveProjectArtifactPath(filePath) {
  if (!filePath) {
    return null;
  }
  if (typeof filePath === "object") {
    if (filePath.rendered === false) {
      return null;
    }
    filePath = filePath.path || filePath.file || filePath.href || null;
    if (!filePath) {
      return null;
    }
  }
  const rebased = rebaseLegacyProjectPath(filePath);
  if (!path.isAbsolute(rebased)) {
    return path.resolve(PROJECT_ROOT, rebased);
  }
  const runsMarker = `${path.sep}reports${path.sep}room16${path.sep}runs${path.sep}`;
  const markerIndex = rebased.indexOf(runsMarker);
  if (markerIndex >= 0) {
    const rebasedRunPath = path.join(PROJECT_ROOT, "reports", "room16", "runs", rebased.slice(markerIndex + runsMarker.length));
    if (fs.existsSync(rebasedRunPath)) {
      return rebasedRunPath;
    }
  }
  return rebased;
}

function inferCompanyFolder(folderName) {
  const match = folderName.match(/^(.*)\s+\(([^()]+)\)$/);
  if (!match) {
    return { companyName: folderName, ticker: normalizeTicker(folderName) };
  }
  return { companyName: match[1].trim(), ticker: normalizeTicker(match[2]) };
}

function parseMarkdownMeta(markdownPath) {
  const resolvedMarkdownPath = resolveProjectArtifactPath(markdownPath);
  if (!resolvedMarkdownPath || !fs.existsSync(resolvedMarkdownPath)) {
    return {};
  }
  const text = fs.readFileSync(resolvedMarkdownPath, "utf8").slice(0, 60000);
  const matchLine = (pattern) => text.match(pattern)?.[1]?.trim() || null;
  const firstTableRow = text.match(/\|\s*`?([A-Z0-9._-]+)`?\s*\|\s*ok\s*\|\s*[^|]*\|\s*([^|]+)\|\s*([^|]+)\|/i);
  return {
    generatedAtLabel: matchLine(/^Erstellt:\s*(.+)$/m),
    tradingAgentsDate: matchLine(/^TradingAgents-Datum:\s*(.+)$/m),
    provider: matchLine(/^- Provider:\s*`?([^`\n]+)`?/m),
    quickModel: matchLine(/^- Quick-Modell:\s*`?([^`\n]+)`?/m),
    deepModel: matchLine(/^- Deep-Modell:\s*`?([^`\n]+)`?/m),
    analysts: matchLine(/^- Analysten:\s*`?([^`\n]+)`?/m),
    rating: matchLine(/^\*\*Rating:\*\*\s*(.+)$/m) || firstTableRow?.[2]?.trim() || null,
    traderSignal: matchLine(/^\*\*Trader-Signal:\*\*\s*(.+)$/m) || firstTableRow?.[3]?.trim() || null,
    latestClose: matchLine(/Schlusskurs[^\n:]*:\s*\*\*?([0-9][0-9.,]*\s*(?:\$|€|USD|EUR)?)/i),
    atr: matchLine(/\bATR\b[^\n|]*\|\s*\*\*?([0-9][0-9.,]*)/i),
    rsi: matchLine(/\bRSI\b[^\n|]*\|\s*\*\*?([0-9][0-9.,]*)/i)
  };
}

function inferTickerFromQuality(filePath, payload) {
  const checks = Array.isArray(payload?.checks) ? payload.checks : [];
  const manifestTickerCheck = checks.find((check) => check.name === "manifest_has_tickers");
  const firstTicker = Array.isArray(manifestTickerCheck?.details) ? manifestTickerCheck.details[0] : null;
  if (firstTicker) {
    return normalizeTicker(firstTicker);
  }
  const parts = filePath.split(path.sep);
  const qualityIndex = parts.lastIndexOf("quality");
  if (qualityIndex > 0) {
    return normalizeTicker(parts[qualityIndex - 1]);
  }
  return null;
}

function normalizeQualityBool(value) {
  if (typeof value === "boolean") return value;
  if (value == null) return null;
  if (typeof value === "number") return Boolean(value);
  const normalized = String(value).trim().toLowerCase();
  if (["true", "1", "yes", "y"].includes(normalized)) return true;
  if (["false", "0", "no", "n", "null", "none"].includes(normalized)) return false;
  return null;
}

function normalizeQualityText(value) {
  if (value == null) return null;
  const text = String(value).trim().replace(/^`|`$/g, "").trim();
  return text && !["null", "none", "n/a"].includes(text.toLowerCase()) ? text : null;
}

function failedChecksFromQuality(quality) {
  const checks = Array.isArray(quality?.checks) ? quality.checks : [];
  return checks
    .filter((check) => check?.status === "fail" && check?.name)
    .map((check) => String(check.name));
}

function isQualityFailed(quality) {
  const metrics = quality?.metrics || {};
  return [quality?.quality_verdict, quality?.verdict, metrics.quality_verdict, metrics.research_integrity_verdict]
    .some((value) => String(value || "").toLowerCase() === "fail") ||
    [quality?.review_status, metrics.review_status]
      .some((value) => ["failed", "qa_failed", "blocked"].includes(String(value || "").toLowerCase()));
}

function deriveQualityDecisionForQuality(quality, { dashboardStatus = {}, artifactConsistency = {}, promotionStatus = {} } = {}) {
  const metrics = quality?.metrics || {};
  const failedChecks = failedChecksFromQuality(quality);
  if (isQualityFailed(quality)) {
    return {
      schema_version: 1,
      decision_type: "room16_quality_decision",
      quality_verdict: "fail",
      review_status: "failed",
      generation_stage: quality?.generation_stage || metrics.generation_stage || dashboardStatus.generation_stage || null,
      render_mode: quality?.render_mode || metrics.render_mode || dashboardStatus.render_mode || null,
      publishable: false,
      public_ready: false,
      visibility: "hidden",
      score_scope: quality?.score_scope || metrics.score_scope || dashboardStatus.score_scope || null,
      publish_gate_verdict: quality?.publish_gate_verdict || metrics.publish_gate_verdict || dashboardStatus.publish_gate_verdict || "not_run",
      promotion_gate_verdict: quality?.promotion_gate_verdict || metrics.promotion_gate_verdict || dashboardStatus.promotion_gate_verdict || "not_run",
      internal_rating: normalizeQualityText(metrics.internal_rating || quality?.internal_rating),
      public_rating: null,
      failed_checks: failedChecks,
      blockers: ["quality_verdict_failed"],
      warnings: artifactConsistency?.artifact_consistency_status === "clean" ? ["artifact_consistency_pre_final_status_ignored"] : [],
      source_observations: {
        dashboard_review_status: dashboardStatus.review_status || null,
        artifact_consistency_status: artifactConsistency?.artifact_consistency_status || null,
        promotion_status: promotionStatus?.promotion_status || promotionStatus?.status || null
      }
    };
  }
  const promotionPublicReady = normalizeQualityBool(promotionStatus?.public_ready) === true;
  const qualityPublicReady = normalizeQualityBool(quality?.public_ready ?? metrics.public_ready);
  const publicReady = promotionPublicReady && qualityPublicReady !== false;
  const internalRating = normalizeQualityText(metrics.internal_rating || quality?.internal_rating);
  return {
    schema_version: 1,
    decision_type: "room16_quality_decision",
    quality_verdict: "pass",
    review_status: publicReady ? "public_ready" : normalizeQualityText(quality?.review_status || metrics.review_status || "qa_pass"),
    generation_stage: quality?.generation_stage || metrics.generation_stage || dashboardStatus.generation_stage || null,
    render_mode: quality?.render_mode || metrics.render_mode || dashboardStatus.render_mode || null,
    publishable: publicReady,
    public_ready: publicReady,
    visibility: publicReady ? "public" : normalizeQualityText(quality?.visibility || metrics.visibility || "internal_only"),
    score_scope: quality?.score_scope || metrics.score_scope || dashboardStatus.score_scope || null,
    publish_gate_verdict: quality?.publish_gate_verdict || metrics.publish_gate_verdict || dashboardStatus.publish_gate_verdict || null,
    promotion_gate_verdict: quality?.promotion_gate_verdict || metrics.promotion_gate_verdict || dashboardStatus.promotion_gate_verdict || null,
    internal_rating: internalRating,
    public_rating: publicReady ? internalRating : null,
    failed_checks: failedChecks,
    blockers: [],
    warnings: []
  };
}

function scanQualityReports() {
  const files = walkFiles(REPORT_RUNS_DIR, (filePath) => filePath.endsWith("quality-report.json"));
  const byTicker = new Map();
  for (const filePath of files) {
    const quality = readJson(filePath);
    const ticker = inferTickerFromQuality(filePath, quality);
    if (!ticker) {
      continue;
    }
    const artifacts = quality?.artifacts || {};
    const meta = parseMarkdownMeta(artifacts.complete_md);
    const rawReportPath = resolveProjectArtifactPath(artifacts.raw_report || artifacts.raw_room16_report);
    const internalBestReportPath = resolveProjectArtifactPath(artifacts.internal_best_report);
    const publishReportPath = resolveProjectArtifactPath(artifacts.publish_report);
    const qualityReportPath = resolveProjectArtifactPath(artifacts.quality_report);
    const evidenceReportPath = resolveProjectArtifactPath(artifacts.evidence_report);
    const promotionStatusPath = resolveProjectArtifactPath(artifacts.promotion_status);
    const artifactConsistencyPath = resolveProjectArtifactPath(artifacts.artifact_consistency_report);
    const promotionStatus = promotionStatusPath && fs.existsSync(promotionStatusPath) ? readJson(promotionStatusPath, {}) : {};
    const artifactConsistency = artifactConsistencyPath && fs.existsSync(artifactConsistencyPath) ? readJson(artifactConsistencyPath, {}) : {};
    const dashboardStatusPath = resolveProjectArtifactPath(artifacts.dashboard_status);
    const dashboardStatus = dashboardStatusPath && fs.existsSync(dashboardStatusPath) ? readJson(dashboardStatusPath, {}) : {};
    const qualityDecision = deriveQualityDecisionForQuality(quality, {
      dashboardStatus,
      artifactConsistency,
      promotionStatus
    });
    let generationStage = quality?.generation_stage || quality?.metrics?.generation_stage || null;
    const legacyManualReview = quality?.metrics?.status === "manual_review" || quality?.metrics?.review_status === "manual_review";
    if (!generationStage && legacyManualReview && internalBestReportPath && fs.existsSync(internalBestReportPath)) {
      generationStage = "internal_best";
    }
    let renderMode = quality?.render_mode || quality?.metrics?.render_mode || null;
    if (!renderMode && generationStage === "internal_best") {
      renderMode = "internal_pdf";
    }
    const finalDocumentsRendered = Boolean(quality?.metrics?.final_documents_rendered);
    const markdownFirstQa = generationStage === "draft_markdown_qa" || renderMode === "markdown_first_qa";
    const internalBest = generationStage === "internal_best";
    const publicFinal = generationStage === "public_final";
    let publishable = qualityDecision.publishable;
    let publicReady = qualityDecision.public_ready;
    let publicRating = qualityDecision.public_rating;
    if (markdownFirstQa || internalBest || (publicFinal && !finalDocumentsRendered) || generationStage !== "public_final") {
      publishable = false;
      publicReady = false;
      publicRating = null;
    }
    if (publicReady !== true) {
      publishable = false;
      publicRating = null;
    }
    const okCheck = Array.isArray(quality?.checks)
      ? quality.checks.find((check) => check.name === "all_tickers_ok")
      : null;
    const okDetails = Array.isArray(okCheck?.details) ? okCheck.details.find((item) => normalizeTicker(item?.ticker) === ticker) : null;
    const stat = fileStatPayload(filePath);
    const item = {
      ticker,
      createdAt: quality?.created_at || stat.modifiedAt,
      verdict: quality?.verdict || "unknown",
      runDir: quality?.run_dir || null,
      qualityPath: filePath,
      qualityId: encodeId(filePath),
      artifacts,
      artifactLinks: {
        raw_report: rawReportPath && fs.existsSync(rawReportPath) ? `/api/artifacts/${encodeId(rawReportPath)}/markdown` : null,
        internal_best_report: internalBestReportPath && fs.existsSync(internalBestReportPath) ? `/api/artifacts/${encodeId(internalBestReportPath)}/markdown` : null,
        publish_report: publishable === true && publicFinal && finalDocumentsRendered && publishReportPath && fs.existsSync(publishReportPath) ? `/api/artifacts/${encodeId(publishReportPath)}/markdown` : null,
        quality_report: qualityReportPath && fs.existsSync(qualityReportPath) ? `/api/artifacts/${encodeId(qualityReportPath)}/markdown` : null,
        evidence_report: evidenceReportPath && fs.existsSync(evidenceReportPath) ? `/api/artifacts/${encodeId(evidenceReportPath)}/markdown` : null
      },
      metrics: quality?.metrics || {},
      generationStage,
      renderMode,
      finalDocumentsRendered,
      publicReady,
      lifecycleVisibility: qualityDecision.visibility,
      scoreScope: qualityDecision.score_scope || (generationStage === "internal_best" ? "internal_best" : null),
      qualityVerdict: qualityDecision.quality_verdict,
      qualityDecision,
      publishGateVerdict: qualityDecision.publish_gate_verdict,
      promotionGateVerdict: qualityDecision.promotion_gate_verdict,
      promotionStatus,
      artifactConsistency,
      status: quality?.metrics?.status || null,
      publishable,
      internalRating: qualityDecision.internal_rating,
      externalDisplayRating: quality?.metrics?.external_display_rating || null,
      publicRating,
      reviewStatus: qualityDecision.review_status,
      qualityScore: quality?.metrics?.quality_score ?? null,
      publishQualityScore: quality?.metrics?.publish_quality_score ?? null,
      internalResearchQualityScore: quality?.metrics?.internal_research_quality_score ?? null,
      dataConfidenceScore: quality?.metrics?.data_confidence_score ?? null,
      totalScoreLegacy: quality?.metrics?.total_score_legacy ?? quality?.metrics?.quality_score ?? null,
      companyArchetype: quality?.metrics?.company_archetype || null,
      archetypeConfidence: quality?.metrics?.archetype_confidence ?? null,
      archetypeTriggeredRules: Array.isArray(quality?.metrics?.archetype_triggered_rules) ? quality.metrics.archetype_triggered_rules : [],
      riskProfiles: Array.isArray(quality?.metrics?.risk_profiles) ? quality.metrics.risk_profiles : [],
      manualReviewReasons: Array.isArray(quality?.metrics?.manual_review_reasons) ? quality.metrics.manual_review_reasons : [],
      rating: meta.rating || okDetails?.decision || null,
      traderSignal: meta.traderSignal || null,
      provider: meta.provider || null,
      quickModel: meta.quickModel || null,
      deepModel: meta.deepModel || null,
      analysts: meta.analysts || null,
      tradingAgentsDate: meta.tradingAgentsDate || null,
      generatedAtLabel: meta.generatedAtLabel || null,
      latestClose: meta.latestClose || null,
      rsi: meta.rsi || null,
      atr: meta.atr || null,
      elapsedSeconds: okDetails?.elapsed_seconds ?? null
    };
    const list = byTicker.get(ticker) || [];
    list.push(item);
    byTicker.set(ticker, list);
  }
  for (const list of byTicker.values()) {
    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  return byTicker;
}

function scanShelf() {
  const qualityByTicker = scanQualityReports();
  const companies = new Map();
  if (fs.existsSync(SHELF_DIR)) {
    for (const entry of fs.readdirSync(SHELF_DIR, { withFileTypes: true })) {
      if (!entry.isDirectory() || entry.name.startsWith("_")) {
        continue;
      }
      const folderPath = path.join(SHELF_DIR, entry.name);
      const folderInfo = inferCompanyFolder(entry.name);
      const quality = qualityByTicker.get(folderInfo.ticker) || [];
      const pdfFiles = fs
        .readdirSync(folderPath, { withFileTypes: true })
        .filter((file) => file.isFile() && file.name.toLowerCase().endsWith(".pdf"))
        .map((file) => {
          const reportPath = path.join(folderPath, file.name);
          const id = encodeId(reportPath);
          const matchedQuality = qualityForShelfReport(file.name, quality);
          const publishReportPath = resolveProjectArtifactPath(matchedQuality?.artifacts?.publish_report);
          const hasBestLayer = Boolean(matchedQuality?.artifacts?.internal_best_report || matchedQuality?.artifacts?.raw_report || matchedQuality?.artifacts?.raw_room16_report);
          const publicFinalReady =
            matchedQuality?.generationStage === "public_final" &&
            matchedQuality?.publicReady === true &&
            matchedQuality?.publishable === true &&
            matchedQuality?.finalDocumentsRendered === true;
          const qualityDecisionFailed = matchedQuality?.qualityDecision?.quality_verdict === "fail";
          const markdownPath = hasBestLayer
            ? (publicFinalReady ? publishReportPath : null)
            : qualityDecisionFailed
              ? null
              : resolveProjectArtifactPath(matchedQuality?.artifacts?.complete_md);
          return {
            id,
            title: stripPdfName(file.name),
            fileName: file.name,
            url: `/api/reports/${id}`,
            localPath: reportPath,
            markdownId: markdownPath && fs.existsSync(markdownPath) ? encodeId(markdownPath) : null,
            markdownUrl: markdownPath && fs.existsSync(markdownPath) ? `/api/artifacts/${encodeId(markdownPath)}/markdown` : null,
            internalBestReportUrl: matchedQuality?.artifactLinks?.internal_best_report || null,
            rawReportUrl: matchedQuality?.artifactLinks?.raw_report || null,
            publishReportUrl: matchedQuality?.artifactLinks?.publish_report || null,
            qualityReportUrl: matchedQuality?.artifactLinks?.quality_report || null,
            evidenceReportUrl: matchedQuality?.artifactLinks?.evidence_report || null,
            qualityId: matchedQuality?.qualityId || null,
            quality: matchedQuality || null,
            ...fileStatPayload(reportPath)
          };
        })
        .sort((a, b) => new Date(b.modifiedAt).getTime() - new Date(a.modifiedAt).getTime());
      const markdownReports = quality
        .map((qualityRun) => reportPayloadForQualityRun(qualityRun))
        .filter(Boolean);
      const reports = [...pdfFiles, ...markdownReports].sort(
        (a, b) => new Date(b.modifiedAt).getTime() - new Date(a.modifiedAt).getTime()
      );
      companies.set(folderInfo.ticker, {
        ticker: folderInfo.ticker,
        companyName: folderInfo.companyName,
        folderPath,
        reportCount: reports.length,
        latestReport: reports[0] || null,
        reports,
        qualityRuns: quality,
        latestQuality: quality[0] || null
      });
    }
  }
  for (const [ticker, qualityRuns] of qualityByTicker.entries()) {
    if (companies.has(ticker)) {
      continue;
    }
    const latestQuality = qualityRuns[0];
    const pdfPath = resolveProjectArtifactPath(latestQuality?.artifacts?.complete_pdf);
    const publishReportPath = resolveProjectArtifactPath(latestQuality?.artifacts?.publish_report);
    const latestManualReviewLocked =
      latestQuality?.publishable === false && Boolean(latestQuality?.artifactLinks?.internal_best_report);
    const latestMarkdownPath = latestManualReviewLocked ? null : resolveProjectArtifactPath(latestQuality?.artifacts?.complete_md);
    const reports = pdfPath && fs.existsSync(pdfPath)
      ? [
          {
            id: encodeId(pdfPath),
            title: stripPdfName(path.basename(pdfPath)),
            fileName: path.basename(pdfPath),
            url: `/api/reports/${encodeId(pdfPath)}`,
            localPath: pdfPath,
            markdownId: latestMarkdownPath && fs.existsSync(latestMarkdownPath) ? encodeId(latestMarkdownPath) : null,
            markdownUrl: latestMarkdownPath && fs.existsSync(latestMarkdownPath) ? `/api/artifacts/${encodeId(latestMarkdownPath)}/markdown` : null,
            internalBestReportUrl: latestQuality?.artifactLinks?.internal_best_report || null,
            rawReportUrl: latestQuality?.artifactLinks?.raw_report || null,
            publishReportUrl: latestQuality?.artifactLinks?.publish_report || null,
            qualityReportUrl: latestQuality?.artifactLinks?.quality_report || null,
            evidenceReportUrl: latestQuality?.artifactLinks?.evidence_report || null,
            qualityId: latestQuality?.qualityId || null,
            quality: latestQuality || null,
            ...fileStatPayload(pdfPath)
          }
        ]
      : qualityRuns
          .map((qualityRun) => reportPayloadForQualityRun(qualityRun))
          .filter(Boolean);
    companies.set(ticker, {
      ticker,
      companyName: ticker,
      folderPath: null,
      reportCount: reports.length,
      latestReport: reports[0] || null,
      reports,
      qualityRuns,
      latestQuality
    });
  }
  return [...companies.values()].sort((a, b) => {
    const byTime = companyLatestTimestamp(b) - companyLatestTimestamp(a);
    return byTime || a.ticker.localeCompare(b.ticker);
  });
}

function findCompany(ticker) {
  const normalized = normalizeTicker(ticker);
  return scanShelf().find((item) => item.ticker === normalized) || null;
}

function inferDefaultSourceStatus(report) {
  if (report?.quality?.verdict === "pass") {
    return "pipeline_verified";
  }
  if (report?.quality?.verdict === "fail") {
    return "qa_failed";
  }
  return "unmatched_pdf";
}

function normalizeEnum(value, allowed, fallback) {
  return allowed.includes(value) ? value : fallback;
}

function loadPublicLibraryState() {
  const state = readJson(PUBLIC_LIBRARY_STATE_PATH, { entries: {} });
  return state && typeof state === "object" && state.entries && typeof state.entries === "object"
    ? state
    : { entries: {} };
}

function savePublicLibraryState(state) {
  writeJson(PUBLIC_LIBRARY_STATE_PATH, {
    version: 1,
    updatedAt: nowIso(),
    entries: state.entries || {}
  });
}

function evaluatePublicLibraryGate(entry) {
  return evaluatePublicLibraryGateContract(entry);
}

function sumQualityMetric(entries, key) {
  return entries.reduce((sum, entry) => {
    const value = entry.qualityMetrics?.[key];
    return sum + (Number.isFinite(Number(value)) ? Number(value) : 0);
  }, 0);
}

function buildPublicLibrary({ includeDismissed = false, writeSnapshot = true } = {}) {
  const companies = scanShelf();
  const state = loadPublicLibraryState();
  const entries = [];

  for (const company of companies) {
    for (const report of company.reports || []) {
      const override = state.entries?.[report.id] || {};
      if (override.dismissedAt && !includeDismissed) {
        continue;
      }
      const sourceStatus = normalizeEnum(
        override.sourceStatus || inferDefaultSourceStatus(report),
        ["unmatched_pdf", "pipeline_verified", "human_verified", "qa_failed"],
        inferDefaultSourceStatus(report)
      );
      const reviewStatus = normalizeEnum(
        override.reviewStatus || "unreviewed",
        ["unreviewed", "reviewed", "rejected"],
        "unreviewed"
      );
      const visibility = normalizeEnum(
        override.visibility || "hidden",
        ["hidden", "member", "public"],
        "hidden"
      );
      const entry = {
        id: report.id,
        ticker: company.ticker,
        companyName: company.companyName,
        title: report.title,
        fileName: report.fileName,
        reportDate: dateFromReportName(report.fileName),
        modelLabel: modelLabelFromName(`${report.fileName} ${report.title} ${report.quality?.deepModel || ""}`) || report.quality?.deepModel || "Unknown",
        pdfUrl: report.url || null,
        markdownUrl: report.markdownUrl || null,
        localPath: report.localPath,
        sizeBytes: report.sizeBytes,
        modifiedAt: report.modifiedAt,
        qualityVerdict: report.quality?.qualityDecision?.quality_verdict || report.quality?.qualityVerdict || report.quality?.verdict || "missing",
        lifecycleQualityVerdict: report.quality?.qualityDecision?.quality_verdict || report.quality?.qualityVerdict || report.quality?.metrics?.quality_verdict || report.quality?.verdict || "missing",
        generationStage: report.quality?.generationStage || report.quality?.metrics?.generation_stage || null,
        renderMode: report.quality?.renderMode || report.quality?.metrics?.render_mode || null,
        finalDocumentsRendered: Boolean(report.quality?.finalDocumentsRendered || report.quality?.metrics?.final_documents_rendered),
        publicReady: Boolean(report.quality?.publicReady || report.quality?.metrics?.public_ready),
        lifecycleVisibility: report.quality?.lifecycleVisibility || report.quality?.metrics?.visibility || null,
        scoreScope: report.quality?.scoreScope || report.quality?.metrics?.score_scope || null,
        qualityDecision: report.quality?.qualityDecision || null,
        publishGateVerdict: report.quality?.publishGateVerdict || report.quality?.metrics?.publish_gate_verdict || null,
        promotionGateVerdict: report.quality?.promotionGateVerdict || report.quality?.metrics?.promotion_gate_verdict || null,
        promotionStatus: report.quality?.promotionStatus || {},
        artifactConsistency: report.quality?.artifactConsistency || {},
        qualityMetrics: report.quality?.metrics || {},
        qualityStatus: report.quality?.status || null,
        publishable: report.quality?.publishable ?? null,
        internalRating: report.quality?.internalRating || null,
        externalDisplayRating: report.quality?.externalDisplayRating || null,
        publicRating: report.quality?.publicRating || null,
        reviewStatusMetric: report.quality?.reviewStatus || null,
        qualityScore: report.quality?.qualityScore ?? null,
        publishQualityScore: report.quality?.publishQualityScore ?? null,
        internalResearchQualityScore: report.quality?.internalResearchQualityScore ?? null,
        dataConfidenceScore: report.quality?.dataConfidenceScore ?? null,
        totalScoreLegacy: report.quality?.totalScoreLegacy ?? null,
        companyArchetype: report.quality?.companyArchetype || null,
        archetypeConfidence: report.quality?.archetypeConfidence ?? null,
        archetypeTriggeredRules: report.quality?.archetypeTriggeredRules || [],
        riskProfiles: report.quality?.riskProfiles || [],
        manualReviewReasons: report.quality?.manualReviewReasons || [],
        internalBestReportUrl: report.internalBestReportUrl || report.quality?.artifactLinks?.internal_best_report || null,
        rawReportUrl: report.rawReportUrl || report.quality?.artifactLinks?.raw_report || null,
        publishReportUrl: report.publishReportUrl || report.quality?.artifactLinks?.publish_report || null,
        qualityReportUrl: report.qualityReportUrl || report.quality?.artifactLinks?.quality_report || null,
        evidenceReportUrl: report.evidenceReportUrl || report.quality?.artifactLinks?.evidence_report || null,
        qualityId: report.qualityId || null,
        sourceStatus,
        reviewStatus,
        visibility,
        nonAdvice: override.nonAdvice === false ? false : true,
        notes: String(override.notes || ""),
        reviewedAt: override.reviewedAt || null,
        reviewedBy: override.reviewedBy || null,
        dismissedAt: override.dismissedAt || null,
        dismissedBy: override.dismissedBy || null
      };
      if (entry.qualityVerdict === "fail") {
        entry.qualityDecision = {
          ...(entry.qualityDecision || {}),
          quality_verdict: "fail",
          review_status: "failed",
          publishable: false,
          public_ready: false,
          visibility: "hidden",
          public_rating: null
        };
        entry.markdownUrl = null;
        entry.publishReportUrl = null;
        entry.publishable = false;
        entry.publicReady = false;
        entry.publicRating = null;
        entry.visibility = "hidden";
      }
      entry.qualityGate = evaluatePublicLibraryGate(entry);
      entries.push(entry);
    }
  }

  entries.sort((a, b) => {
    const dateCompare = String(b.reportDate || "").localeCompare(String(a.reportDate || ""));
    return dateCompare || a.ticker.localeCompare(b.ticker) || a.fileName.localeCompare(b.fileName);
  });

  const summary = {
    totalReports: entries.length,
    companies: new Set(entries.map((entry) => entry.ticker)).size,
    publicReady: entries.filter((entry) => entry.qualityGate.status === "public_ready").length,
    memberReady: entries.filter((entry) => entry.qualityGate.memberReady).length,
    manualReview: entries.filter((entry) => entry.qualityGate.status === "manual_review").length,
    needsHumanReview: entries.filter((entry) => entry.qualityGate.status === "needs_human_review").length,
    rejected: entries.filter((entry) => entry.qualityGate.status === "rejected").length,
    internalOnly: entries.filter((entry) => entry.qualityGate.status === "internal_only").length,
    hiddenByGate: entries.filter((entry) => entry.qualityGate.effectiveVisibility === "hidden").length,
    effectivePublic: entries.filter((entry) => entry.qualityGate.effectiveVisibility === "public").length,
    effectiveMember: entries.filter((entry) => entry.qualityGate.effectiveVisibility === "member").length,
    speculative_deep_tech_profile_count: sumQualityMetric(entries, "speculative_deep_tech_profile_count"),
    accounting_gain_not_operating_turnaround_count: sumQualityMetric(entries, "accounting_gain_not_operating_turnaround_count"),
    vendor_only_hard_metrics_count: sumQualityMetric(entries, "vendor_only_hard_metrics_count"),
    order_materiality_missing_count: sumQualityMetric(entries, "order_materiality_missing_count"),
    technical_overweight_in_thesis_count: sumQualityMetric(entries, "technical_overweight_in_thesis_count")
  };

  const library = {
    version: "public-report-library-v1",
    generatedAt: nowIso(),
    shelfDir: SHELF_DIR,
    statePath: PUBLIC_LIBRARY_STATE_PATH,
    summary,
    entries
  };
  if (writeSnapshot) {
    writePublicLibrarySnapshot(library);
  }
  return library;
}

function writePublicLibrarySnapshot(library) {
  ensureDir(PUBLIC_LIBRARY_DIR);
  const lines = [
    "# Room 16 Public Report Library Status",
    "",
    `Generated: ${library.generatedAt}`,
    `Shelf: ${library.shelfDir}`,
    "",
    "## Summary",
    "",
    `- Total Reports: ${library.summary.totalReports}`,
    `- Companies: ${library.summary.companies}`,
    `- Public Ready: ${library.summary.publicReady}`,
    `- Member Ready: ${library.summary.memberReady}`,
    `- Manual Review: ${library.summary.manualReview}`,
    `- Needs Human Review: ${library.summary.needsHumanReview}`,
    `- Rejected: ${library.summary.rejected}`,
    `- Internal Only: ${library.summary.internalOnly}`,
    `- Effective Public: ${library.summary.effectivePublic}`,
    `- Hidden By Gate: ${library.summary.hiddenByGate}`,
    `- Speculative Deep Tech Profile: ${library.summary.speculative_deep_tech_profile_count}`,
    `- Accounting Gain Not Operating Turnaround: ${library.summary.accounting_gain_not_operating_turnaround_count}`,
    `- Vendor-only Hard Metrics: ${library.summary.vendor_only_hard_metrics_count}`,
    `- Order Materiality Missing: ${library.summary.order_materiality_missing_count}`,
    `- Technical Overweight In Thesis: ${library.summary.technical_overweight_in_thesis_count}`,
    "",
    "## Entries",
    "",
    "| Ticker | Report | Model | Requested | Effective | Gate | Sources | Review |",
    "| --- | --- | --- | --- | --- | --- | --- | --- |",
    ...library.entries.map((entry) => `| ${[
      entry.ticker,
      entry.fileName.replace(/\|/g, "/"),
      entry.modelLabel,
      entry.visibility,
      entry.qualityGate.effectiveVisibility,
      entry.qualityGate.status,
      entry.sourceStatus,
      entry.reviewStatus
    ].join(" | ")} |`)
  ];
  fs.writeFileSync(PUBLIC_LIBRARY_SNAPSHOT_PATH, lines.join("\n"), "utf8");
}

function updatePublicLibraryEntry(id, patch) {
  const library = buildPublicLibrary();
  const current = library.entries.find((entry) => entry.id === id);
  if (!current) {
    const error = new Error("Library-Report nicht gefunden.");
    error.statusCode = 404;
    throw error;
  }
  const state = loadPublicLibraryState();
  const previous = state.entries?.[id] || {};
  const next = {
    ...previous,
    sourceStatus: normalizeEnum(patch.sourceStatus || previous.sourceStatus || current.sourceStatus, ["unmatched_pdf", "pipeline_verified", "human_verified", "qa_failed"], current.sourceStatus),
    reviewStatus: normalizeEnum(patch.reviewStatus || previous.reviewStatus || current.reviewStatus, ["unreviewed", "reviewed", "rejected"], current.reviewStatus),
    visibility: normalizeEnum(patch.visibility || previous.visibility || current.visibility, ["hidden", "member", "public"], current.visibility),
    nonAdvice: typeof patch.nonAdvice === "boolean" ? patch.nonAdvice : previous.nonAdvice ?? current.nonAdvice,
    notes: typeof patch.notes === "string" ? patch.notes.slice(0, 2000) : previous.notes || "",
    reviewedAt: patch.reviewStatus === "reviewed" ? nowIso() : previous.reviewedAt || null,
    reviewedBy: patch.reviewStatus === "reviewed" ? String(patch.reviewedBy || "operator").slice(0, 80) : previous.reviewedBy || null
  };
  state.entries = {
    ...(state.entries || {}),
    [id]: next
  };
  savePublicLibraryState(state);
  return buildPublicLibrary().entries.find((entry) => entry.id === id);
}

function dismissPublicLibraryEntry(id, patch = {}) {
  const library = buildPublicLibrary({ includeDismissed: true, writeSnapshot: false });
  const current = library.entries.find((entry) => entry.id === id);
  if (!current) {
    const error = new Error("Library-Report nicht gefunden.");
    error.statusCode = 404;
    throw error;
  }
  const state = loadPublicLibraryState();
  const previous = state.entries?.[id] || {};
  state.entries = {
    ...(state.entries || {}),
    [id]: {
      ...previous,
      dismissedAt: nowIso(),
      dismissedBy: String(patch.dismissedBy || "operator").slice(0, 80)
    }
  };
  savePublicLibraryState(state);
  return current;
}

function completedArtifactsForJob(job) {
  const company = scanShelf().find((item) => item.ticker === job.ticker);
  if (!company?.latestQuality) {
    return null;
  }
  const exactQuality = qualityRunForJob(job) || company.latestQuality;
  const pdfPath = resolveProjectArtifactPath(exactQuality?.artifacts?.complete_pdf);
  const latestReport = reportPayloadForPath(pdfPath) || reportPayloadForQualityRun(exactQuality) || company.latestReport || null;
  return {
    latestReport,
    latestQuality: exactQuality,
    reportCount: company.reportCount
  };
}

function completeJobFromArtifacts(job, stage = "Gesichert") {
  const artifacts = completedArtifactsForJob(job);
  if (!artifacts?.latestQuality) {
    return false;
  }
  job.status = "completed";
  job.stage = stage;
  job.completedAt = job.completedAt || nowIso();
  job.error = null;
  job.artifacts = artifacts;
  delete job.activePid;
  delete job.failureReportPath;
  return true;
}

function recoverErroredJobFromExactArtifacts(job) {
  if (!job || job.status !== "error") {
    return false;
  }
  const exactQuality = qualityRunForJob(job);
  if (!exactQuality || exactQuality.verdict !== "pass") {
    return false;
  }
  const pdfPath = resolveProjectArtifactPath(exactQuality.artifacts?.complete_pdf);
  const latestReport = reportPayloadForPath(pdfPath) || reportPayloadForQualityRun(exactQuality);
  if (!latestReport) {
    return false;
  }
  const company = scanShelf().find((item) => item.ticker === job.ticker);
  job.status = "completed";
  job.stage = "Gesichert (Recovery nach Fehler)";
  job.completedAt = job.completedAt || nowIso();
  job.error = null;
  job.recoveredAt = job.recoveredAt || nowIso();
  job.recoveryReason =
    job.recoveryReason || "Fehlerstatus korrigiert: exaktes Dossier und Quality-Gate liegen nach Rebuild grün vor.";
  job.artifacts = {
    latestReport,
    latestQuality: exactQuality,
    reportCount: company?.reportCount || 1
  };
  delete job.activePid;
  delete job.failureReportPath;
  return true;
}

function latestMarkdownPath(company) {
  const quality = company?.latestQuality;
  const preferred =
    quality?.publishable === true
      ? quality?.artifacts?.publish_report || quality?.artifacts?.complete_md
      : quality?.artifacts?.internal_best_report || quality?.artifacts?.complete_md;
  const markdownPath = resolveProjectArtifactPath(preferred);
  if (!markdownPath || !fs.existsSync(markdownPath)) {
    return null;
  }
  let realMarkdown = null;
  try {
    realMarkdown = fs.realpathSync(markdownPath);
  } catch {
    return null;
  }
  const realRoot = fs.existsSync(REPORT_RUNS_DIR) ? fs.realpathSync(REPORT_RUNS_DIR) : REPORT_RUNS_DIR;
  return isInside(realMarkdown, realRoot) ? markdownPath : null;
}

function qualityRunForArtifactMarkdown(filePath) {
  let realArtifact = null;
  try {
    realArtifact = fs.realpathSync(filePath);
  } catch {
    return null;
  }
  for (const runs of scanQualityReports().values()) {
    for (const qualityRun of runs) {
      for (const artifactPath of Object.values(qualityRun.artifacts || {})) {
        const resolved = resolveProjectArtifactPath(artifactPath);
        if (!resolved || !fs.existsSync(resolved)) continue;
        try {
          if (fs.realpathSync(resolved) === realArtifact) {
            return qualityRun;
          }
        } catch {
          // Ignore broken artifact links while scanning.
        }
      }
    }
  }
  return null;
}

function renderQualityDecisionStatusbox(qualityDecision) {
  const keys = [
    "review_status",
    "quality_verdict",
    "publishable",
    "public_ready",
    "visibility",
    "internal_rating",
    "public_rating",
    "failed_checks"
  ];
  const lines = ["## Statusbox", ""];
  for (const key of keys) {
    const value = qualityDecision?.[key];
    const rendered = Array.isArray(value)
      ? (value.length ? value.join(", ") : "[]")
      : value == null
        ? "null"
        : typeof value === "boolean"
          ? String(value)
          : String(value);
    lines.push(`- ${key}: \`${rendered}\``);
  }
  return lines.join("\n");
}

function removeLegacyStatusbox(markdown) {
  return String(markdown || "")
    .replace(/\n?## Statusbox\n(?:\s*\n)?(?:[-*]\s*[A-Za-z0-9_ -]+\s*:\s*`?[^`\n]+`?\s*\n?)+/gi, "\n")
    .replace(/^\s*(?:Review status|Quality verdict|Publishable|Public ready|Visibility|Public rating)\s*:\s*`?[^`\n]+`?\s*$/gim, "")
    .trim();
}

function renderMarkdownWithQualityDecision(markdown, qualityRun, filePath) {
  const baseName = path.basename(filePath).toLowerCase();
  if (!qualityRun?.qualityDecision || !["internal_best_report.md", "evidence_report.md"].includes(baseName)) {
    return markdown;
  }
  const body = removeLegacyStatusbox(markdown);
  const statusbox = renderQualityDecisionStatusbox(qualityRun.qualityDecision);
  const lines = body.split(/\r?\n/);
  if (lines[0]?.startsWith("# ")) {
    return [lines[0], "", statusbox, "", ...lines.slice(1).filter((line, index) => index > 0 || line.trim())].join("\n").trim() + "\n";
  }
  return [statusbox, "", body].join("\n").trim() + "\n";
}

function loadJobs() {
  ensureDir(JOB_DIR);
  for (const fileName of fs.readdirSync(JOB_DIR)) {
    if (!fileName.endsWith(".json")) {
      continue;
    }
    const job = readJson(path.join(JOB_DIR, fileName));
    if (!job?.id) {
      continue;
    }
    if (job.status === "running") {
      recoverRunningJobOnLoad(job);
    }
    if (job.status === "error" && recoverErroredJobFromExactArtifacts(job)) {
      saveJob(job);
    }
    if (job.status === "completed" && completeJobFromArtifacts(job)) {
      saveJob(job);
    }
    jobs.set(job.id, job);
    if (job.status === "queued") {
      queuePump();
    }
  }
}

function recoverRunningJobOnLoad(job) {
  const manifest = job.runDir ? summarizeManifest(job.runDir) : null;
  if (manifest) {
    job.manifestSummary = manifest;
  }
  if (completeJobFromArtifacts(job, "Gesichert (Recovery)")) {
    job.recoveredAt = job.recoveredAt || nowIso();
    job.recoveryReason = job.recoveryReason || "Server-Neustart: fertiges Dossier und Quality-Gate erkannt.";
    saveJob(job);
    return job;
  }
  if (manifest?.status === "completed") {
    job.stage = "Dossier-Recovery wird vorbereitet";
    job.error = null;
    delete job.activePid;
    saveJob(job);
    startBundleRecovery(job);
    return job;
  }
  if (job.activePid && processExists(job.activePid)) {
    job.stage = job.stage || "Läuft";
    job.recoveredAt = job.recoveredAt || nowIso();
    job.recoveryReason = job.recoveryReason || "Server-Neustart: Prozess lebt noch.";
    saveJob(job);
    return job;
  }
  job.status = "error";
  job.stage = "Unterbrochen";
  job.error = manifest?.status === "completed_with_errors"
    ? manifestErrorSummary(manifest)
    : "Der App-Server wurde beendet, bevor dieser Job fertig war.";
  delete job.activePid;
  job.updatedAt = nowIso();
  job.failureReportPath = writeFailureReport(job, new Error(job.error));
  saveJob(job);
  return job;
}

function reconcileRecoveredJobs() {
  let changed = false;
  for (const job of jobs.values()) {
    if (job.status === "error" && recoverErroredJobFromExactArtifacts(job)) {
      saveJob(job);
      changed = true;
      continue;
    }
    if (job.status !== "running" || activeChildren.has(job.id) || activeRecoveryJobIds.has(job.id)) {
      continue;
    }
    const manifest = job.runDir ? summarizeManifest(job.runDir) : null;
    if (manifest) {
      job.manifestSummary = manifest;
    }
    if (completeJobFromArtifacts(job, "Gesichert (Recovery)")) {
      job.recoveredAt = job.recoveredAt || nowIso();
      job.recoveryReason = job.recoveryReason || "Recovery-Poller: fertiges Dossier und Quality-Gate erkannt.";
      saveJob(job);
      changed = true;
      continue;
    }
    if (manifest?.status === "completed" && (!job.activePid || !processExists(job.activePid))) {
      job.stage = "Dossier-Recovery wird vorbereitet";
      saveJob(job);
      startBundleRecovery(job);
      changed = true;
      continue;
    }
    if (manifest?.status === "completed_with_errors") {
      job.status = "error";
      job.stage = "Fehlerbericht erstellt";
      job.error = manifestErrorSummary(manifest);
      delete job.activePid;
      job.failureReportPath = writeFailureReport(job, new Error(job.error));
      saveJob(job);
      changed = true;
      continue;
    }
    if (job.activePid && processExists(job.activePid)) {
      activeJobId = activeJobId || job.id;
      continue;
    }
    job.status = "error";
    job.stage = "Unterbrochen";
    job.error = "Der App-Server hat keinen lebenden Prozess und kein fertiges Manifest mehr gefunden.";
    delete job.activePid;
    job.failureReportPath = writeFailureReport(job, new Error(job.error));
    saveJob(job);
    changed = true;
  }
  if (activeJobId && !jobs.get(activeJobId)?.status?.match(/^(queued|running)$/) && !activeChildren.has(activeJobId)) {
    activeJobId = null;
    changed = true;
  }
  if (changed) {
    queuePump();
  }
}

function saveJob(job) {
  job.updatedAt = nowIso();
  writeJson(path.join(JOB_DIR, `${job.id}.json`), job);
}

function jobErrorText(job) {
  const errors = Array.isArray(job.manifestSummary?.results)
    ? job.manifestSummary.results.map((result) => result.error).filter(Boolean).join("\n")
    : "";
  if (/weekly usage limit|RateLimitError|429/i.test(errors)) {
    return "Ollama-Cloud-Wochenlimit erreicht. Dieser Lauf hat keinen Report erzeugt.";
  }
  return job.error || null;
}

function isProviderLimitError(job) {
  const text = [job.error, jobErrorText(job), job.latestProgress, readTail(job.logPath, 40)]
    .filter(Boolean)
    .join("\n");
  return /weekly usage limit|Ollama-Cloud-Wochenlimit|RateLimitError|429/i.test(text);
}

function recentProviderLimitBlock(provider, quickModel, deepModel) {
  const cutoff = Date.now() - 30 * 60 * 1000;
  return [...jobs.values()]
    .filter((job) => {
      if (job.status !== "error" || job.provider !== provider || job.quickModel !== quickModel || job.deepModel !== deepModel) {
        return false;
      }
      const updatedAt = new Date(job.updatedAt || job.createdAt || 0).getTime();
      return updatedAt >= cutoff && isProviderLimitError(job);
    })
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())[0] || null;
}

function jobProgressPath(job) {
  const tickerDir = path.join(job.runDir || "", "tickers", job.ticker || "");
  const canonicalPath = path.join(tickerDir, "progress.jsonl");
  if (fs.existsSync(canonicalPath)) {
    return canonicalPath;
  }
  try {
    const attemptFiles = fs
      .readdirSync(tickerDir)
      .filter((name) => /^progress-attempt-\d+\.jsonl$/.test(name))
      .map((name) => path.join(tickerDir, name))
      .sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs);
    return attemptFiles[0] || canonicalPath;
  } catch {
    return canonicalPath;
  }
}

function readJsonlStats(filePath) {
  if (!filePath || !fs.existsSync(filePath)) {
    return { path: filePath || null, count: 0, last: null };
  }
  const lines = fs
    .readFileSync(filePath, "utf8")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  let last = null;
  for (let index = lines.length - 1; index >= 0; index -= 1) {
    try {
      last = JSON.parse(lines[index]);
      break;
    } catch {
      last = { raw: lines[index] };
      break;
    }
  }
  return { path: filePath, count: lines.length, last };
}

function latestCommandForStage(job, stage) {
  const history = Array.isArray(job.commandHistory) ? job.commandHistory : [];
  return [...history].reverse().find((entry) => entry.stage === stage) || null;
}

function workflowStep(id, status, detail = "", timestamp = null) {
  const template = REPORT_WORKFLOW_TEMPLATE.find((step) => step.id === id) || { id, label: id };
  return {
    id,
    label: template.label,
    status,
    detail,
    timestamp
  };
}

function buildReportWorkflow(job) {
  const progressPath = jobProgressPath(job);
  const progressStats = readJsonlStats(progressPath);
  const sourceLedgerStats = readJsonlStats(path.join(path.dirname(progressPath), "source-ledger.jsonl"));
  const manifest = job.manifestSummary || (job.runDir ? summarizeManifest(job.runDir) : null);
  const researchCommand = latestCommandForStage(job, "TradingAgents Research Flow");
  const bundleCommand =
    latestCommandForStage(job, "Dossier und Quality Gate") ||
    latestCommandForStage(job, "Dossier, PDF und Quality Gate");
  const quality = qualityRunForJob(job);
  const pdfPath = resolveProjectArtifactPath(quality?.artifacts?.complete_pdf);
  const markdownPath = resolveProjectArtifactPath(quality?.artifacts?.complete_md);
  const hasReportArtifact = Boolean(
    job.artifacts?.latestReport ||
      (pdfPath && fs.existsSync(pdfPath)) ||
      (markdownPath && fs.existsSync(markdownPath))
  );
  const manifestStatus = manifest?.status || null;
  const researchDone = manifestStatus === "completed" || researchCommand?.exitCode === 0;
  const researchFailed =
    manifestStatus === "completed_with_errors" ||
    (typeof researchCommand?.exitCode === "number" && researchCommand.exitCode !== 0);
  const researchActive =
    job.status === "running" &&
    (!job.stage || /TradingAgents|Research/i.test(job.stage) || !researchCommand?.completedAt);
  const bundleActive = job.status === "running" && /Dossier|Quality|Recovery/i.test(job.stage || "");
  const bundleFailed = typeof bundleCommand?.exitCode === "number" && bundleCommand.exitCode !== 0;
  const qualityVerdict = quality?.verdict || null;

  const steps = [];
  steps.push(
    workflowStep(
      "intake",
      "done",
      `${job.ticker} · ${job.modelProfileLabel || job.deepModel || "Modellprofil"} · ${job.analysisDate}`,
      job.createdAt
    )
  );
  steps.push(
    workflowStep(
      "queue",
      job.status === "queued" ? "active" : job.status === "canceled" && !job.startedAt ? "canceled" : "done",
      job.status === "queued" ? "wartet auf freien Report-Slot" : "aus der Warteschlange übernommen",
      job.startedAt || job.createdAt
    )
  );
  steps.push(
    workflowStep(
      "research",
      researchDone ? "done" : researchFailed || (job.status === "error" && !researchDone) ? "failed" : job.status === "canceled" && !researchDone ? "canceled" : researchActive ? "active" : "pending",
      progressStats.count
        ? `${progressStats.count} Progress-Ereignisse · zuletzt ${progressStats.last?.event || "Fortschritt"}`
        : "Analysten-, Tool- und LLM-Lauf",
      researchCommand?.completedAt || researchCommand?.startedAt || job.startedAt
    )
  );
  steps.push(
    workflowStep(
      "source_ledger",
      sourceLedgerStats.count
        ? "done"
        : researchDone
          ? "failed"
          : researchActive
            ? "active"
            : researchFailed
              ? "failed"
              : "pending",
      sourceLedgerStats.count
        ? `${sourceLedgerStats.count} Provenienzzeilen erfasst`
        : "Tool-Provenienz mit source_id, asof, period_type und formula_id",
      sourceLedgerStats.last?.time || null
    )
  );
  steps.push(
    workflowStep(
      "manifest",
      manifestStatus === "completed"
        ? "done"
        : manifestStatus === "completed_with_errors"
          ? "failed"
          : manifestStatus === "running"
            ? "active"
            : researchFailed
              ? "failed"
              : "pending",
      manifestStatus
        ? `${manifestStatus} · ${manifest?.results?.length || 0} Ticker`
        : "batch_manifest.json wird nach Research geschrieben",
      researchCommand?.completedAt || null
    )
  );
  steps.push(
    workflowStep(
      "dossier",
      hasReportArtifact
        ? "done"
        : bundleFailed || (job.status === "error" && researchDone)
          ? "failed"
          : bundleActive
            ? "active"
            : "pending",
      hasReportArtifact ? "Markdown-Dossier/Report-Artefakt vorhanden" : "Markdown-Dossier wird für QA gebaut",
      bundleCommand?.completedAt || bundleCommand?.startedAt || null
    )
  );
  steps.push(
    workflowStep(
      "quality_gate",
      qualityVerdict === "pass"
        ? "done"
        : qualityVerdict === "fail" || bundleFailed
          ? "failed"
          : bundleActive
            ? "active"
            : "pending",
      qualityVerdict ? `${qualityVerdict} · ${quality?.status || "Quality-Bericht"}` : "Deterministische QA, Deep-Tech-Guard und Rendercheck",
      quality?.createdAt || bundleCommand?.completedAt || null
    )
  );
  steps.push(
    workflowStep(
      "shelf",
      job.status === "completed" || job.artifacts?.latestReport ? "done" : bundleActive && qualityVerdict === "pass" ? "active" : "pending",
      job.artifacts?.latestReport?.fileName || (hasReportArtifact ? "lesbarer Report-Pfad verfügbar" : "Human Shelf und Reader-Link ausstehend"),
      job.completedAt || null
    )
  );

  let publishStatus = "pending";
  let publishDetail = "wartet auf Human Review, Source Review und Non-Advice-Gate";
  if (quality?.status === "manual_review" || quality?.publishable === false) {
    publishStatus = "blocked";
    publishDetail = "Manual Review blockiert Public-/Member-Ausleitung";
  } else if (qualityVerdict === "fail") {
    publishStatus = "blocked";
    publishDetail = "Quality Gate blockiert Public-/Member-Ausleitung";
  } else if (!qualityVerdict) {
    publishDetail = "erst nach Quality Gate bewertbar";
  }
  steps.push(workflowStep("publish_gate", publishStatus, publishDetail, null));

  const completed = steps.filter((step) => step.status === "done").length;
  const current =
    steps.find((step) => step.status === "active") ||
    steps.find((step) => ["failed", "blocked", "canceled"].includes(step.status)) ||
    steps.find((step) => step.status === "pending") ||
    steps[steps.length - 1];

  return {
    steps,
    progress: {
      completed,
      total: steps.length,
      currentStepId: current?.id || null,
      currentLabel: current?.label || "Workflow",
      currentStatus: current?.status || "pending"
    }
  };
}

function publicJob(job) {
  const progressPath = jobProgressPath(job);
  const latestProgress = readTail(progressPath, 4);
  const workflow = buildReportWorkflow(job);
  return {
    id: job.id,
    ticker: job.ticker,
    status: job.status,
    stage: job.stage,
    createdAt: job.createdAt,
    startedAt: job.startedAt || null,
    completedAt: job.completedAt || null,
    updatedAt: job.updatedAt,
    analysisDate: job.analysisDate,
    provider: job.provider,
    quickModel: job.quickModel,
    deepModel: job.deepModel,
    modelProfileId: job.modelProfileId || null,
    modelProfileLabel: job.modelProfileLabel || null,
    comparisonId: job.comparisonId || null,
    runDir: job.runDir,
    logPath: job.logPath,
    error: jobErrorText(job),
    requestedInput: job.requestedInput || null,
    tickerResolution: job.tickerResolution || null,
    cancelRequestedAt: job.cancelRequestedAt || null,
    canceledAt: job.canceledAt || null,
    failureReportId: job.failureReportPath ? encodeId(job.failureReportPath) : null,
    latestProgress,
    workflow: workflow.steps,
    workflowProgress: workflow.progress,
    artifacts: job.artifacts || null
  };
}

function listJobs() {
  return [...jobs.values()]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .map(publicJob);
}

function recoverableJobs({ ticker } = {}) {
  const normalizedTicker = ticker ? normalizeReportTicker(ticker) : "";
  return [...jobs.values()]
    .filter((job) => ["error", "canceled"].includes(job.status))
    .filter((job) => !normalizedTicker || job.ticker === normalizedTicker)
    .sort((a, b) => new Date(b.updatedAt || b.createdAt).getTime() - new Date(a.updatedAt || a.createdAt).getTime());
}

function buildReportMachineStatus() {
  const allJobs = [...jobs.values()];
  const recoverable = recoverableJobs();
  const profiles = modelProfiles();
  const safeProfiles = profiles.filter((profile) => !profile.requiresPaidConfirmation);
  const running = allJobs.filter((job) => job.status === "running");
  const queued = allJobs.filter((job) => job.status === "queued");
  const failed = allJobs.filter((job) => job.status === "error");
  const canceled = allJobs.filter((job) => job.status === "canceled");
  const preflight = getPreflight();
  const hardening = getHardeningStatus();
  const ready = Boolean(preflight.ok) && hardening.verdict === "pass" && safeProfiles.length >= 2;

  return {
    generatedAt: nowIso(),
    ready,
    activeJobId,
    runningJobs: running.length,
    queuedJobs: queued.length,
    failedJobs: failed.length,
    canceledJobs: canceled.length,
    recoverableJobs: recoverable.length,
    recoverableByTicker: recoverable.reduce((acc, job) => {
      acc[job.ticker] = (acc[job.ticker] || 0) + 1;
      return acc;
    }, {}),
    safeModelProfiles: safeProfiles.map((profile) => ({
      id: profile.id,
      label: profile.label,
      provider: profile.provider,
      deepModel: profile.deepModel
    })),
    lockedModelProfiles: profiles
      .filter((profile) => profile.requiresPaidConfirmation)
      .map((profile) => ({ id: profile.id, label: profile.label, provider: profile.provider })),
    policy: {
      activeModelsExcludeKimiAndGpt55: profiles.every((profile) => !/kimi|gpt-5\.5/i.test(`${profile.id} ${profile.label}`)),
      deepseekIsOllamaCloud: profiles.some((profile) =>
        profile.id === "deepseek-v4-ollama" &&
        profile.provider === "ollama" &&
        String(profile.deepModel || "").endsWith(":cloud")
      ),
      publicReadyRequires: ["quality_pass", "publishable_true", "human_verified_sources", "reviewed", "non_advice"],
      manualReviewProfiles: ["SPECULATIVE_DEEP_TECH_MANUAL_REVIEW_PROFILE"],
      failedQualityVisibility: "rejected_or_hidden",
      reportFlow: REPORT_WORKFLOW_TEMPLATE.map((step) => step.id),
      reportFlowLabels: REPORT_WORKFLOW_TEMPLATE
    },
    nextAction: ready
      ? recoverable.length
        ? "Fehlgeschlagene oder gestoppte Jobs können erneut gestartet werden."
        : "Report-Maschine bereit."
      : "Preflight, Hardening oder Modellprofil-Konfiguration prüfen.",
    latestRecoverable: recoverable.slice(0, 8).map((job) => publicJob(job))
  };
}

async function retryRecoverableJobs(payload = {}) {
  const ticker = payload?.ticker ? normalizeReportTicker(payload.ticker) : "";
  const limit = Math.max(1, Math.min(Number(payload?.limit || 4), 12));
  const candidates = recoverableJobs({ ticker }).slice(0, limit);
  const results = [];

  for (const original of candidates) {
    try {
      const retry = await retryJob(original.id);
      results.push({
        originalJobId: original.id,
        status: "queued",
        retryJob: publicJob(retry)
      });
    } catch (error) {
      results.push({
        originalJobId: original.id,
        status: "blocked",
        error: error.message || String(error)
      });
    }
  }

  return {
    ticker: ticker || null,
    requested: candidates.length,
    queued: results.filter((result) => result.status === "queued").length,
    blocked: results.filter((result) => result.status === "blocked").length,
    results,
    reportMachine: buildReportMachineStatus()
  };
}

function saveComparison(comparison) {
  comparison.updatedAt = nowIso();
  writeJson(path.join(COMPARISON_DIR, `${comparison.id}.json`), comparison);
}

function loadComparison(id) {
  const safeId = String(id || "").replace(/[^A-Za-z0-9._-]/g, "");
  if (!safeId) {
    return null;
  }
  return readJson(path.join(COMPARISON_DIR, `${safeId}.json`));
}

function listComparisons() {
  ensureDir(COMPARISON_DIR);
  return fs
    .readdirSync(COMPARISON_DIR)
    .filter((fileName) => fileName.endsWith(".json"))
    .map((fileName) => readJson(path.join(COMPARISON_DIR, fileName)))
    .filter((comparison) => comparison?.id)
    .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime())
    .slice(0, 16)
    .map((comparison) => hydrateComparison(comparison, { lightweight: true }));
}

function sameResolvedPath(left, right) {
  if (!left || !right) {
    return false;
  }
  return path.resolve(left) === path.resolve(right);
}

function qualityRunForJob(job) {
  if (!job) {
    return null;
  }
  const jobRunDir = resolveProjectArtifactPath(job.runDir);
  const qualityRuns = scanQualityReports().get(job.ticker) || [];
  const exact = qualityRuns.find((run) => sameResolvedPath(resolveProjectArtifactPath(run.runDir), jobRunDir));
  if (exact) {
    return exact;
  }
  return job.artifacts?.latestQuality || null;
}

function comparisonArtifactSummary(qualityRun) {
  if (!qualityRun) {
    return null;
  }
  const pdfPath = resolveProjectArtifactPath(qualityRun.artifacts?.complete_pdf);
  const markdownPath = resolveProjectArtifactPath(qualityRun.artifacts?.complete_md);
  return {
    qualityId: qualityRun.qualityId || (qualityRun.qualityPath ? encodeId(qualityRun.qualityPath) : null),
    pdfId: pdfPath && fs.existsSync(pdfPath) ? encodeId(pdfPath) : null,
    pdfUrl: pdfPath && fs.existsSync(pdfPath) ? `/api/reports/${encodeId(pdfPath)}` : null,
    markdownId: markdownPath && fs.existsSync(markdownPath) ? encodeId(markdownPath) : null,
    markdownUrl: markdownPath && fs.existsSync(markdownPath) ? `/api/artifacts/${encodeId(markdownPath)}/markdown` : null,
    markdownPath: markdownPath && fs.existsSync(markdownPath) ? markdownPath : null
  };
}

function comparisonResultDetail(result) {
  const job = result.jobId ? jobs.get(result.jobId) : null;
  const publicResult = {
    ...result,
    job: job ? publicJob(job) : null,
    quality: null,
    artifacts: null
  };
  if (!job || job.status !== "completed") {
    return publicResult;
  }
  const quality = qualityRunForJob(job);
  publicResult.quality = quality;
  publicResult.artifacts = comparisonArtifactSummary(quality);
  return publicResult;
}

function comparisonStatus(results) {
  const counts = {
    queued: 0,
    running: 0,
    completed: 0,
    error: 0,
    canceled: 0,
    blocked: 0,
    missing: 0
  };
  for (const result of results) {
    if (result.status === "blocked") {
      counts.blocked += 1;
      continue;
    }
    const job = result.jobId ? jobs.get(result.jobId) : null;
    if (!job) {
      counts.missing += 1;
      continue;
    }
    if (counts[job.status] !== undefined) {
      counts[job.status] += 1;
    }
  }
  if (counts.running || counts.queued) {
    return { label: "running", counts };
  }
  if (counts.completed >= 2 && !counts.error && !counts.canceled && !counts.blocked && !counts.missing) {
    return { label: "ready_for_evaluation", counts };
  }
  if (counts.completed >= 2) {
    return { label: "partial_ready", counts };
  }
  if (counts.completed === 1) {
    return { label: "waiting_for_more_reports", counts };
  }
  if (counts.error || counts.canceled || counts.blocked || counts.missing) {
    return { label: "blocked", counts };
  }
  return { label: "empty", counts };
}

function comparisonEvaluationPath(id, extension) {
  return path.join(COMPARISON_DIR, id, `evaluation.${extension}`);
}

function loadComparisonEvaluation(id) {
  const jsonPath = comparisonEvaluationPath(id, "json");
  const markdownPath = comparisonEvaluationPath(id, "md");
  const evaluation = readJson(jsonPath);
  if (!evaluation) {
    return null;
  }
  const markdownId = encodeId(markdownPath);
  return {
    ...evaluation,
    markdownId,
    markdownUrl: `/api/artifacts/${markdownId}/markdown`,
    markdown: fs.existsSync(markdownPath) ? fs.readFileSync(markdownPath, "utf8") : evaluation.markdown || ""
  };
}

function numberMetric(qualityRun, key) {
  const value = Number(qualityRun?.metrics?.[key]);
  return Number.isFinite(value) ? value : 0;
}

function scoreQualityRun(qualityRun) {
  if (!qualityRun) {
    return 0;
  }
  let score = 0;
  if (qualityRun.verdict === "pass") {
    score += 30;
  }
  if (Math.max(numberMetric(qualityRun, "complete_pdf_words"), numberMetric(qualityRun, "complete_md_words")) >= 5500) {
    score += 18;
  }
  if (numberMetric(qualityRun, "raw_source_words") >= 5000) {
    score += 18;
  }
  if (qualityRun.rating) {
    score += 12;
  }
  if (qualityRun.traderSignal) {
    score += 10;
  }
  if (qualityRun.elapsedSeconds && qualityRun.elapsedSeconds <= 900) {
    score += 8;
  }
  if (numberMetric(qualityRun, "final_documents_rendered") && numberMetric(qualityRun, "complete_pdf_pages") >= 12) {
    score += 4;
  }
  const integrityVerdict = qualityRun.metrics?.research_integrity_verdict;
  if (integrityVerdict === "review_required") {
    score -= 10;
  }
  if (integrityVerdict === "fail") {
    score -= 20;
  }
  return Math.max(0, Math.min(score, 100));
}

function formatScoreValue(value) {
  return Number.isFinite(value) ? String(Math.round(value)) : "0";
}

function buildComparisonEvaluation(comparison) {
  const detailedResults = comparison.results.map(comparisonResultDetail);
  const completed = detailedResults.filter((result) => result.job?.status === "completed" && result.quality);
  const status = comparisonStatus(comparison.results);
  const rows = completed.map((result) => {
    const quality = result.quality;
    const score = scoreQualityRun(quality);
    return {
      profileId: result.profileId,
      profileLabel: result.profileLabel,
      jobId: result.jobId,
      provider: result.job?.provider || null,
      quickModel: result.job?.quickModel || null,
      deepModel: result.job?.deepModel || null,
      score,
      verdict: quality?.verdict || null,
      rating: quality?.rating || null,
      traderSignal: quality?.traderSignal || null,
      words: Math.max(numberMetric(quality, "complete_pdf_words"), numberMetric(quality, "complete_md_words")),
      sourceWords: numberMetric(quality, "raw_source_words"),
      pages: numberMetric(quality, "complete_pdf_pages"),
      elapsedSeconds: quality?.elapsedSeconds || null,
      researchIntegrity: quality?.metrics?.research_integrity_verdict || null,
      pdfUrl: result.artifacts?.pdfUrl || null,
      markdownUrl: result.artifacts?.markdownUrl || null
    };
  }).sort((a, b) => b.score - a.score);
  const winner = rows[0] || null;
  const uniqueRatings = [...new Set(rows.map((row) => row.rating).filter(Boolean))];
  const uniqueSignals = [...new Set(rows.map((row) => row.traderSignal).filter(Boolean))];
  const warnings = [];
  if (completed.length < 2) {
    warnings.push("Noch nicht genug fertige Reports für einen belastbaren Vergleich.");
  }
  if (uniqueRatings.length > 1) {
    warnings.push(`Rating-Unterschied sichtbar: ${uniqueRatings.join(" vs. ")}.`);
  }
  if (uniqueSignals.length > 1) {
    warnings.push(`Trader-Signal unterscheidet sich: ${uniqueSignals.join(" vs. ")}.`);
  }
  if (status.counts.blocked || status.counts.error || status.counts.canceled) {
    warnings.push("Mindestens ein Profil ist blockiert, fehlgeschlagen oder gestoppt.");
  }
  const markdown = [
    `# Room 16 Modellvergleich - ${comparison.ticker}`,
    "",
    `Erstellt: ${nowIso()}`,
    `Vergleich: ${comparison.id}`,
    `Analyse-Datum: ${comparison.analysisDate}`,
    `Status: ${status.label}`,
    "",
    "## Kurzfazit",
    "",
    winner
      ? `- Führendes Profil nach deterministischem Operator-Score: **${winner.profileLabel}** (${formatScoreValue(winner.score)}/100).`
      : "- Noch kein führendes Profil, weil weniger als zwei fertige Reports vorliegen.",
    `- Fertige Reports: ${completed.length}/${comparison.results.length}.`,
    warnings.length ? `- Hinweise: ${warnings.join(" ")}` : "- Keine harten Divergenzen im aktuellen Vergleichsstand.",
    "",
    "## Scoreboard",
    "",
    "| Profil | Score | Status | Rating | Trader | Wörter | Quellenwörter | Quellen-QA | Laufzeit | Report |",
    "| --- | ---: | --- | --- | --- | ---: | ---: | --- | --- | --- |",
    ...detailedResults.map((result) => {
      const row = rows.find((item) => item.profileId === result.profileId);
      const jobStatus = result.job?.status || result.status;
      if (!row) {
        return `| ${result.profileLabel} | 0 | ${jobStatus} | - | - | 0 | 0 | - | - | - |`;
      }
      const reportLink = row.pdfUrl ? `[PDF](${row.pdfUrl})` : "-";
      return `| ${row.profileLabel} | ${formatScoreValue(row.score)} | ${jobStatus} | ${row.rating || "-"} | ${row.traderSignal || "-"} | ${row.words} | ${row.sourceWords} | ${row.researchIntegrity || "-"} | ${row.elapsedSeconds ? `${Math.round(row.elapsedSeconds)}s` : "-"} | ${reportLink} |`;
    }),
    "",
    "## Leseregel",
    "",
    "- Dieser Vergleich ist absichtlich deterministisch und ersetzt keine finale menschliche Anlageentscheidung.",
    "- Der Score bewertet technische Nutzbarkeit: Quality-Gate, Reportumfang, Quellen-/Rohmaterialumfang, vorhandene Entscheidungssignale und Laufzeit.",
    "- Bei unterschiedlichen Ratings oder Trader-Signalen muss Vega später eine inhaltliche Review-Runde fahren, bevor ein Modell als neuer Default gesetzt wird."
  ].join("\n");
  return {
    id: comparison.id,
    ticker: comparison.ticker,
    createdAt: nowIso(),
    status: status.label,
    counts: status.counts,
    winnerProfileId: winner?.profileId || null,
    winnerProfileLabel: winner?.profileLabel || null,
    rows,
    warnings,
    markdown
  };
}

function writeComparisonEvaluation(comparison) {
  const evaluation = buildComparisonEvaluation(comparison);
  ensureDir(path.join(COMPARISON_DIR, comparison.id));
  writeJson(comparisonEvaluationPath(comparison.id, "json"), {
    ...evaluation,
    markdown: undefined
  });
  fs.writeFileSync(comparisonEvaluationPath(comparison.id, "md"), evaluation.markdown, "utf8");
  comparison.evaluation = {
    status: evaluation.status,
    createdAt: evaluation.createdAt,
    winnerProfileId: evaluation.winnerProfileId,
    winnerProfileLabel: evaluation.winnerProfileLabel,
    warningCount: evaluation.warnings.length,
    markdownId: encodeId(comparisonEvaluationPath(comparison.id, "md")),
    markdownUrl: `/api/artifacts/${encodeId(comparisonEvaluationPath(comparison.id, "md"))}/markdown`
  };
  saveComparison(comparison);
  return evaluation;
}

function hydrateComparison(comparison, options = {}) {
  const status = comparisonStatus(comparison.results || []);
  const evaluation = options.lightweight
    ? comparison.evaluation || loadComparisonEvaluation(comparison.id)
    : loadComparisonEvaluation(comparison.id) || comparison.evaluation || null;
  const statusLabel = evaluation && status.label === "ready_for_evaluation" ? "evaluated" : status.label;
  const hydrated = {
    ...comparison,
    status: statusLabel,
    counts: status.counts,
    evaluation
  };
  if (!options.lightweight) {
    hydrated.results = (comparison.results || []).map(comparisonResultDetail);
  }
  return hydrated;
}

function requireComparison(id) {
  const comparison = loadComparison(id);
  if (!comparison?.id) {
    const error = new Error("Vergleich nicht gefunden.");
    error.statusCode = 404;
    throw error;
  }
  return comparison;
}

function appendLog(job, text) {
  ensureDir(path.dirname(job.logPath));
  fs.appendFileSync(job.logPath, text, "utf8");
}

function runCommand(job, stage, command, commandArgs) {
  return new Promise((resolve, reject) => {
    if (job.cancelRequestedAt) {
      reject(new JobCanceledError());
      return;
    }
    job.stage = stage;
    job.commandHistory = job.commandHistory || [];
    job.commandHistory.push({
      stage,
      command: [command, ...commandArgs],
      startedAt: nowIso()
    });
    saveJob(job);
    appendLog(job, `\n\n## ${stage}\n+ ${[command, ...commandArgs].join(" ")}\n`);
    const logFd = fs.openSync(job.logPath, "a");
    const child = spawn(command, commandArgs, {
      cwd: PROJECT_ROOT,
      env: { ...process.env, PYTHONUNBUFFERED: "1" },
      detached: true,
      stdio: ["ignore", logFd, logFd]
    });
    job.activePid = child.pid;
    activeChildren.set(job.id, child);
    saveJob(job);
    child.on("error", (error) => {
      closeFd(logFd);
      delete job.activePid;
      activeChildren.delete(job.id);
      saveJob(job);
      appendLog(job, `\n[process error] ${error.message}\n`);
      reject(error);
    });
    child.on("close", (code) => {
      closeFd(logFd);
      appendLog(job, `\n[exit] ${stage}: ${code}\n`);
      const entry = job.commandHistory[job.commandHistory.length - 1];
      entry.completedAt = nowIso();
      entry.exitCode = code;
      delete job.activePid;
      activeChildren.delete(job.id);
      saveJob(job);
      if (job.cancelRequestedAt || job.status === "canceled") {
        reject(new JobCanceledError());
        return;
      }
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`${stage} wurde mit Exit-Code ${code} beendet.`));
      }
    });
  });
}

function choosePython(preferred, fallback = "python3") {
  return fs.existsSync(preferred) ? preferred : fallback;
}

function summarizeManifest(runDir) {
  const manifestPath = path.join(runDir, "batch_manifest.json");
  const manifest = readJson(manifestPath);
  if (!manifest) {
    return null;
  }
  return {
    status: manifest.status,
    tickers: manifest.tickers || [],
    date: manifest.date || null,
    provider: manifest.provider || null,
    deepModel: manifest.deep_model || null,
    quickModel: manifest.quick_model || null,
    results: Array.isArray(manifest.results)
      ? manifest.results.map((result) => ({
          ticker: result.ticker,
          status: result.status,
          elapsedSeconds: result.elapsed_seconds,
          decision: result.decision,
          error: result.error || null
        }))
      : []
  };
}

function manifestErrorSummary(manifest) {
  const errors = Array.isArray(manifest?.results)
    ? manifest.results.map((result) => result.error).filter(Boolean)
    : [];
  const joined = errors.join("\n");
  if (/weekly usage limit|RateLimitError|429/i.test(joined)) {
    return "Ollama-Cloud-Wochenlimit erreicht. Kein Room-16-Report wurde erzeugt.";
  }
  return `TradingAgents-Manifest ist ${manifest?.status || "nicht abgeschlossen"}.`;
}

function getPreflight() {
  const batchPython = choosePython(process.env.ROOM16_BATCH_PYTHON || DEFAULT_BATCH_PYTHON);
  const bundlePython = choosePython(process.env.ROOM16_BUNDLE_PYTHON || DEFAULT_BUNDLE_PYTHON, batchPython);
  const checks = [
    {
      name: "human_shelf",
      ok: fs.existsSync(SHELF_DIR),
      detail: SHELF_DIR
    },
    {
      name: "batch_python",
      ok: fs.existsSync(batchPython) || batchPython === "python3",
      detail: batchPython
    },
    {
      name: "bundle_python",
      ok: fs.existsSync(bundlePython) || bundlePython === "python3",
      detail: bundlePython
    },
    {
      name: "batch_script",
      ok: fs.existsSync(path.join(PROJECT_ROOT, "scripts", "bcr_company_batch.py")),
      detail: path.join(PROJECT_ROOT, "scripts", "bcr_company_batch.py")
    },
    {
      name: "bundle_script",
      ok: fs.existsSync(path.join(PROJECT_ROOT, "scripts", "room16_build_report_bundle.py")),
      detail: path.join(PROJECT_ROOT, "scripts", "room16_build_report_bundle.py")
    },
    {
      name: "runtime_timeouts",
      ok:
        Number.isFinite(ROOM16_LLM_TIMEOUT_SECONDS) &&
        Number.isFinite(ROOM16_TICKER_TIMEOUT_SECONDS) &&
        Number.isFinite(ROOM16_STALL_TIMEOUT_SECONDS) &&
        Number.isFinite(ROOM16_TICKER_RETRIES) &&
        Number.isFinite(ROOM16_RETRY_DELAY_SECONDS),
      detail: `llm=${ROOM16_LLM_TIMEOUT_SECONDS}s ticker=${ROOM16_TICKER_TIMEOUT_SECONDS}s stall=${ROOM16_STALL_TIMEOUT_SECONDS}s retries=${ROOM16_TICKER_RETRIES} retry_delay=${ROOM16_RETRY_DELAY_SECONDS}s`
    }
  ];
  checks.push(...getBundleDependencyPreflight(bundlePython));
  return {
    ok: checks.every((check) => check.ok),
    checks
  };
}

function getBundleDependencyPreflight(bundlePython) {
  const cacheKey = bundlePython;
  const now = Date.now();
  if (
    bundleDependencyPreflightCache?.cacheKey === cacheKey &&
    bundleDependencyPreflightCache.expiresAt > now
  ) {
    return bundleDependencyPreflightCache.checks;
  }
  const script = [
    "import importlib.util, json",
    "mods = ['docx', 'reportlab', 'pypdf', 'fitz']",
    "print(json.dumps({name: importlib.util.find_spec(name) is not None for name in mods}))"
  ].join("; ");
  const result = spawnSync(bundlePython, ["-c", script], {
    cwd: PROJECT_ROOT,
    encoding: "utf8",
    timeout: 5000
  });
  let imports = null;
  try {
    imports = JSON.parse(result.stdout || "{}");
  } catch {
    imports = null;
  }
  const failed = result.status !== 0 || !imports;
  const checks = failed
    ? [
        {
          name: "bundle_python_dependencies",
          ok: false,
          detail: result.stderr?.trim() || result.error?.message || "Dependency import preflight failed."
        }
      ]
    : [
        {
          name: "bundle_python_docx",
          ok: Boolean(imports.docx),
          detail: imports.docx ? "python-docx importable" : "python-docx missing"
        },
        {
          name: "bundle_python_reportlab",
          ok: Boolean(imports.reportlab),
          detail: imports.reportlab ? "reportlab importable" : "reportlab missing"
        },
        {
          name: "bundle_python_pypdf",
          ok: Boolean(imports.pypdf),
          detail: imports.pypdf ? "pypdf text fallback importable" : "pypdf missing"
        },
        {
          name: "bundle_python_pdf_render_backend",
          ok: Boolean(imports.fitz),
          detail: imports.fitz
            ? "PyMuPDF/fitz importable; visual PDF render enabled"
            : "PyMuPDF/fitz missing; report jobs are blocked until visual PDF render QA is available"
        }
      ];
  bundleDependencyPreflightCache = {
    cacheKey,
    expiresAt: now + 60_000,
    checks
  };
  return checks;
}

function getHardeningStatus() {
  const latest = readJson(HARDENING_LATEST_PATH);
  if (!latest) {
    return {
      available: false,
      verdict: "not_run",
      latestCycleId: null,
      createdAt: null,
      reportPath: HARDENING_LATEST_PATH
    };
  }
  return {
    available: true,
    verdict: latest.verdict || "unknown",
    latestCycleId: latest.cycleId || null,
    createdAt: latest.createdAt || null,
    reportPath: HARDENING_LATEST_PATH,
    commands: Array.isArray(latest.commands)
      ? latest.commands.map((command) => ({
          label: command.label,
          exitCode: command.exitCode
        }))
      : []
  };
}

function writeFailureReport(job, error) {
  ensureDir(FAILURE_DIR);
  const filePath = path.join(FAILURE_DIR, `${job.id}-${job.ticker}-failure.md`);
  const manifest = job.runDir ? summarizeManifest(job.runDir) : null;
  const logTail = readTail(job.logPath, 140);
  const body = [
    `# Room 16 Fehlerbericht - ${job.ticker}`,
    "",
    `Erstellt: ${nowIso()}`,
    `Job: ${job.id}`,
    `Status: ${job.status}`,
    `Stage: ${job.stage}`,
    `Fehler: ${error?.message || job.error || "Unbekannt"}`,
    "",
    "## Eingabe",
    "",
    "```json",
    JSON.stringify(
      {
        ticker: job.ticker,
        analysisDate: job.analysisDate,
        provider: job.provider,
        quickModel: job.quickModel,
        deepModel: job.deepModel,
        modelProfileId: job.modelProfileId || null,
        modelProfileLabel: job.modelProfileLabel || null,
        comparisonId: job.comparisonId || null,
        runDir: job.runDir,
        logPath: job.logPath
      },
      null,
      2
    ),
    "```",
    "",
    "## Manifest",
    "",
    "```json",
    JSON.stringify(manifest, null, 2),
    "```",
    "",
    "## Befehle",
    "",
    "```json",
    JSON.stringify(job.commandHistory || [], null, 2),
    "```",
    "",
    "## Log Tail",
    "",
    "```text",
    logTail || "Kein Log vorhanden.",
    "```",
    "",
    "## Vega-Hinweis",
    "",
    "Den Job nicht als fertigen Report behandeln. Erst Ursache beheben, dann denselben Ticker als neuen Einzelreport erneut starten."
  ].join("\n");
  fs.writeFileSync(filePath, body, "utf8");
  return filePath;
}

async function runBundleAndFinalize(job) {
  const batchPython = choosePython(process.env.ROOM16_BATCH_PYTHON || DEFAULT_BATCH_PYTHON);
  const bundlePython = choosePython(process.env.ROOM16_BUNDLE_PYTHON || DEFAULT_BUNDLE_PYTHON, batchPython);
  const bundleArgs = [
    "scripts/room16_build_report_bundle.py",
    "--run-dir",
    job.runDir,
    "--translate-model",
    job.deepModel || defaultModelProfile().deepModel || "deepseek-v4-pro:cloud",
    "--date",
    localDateString(new Date()),
    "--shelf-dir",
    SHELF_DIR
  ];
  if (job.withPremium) {
    bundleArgs.push("--with-premium");
  }
  await runCommand(job, "Dossier und Quality Gate", bundlePython, bundleArgs);

  if (job.cancelRequestedAt) {
    throw new JobCanceledError();
  }

  if (!completeJobFromArtifacts(job)) {
    job.status = "completed";
    job.stage = "Gesichert";
    job.completedAt = nowIso();
    job.artifacts = null;
    delete job.activePid;
  }
  saveJob(job);
}

function startBundleRecovery(job) {
  if (activeRecoveryJobIds.has(job.id)) {
    return;
  }
  activeRecoveryJobIds.add(job.id);
  activeJobId = activeJobId || job.id;
  runBundleAndFinalize(job)
    .catch((error) => {
      job.status = error instanceof JobCanceledError ? "canceled" : "error";
      job.stage = error instanceof JobCanceledError ? "Gestoppt" : "Fehlerbericht erstellt";
      job.error = error instanceof JobCanceledError ? null : error.message || String(error);
      if (!(error instanceof JobCanceledError)) {
        job.failureReportPath = writeFailureReport(job, error);
      }
      saveJob(job);
    })
    .finally(() => {
      activeRecoveryJobIds.delete(job.id);
      if (activeJobId === job.id) {
        activeJobId = null;
      }
      queuePump();
    });
}

async function runJob(job) {
  try {
    job.status = "running";
    job.startedAt = nowIso();
    saveJob(job);

    const batchPython = choosePython(process.env.ROOM16_BATCH_PYTHON || DEFAULT_BATCH_PYTHON);
    const batchArgs = [
      "scripts/bcr_company_batch.py",
      "--tickers",
      job.ticker,
      "--date",
      job.analysisDate,
      "--provider",
      job.provider,
      "--deep-model",
      job.deepModel,
      "--quick-model",
      job.quickModel,
      "--run-dir",
      job.runDir,
      "--output-language",
      "German",
      "--llm-timeout",
      String(ROOM16_LLM_TIMEOUT_SECONDS),
      "--ticker-timeout-seconds",
      String(ROOM16_TICKER_TIMEOUT_SECONDS),
      "--stall-timeout-seconds",
      String(ROOM16_STALL_TIMEOUT_SECONDS),
      "--ticker-retries",
      String(ROOM16_TICKER_RETRIES),
      "--retry-delay-seconds",
      String(ROOM16_RETRY_DELAY_SECONDS)
    ];
    await runCommand(job, "TradingAgents Research Flow", batchPython, batchArgs);
    const manifest = summarizeManifest(job.runDir);
    job.manifestSummary = manifest;
    saveJob(job);
    if (manifest?.status !== "completed") {
      throw new Error(manifestErrorSummary(manifest));
    }

    await runBundleAndFinalize(job);
  } catch (error) {
    if (error instanceof JobCanceledError || job.cancelRequestedAt || job.status === "canceled") {
      job.status = "canceled";
      job.stage = "Gestoppt";
      job.error = null;
      job.canceledAt = job.canceledAt || nowIso();
      saveJob(job);
      return;
    }
    job.status = "error";
    job.error = error instanceof Error ? error.message : String(error);
    job.failureReportPath = writeFailureReport(job, error);
    job.stage = "Fehlerbericht erstellt";
    saveJob(job);
  } finally {
    activeJobId = null;
    queuePump();
  }
}

function stopChildProcess(job) {
  const child = activeChildren.get(job.id);
  const pid = child?.pid || job.activePid;
  if (!pid) {
    return;
  }
  appendLog(job, `\n[cancel] Operator hat Stop angefordert für PID ${pid}.\n`);
  try {
    process.kill(-pid, "SIGTERM");
  } catch {
    try {
      process.kill(pid, "SIGTERM");
    } catch {
      // The process may already be gone; runCommand will settle the job state.
    }
  }
  setTimeout(() => {
    const stillActive = activeChildren.get(job.id);
    if (!stillActive?.pid || job.status !== "canceled") {
      return;
    }
    try {
      process.kill(-stillActive.pid, "SIGKILL");
    } catch {
      try {
        process.kill(stillActive.pid, "SIGKILL");
      } catch {
        // Already stopped.
      }
    }
  }, 8000).unref();
}

function cancelJob(id) {
  const job = jobs.get(id);
  if (!job) {
    const error = new Error("Job nicht gefunden.");
    error.statusCode = 404;
    throw error;
  }
  if (job.status === "completed" || job.status === "error" || job.status === "canceled") {
    return job;
  }
  const canceledAt = nowIso();
  job.cancelRequestedAt = canceledAt;
  job.canceledAt = canceledAt;
  if (job.status === "queued") {
    job.status = "canceled";
    job.stage = "Aus Warteschlange entfernt";
    job.error = null;
    saveJob(job);
    return job;
  }
  job.status = "canceled";
  job.stage = "Stop wird ausgeführt";
  job.error = null;
  saveJob(job);
  stopChildProcess(job);
  return job;
}

function removeJob(id) {
  const job = jobs.get(id);
  if (!job) {
    const error = new Error("Job nicht gefunden.");
    error.statusCode = 404;
    throw error;
  }
  if (job.status === "running") {
    const error = new Error("Laufender Job muss zuerst gestoppt werden.");
    error.statusCode = 409;
    throw error;
  }
  jobs.delete(id);
  try {
    fs.unlinkSync(path.join(JOB_DIR, `${job.id}.json`));
  } catch {
    // If the file is already gone, the in-memory removal is still valid.
  }
  queuePump();
  return job;
}

function queuePump() {
  if (activeJobId) {
    return;
  }
  const next = [...jobs.values()]
    .filter((job) => job.status === "queued")
    .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime())[0];
  if (!next) {
    return;
  }
  activeJobId = next.id;
  runJob(next);
}

async function createJob(payload) {
  const resolution = await resolveReportTicker(payload?.ticker);
  const ticker = resolution.ticker;
  const modelProfile = resolveModelProfile(payload);
  const provider = normalizeProvider(modelProfile.provider);
  assertPaidProviderAllowed(provider, payload);
  const quickModel = modelProfile.quickModel || "deepseek-v4-pro:cloud";
  const deepModel = modelProfile.deepModel || "deepseek-v4-pro:cloud";
  const providerBlock = recentProviderLimitBlock(provider, quickModel, deepModel);
  if (providerBlock && !payload?.forceProviderRetry) {
    const error = new Error(
      `Provider-Limit aktiv: ${provider}/${deepModel} wurde gerade bei ${providerBlock.ticker} mit Wochenlimit blockiert. Nicht erneut gestartet, damit keine weiteren Fehlläufe entstehen.`
    );
    error.statusCode = 429;
    throw error;
  }
  const createdAt = nowIso();
  const id = `${localTimeStamp()}-${ticker.toLowerCase()}-${randomUUID().slice(0, 8)}`;
  const runDir = path.join(BATCH_RUNS_DIR, id);
  const job = {
    id,
    ticker,
    requestedInput: String(payload?.ticker || "").trim(),
    tickerResolution: resolution,
    status: "queued",
    stage: "Warteschlange",
    createdAt,
    updatedAt: createdAt,
    analysisDate: payload?.analysisDate || previousBusinessDateString(),
    provider,
    quickModel,
    deepModel,
    modelProfileId: modelProfile.id,
    modelProfileLabel: modelProfile.label,
    comparisonId: payload?.comparisonId || null,
    withPremium: Boolean(payload?.withPremium),
    runDir,
    logPath: path.join(LOG_DIR, `${id}.log`),
    commandHistory: []
  };
  jobs.set(id, job);
  saveJob(job);
  queuePump();
  return job;
}

async function createComparison(payload = {}) {
  const requestedProfileIds = Array.isArray(payload?.modelProfileIds)
    ? [...new Set(payload.modelProfileIds.map((item) => String(item || "").trim()).filter(Boolean))]
    : [];
  if (requestedProfileIds.length < 2) {
    const error = new Error("Vergleich braucht mindestens zwei Modellprofile.");
    error.statusCode = 400;
    throw error;
  }
  const selectedProfiles = requestedProfileIds.map((modelProfileId) => resolveModelProfile({ modelProfileId }));
  const resolution = await resolveReportTicker(payload?.ticker);
  const ticker = resolution.ticker;
  const createdAt = nowIso();
  const id = `${localTimeStamp()}-${ticker.toLowerCase()}-cmp-${randomUUID().slice(0, 8)}`;
  const comparison = {
    id,
    ticker,
    requestedInput: String(payload?.ticker || "").trim(),
    tickerResolution: resolution,
    analysisDate: payload?.analysisDate || previousBusinessDateString(),
    createdAt,
    updatedAt: createdAt,
    modelProfileIds: selectedProfiles.map((profile) => profile.id),
    results: []
  };
  ensureDir(COMPARISON_DIR);
  for (const profile of selectedProfiles) {
    try {
      const job = await createJob({
        ticker,
        analysisDate: comparison.analysisDate,
        modelProfileId: profile.id,
        comparisonId: id,
        withPremium: Boolean(payload?.withPremium),
        forceProviderRetry: Boolean(payload?.forceProviderRetry),
        confirmPaidProvider: Boolean(payload?.confirmPaidProvider)
      });
      comparison.results.push({
        profileId: profile.id,
        profileLabel: profile.label,
        status: "queued",
        jobId: job.id,
        error: null
      });
    } catch (error) {
      comparison.results.push({
        profileId: profile.id,
        profileLabel: profile.label,
        status: "blocked",
        jobId: null,
        statusCode: error.statusCode || 500,
        error: error.message || String(error)
      });
    }
    saveComparison(comparison);
  }
  return comparison;
}

async function retryJob(id) {
  const original = jobs.get(id);
  if (!original) {
    const error = new Error("Job nicht gefunden.");
    error.statusCode = 404;
    throw error;
  }
  if (!["error", "canceled"].includes(original.status)) {
    const error = new Error("Nur fehlgeschlagene oder gestoppte Jobs können erneut gestartet werden.");
    error.statusCode = 409;
    throw error;
  }
  return createJob({
    ticker: original.requestedInput || original.ticker,
    analysisDate: original.analysisDate,
    modelProfileId: original.modelProfileId || undefined,
    provider: original.modelProfileId ? undefined : original.provider,
    quickModel: original.modelProfileId ? undefined : original.quickModel,
    deepModel: original.modelProfileId ? undefined : original.deepModel,
    withPremium: original.withPremium
  });
}

function registerApi(app) {
  app.use(express.json({ limit: "1mb" }));

  app.get("/api/health", (_req, res) => {
    const defaultProfile = defaultModelProfile();
    const reportLibrary = buildPublicLibrary();
    res.json({
      ok: true,
      projectRoot: PROJECT_ROOT,
      shelfDir: SHELF_DIR,
      activeJobId,
      defaultAnalysisDate: previousBusinessDateString(),
      defaultModelProfileId: defaultProfile.id,
      preflight: getPreflight(),
      hardening: getHardeningStatus(),
      reportLibrary: {
        version: reportLibrary.version,
        generatedAt: reportLibrary.generatedAt,
        summary: reportLibrary.summary
      }
    });
  });

  app.get("/api/state", (_req, res) => {
    const defaultProfile = defaultModelProfile();
    const reportLibrary = buildPublicLibrary();
    res.json({
      companies: scanShelf(),
      jobs: listJobs(),
      comparisons: listComparisons(),
      reportMachine: buildReportMachineStatus(),
      reportLibrary,
      tickerAliases: tickerAliasStats(),
      modelProfiles: modelProfiles(),
      defaults: {
        analysisDate: previousBusinessDateString(),
        provider: defaultProfile.provider,
        quickModel: defaultProfile.quickModel,
        deepModel: defaultProfile.deepModel,
        modelProfileId: defaultProfile.id,
        shelfDir: SHELF_DIR
      },
      preflight: getPreflight(),
      hardening: getHardeningStatus()
    });
  });

  app.get("/api/companies", (_req, res) => {
    res.json({ companies: scanShelf() });
  });

  app.get("/api/public-library", (_req, res) => {
    res.json({ reportLibrary: buildPublicLibrary() });
  });

  app.get("/api/report-machine", (_req, res) => {
    res.json({ reportMachine: buildReportMachineStatus() });
  });

  app.post("/api/public-library/:id/review", (req, res) => {
    if (!requireMutatingApiAccess(req, res)) return;
    try {
      const entry = updatePublicLibraryEntry(req.params.id, req.body || {});
      res.json({ entry, reportLibrary: buildPublicLibrary() });
    } catch (error) {
      res.status(error.statusCode || 500).json({ error: error.message || String(error) });
    }
  });

  app.delete("/api/public-library/:id", (req, res) => {
    if (!requireMutatingApiAccess(req, res)) return;
    try {
      const entry = dismissPublicLibraryEntry(req.params.id, req.body || {});
      res.json({ dismissed: true, entry, reportLibrary: buildPublicLibrary() });
    } catch (error) {
      res.status(error.statusCode || 500).json({ error: error.message || String(error) });
    }
  });

  app.get("/api/membership-scope", (_req, res) => {
    res.status(404).json({ error: "Membership scope gehört nicht in die Room-16-Admin-App." });
  });

  app.get("/api/companies/:ticker", (req, res) => {
    const company = findCompany(req.params.ticker);
    if (!company) {
      res.status(404).json({ error: "Unternehmen nicht gefunden." });
      return;
    }
    res.json({ company });
  });

  app.get("/api/jobs", (_req, res) => {
    res.json({ jobs: listJobs() });
  });

  app.get("/api/comparisons", (_req, res) => {
    res.json({ comparisons: listComparisons() });
  });

  app.get("/api/comparisons/:id", (req, res) => {
    try {
      const comparison = requireComparison(req.params.id);
      res.json({ comparison: hydrateComparison(comparison) });
    } catch (error) {
      res.status(error.statusCode || 500).json({ error: error.message || String(error) });
    }
  });

  app.post("/api/jobs", async (req, res) => {
    if (!requireMutatingApiAccess(req, res)) return;
    try {
      const job = await createJob(req.body);
      res.status(202).json({ job: publicJob(job) });
    } catch (error) {
      res.status(error.statusCode || 500).json({ error: error.message || String(error) });
    }
  });

  app.post("/api/comparisons", async (req, res) => {
    if (!requireMutatingApiAccess(req, res)) return;
    try {
      const comparison = await createComparison(req.body);
      res.status(202).json({ comparison: hydrateComparison(comparison) });
    } catch (error) {
      res.status(error.statusCode || 500).json({ error: error.message || String(error) });
    }
  });

  app.post("/api/comparisons/:id/evaluate", (req, res) => {
    if (!requireMutatingApiAccess(req, res)) return;
    try {
      const comparison = requireComparison(req.params.id);
      const evaluation = writeComparisonEvaluation(comparison);
      res.json({ evaluation, comparison: hydrateComparison(comparison) });
    } catch (error) {
      res.status(error.statusCode || 500).json({ error: error.message || String(error) });
    }
  });

  app.get("/api/symbols/resolve", async (req, res) => {
    try {
      const resolution = await resolveReportTicker(req.query.q);
      res.json({ resolution });
    } catch (error) {
      res.status(error.statusCode || 500).json({ error: error.message || String(error) });
    }
  });

  app.get("/api/jobs/:id", (req, res) => {
    const job = jobs.get(req.params.id);
    if (!job) {
      res.status(404).json({ error: "Job nicht gefunden." });
      return;
    }
    res.json({ job: publicJob(job) });
  });

  app.post("/api/jobs/:id/cancel", (req, res) => {
    if (!requireMutatingApiAccess(req, res)) return;
    try {
      const job = cancelJob(req.params.id);
      res.json({ job: publicJob(job) });
    } catch (error) {
      res.status(error.statusCode || 500).json({ error: error.message || String(error) });
    }
  });

  app.post("/api/jobs/:id/retry", async (req, res) => {
    if (!requireMutatingApiAccess(req, res)) return;
    try {
      const job = await retryJob(req.params.id);
      res.status(202).json({ job: publicJob(job) });
    } catch (error) {
      res.status(error.statusCode || 500).json({ error: error.message || String(error) });
    }
  });

  app.post("/api/jobs/retry-failed", async (req, res) => {
    if (!requireMutatingApiAccess(req, res)) return;
    try {
      const result = await retryRecoverableJobs(req.body || {});
      res.status(202).json(result);
    } catch (error) {
      res.status(error.statusCode || 500).json({ error: error.message || String(error) });
    }
  });

  app.delete("/api/jobs/:id", (req, res) => {
    if (!requireMutatingApiAccess(req, res)) return;
    try {
      const job = removeJob(req.params.id);
      res.json({ removed: true, job: publicJob(job) });
    } catch (error) {
      res.status(error.statusCode || 500).json({ error: error.message || String(error) });
    }
  });

  app.get("/api/jobs/:id/log", (req, res) => {
    const job = jobs.get(req.params.id);
    if (!job) {
      res.status(404).type("text/plain").send("Job nicht gefunden.");
      return;
    }
    res.type("text/plain").send(readTail(job.logPath, 220));
  });

  app.get("/api/reports/:id", (req, res) => {
    const filePath = resolveAllowedFile(req.params.id, [SHELF_DIR, REPORT_RUNS_DIR]);
    if (!filePath || !filePath.toLowerCase().endsWith(".pdf")) {
      res.status(404).send("Report nicht gefunden.");
      return;
    }
    res.type("application/pdf").sendFile(filePath);
  });

  app.get("/api/reports/latest/:ticker", (req, res) => {
    const company = findCompany(req.params.ticker);
    if (!company?.latestReport) {
      res.status(404).json({ error: "Latest Report nicht gefunden." });
      return;
    }
    res.json({ company, report: company.latestReport });
  });

  app.get("/api/reports/latest/:ticker/pdf", (req, res) => {
    const company = findCompany(req.params.ticker);
    const filePath = company?.latestReport?.localPath;
    const resolved = filePath ? resolveAllowedFile(encodeId(filePath), [SHELF_DIR, REPORT_RUNS_DIR]) : null;
    if (!resolved || !resolved.toLowerCase().endsWith(".pdf")) {
      res.status(404).send("Latest Report nicht gefunden.");
      return;
    }
    res.type("application/pdf").sendFile(resolved);
  });

  app.get("/api/reports/latest/:ticker/markdown", (req, res) => {
    const company = findCompany(req.params.ticker);
    const filePath = latestMarkdownPath(company);
    if (!filePath) {
      res.status(404).type("text/plain").send("Markdown-Dossier nicht gefunden.");
      return;
    }
    const qualityRun = qualityRunForArtifactMarkdown(filePath);
    const markdown = fs.readFileSync(filePath, "utf8");
    res.type("text/markdown; charset=utf-8").send(renderMarkdownWithQualityDecision(markdown, qualityRun, filePath));
  });

  app.get("/api/failures/:id", (req, res) => {
    const filePath = resolveAllowedFile(req.params.id, [FAILURE_DIR]);
    if (!filePath || !filePath.toLowerCase().endsWith(".md")) {
      res.status(404).type("text/plain").send("Fehlerbericht nicht gefunden.");
      return;
    }
    res.type("text/markdown; charset=utf-8").sendFile(filePath);
  });

  app.get("/api/artifacts/:id/markdown", (req, res) => {
    const filePath = resolveAllowedFile(req.params.id, [REPORT_RUNS_DIR, COMPARISON_DIR, FAILURE_DIR]);
    if (!filePath || !filePath.toLowerCase().endsWith(".md")) {
      res.status(404).type("text/plain").send("Markdown-Artefakt nicht gefunden.");
      return;
    }
    const qualityRun = qualityRunForArtifactMarkdown(filePath);
    const markdown = fs.readFileSync(filePath, "utf8");
    res.type("text/markdown; charset=utf-8").send(renderMarkdownWithQualityDecision(markdown, qualityRun, filePath));
  });
}

async function main() {
  ensureDir(RUNTIME_ROOT);
  ensureDir(JOB_DIR);
  ensureDir(LOG_DIR);
  ensureDir(FAILURE_DIR);
  ensureDir(COMPARISON_DIR);
  loadJobs();
  setInterval(reconcileRecoveredJobs, 15000).unref();

  const app = express();
  registerApi(app);

  if (devMode) {
    const vite = await createViteServer({
      root: APP_ROOT,
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(APP_ROOT, "dist");
    app.use(
      express.static(distDir, {
        etag: false,
        lastModified: false,
        setHeaders(res) {
          res.setHeader("Cache-Control", "no-store, max-age=0");
        }
      })
    );
    app.use((_req, res) => {
      res.setHeader("Cache-Control", "no-store, max-age=0");
      res.sendFile(path.join(distDir, "index.html"));
    });
  }

  httpServer = app.listen(PORT, HOST, () => {
    console.log(`Room 16 App listening at http://${HOST}:${PORT}`);
  });
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
