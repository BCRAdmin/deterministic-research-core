# Secret And Redaction Policy

Enthalten:
- relevanter Quellcode
- Diffs
- Dependency-Manifeste und Lockfiles, soweit klein genug und nicht secret-haltig
- lokale Verifier-Outputs
- Vault-Kontext
- Maturity-/Closure-/Hardening-Evidence

Nicht enthalten:
- `.env*`, `.npmrc`, `.pypirc`, private keys, Zertifikate, Tokens, echte Credentials
- `node_modules`, `.venv`, `.next`, `dist`, `.runtime`, Build-/Cache-/Packaging-Artefakte
- große Binärdateien und App-Bundles

Textdateien werden zusätzlich auf typische Secret-Patterns gescannt und Treffer werden ersetzt. Das Ergebnis steht in `SECRET_REDACTION_REPORT.json`.
